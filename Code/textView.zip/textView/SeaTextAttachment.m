//
//  SeaTextAttachment.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextAttachment.h"
#import <CoreText/CoreText.h>

@implementation SeaTextAttachment

- (void)dealloc
{
    [_image release];
    [_thumbnail release];
    
    [super dealloc];
}

/**等比例缩小图片
 *@param w 限制的宽度
 */
- (void)shrinkImageWithWidth:(CGFloat) w
{
    CGSize retSize = CGSizeZero;
    CGFloat width = self.image.size.width;
    CGFloat height = self.image.size.height;
    
    if(width == height)
    {
        width = width > w ? w : width;
        height = width;
    }
    else
    {
        CGFloat widthScale = width / w;

        if(width > w)
        {
            height = floorf(height / widthScale);
            width = floorf(width / widthScale);
        }
    }
    
    retSize = CGSizeMake(width, height);
    
    CGRect bounds = self.bounds;
    bounds.size = retSize;
    self.bounds = bounds;
  
    [self useThumbnail];
}

//生成缩略图
- (void)useThumbnail
{
    if(!self.image )
        return;
    CGSize size = self.bounds.size;
    CGImageRef cgImage = self.image.CGImage;
    size_t width = CGImageGetWidth(cgImage);
    
    if(size.width >= width)
    {
        self.thumbnail = self.image;
        return;
    }
    
    
    UIGraphicsBeginImageContextWithOptions(size, NO, 0.0f);
    CGRect imageRect = CGRectMake(0.0, 0.0, size.width, size.height);
    [self.image drawInRect:imageRect];
    UIImage *thumbnail = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    NSData *data = UIImageJPEGRepresentation(thumbnail, 0.9);

    UIImage *ret = nil;

    ret = [UIImage imageWithData:data scale:thumbnail.scale];

    
    if(ret.imageOrientation != UIImageOrientationUp)
    {
        ret = [UIImage imageWithCGImage:ret.CGImage scale:ret.scale orientation:UIImageOrientationUp];
    }
    
    self.thumbnail = ret;
}

#pragma mark- class method

/**重新排序附件 升序
 *@param attachments 要排序的附件信息，数组元素是 SeaTextAttachment
 */
+ (void)sortAttachments:(NSMutableArray*) attachments
{
    [attachments sortUsingComparator:^NSComparisonResult(id obj1, id obj2){
        
        SeaTextAttachment *att1 = (SeaTextAttachment*)obj1;
        SeaTextAttachment *att2 = (SeaTextAttachment*)obj2;
        
        if(att1.range.location < att2.range.location)
        {
            return NSOrderedAscending;
        }
        else if(att1.range.location > att2.range.location)
        {
            return NSOrderedDescending;
        }
        else
        {
            return NSOrderedSame;
        }
    }];
}

+ (NSAttributedString*)attributedStringWithAttachment:(SeaTextAttachment *)attachment string:(NSString *)string
{
    if(attachment == nil)
        return nil;
    
    NSString *content = string;
    if(content == nil)
    {
        content = [NSString stringWithCharacters:&SeaAttachmentCharacter length:SeaAttachmentCharacterLength];
    }
    
    //设定图片绘制代理
    CTRunDelegateCallbacks imageCallBack;
    imageCallBack.version = kCTRunDelegateCurrentVersion;
    imageCallBack.dealloc = RunDelegateDealloc;
    imageCallBack.getAscent = RunDelegateGetAscent;
    imageCallBack.getDescent = RunDelegateGetDescent;
    imageCallBack.getWidth = RunDelegateGetWidth;
    
    CTRunDelegateRef runDelegate = CTRunDelegateCreate(&imageCallBack,(void*)[attachment retain]);
    
    if(runDelegate != NULL)
    {
        NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:content];
        NSRange range = NSMakeRange(0, SeaAttachmentCharacterLength);
        
        [tmp addAttribute:(NSString*)kCTRunDelegateAttributeName value:(id)runDelegate range:range];
        [tmp addAttribute:SeaAttachmentAttributeName value:attachment range:range];
        
        CFRelease(runDelegate);
        return [tmp autorelease];
    }
    return nil;
}

@end

#pragma mark- CTRunDelegateCallbacks

void RunDelegateDealloc(void* refCon)
{
    SeaTextAttachment *attachment = (SeaTextAttachment*)refCon;
    [attachment release];
}

CGFloat RunDelegateGetAscent(void* refCon)
{
    SeaTextAttachment *attachment = (SeaTextAttachment*)refCon;
    return attachment.bounds.size.height;
    // return 0;
}

CGFloat RunDelegateGetDescent(void* refCon)
{
    //    SeaTextAttachment *attachment = (SeaTextAttachment*)refCon;
    //    return - attachment.bounds.size.height;
    return 0.0;
}

CGFloat RunDelegateGetWidth(void* refCon)
{
    SeaTextAttachment *attachment = (SeaTextAttachment*)refCon;
    return attachment.bounds.size.width;
}
