//
//  SeaTextSelectedDragView.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextSelectedDragView.h"

@implementation SeaTextSelectedDragCircleLayer


@end

@implementation SeaTextSelectedDragRodLayer

@end

@interface SeaTextSelectedDragView ()

@property(nonatomic,retain) SeaTextSelectedDragCircleLayer *circle;
@property(nonatomic,retain) SeaTextSelectedDragRodLayer *rod;

@end

@implementation SeaTextSelectedDragView

/**构造方法
 *style 文本选择拖动杆类型
 *@return 一个初始化的 SeaTextSelectedDragView 对象
 */
- (id)initWithFrame:(CGRect)frame style:(SeaTextSelectedDragStyle) style
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _style = style;
        self.backgroundColor = [UIColor clearColor];
        self.fillColor = [UIColor colorWithRed:0.259f green:0.420f blue:0.949f alpha:1.0f];
        
        self.circle = [SeaTextSelectedDragCircleLayer layer];
        self.circle.backgroundColor = self.fillColor.CGColor;
        self.circle.masksToBounds = YES;
        
        self.rod = [SeaTextSelectedDragRodLayer layer];
        self.rod.backgroundColor = self.fillColor.CGColor;
        
        [self.layer addSublayer:self.circle];
        [self.layer addSublayer:self.rod];
        
        [self setNeedsLayout];
    }
    return self;
}

- (void)dealloc
{
    [_fillColor release];
    [_rod release];
    [_circle release];
    
    [super dealloc];
}

- (void)setFillColor:(UIColor *)fillColor
{
    if(_fillColor != fillColor)
    {
        [_fillColor release];
        _fillColor = [fillColor retain];
        self.circle.backgroundColor = _fillColor.CGColor;
        self.rod.backgroundColor = _fillColor.CGColor;
        [self setNeedsDisplay];
    }
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    [self setNeedsLayout];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    switch (_style)
    {
        case SeaTextSelectedDragStyleUp :
        {
            self.circle.frame = CGRectMake((self.frame.size.width - _textSelectedDragCircleRadius_ * 2) / 2.0, 0, _textSelectedDragCircleRadius_ * 2, _textSelectedDragCircleRadius_ * 2);
            self.rod.frame = CGRectMake((self.frame.size.width - _textSelectedDragRodWidth_) / 2.0, self.circle.frame.size.height, _textSelectedDragRodWidth_, self.frame.size.height - self.circle.frame.size.height);
        }
            break;
        case SeaTextSelectedDragStyleDown :
        {
            self.circle.frame = CGRectMake((self.frame.size.width - _textSelectedDragCircleRadius_ * 2) / 2.0, self.frame.size.height - _textSelectedDragCircleRadius_ * 2, _textSelectedDragCircleRadius_ * 2, _textSelectedDragCircleRadius_ * 2);
            self.rod.frame = CGRectMake((self.frame.size.width - _textSelectedDragRodWidth_) / 2.0, 0, _textSelectedDragRodWidth_, self.frame.size.height - self.circle.frame.size.height);
        }
            break;
        default:
            break;
    }
    
    self.circle.cornerRadius = self.circle.frame.size.width / 2.0;
}



@end
