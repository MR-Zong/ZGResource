//
//  SeaTextStorage.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

//CGFloat BNRTimeBlock (void (^block)(void));

#define _maxFloat_ 8388608.0

@class SeaTextStorage;
@class SeaTextAttachment;
@class SeaTextContainer;
@class SeaTextView;

@protocol SeaTextStorageDelegate <NSObject>

@optional

/**将要要改变attributes
 */
- (void)textStorageWillProcessEditing:(SeaTextStorage *)textStorage;

/**已修改attributes
 */
- (void)textStorageDidProcessEditing:(SeaTextStorage *)textStorage;

/**获取编辑器基本样式
 */
- (NSDictionary*)textStorageGetDefaultAttributes:(SeaTextStorage*)textStorage;

/**删除附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (void)textStorage:(SeaTextStorage*) textStorage willDeleteAttachments:(NSArray*) attachments;

/**内容改变
 */
- (void)textStorageContentDidChange:(SeaTextStorage *)textStorage;

/**内容将要改变
 */
- (void)textStorageContentWillChange:(SeaTextStorage *)textStorage;

@end

/**文本储存类
 */
@interface SeaTextStorage : NSObject

@property(nonatomic,assign) id<SeaTextStorageDelegate> delegate;

@property(nonatomic,readonly) NSMutableAttributedString *attributedText;

/**段落信息 数组元素是 SeaTextParagraphInfo对象
 */
@property(nonatomic,readonly) NSMutableArray *paragraphInfos;

/**改变的段落信息 数组元素是 SeaTextParagraphInfo
 */
@property(nonatomic,readonly) NSMutableArray *changedParagraphInfos;

/**文本容器
 */
@property(nonatomic,assign) SeaTextContainer *textContainer;

/**编辑器
 */
@property(nonatomic,assign) SeaTextView *textView;

/**替换文本 如果range
 *@param 替换的范围 range
 *@param str 新的文本
 */
- (void)replaceCharactersInRange:(NSRange)range withString:(NSString *)str;

/**插入文本
 */
- (void)insertAttributedString:(NSAttributedString *)attrString atIndex:(NSUInteger)loc;

/**替换文本
 */
- (void)replaceCharactersInRange:(NSRange)range withAttributedString:(NSAttributedString *)attrString;

/**添加附件
 *@param attachments 数组元素是 SeaTextAttachment
 *@return 返回插入字符的长度
 */
- (NSInteger)insertAttachments:(NSArray*) attachments atIndex:(NSInteger) index;

/**替换附件
 *@param attachment新的附件
 *@param range 要替换的范围
 */
- (void)replaceAttachmentInRange:(NSRange) range withAttachment:(SeaTextAttachment*) attachment;

/**删除文本
 */
- (void)deleteCharactersInRange:(NSRange)range;

/**设置文本
 */
- (void)setAttributedString:(NSAttributedString*) attrString;

/**设置文本样式
 */
- (BOOL)addAttributes:(NSDictionary *)attrs range:(NSRange)range;

/**子文本
 */
- (NSAttributedString*)attributedSubstringFromRange:(NSRange) range;

/**刷新文本
 *@param 选中的文本
 *@param str 新的文本
 */
- (void)refreshTextInRange:(NSRange) selectedRange string:(NSString*) str;

/**文本高度
 */
- (CGFloat)textHeight;

/**获取某一范围内附件
 *@param range 文本范围
 *@param count 要获取的附件数量
 *@return 数组元素是 SeaTextAttachment
 */
- (NSArray*)attachmentsInRange:(NSRange) range count:(NSInteger) count;

#pragma mark- class method

/**附件标记
 */
+ (NSString*)attachmentMarkedString;

/**附件属性
 *@param string 附件内容
 *@param attachments 数组元素是 SeaTextAttachment
 */
+ (NSMutableAttributedString*)attributeStringWitString:(NSString*) string attachments:(NSArray*) attachments;

/**默认样式
 */
+ (NSDictionary*)defaultAttributes;

@end
