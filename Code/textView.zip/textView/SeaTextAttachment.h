//
//  SeaTextAttachment.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

//文本附件属性
static NSString *const SeaAttachmentAttributeName = @"SeaAttachmentAttributeName";

//附件字符
static unichar SeaAttachmentCharacter = 0xfffc;

//附件字符总长 加上换行符长度
static const NSInteger SeaAttachmentStringLength = 2;

//附件字符长度
static const NSInteger SeaAttachmentCharacterLength = 1;


/**文本附件
 */
@interface SeaTextAttachment : NSObject

/**附件大小
 */
@property(nonatomic,assign) CGRect bounds;

/**图片附件
 */
@property(nonatomic,retain) UIImage *image;

/**缩略图
 */
@property(nonatomic,retain) UIImage *thumbnail;

/**在文本中的范围
 */
@property(nonatomic,assign) NSRange range;

/**等比例缩小图片
 *@param w 限制的宽度
 */
- (void)shrinkImageWithWidth:(CGFloat) w;

#pragma mark- class method

/**重新排序附件 升序
 *@param attachments 要排序的附件信息，数组元素是 SeaTextAttachment 
 */
+ (void)sortAttachments:(NSMutableArray*) attachments;

/**获取附件富文本
 *@param attachment 附件
 *@param string 附件替换字符，可以为空，如果空则用默认的
 */
+ (NSAttributedString*)attributedStringWithAttachment:(SeaTextAttachment*) attachment string:(NSString*) string;

@end


#pragma mark- CTRunDelegateCallbacks

UIKIT_EXTERN void RunDelegateDealloc(void* refCon);

UIKIT_EXTERN CGFloat RunDelegateGetAscent(void* refCon);

UIKIT_EXTERN CGFloat RunDelegateGetDescent(void* refCon);

UIKIT_EXTERN CGFloat RunDelegateGetWidth(void* refCon);

