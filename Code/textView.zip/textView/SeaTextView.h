//
//  SeaTextView.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

/**判断两个 NSRange是否相等
 */
UIKIT_STATIC_INLINE BOOL NSRangeEqualToRange(NSRange r1, NSRange r2)
{
    if(r1.location == r2.location && r1.length == r2.length)
    {
        return YES;
    }
    return NO;
}

/** 范围1是否包含范围2
 */
UIKIT_STATIC_INLINE BOOL NSRangeContainRange(NSRange r1, NSRange r2)
{
    if(r1.location == NSNotFound || r2.location == NSNotFound)
        return NO;
    
    if(r2.length == 0)
    {
        if(r1.location <= r2.location && r1.location + r1.length >= r2.location)
        {
            return YES;
        }
    }
    else
    {
        NSRange range = NSIntersectionRange(r1, r2);
        if(range.length == 0)
            return NO;
        else
            return YES;
    }
    
    return NO;
}

@class SeaTextView;
@class SeaTextStorage;
@class SeaTextContainer;
@class SeaTextCaretView;
@class SeaTextAttachment;

/**文本编辑器代理
 */
@protocol SeaTextViewDelegate <NSObject>

@optional

/**开始编辑
 */
- (void)customTextViewDidBeginEditing:(SeaTextView*) textView;

/**结束编辑
 */
- (void)customTextViewDidEndEditing:(SeaTextView *)textView;

/**文本内容改变
 */
- (void)customTextViewDidChange:(SeaTextView *)textView;

/**选择状态改变
 */
- (void)customTextViewDidChangeSelection:(SeaTextView *)textView;

/**是否可以替换文本
 *@param range 替换的范围
 *@param text 新的文本
 */
- (BOOL)customTextView:(SeaTextView*) textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text;

/**插入图片
 */
- (void)customTextViewDidInsertImage:(SeaTextView*) textView;

/**删除附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (void)customTextView:(SeaTextView*) textView willDeleteAttachments:(NSArray*) attachments;

/**选择样式
 */
- (void)customTextViewDidSelectTextStyle:(SeaTextView *)textView;

/**粘贴附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (void)customTextView:(SeaTextView *)textView didPasteAttachemts:(NSArray *)attachments;

/**获取附件数量 通过外部获取 不用遍历
 *@return 数组元素是 SeaTextAttachment
 */
- (NSArray*)customTextViewDidGetAttachments:(SeaTextView*) textView;

/**插入附近成功
 *@param 附件字符长度
 */
- (void)customTextView:(SeaTextView *)textView didInsertAttachemtsInWithTextLength:(NSInteger) length;

/**长按附件
 *@param attachment 被长按的附件
 *@param index 附件所在段落的下标
 */
- (void)customTextView:(SeaTextView *)textView didLongPressAttachemt:(SeaTextAttachment*)attachment atParagraphIndex:(NSInteger) index;

/**附件被替换
 *@param attachment 旧的附件
 *@param otherAttachment 新的附件，空的时候为删除附件
 */
- (void)customTextView:(SeaTextView *)textView WillReplaceAttachemt:(SeaTextAttachment *)attachment withAttachemnt:(SeaTextAttachment*) otherAttachment;

/**撤销
 */
- (void)customTextViewDidUndo:(SeaTextView *)textView;

/**重做
 */
- (void)customTextViewDidRedo:(SeaTextView *)textView;

@end

/**文本编辑器
 */
@interface SeaTextView : UIScrollView<UITextInput,UITextInputTraits,UIScrollViewDelegate,UIGestureRecognizerDelegate>

/**文本内容限制数量 default is NSNotFound
 */
@property(nonatomic,assign) NSInteger maxCount;

/**图片最大数量 default is NSNotFound
 */
@property(nonatomic,assign) NSInteger maxImageCount;

/**文本段落最大数量，以图片作为分隔符 default is NSNotFound
 */
@property(nonatomic,assign) NSInteger maxParagraphCount;

/**文本数量超出提示样式 default is '[UIColor grayColor]'
 */
@property(nonatomic,retain) NSDictionary *remindAttributes;

/**文本编辑器代理
 */
@property(nonatomic,assign) id<SeaTextViewDelegate> textDelegate;

/**文本输入代理
 */
@property(nonatomic,assign) id<UITextInputDelegate> inputDelegate;

/**单击手势
 */
@property(nonatomic,readonly) UITapGestureRecognizer *tapGesture;

/**长按手势
 */
@property(nonatomic,readonly) UILongPressGestureRecognizer *longPressGesture;

/**基本字体
 */
@property(nonatomic,retain) UIFont *font;

/**支持的字体 数组元素是 NSString, default is 'nil',支持所有字体,粘贴时用到
 */
@property(nonatomic,retain) NSArray *supportedFontNames;

/**支持的字体大小 数组元素是 NSNumber floatValue, default is 'nil',支持所有字体大小,粘贴时用到
 */
@property(nonatomic,retain) NSArray *supportedFontSizes;

/**基本字体颜色
 */
@property(nonatomic,retain) UIColor *textColor;

/**支持的字体颜色 数组元素是 UIColor，default is 'nil'，支持所有颜色，粘贴时用到
 */
@property(nonatomic,retain) NSArray *supportedTextColors;

/**文本
 */
@property(nonatomic,copy) NSString *text;

/**样式文本
 */
@property(nonatomic,copy) NSAttributedString *attributedText;

/**选中的部分 length = 0时表示光标的位置
 */
@property(nonatomic,assign) NSRange selectedRange;

/**文本输入高亮部分
 */
@property(nonatomic,assign) NSRange markedRange;

/**文本输入高亮样式
 */
@property(nonatomic,copy) NSDictionary *markedTextStyle;

/**是否可编辑 default is 'YES'
 */
@property(nonatomic,assign) BOOL editable;

/**是否可以编辑样式 default is 'YES'
 */
@property(nonatomic,assign) BOOL enableEidtTextStyle;

/**输入视图，default is ‘nil’,如果赋值，键盘将不显示
 */
@property(nonatomic,retain) UIView *inputView;

/**键盘输入附加视图
 */
@property(nonatomic,retain) UIView *inputAccessoryView;

/**文本边距 default is '{8,8,8,8}'
 */
@property(nonatomic,assign) UIEdgeInsets textInset;

/**文本容器
 */
@property(nonatomic,readonly) SeaTextContainer *textContainer;

/**文本储存器
 */
@property(nonatomic,readonly) SeaTextStorage *textStorage;

/**选中的背景
 */
@property(nonatomic,retain) UIColor *selectedColor;

/**编辑光标
 */
@property(nonatomic,readonly) SeaTextCaretView *textCaretView;

/**placeHolder 提示信息 default is 'nil'
 */
@property(nonatomic,copy) NSString *placeHolder;

/**placeholder 的字体颜色. default is '[UIColor colorWithWhite:0.702f alpha:0.7]'.
 */
@property (nonatomic, retain) UIColor *placeholderTextColor;
/** placeholder的字体 default is '[UIFont systemFontOfSize:16.0]'
 */
@property (nonatomic, retain) UIFont *placeholderFont;

/** placeholder画的起始位置 default is 'CGPointMake(0.0f, 0.0f)'
 */
@property (nonatomic, assign) CGPoint placeholderOffset;

#pragma mark public method

//获取基本样式
- (NSDictionary*)defaultAttributes;

/**添加附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (void)insertAttachments:(NSArray*) attachments atIndex:(NSInteger) index;

/**替换附件
 *@param attachment 旧的附件
 *@param otherAttachment 新的附件，空的时候为删除附件
 *@param index 附件所在段落
 */
- (void)replaceAttachment:(SeaTextAttachment*) attachment withAttachment:(SeaTextAttachment*) otherAttachment paragraphIndex:(NSInteger) index;

/**获取所有附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (NSArray*)attachments;

/**设置文本样式
 */
- (void)addAttributes:(NSDictionary *)attrs range:(NSRange)range;

/**获取文本内容最大宽度
 */
- (CGFloat)maxTextWidth;

/**最小文本容器
 */
- (CGSize)minTextContainerSize;

/**创建附件
 *@param 附件图片 不能为空
 */
- (SeaTextAttachment*)attachmentWithImage:(UIImage*) image;

/**选择样式
 */
- (void)selectTextStyle:(id) sender;

/**插入图片
 */
- (void)insertImage:(id) sender;

/**结束编辑
 */
- (void)endEdit;

/**设置默认的附加视图
 */
- (void)setupDefaultInputAccessoryView;

/**获取分离的文本信息
 *@return 数组元素信息 SeaTextViewTextInfo对象
 */
- (NSArray*)getSeparatedTextInfo;

/**获取分段数量 以连续的图片作为分隔符
 *@param flag 是否需要获取文本内容
 *@return 数组元素信息 SeaTextViewTextInfo对象
 */
- (NSMutableArray*)textParagraphCountAndImageCount:(BOOL) flag;

@end
