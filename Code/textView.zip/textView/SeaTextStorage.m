//
//  SeaTextStorage.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextStorage.h"
#import "SeaTextAttachment.h"
#import "SeaTextContainer.h"
#import "SeaTextView.h"
#import <mach/mach_time.h>
#import "SeaTextParagraphInfo.h"

//方法执行耗时
//CGFloat BNRTimeBlock (void (^block)(void)) {
//    mach_timebase_info_data_t info;
//    if (mach_timebase_info(&info) != KERN_SUCCESS) return -1.0;
//    
//    uint64_t start = mach_absolute_time ();
//    block ();
//    uint64_t end = mach_absolute_time ();
//    uint64_t elapsed = end - start;
//    
//    uint64_t nanos = elapsed * info.numer / info.denom;
//    return (CGFloat)nanos / NSEC_PER_SEC;
//    
//}

@interface SeaTextStorage ()


@end

@implementation SeaTextStorage

#pragma mark- dealloc

- (id)init
{
    self = [super init];
    if(self)
    {
        _attributedText = [[NSMutableAttributedString alloc] init];
        _paragraphInfos = [[NSMutableArray alloc] init];
        _changedParagraphInfos = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    self.textContainer = nil;
    self.textView = nil;
    
    [_attributedText release];
    
    [_paragraphInfos release];
    [_changedParagraphInfos release];
    
    [super dealloc];
}

#pragma mark- public method

/**替换文本 如果range 越界将添加到后面
 *@param 替换的范围 range
 *@param str 新的文本
 */
- (void)replaceCharactersInRange:(NSRange)range withString:(NSString *)str
{
   // NSLog(@"%d,%d,%d", range.location, range.length,self.attributedText.length);
    //越界
    if(range.location == NSNotFound || (range.location + range.length) > self.attributedText.length)
    {
        return;
    }
    
    BOOL insert = NO;
    if(self.attributedText.length > 0)
    {
        //判断是否在图片后面输入文字
        NSRange newRange = NSMakeRange(MAX((NSInteger)range.location - SeaAttachmentStringLength, 0), SeaAttachmentStringLength);

        if(newRange.location != NSNotFound && newRange.location + newRange.length <= self.attributedText.length)
        {
            NSString *subStr = [self.attributedText.string substringWithRange:newRange];
            NSRange attachRange = [subStr rangeOfString:[SeaTextStorage attachmentMarkedString]];
            
            if(attachRange.location != NSNotFound && attachRange.length > 0)
            {
               // NSLog(@"图片后面 str = %@", str);
                insert = YES;
            }
        }
        
        //判断是否在图片前面
        if(str.length > 0 && self.attributedText.length - range.location >= SeaAttachmentStringLength)
        {
            newRange = NSMakeRange(range.location, SeaAttachmentStringLength);
            
            if(newRange.location + newRange.length <= self.attributedText.length)
            {
                NSString *subStr = [self.attributedText.string substringWithRange:newRange];
                NSRange attachRange = [subStr rangeOfString:[SeaTextStorage attachmentMarkedString]];
                
                if(attachRange.location != NSNotFound && attachRange.length > 0)
                {
                    //NSLog(@"图片前面 str = %@", str);
                    insert = YES;
                    
                    //判断是否有换行符
                    if([self.attributedText.string characterAtIndex:range.location] != '\n')
                    {
                        str = [NSString stringWithFormat:@"%@\n", str];
                    }
                }
            }
        }
    }
    else
    {
        insert = YES;
    }
    
    if([self.delegate respondsToSelector:@selector(textStorageContentWillChange:)])
    {
        [self.delegate textStorageContentWillChange:self];
    }
    
    if(insert)
    {
        NSDictionary *attributes = [self getDefaultAttributes];
        
        NSAttributedString *attributedString = [[NSAttributedString alloc] initWithString:str attributes:attributes];
        [self replaceCharactersInRange:range withAttributedString:attributedString];
        [attributedString release];
    }
    else
    {
        [self notifyDeletedAttachmentsInRange:range];
        [self changedParagraphsWithRange:range];
        [self.attributedText replaceCharactersInRange:range withString:str];
        [self refreshTextInRange:range string:str];
    }
}

/**插入文本
 */
- (void)insertAttributedString:(NSAttributedString *)attrString atIndex:(NSUInteger)loc
{
    if(loc > self.attributedText.length || attrString == nil)
    {
        return;
    }
    
    if([self.delegate respondsToSelector:@selector(textStorageContentWillChange:)])
    {
        [self.delegate textStorageContentWillChange:self];
    }
    
    [self changedParagraphsWithRange:NSMakeRange(loc, 0)];
    [self.attributedText insertAttributedString:attrString atIndex:loc];
    [self refreshTextInRange:NSMakeRange(loc, 0) string:attrString.string];
}

/**替换文本
 */
- (void)replaceCharactersInRange:(NSRange)range withAttributedString:(NSAttributedString *)attrString
{
    if(range.location + range.length > self.attributedText.length)
        return;
    
    if([self.delegate respondsToSelector:@selector(textStorageContentWillChange:)])
    {
        [self.delegate textStorageContentWillChange:self];
    }
    
    [self notifyDeletedAttachmentsInRange:range];
    [self changedParagraphsWithRange:range];
    [self.attributedText replaceCharactersInRange:range withAttributedString:attrString];
    [self refreshTextInRange:range string:attrString.string];
}

/**添加附件
 *@param attachments 数组元素是 SeaTextAttachment
 *@return 返回插入字符的长度
 */
- (NSInteger)insertAttachments:(NSArray*) attachments atIndex:(NSInteger) index
{
    NSMutableAttributedString *tmp = [SeaTextStorage attributeStringWitString:[SeaTextStorage attachmentMarkedString] attachments:attachments];
    
    if(tmp.length > 0)
    {
        if(self.attributedText.length == 0)
        {
            [tmp deleteCharactersInRange:NSMakeRange(0, 1)];
        }
        
        [tmp addAttributes:[self getDefaultAttributes] range:NSMakeRange(0, tmp.length)];

        //判断前后是否有换行符
        if(index == 0)
        {
           // [tmp replaceCharactersInRange:NSMakeRange(0, 1) withString:@""];
        }
        else if(index - 1 > 0 && index != NSNotFound)
        {
            char forword = [self.attributedText.string characterAtIndex:index - 1];
            if(forword == '\n' || forword == '\r')
            {
                [tmp replaceCharactersInRange:NSMakeRange(0, 1) withString:@""];
            }
        }
        
        [self insertAttributedString:tmp atIndex:index];
        
        return tmp.length;
    }
    
    return 0;
}

/**替换附件
 *@param attachment新的附件
 *@param range 要替换的范围
 */
- (void)replaceAttachmentInRange:(NSRange) range withAttachment:(SeaTextAttachment*) attachment
{
    if(range.location + range.length > self.attributedText.length || attachment == nil)
        return;
    NSMutableAttributedString *tmp = [SeaTextStorage attributeStringWitString:[SeaTextStorage attachmentMarkedString] attachments:[NSArray arrayWithObject:attachment]];
    
    if(tmp.length > 0)
    {
        if(self.attributedText.length == 0)
        {
            [tmp deleteCharactersInRange:NSMakeRange(0, 1)];
        }
        
        [tmp addAttributes:[self getDefaultAttributes] range:NSMakeRange(0, tmp.length)];
        
        NSInteger index = range.location;
        //判断前后是否有换行符
        if(index - 1 > 0 && index != NSNotFound)
        {
            char forword = [self.attributedText.string characterAtIndex:index - 1];
            if(forword == '\n' || forword == '\r')
            {
                [tmp replaceCharactersInRange:NSMakeRange(0, 1) withString:@""];
            }
        }
        
        [self replaceCharactersInRange:range withAttributedString:tmp];
    }
}

/**删除文本
 */
- (void)deleteCharactersInRange:(NSRange)range
{
    if(range.location + range.length > self.attributedText.length)
    {
        return;
    }
    
    if([self.delegate respondsToSelector:@selector(textStorageContentWillChange:)])
    {
        [self.delegate textStorageContentWillChange:self];
    }
    
    [self changedParagraphsWithRange:range];
    [self notifyDeletedAttachmentsInRange:range];
    [self.attributedText deleteCharactersInRange:range];
    [self refreshTextInRange:range string:nil];
}

/**设置文本
 */
- (void)setAttributedString:(NSAttributedString*) attrString
{
    if(self.attributedText.length > 0)
    {
        [self notifyDeletedAttachmentsInRange:NSMakeRange(0, self.attributedText.length)];
    }
    
    if([self.delegate respondsToSelector:@selector(textStorageContentWillChange:)])
    {
        [self.delegate textStorageContentWillChange:self];
    }
    
    [_changedParagraphInfos removeAllObjects];
    [_paragraphInfos removeAllObjects];
    [self.attributedText setAttributedString:attrString];
    [self refreshTextInRange:NSMakeRange(0, 0) string:self.attributedText.string];
  //  NSLog(@"length %d", self.attributedText.length);
}

/**设置文本样式
 */
- (BOOL)addAttributes:(NSDictionary *)attrs range:(NSRange)range
{
    // NSLog(@"addAttributes %@",attrs);
    if(range.location + range.length > self.attributedText.length || attrs == nil)
        return NO;
   
    if([self.delegate respondsToSelector:@selector(textStorageContentWillChange:)])
    {
        [self.delegate textStorageContentWillChange:self];
    }
    
    [self changedParagraphsWithRange:range];
    [self.attributedText addAttributes:attrs range:range];
    [self refreshTextInRange:range string:[self.attributedText.string substringWithRange:range]];
    return YES;
}

/**子文本
 */
- (NSAttributedString*)attributedSubstringFromRange:(NSRange) range
{
    if(range.location + range.length > self.attributedText.length)
        return nil;
    
    return [self.attributedText attributedSubstringFromRange:range];
}

/**刷新文本
 *@param 选中的文本
 *@param str 新的文本
 */
- (void)refreshTextInRange:(NSRange) selectedRange string:(NSString*) str
{
    if(str == nil)
        str = @"";
    
    CGFloat changedHeight = 0;
    CGFloat changedOriginalY = 0;
    NSRange range = NSMakeRange(NSNotFound, 0);
    
    //NSLog(@"chang %d", _changedParagraphInfos.count);
    for(NSInteger i = 0;i < _changedParagraphInfos.count;i ++)
    {
        SeaTextParagraphInfo *info = [_changedParagraphInfos objectAtIndex:i];
        changedHeight += info.rect.size.height;
        
        if(range.location == NSNotFound)
        {
            range.location = info.range.location;
        }
        range = NSUnionRange(range, info.range);
        
        if(i == _changedParagraphInfos.count - 1)
        {
            changedOriginalY = info.rect.origin.y;
        }
    }
    // NSLog(@"changedHeight %f", changedHeight);
    
    // NSLog(@"%@", NSStringFromRange(range));
    range.length = range.length - selectedRange.length + str.length;
    // NSLog(@"%@", NSStringFromRange(range));
    
    if(range.location == NSNotFound)
    {
        range = NSMakeRange(0, self.attributedText.length);
    }
    
    //判断最后是否有换行符
    NSInteger length = self.attributedText.length;
    if(length > 0 && range.location + range.length == length)
    {
        char c = [self.attributedText.string characterAtIndex:length - 1];
        if(c == '\n' || c == '\r')
        {
            NSDictionary *attributes = [self getDefaultAttributes];
            NSAttributedString *attributedString = [[NSAttributedString alloc] initWithString:@" " attributes:attributes];
            [self.attributedText appendAttributedString:attributedString];
            [attributedString release];
            range.length ++;
        }
    }
    
    
    if(self.textView != nil && self.attributedText.length > self.textView.maxCount)
    {
        [self.attributedText addAttributes:self.textView.remindAttributes range:NSMakeRange(self.textView.maxCount, self.attributedText.length - self.textView.maxCount)];
    }
    
    NSArray *infos = [self tokenizeTextInRange:range originalY:changedOriginalY];
    
   // NSLog(@"%d", infos.count);
    
    
    CGFloat newHeight = 0;
    for(SeaTextParagraphInfo *info in infos)
    {
        newHeight += info.rect.size.height;
    }
    
   // NSLog(@"newHeight = %f", newHeight);
    
    NSInteger insertedIndex = 0;
    if(_changedParagraphInfos.count > 0)
    {
        insertedIndex = [_paragraphInfos indexOfObject:[_changedParagraphInfos firstObject]];
        if(insertedIndex == NSNotFound)
            insertedIndex = 0;
    }
    
  //  NSLog(@"insertedIndex %d", insertedIndex);
    
    [_paragraphInfos removeObjectsInArray:_changedParagraphInfos];

    if(insertedIndex > self.paragraphInfos.count)
    {
        [self.paragraphInfos addObjectsFromArray:infos];
    }
    else
    {
        [self.paragraphInfos insertObjects:infos atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(insertedIndex, infos.count)]];
    }
    [_changedParagraphInfos removeAllObjects];
    
    //更新前面的段落
    for(NSInteger i = 0;i < insertedIndex && i < _paragraphInfos.count;i ++)
    {
        SeaTextParagraphInfo *info = [_paragraphInfos objectAtIndex:i];
        CGRect rect = info.rect;
        rect.origin.y = rect.origin.y - (changedHeight - newHeight);
        info.rect = rect;
        
        //NSLog(@"sort rect %@", NSStringFromCGRect(info.rect));
    }
    
    //更新后续的段落
    for(NSInteger i = (insertedIndex + infos.count);i < _paragraphInfos.count;i ++)
    {
        SeaTextParagraphInfo *info = [_paragraphInfos objectAtIndex:i];
        NSRange range = info.range;
        range.location = range.location - selectedRange.length + str.length;
        info.range = range;
    }
    
    if([self.delegate respondsToSelector:@selector(textStorageContentDidChange:)])
    {
        [self.delegate textStorageContentDidChange:self];
    }
    
//    for(NSInteger i = 0;i < 4 && i < _paragraphInfos.count;i ++)
//    {
//        SeaTextParagraphInfo *info = [_paragraphInfos objectAtIndex:i];
//        NSLog(@"%@,%@", NSStringFromRange(info.range), NSStringFromCGRect(info.rect));
//    }
}

/**文本高度
 */
- (CGFloat)textHeight
{
    SeaTextParagraphInfo *info = [_paragraphInfos firstObject];
    CGFloat height = info.rect.origin.y + info.rect.size.height;

    return MAX(height, self.textView.font.lineHeight);
}

/**获取某一范围内附件
 *@param range 文本范围
 *@param count 要获取的附件数量
 *@return 数组元素是 SeaTextAttachment
 */
- (NSArray*)attachmentsInRange:(NSRange) range count:(NSInteger) count
{
    if(range.length <= 0 || range.location + range.length > self.attributedText.length)
        return nil;
    
    NSMutableArray *attachments = [NSMutableArray array];
    [self.attributedText enumerateAttribute:SeaAttachmentAttributeName inRange:range options:NSAttributedStringEnumerationReverse usingBlock:^(id value, NSRange range, BOOL *stop){
        
        if([value isKindOfClass:[SeaTextAttachment class]])
        {
            SeaTextAttachment *attachment = (SeaTextAttachment*)value;
            attachment.range = NSMakeRange(range.location, SeaAttachmentStringLength);
            [attachments addObject:attachment];
        }
        
        if(attachments.count >= count)
        {
            *stop = YES;
        }
    }];
    
    //重新排序
    [SeaTextAttachment sortAttachments:attachments];
    
    return attachments;
}

#pragma mark- private method

/**分离段落
 *@param range 文本的范围
 *@param y 段落起点
 *@param 新的段落 数组元素是 SeaTextParagraphInfo 对象
 */
- (NSArray*)tokenizeTextInRange:(NSRange) range originalY:(CGFloat) y
{
    if(range.location == NSNotFound || range.location + range.length > self.attributedText.length)
        return [NSArray array];
    CFLocaleRef locale = CFLocaleCopyCurrent();
    
    NSString *subString = [self.attributedText.string substringWithRange:range];
    
    CFStringTokenizerRef tokenizer = CFStringTokenizerCreate(kCFAllocatorDefault, (CFStringRef) subString, CFRangeMake(0, subString.length), kCFStringTokenizerUnitParagraph, locale);
    
    NSMutableArray *ranges = [NSMutableArray array];
    
    while (CFStringTokenizerAdvanceToNextToken(tokenizer) != kCFStringTokenizerTokenNone)
    {
        CFRange subRange = CFStringTokenizerGetCurrentTokenRange(tokenizer);
        NSRange newRange = NSMakeRange(subRange.location == kCFNotFound ? NSNotFound : subRange.location + range.location, subRange.length);
        
        if(newRange.location != NSNotFound && newRange.length != NSNotFound && newRange.length != 0)
        {
            [ranges addObject:NSStringFromRange(newRange)];
        }
    }
    
    NSMutableArray *paragraphs = [[NSMutableArray alloc] initWithCapacity:ranges.count];
    for(NSInteger i = ranges.count - 1;i >= 0;i --)
    {
        NSRange newRange = NSRangeFromString([ranges objectAtIndex:i]);
        NSAttributedString *attributeString = [self attributedSubstringFromRange:newRange];
        
        if(attributeString != nil)
        {
            SeaTextParagraphInfo *info = [[SeaTextParagraphInfo alloc] init];
            info.range = newRange;
            [info createTextParagraphWithAttributedString:attributeString maxWidth:self.textContainer.bounds.size.width originalY:y];
           
           // NSLog(@"%@,%@", attributeString.string, NSStringFromCGRect(info.rect));
          //  NSLog(@"range %@", NSStringFromRange(info.range));
            y += info.rect.size.height;
            
            [paragraphs insertObject:info atIndex:0];
            [info release];
        }
    }
    
    CFRelease(locale);
    CFRelease(tokenizer);
    
    return [paragraphs autorelease];
}

/**删除要改变的段落
 *@param range 文本改变的范围
 */
- (void)changedParagraphsWithRange:(NSRange) range
{
    [_changedParagraphInfos removeAllObjects];
    // NSLog(@"change range %@", NSStringFromRange(range));
    
    if(range.location != NSNotFound && range.location + range.length <= self.attributedText.length)
    {
        NSString *subStr = [self.attributedText.string substringWithRange:range];
        if([subStr isEqualToString:@"\n"] || [subStr isEqualToString:@"\r"])
        {
            range.location = MAX((NSInteger)range.location - 1, 0);
            range.length += SeaAttachmentStringLength;
            
            if(range.location == NSNotFound)
            {
                range.location = 0;
            }
            
            if(range.location + range.length > self.attributedText.length)
            {
                range.length = self.attributedText.length - range.location;
            }
        }
    }
    
    //NSLog(@"change range %@", NSStringFromRange(range));
    
    for(NSInteger i = 0; i < _paragraphInfos.count;i ++)
    {
        SeaTextParagraphInfo *info = [_paragraphInfos objectAtIndex:i];
        if(NSRangeContainRange(info.range, range))
        {
            [_changedParagraphInfos addObject:info];
        }
    }
}

/**获取默认样式
 */
- (NSDictionary*)getDefaultAttributes
{
    NSDictionary *attributes = nil;
    if([self.delegate respondsToSelector:@selector(textStorageGetDefaultAttributes:)])
    {
        attributes = [self.delegate textStorageGetDefaultAttributes:self];
    }
    else
    {
        attributes = [SeaTextStorage defaultAttributes];
    }
    
    return attributes;
}

/**通知附件被删除
 *@param range 文本范围
 */
- (void)notifyDeletedAttachmentsInRange:(NSRange) range
{
    NSArray *attachments = [self attachmentsInRange:range count:NSNotFound];
    if(attachments.count > 0)
    {
        if([self.delegate respondsToSelector:@selector(textStorage:willDeleteAttachments:)])
        {
            [self.delegate textStorage:self willDeleteAttachments:attachments];
        }
    }
}

#pragma mark- class method

/**附件标记
 */
+ (NSString*)attachmentMarkedString
{
    return [NSString stringWithCharacters:&SeaAttachmentCharacter length:1];
}

/**附件属性
 *@param string 附件内容
 *@param attachments 数组元素是 SeaTextAttachment
 */
+ (NSMutableAttributedString*)attributeStringWitString:(NSString*) string attachments:(NSArray*) attachments
{
    if(attachments.count == 0)
        return nil;
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:@"\n"];
    NSString *content = [NSString stringWithFormat:@"%@\n", string];
    
    for(SeaTextAttachment *attachment in attachments)
    {
        NSAttributedString *attr = [SeaTextAttachment attributedStringWithAttachment:attachment string:content];
        [attributedString appendAttributedString:attr];
    }
    
    return [attributedString autorelease];
}

/**默认样式
 */
+ (NSDictionary*)defaultAttributes
{
    UIFont *font = [UIFont systemFontOfSize:16.0];
    CTFontRef ctFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
    
    //换行模式
    CTParagraphStyleSetting lineBreadMode;
    CTLineBreakMode linkBreak = kCTLineBreakByCharWrapping;
    lineBreadMode.spec = kCTParagraphStyleSpecifierLineBreakMode;
    lineBreadMode.value = &linkBreak;
    lineBreadMode.valueSize = sizeof(CTLineBreakMode);
    
    CTParagraphStyleSetting setting[] = {lineBreadMode};
    CTParagraphStyleRef style = CTParagraphStyleCreate(setting, 1);
    
    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:(id)[UIColor blackColor].CGColor, (NSString*)kCTForegroundColorAttributeName, (id)ctFont, (NSString*)kCTFontAttributeName, (id)style, (NSString*)kCTParagraphStyleAttributeName, nil];
    
    CFRelease(style);
    CFRelease(ctFont);
    return attributes;
}

@end
