//
//  SeaTextViewTextInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-11-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**编辑器文本信息
 */
@interface SeaTextViewTextInfo : NSObject

/**文本内容
 */
@property(nonatomic,copy) NSString *content;

/**文本后面的图片数量
 */
@property(nonatomic,assign) NSInteger imageCount;

/**在所有文本中的范围
 */
@property(nonatomic,assign) NSRange range;

@end
