//
//  SeaTextSelectedDragView.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

//圆半径
#define _textSelectedDragCircleRadius_ 5.0
//杆宽度
#define _textSelectedDragRodWidth_ 2.5

//
#define _textSelectedDragExpandWidth_ 70.0

/**杆
 */
@interface SeaTextSelectedDragRodLayer : CALayer

@end


/**圆点
 */
@interface SeaTextSelectedDragCircleLayer : CALayer


@end


/**文本选择拖动杆类型
 */
typedef NS_ENUM(NSInteger, SeaTextSelectedDragStyle)
{
    SeaTextSelectedDragStyleUp = 0, //圆在上方
    SeaTextSelectedDragStyleDown = 1, //圆在下方
};

/**文本选择拖动杆
 */
@interface SeaTextSelectedDragView : UIView

/**文本选择拖动杆类型
 */
@property(nonatomic,readonly) SeaTextSelectedDragStyle style;

/**颜色
 */
@property(nonatomic,retain) UIColor *fillColor;

/**构造方法
 *style 文本选择拖动杆类型
 *@return 一个初始化的 SeaTextSelectedDragView 对象
 */
- (id)initWithFrame:(CGRect)frame style:(SeaTextSelectedDragStyle) style;

@end
