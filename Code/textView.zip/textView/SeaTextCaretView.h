//
//  SeaTextCaretView.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

//光标宽度
#define _defaultTextCaretWidth_ 2.5

/**编辑器光标
 */
@interface SeaTextCaretView : UIView

/**是否真正动画
 */
@property(nonatomic,readonly) BOOL isAnimating;

/**开始动画
 */
- (void)startAnimated;

/**停止动画
 */
- (void)stopAnimated;


@end
