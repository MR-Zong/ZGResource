//
//  SeaTextPosition.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextPosition.h"

@implementation SeaTextPosition

/**构造方法
 *@param index 文本下标
 *@return 一个初始化的 SeaTextPosition 对象
 */
+ (SeaTextPosition*)textPositionWithIndex:(NSInteger) index
{
    SeaTextPosition *position = [[SeaTextPosition alloc] init];
    position.index = index;
    return [position autorelease];
}

@end
