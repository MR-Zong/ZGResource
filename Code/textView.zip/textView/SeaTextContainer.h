//
//  SeaTextContainer.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**文本绘制图层
 */
@interface SeaTextContainerTiledLayer : CATiledLayer

@end

@class SeaTextContainer;

/**文本容器代理
 */
@protocol SeaTextContainerDelegate <NSObject>

/**需要绘制文本
 *@param rect 绘制的rect
 *@param contenxt 画板
 */
- (void)textContainer:(SeaTextContainer*) container didNeedDrawContentInRect:(CGRect) rect context:(CGContextRef) context;

/**获取可见的部分
 */
- (CGRect)textContainerDidGetVisibleRect:(SeaTextContainer*) container;

@end

/**文本容器
 */
@interface SeaTextContainer : UIView

/**文本绘制图层
 */
@property(nonatomic,readonly) SeaTextContainerTiledLayer *textContainerTileLayer;

/**绘制代理
 */
@property(nonatomic,assign) id<SeaTextContainerDelegate> delegate;

/**撤销管理器
 */
@property(nonatomic,retain) NSUndoManager *undoManager;

/**是否可以编辑样式 default is 'YES'
 */
@property(nonatomic,assign) BOOL enableEidtTextStyle;

/**刷新某一部分的文本
 */
- (void)refreshVisibleRect;

/**刷新全部
 */
- (void)refreshAll;

/**获取正确的坐标，coreText坐标和 UIKit不同
 */
- (CGRect)UIKitRectFromRect:(CGRect) rect;

@end
