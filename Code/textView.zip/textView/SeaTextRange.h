//
//  SeaTextRange.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**文本的范围
 */
@interface SeaTextRange : UITextRange

/**文本的范围
 */
@property(nonatomic,assign) NSRange range;

/**构造方法
 *@param range 文本范围
 *@return 一个初始化的 SeaTextRange 对象
 */
+ (SeaTextRange*)textRangeWithRange:(NSRange) range;

@end
