//
//  SeaTextViewTextInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-11-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextViewTextInfo.h"

@implementation SeaTextViewTextInfo

- (void)dealloc
{
    [_content release];
    [super dealloc];
}

@end
