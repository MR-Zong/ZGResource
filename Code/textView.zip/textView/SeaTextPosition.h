//
//  SeaTextPosition.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeaTextPosition : UITextPosition

/**文本的下标
 */
@property(nonatomic,assign) NSInteger index;

/**构造方法
 *@param index 文本下标
 *@return 一个初始化的 SeaTextPosition 对象
 */
+ (SeaTextPosition*)textPositionWithIndex:(NSInteger) index;

@end
