//
//  SeaTextContainer.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextContainer.h"
#import "SeaTextStorage.h"
#import "SeaTextView.h"

@implementation SeaTextContainerTiledLayer

+ (CFTimeInterval)fadeDuration
{
    return 0;
}

@end

@implementation SeaTextContainer

@synthesize undoManager;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        SeaTextContainerTiledLayer *layer = self.textContainerTileLayer;
       // layer.backgroundColor = [UIColor redColor].CGColor;
        
        layer.levelsOfDetail = 1;
        layer.levelsOfDetailBias = 0;
        UIScreen *mainScreen = [UIScreen mainScreen];
        CGFloat largerDimension = MAX(mainScreen.applicationFrame.size.width, mainScreen.applicationFrame.size.height);
        CGFloat scale = mainScreen.scale;
        CGSize tileSize = CGSizeMake(largerDimension * scale, largerDimension * scale);
        layer.tileSize = tileSize;
    }
    return self;
}

- (void)dealloc
{
    self.undoManager = nil;
    [super dealloc];
}

- (void)setBackgroundColor:(UIColor *)backgroundColor
{
    [super setBackgroundColor:backgroundColor];
    self.layer.backgroundColor = backgroundColor.CGColor;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
}

+ (Class)layerClass
{
    return [SeaTextContainerTiledLayer class];
}

- (SeaTextContainerTiledLayer*)textContainerTileLayer
{
    return (SeaTextContainerTiledLayer*)self.layer;
}

- (void)drawLayer:(CALayer *)layer inContext:(CGContextRef)ctx
{
    CGContextSetTextMatrix(ctx, CGAffineTransformIdentity);//设置字形变换矩阵为CGAffineTransformIdentity，也就是说每一个字形都不做图形变换
    
    //转换坐标系，防止文本颠倒
    CGAffineTransform transform = CGAffineTransformMake(1, 0, 0, -1, 0, self.bounds.size.height);
    CGContextConcatCTM(ctx, transform);
    
    CGRect rect = CGContextGetClipBoundingBox(ctx);
    
    if([self.delegate respondsToSelector:@selector(textContainer:didNeedDrawContentInRect:context:)])
    {
        [self.delegate textContainer:self didNeedDrawContentInRect:rect context:ctx];
    }
  //  NSLog(@"draw time = %f", time);
}

#pragma mark- public method

/**刷新某一部分的文本
 *param rect要刷新的部分
 */
- (void)refreshVisibleRect
{
    if([self.delegate respondsToSelector:@selector(textContainerDidGetVisibleRect:)])
    {
        [self setNeedsDisplayInRect:[self.delegate textContainerDidGetVisibleRect:self]];
    }
    else
    {
        [self setNeedsDisplayInRect:self.bounds];
    }
    
    //[self setNeedsDisplayInRect:rect];
}

/**刷新全部
 */
- (void)refreshAll
{
    [self setNeedsDisplayInRect:self.bounds];
}

/**获取正确的坐标，coreText坐标和 UIKit不同
 */
- (CGRect)UIKitRectFromRect:(CGRect) rect
{
    return CGRectApplyAffineTransform(rect, CGAffineTransformMake(1, 0, 0, -1, 0, self.bounds.size.height));
}

#pragma mark- cut copy delete select

- (BOOL)canBecomeFirstResponder
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return NO;
    if([textView isFirstResponder])
        return NO;
    
    if(textView.text.length == 0)
        return NO;
    
    return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return NO;
    
    if(textView.selectedRange.length > 0)
    {
        if(action == @selector(cut:) ||
           action == @selector(copy:) ||
           action == @selector(delete:) ||
           action == @selector(selectAll:) ||
           (_enableEidtTextStyle && action == @selector(selectTextStyle:)))
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    
    //NSLog(@"%@", NSStringFromSelector(action));
    return NO;
}

- (void)selectAll:(id)sender
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return;
    [textView selectAll:sender];
}

- (void)cut:(id)sender
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return;
    [textView cut:sender];
}

- (void)delete:(id)sender
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return;
    [textView delete:sender];
}

- (void)copy:(id)sender
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return;
    [textView copy:sender];
}

/**选择样式
 */
- (void)selectTextStyle:(id) sender
{
    SeaTextView *textView = (SeaTextView*)self.superview;
    if(![textView isKindOfClass:[SeaTextView class]])
        return;
    [textView selectTextStyle:sender];
}

/**插入图片
 */
//- (void)insertImage:(id) sender
//{
//    SeaTextView *textView = (SeaTextView*)self.superview;
//    if(![textView isKindOfClass:[SeaTextView class]])
//        return;
//    [textView insertImage:sender];
//}

@end
