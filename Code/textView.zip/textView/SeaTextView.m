//
//  SeaTextView.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextView.h"
#import "SeaTextPosition.h"
#import "SeaTextRange.h"
#import "SeaTextStorage.h"
#import "SeaTextContainer.h"
#import "SeaTextCaretView.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "SeaTextSelectedDragView.h"
#import "SeaTextAttachment.h"
#import "SeaTextParagraphInfo.h"
#import "SeaTextViewTextInfo.h"

/**选择文本拖动方向
 */
typedef NS_ENUM(NSInteger, SeaTextViewDragDirection)
{
    SeaTextViewDragDirectionUp = 0, //向上
    SeaTextViewDragDirectionDown = 1 //向下
};

/**网页数据
 */
static NSString *const webArchive = @"Apple Web Archive pasteboard type";

@interface SeaTextView ()<SeaTextContainerDelegate,SeaTextStorageDelegate>
{
    //文本输入分词器
    UITextInputStringTokenizer *_tokenizer;
}

/**撤销管理器
 */
@property(nonatomic,retain) NSUndoManager *undoManager;

/**选择拖动
 */
@property(nonatomic,retain) SeaTextSelectedDragView *beginDrag;
@property(nonatomic,retain) SeaTextSelectedDragView *endDrag;

//拖动的位置
@property(nonatomic,assign) CGPoint beginDragPoint;
@property(nonatomic,assign) CGPoint endDragPoint;

//点击的位置
@property(nonatomic,assign) CGPoint point;

//是否在点击
@property(nonatomic,assign) BOOL isTapping;

//正在拖动选择
@property(nonatomic,assign) BOOL isSelecting;

//拖动方向
@property(nonatomic,assign) SeaTextViewDragDirection dragDirection;

//选择拖动动画
@property(nonatomic,assign) BOOL isDragAnimating;

@end

@implementation SeaTextView

@synthesize undoManager;

#pragma mark- init

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        [self initlization];
    }
    return self;
}

/**属性初始化
 */
- (void)initlization
{
    self.delaysContentTouches = NO;
    self.isTapping = NO;
    self.isSelecting = NO;
    self.enableEidtTextStyle = YES;
    
    //默认placeholder 样式
    self.placeholderFont = [UIFont systemFontOfSize:16.0];
    self.placeholderTextColor = [UIColor colorWithWhite:0.702f alpha:0.7];
    self.placeholderOffset = CGPointMake(0.0f, 0.0f);
    
    self.maxCount = NSNotFound;
    self.maxImageCount = NSNotFound;
    self.maxParagraphCount = NSNotFound;
    
    /**文本默认字数限制超出 样式
     */
    self.remindAttributes = [NSDictionary dictionaryWithObject:(id)[UIColor grayColor].CGColor forKey:(NSString*)(kCTForegroundColorAttributeName)];
    
    self.selectedRange = NSMakeRange(NSNotFound, 0);
    self.markedRange = NSMakeRange(NSNotFound, 0);
    self.editable = YES;
    self.clipsToBounds = YES;
    self.backgroundColor = [UIColor whiteColor];
    
    //文本默认间距
    _textInset = UIEdgeInsetsMake(8.0, 8.0, 8.0, 8.0);
    
    //文本显示容器
    _textContainer = [[SeaTextContainer alloc] initWithFrame:CGRectMake(_textInset.left, _textInset.top, self.bounds.size.width - _textInset.left - _textInset.right, self.bounds.size.height - _textInset.top - _textInset.bottom)];
    _textContainer.delegate = self;
    _textContainer.enableEidtTextStyle = self.enableEidtTextStyle;
    [self addSubview:_textContainer];
    
    //文本默认字体 颜色 高亮颜色
    self.font = [UIFont systemFontOfSize:16.0];
    self.textColor = [UIColor blackColor];
    self.selectedColor = [UIColor colorWithRed:0.800f green:0.867f blue:0.929f alpha:1.0f];
    
    //文本储存器
    _textStorage = [[SeaTextStorage alloc] init];
    _textStorage.textContainer = _textContainer;
    _textStorage.delegate = self;
    _textStorage.textView = self;
    self.delegate = self;
    
    //内容撤销和恢复
    self.undoManager = [[[NSUndoManager alloc] init] autorelease];
    [self.undoManager setLevelsOfUndo:3];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(undoManagerDidUndo:) name:NSUndoManagerDidUndoChangeNotification object:self.undoManager];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(undoManagerDidRedo:) name:NSUndoManagerDidRedoChangeNotification object:self.undoManager];
    
    _textContainer.undoManager = self.undoManager;
}

#pragma mark- SeaTextStorage 代理

- (NSDictionary*)textStorageGetDefaultAttributes:(SeaTextStorage *)textStorage
{
    return [self defaultAttributes];
}

- (void)textStorage:(SeaTextStorage *)textStorage willDeleteAttachments:(NSArray *)attachments
{
    // NSLog(@"delete attachemts %@", attachments);
    if([self.textDelegate respondsToSelector:@selector(customTextView:willDeleteAttachments:)])
    {
        [self.textDelegate customTextView:self willDeleteAttachments:attachments];
    }
}

- (void)textStorageContentDidChange:(SeaTextStorage *)textStorage
{
    if(self.attributedText.length == 0 && ![NSString isEmpty:self.placeHolder])
    {
        [self setupTextContainterSize];
        [self.textContainer refreshVisibleRect];
    }
    
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidChange:)])
    {
        [self.textDelegate customTextViewDidChange:self];
    }
}

- (void)textStorageContentWillChange:(SeaTextStorage *)textStorage
{
    if(!self.markedTextRange)
    {
        NSAttributedString *attributedText = [self.attributedText copy];
        NSRange range = self.selectedRange;
        
        [[self.undoManager prepareWithInvocationTarget:self] undoAttributedText:attributedText selectedRange:range];
        [attributedText release];
        
        if(![self.undoManager isUndoing])
        {
            
        }
    }
}

#pragma mark- property

//能否编辑
- (void)setEditable:(BOOL)editable
{
    if(_editable != editable)
    {
        _editable = editable;
        if(_editable)
        {
            if(!self.markedTextStyle)
            {
                self.markedTextStyle = [self defaultMarkedTextStyle];
            }
            
            if(!_tokenizer)
            {
                _tokenizer = [[UITextInputStringTokenizer alloc] initWithTextInput:self];
            }
            
            if(!self.tapGesture)
            {
                _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
                _tapGesture.delegate = self;
                [self addGestureRecognizer:_tapGesture];
            }
            
            if(!self.longPressGesture)
            {
                _longPressGesture = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
                _longPressGesture.delegate = self;
                [self addGestureRecognizer:_longPressGesture];
            }
            
            if(!self.textCaretView)
            {
                _textCaretView = [[SeaTextCaretView alloc] initWithFrame:CGRectZero];
                [self.textContainer addSubview:_textCaretView];
                [_textCaretView stopAnimated];
            }
        }
        
        self.tapGesture.enabled = _editable;
        self.longPressGesture.enabled = _editable;
        if(_editable && self.selectedRange.location != NSNotFound)
        {
            [self selectionDidChange];
        }
        else if(!_editable)
        {
            [self hideMenuController];
            [_textCaretView stopAnimated];
            self.selectedRange = NSMakeRange(NSNotFound, 0);
            [self.textContainer refreshVisibleRect];
        }
    }
}

- (void)setEnableEidtTextStyle:(BOOL)enableEidtTextStyle
{
    if(_enableEidtTextStyle != enableEidtTextStyle)
    {
        _enableEidtTextStyle = enableEidtTextStyle;
        _textContainer.enableEidtTextStyle = _enableEidtTextStyle;
    }
}

//文本边距
- (void)setTextInset:(UIEdgeInsets)textInset
{
    if(!UIEdgeInsetsEqualToEdgeInsets(_textInset, textInset))
    {
        _textInset = textInset;
        [self refresh];
    }
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    
    [self refresh];
    
    [self selectionDidChange];
}

- (void)setSelectedRange:(NSRange)selectedRange
{
    if(!NSRangeEqualToRange(_selectedRange, selectedRange))
    {
        _selectedRange = selectedRange;
        [self selectionDidChange];
    }
}

- (UIView*)inputAccessoryView
{
    if([self isFirstResponder])
    {
        return _inputAccessoryView;
    }
    else
    {
        return nil;
    }
}

- (void)setPlaceHolder:(NSString *)placeHolder
{
    if(_placeHolder != placeHolder)
    {
        [_placeHolder release];
        _placeHolder = [placeHolder copy];
        
        [self.textContainer refreshAll];
    }
}

#pragma mark- public method

/**添加附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (void)insertAttachments:(NSArray*) attachments atIndex:(NSInteger) index
{
    if(index > self.attributedText.length || attachments.count == 0)
    {
        return;
    }
    
    NSInteger length = [self.textStorage insertAttachments:attachments atIndex:index];
    if(length > 0)
    {
        [self setupTextContainterSize];
        [self.textContainer refreshVisibleRect];
        if([self.textDelegate respondsToSelector:@selector(customTextView:didInsertAttachemtsInWithTextLength:)])
        {
            [self.textDelegate customTextView:self didInsertAttachemtsInWithTextLength:length];
        }
    }
}

/**替换附件
 *@param attachment 旧的附件
 *@param otherAttachment 新的附件，空的时候为删除附件
 *@param index 附件所在段落
 */
- (void)replaceAttachment:(SeaTextAttachment*) attachment withAttachment:(SeaTextAttachment*) otherAttachment paragraphIndex:(NSInteger) index
{
    if(index >= self.textStorage.paragraphInfos.count)
    {
        return;
    }
    
    SeaTextParagraphInfo *info = [self.textStorage.paragraphInfos objectAtIndex:index];
    NSRange range = info.range;
    if(otherAttachment == nil)
    {
        [self.textStorage deleteCharactersInRange:info.range];
        range.length = 0;
    }
    else
    {
        if([self.textDelegate respondsToSelector:@selector(customTextView:WillReplaceAttachemt:withAttachemnt:)])
        {
            [self.textDelegate customTextView:self WillReplaceAttachemt:attachment withAttachemnt:otherAttachment];
        }
        [self.textStorage replaceAttachmentInRange:info.range withAttachment:otherAttachment];
        range.location = range.location + range.length;
        range.length = 0;
    }
    
    [self setupTextContainterSize];
    self.selectedRange = range;
    [self.textContainer refreshVisibleRect];
}

/**获取所有附件
 *@param attachments 数组元素是 SeaTextAttachment
 */
- (NSArray*)attachments
{
    return [self.textStorage attachmentsInRange:NSMakeRange(0, self.attributedText.length) count:NSNotFound];
}

/**设置文本样式
 */
- (void)addAttributes:(NSDictionary *)attrs range:(NSRange)range
{
    if([self.textStorage addAttributes:attrs range:range])
    {
        [self setupTextContainterSize];
        [self.textContainer refreshVisibleRect];
    }
}

/**获取文本内容最大宽度
 */
- (CGFloat)maxTextWidth
{
    return self.textContainer.bounds.size.width;
}

//最小文本容器
- (CGSize)minTextContainerSize
{
    return CGSizeMake(self.bounds.size.width - self.textInset.left - self.textInset.right, self.bounds.size.height - self.textInset.bottom - self.textInset.top);
}

/**创建附件
 *@param 附件图片 不能为空
 */
- (SeaTextAttachment*)attachmentWithImage:(UIImage*) image
{
    if(image == nil)
        return nil;
    
    SeaTextAttachment *attachment = [[SeaTextAttachment alloc] init];
    attachment.image = image;
    [attachment shrinkImageWithWidth:[self maxTextWidth]];
    
    return [attachment autorelease];
}

/**结束编辑
 */
- (void)endEdit
{
    if([self isFirstResponder])
    {
        [self resignFirstResponder];
    }
    //    else if([self.textContainer isFirstResponder])
    //    {
    //        [self.textContainer resignFirstResponder];
    //    }
}

/**设置默认的附加视图
 */
- (void)setupDefaultInputAccessoryView
{
    //文本输入框
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
    view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    
    CGFloat buttonWidth = 60.0;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitle:@"完成" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
    [view addSubview:button];
    self.inputAccessoryView = view;
    [view release];
}

/**获取分离的文本信息
 *@return 数组元素信息 SeaTextViewTextInfo对象
 */
- (NSArray*)getSeparatedTextInfo
{
    NSMutableArray *infos = [self textParagraphCountAndImageCount:YES];
    
    //判断文本有没有超出限制
    NSInteger index = 0;
    NSInteger contentLength = 0;
    while (index < infos.count)
    {
        SeaTextViewTextInfo *textInfo = [infos objectAtIndex:index];
        if([NSString isEmpty:textInfo.content] && textInfo.imageCount == 0)
        {
            [infos removeObjectAtIndex:index];
            continue;
        }
        
        //判断文本有没有超出限制
        BOOL beyond = NO;
        if(contentLength + textInfo.content.length > self.maxCount)
        {
            NSInteger length = self.maxCount - contentLength;
            if(length > 0 && length < textInfo.content.length)
            {
                textInfo.content = [textInfo.content substringToIndex:length - 1];
                NSRange textRange = textInfo.range;
                textRange.length = length;
                
            }
            beyond = YES;
        }
        else
        {
            contentLength += textInfo.content.length;
        }
        index ++;
        if(beyond)
        {
            break;
        }
    }
    
    //如果文本已越界，把后面的图片移到前面
    if(index > 1)
    {
        SeaTextViewTextInfo *textInfo = [infos objectAtIndex:index - 1];
        NSInteger imageCount = 0;
        for(NSInteger i = index;i < infos.count;i ++)
        {
            SeaTextViewTextInfo *tmpTextInfo = [infos objectAtIndex:i];
            imageCount += tmpTextInfo.imageCount;
        }
        textInfo.imageCount += (int)imageCount;
    }
    
    //删除越界的文本
    if(index < infos.count)
    {
        [infos removeObjectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(index, infos.count - index)]];
    }
    
    return infos;
}

/**获取分段数量 以连续的图片作为分隔符
 *@param flag 是否需要获取文本内容
 *@return 数组元素信息 SeaTextViewTextInfo对象
 */
- (NSMutableArray*)textParagraphCountAndImageCount:(BOOL) flag
{
    NSMutableArray *infos = [NSMutableArray array];
    
    NSArray *array = [self.textStorage attachmentsInRange:NSMakeRange(0, self.attributedText.length) count:NSNotFound];
    
    //没有图片
    if(array.count == 0)
    {
        SeaTextViewTextInfo *textInfo = [[SeaTextViewTextInfo alloc] init];
        textInfo.content = self.attributedText.string;
        textInfo.imageCount = 0;
        textInfo.range = NSMakeRange(0, self.attributedText.length);
        [infos addObject:textInfo];
        [textInfo release];
    }
    else
    {
        SeaTextAttachment *lastAttachment = nil;
        for(NSInteger i = 0;i < array.count;i++)
        {
            SeaTextAttachment *attachment = [array objectAtIndex:i];
            
            //第一张图片
            if(i == 0)
            {
                SeaTextViewTextInfo *textInfo = [[SeaTextViewTextInfo alloc] init];
                if(attachment.range.location == 0)
                {
                    if(flag)
                    {
                        textInfo.content = @"";
                    }
                    
                    textInfo.range = NSMakeRange(0, 0);
                }
                else
                {
                    NSRange range = NSMakeRange(0, attachment.range.location);
                    textInfo.range = range;
                    if(flag)
                    {
                        textInfo.content = [self.attributedText.string substringWithRange:range];
                    }
                }
                textInfo.imageCount ++;
                [infos addObject:textInfo];
                [textInfo release];
            }
            else
            {
                SeaTextViewTextInfo *textInfo = [infos lastObject];
                
                //判断是否是连续的图片
                if(lastAttachment.range.location + lastAttachment.range.length != attachment.range.location)
                {
                    //不是连续的图片，获取文本内容
                    textInfo = [[SeaTextViewTextInfo alloc] init];
                    [infos addObject:textInfo];
                    [textInfo release];
                    
                    NSInteger loc = lastAttachment.range.location + lastAttachment.range.length;
                    NSRange range = NSMakeRange(loc, attachment.range.location - loc);
                    textInfo.range = range;
                    if(flag)
                    {
                        textInfo.content = [self.attributedText.string substringWithRange:range];
                    }
                }
                textInfo.imageCount ++;
            }
            
            //最后一张图片，判断图片后面还有没有内容
            if(i == array.count - 1)
            {
                NSInteger loc = attachment.range.location + attachment.range.length;
                if(loc < self.attributedText.length)
                {
                    NSRange range = NSMakeRange(loc, self.attributedText.length - loc);
                    SeaTextViewTextInfo *textInfo = [[SeaTextViewTextInfo alloc] init];
                    textInfo.range = range;
                    if(flag)
                    {
                        textInfo.content = [self.attributedText.string substringWithRange:range];
                    }
                    [infos addObject:textInfo];
                    [textInfo release];
                }
            }
            
            lastAttachment = attachment;
        }
    }
    
    return infos;
}

#pragma mark- scroll

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self hideMenuController];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!decelerate && self.selectedRange.length > 0)
    {
        [self showMenuController];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if(self.selectedRange.length > 0)
    {
        [self showMenuController];
    }
}

#pragma mark- 设置文本

- (void)setText:(NSString *)text
{
    if(text)
    {
        self.attributedText = [[[NSAttributedString alloc] initWithString:text attributes:[self defaultAttributes]] autorelease];
    }
    else
    {
        self.attributedText = nil;
    }
}

- (NSString*)text
{
    return self.textStorage.attributedText.string;
}

- (void)setAttributedText:(NSAttributedString *)attributedText
{
    [self.inputDelegate textWillChange:self];
    [self.textStorage setAttributedString:attributedText];
    [self.inputDelegate textDidChange:self];
    
    [self setupTextContainterSize];
    [self.textContainer refreshAll];
}

- (NSAttributedString*)attributedText
{
    return self.textStorage.attributedText;
}

#pragma mark- dealloc

- (void)dealloc
{
    self.textDelegate = nil;
    self.inputDelegate = nil;
    
    [_remindAttributes release];
    
    [_tapGesture release];
    [_longPressGesture release];
    
    [_font release];
    [_supportedFontNames release];
    [_supportedFontSizes release];
    [_textColor release];
    [_supportedTextColors release];
    [_markedTextStyle release];
    
    [_inputView release];
    [_inputAccessoryView release];
    
    [_textContainer release];
    [_textStorage release];
    [_selectedColor release];
    [_textCaretView release];
    
    [_placeHolder release];
    [_placeholderFont release];
    [_placeholderTextColor release];
    
    [_tokenizer release];
    
    [_beginDrag release];
    [_endDrag release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSUndoManagerDidUndoChangeNotification object:self.undoManager];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:NSUndoManagerDidRedoChangeNotification object:self.undoManager];
    
    [self.undoManager removeAllActionsWithTarget:self];
    self.undoManager = nil;
    
    [super dealloc];
}

#pragma mark- SeaTextContainer 代理

- (CGRect)textContainerDidGetVisibleRect:(SeaTextContainer *)container
{
    return [self visibleRect];
}

- (void)textContainer:(SeaTextContainer *)container didNeedDrawContentInRect:(CGRect)rect context:(CGContextRef)context
{
    if(self.attributedText.length > 0)
    {
        //NSLog(@"length %d", self.attributedText.length);
        
        // NSLog(@"%@", NSStringFromCGRect(rect));
        
        //绘制选中和输入高亮部分
        CGContextSetFillColorWithColor(context, self.selectedColor.CGColor);
        [self drawHighlightBackgroundWithSelectedRange:self.selectedRange atContext:context];
        [self drawHighlightBackgroundWithSelectedRange:self.markedRange atContext:context];
        
        CGFloat start = rect.origin.y;
        CGFloat end = rect.size.height + rect.origin.y;
        //        NSLog(@"drawRect %@", NSStringFromCGRect(rect));
        //        NSLog(@"%@", NSStringFromCGRect(self.textContainer.bounds));
        
        NSArray *paragraphInfos = self.textStorage.paragraphInfos;
        
        if(self.maxParagraphCount != NSNotFound)
        {
            NSArray *textParagraphs = [self textParagraphCountAndImageCount:NO];
            
            if(textParagraphs.count > self.maxParagraphCount)
            {
                SeaTextViewTextInfo *info = [textParagraphs objectAtIndex:self.maxParagraphCount];
                CGContextSetFillColorWithColor(context, [UIColor colorWithRed:0.9 green:0 blue:0 alpha:0.5].CGColor);
                
                NSInteger loc = info.range.location;
                NSInteger len = self.attributedText.length - loc;
                [self drawHighlightBackgroundWithSelectedRange:NSMakeRange(loc, len) atContext:context];
            }
        }
        
        for(int m = 0;m < paragraphInfos.count;m ++)
        {
            SeaTextParagraphInfo *info = [[[paragraphInfos objectAtIndex:m] retain] autorelease];
            @synchronized(info)
            {
                if(info.ctFrame == NULL)
                    return;
                
                CGFloat originalY = info.rect.origin.y;
                
                //NSLog(@"rect %@", NSStringFromCGRect(info.rect));
                
                //只绘制可见区域
                if(originalY > end)
                    continue;
                else if (originalY + info.rect.size.height < start)
                    break;
                
                //文本框大小
                CTFrameRef frame = CFRetain(info.ctFrame);
                CFArrayRef lines = CFRetain(CTFrameGetLines(frame));
                
                CGPoint lineOrigins[CFArrayGetCount(lines)];
                CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), lineOrigins);
                
                
                for(NSInteger i = 0;i < CFArrayGetCount(lines);i ++)
                {
                    CTLineRef line = CFArrayGetValueAtIndex(lines, i);
                    
                    CGPoint lineOrigin = lineOrigins[i];
                    
                    // NSLog(@"%@", NSStringFromCGPoint(lineOrigin));
                    //lineOrigin.y +=  originalY;
                    lineOrigin.y = originalY + lineOrigin.y;
                    
                    // NSLog(@"%@", NSStringFromCGPoint(lineOrigin));
                    
                    CGFloat lineAscent;
                    CGFloat lineDescent;
                    CGFloat leading;
                    
                    //获取文字排版
                    CTLineGetTypographicBounds(line, &lineAscent, &lineDescent, &leading);
                    //CGFloat lineHeight = lineAscent + lineDescent + leading;
                    
                    //只绘制可见区域
                    if(lineOrigin.y > end)
                        continue;
                    else if(lineOrigin.y + lineAscent < start)
                        break;
                    //NSLog(@"lineOrigin%@", NSStringFromCGPoint(lineOrigin));
                    CGContextSetTextPosition(context, lineOrigin.x, lineOrigin.y);
                    CTLineDraw(line, context);
                    
                    //图片回调
                    CFArrayRef runs = CTLineGetGlyphRuns(line);
                    CFIndex count = CFArrayGetCount(runs);
                    if(count == 0)
                        continue;
                    
                    for(int j = 0;j < count;j ++)
                    {
                        CTRunRef run = CFArrayGetValueAtIndex(runs, j);
                        
                        NSDictionary *attributes = (NSDictionary*)CTRunGetAttributes(run);
                        
                        SeaTextAttachment *attachment = [attributes objectForKey:SeaAttachmentAttributeName];
                        
                        if(attachment.thumbnail)
                        {
                            //   NSLog(@"m = %d",m);
                            CGFloat runAscent;
                            CGFloat runDescent;
                            CGRect runRect;
                            runRect.size.width = CTRunGetTypographicBounds(run, CFRangeMake(0, 0), &runAscent, &runDescent, NULL);
                            
                            runRect = CGRectMake(lineOrigin.x + CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL), lineOrigin.y - runDescent, runRect.size.width, runAscent + runDescent);
                            
                            UIImage *image = attachment.thumbnail;
                            CGRect imageDrawRect;
                            imageDrawRect.origin.x = runRect.origin.x + lineOrigin.x;
                            imageDrawRect.origin.y = lineOrigin.y;
                            imageDrawRect.size = attachment.bounds.size;
                            
                            //NSLog(@"imageDrawRect%@", NSStringFromCGRect(imageDrawRect));
                            
                            CGContextDrawImage(context, imageDrawRect, image.CGImage);
                        }
                    }
                }
                CFRelease(frame);
                CFRelease(lines);
            }
        }
    }
    else if(![NSString isEmpty:self.placeHolder])
    {
        NSAttributedString *attributedString = [[[NSAttributedString alloc] initWithString:self.placeHolder attributes:[self baseAttributesWithFont:self.placeholderFont textColor:self.placeholderTextColor]] autorelease];
        
        CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef) attributedString);
        if(framesetter == NULL)
            return;
        
        CGRect bounds = self.textContainer.bounds;
        
        CGMutablePathRef path = CGPathCreateMutable();
        CGPathAddRect(path, NULL, bounds);
        
        CTFrameRef ctframe = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, NULL);
        
        CTFrameDraw(ctframe, context);
        
        CFRelease(ctframe);
        CFRelease(framesetter);
        CGPathRelease(path);
    }
}

#pragma mark- draw

/**绘制高亮背景
 *@param selectedRange 选中部分
 *@param context 画板
 */
- (void)drawHighlightBackgroundWithSelectedRange:(NSRange) selectedRange atContext:(CGContextRef) context
{
    if(selectedRange.location == NSNotFound || selectedRange.length == 0)
        return;
    
    // NSLog(@"draw hightlight");
    
    // NSLog(@"drawHighlightBackgroundWithSelectedRange");
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    NSArray *rects = [self rectsForRange:selectedRange requiredCount:NSNotFound];
    for(NSString *rectStr in rects)
    {
        CGPathAddRect(path, NULL, CGRectFromString(rectStr));
    }
    
    CGContextAddPath(context, path);
    CGContextFillPath(context);
    CGPathRelease(path);
}

#pragma mark- selection

/**文本选择改变
 */
- (void)selectionDidChange
{
    if(![self.textContainer isFirstResponder] && self.selectedRange.length == 0)
    {
        [self hideMenuController];
        if(self.selectedRange.location != NSNotFound)
        {
            [self setCaretPositionForIndex:self.selectedRange.location point:self.point];
            self.point = CGPointZero;
        }
        else
        {
            [self.textCaretView stopAnimated];
        }
        [self setDragHidden:YES];
    }
    else if(self.selectedRange.length > 0)
    {
        [self.textCaretView stopAnimated];
        [self createSelectedDragView];
        
        [self setDragHidden:NO];
        
        CGRect beginRect = [self caretRectForIndex:self.selectedRange.location point:self.beginDragPoint];
        
        CGRect endRect = [self caretRectForIndex:self.selectedRange.location + self.selectedRange.length point:self.endDragPoint];
        
        beginRect.size.width = self.beginDrag.bounds.size.width;
        beginRect.size.height += _textSelectedDragCircleRadius_ * 2;
        beginRect.origin.x -= _textSelectedDragCircleRadius_ + _textSelectedDragExpandWidth_ / 2.0;
        beginRect.origin.y -= _textSelectedDragCircleRadius_ * 2;
        if(beginRect.origin.y < - _textSelectedDragCircleRadius_ * 2)
        {
            beginRect.origin.y = - _textSelectedDragCircleRadius_ * 2;
        }
        
        self.beginDrag.frame = [self.textContainer convertRect:beginRect toView:self];
        endRect.origin.x -= _textSelectedDragCircleRadius_ + _textSelectedDragExpandWidth_ / 2.0;
        endRect.size.width = self.endDrag.bounds.size.width;
        endRect.size.height += _textSelectedDragCircleRadius_ * 2;
        self.endDrag.frame = [self.textContainer convertRect:endRect toView:self];
    }
    else
    {
        [self setDragHidden:YES];
    }
    
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidChangeSelection:)])
    {
        [self.textDelegate customTextViewDidChangeSelection:self];
    }
}

/**设置选择器状态
 */
- (void)setDragHidden:(BOOL) hidden
{
    self.beginDrag.hidden = hidden;
    self.endDrag.hidden = hidden;
}

/**设置光标位置
 *@param index 文本位置
 *@param point 点击的位置
 */
- (void)setCaretPositionForIndex:(NSInteger) index point:(CGPoint) point
{
    if(!self.isTapping)
    {
        [self setupTextContainterSize];
    }
    
    CGRect rect = [self caretRectForIndex:index point:point];
    
    if(self.textCaretView.superview == nil)
    {
        [self.textContainer addSubview:self.textCaretView];
    }
    
    self.textCaretView.frame = rect;
    [self.textCaretView startAnimated];
    
    // NSLog(@"%@",self.textCaretView)
    
    rect = [self.textContainer convertRect:rect toView:self];
    [self scrollRectToVisible:rect animated:YES];
}

#pragma mark- UIKeyInput

/**插入一段文本
 */
- (void)insertText:(NSString *)text
{
    // NSLog(@"insertText %@",text);
    [self hideMenuController];
    
    BOOL canReplace = YES;
    
    if([self.textDelegate respondsToSelector:@selector(customTextView:shouldChangeTextInRange:replacementText:)])
    {
        canReplace = [self.textDelegate customTextView:self shouldChangeTextInRange:self.selectedRange replacementText:text];
    }
    
    if(canReplace)
    {
        NSRange range = self.selectedRange;
        NSInteger length = text.length;
        [self.textStorage replaceCharactersInRange:self.selectedRange withString:text];
        [self.textContainer refreshVisibleRect];
        
        range.location = self.selectedRange.location + length;
        
        self.selectedRange = range;
    }
    
    // NSLog(@"%@,%d", NSStringFromRange(self.selectedRange), self.attributedText.length);
}

/**键盘回删
 */
- (void)deleteBackward
{
    // NSLog(@"deleteBackward");
    
    [self hideMenuController];
    
    if(self.selectedRange.length == 0)
        return;
    
    if(self.attributedText.length > 0)
    {
        NSRange range = self.selectedRange;
        NSRange markedRange = self.markedRange;
        
        if(markedRange.location != NSNotFound)
        {
            markedRange.location = NSNotFound;
            markedRange.length = 0;
            self.markedRange = markedRange;
        }
        
        BOOL can = YES;
        if([self.textDelegate respondsToSelector:@selector(customTextView:shouldChangeTextInRange:replacementText:)])
        {
            can = [self.textDelegate customTextView:self shouldChangeTextInRange:range replacementText:@""];
        }
        
        //  NSLog(@"delete %@", [self.attributedText.string substringWithRange:range]);
        
        //判断是否需要删除图片
        if ([self.attributedText.string characterAtIndex:range.location] == '\n' && range.length == 1)
        {
            //NSLog(@"删除换行符");
            //删除时，删除整张图片
            NSRange checkImageRang = NSMakeRange(MAX(0, (NSInteger)range.location - 1), SeaAttachmentStringLength) ;
            
            if(checkImageRang.location != NSNotFound && checkImageRang.location + checkImageRang.length <= self.attributedText.length)
            {
                if ([[self.attributedText.string substringWithRange:checkImageRang] isEqualToString:[NSString stringWithFormat:@"%@\n",[SeaTextStorage attachmentMarkedString]]])
                {
                    //NSLog(@"前面图片");
                    range = checkImageRang;
                }
            }
            
            checkImageRang = NSMakeRange(range.location, SeaAttachmentStringLength);
            if(checkImageRang.location != NSNotFound && checkImageRang.location + checkImageRang.length <= self.attributedText.length)
            {
                if ([[self.attributedText.string substringWithRange:checkImageRang] isEqualToString:[NSString stringWithFormat:@"\n%@",[SeaTextStorage attachmentMarkedString]]])
                {
                    //NSLog(@"后面图片");
                    range.location = MAX(0, (NSInteger)range.location - 1);
                }
            }
        }
        
        if(can)
        {
            BOOL refreshAll = NO;
            
            if(range.length > 20)
            {
                CGFloat deletedTextHeight = self.endDrag.bottom - self.beginDrag.top;
                if(deletedTextHeight > [self visibleRect].size.height)
                {
                    refreshAll = YES;
                }
            }
            
            [self.textStorage deleteCharactersInRange:range];
            self.selectedRange = NSMakeRange(range.location, 0);
            
            if(!refreshAll)
            {
                [self.textContainer refreshVisibleRect];
            }
            else
            {
                [self.textContainer refreshAll];
            }
        }
    }
}

/**是否还有文本
 */
- (BOOL)hasText
{
    return self.attributedText.length > 0;
}

#pragma mark- UITextInput

#pragma mark- 文本替换和获取

/**获取一个确定的范围的文本
 *@param range 文本的范围
 *@return 如果范围不越界，返回该范围的文本，否则返回nil
 */
- (NSString*)textInRange:(UITextRange *)range
{
    SeaTextRange *textRange = (SeaTextRange*)range;
    if(textRange.range.location != NSNotFound && textRange.range.length + textRange.range.location <= self.attributedText.length)
    {
        return [self.attributedText.string substringWithRange:textRange.range];
    }
    else
    {
        return nil;
    }
}

/**替换一个确定范围的文本
 *@param range 要替换的范围
 *@param text 新的文本
 */
- (void)replaceRange:(UITextRange *)range withText:(NSString *)text
{
    NSLog(@"replaceRange %@",text);
    SeaTextRange *textRange = (SeaTextRange*)range;
    
    BOOL canReplace = YES;
    if([self.textDelegate respondsToSelector:@selector(customTextView:shouldChangeTextInRange:replacementText:)])
    {
        canReplace = [self.textDelegate customTextView:self shouldChangeTextInRange:textRange.range replacementText:text];
    }
    
    if(canReplace)
    {
        self.selectedRange = NSMakeRange(textRange.range.location - self.selectedRange.length + text.length, 0);
        [self.textStorage replaceCharactersInRange:textRange.range withString:text];
        if([self.textContainer isFirstResponder])
        {
            [self setupTextContainterSize];
        }
        [self.textContainer refreshVisibleRect];
    }
}

/**是否可以替换某个范围的文本
 *@param range 将要替换的范围
 *@param text 新的文本
 *@return 是否可以替换，default is 'YES'
 */
- (BOOL)shouldChangeTextInRange:(UITextRange *)range replacementText:(NSString *)text
{
    if([self.textDelegate respondsToSelector:@selector(customTextView:shouldChangeTextInRange:replacementText:)])
    {
        SeaTextRange *textRange = (SeaTextRange*)range;
        return [self.textDelegate customTextView:self shouldChangeTextInRange:textRange.range replacementText:text];
    }
    
    return YES;
}

#pragma mark- 文本输入高亮和文本选择

/**文本选择的范围
 */
- (UITextRange*)selectedTextRange
{
    return [SeaTextRange textRangeWithRange:self.selectedRange];
}

/**设置文本选择的范围
 */
- (void)setSelectedTextRange:(UITextRange *)selectedTextRange
{
    SeaTextRange *textRange = (SeaTextRange*)selectedTextRange;
    self.selectedRange = textRange.range;
}

/**文本输入法输入高亮范围
 */
- (UITextRange*)markedTextRange
{
    if(self.markedRange.location != NSNotFound && self.markedRange.length != 0)
    {
        return [SeaTextRange textRangeWithRange:self.markedRange];
    }
    return nil;
}


/**默认文本输入高亮样式
 */
- (NSDictionary*)defaultMarkedTextStyle
{
    //ios 8.0之后使用这个
    if([[UIDevice currentDevice].systemVersion floatValue] >= 8.0)
    {
#ifdef __IPHONE_6_0
        return [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], NSForegroundColorAttributeName, [UIFont systemFontOfSize:15.0], NSFontAttributeName, [UIColor colorWithRed:0.800f green:0.867f blue:0.929f alpha:1.0f], NSBackgroundColorAttributeName, nil];
#endif
    }
    else
    {
        return [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor], UITextInputTextColorKey, [UIFont systemFontOfSize:15.0], UITextInputTextFontKey, [UIColor colorWithRed:0.800f green:0.867f blue:0.929f alpha:1.0f], UITextInputTextBackgroundColorKey, nil];
    }
}

/**设置输入法输入的高亮文本
 *@param markedText 高亮文本
 *@param selectedRange 在输入高亮部分文本的位置
 */
- (void)setMarkedText:(NSString *)markedText selectedRange:(NSRange)selectedRange
{
    // NSLog(@"setMarkedText");
    //关闭菜单
    [self hideMenuController];
    
    BOOL canReplace = YES;
    if([self.textDelegate respondsToSelector:@selector(customTextView:shouldChangeTextInRange:replacementText:)])
    {
        NSRange range;
        if(self.markedRange.location != NSNotFound)
        {
            range = self.markedRange;
        }
        else if(self.selectedRange.length > 0)
        {
            range = self.selectedRange;
        }
        else
        {
            range = NSMakeRange(self.selectedRange.location, 0);
        }
        canReplace = [self.textDelegate customTextView:self shouldChangeTextInRange:range replacementText:markedText];
    }
    
    if(!canReplace)
        return;
    
    if(markedText != nil && markedText.length > 0)
    {
        // NSLog(@"%@,%@", NSStringFromRange(self.markedRange), NSStringFromRange(self.selectedRange));
        NSRange markedRange = self.markedRange;
        //输入文本
        if(self.markedRange.location != NSNotFound)
        {
            //继续输入
            [self.textStorage replaceCharactersInRange:markedRange withString:markedText];
            markedRange.length = markedText.length;
        }
        else if(self.selectedRange.length > 0)
        {
            //选择文本输入
            [self.textStorage replaceCharactersInRange:self.selectedRange withString:markedText];
            markedRange.location = self.selectedRange.location;
            markedRange.length = markedText.length;
        }
        else
        {
            //刚开始输入
            markedRange.location = self.selectedRange.location;
            markedRange.length = markedText.length;
            
            [self.textStorage replaceCharactersInRange:self.selectedRange withString:markedText];
        }
        
        self.markedRange = markedRange;
        self.selectedRange = NSMakeRange(selectedRange.location + self.markedRange.location, selectedRange.length);
        
        // NSLog(@"%@,%@", NSStringFromRange(self.markedRange), NSStringFromRange(self.selectedRange));
    }
    else
    {
        //判断是否是unmarkText后
        if(self.markedRange.location != NSNotFound)
        {
            //删除文本
            if(!markedText)
            {
                markedText = @"";
            }
            
            NSRange markedRange = self.markedRange;
            [self.textStorage replaceCharactersInRange:markedRange withString:markedText];
            markedRange.length = markedText.length;
            self.markedRange = markedRange;
            
            //NSLog(@"%@", NSStringFromRange(self.markedRange));
            
            self.selectedRange = NSMakeRange(self.markedRange.location, selectedRange.length);
        }
    }
    
    [self.textContainer refreshVisibleRect];
}

/**取消输入高亮
 */
- (void)unmarkText
{
    if(self.markedRange.location == NSNotFound)
        return;
    
    NSRange range = self.markedRange;
    range.location = NSNotFound;
    range.length = 0;
    
    NSLog(@"unmark");
    self.markedRange = range;
}

#pragma mark- 计算文本的范围和位置

/**返回两个位置间的范围
 */
- (UITextRange*)textRangeFromPosition:(UITextPosition *)fromPosition toPosition:(UITextPosition *)toPosition
{
    SeaTextPosition *fromTextPosition = (SeaTextPosition*)fromPosition;
    SeaTextPosition *toTextPosition = (SeaTextPosition*)toPosition;
    
    NSRange range = NSMakeRange(MIN(fromTextPosition.index, toTextPosition.index), ABS(toTextPosition.index - fromTextPosition.index));
    
    return [SeaTextRange textRangeWithRange:range];
}

/**通过一个确定的位置和抵消的长度返回一个新的位置，
 *@param position 一个确定的位置
 *@param offset 抵消的长度 正数或负数
 *@return 返回一个新的位置，或者nil,如果新的下标越界了
 */
- (UITextPosition*)positionFromPosition:(UITextPosition *)position offset:(NSInteger)offset
{
    SeaTextPosition *textPosition = (SeaTextPosition*)position;
    NSInteger index = textPosition.index + offset;
    
    if(index < 0 || index > self.attributedText.length)
        return nil;
    return [SeaTextPosition textPositionWithIndex:index];
}

/**通过一个确定的位置、抵消的长度和布局方向返回一个新的位置，
 *@param position 一个确定的位置
 *@param direction 布局方向
 *@param offset 抵消的长度 正数或负数
 *@return 返回一个新的位置，或者nil,如果新的下标越界了
 */
- (UITextPosition*)positionFromPosition:(UITextPosition *)position inDirection:(UITextLayoutDirection)direction offset:(NSInteger)offset
{
    SeaTextPosition *textPosition = (SeaTextPosition*)position;
    NSInteger index = 0;
    switch (direction)
    {
        case UITextLayoutDirectionLeft :
        {
            index = textPosition.index - offset;
        }
            break;
        case UITextLayoutDirectionRight :
        {
            index = textPosition.index + offset;
        }
            break;
        default:
            break;
    }
    
    if(index < 0 || index > self.attributedText.length)
        return nil;
    
    return [SeaTextPosition textPositionWithIndex:index];
}

/**整个文本的起点
 */
- (UITextPosition*)beginningOfDocument
{
    return [SeaTextPosition textPositionWithIndex:0];
}

/**整个文本的结尾
 */
- (UITextPosition*)endOfDocument
{
    return [SeaTextPosition textPositionWithIndex:self.attributedText.length];
}

#pragma mark- 比较文本的位置

/**比较两个位置的大小
 */
- (NSComparisonResult)comparePosition:(UITextPosition *)position toPosition:(UITextPosition *)other
{
    SeaTextPosition *textPosition = (SeaTextPosition*)position;
    SeaTextPosition *textOther = (SeaTextPosition*)other;
    
    if(textPosition.index > textOther.index)
    {
        return NSOrderedDescending;
    }
    else if(textPosition.index < textOther.index)
    {
        return NSOrderedAscending;
    }
    else
    {
        return NSOrderedSame;
    }
}

/**获取两个位置的差距
 */
- (NSInteger)offsetFromPosition:(UITextPosition *)from toPosition:(UITextPosition *)toPosition
{
    SeaTextPosition *fromTextPosition = (SeaTextPosition*)from;
    SeaTextPosition *toTextPosition = (SeaTextPosition*)toPosition;
    
    return toTextPosition.index - fromTextPosition.index;
}

#pragma mark- 确定布局和写作方向

/**通过一个确定的文本和布局方向获取文本位置
 *@param range 文本范围
 *@param direction 布局方向
 *@return 在可见文本中的位置
 */
- (UITextPosition*)positionWithinRange:(UITextRange *)range farthestInDirection:(UITextLayoutDirection)direction
{
    SeaTextRange *textRange = (SeaTextRange*)range;
    NSInteger index = 0;
    switch (direction)
    {
        case UITextLayoutDirectionDown :
        case UITextLayoutDirectionUp :
        {
            index = textRange.range.location;
        }
            break;
        case UITextLayoutDirectionRight :
        case UITextLayoutDirectionLeft :
        {
            index = textRange.range.location + textRange.range.length;
        }
            break;
        default:
            break;
    }
    
    return [SeaTextPosition textPositionWithIndex:index];
}

/**通过文本位置和布局方向返回文本范围
 *@param position 文本位置
 *@param direction 布局方向
 *@return 文本范围
 */
- (UITextRange*)characterRangeByExtendingPosition:(UITextPosition *)position inDirection:(UITextLayoutDirection)direction
{
    SeaTextPosition *textPosition = (SeaTextPosition*)position;
    NSRange range = NSMakeRange(textPosition.index, 1);
    
    switch (direction)
    {
        case UITextLayoutDirectionUp :
        case UITextLayoutDirectionDown :
        {
            range = NSMakeRange(textPosition.index - 1, 1);
        }
            break;
        default:
            break;
    }
    
    return [SeaTextRange textRangeWithRange:range];
}

/**返回一个基本的写作方向从文本位置和存储方向
 *@param position 文本位置
 *@param direction 存储方向
 *@return 写作方向，如从左到右，从右到左
 */
- (UITextWritingDirection)baseWritingDirectionForPosition:(UITextPosition *)position inDirection:(UITextStorageDirection)direction
{
    return UITextWritingDirectionLeftToRight;
}

/**通过确定的文本范围设置基本的写作方向
 *@param direction 要设置的写作方向
 *@param range 文本范围
 */
- (void)setBaseWritingDirection:(UITextWritingDirection)writingDirection forRange:(UITextRange *)range
{
    
}

#pragma mark- Geometry and Hit-Testing Methods

/**通过文本范围获取第一个矩形框，第一行的
 *@param range 文本范围
 *@return 矩形框
 */
- (CGRect)firstRectForRange:(UITextRange *)range
{
    //  NSLog(@"--");
    SeaTextRange *textRange = (SeaTextRange*)range;
    CGRect rect = [self firstRectForTextRange:textRange.range];
    return [self.textContainer convertRect:rect toView:self];
}

/**获取插入的字符的rect
 *@param position 插入的位置
 *@return 矩形框
 */
- (CGRect)caretRectForPosition:(UITextPosition *)position
{
    SeaTextPosition *textPosition = (SeaTextPosition*)position;
    return [self caretRectForIndex:textPosition.index];
}

/**通过某一点获取最近的位置
 *@param point 点
 *@return 文本位置
 */
- (UITextPosition*)closestPositionToPoint:(CGPoint)point
{
    return [SeaTextPosition textPositionWithIndex:[self closestIndexForPoint:point]];
}

/**获取选中文本的rect ios6.0以后
 *@param range 选中文本的范围
 *@return 矩形框，数组元素是UITextSelectionRect 对象
 */
- (NSArray*)selectionRectsForRange:(UITextRange *)range
{
    return [NSArray array];
}

/**在给定文本范围内获取最接近某一点的位置
 *@param point 某一点
 *@param range 文本范围
 *@return 最接近的文本位置
 */
- (UITextPosition*)closestPositionToPoint:(CGPoint)point withinRange:(UITextRange *)range
{
    return [SeaTextPosition textPositionWithIndex:[self closestIndexForPoint:point]];
}

/**获取某一点的文本范围
 */
- (UITextRange*)characterRangeAtPoint:(CGPoint)point
{
    return [SeaTextRange textRangeWithRange:[self textRangeAtPoint:point]];
}

#pragma mark- 文本输入代理和分词器

//文本输入分词器
- (id<UITextInputTokenizer>)tokenizer
{
    return _tokenizer;
}

#pragma mark- private method



#pragma mark- 获取文本位置和rect

/**获取某个文本范围的矩形框
 *@param range 文本范围
 *@return 矩形框
 */
- (CGRect)firstRectForTextRange:(NSRange) range
{
    CGRect rect = CGRectZero;
    if(range.location == NSNotFound || range.length == 0)
        return rect;
    
    if(range.location + range.length > self.attributedText.length)
        return rect;
    
    NSArray *rects = [self rectsForRange:range requiredCount:1];
    rect = CGRectFromString([rects firstObject]);
    
    return rect;
}

/**获取某个文本范围的矩形框
 *@param range 文本范围
 *@param requiredCount 要获取的数量
 *@return 矩形框
 */
- (NSArray*)rectsForRange:(NSRange) range requiredCount:(NSInteger) requiredCount;
{
    CGRect rect = CGRectZero;
    
    NSArray *paragraphInfos = _textStorage.paragraphInfos;
    
    if(paragraphInfos.count == 0)
        return [NSArray arrayWithObject:NSStringFromCGRect(rect)];
    
    NSMutableArray *rects = [NSMutableArray array];
    for(NSInteger j = 0;j < paragraphInfos.count;j ++)
    {
        SeaTextParagraphInfo *info = [[[paragraphInfos objectAtIndex:j] retain] autorelease];;
        
        @synchronized(info){
            
            if(!NSRangeContainRange(info.range, range))
                continue;
            else if(info.range.location > range.location + range.length)
                break;
            
            // NSLog(@"rectsForRange%@", NSStringFromCGRect(info.rect));
            
            CTFrameRef frame = CFRetain(info.ctFrame);
            CFArrayRef lines = CFRetain(CTFrameGetLines(frame));
            
            NSInteger count = CFArrayGetCount(lines);
            CGPoint lineOrigins[count];
            CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), lineOrigins);
            
            for(NSInteger i = 0;i < count;i ++)
            {
                CTLineRef line = CFArrayGetValueAtIndex(lines, i);
                CFRange lineRange = CTLineGetStringRange(line);
                lineRange.location += info.range.location;
                
                NSRange innerRange = [self innerRangeBetweenOne:range andSecond:NSMakeRange(lineRange.location == kCFNotFound ? NSNotFound : lineRange.location, lineRange.length)];
                
                // NSLog(@"%@", NSStringFromRange(innerRange));
                
                if(innerRange.location != NSNotFound && innerRange.length > 0)
                {
                    CGFloat lineAscent;
                    CGFloat lineDescent;
                    CGFloat lineLeading;
                    
                    //获取文字排版
                    CTLineGetTypographicBounds(line, &lineAscent, &lineDescent, &lineLeading);
                    CGFloat startX = CTLineGetOffsetForStringIndex(line, innerRange.location - info.range.location, NULL);
                    CGFloat endX = CTLineGetOffsetForStringIndex(line, innerRange.location - info.range.location + innerRange.length, NULL);
                    
                    if(i != count - 1 && innerRange.location + innerRange.length == lineRange.length + lineRange.location)
                    {
                        endX = CGRectGetMaxX(_textContainer.frame);
                    }
                    
                    ///  NSLog(@"%f,%f",startX,endX);
                    
                    CGPoint lineOrigin = lineOrigins[i];
                    lineOrigin.y += info.rect.origin.y;
                    
                    rect = CGRectMake(lineOrigin.x + startX, lineOrigin.y - lineDescent, endX - startX, lineAscent + lineDescent + lineLeading);
                    
                    //  NSLog(@"%@", NSStringFromCGRect(rect));
                    
                    [rects addObject:NSStringFromCGRect(rect)];
                    
                    if(i >= requiredCount - 1)
                        break;
                }
                else if(lineRange.location > range.location + range.length)
                    break;
            }
            CFRelease(frame);
            CFRelease(lines);
        }
    }
    
    if(rects.count == 0)
    {
        [rects addObject:NSStringFromCGRect(rect)];
    }
    return rects;
}

/**获取文本位置的rect,或光标位置
 */
- (CGRect)caretRectForIndex:(NSInteger) index
{
    return [self caretRectForIndex:index point:CGPointZero];
}

/**获取等精准的光标位置
 */
- (CGRect)caretRectForIndex:(NSInteger) index point:(CGPoint) point
{
    //文本为空
    if(self.attributedText.length == 0 || index == 0)
    {
        CGRect rect = CGRectZero;
        rect.origin.x = CGRectGetMinX(_textContainer.bounds);
        rect.origin.y = CGRectGetMaxY(_textContainer.bounds) - _font.leading;
        
        rect.size.width = _defaultTextCaretWidth_;
        rect.size.height = _font.ascender + fabs(_font.descender * 2);
        
        return [_textContainer UIKitRectFromRect:rect];
    }
    else
    {
        NSArray *paragraphInfos = _textStorage.paragraphInfos;
        
        if(paragraphInfos.count == 0)
            return [self caretRectForIndex:0 point:CGPointZero];
        
        //转成ct坐标
        if(!CGPointEqualToPoint(point, CGPointZero))
        {
            point = CGPointMake(point.x, self.textContainer.bounds.size.height - point.y);
        }
        
        
        for(NSInteger j = 0;j < paragraphInfos.count;j ++)
        {
            SeaTextParagraphInfo *info = [[[paragraphInfos objectAtIndex:j] retain] autorelease];
            
            @synchronized(info){
                
                if(index > info.range.location + info.range.length)
                    continue;
                else if(index < info.range.location)
                    break;
                
                CTFrameRef frame = CFRetain(info.ctFrame);
                CFArrayRef lines = CFRetain(CTFrameGetLines(frame));
                NSInteger count = CFArrayGetCount(lines);
                
                if(count == 0)
                {
                    CFRelease(frame);
                    CFRelease(lines);
                    return [self caretRectForIndex:0 point:CGPointZero];
                }
                
                CGPoint lineOrigins[count];
                CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), lineOrigins);
                
                // NSLog(@"%@", NSStringFromCGPoint(point));
                
                for(NSInteger i = 0;i < count;i ++)
                {
                    CTLineRef line = CFArrayGetValueAtIndex(lines, i);
                    CFRange lineRange = CTLineGetStringRange(line);
                    lineRange.location += info.range.location;
                    
                    NSInteger poor = index - lineRange.location;
                    
                    CGPoint lineOrigin = lineOrigins[i];
                    lineOrigin.y += info.rect.origin.y;
                    
                    //判断是在每行前面还是后面
                    BOOL can = NO;
                    
                    if(!CGPointEqualToPoint(point, CGPointZero))
                    {
                        if(point.y < lineOrigin.y)
                        {
                            can = poor < lineRange.length;
                        }
                        else
                        {
                            can = poor <= lineRange.length;
                        }
                    }
                    else
                    {
                        can = poor <= lineRange.length;
                        if(i == count - 1)
                        {
                            NSRange range = NSMakeRange(lineRange.location + lineRange.length - 1, 1);
                            if(range.location != NSNotFound && range.location + range.length < self.attributedText.length)
                            {
                                NSString *str = [self.attributedText.string substringWithRange:range];
                                if([str isEqualToString:@"\n"] || [str isEqualToString:@"\r"])
                                {
                                    can = poor < lineRange.length;
                                }
                            }
                        }
                    }
                    
                    if(poor >= 0 && can)
                    {
                        CGFloat lineAscent;
                        CGFloat lineDescent;
                        
                        //获取文字排版
                        CTLineGetTypographicBounds(line, &lineAscent, &lineDescent, NULL);
                        CGFloat startX = CTLineGetOffsetForStringIndex(line, index - info.range.location, NULL);
                        
                        CGRect rect = CGRectMake(lineOrigin.x + startX, lineOrigin.y - lineDescent, _defaultTextCaretWidth_, lineAscent + lineDescent * 2);
                        CFRelease(frame);
                        CFRelease(lines);
                        
                        return [_textContainer UIKitRectFromRect:rect];
                    }
                }
                CFRelease(frame);
                CFRelease(lines);
            }
        }
        
        NSLog(@"unvalid index %d,%d", (int)index, (int)self.attributedText.length);
        return [self caretRectForIndex:0 point:CGPointZero];
    }
}

/**获取某一点最近的index
 */
- (NSInteger)closestIndexForPoint:(CGPoint) point
{
    //NSLog(@"point %@", NSStringFromCGPoint(point));
    
    NSInteger index = self.attributedText.length;
    if(self.isSelecting)
    {
        switch (self.dragDirection)
        {
            case SeaTextViewDragDirectionUp :
            {
                index = 0;
            }
                break;
            default:
                break;
        }
    }
    
    
    //  NSLog(@"%d",index);
    if(index < 0)
    {
        index = 0;
    }
    //    // Convert tap coordinates (start at top left) to CT coordinates (start at bottom left) 转换UIKit坐标成coreText坐标
    //
    //NSLog(@"%@", NSStringFromCGPoint(point));
    
    point = CGPointMake(point.x, self.textContainer.bounds.size.height - point.y);
    
    NSArray *paragraphInfos = _textStorage.paragraphInfos;
    
    if(paragraphInfos.count == 0)
        return index;
    
    for(NSInteger j = 0;j < paragraphInfos.count;j ++)
    {
        SeaTextParagraphInfo *info = [[[paragraphInfos objectAtIndex:j] retain] autorelease];
        
        @synchronized(info){
            
            // NSLog(@"%@,%@", NSStringFromCGRect(info.rect), NSStringFromCGPoint(point));
            
            if(self.isSelecting)
            {
                switch (self.dragDirection)
                {
                    case SeaTextViewDragDirectionUp :
                    {
                        index = info.range.location;
                    }
                        break;
                    case SeaTextViewDragDirectionDown :
                    {
                        index = info.range.location + info.range.length - 1;
                    }
                        break;
                    default:
                        break;
                }
            }
            else
            {
                index = info.range.location + info.range.length - 1;
            }
            if(info.rect.origin.y > point.y)
                continue;
            else if(info.rect.origin.y + info.rect.size.height < point.y)
                break;
            
            CTFrameRef frame = CFRetain(info.ctFrame);
            CFArrayRef lines = CFRetain(CTFrameGetLines(frame));
            NSInteger count = CFArrayGetCount(lines);
            
            if(count == 0)
            {
                CFRelease(frame);
                CFRelease(lines);
                return index;
            }
            
            CGPoint lineOrigins[count];
            CTFrameGetLineOrigins(frame, CFRangeMake(0, 0), lineOrigins);
            
            for(NSInteger i = 0;i < count;i ++)
            {
                CGPoint lineOrigin = lineOrigins[i];
                
                lineOrigin.y += info.rect.origin.y;
                
                if (lineOrigin.y <= point.y)
                {
                    CTLineRef line = CFArrayGetValueAtIndex(lines, i);
                    
                    // Convert CT coordinates to line-relative coordinates
                    CGPoint relativePoint = CGPointMake(point.x - lineOrigin.x, point.y - lineOrigin.y);
                    CFIndex idx = CTLineGetStringIndexForPosition(line, relativePoint) + info.range.location;
                    
                    //NSLog(@"%ld",idx);
                    
                    if (idx == kCFNotFound)
                    {
                        idx = index;
                    }
                    CFRelease(frame);
                    CFRelease(lines);
                    
                    //是否点中图片
                    NSString *str = [self.attributedText.string substringWithRange:info.range];
                    NSRange imageRange = [str rangeOfString:[SeaTextStorage attachmentMarkedString]];
                    if(imageRange.location != NSNotFound && imageRange.length > 0)
                    {
                        if(self.isSelecting)
                        {
                            switch (self.dragDirection)
                            {
                                case SeaTextViewDragDirectionUp :
                                {
                                    idx = MAX(0, (NSInteger)info.range.location - 1);
                                }
                                    break;
                                case SeaTextViewDragDirectionDown :
                                {
                                    idx = info.range.location + info.range.length;
                                }
                                    break;
                                default:
                                    break;
                            }
                        }
                        else
                        {
                            idx = info.range.location + info.range.length;
                        }
                    }
                    
                    //                    NSLog(@"idex = %d location = %d", (int)idx, (int)info.range.location);
                    //
                    //                    NSLog(@"%@ len = %d", str, (int)str.length);
                    
                    if(str.length == 1)
                    {
                        if([str isEqualToString:@" "] || [str isEqualToString:@"\n"])
                        {
                            idx = info.range.location;
                        }
                    }
                    else
                    {
                        //判断点击的位置是否在某一样的换行符后面
                        if(idx < self.text.length)
                        {
                            char c = [self.text characterAtIndex:index];
                            
                            if(c == '\n' || c == '\r')
                            {
                                idx --;
                            }
                            idx = MAX(idx, 0);
                        }
                    }
                    
                    return idx;
                }
            }
            CFRelease(frame);
            CFRelease(lines);
        }
    }
    
    return index;
}

/**获取某一点的文本范围
 */
- (NSRange)textRangeAtPoint:(CGPoint) point
{
    return NSMakeRange(0, 0);
}

/**获取内部的range
 */
- (NSRange)innerRangeBetweenOne:(NSRange) one andSecond:(NSRange) second
{
    NSRange range = NSMakeRange(NSNotFound, 0);
    
    //交换
    if(one.location > second.location)
    {
        NSRange tmp = one;
        one = second;
        second = tmp;
    }
    
    if(second.location < one.location + one.length)
    {
        range.location = second.location;
        
        NSInteger end = MIN(one.location + one.length, second.location + second.length);
        range.length = end - range.location;
    }
    
    return range;
}

/**获取接近给定数字的字体大小
 */
- (float)fontSizeCloseToGivenValue:(float) value
{
    float result = value;
    float difference = _maxFloat_;
    
    for(NSNumber *number in self.supportedFontSizes)
    {
        float differ = fabsf([number floatValue] - value);
        if(differ < difference)
        {
            difference = differ;
            result = [number floatValue];
        }
    }
    
    return result;
}

#pragma mark- menuController

/**显示菜单
 */
- (void)showMenuController
{
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    
    UIMenuItem *insertImageItem = [[UIMenuItem alloc] initWithTitle:@"插入图片" action:@selector(insertImage:)];
    UIMenuItem *selectTextStyleItem = [[UIMenuItem alloc] initWithTitle:@"样式" action:@selector(selectTextStyle:)];
    
    menuController.menuItems = [NSArray arrayWithObjects:insertImageItem, selectTextStyleItem, nil];
    
    [insertImageItem release];
    [selectTextStyleItem release];
    
    if([menuController isMenuVisible])
    {
        [menuController setMenuVisible:NO animated:NO];
    }
    
    if(self.selectedRange.length == 0)
    {
        [menuController setTargetRect:[self.textContainer convertRect:self.textCaretView.frame toView:self] inView:self];
        [menuController setMenuVisible:YES animated:YES];
    }
    else
    {
        CGRect rect = CGRectMake(self.beginDrag.frame.origin.x, self.beginDrag.frame.origin.y, fabs(self.beginDrag.frame.origin.x - self.endDrag.frame.origin.x), MIN(self.endDrag.frame.origin.y + self.endDrag.frame.size.height - self.beginDrag.frame.origin.y, self.bounds.size.height));
        
        if(rect.origin.x < _textContainer.left)
        {
            rect.origin.x = _textContainer.left;
        }
        
        //        if(rect.origin.y > _textContainer.bottom )
        //        {
        //            rect.origin.y = _textInset.bottom;
        //        }
        //
        
        //  NSLog(@"%@", NSStringFromCGRect(rect));
        
        //判断是否在可见范围内
        CGRect bounds = self.bounds;
        //NSLog(@"%@", NSStringFromCGRect(bounds));
        
        if((rect.origin.y > bounds.origin.y && rect.origin.y < bounds.size.height + bounds.origin.y) ||
           (rect.origin.y + rect.size.height > bounds.origin.y && rect.origin.y + rect.size.height < bounds.origin.y + bounds.size.height))
        {
            rect.origin.y = MAX(self.beginDrag.frame.origin.y, self.bounds.origin.y);
            if([self isFirstResponder])
            {
                [menuController setTargetRect:rect inView:self];
            }
            else
            {
                [menuController setTargetRect:[self convertRect:rect toView:self.textContainer] inView:self.textContainer];
            }
            [menuController setMenuVisible:YES animated:YES];
        }
    }
    
    // NSLog(@"showMenuController");
    
}

/**隐藏菜单
 */
- (void)hideMenuController
{
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    if([menuController isMenuVisible])
    {
        [menuController setMenuVisible:NO animated:NO];
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if(![self isFirstResponder])
        return NO;
    //  NSLog(@"textView canPerformAction");
    if(self.attributedText.length == 0)
    {
        if((action == @selector(paste:) &&
            [self canPaste]) ||
           action == @selector(insertImage:))
        {
            return YES;
        }
    }
    else
    {
        if((self.selectedRange.length == 0))
        {
            if((action == @selector(paste:) && [self canPaste]) ||
               action == @selector(select:) ||
               action == @selector(selectAll:) ||
               action == @selector(insertImage:))
            {
                return YES;
            }
        }
        else
        {
            if(action == @selector(cut:) ||
               action == @selector(copy:) ||
               (action == @selector(paste:) &&
                [self canPaste]) ||
               action == @selector(delete:) ||
               (_enableEidtTextStyle && action == @selector(selectTextStyle:)))
            {
                return YES;
            }
        }
    }
    
    
    return NO;
}

#pragma mark- copy cut select paste

/**插入图片
 */
- (void)insertImage:(id) sender
{
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidInsertImage:)])
    {
        [self.textDelegate customTextViewDidInsertImage:self];
    }
}

//是否能够复制
- (BOOL)canPaste
{
    if(self.selectedRange.length != NSNotFound && self.selectedRange.length > 0)
        return NO;
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    id text = [pasteboard valueForPasteboardType:(NSString*)kUTTypePlainText];
    
    if(text != nil)
    {
        return YES;
    }
    
    text = [pasteboard valueForPasteboardType:(NSString*)kUTTypeUTF8PlainText];
    if(text != nil)
    {
        return YES;
    }
    
    text = [pasteboard valueForPasteboardType:webArchive];
    if(text != nil)
    {
        return YES;
    }
    
    text = [pasteboard valueForPasteboardType:(NSString*)kUTTypeRTFD];
    if(text != nil)
    {
        return YES;
    }
    
    text = [pasteboard valueForPasteboardType:(NSString*)kUTTypeImage];
    if(text != nil)
    {
        NSArray *attachments = [self getOuterAttachments];
        if(attachments.count >= self.maxImageCount)
        {
            return NO;
        }
        return YES;
    }
    
    return NO;
}

- (void)paste:(id)sender
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    
    // NSLog(@"numberOfitems %@", pasteboard.items);
    //    NSLog(@"itemSet %@", [pasteboard itemSetWithPasteboardTypes:[NSArray arrayWithObjects:(NSString*)kUTTypePlainText, (NSString*)kUTTypeUTF8PlainText, (NSString*)kUTTypeWebArchive, nil]]);
    //NSLog(@"pasteboardTypes %@", [pasteboard pasteboardTypesForItemSet:nil]);
    //    NSLog(@"images %@", pasteboard.images);
    //    NSLog(@"image %@", pasteboard.image);
    
    // NSLog(@"rtf %@", [pasteboard valueForPasteboardType:(NSString*)kUTTypeRTF]);
    
    NSData *data = [pasteboard valueForPasteboardType:webArchive];
    
    
    if(data == nil)
    {
        data = [pasteboard valueForPasteboardType:(NSString*)kUTTypeRTFD];
    }
    
    //获取剪切板上的图片
    if(_ios7_0_ && [data isKindOfClass:[NSData class]])
    {
#ifdef __IPHONE_7_0
        NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithData:data options:nil documentAttributes:nil error:nil];
        
        if(attr != nil)
        {
            //粘贴存在的附件
            NSMutableArray *attachments = [NSMutableArray array];
            
            //获取所有可用的附件
            [attr enumerateAttribute:NSAttachmentAttributeName inRange:NSMakeRange(0, attr.length) options:NSAttributedStringEnumerationReverse usingBlock:^(id value, NSRange range, BOOL *stop){
                
                if([value isKindOfClass:[NSTextAttachment class]])
                {
                    NSTextAttachment *tmp = (NSTextAttachment*)value;
                    UIImage *image = nil;
                    if(tmp.image != nil)
                    {
                        image = tmp.image;
                    }
                    else if(tmp.fileWrapper.regularFileContents != nil)
                    {
                        image = [UIImage imageWithData:tmp.fileWrapper.regularFileContents];
                        tmp.image = image;
                    }
                    
                    if(image)
                    {
                        [attachments addObject:tmp];
                    }
                    else
                    {
                        [attr replaceCharactersInRange:range withString:@""];
                    }
                }
            }];
            
            //删除超出图片数量限制的图片
            NSArray *existAttachments = [self getOuterAttachments];
            if(existAttachments.count + attachments.count > self.maxImageCount)
            {
                NSInteger count = existAttachments.count + attachments.count - self.maxImageCount;
                [attachments removeObjectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, count)]];
            }
            
            // NSLog(@"attachments %d", attachments.count);
            
            //可插入的附件
            NSMutableArray *textAttachments = [NSMutableArray arrayWithCapacity:attachments.count];
            
            [attr enumerateAttributesInRange:NSMakeRange(0, attr.length) options:NSAttributedStringEnumerationReverse usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop){
                
                [attrs enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop)
                 {
                     if([key isKindOfClass:[NSString class]])
                     {
                         NSString *attribute = (NSString*) key;
                         
                         //附件，可能是图片
                         if([attribute isEqualToString:NSAttachmentAttributeName] && [obj isKindOfClass:[NSTextAttachment class]])
                         {
                             NSTextAttachment *tmp = (NSTextAttachment*) obj;
                             if(tmp.image && [attachments containsObject:tmp])
                             {
                                 SeaTextAttachment *attachment = [self attachmentWithImage:tmp.image];
                                 attachment.range = range;
                                 [textAttachments addObject:attachment];
                                 
                                 //判断前后是否有换行符
                                 NSInteger index = (NSInteger)range.location - 1;
                                 if(index > 0 && index != NSNotFound)
                                 {
                                     char forword = [attr.string characterAtIndex:index];
                                     if(forword == '\n' || forword == '\r')
                                     {
                                         NSRange newRange = attachment.range;
                                         newRange.location --;
                                         newRange.length ++;
                                         attachment.range = newRange;
                                     }
                                 }
                                 
                                 index = (NSInteger)(range.length + range.location);
                                 if(index < attr.length && index != NSNotFound)
                                 {
                                     char forword = [attr.string characterAtIndex:index];
                                     if(forword == '\n' || forword == '\r')
                                     {
                                         NSRange newRange = attachment.range;
                                         newRange.length ++;
                                         attachment.range = newRange;
                                     }
                                 }
                                 
                                 //替换系统的附件
                                 NSAttributedString *attachmentAttr = [SeaTextStorage attributeStringWitString:[SeaTextStorage attachmentMarkedString] attachments:[NSArray arrayWithObject:attachment]];
                                 
                                 [attr replaceCharactersInRange:attachment.range withAttributedString:attachmentAttr];
                                 NSRange attRange = attachment.range;
                                 attRange.length = attachmentAttr.length;
                                 attachment.range = attRange;
                             }
                         }
                         else if([attribute isEqualToString:NSFontAttributeName] && [obj isKindOfClass:[UIFont class]]) //字体
                         {
                             UIFont *font = (UIFont*)obj;
                             
                             //  NSLog(@"%@", font.fontName);
                             //判断字体是否支持
                             if(self.supportedFontNames.count > 0 && [self.supportedFontNames containsObject:font.fontName])
                             {
                                 NSString *fontName = font.fontName;
                                 
                                 //使用黑体
                                 NSRange range = [fontName rangeOfString:@"bold"];
                                 if(range.length != NSNotFound && range.length > 0)
                                 {
                                     fontName = [UIFont boldSystemFontOfSize:1.0].fontName;
                                 }
                                 
                                 CTFontRef fontRef = CTFontCreateWithName((CFStringRef)fontName, [self fontSizeCloseToGivenValue:font.pointSize], NULL);
                                 [attr addAttribute:(NSString*)kCTFontAttributeName value:(id)fontRef range:range];
                                 CFRelease(fontRef);
                             }
                             else if(self.supportedFontNames.count > 0)
                             {
                                 CTFontRef fontRef = CTFontCreateWithName((CFStringRef)[self.supportedFontNames firstObject], [self fontSizeCloseToGivenValue:font.pointSize], NULL);
                                 [attr addAttribute:(NSString*)kCTFontAttributeName value:(id)fontRef range:range];
                                 CFRelease(fontRef);
                             }
                         }
                         else if ([attribute isEqualToString:NSForegroundColorAttributeName] && [obj isKindOfClass:[UIColor class]]) //字体颜色
                         {
                             UIColor *textColor = (UIColor*)obj;
                             
                             BOOL exist = NO;
                             for(UIColor *color in self.supportedTextColors)
                             {
                                 if([color isEqualToColor:textColor])
                                 {
                                     exist = YES;
                                     break;
                                 }
                             }
                             
                             if(!exist && self.supportedTextColors.count > 0)
                             {
                                 textColor = [self.supportedTextColors firstObject];
                             }
                             
                             [attr addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)textColor.CGColor range:range];
                         }
                     }
                 }];
            }];
            
            //删除下划线
            [attr removeAttribute:NSUnderlineStyleAttributeName range:NSMakeRange(0, attr.length)];
            [attr removeAttribute:NSUnderlineColorAttributeName range:NSMakeRange(0, attr.length)];
            
            //设置默认样式
            NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self defaultAttributes]];
            [dic removeObjectForKey:(NSString*)kCTForegroundColorAttributeName];
            [dic removeObjectForKey:(NSString*)kCTFontAttributeName];
            
            [attr addAttributes:dic range:NSMakeRange(0, attr.length)];
            
            NSRange range = self.selectedRange;
            
            //删除第一个换行符
            if(self.attributedText.length == 0 && attr.length > 0 && [attr.string characterAtIndex:0] == '\n')
            {
                [attr deleteCharactersInRange:NSMakeRange(0, 1)];
            }
            
            [self.textStorage insertAttributedString:attr atIndex:range.location];
            
            range.location = self.selectedRange.location + attr.length;
            
            [self setupTextContainterSize];
            [self.textContainer refreshVisibleRect];
            self.selectedRange = range;
            
            // NSLog(@"粘贴的图片数量 %d", textAttachments.count);
            
            if(textAttachments.count > 0 && [self.textDelegate respondsToSelector:@selector(customTextView:didPasteAttachemts:)])
            {
                [self.textDelegate customTextView:self didPasteAttachemts:textAttachments];
            }
        }
        
        [attr release];
#endif
    }
    else
    {
        NSString *text = [pasteboard valueForPasteboardType:(NSString*)kUTTypePlainText];
        
        if(text != nil)
        {
            [self insertText:text];
            return;
        }
        
        text = [pasteboard valueForPasteboardType:(NSString*)kUTTypeUTF8PlainText];
        if(text != nil)
        {
            [self insertText:text];
            return;
        }
        
        UIImage *image = pasteboard.image;
        if(image)
        {
            SeaTextAttachment *attachment = [self attachmentWithImage:image];
            NSArray *attachments = [NSArray arrayWithObject:attachment];
            [self insertAttachments:attachments atIndex:self.selectedRange.location];
            
            if([self.textDelegate respondsToSelector:@selector(customTextView:didPasteAttachemts:)])
            {
                [self.textDelegate customTextView:self didPasteAttachemts:attachments];
            }
        }
    }
}

- (void)copy:(id)sender
{
    [self copyMsg];
    [self hideMenuController];
}

- (void)copyMsg
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    NSMutableDictionary *items = [NSMutableDictionary dictionary];
    if(_ios7_0_)
    {
#ifdef __IPHONE_7_0
        
        //可复制图片
        NSAttributedString *text = [self.textStorage attributedSubstringFromRange:self.selectedRange];
        
        if(text)
        {
            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithAttributedString:text];
            
            [attributedText enumerateAttribute:SeaAttachmentAttributeName inRange:NSMakeRange(0, attributedText.length) options:NSAttributedStringEnumerationReverse usingBlock:^(id value, NSRange range, BOOL* stop){
                
                if([value isKindOfClass:[SeaTextAttachment class]])
                {
                    SeaTextAttachment *attachment = (SeaTextAttachment*)value;
                    NSTextAttachment *textAttachment = [[NSTextAttachment alloc] initWithData:nil ofType:nil];
                    // textAttachment.bounds = attachment.bounds;
                    textAttachment.image = attachment.image;
                    
                    NSAttributedString *attributeString = [NSAttributedString attributedStringWithAttachment:textAttachment];
                    
                    [attributedText replaceCharactersInRange:range withString:@""];
                    [attributedText insertAttributedString:attributeString atIndex:range.location];
                    
                    [textAttachment release];
                }
            }];
            
            
            NSRange range = NSMakeRange(0, attributedText.length);
            
            //去除coreText样式，否则程序会崩溃
            [attributedText removeAttribute:(NSString*)kCTFontAttributeName range:range];
            [attributedText removeAttribute:(NSString*)kCTForegroundColorAttributeName range:range];
            [attributedText removeAttribute:(NSString*)kCTParagraphStyleAttributeName range:range];
            
            //设置默认的样式
            UIFont *font = self.font;
            UIColor *textColor = self.textColor;
            
            if(font == nil)
                font = [UIFont systemFontOfSize:16.0];
            if(textColor == nil)
                textColor = [UIColor blackColor];
            
            [attributedText addAttributes:[NSDictionary dictionaryWithObjectsAndKeys:textColor, NSForegroundColorAttributeName, font, NSFontAttributeName,nil] range:range];
            
            NSError *error = nil;
            NSData *data = [attributedText dataFromRange:NSMakeRange(0, attributedText.length) documentAttributes:[NSDictionary dictionaryWithObject:NSRTFDTextDocumentType forKey:NSDocumentTypeDocumentAttribute] error:&error];
            
            //  NSLog(@"%@",attributedText);
            
            if(data)
            {
                [items setObject:data forKey:webArchive];
                [items setObject:data forKey:(NSString*)kUTTypeFlatRTFD];
            }
            else
            {
                NSLog(@"SeaTextView copy fail error %@", error);
            }
            [attributedText release];
        }
#endif
    }
    
    if(self.selectedRange.location + self.selectedRange.length <= self.attributedText.length)
    {
        NSString *text = [self.attributedText.string substringWithRange:self.selectedRange];
        
        NSString *mark = [SeaTextStorage attachmentMarkedString];
        NSString *markString = [NSString stringWithFormat:@"%@\n", mark];
        
        text = [text stringByReplacingOccurrencesOfString:markString withString:@""];
        text = [text stringByReplacingOccurrencesOfString:mark withString:@""];
        
        if(text != nil)
        {
            [items setObject:text forKey:(NSString*)kUTTypePlainText];
        }
    }
    
    if(items.count > 0)
    {
        [pasteboard setItems:[NSArray arrayWithObject:items]];
    }
}

- (void)cut:(id)sender
{
    [self copyMsg];
    
    [self.inputDelegate textWillChange:self];
    [self.textStorage deleteCharactersInRange:self.selectedRange];
    [self.inputDelegate textDidChange:self];
    
    NSRange range = self.selectedRange;
    range.length = 0;
    self.selectedRange = range;
    
    if([self.textContainer isFirstResponder])
    {
        [self setupTextContainterSize];
    }
    [self.textContainer refreshAll];
}

- (void)select:(id)sender
{
    NSRange range = self.selectedRange;
    NSInteger length = 3;
    
    if(range.location == 0)
    {
        range.length = MIN(length, self.attributedText.length);
    }
    else if(range.location == self.attributedText.length)
    {
        range.length = MIN(length, self.attributedText.length);
        range.location = self.attributedText.length - range.length;
    }
    else
    {
        NSInteger len = self.attributedText.length - range.location;
        if(len < length && range.location >= length)
        {
            range.location -= length;
            range.length = length;
        }
        else
        {
            range.length = MIN(len, length);
        }
    }
    
    self.selectedRange = range;
    if(sender != nil)
    {
        [self hideMenuController];
    }
    
    [self.textContainer refreshVisibleRect];
}

- (void)selectAll:(id)sender
{
    self.point = CGPointZero;
    self.selectedRange = NSMakeRange(0, self.attributedText.length);
    [self.textContainer refreshAll];
    [self showMenuController];
}

/**删除
 */
- (void)delete:(id)sender
{
    [self.inputDelegate textWillChange:self];
    [self.textStorage deleteCharactersInRange:self.selectedRange];
    [self.inputDelegate textDidChange:self];
    
    NSRange range = self.selectedRange;
    range.length = 0;
    self.selectedRange = range;
    
    if([self.textContainer isFirstResponder])
    {
        [self setupTextContainterSize];
    }
    
    [self.textContainer refreshAll];
}

/**选择样式
 */
- (void)selectTextStyle:(id) sender
{
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidSelectTextStyle:)])
    {
        [self.textDelegate customTextViewDidSelectTextStyle:self];
    }
}

/**创建选择拖动视图
 */
- (void)createSelectedDragView
{
    if(!self.beginDrag)
    {
        SeaTextSelectedDragView *drag = [[SeaTextSelectedDragView alloc] initWithFrame:CGRectMake(0, 0, _textSelectedDragCircleRadius_ * 2 + _textSelectedDragExpandWidth_, self.font.ascender + fabs(self.font.descender * 2)) style:SeaTextSelectedDragStyleUp];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleSelectedDrag:)];
        [drag addGestureRecognizer:pan];
        [self.panGestureRecognizer requireGestureRecognizerToFail:pan];
        [pan release];
        [self addSubview:drag];
        self.beginDrag = drag;
        [drag release];
        
        drag = [[SeaTextSelectedDragView alloc] initWithFrame:CGRectMake(0, 0, _textSelectedDragCircleRadius_ * 2 + _textSelectedDragExpandWidth_, self.font.ascender + fabs(self.font.descender * 2)) style:SeaTextSelectedDragStyleDown];
        pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleSelectedDrag:)];
        [drag addGestureRecognizer:pan];
        [self.panGestureRecognizer requireGestureRecognizerToFail:pan];
        [pan release];
        [self addSubview:drag];
        self.endDrag = drag;
        [drag release];
    }
}

/**获取外部保存的附件信息 没有则遍历
 */
- (NSArray*)getOuterAttachments
{
    NSArray *attachments = nil;
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidGetAttachments:)])
    {
        attachments = [self.textDelegate customTextViewDidGetAttachments:self];
    }
    else
    {
        attachments = [self attachments];
    }
    
    return attachments;
}

#pragma mark- gesture

//单击手势
- (void)handleTap:(UITapGestureRecognizer*) tap
{
    self.point = [tap locationInView:self.textContainer];
    
    //点击选择区域
    if([self isSelectedRectContaintPoint:self.point])
    {
        [self showMenuController];
    }
    else
    {
        [self.inputDelegate selectionWillChange:self];
        NSInteger index = [self closestIndexForPoint:self.point];
        
        NSRange oldSelectedRange = self.selectedRange;
        
        
        self.isTapping = YES;
        self.selectedRange = NSMakeRange(index, 0);
        self.isTapping = NO;
        
        //初始化输入高亮
        self.markedRange = NSMakeRange(NSNotFound, 0);
        
        if([self.textContainer isFirstResponder] && oldSelectedRange.length > 0)
        {
            [self hideMenuController];
            self.selectedRange = NSMakeRange(NSNotFound, 0);
        }
        else if(![self isFirstResponder])
        {
            [self hideMenuController];
            [self becomeFirstResponder];
        }
        else if(oldSelectedRange.location == self.selectedRange.location && oldSelectedRange.length == self.selectedRange.length)
        {
            [self showMenuController];
        }
        else
        {
            [self hideMenuController];
        }
        
        if(oldSelectedRange.length != 0)
        {
            [self.textContainer refreshAll];
        }
        
        [self.inputDelegate selectionDidChange:self];
    }
}

//长按手势
- (void)handleLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        if(self.attributedText.length == 0)
        {
            [self showMenuController];
            return;
        }
        
        self.point = [longPress locationInView:self.textContainer];
        
        //转成coreText 坐标
        CGPoint point = CGPointMake(self.point.x, self.textContainer.bounds.size.height - self.point.y);
        //判断是否长按图片
        for(NSInteger i = 0;i < self.textStorage.paragraphInfos.count;i ++)
        {
            SeaTextParagraphInfo *info = [self.textStorage.paragraphInfos objectAtIndex:i];
            // NSLog(@"attachment rect %@", NSStringFromCGRect(info.rect));
            
            if(CGRectContainsPoint(info.rect, point))
            {
                NSString *str = [self.attributedText.string substringWithRange:info.range];
                NSString *markedStr = [SeaTextStorage attachmentMarkedString];
                NSRange range = [str rangeOfString:markedStr];
                if(range.location != NSNotFound && range.length > 0)
                {
                    SeaTextAttachment *attachment = [[self.textStorage attachmentsInRange:info.range count:1] firstObject];
                    if(attachment)
                    {
                        // NSLog(@"delete attachment range %@", NSStringFromRange(attachment.range));
                        if([self.textDelegate respondsToSelector:@selector(customTextView:didLongPressAttachemt:atParagraphIndex:)])
                        {
                            [self.textDelegate customTextView:self didLongPressAttachemt:attachment atParagraphIndex:i];
                            return;
                        }
                    }
                }
                break;
            }
        }
        [self.inputDelegate selectionWillChange:self];
        NSInteger index = [self closestIndexForPoint:self.point];
        
        self.isTapping = YES;
        self.selectedRange = NSMakeRange(index, 0);
        self.isTapping = NO;
        
        //初始化输入高亮
        self.markedRange = NSMakeRange(NSNotFound, 0);
        
        if(![self isFirstResponder])
        {
            [self.textContainer becomeFirstResponder];
            [self select:nil];
        }
        
        [self showMenuController];
        [self.inputDelegate selectionDidChange:self];
    }
}

//选择拖动
- (void)handleSelectedDrag:(UIPanGestureRecognizer*) pan
{
    if(pan.state == UIGestureRecognizerStateBegan)
    {
        self.isSelecting = YES;
        [self hideMenuController];
        self.point = [pan locationInView:self.textContainer];
    }
    else if(pan.state == UIGestureRecognizerStateChanged)
    {
        CGPoint point = [pan locationInView:self.textContainer];
        NSRange range = self.selectedRange;
        
        if(point.y - self.point.y > 0)
        {
            self.dragDirection = SeaTextViewDragDirectionDown;
        }
        else
        {
            self.dragDirection = SeaTextSelectedDragStyleUp;
        }
        
        //获取拖动到的位置
        NSInteger index = [self closestIndexForPoint:point];
        
        if([pan.view isEqual:self.beginDrag])
        {
            self.beginDragPoint = point;
            NSInteger location = MIN(range.location + range.length - 1, index);
            range.length = range.location + range.length - location;
            range.location = location;
        }
        else
        {
            self.endDragPoint = point;
            NSInteger length = MAX(index - (NSInteger)range.location, 1);
            range.length = length;
        }
        
        //判断是否选中换行符
        if(range.length == 1)
        {
            if(range.location + range.length <= self.attributedText.length)
            {
                NSString *str = [self.attributedText.string substringWithRange:range];
                if([str isEqualToString:@"\n"] || [str isEqualToString:@"\r"])
                {
                    NSInteger loc = range.location - 1;
                    if(loc < 0 || loc == NSNotFound)
                    {
                        loc = 0;
                    }
                    NSInteger len = range.length + 1;
                    if(loc + len > self.attributedText.length)
                    {
                        len = MIN(2, self.attributedText.length - loc);
                    }
                    range = NSMakeRange(loc, len);
                }
            }
        }
        
        self.selectedRange = range;
        
        if(!self.isDragAnimating)
        {
            CGRect rect = pan.view.frame;
            CGRect bounds = self.bounds;
            if(rect.origin.y < (bounds.origin.y + bounds.size.height / 2.0))
            {
                rect.origin.y -= rect.size.height;
            }
            
            if(rect.origin.y < 0)
            {
                rect.origin.y = 0;
            }
            
            if(rect.origin.y + rect.size.height >= (bounds.origin.y + bounds.size.height - rect.size.height))
            {
                rect.origin.y += rect.size.height;
            }
            
            // NSLog(@"rect %@", NSStringFromCGRect(rect));
            
            self.isDragAnimating = YES;
            [UIView animateWithDuration:0.5 animations:^(void){
                
                [self scrollRectToVisible:rect animated:NO];
            }completion:^(BOOL finish){
                
                self.isDragAnimating = NO;
            }];
        }
        
        [self.textContainer refreshVisibleRect];
    }
    else
    {
        self.point = CGPointZero;
        [self showMenuController];
        self.isSelecting = NO;
        
        //滚动到选择的区域
        CGRect rect = pan.view.frame;
        CGRect bounds = self.bounds;
        if(rect.origin.y < (bounds.origin.y + bounds.size.height / 2.0))
        {
            rect.origin.y -= rect.size.height;
        }
        
        if(rect.origin.y < 0)
        {
            rect.origin.y = 0;
        }
        
        if(rect.origin.y + rect.size.height >= (bounds.origin.y + bounds.size.height - rect.size.height))
        {
            rect.origin.y += rect.size.height;
        }
        
        // NSLog(@"rect %@", NSStringFromCGRect(rect));
        
        [self scrollRectToVisible:rect animated:YES];
    }
}

//判断点击的位置是否在选择的高亮区域
- (BOOL)isSelectedRectContaintPoint:(CGPoint) point
{
    if(self.beginDrag.hidden && self.endDrag.hidden)
        return NO;
    
    CGRect rect1 = self.beginDrag.frame;
    CGRect rect2 = self.endDrag.frame;
    
    if(point.x > rect1.origin.x)
    {
        if(point.y > rect1.origin.y && point.y < rect2.origin.y + rect2.size.height)
        {
            if(point.x < rect2.origin.x)
            {
                return YES;
            }
        }
    }
    else
    {
        if(point.y > rect1.origin.y + rect1.size.height && point.y < rect2.origin.y + rect2.size.height)
        {
            if(point.x < rect2.origin.x)
            {
                return YES;
            }
        }
    }
    
    return NO;
}

#pragma mark- rect

//获取可见范围
- (CGRect)visibleRect
{
    return CGRectMake(self.bounds.origin.x, self.bounds.origin.y, self.textContainer.frame.size.width, MIN(self.frame.size.height, self.textContainer.frame.size.height));
}

//设置文本框大小
- (void)setupTextContainterSize
{
    CGRect frame = self.textContainer.frame;
    
    CGFloat height = [self.textStorage textHeight];
    if(self.attributedText.length == 0 && ![NSString isEmpty:self.placeHolder])
    {
        //计算文本框大小
        height = [_placeHolder stringSizeWithFont:self.placeholderFont contraintWith:self.textCaretView.frame.size.width].height + 5.0;
    }
    
    
    frame.size.height = height;
    self.textContainer.frame = frame;
    
    
    [self setupContentSize];
}

//设置滚动视图内容大小
- (void)setupContentSize
{
    self.contentSize = CGSizeMake(self.bounds.size.width, self.textContainer.bounds.size.height + self.textInset.bottom + self.textInset.top);
}

#pragma mark- 文本样式

//获取基本样式
- (NSDictionary*)defaultAttributes
{
    return [self baseAttributesWithFont:self.font textColor:self.textColor];
}

/**获取基本样式
 *@param font 字体
 *@param textColor 字体颜色
 *@return 基本样式
 */
- (NSDictionary*)baseAttributesWithFont:(UIFont*) font textColor:(UIColor*) textColor
{
    if(font == nil)
        font = [UIFont systemFontOfSize:16.0];
    if(textColor == nil)
        textColor = [UIColor blackColor];
    //换行模式
    CTParagraphStyleSetting lineBreadMode;
    CTLineBreakMode linkBreak = kCTLineBreakByCharWrapping;
    lineBreadMode.spec = kCTParagraphStyleSpecifierLineBreakMode;
    lineBreadMode.value = &linkBreak;
    lineBreadMode.valueSize = sizeof(CTLineBreakMode);
    
    CTParagraphStyleSetting setting[] = {lineBreadMode};
    CTParagraphStyleRef style = CTParagraphStyleCreate(setting, 1);
    
    CTFontRef ctFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:(id)textColor.CGColor, (NSString*)kCTForegroundColorAttributeName, (id)ctFont, (NSString*)kCTFontAttributeName, (id)style, (NSString*)kCTParagraphStyleAttributeName, nil];
    
    CFRelease(ctFont);
    CFRelease(style);
    
    return dic;
}

#pragma mark- responder

- (BOOL)canBecomeFirstResponder
{
    if(self.editable)
        return YES;
    return NO;
}

- (BOOL)becomeFirstResponder
{
    [self selectionDidChange];
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidBeginEditing:)])
    {
        [self.textDelegate customTextViewDidBeginEditing:self];
    }
    return [super becomeFirstResponder];
}

- (BOOL)resignFirstResponder
{
    [self hideMenuController];
    
    NSRange oldRange = self.selectedRange;
    self.selectedRange = NSMakeRange(NSNotFound, 0);
    self.markedRange = NSMakeRange(NSNotFound, 0);
    
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidEndEditing:)])
    {
        [self.textDelegate customTextViewDidEndEditing:self];
    }
    
    if(oldRange.length > 0)
    {
        [self.textContainer refreshVisibleRect];
    }
    
    return [super resignFirstResponder];
}

/**回收键盘
 */
- (void)inputFinish:(id) sender
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

#pragma mark- refresh

//刷新
- (void)refresh
{
    [self setupTextContainterSize];
    // [self.textStorage refreshTextInRange:NSMakeRange(0, self.attributedText.length) string:self.attributedText.string];
    [self.textContainer refreshAll];
}

#pragma mark- undoManager

- (void)undoAttributedText:(NSAttributedString *)attributedText selectedRange:(NSRange) selectedRange
{
    self.attributedText = attributedText;
    self.selectedRange = selectedRange;
}

/**撤销完成
 */
- (void)undoManagerDidUndo:(NSNotification*) notification
{
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidUndo:)])
    {
        [self.textDelegate customTextViewDidUndo:self];
    }
}

/**恢复完成
 */
- (void)undoManagerDidRedo:(NSNotification*) notification
{
    if([self.textDelegate respondsToSelector:@selector(customTextViewDidRedo:)])
    {
        [self.textDelegate customTextViewDidRedo:self];
    }
}

@end
