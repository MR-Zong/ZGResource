//
//  SeaTextRange.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextRange.h"
#import "SeaTextPosition.h"

@implementation SeaTextRange

/**构造方法
 *@param range 文本范围
 *@return 一个初始化的 SeaTextRange 对象
 */
+ (SeaTextRange*)textRangeWithRange:(NSRange) range
{
    SeaTextRange *textRange = [[SeaTextRange alloc] init];
    textRange.range = range;
    return [textRange autorelease];
}

- (UITextPosition*)start
{
    return [SeaTextPosition textPositionWithIndex:self.range.location];
}

- (UITextPosition*)end
{
    return [SeaTextPosition textPositionWithIndex:self.range.location + self.range.length];
}

- (BOOL)isEmpty
{
    return (self.range.location == NSNotFound || self.range.length == 0);
}

@end
