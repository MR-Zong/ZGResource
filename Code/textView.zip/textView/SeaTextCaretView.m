//
//  SeaTextCaretView.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-10-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextCaretView.h"


@implementation SeaTextCaretView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor colorWithRed:0.259f green:0.420f blue:0.949f alpha:1.0f];
        _isAnimating = NO;
    }
    return self;
}

#pragma mark- dealloc 

- (void)dealloc
{
    [self.layer removeAllAnimations];
    
    [super dealloc];
}

#pragma mark- public method

/**开始动画
 */
- (void)startAnimated
{
    self.hidden = NO;
    [self delayBlink];
}

/**停止动画
 */
- (void)stopAnimated
{
    self.hidden = YES;
    _isAnimating = NO;
    [self.layer removeAllAnimations];
}

#pragma mark- private method

//眨眼动画
- (void)delayBlink
{
    if(self.isAnimating)
        return;
    CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
    animation.values = [NSArray arrayWithObjects:[NSNumber numberWithFloat:1.0f], [NSNumber numberWithFloat:1.0f], [NSNumber numberWithFloat:0.0f], [NSNumber numberWithFloat:0.0f], nil];
    animation.calculationMode = kCAAnimationCubic;
    animation.duration = 1.0;
    animation.beginTime = CACurrentMediaTime() + 0.6;
    animation.repeatCount = CGFLOAT_MAX;
    [self.layer addAnimation:animation forKey:@"BlinkAnimation"];
    _isAnimating = YES;
}

@end
