//
//  SeaTextParagraph.m
//  TextViewDemo
//
//  Created by kinghe005 on 14-11-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "SeaTextParagraphInfo.h"
#import "SeaTextStorage.h"
#import "SeaTextAttachment.h"

@implementation SeaTextParagraphInfo

- (void)dealloc
{
    if(_ctFrame != NULL)
    {
        CFRelease(_ctFrame);
    }
    
    [_attachment release];
    
    [super dealloc];
}

- (CTFrameRef)ctFrame
{
    return _ctFrame;
}

/**创建段落
 *@param attributedString 段落文本内容
 *@param maxWidth 段落的最大宽度
 *@param y 段落的起点y轴位置
 *@return 实际段落所占的文本范围
 */
- (void)createTextParagraphWithAttributedString:(NSAttributedString*) attributedString maxWidth:(CGFloat) maxWidth originalY:(CGFloat) y
{
    if(attributedString == nil)
        return;
    
    //NSLog(@"%@",attributedString);
    
    //判断是否是附件
    if(attributedString.length == SeaAttachmentStringLength)
    {
        NSString *markString = [SeaTextStorage attachmentMarkedString];
        NSRange range = [attributedString.string rangeOfString:markString];
        if(range.location != NSNotFound && range.length > 0)
        {
            SeaTextAttachment *attachment = [attributedString attribute:SeaAttachmentAttributeName atIndex:0 effectiveRange:NULL];
            if([attachment isKindOfClass:[SeaTextAttachment class]])
            {
                self.attachment = attachment;
                maxWidth = MIN(self.attachment.bounds.size.width, maxWidth);
            }
        }
    }
    
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef) attributedString);
    if(framesetter == NULL)
        return;

    CGSize size = CTFramesetterSuggestFrameSizeWithConstraints(framesetter, CFRangeMake(0, 0), NULL, CGSizeMake(maxWidth, CGFLOAT_MAX), NULL);
    
    CGRect bounds = CGRectMake(0, y, maxWidth, size.height);
    
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, bounds);
    
    if(_ctFrame != NULL)
        CFRelease(_ctFrame);
    
    _ctFrame = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), path, NULL);

    self.rect = bounds;
    CFRelease(framesetter);
    CGPathRelease(path);
}

@end
