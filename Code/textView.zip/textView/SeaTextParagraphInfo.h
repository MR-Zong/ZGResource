//
//  JBoTextParagraph.h
//  TextViewDemo
//
//  Created by kinghe005 on 14-11-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>

@class SeaTextAttachment;

/**文本段落信息
 */
@interface SeaTextParagraphInfo : NSObject
{
    CTFrameRef _ctFrame;
}
/**段落的文本范围
 */
@property(nonatomic,assign) NSRange range;

/**段落的文本区域 UIKit 坐标系
 */
@property(nonatomic,assign) CGRect rect;

/**段落附件 没有则为nils
 */
@property(nonatomic,retain) SeaTextAttachment *attachment;

/**段落的行信息
 */
@property(nonatomic,readonly) CTFrameRef ctFrame;

/**创建段落
 *@param attributedString 段落文本内容
 *@param maxWidth 段落的最大宽度
 *@param y 段落的起点y轴位置
 *@return 实际段落所占的文本范围
 */
- (void)createTextParagraphWithAttributedString:(NSAttributedString*) attributedString maxWidth:(CGFloat) maxWidth originalY:(CGFloat) y;

@end
