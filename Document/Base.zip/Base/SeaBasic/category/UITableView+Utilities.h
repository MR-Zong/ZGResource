//
//  UITableView+extraCellLine.h

//

#import <UIKit/UIKit.h>

@interface UITableView (Utilities)

/**隐藏多余的分割线
 */
- (void)setExtraCellLineHidden;

@end
