//
//  SeaSegmentedSliderItem.h

//

#import <UIKit/UIKit.h>

/**分段滑杆按钮
 */
@interface SeaSegmentedSliderItem : UIButton

@property(nonatomic, retain) UIColor *handlerColor;

@end
