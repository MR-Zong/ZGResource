//
//  JBoLookAndTellOperation.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoLookAndTellListInfo.h"
#import "JBoOfflineCacheOperation.h"

#define _releaseLookAndTellIdntifier_ @"releaseLookAndTellIdntifier"
#define _getCircleLookAndTellIdentifier_ @"getCircleLookAndTellIdentifier"
#define _getUserLookAndTellIdentifier_ @"getUserLookAndTellIdentifier"
#define _removeLookAndTellIdentifier_ @"removeLookAndTellIdentifier"

#define _getAllLookAndTellIdentifier_ @"getAllLookAndTellIdentifier"
#define _setupUserLookAndTellIdentifier_ @"setupUserLookAndTellIdentifier"

#define _laysReviewIdentifier_ @"laysReviewIdentifier"
#define _updateLaysIdentifer_ @"updateLaysIdentifer"
#define _getMyLaysIdentifier_ @"getMyLaysIdentifier"

#define _trasmitLookAndTellIdentifier_ @"trasmitLookAndTellIdentifier"
#define _stickLookAndTellIdentifier_ @"stickLookAndTellIdentifier"

#define _updateMsgOperationStatusIdentifier_ @"updateMsgOperationStatusIdentifier"

#define _activityReviewIdentifier_ @"activityReviewIdentifier"

#define _lookAndTellVisibleIdentifier_ @"lookAndTellVisibleIdentifier"

#define _getLookAndTellByGroupIdIdentifier_ @"getLookAndTellByGroupIdIdentifier"
#define _getLookAndTellByMsgIdIdentifier_ @"getLookAndTellByMsgIdIdentifier"

#define _releaseLookAndTellCommentIdentifier_ @"releaseLookAndTellCommentIdentifier"

@class XMPPIQ;
@class JBoSignInInfo;

/**靓友圈网络操作
 */
@interface JBoLookAndTellOperation : NSObject

#pragma mark- 靓友圈信息内容

/**发布靓友圈信息，有图片
 *@return post请求url
 */
+ (NSString*)getReleaseLookAndTellURL;

/**发布靓友圈信息，没图片
 *@return post请求url
 */
+ (NSString*)getReleaseLookAndTellURLWithOutFiles;

/**获取发布靓友圈信息参数
 *@param content 文本内容
 *@param type 靓友圈信息类型
 *@param groupId 组Id
 *@param order 多图文顺序
 *@param count 多图文数量
 *@param url 分享的链接
 *@param need 参加活动是否需要图文
 *@param visible 可见范围
 *@return post请求参数
 */
+ (NSDictionary*)releaseLookAndTellWithContent:(NSString*) content type:(NSInteger) type groupId:(NSString*) groupId order:(NSInteger) order count:(NSInteger) count url:(NSString*) url needImageText:(BOOL) need visible:(NSInteger) visible;

/**分享连接到靓友圈 参数
 *@param content 文本内容
 *@param groupId 组Id
 *@param urlTitle 链接标题
 *@param url 链接
 *@return post请求参数
 */
+ (NSDictionary*)shareLinkWithContent:(NSString*) content groupId:(NSString*) groupId urlTitle:(NSString*) urlTitle url:(NSString*) url;

/**获取靓友圈信息
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getCircleLookAndTellInfoWithPageNum:(NSInteger) pageNum rows:(NSInteger) rows;

/**从返回的数据获取靓友圈信息
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param offineCache 离线缓存
 *@return 数组元素是 JBoLookAndTellListInfo 对象
 */
+ (NSMutableArray*)getCircleLookAndTellInfoFromData:(NSData*) data multiInfo:(NSMutableDictionary*) multiInfo offlineCache:(JBoOfflineCacheOperation*) offlineCache;

/**添加靓友圈信息类型图标
 *@param transmitId 是否为转载的
 *@param type 靓友圈信息类型
 *@param generalId 参加活动的审核状态
 *@param enterpriseId
 */
+ (void)addFaceIconWithTransmitId:(NSInteger) transmitId type:(NSInteger) type generalId:(NSInteger) generalId enterpriseId:(NSInteger) enterpriseId text:(JBoMultiImageText*) text;

/**获取某个用户的靓友圈信息
 *@userId 用户id
 *@param pageNum 页码
 *@param rows 每页数量
 *visible 可见范围
 *@return get请求url
 */
+ (NSString*)getUserLookAndTellInfoWithUserId:(NSString*) userId pageNum:(NSInteger) pageNum rows:(NSInteger) rows visible:(NSInteger) visible;

/**从返回的数据获取某个用户的靓友圈信息
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param offineCache 离线缓存
 *@return 数组元素是 JBoLookAndTellListInfo 对象
 */
+ (NSMutableArray*)getUserLookAndTellInfoFromData:(NSData*) data multiInfo:(NSMutableDictionary*) multiInfo offlineCache:(JBoOfflineCacheOperation*) offlineCache;;

/**删除靓友圈信息
 *@param groupId 组Id
 *@return get请求url
 */
+ (NSString*)getRemoveLookAndTellWithGroupId:(NSString*) groupId;

/**根据靓友圈信息msgId获取它的详细信息
 *@param msgId 靓友圈信息的msgId
 *@return get请求url
 */
+ (NSString*)getLookAndTellFromMsgId:(NSString*) msgId;

/**通过返回的数据获取靓友圈信息
 *@param data 返回的数据
 *@return 靓友圈信息
 */
+ (JBoLookAndTellListInfo*) getLookAndTellFromData:(NSData*) data;

/**通过groupId获取靓友圈信息
 *@param groupId 靓友圈信息的groupId
 *@return get请求url
 */
+ (NSString*)getLookAndtellFromGroupId:(NSString*) groupId;

#pragma mark- 靓友圈信息状态

/**转载靓友圈信息
 *@param info 靓友圈信息
 *@return qet请求url
 */
+ (NSString*)getTrasmitLookAndTellWithInfo:(JBoLookAndTellListInfo*) info;

/**设置靓友圈信息的置顶状态
 *@param groupId 靓友圈信息的groupId
 *@param state 置顶状态
 *@return get请求url
 */
+ (NSString*)getStickLookAndTellWithGroupId:(NSString*) groupId state:(NSInteger) state;

/**获取某个用户的置顶靓友圈信息
 *@param userId 用户的id
 *@return get请求url
 */
+ (NSString*)getStickMsgWithUserId:(NSString*) userId;

/**设置靓友圈信息可见范围 url
 *@return post请求url
 */
+ (NSString*)lookAndTellVisibleURL;

/**设置靓友圈信息可见范围 参数
 *@param visible 可见范围
 *@param groupId 靓友圈信息的groupId
 *@return post请求参数
 */
+ (NSDictionary*)lookAndTellParaWithVisible:(NSInteger) visible groupId:(NSString*) groupId;

#pragma mark- 靓友圈背景

/**获取靓友圈的背景图片信息
 *@return get请求url
 */
+ (NSString*)getALlLookAndTellBgImage;

/**从返回的数据获取靓友圈背景图片信息
 *@param data 返回的数据
 *@param titleArray 空的数组，将填充靓友圈背景图片分类标题信息  数组元素是 NSString对象
 *@param infoDic 空的字典，将填充靓友圈背景图片信息，key为标题，value 是 一个数组，数组元素是JBoLookAndTellBigImageInfo对象
 */
+ (void)getAllLookAndTellFromData:(NSData*) data withTitleArray:(NSMutableArray*) titleArray infoDic:(NSMutableDictionary*) infoDic;

/**设置用户的靓友圈背景图片
 *@param imageUrl 图片路径
 *@return get请求url
 */
+ (NSString*)setupUserLookAndTellBgImageWithUrl:(NSString*) imageUrl;

/**获取用户的靓友圈背景图片
 *@param userId 用户的id
 *@return get请求url
 */
+ (NSString*)getUserLookAndTellBgImageWithUserId:(NSString*) usrId;

/**通过返回的数据获取靓友圈的背景图片
 *@param data 返回的数据
 *@return 图片路径
 */
+ (NSString*)getUserLookAndTellBgImageFromData:(NSData*) data;

#pragma mark- 靓友圈信息评论

/**获取靓友圈信息评论
 *@param groupId 靓友圈信息的groupId
 *@return get请求url
 */
+ (NSString*)getLookAndTellCommentURLWithGroupId:(NSString*) groupId;

/**从返回的数据获取靓友圈信息评论内容
 *@param data 返回的数据
 *@return 评论内容 数组元素是JBoLookAndTellCommentInfo对象
 */
+ (NSMutableArray*)getLookAndTellCommetnFromData:(NSData*) data;

/**评论靓友圈信息 url
 *@return post请求url
 */
+ (NSString*)releaseLookAndTellCommentURL;

/**评论靓友圈信息 参数
 *@param groupId 靓友圈信息的groupId
 *@param content 评论内容
 *@return post请求参数
 */
+ (NSDictionary*)releaseLookAndTellCommentParaWithGroupId:(NSString*) groupId content:(NSString*) content;

#pragma mark- 靓友圈信息操作

/**更新靓友圈信息的 点赞，同情等操作状态
 *@param info 靓友圈信息
 *@return get请求url
 */
+ (NSString*)updateLookAndTellStatusWithInfo:(JBoLookAndTellListInfo*) info;

/**从返回的数据获取数量
 *@param data 返回的数据
 *@return 数量
 */
+ (NSInteger)getCountFromData:(NSData*) data;

/**获取靓友圈信息点赞数量
 *@param groupId 靓友圈信息的
 *@return get请求url
 */
+ (NSString*)getPraiseCountWithGroupId:(NSString*) groupId;

/**获取靓友圈信息同情总数
 *@param groupId 靓友圈信息
 *@return get请求url
 */
+ (NSString*)getPityCountWithGroupId:(NSString*) groupId;

/**获取靓友圈信息 点赞，同情等事件状态
 *@param groupId 靓友圈信息的groupId
 *@param userId 用户的id
 *@return get请求url
 */
+ (NSString*)getMsgStateWithGroupId:(NSString*) groupId userId:(NSString*) userId;

/**从返回的数据获取 靓友圈信息 点赞，同情等事件状态
 *@param data 返回的数据
 *@param info 靓友圈信息事件状态容器
 */
+ (void)getMsgstateFromData:(NSData*) data withInfo:(JBoMsgOperationInfo*) info;

#pragma mark- 报名签到

/**获取靓友圈信息签到总数
 *@param groupId 靓友圈信息的
 *@return get请求url
 */
+ (NSString*)getSignInCountWithGroupId:(NSString*) groupId;

/**获取靓友圈信息报名总数
 *@param groupId 靓友圈信息的
 *@return get请求url
 */
+ (NSString*)getSignUpCountWithGroupId:(NSString*) groupId;

/**靓友圈信息签到 url
 *@return post请求url
 */
+ (NSString*)signInActivity;

/**靓友圈信息签到 参数
 *@param groupId 靓友圈信息groupId
 *@param address 签到的地址
 *@return post请求参数
 */
+ (NSDictionary*)signInActivityInfoWithGroupId:(NSString*) groupId address:(NSString*) address;

/**获取靓友圈活动签到的用户
 *@param srcGroupId 靓友圈信息的 groupId
 *@param pageNun 页码
 *@param row 每页数量
 *@return get请求url
 */
+ (NSString*)getSignInUsersWithId:(NSString*) srcGroupId pageNum:(NSInteger) pageNun row:(NSInteger) row;;

/**从返回的数据获取靓友圈活动签到的用户
 *@param data 返回的数据
 *@return 数组元素是 JBoSignInInfo对象
 */
+ (NSMutableArray*)getSignInUsersFromData:(NSData*) data;

/**靓友圈信息签到抽奖
 *@param groupId 靓友圈信息groupId
 *@param result 已抽到的用户
 *@return get请求url
 */
+ (NSString*)activityLuckyDrawWithGroupId:(NSString*) groupId result:(NSString*) result;

/**通过返回的数据获取靓友圈信息签到抽奖结果
 *@param data 返回的数据
 *@return 用户的签到信息
 */
+ (JBoSignInInfo*)activityLuckyDrawWithGroupFromData:(NSData*) data;

/**获取靓友圈活动报名的用户
 *@param srcGroupId 靓友圈信息的 groupId
 *@param pageNun 页码
 *@param row 每页数量
 *@return get请求url
 */
+ (NSString*)getSignUpUsersWithId:(NSString*) srcGroupId pageNum:(NSInteger) pageNun row:(NSInteger) row;

/**从返回的数据获取靓友圈活动报名的用户
 *@param data 返回的数据
 *@return 数组元素是 JBoSignUpInfo对象
 */
+ (NSMutableArray*)getSignUpUserFromData:(NSData*) data;

/**靓友圈活动报名 url
 *@return post请求url
 */
+ (NSString*)getActivitySignupURL;

/**靓友圈活动报名 参数
 *@param name 真实姓名
 *@param phoneNum 手机号码
 *@param email 邮箱
 *@param remark 备注信息
 *@param info 靓友圈信息
 *@return post请求参数
 */
+ (NSDictionary*)getActivitySignupParaWithName:(NSString*) name phoneNum:(NSString*) phoneNum email:(NSString*) email ramrk:(NSString*) remark info:(JBoLookAndTellListInfo*) info;

#pragma mark- 靓友圈活动

/**返回申请参加活动用户总数
 *@param 靓友圈活动的groupId
 *@return get请求url
 */
+ (NSString*)getApplyCountWithGroupId:(NSString*) groupId;

/**参加或审核靓友圈活动
 *@param userId 参与者的userId
 *@param msgId 参加活动的靓友圈信息的 msgId
 *@param groupId 参加活动的靓友圈信息的 groupId
 *@param state 参与状态 或 审核结果（初选，复选，决选）
 *@return get请求url
 */
+ (NSString*)joinActivityWithUserId:(NSString*) userId msgId:(NSString*) msgId groupId:(NSString*) groupId state:(NSInteger) state;

/**获取所有已成功参加活动的靓友圈信息 (查看自己参加的）
 *@param typeId 活动角色，使用 0，参与者
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getAllActivityActorWithTypeId:(NSInteger) typeId pageNum:(NSInteger) pageNum rows:(NSInteger) rows;

/**通过返回的数据获取所有已成功参加活动的靓友圈信息 (查看自己参加的）
 *@param  data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param 靓友圈信息，数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)getAllActivityActorFromData:(NSData*) data multiInfo:(NSMutableDictionary*) multiInfo;

//根据用户ID筛选已成功参加活动的连说(查看自己参加的）
//+ (NSString*)filterAllActivityActorWithTypeId:(NSInteger) typeId pageNum:(NSInteger) pageNum rows:(NSInteger) rows filterId:(NSInteger) filterId;
//+ (NSMutableArray*)filterAllActivityActorFromData:(NSData*) data multiInfo:(NSMutableDictionary*) multiInfo;

/**获取某个活动的所有已成功参加活动的靓友圈信息（活动发起人）
 *@param groupId 活动的groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getActivityActorWithGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows;

/**通过返回的数据 获取某个活动的所有已成功参加活动的靓友圈信息（活动发起人）
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param 靓友圈信息，数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)getActivityActorFromData:(NSData*) data multiInfo:(NSMutableDictionary*) multiInfo;

/**筛选某个活动的所有已成功参加活动的靓友圈信息（活动发起人)
 *@param groupId 活动的groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@param filterId 筛选类型 ，初选，复选，决选
 *@return get请求url
 */
+ (NSString*)filterActivityWithGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows filterId:(NSInteger) filterId;

/**通过返回的数据 筛选某个活动的所有已成功参加活动的靓友圈信息（活动发起人）
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param 靓友圈信息，数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)filterActivityActorFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo;

#pragma mark- 爱心活动

/**获取爱心活动的证明人总数
 *@param groupId 爱心活动的groupId
 *@return get请求url
 */
+ (NSString*)getWitnessCountWithGroupId:(NSString*) groupId;

/**成为某个爱心活动的证明人 url
 *@return post请求url
 */
+ (NSString*)witnessActivity;

/**成为某个爱心活动的证明人 参数
 *@param groupId 爱心活动的groupId
 *@param content 证明信息
 *@return post请求参数
 */
+ (NSDictionary*)winessActivityInfoWithGroupId:(NSString*) groupId content:(NSString*) content;

/**获取某个爱心活动的证明人
 *@param groupId 爱心活动的groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getActivityWitnessWitthGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows;

/**从返回的数据获取某个爱心活动的证明人
 *@param data 返回的数据
 *@return 数组元素是 JBoWitnessInfo对象
 */
+ (NSMutableArray*)getActivityWinessFromData:(NSData*) data;

#pragma mark- 视频

/**上传视频 url
 *@return post请求url
 */
+ (NSString*)uploadMovieURL;

/**上传视频参数
 *@param file s视频文件
 *@param post请求参数
 */
+ (NSDictionary*)getUploadMovieDicWithFile:(NSString*) file;

/**从返回的数据获取上传视频结果
 *@param data 返回的参数
 *@return 视频文件的网络url
 */
+ (NSString*)getUploadMovieResultFromData:(NSData*) data;

/**删除视频
 */
+ (NSString*)removeMovieURL;

#pragma mark- 活动代言

/**靓友圈代言活动审核
 *@param targetId 审核人，一般是当前登录用户的 userId
 *@param msgId 参加活动的靓友圈信息的 msgId
 *@param state 审核结果 初选，复选，决选
 *@param groupId 参加活动的靓友圈信息的 groupId
 *@return get请求url
 */
+ (NSString*)getLaysReviewWithTargetId:(NSString*) targetId msgId:(NSString*) msgId state:(NSInteger) state groupId:(NSString*) groupId;

//获取我的代言
+ (NSString*)getMyLaysWithPageNum:(NSInteger) pageNum rows:(NSInteger) rows;
+ (NSMutableArray*)getMyLaysFromData:(NSData*) data multiInfo:(NSMutableDictionary*) multiInfo;

//筛选代言
+ (NSString*)getMyLaysWithPageNum:(NSInteger)pageNum rows:(NSInteger)rows filter:(NSInteger) filter;

//更新代言
+ (NSString*)getUpdateLaysWithMsgId:(NSString*) msgId groupId:(NSString*)groupId state:(NSInteger) state;

//代言筛选
+ (NSString*)getLaysActorWithGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows;
+ (NSString*)filterLaysActorWithGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows filterId:(NSInteger) filterId;

@end
