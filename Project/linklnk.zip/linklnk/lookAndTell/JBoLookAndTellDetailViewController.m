//
//  JBoLookAndTellDetailViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellDetailViewController.h"
#import "JBoAppDelegate.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserLookAndTellCell.h"
#import "JBoImageTextTool.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoUserDetailInfo.h"
#import "JBoCircleBgViewController.h"
#import "JBoImageBrowerViewController.h"
#import "JBoUserLookAndTellViewController.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoUserTableHeaderView.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoImageCacheTool.h"
#import "JBoNavigationViewController.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoUserInfoViewController.h"
#import "JBoLookAndTellCommentInfo.h"
#import "JBoLookAndTellCommentCell.h"
#import "JBoSubmitInputContentView.h"

@interface JBoLookAndTellDetailViewController ()<JBoUserTableHeaderViewDelegate,JBoUserLookAndTellCellDelegate,JBoSubmitInputContentViewDelegate,JBoLookAndTellCommentCellDelegate>

//内容高度
@property(nonatomic,assign) NSInteger contentHeight;

//计算评论高度
@property(nonatomic,retain) JBoImageTextLabel *caculateHeight;

//评论
@property(nonatomic,retain) JBoSubmitInputContentView *submitCommentView;
@property(nonatomic,retain) JBoLookAndTellCommentInfo *commentInfo;

@end

@implementation JBoLookAndTellDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"详情";
        self.contentHeight = NSNotFound;
        
        self.caculateHeight = [[[JBoImageTextLabel alloc] init] autorelease];
        self.caculateHeight.font = _lookAndTellCommentContentFont_;
        self.caculateHeight.textInset = _lookAndTellCommentContentTextInset_;
        self.caculateHeight.minLineHeight = _lookAndTellCommentContentMinLineHeight_;
        
        self.needLoadAllImage = YES;
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoLookAndTellDetailViewController dealloc");
    [_groupId release];
    [_msgId release];
    
    [_info release];
    
    [_caculateHeight release];
    [_submitCommentView release];
    
    [_commentInfo release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [self.appDelegate closeAlertView];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

#pragma mark-http代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
     self.isRequesting = NO;
    
    if([identifier isEqualToString:_removeLookAndTellIdentifier_])
    {
        [self alertNetworkMsg:@"删除失败"];
        return;
    }
    
    if([identifier isEqualToString:_stickLookAndTellIdentifier_])
    {
        [self alertNetworkMsg:@"请重试"];
        return;
    }
    
    if([identifier isEqualToString:_lookAndTellVisibleIdentifier_])
    {
        [self alertNetworkMsg:@"设置失败"];
        return;
    }
    
    if([identifier isEqualToString:_releaseLookAndTellCommentIdentifier_])
    {
        [self alertNetworkMsg:@"评论失败"];
        return;
    }
    
    if([identifier isEqualToString:_getLookAndTellByGroupIdIdentifier_] || [identifier isEqualToString:_getLookAndTellByMsgIdIdentifier_])
    {
        [self alertNetworkMsg:[NSString stringWithFormat:@"获取%@消息失败", _lookAndTellName_]];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getLookAndTellByMsgIdIdentifier_])
    {
        self.info = [JBoLookAndTellOperation getLookAndTellFromData:data];
        if(self.info)
        {
            if(!self.tableView)
            {
                [self loadInitView];
            }
            else
            {
                [self.tableView reloadData];
            }
        }
        else
        {
            [self alertNetworkMsg:[NSString stringWithFormat:@"获取%@消息失败", _lookAndTellName_]];
        }
        return;
    }
    
    if([identifier isEqualToString:_getLookAndTellByGroupIdIdentifier_])
    {
        NSArray *array = [JBoLookAndTellOperation getCircleLookAndTellInfoFromData:data multiInfo:[NSMutableDictionary dictionary] offlineCache:nil];
        if(array)
        {
            [self.infoArray addObjectsFromArray:array];
            self.info = [self.infoArray firstObject];
            if(!self.tableView)
            {
                [self loadInitView];
            }
            else
            {
                [self.tableView reloadData];
            }
        }
        else
        {
            [self alertNetworkMsg:[NSString stringWithFormat:@"获取%@消息失败", _lookAndTellName_]];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeLookAndTellIdentifier_])
    {
        [self alertMsg:@"删除成功"];
        
        if([self.delegate respondsToSelector:@selector(detailViewController:didDeletedInfo:)])
        {
            [self.delegate detailViewController:self didDeletedInfo:self.info];
        }
        
        [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
        
        return;
    }
    
    
    if([identifier isEqualToString:_stickLookAndTellIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            self.info.stick = !self.info.stick;
            [self alertMsg:@"置顶成功"];
            
            if([self.delegate respondsToSelector:@selector(detailViewController:didStickedInfo:)])
            {
                [self.delegate detailViewController:self didStickedInfo:self.info];
            }
        }
        else
        {
            [self alertMsg:@"置顶失败"];
        }
    }
    
    if([identifier isEqualToString:_lookAndTellVisibleIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoLookAndTellListInfo *info = self.info;
            if(info.visible == _lookAndTellVisiblePublic_)
            {
                info.visible = _lookAndTellVisiblePrivate_;
            }
            else
            {
                info.visible = _lookAndTellVisiblePublic_;
            }
            [self.tableView reloadData];
        }
        else
        {
            [self alertNetworkMsg:@"设置失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_releaseLookAndTellCommentIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [self alertMsg:@"评论成功"];
            [self.info.operationInfo.commentInfoArray insertObject:self.commentInfo atIndex:0];
            [self.tableView reloadData];
            [self.offlineCache insertCircleComment:self.commentInfo groupId:[self.info getGroupId]];
            self.commentInfo = nil;
        }
        else
        {
            [self alertNetworkMsg:@"评论失败"];
        }
        return;
    }
}

#pragma mark- super method

- (void)seeDetailLookAndTellWithIndexPath:(NSIndexPath *)indexPath
{
    [self comment];
}

#pragma mark-加载视图

- (void)back
{
    self.appDelegate.dataLoadingView.hidden = YES;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setBackItem:YES];
    
    if(self.info)
    {
        [self.infoArray addObject:self.info];
        [self loadInitView];
    }
    else
    {
        [self.httpRequest startDataLoading];
        self.isRequesting = YES;
        if(![NSString isEmpty:self.groupId])
        {
            self.httpRequest.identifier = _getLookAndTellByGroupIdIdentifier_;
            [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getLookAndtellFromGroupId:self.groupId]];
        }
        else
        {
            self.httpRequest.identifier = _getLookAndTellByMsgIdIdentifier_;
            [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getLookAndTellFromMsgId:self.msgId]];
        }
    }
}

- (void)loadInitView
{
    if(self.black)
    {
        [self setRightBarItemWithIcon:[UIImage imageNamed:@"helpComment_blackIcon"] action:@selector(comment)];
    }
    else
    {
        [self setRightBarItemWithIcon:[UIImage imageNamed:@"helpComment_icon@"] action:@selector(comment)];
    }
    
    
    JBoUserTableHeaderView *tableHeaderView = [[JBoUserTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tableHeaderViewHeight_)];
    
    tableHeaderView.delegate = self;
    tableHeaderView.bgImageView.userId = self.info.userID;
    tableHeaderView.nameLabel.text = self.info.userName;
    tableHeaderView.nameLabel.sex = self.info.sex;
    tableHeaderView.headImageView.role = self.info.role;
    tableHeaderView.headImageView.sex = self.info.sex;
    tableHeaderView.headImageView.headImageURL = self.info.headImageURL;
    
    //如果没有个人信息，隐藏头像
    if([NSString isEmpty:self.info.userName])
    {
        tableHeaderView.headImageView.hidden = YES;
        tableHeaderView.height -= tableHeaderView.nameLabel.height;
    }
  
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.tableHeaderView = tableHeaderView;
    tableView.backgroundColor = [UIColor clearColor];
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        tableView.separatorInset = UIEdgeInsetsZero;
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
    }
#endif
    [self.view addSubview:tableView];
    [tableHeaderView release];
    
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
}

#pragma mark-JBoSubmitCommentView代理

- (void)comment
{
    if(self.isRequesting)
        return;
    
    self.title = @"评论";
    
    if(!self.submitCommentView)
    {
        JBoSubmitInputContentView *submitCommentView = [[JBoSubmitInputContentView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) maxCommentCount:_inputFormatNewsComment_];
        submitCommentView.delegate = self;
        [self.view addSubview:submitCommentView];
        self.submitCommentView = submitCommentView;
        [submitCommentView release];
    }
    
    if(self.commentInfo)
    {
        self.submitCommentView.newsCommentTextView.text = self.commentInfo.comment;
    }
    
    [self.submitCommentView beginComment];
}

- (void)submitDidFinished:(NSString *)comment
{
    self.title = @"详情";
    if([comment stringByReplacingOccurrencesOfString:@" " withString:@""].length > 0)
    {
        self.httpRequest.identifier = _releaseLookAndTellCommentIdentifier_;
        self.isRequesting = YES;
        
        
        self.commentInfo = [[[JBoLookAndTellCommentInfo alloc] init] autorelease];
        self.commentInfo.comment = comment;
        self.commentInfo.userId = self.myInfo.rosterInfo.username;
        self.commentInfo.name = self.myInfo.rosterInfo.name;
        
        [self.httpRequest downloadWithURL:[JBoLookAndTellOperation releaseLookAndTellCommentURL] dic:[JBoLookAndTellOperation releaseLookAndTellCommentParaWithGroupId:[self.info getGroupId] content:comment]];
    }
    else
    {
        [self alertMsg:@"评论内容不能为空"];
    }
}

- (void)submitViewWillDismiss:(JBoSubmitInputContentView *)view
{
    self.title = @"详情";
}


#pragma mark-JBoLookAndTellTableHeaderView代理

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView headImageDidTapped:(JBoUserHeadImageView *)headImageView
{
    if(!self.groupId && [self.msgId longLongValue] == 0)
    {
        [self seeMyLookAndTellInfo];
    }
}

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView bgImageDidTapped:(UIView *)view
{
//    JBoCircleBgViewController *circleBgVC = [[JBoCircleBgViewController alloc] init];
//    [self.navigationController pushViewController:circleBgVC animated:YES];
//    [circleBgVC release];
}

- (void)seeMyLookAndTellInfo
{
    JBoLookAndTellListInfo *info = self.info;
    
    if([info.userID isEqualToString:[JBoUserOperation getUserId]])
    {
        JBoUserInfoViewController *userInfoVC = [[JBoUserInfoViewController alloc] init];
        userInfoVC.black = self.black;
        [self.navigationController pushViewController:userInfoVC animated:YES];
        [userInfoVC release];
    }
    else
    {
        JBoRosterInfo *rosterInfo = [self.appDelegate.rosterAndUsernameDic objectForKey:info.userID];
        if(rosterInfo)
        {
            JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
            detail.rosterInfo = rosterInfo;
            detail.black = self.black;
            [self.navigationController pushViewController:detail animated:YES];
            [detail release];
        }
        else
        {
            JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
            userInfo.userId = info.userID;
            userInfo.black = self.black;
            [self.navigationController pushViewController:userInfo animated:YES];
            [userInfo release];
        }
    }
}


#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    if(self.contentHeight == NSNotFound)
    {
        self.contentHeight = [info getContentHeightWithContraintWidth:_defaultMultiImageTextViewWidth_ - _defaultMultiImageTextInset_ * 2 showMultiImageText:YES];
    }
    
    CGFloat height = _innerPadding_ * 2 + self.contentHeight;
    
    height += [JBoMsgOperationView getHeightWithStyle:info.type canComplaint:YES needImageText:info.needImageText];
    
    height += [info getMsgOperationHeightWithCommentCount:info.operationInfo.commentInfoArray.count] + _msgOperationPadding_;
    
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    static NSString *defaultIdentifier = @"default";
    static NSString *shareLinkIdentifier = @"sharelink";
    static NSString *shortMovieIdentifier = @"shortMovie";
    
    NSString *cellIdentifier = defaultIdentifier;
    JBoLookAndTellCellStyle style = JBoLookAndTellCellStyleDefault;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cellIdentifier = shareLinkIdentifier;
            style = JBoLookAndTellCellStyleLinkShare;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cellIdentifier = shortMovieIdentifier;
            style = JBoLookAndTellCellStyleShortMovie;
        }
            break;
        default:
            break;
    }
    
    JBoUserLookAndTellCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoUserLookAndTellCell alloc] initWithCellStyle:style reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    cell.msgOperationView.showCommentCount = info.operationInfo.commentInfoArray.count;
    cell.msgOperationView.info = info;
    cell.msgOperationView.style = self.isSelf ? JBoMsgOperationUserOperation : info.type;
    cell.msgOperationView.index = indexPath.row;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cell.linkView.shareView.htmlTitleLabel.text = info.urlTitle;
            cell.linkView.shareURL = info.url;
            cell.linkView.srcArray = info.multiInfo;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cell.shareShortMovieView.srcArray = info.multiInfo;
        }
            break;
        default:
        {
            cell.multiImageTextView.hasMoreText = NO;
            cell.multiImageTextView.srcArray = info.multiInfo;
        }
            break;
    }
    
    cell.dateView.time = info.date;
    
    return cell;
}

#pragma mark- JBoLookAndTellCommentCell代理

- (void)lookAndTellCommentCellDidTapHeadImage:(JBoLookAndTellCommentCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    JBoLookAndTellCommentInfo *info = [self.info.operationInfo.commentInfoArray objectAtIndex:indexPath.row - self.infoArray.count];
    [self seeCommentUserInfoWithCommemtInfo:info];
}

#pragma mark-alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        self.httpRequest.identifier = _removeLookAndTellIdentifier_;
        
        JBoLookAndTellListInfo *info = self.info;
        self.isRequesting = YES;
        [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getRemoveLookAndTellWithGroupId:info.groupId]];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


@end
