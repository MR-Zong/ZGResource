//
//  JBoMultiImageTextInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMultiImageTextInfo.h"

@implementation JBoMultiImageText

- (id)init
{
    self = [super init];
    if(self)
    {
        self.titleHeight = NSNotFound;
        self.imageHeight = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_content release];
    [_imageURLArray release];
    
    
    [super dealloc];
}

@end

@implementation JBoMultiImageTextInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.contentHeight = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_multiInfo release];
    
    [_userID release];
    [_date release];
    
    [_url release];
    [_urlTitle release];
    
    [super dealloc];
}

@end
