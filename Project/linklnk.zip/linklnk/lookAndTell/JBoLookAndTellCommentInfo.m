//
//  JBoLookAndTellCommentInfo.m
//  靓咖
//
//  Created by kinghe005 on 14-7-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellCommentInfo.h"

@implementation JBoLookAndTellCommentInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.commentHeight =  NSNotFound;
        self.commentBottmHeight = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_userId release];
    [_name release];
    [_comment release];
    [_time release];
    
    [super dealloc];
}

@end
