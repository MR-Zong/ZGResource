//
//  JBoLookAndTellTypeSelectedViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellTypeSelectedViewController.h"
#import "JBoSceneMakingHomeViewController.h"
#import "JBoCustomTabBarController.h"
#import "JBoImageCacheTool.h"
#import "JBoHttpRequest.h"
#import "JBoLookAndTellTypeSelectedCell.h"
#import "SWRevealViewController.h"
#import "JBoImageTextTool.h"
#import "JBoSceneMakingOperation.h"
#import "JBoUserOperation.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoCustomInsetLabel.h"
#import "JBoSceneMakingImageInfo.h"

@interface JBoLookAndTellTypeSelectedViewController ()<JBoHttpRequestDelegate,UIAlertViewDelegate>
{
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,retain) UITableView *tableView;

/**数组元素是 场景信息分类标题 NSString
 */
@property(nonatomic,retain) NSMutableArray *infoArray;

/**key 是场景信息分类标题 NSString，value 是 NSArray, 数组元素是  JBoSceneMakingImageInfo
 */
@property(nonatomic,retain) NSMutableDictionary *infoDic;

/**选中的场景信息
 */
@property(nonatomic,retain) JBoSceneMakingImageInfo *selectedSceneImageInfo;

@end

@implementation JBoLookAndTellTypeSelectedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"目的场景";
    }
    return self;
}

#pragma mark-内存管理
- (void)dealloc
{
    [_httpRequest release];
    
    [_tableView release];
    [_infoArray release];
    [_infoDic release];
    
    [_selectedSceneImageInfo release];
 
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UINavigationController *selfNav = self.navigationController;
    selfNav.view.frame = CGRectMake(_width_ - _revealWidth_, selfNav.view.frame.origin.y, _revealWidth_, selfNav.view.frame.size.height);
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.appDelegate.dataLoadingView.hidden = YES;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取场景失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.appDelegate.dataLoadingView.hidden = YES;
    
    NSMutableArray *infoArray = [[NSMutableArray alloc] init];
    NSMutableDictionary *infoDic = [[NSMutableDictionary alloc] init];
    
    [JBoSceneMakingOperation getSceneMakingImageFromData:data infoArray:infoArray infoDic:infoDic notDisplayInfoDic:nil cache:YES topSceneImageInfo:nil];
    
    if(infoArray.count > 0)
    {
        [self.infoArray addObjectsFromArray:infoArray];
        [self.infoDic addEntriesFromDictionary:infoDic];
        
        if(!_tableView)
        {
            [self loadInitView];
        }
    }
    else
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"获取场景失败"];
    }
    
    [infoArray release];
    [infoDic release];
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    
//    if(self.black)
//    {
//        [JBoNavigatioinBarOperation setBlackBackItemWithTarget:self action:@selector(back)];
//    }
//    else
//    {
//        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
//    }
    
    //获取场景
    JBoCustomTabBarController *tabBar = (JBoCustomTabBarController*)self.appDelegate.window.rootViewController;
    JBoSceneMakingHomeViewController *homeVC = nil;
    UINavigationController *nav = [tabBar.navigationControllers objectAtIndex:tabBar.homeIndex];
    
    for(UIViewController *VC in nav.viewControllers)
    {
        if([VC isKindOfClass:[JBoSceneMakingHomeViewController class]])
        {
            homeVC = (JBoSceneMakingHomeViewController*)VC;
            break;
        }
    }
    
    self.infoArray = homeVC.sceneMakingView.infoArray;
    self.infoDic = homeVC.sceneMakingView.infoDic;
    
    if(self.infoArray.count > 0)
    {
        [self loadInitView];
    }
    else
    {
        self.appDelegate.dataLoadingView.hidden = NO;
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
        self.infoDic = [[[NSMutableDictionary alloc] init] autorelease];
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        [_httpRequest downloadWithURL:[JBoSceneMakingOperation getSceneMakingImage]];
    }
    
//    [self.view addGestureRecognizer:reveal.panGestureRecognizer];
//    [_tableView.panGestureRecognizer requireGestureRecognizerToFail:reveal.panGestureRecognizer];
}

- (void)loadInitView
{
    //清除没有场景信息的分类
    for(NSInteger i = 0;i < self.infoArray.count;i ++)
    {
        NSString *key = [self.infoArray objectAtIndex:i];
        NSArray *array = [self.infoDic objectForKey:key];
        
        if(array.count == 0)
        {
            [self.infoDic removeObjectForKey:key];
            [self.infoArray removeObjectAtIndex:i];
            i --;
        }
    }
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _revealWidth_, _height_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = [UIColor clearColor];
    tableView.rowHeight = _lookAndTellTypeSelectedCellHeight_;
    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _revealWidth_, _statuBarHeight_ + _navgateBarHeight_)];
    footerView.backgroundColor = [UIColor clearColor];
    tableView.tableFooterView = footerView;
    [footerView release];
    
    [self.view addSubview:tableView];
    
    self.tableView = tableView;
    [tableView release];
}


#pragma mark-tableView代理

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return _sectionHeaderHeight_;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _infoArray.count;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = nil;
    NSString *title = [_infoArray objectAtIndex:section];
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"header";
        UITableViewHeaderFooterView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
            UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, header.bounds.size.width, _sectionHeaderHeight_)];
            bgView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.8];
            header.backgroundView = bgView;
            [bgView release];
        }
        header.textLabel.text = title;
        view = header;
#endif
    }
    else
    {
        JBoCustomInsetLabel *label = [[[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, _sectionHeaderHeight_)] autorelease];
        label.insets = UIEdgeInsetsMake(0, 10.0, 0, 0);
        label.textColor = [UIColor blackColor];
        label.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.8];
        label.text = title;
        view = label;
    }

    return view;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *title = [_infoArray objectAtIndex:section];
   
    NSArray *array = [_infoDic objectForKey:title];
    return array.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoLookAndTellTypeSelectedCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoLookAndTellTypeSelectedCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    
    NSString *title = [_infoArray objectAtIndex:indexPath.section];
    NSArray *array = [_infoDic objectForKey:title];
    
    JBoSceneMakingImageInfo *info = [array objectAtIndex:indexPath.row];
    
    cell.titleLabel.text = info.title;
    
    [cell.iconImageView getImageWithURL:info.imageURL];
  
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSString *title = [_infoArray objectAtIndex:indexPath.section];
    NSArray *array = [_infoDic objectForKey:title];
    
    JBoSceneMakingImageInfo *info = [array objectAtIndex:indexPath.row];
    
    if(info.sceneRole != _sceneRoleGeneral_)
    {
        JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getUserDetailInfo];
        switch (info.sceneRole)
        {
            case _sceneRoleEnterprise_:
            {
                if(userDetailInfo.rosterInfo.role != _rosterRoleEnterprise_)
                {
                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"该场景%@", realNameAuthenTitle] message:realNameAuthenMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", goToRealNameAuthen, nil];
                    [alertView show];
                    [alertView release];
                    [_tableView reloadData];
                    return;
                }
            }
                break;
            case _sceneRoleEnterpriesDisable_:
            {
                if(userDetailInfo.rosterInfo.role == _rosterRoleEnterprise_)
                {
                    [JBoUserOperation alertMsg:[NSString stringWithFormat:@"%@无法使用该场景", _rosterGodenUser_]];
                    [_tableView reloadData];
                    return;
                }
            }
                break;
            default:
                break;
        }
        
    }
    
    if(info.sceneSexId != _sceneSexGeneral_)
    {
        if(info.sceneSexId != [JBoUserOperation getSexId])
        {
            [JBoUserOperation alertMsg:@"该场景与您的性别不相符"];
            [_tableView reloadData];
            return;
        }
    }
    
    if([self.delegate respondsToSelector:@selector(lookAndTellTypeSelectedViewController:didFinishWithInfo:)])
    {
        [self.delegate lookAndTellTypeSelectedViewController:self didFinishWithInfo:info];
    }

    SWRevealViewController *reveal = [self revealVC];
    [reveal setFrontViewPosition:FrontViewPositionLeft animated:YES];
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        JBoRealNameAuthenViewController *realNameAuthenVC = [[JBoRealNameAuthenViewController alloc] init];
        realNameAuthenVC.black = YES;
        SWRevealViewController *reveal = [self revealVC];
        [reveal setFrontViewPosition:FrontViewPositionLeft animated:NO];
        
        UINavigationController *nav = (UINavigationController*)reveal.frontViewController;
        if(![reveal.frontViewController isKindOfClass:[UINavigationController class]])
        {
            nav = reveal.frontViewController.navigationController;
        }
        
        [nav pushViewController:realNameAuthenVC animated:YES];
        [realNameAuthenVC release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
