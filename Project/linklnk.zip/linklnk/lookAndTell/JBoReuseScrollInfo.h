//
//  JBoLookAndTellBigInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoReuseScrollViewCell.h"

/**图片预览大图时的信息
 */
@interface JBoReuseScrollInfo : NSObject

/**图片
 */
@property(nonatomic,retain) UIImage *image;

/**信息Id
 */
@property(nonatomic,assign) long long msgId;

/**文本内容
 */
@property(nonatomic,retain) NSString *title;

/**图片路径
 */
@property(nonatomic,retain) NSString *url;

/**内容高度
 */
@property(nonatomic,assign) CGFloat titleHeight;

/**获取文本内容高度
 */
+ (CGFloat)getHeightWithContent:(NSString*) content;

@end
