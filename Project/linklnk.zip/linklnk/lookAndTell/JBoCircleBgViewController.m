//
//  JBoCircleBgViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoCircleBgViewController.h"
#import "JBoBasic.h"
#import "JBoCircleBgImageCell.h"
#import "JBoLookAndTellOperation.h"
#import "JBoHttpRequest.h"
#import "JBoAppDelegate.h"
#import "JBoUserOperation.h"
#import "JBoLookAndTellBgImageInfo.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoCustomInsetLabel.h"

#define _controlInterval_ 5

@interface JBoCircleBgViewController ()<JBoHttpRequestDelegate,UIActionSheetDelegate>
{
    JBoHttpRequest *_httpRequest;
    
    JBoAppDelegate *_appDelegate;
}

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) NSIndexPath *currentIndexPath;

@property(nonatomic,retain)  UITableView *tableView;

@end

@implementation JBoCircleBgViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"靓背景";
        _sectionArray = [[NSMutableArray alloc] init];
        _imageDic = [[NSMutableDictionary alloc] init];
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        self.black = YES;
        
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_sectionArray release];
    [_imageDic release];
    
    [_tableView release];
    
    [_httpRequest release];
    
    [_currentIndexPath release];
    [super dealloc];
}

#pragma mark-视图出现消失
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   // self.navigationController.navigationBar.translucent = YES;
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getAllLookAndTellIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"获取靓背景失败"];
        return;
    }
    
    if([identifier isEqualToString:_setupUserLookAndTellIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"设置靓背景失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getAllLookAndTellIdentifier_])
    {
        
        [JBoLookAndTellOperation getAllLookAndTellFromData:data withTitleArray:_sectionArray infoDic:_imageDic];
        if(_sectionArray.count > 0)
        {
            [self loadInitView];
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"获取靓背景失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_setupUserLookAndTellIdentifier_])
    {
        BOOL sucess = [JBoUserOperation isSuccess:data];
        if(sucess)
        {
            NSString *title = [_sectionArray objectAtIndex:self.currentIndexPath.section];
            NSArray *array = [_imageDic objectForKey:title];
            JBoLookAndTellBgImageInfo *info = [array objectAtIndex:self.currentIndexPath.row];
            
            JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
            UIImage *image = [cache imageForURL:info.imageURL thumbnailSize:CGSizeMake(_width_, _circleBgImageCellHeight_ - _controlInterval_ * 2)];
            
            if(!image)
            {
                [cache getImageWithURL:info.imageURL thumbnailSize:CGSizeMake(_width_, _circleBgImageCellHeight_ - _controlInterval_ * 2) useCache:YES completion:^(UIImage *image){
                    
                    if(image)
                    {
                        [[NSNotificationCenter defaultCenter] postNotificationName:_circleBgImageSelectedNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:image forKey:_circleBgImageName_]];
                    }
                    
                    [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
                }];
            }
            else
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:_circleBgImageSelectedNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:image forKey:_circleBgImageName_]];
                
                [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
            }
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"设置靓背景失败"];
        }
        return;
    }
}

#pragma mark-加载视图

- (void)cancelAction:(id)sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.backItem = YES;
    
	_httpRequest.identifier = _getAllLookAndTellIdentifier_;
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation getALlLookAndTellBgImage]];
}

- (void)loadInitView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
}

#pragma mark-tableview代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *title = [_sectionArray objectAtIndex:section];
    NSArray *array = [_imageDic objectForKey:title];
    
    return array.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _sectionArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return _circleBgImageCellHeight_;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return _circleBgImageHeaderHeight_;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSString *title = [_sectionArray objectAtIndex:section];
    UIView *view = nil;
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"header";
        UITableViewHeaderFooterView *header = [tableView dequeueReusableCellWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.textLabel.text = title;
        view = header;
#endif
    }
    else
    {
        JBoCustomInsetLabel *label = [[[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, 0, _width_, _circleBgImageHeaderHeight_)] autorelease];
        label.insets = UIEdgeInsetsMake(0, 10.0, 0, 0);
        label.backgroundColor = [UIColor colorWithWhite:0.8 alpha:1.0];
        label.textColor = [UIColor blackColor];
        label.text = title;
        view = label;
    }
    return view;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoCircleBgImageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoCircleBgImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSString *title = [_sectionArray objectAtIndex:indexPath.section];
    NSArray *array = [_imageDic objectForKey:title];
    JBoLookAndTellBgImageInfo *info = [array objectAtIndex:indexPath.row];
    [cell.bgImageView getImageWithURL:info.imageURL];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoCircleBgImageCell *cell = (JBoCircleBgImageCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    if(!cell.bgImageView.image)
    {
        return;
    }
    
    self.currentIndexPath = indexPath;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"替换靓背景" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"更换背景", nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        NSString *title = [_sectionArray objectAtIndex:self.currentIndexPath.section];
        NSArray *array = [_imageDic objectForKey:title];
        JBoLookAndTellBgImageInfo *info = [array objectAtIndex:self.currentIndexPath.row];
        
        _httpRequest.identifier = _setupUserLookAndTellIdentifier_;
        [_httpRequest startDataLoading];
        if([_httpRequest downloadWithURL:[JBoLookAndTellOperation setupUserLookAndTellBgImageWithUrl:info.ID]])
        {
            self.isRequesting = YES;
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
