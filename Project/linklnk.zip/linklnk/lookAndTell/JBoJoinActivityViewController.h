//
//  JBoJoinActivityViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoReleaseLookAndTellTableHeaderView.h"

typedef NS_ENUM(NSInteger, JBoJoinType)
{
    JBoJoinTypeLays = 0,
    JBoJoinTypeActivity = 1
};

@interface JBoJoinActivityViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
}

@property(nonatomic,assign) JBoReleaseLookAndTellType joinType;
@property(nonatomic,copy) NSString *userId;
@property(nonatomic,copy) NSString *groupId;

@property(nonatomic,assign) BOOL black;

@end
