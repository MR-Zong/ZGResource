//
//  JBoReleaseLookAndTellViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoReleaseLookAndTellViewController.h"
#import "JBoMoreViewController.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoCircleLookAndTellViewController.h"
#import "JBoSceneMakingOperation.h"
#import "JBoShortMovieReleaseView.h"
#import "JBoMsgSingleImageTextView.h"
#import "JBoMsgMultiImageTextView.h"
#import "JBoCustomFilterBar.h"
#import "JBoOfflineCacheOperation.h"
#import "JBoSceneMakingImageInfo.h"
#import "JBoStraightlineProgressView.h"


@interface JBoReleaseLookAndTellViewController ()<JBoHttpRequestDelegate,JBoCustomFilterBarDelegate,JBoLookAndTellReleaseBaseViewDelegate>

//滚动视图，防止键盘挡住输入框
@property(nonatomic,retain) UIScrollView *scrollView;

//视频 图文 场景图文
@property(nonatomic,retain) JBoShortMovieReleaseView *shortMovieReleaseView;
@property(nonatomic,retain) JBoMsgSingleImageTextView *msgSingleView;
@property(nonatomic,retain) JBoMsgMultiImageTextView *msgMultiView;

//说说类型选择
@property(nonatomic,retain) JBoCustomFilterBar *filterBar;

//上传进度
@property(nonatomic,retain) JBoStraightlineProgressView *progressView;

@end

@implementation JBoReleaseLookAndTellViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.style = JBoReleaseLookAndTellStyleNormal;
        self.black = YES;
    }
    return self;
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    self.navigationController.navigationBar.translucent = NO;
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
    [self.msgMultiView viewWillDisAppear];
}


#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoReleaseLookAndTellViewController dealloc");
    
    [_offlineCache release];
    [_sceneInfo release];
    [_addr release];
    
    [_scrollView release];
    [_shortMovieReleaseView release];
    [_msgSingleView release];
    [_msgMultiView release];
    
    [_filterBar release];
 
    [_progressView release];
    
    [super dealloc];
}


#pragma mark-加载视图

- (void)back
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    //[self.navigationController popViewControllerAnimated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)popToCircleController
{
    NSMutableArray *viewControllers = [[NSMutableArray alloc] initWithCapacity:2];
    for(UIViewController *VC in self.navigationController.viewControllers)
    {
        if([VC isKindOfClass:[JBoMoreViewController class]])
        {
            [viewControllers addObject:VC];
            break;
        }
    }
    
    JBoCircleLookAndTellViewController *circle = [[JBoCircleLookAndTellViewController alloc] init];
    [viewControllers addObject:circle];
    [self.navigationController setViewControllers:viewControllers animated:YES];
    [circle release];
    [viewControllers release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation
{
    return YES;
}

#ifdef __IPHONE_6_0

- (BOOL)shouldAutorotate
{
    return NO ;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationPortrait;
}

#endif


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(releaseAction:) title:@"发布" backgroundImage:nil textColor:[UIColor blackColor]];

    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    [self loadInitView];
}

- (void)loadInitView
{
    CGRect frame = CGRectMake(0, _defaultFilterBarHeight_, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _defaultFilterBarHeight_);
    
    self.filterBar = [[[JBoCustomFilterBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _defaultFilterBarHeight_) titles:[NSArray arrayWithObjects:@"一语双关", @"视频", @"图文", nil] icons:nil] autorelease];
    self.filterBar.titleFont = [UIFont systemFontOfSize:14.0];
    self.filterBar.delegate = self;
    self.filterBar.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.filterBar];
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:frame];
    scrollView.backgroundColor = [UIColor clearColor];
    scrollView.delegate = self;
    [self.view addSubview:scrollView];
    self.scrollView = scrollView;
    [scrollView release];
    
    [self createMsgMultiView];
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
    }
#endif
    
}

#pragma mark- private method

//发布
- (void)releaseAction:(id) sender
{
    BOOL enable = YES;
    switch (self.filterBar.selectedIndex)
    {
        case 0 :
           enable = [self.msgMultiView finish];
            break;
        case 1 :
            enable = [self.shortMovieReleaseView finish];
            break;
        case 2 :
           enable = [self.msgSingleView finish];
            break;
        default:
            break;
    }
    self.filterBar.userInteractionEnabled = !enable;
}

#pragma mark- JBoLookAndTellReleaseBaseView delegate

- (void)lookAndTellReleaseBaseView:(JBoLookAndTellReleaseBaseView *)releaseView didFinishedWithInfo:(JBoLookAndTellListInfo *)info
{
    self.filterBar.userInteractionEnabled = YES;
    
    if(info)
    {
        if([self.delegate respondsToSelector:@selector(releaseLookAndTell:didFinished:)])
        {
            [self.delegate releaseLookAndTell:self didFinished:info];
        }
        else
        {
            [self back];
        }
    }
}

- (void)lookAndTellReleaseBaseView:(JBoLookAndTellReleaseBaseView *)releaseView updateUploadProgress:(float)progress
{
    if(!self.progressView)
    {
        CGFloat height = 3.0;
        JBoStraightlineProgressView *view = [[JBoStraightlineProgressView alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
        [self.view addSubview:view];
        self.progressView = view;
        [view release];
    }
    if(progress < 0)
    {
        self.progressView.hidden = YES;
        self.progressView.progress = 0;
    }
    else
    {
        [self.view bringSubviewToFront:self.progressView];
        self.progressView.hidden = NO;
        self.progressView.progress = progress;
    }
}

#pragma mark-JBoCustomFilterBar代理

- (void)filterBar:(JBoCustomFilterBar *)filterBar didSelectedAtIndex:(NSInteger)index
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    switch (index)
    {
        case 0 :
        {
            [self createMsgMultiView];
            self.msgMultiView.hidden = NO;
            self.msgSingleView.hidden = YES;
            self.shortMovieReleaseView.hidden = YES;
            self.scrollView.contentSize = self.msgMultiView.bounds.size;
        }
            break;
        case 1 :
        {
            [self createShortMovieView];
            self.shortMovieReleaseView.hidden = NO;
            self.msgSingleView.hidden = YES;
            self.msgMultiView.hidden = YES;
            self.scrollView.contentSize = self.shortMovieReleaseView.bounds.size;
        }
            break;
        case 2 :
        {
            [self createSingleView];
            self.msgSingleView.hidden = NO;
            self.msgMultiView.hidden = YES;
            self.shortMovieReleaseView.hidden = YES;
            self.scrollView.contentSize = self.msgSingleView.bounds.size;
        }
            break;
        default :
            break;
    }
}

//普通图文
- (void)createSingleView
{
    if(!self.msgSingleView)
    {
        self.msgSingleView = [[[JBoMsgSingleImageTextView alloc] initWithFrame:CGRectMake(0, 0, _width_, self.scrollView.bounds.size.height)] autorelease];
        self.msgSingleView.navigationController = self.navigationController;
        self.msgSingleView.delegate = self;
        self.msgSingleView.scrollView = self.scrollView;
        [self.scrollView addSubview:self.msgSingleView];
    }
}

//一语双关
- (void)createMsgMultiView
{
    if(!self.msgMultiView)
    {
        self.msgMultiView = [[[JBoMsgMultiImageTextView alloc] initWithFrame:CGRectMake(0, 0, _width_, self.scrollView.bounds.size.height)] autorelease];
        self.msgMultiView.navigationController = self.navigationController;
        self.msgMultiView.delegate = self;
        self.msgMultiView.scrollView = self.scrollView;
        [self.scrollView addSubview:self.msgMultiView];
        self.scrollView.contentSize = self.msgMultiView.bounds.size;
        
        switch (self.style)
        {
            case JBoReleaseLookAndTellStyleNormal :
            {
                SWRevealViewController *revealVC = [self revealVC];
                UINavigationController *nav = (UINavigationController*)revealVC.rightViewController;
                JBoLookAndTellTypeSelectedViewController *selectedVC = (JBoLookAndTellTypeSelectedViewController*)[nav.viewControllers firstObject];
                selectedVC.delegate = self.msgMultiView;
                
                revealVC.delegate = self.msgMultiView;
                self.msgMultiView.revealVC = revealVC;
                [self.msgMultiView addGestureRecognizer:revealVC.panGestureRecognizer];
                [self.scrollView.panGestureRecognizer requireGestureRecognizerToFail:revealVC.panGestureRecognizer];
            }
                break;
            case JBoReleaseLookAndTellStyleScene:
            {
                if(self.addr)
                {
                    [self.msgMultiView setAddr:self.addr coordinate:self.coordinate];
                }
                
                if(self.sceneInfo)
                {
                    [self.msgMultiView setSceneInfo:self.sceneInfo];
                }
            }
                break;
            default:
                break;
        }
    }
}

//短视频
- (void)createShortMovieView
{
    if(!self.shortMovieReleaseView)
    {
        self.shortMovieReleaseView = [[[JBoShortMovieReleaseView alloc] initWithFrame:CGRectMake(0, 0, _width_, self.scrollView.bounds.size.height)] autorelease];
        self.shortMovieReleaseView.navigationController = self.navigationController;
        self.shortMovieReleaseView.delegate = self;
        self.shortMovieReleaseView.scrollView = self.scrollView;
        self.shortMovieReleaseView.shortMovieView.viewController = self;
        [self.scrollView addSubview:self.shortMovieReleaseView];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
