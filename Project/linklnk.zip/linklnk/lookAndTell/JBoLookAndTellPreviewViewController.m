//
//  JBoLookAndTellPreviewViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellPreviewViewController.h"
#import "JBoLookAndTellPreviewView.h"
#import "JBoAppDelegate.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoLookAndTellPreviewHeader.h"
#import "JBoSceneMakingInfo.h"

@interface JBoLookAndTellPreviewViewController ()

@property(nonatomic,retain) JBoLookAndTellPreviewView *preview;

@property(nonatomic,retain) JBoLookAndTellListInfo *info;

/**匹配信息
 */
@property(nonatomic,retain) JBoSceneMakingInfo *sceneInfo;

@end

@implementation JBoLookAndTellPreviewViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
    }
    return self;
}

- (id)initWithLookAndTell:(JBoLookAndTellListInfo *)lookAndTell sceneMakingInfo:(JBoSceneMakingInfo *)info
{
    self = [super initWithNibName:nil bundle:nil];
    if(self)
    {
         self.title = @"预览";
        self.info = lookAndTell;
        self.sceneInfo = info;
    }
    
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_info release];
    [_preview release];
    [_sceneInfo release];
    
    [super dealloc];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.preview reloadData];
}

#pragma mark- 加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [JBoNavigatioinBarOperation setBlackBackItemWithTarget:self action:@selector(back)];
    
    JBoLookAndTellPreviewView *view = [[JBoLookAndTellPreviewView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) lookAndTellInfo:self.info];
    view.navigationController = self.navigationController;
    
    
    JBoLookAndTellPreviewHeader *header = [[JBoLookAndTellPreviewHeader alloc] initWithFrame:CGRectMake(0, 0, _width_, 0) info:self.sceneInfo];
    header.navigationController = self.navigationController;
    view.tableView.tableHeaderView = header;
    [header release];
    
    [self.view addSubview:view];
    self.preview = view;
    [view release];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
