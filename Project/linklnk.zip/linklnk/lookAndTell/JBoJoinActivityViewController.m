//
//  JBoJoinActivityViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

//
//  JBoReleaseLookAndTellViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoJoinActivityViewController.h"
#import "SSTextView.h"
#import "JBoAppDelegate.h"

#import "JBoLookAndTellOperation.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoHttpRequest.h"
#import "JBoImageOperationView.h"
#import "JBoImageOperationPreviewedViewController.h"
#import "JBoFileManager.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoImageTextTool.h"
#import "JBoRosterListViewController.h"
#import "JBoChatOperation.h"
#import "UITableView+extraCellLine.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoImageBrowerViewController.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoUserDetailInfo.h"
#import "JBoMoreViewController.h"
#import "JBoCircleLookAndTellViewController.h"
#import "JBoImageCacheTool.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoStraightlineProgressView.h"


#define _padding_ 10
#define _imageSize_ 100

#define _deleteActionSheetTag_ 100

@interface JBoJoinActivityViewController ()<JBoHttpRequestDelegate,UIActionSheetDelegate>
{
    JBoAppDelegate *_appDelegate;
    
    JBoReleaseLookAndTellTableHeaderView *_tableHeaderView;
}

@property(nonatomic,assign) BOOL isRequesting;

@property(nonatomic,retain) JBoLookAndTellListInfo *info;
@property(nonatomic,retain) NSMutableArray *imageNameArray;

@property(nonatomic,retain) NSMutableArray *imageURLArray;
@property(nonatomic,retain) ASINetworkQueue *httpQueue;

@property(nonatomic,assign) BOOL success;
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

//上传进度条
@property(nonatomic,retain) JBoStraightlineProgressView *progressView;

@end

@implementation JBoJoinActivityViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        self.isRequesting = NO;
        
        JBoLookAndTellListInfo *info = [[JBoLookAndTellListInfo alloc] init];
        self.info = info;
        [info release];
        
        self.joinType = JBoReleaseLookAndTellTypeDefault;
        self.imageNameArray = [[[NSMutableArray alloc] init] autorelease];
        
        self.black = YES;
    }
    return self;
}

#pragma mark-通知

- (void)setIsRequesting:(BOOL)isRequesting
{
    _isRequesting = isRequesting;
    _appDelegate.dataLoadingView.hidden = !_isRequesting;
    self.navigationItem.rightBarButtonItem.enabled = !_isRequesting;
    self.view.userInteractionEnabled = !_isRequesting;
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];

    if(self.black)
    {
        //返回
        [JBoNavigatioinBarOperation setBlackBackItemWithTarget:self action:@selector(backAction:)];
    }
    else
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(backAction:)];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_appDelegate closeAlertView];
}


#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoJoinActivityViewController dealloc");
    
    [_tableView release];
    
    [_userId release];
    [_groupId release];
    
    [_tableHeaderView release];
    
    [_info release];
    [_imageNameArray release];
    
    [_imageURLArray release];
    
    [_httpQueue cancelAllOperations];
    [_httpQueue release];
    [_httpRequest release];
    [_userDetailInfo release];
    
    [_progressView release];
    
    [super dealloc];
}

#pragma mark-http代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.progressView.hidden = YES;
    if([identifier isEqualToString:_releaseLookAndTellIdntifier_])
    {
        self.isRequesting = NO;
        self.success = NO;
//        NSString *alertMsg = nil;
//        switch (self.joinType)
//        {
//            case JBoJoinTypeActivity :
//                alertMsg = @"网络不给力,申请活动失败";
//                break;
//            case JBoJoinTypeLays :
//                alertMsg = @"网络不给力,申请代言失败";
//                break;
//            default:
//                break;
//        }
        [JBoUserOperation alertmsgWithBadNetwork:@"申请活动失败"];
        [JBoFileManager deleteFiles:self.imageNameArray];
        return;
    }
    
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        self.isRequesting = NO;
        [self sendSuccess:NO];
        return;
    }

    
    if([identifier isEqualToString:_laysReviewIdentifier_])
    {
        self.isRequesting = NO;
        [JBoUserOperation alertmsgWithBadNetwork:@"申请代言失败"];
        return;
    }
    
    if([identifier isEqualToString:_activityReviewIdentifier_])
    {
        self.isRequesting = NO;
        [JBoUserOperation alertmsgWithBadNetwork:@"申请活动失败"];
        return;
    }

}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    //self.isRequesting = NO;
    if([identifier isEqualToString:_releaseLookAndTellIdntifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            self.success = YES;
        }
        else
        {
            self.success = NO;
        }
        return;
    }
    
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        self.isRequesting = NO;
        [self releaseData:data];
        return;
    }
    
    if([identifier isEqualToString:_laysReviewIdentifier_])
    {
        self.isRequesting = NO;
        [JBoUserOperation alertMsg:@"申请成功,请耐心等待对方回复"];
        
        JBoChatOperation *chat = [[JBoChatOperation alloc] init];
        JBoMultiImageText *text = [self.info.multiInfo firstObject];
        
        [chat sendLaysMsgWithMsgId:[NSString stringWithFormat:@"%lld",text.msgId] imageURL:[text.imageURLArray firstObject] msg:text.content targetJid:self.userDetailInfo.rosterInfo.jid type:_sendMsgActivityTypeLays_ groupId:self.groupId];
        [chat release];
        [self sendSuccess:YES];
        return;
    }
    
    if([identifier isEqualToString:_activityReviewIdentifier_])
    {
        self.isRequesting = NO;
        [JBoUserOperation alertMsg:@"申请成功,请耐心等待对方回复"];
        
        JBoChatOperation *chat = [[JBoChatOperation alloc] init];
        JBoMultiImageText *text = [self.info.multiInfo firstObject];
        
        [chat sendLaysMsgWithMsgId:[NSString stringWithFormat:@"%lld",text.msgId] imageURL:[text.imageURLArray firstObject] msg:text.content targetJid:self.userDetailInfo.rosterInfo.jid type:_sendMsgActivityTypeNormal_ groupId:self.groupId];
        [chat release];
        [self sendSuccess:YES];
        return;
    }
}


//设置 queue
- (ASINetworkQueue*)queue
{
    if(!self.httpQueue)
    {
        self.httpQueue = [ASINetworkQueue queue];
        [self.httpQueue setDelegate:self];
        [self.httpQueue setQueueDidFinishSelector:@selector(httpQuqueDidFinish:)];
        [self.httpQueue setRequestDidFailSelector:@selector(requestDidFail:)];
        [self.httpQueue setDelegate:self];
        [self.httpQueue setShowAccurateProgress:YES];
        [self.httpQueue setQueueDidUpdateProgerssSelector:@selector(httpQueueDidUpdateProgress:)];
    }
    return self.httpQueue;
}

- (void)requestDidFail:(ASIHTTPRequest*) request
{
    NSLog(@"失败");
    self.success = NO;
}

- (void)httpQuqueDidFinish:(ASINetworkQueue*) queue
{
    //[JBoUserOperation alertMsg:@"发布成功"];
    [self.httpQueue reset];
    self.httpQueue = nil;
    
    if(self.success)
    {
        self.isRequesting = YES;
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self identifier:_getUserLookAndTellIdentifier_] autorelease];
        [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getLookAndtellFromGroupId:self.info.groupId]];
    }
    else
    {
        self.progressView.hidden = YES;
        self.isRequesting = NO;
        [JBoUserOperation alertmsgWithBadNetwork:@"发送失败"];
    }
}

- (void)httpQueueDidUpdateProgress:(ASINetworkQueue*) queue
{
    if(!self.progressView)
    {
        CGFloat height = 3.0;
        JBoStraightlineProgressView *view = [[JBoStraightlineProgressView alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
        [self.view addSubview:view];
        self.progressView = view;
        [view release];
    }
    
    [self.view bringSubviewToFront:self.progressView];
    self.progressView.hidden = NO;
    self.progressView.progress = ((double)queue.bytesUploadedSoFar / (double)queue.totalBytesToUpload) * 0.95;
}

//解析
- (void)releaseData:(NSData*) data
{
    NSArray *array = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:[NSMutableDictionary dictionary] offlineCache:nil];
    NSLog(@"%@",array);
    
    if(array.count > 0)
    {
        JBoLookAndTellListInfo *info = [array firstObject];
        JBoMultiImageText *text = [info.multiInfo firstObject];
        
        JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
        
        NSMutableArray *urls = [NSMutableArray array];
        for(NSInteger i = 0; i < info.multiInfo.count; i ++)
        {
            JBoMultiImageText *text = [info.multiInfo objectAtIndex:i];
            [urls addObjectsFromArray:text.imageURLArray];
        }
        
        [JBoFileManager moveFiles:self.imageURLArray withURLs:urls suffix:cache.imageSuffix toPath:cache.normalCachePath];
        [JBoFileManager deleteFiles:self.imageNameArray];
        
        self.info = info;
        self.isRequesting = YES;
//        switch (self.joinType)
//        {
//            case JBoReleaseLookAndTellTypeLays :
//            {
//                self.httpRequest.identifier = _laysReviewIdentifier_;
//                [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getLaysReviewWithTargetId:self.userDetailInfo.rosterInfo.username msgId:info.messageID state:_laysReviewStateWaite_ groupId:self.groupId]];
//            }
//                break;
//                case JBoReleaseLookAndTellTypeActivity :
//            {
//              //  NSLog(@"%@--%@",self.userDetailInfo, self.userDetailInfo.rosterInfo.username);
//              
//            }
//            default:
//                break;
//        }
        self.httpRequest.identifier = _activityReviewIdentifier_;
        [self.httpRequest downloadWithURL:[JBoLookAndTellOperation joinActivityWithUserId:self.userDetailInfo.rosterInfo.username msgId:[NSString stringWithFormat:@"%lld", text.msgId] groupId:self.groupId state:_activityActorStateWaite_]];
        
    }
    else
    {
        self.isRequesting = NO;
//        NSString *alertMsg = nil;
//        switch (self.joinType)
//        {
//            case JBoJoinTypeActivity :
//                alertMsg = @"网络不给力,参加活动失败";
//                break;
//                case JBoJoinTypeLays :
//                alertMsg = @"网络不给力,申请代言失败";
//                break;
//            default:
//                break;
//        }
        [JBoUserOperation alertmsgWithBadNetwork:@"参加活动失败"];
    }
}

- (void)sendSuccess:(BOOL) success
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    self.info.userID = detailInfo.rosterInfo.username;
    self.info.headImageURL = detailInfo.rosterInfo.imageURL;
    self.info.userName = detailInfo.rosterInfo.name;
    self.info.sex = detailInfo.rosterInfo.sex;
    self.info.role = detailInfo.rosterInfo.role;
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:_releaseLookAndTellNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:self.info forKey:_releaseLookAdnTellInfo_]];
    
    [self performSelector:@selector(backAction:) withObject:nil afterDelay:0.3];
}

#pragma mark-加载视图

- (void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)popToCircleController
{
    NSMutableArray *viewControllers = [[NSMutableArray alloc] initWithCapacity:2];
    for(UIViewController *VC in self.navigationController.viewControllers)
    {
        if([VC isKindOfClass:[JBoMoreViewController class]])
        {
            [viewControllers addObject:VC];
            break;
        }
    }
    
    JBoCircleLookAndTellViewController *circle = [[JBoCircleLookAndTellViewController alloc] init];
    [viewControllers addObject:circle];
    [self.navigationController setViewControllers:viewControllers animated:YES];
    [circle release];
    [viewControllers release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
}

- (void)setUserId:(NSString *)userId
{
    if(_userId != userId)
    {
        [_userId release];
        _userId = [userId copy];
        self.title = @"参加活动";
        
//        switch (self.joinType)
//        {
//            case JBoReleaseLookAndTellTypeActivity :
//            {
//               
//            }
//                break;
//            case JBoReleaseLookAndTellTypeLays :
//            {
//                self.title = @"申请代言";
//            }
//            default:
//                break;
//        }
        
        _appDelegate.dataLoadingView.hidden = NO;
        JBoAsyncDownloadUserInfoOperation *asyncDownload = [[JBoAsyncDownloadUserInfoOperation alloc] init];
        asyncDownload.needHeadImage = NO;
        __block JBoAsyncDownloadUserInfoOperation *blockAsyncDownload = asyncDownload;
        asyncDownload.completionHandler = ^(void)
        {
            self.userDetailInfo = blockAsyncDownload.userDetailInfo;
            self.userDetailInfo.rosterInfo.username = self.userId;
            [self loadInitView];
            [blockAsyncDownload release];
        };
        [asyncDownload downloadWithUserId:self.userId];
    }
}

#pragma mark-私有方法
//发送
- (void)sendAction:(id) sender
{
    if(self.isRequesting)
        return;
    
    if([NSString isEmpty:_tableHeaderView.contentTextView.text])
    {
        [JBoUserOperation alertMsg:@"图文内容不能为空"];
        return;
    }
    
    if(_tableHeaderView.imageArray.count == 0)
    {
        [JBoUserOperation alertMsg:@"请上传图片"];
        return;
    }
    [self releaseLookAndTell];
    
}

- (void)releaseLookAndTell
{
    self.progressView.progress = 0;
    _appDelegate.dataLoadingView.hidden = NO;
    
    if(_tableHeaderView.contentTextView.text.length > _inputFormatLookAndTellNum_ )
    {
        [self alert];
        [_tableHeaderView.contentTextView setContentOffset:CGPointMake(0, _inputFormatLookAndTellNum_ / (_tableHeaderView.contentTextView.frame.size.width / 17.0) * 22) animated:YES];
        return;
    }
    
    if(_tableHeaderView.lookAndTellType != _lookAndTellTypeNormal_ && _tableHeaderView.secondTextView.text.length > _inputFormatLookAndTellNum_)
    {
        [self alert];
        [_tableHeaderView.secondTextView setContentOffset:CGPointMake(0, _inputFormatLookAndTellNum_ / (_tableHeaderView.contentTextView.frame.size.width / 17.0) * 22) animated:YES];
        return;
    }
    
    if(_tableHeaderView.lookAndTellType != _lookAndTellTypeNormal_ && _tableHeaderView.thirdTextView.text.length > _inputFormatLookAndTellNum_)
    {
        [self alert];
        [_tableHeaderView.thirdTextView setContentOffset:CGPointMake(0, _inputFormatLookAndTellNum_ / (_tableHeaderView.contentTextView.frame.size.width / 17.0) * 22) animated:YES];
        return;
    }
    
    self.info.date = [JBoDatetimeTool getCurrentTime];
    self.info.type = _lookAndTellTypeNormal_;
    self.info.groupId = [JBoDatetimeTool getTimeAndRandom];
    
    [NSThread detachNewThreadSelector:@selector(writeImageToFile) toTarget:self withObject:nil];
}

- (void)alert
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您发表的内容已超过字数限制,超出部分标示为红色" message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertView show];
    [alertView release];
}

- (void)writeImageToFile
{
    NSMutableArray *multis = [[NSMutableArray alloc] init];
    
    if(![NSString isEmpty:_tableHeaderView.contentTextView.text])
    {
        JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
        text.content = _tableHeaderView.contentTextView.text;
        
        if(_tableHeaderView.imageArray.count > 0)
        {
            NSArray *files = [JBoFileManager writeImageInTemporaryFile:_tableHeaderView.imageArray withCompressedScale:_lookAndTellImageCompressedScale_];
            text.imageURLArray = files;
        }
        [multis addObject:text];
        [text release];
    }
    
    if(![NSString isEmpty:_tableHeaderView.secondTextView.text])
    {
        JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
        text.content = _tableHeaderView.secondTextView.text;
        
        if(_tableHeaderView.secondImageArray.count > 0)
        {
            NSArray *files = [JBoFileManager writeImageInTemporaryFile:_tableHeaderView.secondImageArray withCompressedScale:_lookAndTellImageCompressedScale_];
            text.imageURLArray = files;
        }
        [multis addObject:text];
        [text release];
    }
    
    if(![NSString isEmpty:_tableHeaderView.thirdTextView.text])
    {
        JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
        text.content = _tableHeaderView.thirdTextView.text;
        
        if(_tableHeaderView.secondImageArray.count > 0)
        {
            NSArray *files = [JBoFileManager writeImageInTemporaryFile:_tableHeaderView.thirdImageArray withCompressedScale:_lookAndTellImageCompressedScale_];
            text.imageURLArray = files;
        }
        [multis addObject:text];
        [text release];
    }
    
    [self performSelectorOnMainThread:@selector(uplaodWithInfos:) withObject:multis waitUntilDone:NO];
    
    [multis release];
}

- (void)uplaodWithInfos:(NSMutableArray*) infos
{
    if(infos.count > 0)
    {
        for(NSInteger i = 0;i < infos.count; i ++)
        {
            
            JBoMultiImageText *text  = [infos objectAtIndex:i];
            [self.imageNameArray addObjectsFromArray:text.imageURLArray];
            
            JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
            httpRequest.startImmediately = NO;
            
            NSString *url = [JBoLookAndTellOperation getReleaseLookAndTellURL];
            if(text.imageURLArray.count == 0)
            {
                url = [JBoLookAndTellOperation getReleaseLookAndTellURLWithOutFiles];
            }
            
            ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
            [request setTimeOutSeconds:30.0];
            
            NSDictionary *paraDic = [JBoLookAndTellOperation releaseLookAndTellWithContent:text.content type:self.info.type groupId:self.info.groupId order:i count:infos.count url:nil needImageText:NO visible:_lookAndTellVisiblePublic_];
            
            [paraDic enumerateKeysAndObjectsUsingBlock:^(id key, id vaule, BOOL *stop)
             {
                 [request setPostValue:vaule forKey:key];
             }];
            
            for(NSString *str in text.imageURLArray)
            {
                [request addFile:str forKey:_lookAndTellImagesFile_];
            }
            
            [[self queue] addOperation:request];
        }
        
        self.success = YES;
        self.info.multiInfo = infos;
        self.isRequesting = YES;
        [[self queue] go];
    }
}

- (void)loadInitView
{
    _appDelegate.dataLoadingView.hidden = YES;
    if(self.black)
    {
        [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(sendAction:) title:@"申请" backgroundImage:nil textColor:[UIColor blackColor]];
    }
    else
    {
        [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(sendAction:) title:@"申请" backgroundImage:nil textColor:[UIColor whiteColor]];
    }
    
    CGRect frame = CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_);
    _tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    //_tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    [_tableView setExtraCellLineHidden];
    
    
    _tableHeaderView = [[JBoReleaseLookAndTellTableHeaderView alloc] initWithFrame:CGRectZero type:JBoReleaseLookAndTellTypeActivity];
    _tableHeaderView.contentTextView.placeholder = @"请按发布活动方要求提供图文申请\n限1000字,超出部分以红色显示";
    _tableHeaderView.navigationController = self.navigationController;
    _tableView.tableHeaderView = _tableHeaderView;
    _tableHeaderView.tableView = _tableView;

    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
    }
#endif
}


#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
    }
    
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

