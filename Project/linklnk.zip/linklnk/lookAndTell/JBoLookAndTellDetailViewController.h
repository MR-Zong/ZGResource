//
//  JBoLookAndTellDetailViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellViewController.h"
#import "JBoLookAndTellListInfo.h"

@class JBoLookAndTellDetailViewController;

@protocol JBoLookAndTellDetailViewControllerDelegate <NSObject>

@optional

/** 说说置顶
 */
- (void)detailViewController:(JBoLookAndTellDetailViewController*) viewController didStickedInfo:(JBoLookAndTellListInfo*) info;
/** 说说被删除
 */
- (void)detailViewController:(JBoLookAndTellDetailViewController *)viewController didDeletedInfo:(JBoLookAndTellListInfo *)info;

@end


@interface JBoLookAndTellDetailViewController : JBoLookAndTellViewController

/**要查看的说说Id
 */
@property(nonatomic,copy) NSString *groupId;

/**要查看的说说的 msgId 用于某些没有groupId的说说
 */
@property(nonatomic,copy) NSString *msgId;

/**要查看详情的说说，如果nil,则通过groupId获取 msgId获取
 */
@property(nonatomic,retain) JBoLookAndTellListInfo *info;

@property(nonatomic,assign) id<JBoLookAndTellDetailViewControllerDelegate> delegate;

@end
