//
//  JBoCircleLookAndTellViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoCircleLookAndTellViewController.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoLookAndTellOperation.h"
#import "JBoLookAndTellListCell.h"
#import "JBoBottomLoadingView.h"
#import "JBoImageTextTool.h"
#import "JBoUserDetailInfo.h"
#import "JBoReleaseLookAndTellViewController.h"
#import "JBoCircleBgViewController.h"
#import "JBoUserLookAndTellViewController.h"
#import "UITableView+extraCellLine.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoUserTableHeaderView.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoShareOperation.h"
#import "JBoNavigationViewController.h"
#import "JBoOfflineCacheOperation.h"
#import "JBoCheckInputText.h"
#import "JBoLookAndTellTypeSelectedViewController.h"
#import "JBoWebViewController.h"

@interface JBoCircleLookAndTellViewController ()<EGORefreshTableHeaderDelegate,JBoUserTableHeaderViewDelegate,JBoLookAndTellDelegate,JBoLookAndTellListCellDelegate>
{
    //下拉刷新
    EGORefreshTableHeaderView *_refreshView;
    BOOL _isLoading;
    
    JBoBottomLoadingView *_bottomLoadingView;
}


@end

@implementation JBoCircleLookAndTellViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = _lookAndTellName_;
        self.isRequesting = NO;
        self.needLoadHeadImage = YES;
        self.hasNoInfoMsg = [NSString stringWithFormat:@"暂无%@信息", _lookAndTellName_];
        self.black = YES;
        self.hasInfo = NO;
        
        //发布说说
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(releaseAction:) name:_releaseLookAndTellNotification_ object:nil];
       
        //说说被删除
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteLookAndTell:) name:_lookAndTellDidDeletedNotification_ object:nil];

    }
    return self;
}

#pragma mark-通知

- (void)releaseAction:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoLookAndTellListInfo *info = [dic objectForKey:_releaseLookAdnTellInfo_];
    
    if(info.visible == _lookAndTellVisiblePrivate_)
        return;
    
    for(JBoMultiImageText *text in info.multiInfo)
    {
        [self.offlineCache insertBeautifulCircle:info multiImageText:text images:[JBoImageTextTool imagesFromImageURLArray:text.imageURLArray] isSelf:YES];
        [self.offlineCache insertBeautifulCircle:info multiImageText:text images:[JBoImageTextTool imagesFromImageURLArray:text.imageURLArray] isSelf:NO];
    }
 
    [self.infoArray insertObject:info atIndex:0];
    
    [self.tableView reloadData];
    [self infoIsNull];
}

- (void)deleteLookAndTell:(NSNotification*) notification
{
    NSString *groupId = [[notification userInfo] objectForKey:_lookAndTellGroupId_];
    [self removeLookAndTellWithGroupId:groupId];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoCircleLookAndTellViewController dealloc");
    
    [_refreshView release];
    [_bottomLoadingView release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_lookAndTellDidDeletedNotification_ object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_releaseLookAndTellNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    self.navigationController.navigationBar.translucent = NO;
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
}

#pragma mark-http代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_getCircleLookAndTellIdentifier_])
    {
        self.isRequesting = NO;
        if(!_isLoading)
        {
            if(self.infoArray.count == 0)
            {
                [self getCircleInfo];
            }
            else
            {
                [self alertNetworkMsg:[NSString stringWithFormat:@"获取%@信息失败", _lookAndTellName_]];
            }
        }
        else
        {
            _refreshView.finishText = [NSString stringWithFormat:@"暂无%@信息", _lookAndTellName_];
            [self tableViewDataSourceDidFinishLoading];
        }
        [self infoIsNull];
        return;
    }
    
    if([identifier isEqualToString:_trasmitLookAndTellIdentifier_])
    {
        self.isRequesting = NO;
        [self alertNetworkMsg:@"请重试"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getCircleLookAndTellIdentifier_])
    {
        if(_isLoading)
        {
            [self.offlineCache removeBeautifulCircleWithSelf:NO];
        }
        
        NSMutableArray *infoArray = [JBoLookAndTellOperation getCircleLookAndTellInfoFromData:data multiInfo:self.multisInfoDic offlineCache:self.offlineCache];
        if(infoArray != nil)
        {
            self.hasInfo = infoArray.count != 0;
            
            if(_isLoading)
            {
                [self.infoArray removeAllObjects];
            }
            
            [self.infoArray addObjectsFromArray:infoArray];
            
            if(!self.tableView)
            {
                [self loadInitView];
            }
            
            if(_isLoading)
            {
                self.pageIndex = 1;
                _refreshView.finishText = @"刷新成功";
                [self tableViewDataSourceDidFinishLoading];
            }
            [self.tableView reloadData];
        }
        else
        {
            if(_isLoading)
            {
                _refreshView.finishText = [NSString stringWithFormat:@"暂无%@信息", _lookAndTellName_];
                [self tableViewDataSourceDidFinishLoading];
            }
            else
            {
                [self alertMsg:[NSString stringWithFormat:@"暂无%@信息", _lookAndTellName_]];
            }
            
            if(!self.tableView)
            {
                [self loadInitView];
            }
            [self.tableView reloadData];
            self.hasInfo = NO;
            [self infoIsNull];
        }
    }
   
    if([identifier isEqualToString:_trasmitLookAndTellIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [self alertMsg:@"已转载"];
        }
        return;
    }
}

#pragma mark- 数据库操作

- (void)getCircleInfo
{
//    self.appDelegate.dataLoadingView.hidden = NO;
//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
//       
        [self.offlineCache getBeautifulCircleInfoWithArray:self.infoArray multisInfo:[NSMutableDictionary dictionary] isSelf:NO];
        
        NSInteger count = 0;
        for(JBoLookAndTellListInfo *info in self.infoArray)
        {
            count += info.multiInfo.count;
        }
        self.pageIndex = count / _lookAndTellPageSize_;
        
    self.appDelegate.dataLoadingView.hidden = YES;
    if(!self.tableView)
    {
        [self loadInitView];
    }
    else
    {
        [self.tableView reloadData];
    }
    //});
}

#pragma mark-加载视图

- (void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    //返回
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(backAction:) image:[UIImage imageNamed:@"newsBact.png"]];
    
    [self getCircleInfo];
}

- (void)loadInfo:(BOOL) hidden
{
    if(self.isRequesting)
        return;
    
    NSInteger pageIndex = self.pageIndex;
    if(_isLoading)
    {
        pageIndex = 1;
    }
    
    self.httpRequest.identifier = _getCircleLookAndTellIdentifier_;
    self.isRequesting = YES;
    self.appDelegate.dataLoadingView.hidden = hidden;
    [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getCircleLookAndTellInfoWithPageNum:pageIndex rows:_lookAndTellPageSize_]];
}

- (void)releaseLookAndTell:(id)sender
{
    JBoReleaseLookAndTellViewController *releaseVC = [[JBoReleaseLookAndTellViewController alloc] init];
    UINavigationController *frontNav = [[UINavigationController alloc] initWithRootViewController:releaseVC];
    
    JBoLookAndTellTypeSelectedViewController *selectedVC = [[JBoLookAndTellTypeSelectedViewController alloc] init];
    UINavigationController *rightNav = [[UINavigationController alloc] initWithRootViewController:selectedVC];
    
    
    SWRevealViewController *revealVC = [[SWRevealViewController alloc] initWithRearViewController:nil frontViewController:frontNav];
    revealVC.rightViewController = rightNav;
    releaseVC.revealVC = revealVC;
    selectedVC.revealVC = revealVC;
    
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:revealVC];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:nav.navigationBar];
    nav.navigationBar.translucent = NO;
    [self presentViewController:nav animated:YES completion:nil];
    
    [nav release];
    [revealVC release];
    [releaseVC release];
    [frontNav release];
    [selectedVC release];
    [rightNav release];
}

- (void)openWebToShare:(id)sender
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请输入网址" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"前往", nil];
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *textField = [alertView textFieldAtIndex:0];
    textField.keyboardType = UIKeyboardTypeURL;
    [alertView show];
    [alertView release];
}

- (void)loadInitView
{
    //发布连说
    UIImage *releaseImage = [UIImage imageNamed:@"newsRelease"];
    self.navigationItem.rightBarButtonItem = [JBoNavigatioinBarOperation barButtonItemWithIcon:releaseImage target:self tapAction:@selector(releaseLookAndTell:) longPressAction:@selector(openWebToShare:)];
    
    JBoUserTableHeaderView *tableHeaderView = [[JBoUserTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tableHeaderViewHeight_)];
    tableHeaderView.nameLabel.text = @"我的日志";
    tableHeaderView.nameLabel.sex = self.myInfo.rosterInfo.sex;
    tableHeaderView.bgImageView.userId = [JBoUserOperation getUserId];
    tableHeaderView.delegate = self;
    tableHeaderView.headImageView.role = self.myInfo.rosterInfo.role;
    
    if(self.myInfo.rosterInfo.image)
    {
        tableHeaderView.headImageView.imageView.image = self.myInfo.rosterInfo.image;
    }
    else
    {
        tableHeaderView.headImageView.sex = self.myInfo.rosterInfo.sex;
    }

    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.tableHeaderView = tableHeaderView;
    tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tableView];
    [tableHeaderView release];
    self.tableView = tableView;
    [tableView release];
    
    [self.tableView setExtraCellLineHidden];
    
    //下拉刷新
    _refreshView = [[EGORefreshTableHeaderView alloc] initWithFrame:self.tableView.frame];
    _refreshView.delegate = self;
    _refreshView.scrollView = self.tableView;
    _refreshView.backgroundColor = [UIColor whiteColor];
    [self.view insertSubview:_refreshView belowSubview:self.tableView];
    
    if(self.appDelegate.previousWorkStatus != NotReachable)
    {
        [_refreshView beginRefresh];
    }
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        
        NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
        
        if([title isEqualToString:@"前往"])
        {
            UITextField *textField = [alertView textFieldAtIndex:0];
            NSString *url = textField.text;;
            if([JBoCheckInputText isURL:url])
            {
                JBoWebViewController *webVC = [[JBoWebViewController alloc] init];
                webVC.URL = [NSURL URLWithString:[NSString encodeStr:url]];
                webVC.black = YES;
                [webVC showInViewController:self animated:YES completion:nil];
                [webVC release];
            }
            else
            {
                [self alertMsg:@"请输入有效地址"];
            }
        }
    }
}

#pragma mark-JBoLookAndTellTableHeaderView代理
- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView headImageDidTapped:(JBoUserHeadImageView *)headImageView
{
    [self seeMyLookAndTellInfo];
}

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView bgImageDidTapped:(UIView *)view
{
    JBoCircleBgViewController *circleBgVC = [[JBoCircleBgViewController alloc] init];
    [self.navigationController pushViewController:circleBgVC animated:YES];
    [circleBgVC release];
}

- (void)seeMyLookAndTellInfo
{
    JBoUserLookAndTellViewController *userLookAndTellVC = [[JBoUserLookAndTellViewController alloc] init];
    userLookAndTellVC.delegate = self;
    userLookAndTellVC.myInfo = self.myInfo;
    [self.navigationController pushViewController:userLookAndTellVC animated:YES];
    [userLookAndTellVC release];
}

#pragma mark-JBoUserLookAndTellViewController代理

- (void)userLookAndTellViewController:(UIViewController *)viewController didDeleteMsgWithGroupId:(NSString *)groupId
{
    [self removeLookAndTellWithGroupId:groupId];
}

- (void)removeLookAndTellWithGroupId:(NSString*) groupId
{
    dispatch_async(dispatch_get_main_queue(), ^(void){
        
        for(NSInteger i = 0; i < self.infoArray.count; i ++)
        {
            JBoLookAndTellListInfo *info = [[self.infoArray objectAtIndex:i] retain];
            if([info.groupId isEqualToString:groupId])
            {
                [self.infoArray removeObjectAtIndex:i];
                [self.offlineCache removeBeautifulCircleWithGroupId:groupId];
                
                if(info.transmitId == _trasmitNo_)
                {
                    [self.offlineCache removeCircleCommentWithGroupId:info.groupId];
                    [self.offlineCache deleteCircleOperationWithInfo:info];
                }
                
                [self.tableView reloadData];
                [self infoIsNull];
            }
            [info release];
        }
    });
}

#pragma mark-tableView代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self circleHeightForIndexPath:indexPath];
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    static NSString *defaultIdentifier = @"default";
    static NSString *shareLinkIdentifier = @"shareLink";
    static NSString *shortMovieIdentifier = @"shortMovie";
    
    NSString *cellIdentifier = defaultIdentifier;
    JBoLookAndTellCellStyle style = JBoLookAndTellCellStyleDefault;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cellIdentifier = shareLinkIdentifier;
            style = JBoLookAndTellCellStyleLinkShare;
        }
            break;
           case _lookAndTellTypeShortMovie_ :
        {
            cellIdentifier = shortMovieIdentifier;
            style = JBoLookAndTellCellStyleShortMovie;
        }
            break;
        default:
            break;
    }
    
    JBoLookAndTellListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];

    if(cell == nil)
    {
        cell = [[[JBoLookAndTellListCell alloc] initWithCellStyle:style reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.msgOperationView.canComplaint = YES;
    }
    
    
    cell.msgOperationView.info = info;
    cell.msgOperationView.style = info.operationInfo.style;

    cell.msgOperationView.index = indexPath.row;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cell.linkView.shareView.htmlTitleLabel.text = info.urlTitle;
        
            cell.linkView.shareURL = info.url;
            cell.linkView.srcArray = info.multiInfo;
        }
            break;
            case _lookAndTellTypeShortMovie_ :
        {
            cell.shareShortMovieView.srcArray = info.multiInfo;
        }
            break;
        default:
        {
            cell.multiImageTextView.hasMoreText = info.hasMoreText;
            cell.multiImageTextView.srcArray = info.multiInfo;
        }
            break;
    }
   
    JBoRosterInfo *rosterInfo = [self.appDelegate.rosterAndUsernameDic objectForKey:info.userID];
    if([NSString isEmpty:rosterInfo.remark])
    {
        cell.nameLabel.text = info.userName;
    }
    else
    {
        cell.nameLabel.text = rosterInfo.remark;
    }
    
    cell.nameLabel.sex = info.sex;
    cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.date];
    cell.headImageView.sex = info.sex;
    cell.headImageView.role = info.role;
    cell.headImageView.sex = info.sex;
    cell.headImageView.headImageURL = info.headImageURL;
    
    return cell;
}


#pragma mark-JBoLookAndTellListCell代理

- (void)lookAndTellListCellHeadImageDidSelected:(JBoLookAndTellListCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    if([info.userID isEqualToString:[JBoUserOperation getUserId]])
    {
        [self seeMyLookAndTellInfo];
    }
    else
    {
        JBoRosterInfo *rosterInfo = [self.appDelegate.rosterAndUsernameDic objectForKey:info.userID];
        if(!rosterInfo)
        {
            rosterInfo = [[[JBoRosterInfo alloc] init] autorelease];
            rosterInfo.username = info.userID;
        }
        
        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
        detail.rosterInfo = rosterInfo;
        [self.navigationController pushViewController:detail animated:YES];
        [detail release];
    }
}

#pragma mark-scrollView代理  在用户停止拖动和拖动停止减速时加载图片
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
}


- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [_refreshView egoRefreshScrollViewWillBeginScroll:scrollView];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
     [_refreshView egoRefreshScrollViewDidScroll:scrollView];
  
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!_bottomLoadingView)
        {
            //创建加载更多视图
            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
        }
        if(!self.isRequesting && self.hasInfo)
        {
            self.pageIndex ++;
            self.tableView.tableFooterView = _bottomLoadingView;
            [self loadInfo:YES];
        }
    }
}

#pragma mark-刷新数据

// 加载数据
- (void)reloadTableViewDataSource
{
    _isLoading = YES;
    self.hasInfo = YES;
    
    [self loadInfo:YES];
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading
{
    _isLoading = NO;
    
    [self.tableView reloadData];
    [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
}

//下拉刷新
- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
