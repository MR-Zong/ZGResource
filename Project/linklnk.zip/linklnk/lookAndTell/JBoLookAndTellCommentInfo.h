//
//  JBoLookAndTellCommentInfo.h
//  靓咖
//
//  Created by kinghe005 on 14-7-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**靓友圈 评论信息
 */
@interface JBoLookAndTellCommentInfo : NSObject

/**评论Id
 */
@property(nonatomic,assign) long long Id;

/**评论用户
 */
@property(nonatomic,copy) NSString *userId;

/**用户昵称,如果有备注则为备注
 */
@property(nonatomic,copy) NSString *name;

/**用户性别
 */
@property(nonatomic,assign) NSInteger sex;

/**评论内容
 */
@property(nonatomic,copy) NSString *comment;

/**内容高度 在详情中显示 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger commentHeight;

/**内容高度 在说说底部显示 default is ‘NSNotFound’
 */
@property(nonatomic,assign) NSInteger commentBottmHeight;

/**评论时间
 */
@property(nonatomic,copy) NSString *time;

@end
