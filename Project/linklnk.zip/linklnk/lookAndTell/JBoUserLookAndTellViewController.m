//
//  JBoLookAndTellViewController.m
//  简宝
//
//  Created by kinghe005 on 13-11-18.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserLookAndTellViewController.h"
#import "JBoAppDelegate.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoLookAndTellOperation.h"
#import "JBoBottomLoadingView.h"
#import "JBoImageTextTool.h"
#import "JBoMultiImageView.h"
#import "JBoUserLookAndTellCell.h"
#import "JBoDatetimeTool.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoUserTableHeaderView.h"
#import "JBoCircleBgViewController.h"
#import "JBoMyCraticActivityViewController.h"
#import "JBoImageCacheTool.h"
#import "JBoMsgOperation.h"
#import "JBoLookAndTellDetailViewController.h"
#import "JBoMovieCacheTool.h"
#import "JBoOfflineCacheOperation.h"
#import "JBoSceneLookAndTellReleaseViewController.h"
#import "JBoSceneMakingImageInfo.h"

#define _deleteTitle_ @"删除"
#define _topTitle_ @"置顶"

@interface JBoUserLookAndTellViewController ()<JBoUserLookAndTellCellDelegate,JBoUserTableHeaderViewDelegate,UIAlertViewDelegate,JBoCustomFilterBarDelegate>
{
    //加载更多信息视图
    JBoBottomLoadingView *_bottomLoadingView;
}

//说说状态筛选
@property(nonatomic,retain) JBoCustomFilterBar *filterBar;
@property(nonatomic,assign) BOOL filter;

@end

@implementation JBoUserLookAndTellViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        //删除说说
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deleteLookAndTell:) name:_lookAndTellDidDeletedNotification_ object:nil];
        
        //发布说说
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(releaseAction:) name:_releaseLookAndTellNotification_ object:nil];
        
        self.title = @"我的日志";
        
        self.operationStyle = JBoMsgOperationUserOperation;
        self.hasNoInfoMsg = @"你还没有日志";
        self.black = YES;
        self.isSelf = YES;
    }
    return self;
}

#pragma mark-通知

//发布说说
- (void)releaseAction:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoLookAndTellListInfo *info = [dic objectForKey:_releaseLookAdnTellInfo_];
    
    switch (self.filterBar.selectedIndex)
    {
        case 1 :
        {
            if(info.visible != _lookAndTellVisiblePublic_)
            {
                return;
            }
        }
            break;
        case 2 :
        {
            if(info.visible != _lookAndTellVisiblePrivate_)
            {
                return;
            }
        }
            break;
        default:
            break;
    }
    
    JBoLookAndTellListInfo *stickInfo = [self.infoArray firstObject];
    if(stickInfo && stickInfo.stick == _lookAndTellStickYes_)
    {
        [self.infoArray insertObject:info atIndex:1];
    }
    else
    {
        [self.infoArray insertObject:info atIndex:0];
    }
    
    [self.tableView reloadData];
}

- (void)deleteLookAndTell:(NSNotification*) notification
{
    NSString *groupId = [[notification userInfo] objectForKey:_lookAndTellGroupId_];
    dispatch_async(dispatch_get_main_queue(), ^(void){
        
        for(NSInteger i = 0; i < self.infoArray.count; i ++)
        {
            JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:i];
            
            if([info.groupId isEqualToString:groupId])
            {
                [self.offlineCache removeBeautifulCircleWithGroupId:groupId];
                
                if(info.transmitId == _trasmitNo_)
                {
                    [self.offlineCache removeCircleCommentWithGroupId:info.groupId];
                    [self.offlineCache deleteCircleOperationWithInfo:info];
                }
                
                 [self.infoArray removeObjectAtIndex:i];
                [self.tableView reloadData];
                break;
            }
        }
    });
}


#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoUserLookAndTellViewController dealloc");
    
    [_conditions release];
    
    [_sceneImageInfo release];
    [_relateGroupId release];
    
    [_bottomLoadingView release];

    [_filterBar release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_lookAndTellDidDeletedNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.translucent = NO;
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if(self.isRequesting)
    {
        self.appDelegate.dataLoadingView.hidden = NO;
    }
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.filter = NO;
    self.isRequesting = NO;
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        if(self.infoArray.count == 0)
        {
            [self getMyCircleInfo];
        }
        else
        {
            [self alertNetworkMsg:@"获取数据失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeLookAndTellIdentifier_])
    {
        [self alertNetworkMsg:@"删除失败"];
        return;
    }
    
    if([identifier isEqualToString:_stickLookAndTellIdentifier_])
    {
        [self alertNetworkMsg:@"请重试"];
        return;
    }
    
    if([identifier isEqualToString:_lookAndTellVisibleIdentifier_])
    {
        [self alertNetworkMsg:@"设置失败"];
        return;
    }
    
    if([identifier isEqualToString:_getLookAndTellByGroupIdIdentifier_])
    {
        [self alertNetworkMsg:@"获取数据失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        NSMutableArray *infoArray = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:self.multisInfoDic offlineCache:self.offlineCache];
        if(infoArray != nil)
        {
            if(infoArray.count == 0)
            {
                self.hasInfo = _lookAndTellStickNo_;
            }
            
            if(self.relateGroupId)
            {
                for(NSInteger i = 0;i < infoArray.count;i ++)
                {
                    JBoLookAndTellListInfo *info = [infoArray objectAtIndex:i];
                    if([info.groupId isEqualToString:self.relateGroupId])
                    {
                        [infoArray removeObject:info];
                        break;
                    }
                }
            }
            
            if(self.filter)
            {
                self.filter = NO;
                [self.infoArray removeAllObjects];
            }
            [self.infoArray addObjectsFromArray:infoArray];
        }
        else
        {
            [self alertMsg:@"还没有日志呢"];
            self.hasInfo = NO;
        }
        
        if(!self.tableView)
        {
            [self loadInitView];
        }
        
        [self.tableView reloadData];
        
        [self infoIsNull];
        return;
    }
  
    if([identifier isEqualToString:_removeLookAndTellIdentifier_])
    {
        if(self.currentIndex < self.infoArray.count)
        {
            [self alertMsg:@"删除成功"];
            
            JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:self.currentIndex];
            
            [self.offlineCache removeBeautifulCircleWithGroupId:info.groupId];
            
            if(info.transmitId == _trasmitNo_)
            {
                [self.offlineCache removeCircleCommentWithGroupId:info.groupId];
                [self.offlineCache deleteCircleOperationWithInfo:info];
            }
            
            if([self.delegate respondsToSelector:@selector(userLookAndTellViewController:didDeleteMsgWithGroupId:)])
            {
                [self.delegate userLookAndTellViewController:self didDeleteMsgWithGroupId:info.groupId];
            }
            [self.infoArray removeObjectAtIndex:self.currentIndex];
            
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.currentIndex inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
            
            self.currentIndex = NSNotFound;
            [self infoIsNull];
        }
        
        return;
    }

    
    if([identifier isEqualToString:_stickLookAndTellIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            if(self.currentIndex != 0)
            {
                JBoLookAndTellListInfo *info = [self.infoArray firstObject];
                info.stick = _lookAndTellStickNo_;
            }
            
            if(self.currentIndex >= self.infoArray.count)
                return;
            
            JBoLookAndTellListInfo *info = [[self.infoArray objectAtIndex:self.currentIndex] retain];
            
            info.stick = !info.stick;
            
            [self.infoArray removeObjectAtIndex:self.currentIndex];
            [self.infoArray insertObject:info atIndex:0];
            
            [self alertMsg:@"置顶成功"];
            [info release];
            [self.tableView reloadData];
        }
        else
        {
            [self alertMsg:@"置顶失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_lookAndTellVisibleIdentifier_])
    {
        if(self.currentIndex >= self.infoArray.count)
            return;
        
        if([JBoUserOperation isSuccess:data])
        {
            JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:self.currentIndex];
            if(info.visible == _lookAndTellVisiblePublic_)
            {
                info.visible = _lookAndTellVisiblePrivate_;
            }
            else
            {
                info.visible = _lookAndTellVisiblePublic_;
            }
            
            if(self.filterBar.selectedIndex != 0)
            {
                [self.infoArray removeObjectAtIndex:self.currentIndex];
            }
            
            [self.tableView reloadData];
        }
        else
        {
            [self alertNetworkMsg:@"设置失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_getLookAndTellByGroupIdIdentifier_])
    {
        NSArray *infos = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:self.multisInfoDic offlineCache:self.offlineCache];
        if(infos.count > 0)
        {
            JBoLookAndTellListInfo *info = [infos firstObject];
            [self.infoArray addObject:info];
        }
        else
        {
            self.relateGroupId = nil;
        }
        
        [self loadInfo:NO];
    }
}

- (void)getMyCircleInfo
{
    self.appDelegate.dataLoadingView.hidden = NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        [self.offlineCache getBeautifulCircleInfoWithArray:self.infoArray multisInfo:[NSMutableDictionary dictionary] isSelf:YES];
        NSInteger count = 0;
        for(JBoLookAndTellListInfo *info in self.infoArray)
        {
            count += info.multiInfo.count;
        }
        self.pageIndex = count / _lookAndTellPageSize_;
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            self.appDelegate.dataLoadingView.hidden = YES;
            if(!self.tableView)
            {
                [self loadInitView];
            }
            else
            {
                [self.tableView reloadData];
            }
            [self infoIsNull];
        });
    });
}

#pragma mark- super method

//删除说说
- (void)removeLookAndTell
{
    if(self.isRequesting)
        return;
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"确定删除这条日志?" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    [alertView show];
    [alertView release];
}

//置顶说说
- (void)stickLookAndTell
{
    if(self.isRequesting)
        return;
    
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:self.currentIndex];
    self.httpRequest.identifier = _stickLookAndTellIdentifier_;
    self.isRequesting = YES;
    [self.httpRequest startDataLoading];
    
    NSInteger state = _stickSetup_;
    if(info.stick == _lookAndTellStickYes_)
        state = _stickCancel_;
    
    [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getStickLookAndTellWithGroupId:info.groupId state:state]];
}

//设定说说的可见范围
- (void)setLookAndTellVisible
{
    if(self.isRequesting)
        return;
    
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:self.currentIndex];
    [self.httpRequest startDataLoading];
    self.isRequesting = YES;
    self.httpRequest.identifier = _lookAndTellVisibleIdentifier_;
    NSInteger visible = _lookAndTellVisiblePublic_;
    if(info.visible == _lookAndTellVisiblePublic_)
        visible = _lookAndTellVisiblePrivate_;
    [self.httpRequest downloadWithURL:[JBoLookAndTellOperation lookAndTellVisibleURL] dic:[JBoLookAndTellOperation lookAndTellParaWithVisible:visible groupId:info.groupId]];
}

//关联说说
- (void)relateCircle
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:self.currentIndex];
    if(info.operationInfo.selected)
    {
        info.operationInfo.selected = NO;
        self.relateGroupId = nil;
        [self.tableView reloadData];
        
        if([self.delegate respondsToSelector:@selector(userLookAndTellViewController:didSelectedMsg:)])
        {
            [self.delegate userLookAndTellViewController:self didSelectedMsg:nil];
        }
    }
    else
    {
        if([self.delegate respondsToSelector:@selector(userLookAndTellViewController:didSelectedMsg:)])
        {
            [self.delegate userLookAndTellViewController:self didSelectedMsg:info];
        }
    }
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)cancel
{
    [self dismissModalViewControllerAnimated:YES];
}

- (void)sceneLookAndTellRelease
{
    JBoSceneLookAndTellReleaseViewController *release = [[JBoSceneLookAndTellReleaseViewController alloc] init];
    release.sceneImageInfo = self.sceneImageInfo;
    release.conditions = self.conditions;
    release.delegate = self.delegate;
    [self.navigationController pushViewController:release animated:YES];
    [release release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.isSelf = YES;
    self.black = YES;
    [self setWhiteNavigationBar];
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
    
    switch (self.operationStyle)
    {
        case JBoMsgOperationVStyleScene :
        {
            [self setLeftBarItemsWithTitle:@"取消" action:@selector(cancel)];
            
            if(self.relateGroupId)
            {
                self.isRequesting = YES;
                [self.httpRequest startDataLoading];
                self.httpRequest.identifier = _getLookAndTellByGroupIdIdentifier_;
                [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getLookAndtellFromGroupId:self.relateGroupId]];
            }
            else
            {
                [self loadInfo:NO];
            }
        }
            break;
        case JBoMsgOperationUserOperation :
        {
            [self setBackItem:YES];
            if(self.appDelegate.previousWorkStatus != NotReachable)
            {
                [self loadInfo:NO];
            }
            else
            {
                [self getMyCircleInfo];
            }
        }
            break;
        default:
            break;
    }
    
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)loadInfo:(BOOL)hidden
{
    if(self.isRequesting)
        return;
    
    self.httpRequest.identifier = _getUserLookAndTellIdentifier_;
    self.appDelegate.dataLoadingView.hidden = hidden;
    self.isRequesting = YES;
    [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getUserLookAndTellInfoWithUserId:self.myInfo.rosterInfo.username pageNum:self.pageIndex rows:_lookAndTellPageSize_ visible:[self visible]]];
}

- (void)loadInitView
{
    if(self.operationStyle == JBoMsgOperationVStyleScene)
    {
        UIImage *releaseImage = [UIImage imageNamed:@"newsRelease"];
        [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(sceneLookAndTellRelease) title:nil backgroundImage:releaseImage textColor:nil];
    }
    
    
    
    switch (self.operationStyle)
    {
        case JBoMsgOperationUserOperation :
        {
          
            JBoCustomFilterBar *filterBar = [[JBoCustomFilterBar alloc] initWithFrame:
                                             CGRectMake(0, 0, _width_, _defaultFilterBarHeight_) titles:
                                             [NSArray arrayWithObjects:@"全部", @"公开", @"私密", nil] icons:
                                             [NSArray arrayWithObjects:
                                              [UIImage imageNamed:@"visible_all"],
                                              [UIImage imageNamed:@"visible_public"],
                                              [UIImage imageNamed:@"visible_private"],
                                              nil]];
            filterBar.delegate = self;
            [self.view addSubview:filterBar];
            self.filterBar = filterBar;
            [filterBar release];
        }
            break;
        case JBoMsgOperationVStyleScene :
        {
            
        }
        default:
            break;
    }
   
  
    CGRect frame = CGRectMake(0, self.filterBar.bottom, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - self.filterBar.height);
    UITableView *tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = [UIColor clearColor];
    //_tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:tableView];
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
    
    JBoUserTableHeaderView *tableHeaderView = [[JBoUserTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tableHeaderViewHeight_)];
    switch (self.operationStyle)
    {
        case JBoMsgOperationUserOperation :
        {
            tableHeaderView.nameLabel.text = @"我参加的活动";
        }
            break;
        case JBoMsgOperationVStyleScene :
        {
            tableHeaderView.nameLabel.text = self.myInfo.rosterInfo.name;
        }
            break;
        default:
            break;
    }
    
    tableHeaderView.nameLabel.sex = self.myInfo.rosterInfo.sex;
    tableHeaderView.bgImageView.userId = [JBoUserOperation getUserId];
    tableHeaderView.delegate = self;
    tableHeaderView.backgroundColor = [UIColor clearColor];
    tableHeaderView.headImageView.role = self.myInfo.rosterInfo.role;
    
    if(self.myInfo.rosterInfo.image)
    {
        tableHeaderView.headImageView.imageView.image = self.myInfo.rosterInfo.image;
    }
    else
        
    {
        tableHeaderView.headImageView.sex = self.myInfo.rosterInfo.sex;
    }
    
    tableHeaderView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = tableHeaderView;
    [tableHeaderView release];
    
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
    }
#endif
}

#pragma mark- filterBar 代理

- (void)filterBar:(JBoCustomFilterBar *)filterBar didSelectedAtIndex:(NSInteger)index
{
    self.pageIndex = 1;
    self.filter = YES;
    [self loadInfo:NO];
}

- (NSInteger)visible
{
    if(self.operationStyle == JBoMsgOperationVStyleScene)
        return _lookAndTellVisiblePublic_;
    
    switch (self.filterBar.selectedIndex)
    {
        case 0 :
        {
            return NSNotFound;
        }
            break;
        case 1 :
        {
            return _lookAndTellVisiblePublic_;
        }
            break;
        case 2 :
        {
            return _lookAndTellVisiblePrivate_;
        }
            break;
        default:
            break;
    }
    return NSNotFound;
}

#pragma mark-JBoLookAndTellTableHeaderView代理

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView bgImageDidTapped:(UIView *)view
{
    JBoCircleBgViewController *circleBgVC = [[JBoCircleBgViewController alloc] init];
    [self.navigationController pushViewController:circleBgVC animated:YES];
    [circleBgVC release];
}

- (void)tableHeaderView:(JBoUserTableHeaderView *)tableHeaderView headImageDidTapped:(JBoUserHeadImageView *)headImageView
{
    switch (self.operationStyle)
    {
        case JBoMsgOperationUserOperation :
        {
            JBoMyCraticActivityViewController *lays = [[JBoMyCraticActivityViewController alloc] init];
            [self.navigationController pushViewController:lays animated:YES];
            [lays release];
        }
            break;
        case JBoMsgOperationVStyleScene :
        {
            
        }
            break;
        default:
            break;
    }
}

#pragma mark-tableView代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self userLookAndTellHeightForIndexPath:indexPath style:self.operationStyle];
}


- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    static NSString *defaultIdentifier = @"default";
    static NSString *shareLinkIdentifier = @"sharelink";
    static NSString *shortMovieIdentifier = @"shortMovie";
    
    NSString *cellIdentifier = defaultIdentifier;
    JBoLookAndTellCellStyle style = JBoLookAndTellCellStyleDefault;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cellIdentifier = shareLinkIdentifier;
            style = JBoLookAndTellCellStyleLinkShare;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cellIdentifier = shortMovieIdentifier;
            style = JBoLookAndTellCellStyleShortMovie;
        }
            break;
        default:
            break;
    }
    
    
    JBoUserLookAndTellCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoUserLookAndTellCell alloc] initWithCellStyle:style reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.msgOperationView.canComplaint = NO;
    }
    
    info.operationInfo.selected = [self.relateGroupId isEqualToString:info.groupId];
    cell.status = info.enterpriseId == _laysEnterpriseTransmitNormal_ ? info.generalId : info.enterpriseId;
    
    cell.msgOperationView.info = info;
    cell.msgOperationView.style = self.operationStyle;
    
    cell.msgOperationView.index = indexPath.row;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cell.linkView.shareView.htmlTitleLabel.text = info.urlTitle;
            cell.linkView.shareURL = info.url;
            cell.linkView.srcArray = info.multiInfo;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cell.shareShortMovieView.srcArray = info.multiInfo;
        }
            break;
        default:
        {
            cell.multiImageTextView.hasMoreText = info.hasMoreText;
            cell.multiImageTextView.srcArray = info.multiInfo;
        }
            break;
    }
    
    if(indexPath.row != 0)
    {
        JBoLookAndTellListInfo *listInfo = [self.infoArray objectAtIndex:indexPath.row - 1];
        cell.dateView.sameDay = [JBoDatetimeTool isOnTheSameDay:listInfo.date otherDay:info.date];
    }
    else
    {
        cell.dateView.sameDay = NO;
    }
    cell.dateView.time = info.date;
    
    return cell;
}

#pragma mark-alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        self.httpRequest.identifier = _removeLookAndTellIdentifier_;
        [self.httpRequest startDataLoading];
         self.isRequesting = YES;
        JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:self.currentIndex];
        [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getRemoveLookAndTellWithGroupId:info.groupId]];
    }
}

#pragma mark- scrollView代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!_bottomLoadingView)
        {
            //创建加载更多视图
            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            _bottomLoadingView.backgroundColor = [UIColor clearColor];
        }
        if(!self.isRequesting && self.hasInfo)
        {
            self.pageIndex ++;
            self.tableView.tableFooterView = _bottomLoadingView;
            [self loadInfo:YES];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
