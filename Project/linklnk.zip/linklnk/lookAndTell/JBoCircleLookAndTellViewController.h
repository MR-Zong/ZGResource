//
//  JBoCircleLookAndTellViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLookAndTellViewController.h"

/**超友圈
 */
@interface JBoCircleLookAndTellViewController : JBoLookAndTellViewController <UIActionSheetDelegate,UIAlertViewDelegate>

@end
