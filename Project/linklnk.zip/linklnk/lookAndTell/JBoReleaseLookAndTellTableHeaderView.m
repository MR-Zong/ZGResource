//
//  JBoReleaseLookAndTellTableHeaderView.m
//  连你
//
//  Created by kinghe005 on 14-3-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoReleaseLookAndTellTableHeaderView.h"
#import "SSTextView.h"
#import "JBoAppDelegate.h"

#import "JBoLookAndTellOperation.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageOperationView.h"
#import "JBoImageOperationPreviewedViewController.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoMultiImageView.h"
#import "JBoImageTextTool.h"
#import "JBoRosterListViewController.h"
#import "JBoCheckBoxTextView.h"
#import "JBoNavigationViewController.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoUserPrivacyViewController.h"
#import "JBoLookAndTellTypeSelectedViewController.h"
#import "JBoMapViewController.h"

#define _padding_ 10
#define _imageSize_ 100
#define _controlInterval_ 5
#define _controlHeight_ 30

#define _deleteActionSheetTag_ 200
#define _textViewStartTag_ 1500
#define _imageOperationViewTag_ 10000
#define _alertLabelTag_ 2000
#define _maxMultis_ 3
#define _bottomViewTag_ 3000

static NSString *const activityPlaceHolder = @"关联场景后,陌生人可通过场景匹配找到你,每段限1000字,超出部分以红色显示";
static NSString *const generalPlaceHolder = @"你的心情你做主!\n陌生人不能查看,所有人不能评论\n每段限1000字,超出部分以红色显示";

static NSString *const activityPlaceHolder_5 = @"关联场景后,陌生人可通过场景匹配找到你,每段限1000字";
static NSString *const generalPlaceHolder_5 = @"你的心情你做主!\n陌生人不能查看,所有人不能评论\n每段限1000字";


@interface JBoReleaseLookAndTellTableHeaderView ()<JBoImageOperationViewDelegate,UITextViewDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,JBoImageOperationPreviewedViewControllerDelegate,JBoCheckBoxTextViewDelegate,JBoMutiImagePickerDelegate,JBoCustomFilterBarDelegate,UIGestureRecognizerDelegate,BMKGeoCodeSearchDelegate,BMKLocationServiceDelegate,JBoMapViewControllerDelegate>
{
    JBoAppDelegate *_appDelegate;
    BMKLocationService *_locationManager;
    BMKGeoCodeSearch *_addrSearch;
}

@property(nonatomic,retain) JBoImageOperationView *imageOperationView;
@property(nonatomic,retain) JBoImageOperationView *secondImageOperationView;
@property(nonatomic,retain) JBoImageOperationView *thirdImageOperationView;

@property(nonatomic,assign) NSInteger selectedIndex;

@property(nonatomic,assign) CGFloat scrollViewHeight;
@property(nonatomic,retain) UITapGestureRecognizer *reconverGesture;

//活动类型
@property(nonatomic,retain) UIView *typeSelectedView;
@property(nonatomic,readonly) UILabel *activityTypeLabel;
@property(nonatomic,readonly) JBoCheckBoxTextView *needTextImageCheckBox;

//许可协议
@property(nonatomic,retain) UIView *protocolView;

//位置
@property(nonatomic,readonly) UILabel *addressLabel;
@property(nonatomic,readonly) UIButton *currentLocationButton;
@property(nonatomic,readonly) UIButton *otherLocationButton;
@property(nonatomic,readonly) UIActivityIndicatorView *actView;

@property(nonatomic,copy) NSString *generPlaceHolder;
@property(nonatomic,copy) NSString *activityPlaceHolder;

//是否定位
@property(nonatomic,assign) BOOL locating;


@end

@implementation JBoReleaseLookAndTellTableHeaderView

- (id)initWithFrame:(CGRect)frame type:(JBoReleaseLookAndTellType)type
{
    self = [super initWithFrame:frame];
    if(self)
    {
        if(_ios6_0_)
        {
            self.generPlaceHolder = generalPlaceHolder;
            self.activityPlaceHolder = activityPlaceHolder;
        }
        else
        {
            self.generPlaceHolder = generalPlaceHolder_5;
            self.activityPlaceHolder = activityPlaceHolder_5;
        }
        
        self.clipsToBounds = YES;
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        if(type == JBoReleaseLookAndTellTypeDefault)
        {
            self.filterBar = [[[JBoCustomFilterBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _defaultFilterBarHeight_) titles:[NSArray arrayWithObjects:@"图文", @"关联场景的图文", nil] icons:nil] autorelease];
            self.filterBar.delegate = self;
            self.filterBar.backgroundColor = [UIColor whiteColor];
            [self addSubview:self.filterBar];
        }
        
        UITapGestureRecognizer *reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyborad:)];
        reconverGesture.delegate = self;
        [self addGestureRecognizer:reconverGesture];
        self.reconverGesture = reconverGesture;
        [reconverGesture release];
        
        // multis = multis > _maxMultis_ ? _maxMultis_ : multis;
        
        CGFloat height = 112.5;
        CGFloat labelHeight = 20.0;
        
        
        self.imageArray = [[[NSMutableArray alloc] init] autorelease];
        self.thirdImageArray = [[[NSMutableArray alloc] init] autorelease];
        self.secondImageArray = [[[NSMutableArray alloc] init] autorelease];
        
        CGFloat y = self.filterBar != nil ? _defaultFilterBarHeight_ : 0;
        
        for(NSInteger i = 0;i < _maxMultis_; i++)
        {
            SSTextView *textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_ + y + (height + labelHeight + _padding_ * 3 + _imageOperationDefaultCellSize_) * i, _width_ - _padding_ * 2, height)];
            textView.layer.cornerRadius = 6;
            textView.layer.borderWidth = 0.2;
            textView.returnKeyType = UIReturnKeyDone;
            textView.layer.borderColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0].CGColor;
            textView.font = [UIFont systemFontOfSize:17];
            textView.delegate = self;
            textView.textColor = [UIColor blackColor];

            //textView.maxCount = _inputFormatLookAndTellNum_;
            //textView.limitable = YES;
            textView.tag = _textViewStartTag_ + i;
            [self addSubview:textView];
            [textView release];
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, textView.frame.origin.y + textView.frame.size.height + _padding_, _width_ - _padding_ * 2, labelHeight)];
            label.text = @"上传图片";
            label.tag = _alertLabelTag_ + i;
            label.textColor = [UIColor grayColor];
            label.backgroundColor = [UIColor clearColor];
            [self addSubview:label];
            [label release];
            
            JBoImageOperationView *imageOperationView = [[JBoImageOperationView alloc] initWithFrame:CGRectMake(_padding_, label.frame.origin.y + label.frame.size.height + _padding_, _width_ - _padding_ * 2, _imageOperationDefaultCellSize_) srcArray:self.imageArray imageSize:_imageOperationDefaultCellSize_];
            imageOperationView.backgroundColor = [UIColor whiteColor];
            imageOperationView.delegate = self;
            imageOperationView.maxCount = 9;
            imageOperationView.tag = _imageOperationViewTag_ + i;
            [self addSubview:imageOperationView];
            [imageOperationView release];
            
        }
        
        self.contentTextView = (SSTextView*)[self viewWithTag:_textViewStartTag_];
       
        self.contentTextView.placeholder = self.generPlaceHolder;
        self.secondTextView = (SSTextView*)[self viewWithTag:_textViewStartTag_ + 1];
        self.secondTextView.placeholder = self.activityPlaceHolder;
        self.thirdTextView = (SSTextView*)[self viewWithTag:_textViewStartTag_ + 2];
        self.thirdTextView.placeholder = self.activityPlaceHolder;
        
        self.imageOperationView = (JBoImageOperationView*)[self viewWithTag:_imageOperationViewTag_];
        self.imageOperationView.srcArray = self.imageArray;
        self.secondImageOperationView = (JBoImageOperationView*)[self viewWithTag:_imageOperationViewTag_ + 1];
        self.secondImageOperationView.srcArray = self.secondImageArray;
        self.thirdImageOperationView = (JBoImageOperationView*)[self viewWithTag:_imageOperationViewTag_ + 2];
        self.thirdImageOperationView.srcArray = self.thirdImageArray;
        
        //使用条款
        self.protocolView = [JBoUserOperation getProtocolViewWithFrame:CGRectMake(_padding_, 0, _width_ - _padding_ * 2, 0) target:self action:@selector(serverProtocolAction:)];
        [self addSubview:self.protocolView];
        
        self.lookAndTellType = _lookAndTellTypeNormal_;
        [self filterBar:self.filterBar didSelectedAtIndex:0];
        self.mapInfo = [[[JBoMapInfo alloc] init] autorelease];
        
    }
    return self;
}


- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame multis:1];
}

- (id)initWithFrame:(CGRect)frame multis:(NSInteger)multis
{
    self = [super initWithFrame:frame];
    if(self)
    {
       
    }
    
    return self;
}

- (void)viewWillDisAppear
{
    self.locating = NO;
    [_actView stopAnimating];
    
    if(_locationManager)
    {
        [_locationManager stopUserLocationService];
        _locationManager.delegate = nil;
        
        [_locationManager release];
        _locationManager = nil;
    }
    
    if(_addrSearch)
    {
        _addrSearch.delegate = nil;
        [_addrSearch release];
        _addrSearch = nil;
    }
}

#pragma mark-filterBar代理

- (void)filterBar:(JBoCustomFilterBar *)filterBar didSelectedAtIndex:(NSInteger)index
{
    [self setNeedsLayout];
}

- (BOOL)filterBar:(JBoCustomFilterBar *)filterBar canSelectedAtIndex:(NSInteger)index
{
    switch (index)
    {
        case 0 :
            return YES;
            break;
        case 1 :
        {
            return YES;
        }
        default:
        {
            return YES;
        }
            break;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    NSInteger index = self.filterBar.selectedIndex;
    if(!_activityTypeLabel)
    {
        CGFloat width = _width_ - _padding_ * 2;
        CGFloat controHeight = 30.0;
        
        
        UIView *typeView = [[UIView alloc] initWithFrame:CGRectZero];
        typeView.backgroundColor = [UIColor whiteColor];
        typeView.layer.cornerRadius = 5.0;
        typeView.tag = _bottomViewTag_;
        [self addSubview:typeView];
        self.typeSelectedView = typeView;
        [typeView release];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(activityTypeSelected:)];
        _activityTypeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_padding_ / 2, 0, width / 3, controHeight + _padding_)];
        _activityTypeLabel.userInteractionEnabled = YES;
        [_activityTypeLabel addGestureRecognizer:tap];
        [tap release];
        _activityTypeLabel.backgroundColor = [UIColor clearColor];
        _activityTypeLabel.text = @"目的场景";
        [typeView addSubview:_activityTypeLabel];
        
        UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(activityTypeSelected:)];
        _activityContentLabel = [[UILabel alloc] initWithFrame:CGRectMake(width / 3 , 0, width * 2 / 3 - 25, _activityTypeLabel.frame.size.height)];
        _activityContentLabel.userInteractionEnabled = YES;
        [_activityContentLabel addGestureRecognizer:tap2];
        [tap2 release];
        _activityContentLabel.backgroundColor = [UIColor clearColor];
        _activityContentLabel.textColor = [UIColor grayColor];
        [_activityContentLabel setTextAlign:JBoTextAlignmentRight];
        [typeView addSubview:_activityContentLabel];
        
        CGFloat lineHeight = 0.5;
        UIColor *lineColor = [UIColor colorWithWhite:0.2 alpha:0.4];
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, _activityContentLabel.frame.origin.y + _activityContentLabel.frame.size.height - _padding_ / 2, width, lineHeight)];
        lineView.backgroundColor = lineColor;
        [typeView addSubview:lineView];
        [lineView release];
        
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        imageView.frame = CGRectMake(_activityContentLabel.frame.origin.x + _activityContentLabel.frame.size.width + 5.0, (_activityContentLabel.frame.size.height - image.size.height) / 2, image.size.width, image.size.height);
        [typeView addSubview:imageView];
        [imageView release];
        
        CGFloat locationButtonWidth = 80;
        UIImage *icon = [UIImage imageNamed:@"location_icon"];
        UIImageView *locationIcon = [[UIImageView alloc] initWithFrame:CGRectMake(_padding_ / 2, _activityContentLabel.frame.origin.y + _activityContentLabel.frame.size.height + lineHeight + (_controlHeight_ - icon.size.height) / 2, icon.size.width, icon.size.height)];
        locationIcon.image = icon;
        [typeView addSubview:locationIcon];
        [locationIcon release];
        
        //位置地址
        _addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(locationIcon.frame.origin.x + locationIcon.frame.size.width + _controlInterval_, _activityContentLabel.frame.origin.y + _activityContentLabel.frame.size.height + lineHeight, width - locationIcon.frame.origin.x * 2 - locationIcon.frame.size.width - _controlInterval_, _controlHeight_)];
        //_addressTextView.textAlignment = NSTextAlignmentCenter;
        _addressLabel.textColor = [UIColor blackColor];
        _addressLabel.numberOfLines = 0;
        _addressLabel.adjustsFontSizeToFitWidth = YES;
        _addressLabel.font = [UIFont systemFontOfSize:14.0];
        _addressLabel.hidden = YES;
        [typeView addSubview:_addressLabel];
        
        
        UIImage *uploadImage = [UIImage imageNamed:@"upload_btn"];
        _currentLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_currentLocationButton setTitle:@"定位当前" forState:UIControlStateNormal];
        [_currentLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_currentLocationButton setBackgroundImage:uploadImage forState:UIControlStateNormal];
        [_currentLocationButton addTarget:self action:@selector(currentLocation) forControlEvents:UIControlEventTouchUpInside];
        [_currentLocationButton setFrame:CGRectMake(locationIcon.frame.origin.x, _addressLabel.frame.size.height + _addressLabel.frame.origin.y + _controlInterval_, locationButtonWidth, _controlHeight_)];
        [typeView addSubview:_currentLocationButton];
        
        _otherLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_otherLocationButton setTitle:@"其他位置" forState:UIControlStateNormal];
        [_otherLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_otherLocationButton setBackgroundImage:uploadImage forState:UIControlStateNormal];
        [_otherLocationButton addTarget:self action:@selector(otherLocation) forControlEvents:UIControlEventTouchUpInside];
        [_otherLocationButton setFrame:CGRectMake(width - _currentLocationButton.frame.origin.x - locationButtonWidth, _currentLocationButton.frame.origin.y, locationButtonWidth, _controlHeight_)];
        [typeView addSubview:_otherLocationButton];
        
        UIView *secondLineView = [[UIView alloc] initWithFrame:CGRectMake(0, _currentLocationButton.frame.origin.y + _currentLocationButton.frame.size.height + _controlInterval_, width, lineHeight)];
        secondLineView.backgroundColor = lineColor;
        [typeView addSubview:secondLineView];
        [secondLineView release];
        
        _needTextImageCheckBox = [[JBoCheckBoxTextView alloc] initWithFrame:CGRectMake(_padding_ / 2, secondLineView.frame.origin.y + secondLineView.frame.size.height, width, controHeight - lineHeight) title:@"参加活动是否需要上传图文"];
        _needTextImageCheckBox.delegate = self;
        [typeView addSubview:_needTextImageCheckBox];
        
        typeView.frame = CGRectMake(_padding_, self.filterBar.frame.origin.y + self.filterBar.frame.size.height + _padding_, width, _needTextImageCheckBox.frame.origin.y + _needTextImageCheckBox.frame.size.height);
        
        self.lookAndTellType = _lookAndTellTypeLays_;
    }
    
    //NSLog(@"%d",index);
    BOOL hidden = NO;
    CGFloat height = 0;
    CGFloat y = 0;
    
    switch (index)
    {
        case 0 :
        {
            self.typeSelectedView.hidden = YES;
            hidden = YES;
            self.lookAndTellType = _lookAndTellTypeNormal_;
            y = self.filterBar.frame.size.height + self.filterBar.frame.origin.y + _padding_;
            self.revealVC.panGestureRecognizer.enabled = NO;
        }
            break;
        case 1 :
        {
            self.typeSelectedView.hidden = NO;
            y = self.typeSelectedView.frame.origin.y + self.typeSelectedView.frame.size.height + _padding_;
            self.revealVC.panGestureRecognizer.enabled = YES;
        }
            break;
        default:
            break;
    }
    
    self.contentTextView.placeholder = hidden ? self.generPlaceHolder : self.activityPlaceHolder;
    [self.contentTextView setNeedsDisplay];
    
    for(NSInteger i = 0;i < _maxMultis_;i ++)
    {
        SSTextView *textView = (SSTextView*)[self viewWithTag:_textViewStartTag_ + i];
        UIView *imageView = [self viewWithTag:_imageOperationViewTag_ + i];
        UIView *label = [self viewWithTag:_alertLabelTag_ + i];
        
        if(i != 0)
        {
            textView.hidden = hidden;
            imageView.hidden = hidden;
            label.hidden = hidden;
        }
        
        textView.frame = CGRectMake(textView.frame.origin.x, y + (textView.frame.size.height + label.frame.size.height + _padding_ * 3 + _imageOperationDefaultCellSize_) * i, textView.frame.size.width, textView.frame.size.height);
        label.frame = CGRectMake(label.frame.origin.x, textView.frame.size.height + textView.frame.origin.y + _padding_, label.frame.size.width, label.frame.size.height);
        imageView.frame = CGRectMake(imageView.frame.origin.x, label.frame.origin.y + label.frame.size.height + _padding_, imageView.frame.size.width, imageView.frame.size.height);
    }
    
    height = hidden ? self.imageOperationView.frame.origin.y + self.imageOperationView.frame.size.height : self.thirdImageOperationView.frame.origin.y + self.thirdImageOperationView.frame.size.height;;
    
    self.protocolView.top = height + _padding_;
    
    [UIView animateWithDuration:0.25 animations:^(void)
     {
         self.frame = CGRectMake(0, 0, _width_, self.protocolView.bottom + _padding_);
         self.tableView.tableHeaderView = nil;
         self.tableView.tableHeaderView = self;
     }];

}

- (void)activityTypeSelected:(UITapGestureRecognizer*) tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    [self.revealVC setFrontViewPosition:FrontViewPositionLeftSide animated:YES];
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if([touch.view isEqual:self.typeSelectedView] || [touch.view isEqual:self.activityContentLabel] || [touch.view isEqual:self.activityTypeLabel] || [touch.view isEqual:self.filterBar] || [touch.view isKindOfClass:[UIButton class]])
    {
        return NO;
    }
    return YES;
}

#pragma mark-JBoCheckBoxTextView代理
- (void)selectedStateDidChanged:(JBoCheckBoxTextView *)checkBox
{
    self.needImageText = checkBox.checkBox.selected;
}

#pragma mark-键盘
- (void)reconverKeyborad:(id) sender
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (void)serverProtocolAction:(UIButton*) button
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    JBoUserPrivacyViewController *userPrivacy = [[JBoUserPrivacyViewController alloc] init];
    [self.navigationController pushViewController:userPrivacy animated:YES];
    [userPrivacy release];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoReleaseLookAndTellTableHeaderView dealloc");
    
    [_contentTextView release];
    [_secondTextView release];
    [_thirdTextView release];
    
    [_imageOperationView release];
    [_secondImageOperationView release];
    [_thirdImageOperationView release];
    
    
    [_imageArray release];
    [_secondImageArray release];
    [_thirdImageArray release];
    
    [_reconverGesture release];
    
    [_filterBar release];
    
    [_activityContentLabel release];
    [_activityTypeLabel release];
    [_needTextImageCheckBox release];
    
    [_protocolView release];
    [_addressLabel release];
    [_actView release];
    [_locationManager release];
    [_addrSearch release];
    [_mapInfo release];
    
    [_generPlaceHolder release];
    [_activityPlaceHolder release];
    
    [super dealloc];
}

#pragma mark-textView代理
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.scrollViewHeight = self.tableView.frame.size.height;
    self.tableView.frame = CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y, self.tableView.frame.size.width, self.tableView.frame.size.height - 216);
    self.tableView.contentOffset = CGPointMake(0, textView.frame.origin.y - _padding_);
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
     self.tableView.frame = CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y, self.tableView.frame.size.width, self.scrollViewHeight);
    CGFloat y = textView.frame.origin.y - 216;
    self.tableView.contentOffset = CGPointMake(0, y < 0 ? 0 : y);
}

- (void)textViewDidChange:(UITextView *)textView
{
   // NSLog(@"textViewDidChange");
    
    NSString *text = textView.text;

    if(text.length > _inputFormatLookAndTellNum_)
    {
        if(_ios6_0_)
        {
#ifdef __IPHONE_6_0
            SSTextView *sst = (SSTextView*)textView;
            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
            [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(_inputFormatLookAndTellNum_, text.length - _inputFormatLookAndTellNum_)];
            [attributedText addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:17.0] range:NSMakeRange(0, text.length)];
            sst.attributedText = attributedText;
            [attributedText release];
#endif
        }
        else
        {
            textView.text = [text substringToIndex:_inputFormatLookAndTellNum_];
        }
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    // NSLog(@"--%@-- %d",text,range.length);
    if([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

#pragma mark-JBoImageOperationView代理

- (void)imageOperationViewDidAddedCell:(JBoImageOperationView *)selectedView
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    self.selectedIndex = selectedView.tag - _imageOperationViewTag_;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
    [actionSheet showInView:self.navigationController.view];
    [actionSheet release];
}

- (void)imageOperationView:(JBoImageOperationView *)selctedView didSelectImageAtIndex:(NSInteger)index
{
    self.selectedIndex = selctedView.tag - _imageOperationViewTag_;
    JBoImageOperationPreviewedViewController *previewVC = [[JBoImageOperationPreviewedViewController alloc] init];
    previewVC.srcArray = selctedView.srcArray;
    previewVC.currentIndex = index;
    previewVC.delegate = self;
    [self.navigationController pushViewController:previewVC animated:YES];
    [previewVC release];
}

- (void)imageOperationViewDidReloadData:(JBoImageOperationView *)selctedView
{
    _appDelegate.dataLoadingView.hidden = YES;
}

#pragma mark-JBoImageOperationPreviewedViewController代理
- (void)imageOperationPreviewedViewController:(JBoImageOperationPreviewedViewController *)viewController didRemoveImageAtIndex:(NSInteger)index
{
    JBoImageOperationView *imageOperationView = (JBoImageOperationView*)[self viewWithTag:_imageOperationViewTag_ + self.selectedIndex];
    [imageOperationView removeImageAtIndex:index];
}

#pragma makr-actionsheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [self getCamera];
    }
    else if(buttonIndex == 1)
    {
        [self getPhotos];
    }
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
   // NSLog(@"拍照");
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        JBoImageOperationView *imageOperationView = (JBoImageOperationView*)[self viewWithTag:_imageOperationViewTag_ + self.selectedIndex];
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        [imageOperationView.srcArray addObject:[JBoImageTextTool getThumbnailFromImage:retImage withSize:size]];
      
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 [imageOperationView updateContent];
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("album", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [_appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoImageOperationView *imageOperationView = (JBoImageOperationView*)[self viewWithTag:_imageOperationViewTag_ + self.selectedIndex];
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)imageOperationView.maxCount - (int)imageOperationView.srcArray.count;;
    mutilImagePicker.title = @"相册";
    JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:mutilImagePicker];
    nav.black = NO;
    [self.navigationController presentViewController:nav animated:YES completion:nil];
    
    [mutilImagePicker release];
    [nav release];
}

#pragma mark-JBoMutilImagePickerViewController代理
- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    _appDelegate.dataLoadingView.hidden = NO;

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        if(assetArray.count > 0)
        {
            for(ALAsset *asset in assetArray)
            {
               // NSLog(@"开始2");
                UIImage *image = [UIImage imageWithCGImage:[[asset defaultRepresentation] fullScreenImage]];
                CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                
                //NSLog(@"开始4");
                switch (self.selectedIndex)
                {
                    case 0 :
                    {
                        [self.imageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
                    }
                        break;
                    case 1 :
                    {
                        [self.secondImageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
                    }
                        break;
                    case 2 :
                    {
                        [self.thirdImageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
                    }
                        break;
                    default:
                        break;
                }
               // NSLog(@"开始5");
            }
        }
        [self imageDidSelecedWithPicker:viewController];
    });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        
        //NSLog(@"开始4");
        switch (self.selectedIndex)
        {
            case 0 :
            {
                [self.imageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
            }
                break;
            case 1 :
            {
                [self.secondImageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
            }
                break;
            case 2 :
            {
                [self.thirdImageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
            }
                break;
            default:
                break;
        }
        
        [self imageDidSelecedWithPicker:viewController];
    });
}

- (void)imageDidSelecedWithPicker:(UIViewController*) picker
{
    dispatch_async(dispatch_get_main_queue(), ^(void){
        [picker dismissViewControllerAnimated:YES completion:^(void)
         {
             switch (self.selectedIndex)
             {
                 case 0 :
                     [_imageOperationView updateContent];
                     break;
                 case 1 :
                     [self.secondImageOperationView updateContent];
                     break;
                 case 2 :
                     [self.thirdImageOperationView updateContent];
                     break;
                 default:
                     break;
             }
             _appDelegate.dataLoadingView.hidden = YES;
         }];
    });
}

#pragma mark-位置
//位置
- (void)currentLocation
{
    _addressLabel.hidden = YES;
    if(!_actView)
    {
        CGFloat size = 30;
        _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _actView.hidesWhenStopped = YES;
        _actView.frame = CGRectMake(_addressLabel.frame.origin.x, _addressLabel.frame.origin.y + (_addressLabel.frame.size.height - size) / 2, size, size);
        UIView *view = [self viewWithTag:_bottomViewTag_];
        [view addSubview:_actView];
    }
    
    [_actView startAnimating];
    [self location];
}

- (void)otherLocation
{
    [self viewWillDisAppear];
    
    JBoMapViewController *mapVC = [[JBoMapViewController alloc] init];
    mapVC.delegate = self;
    mapVC.isSender = YES;
    mapVC.black = YES;
    if(self.isLocation)
    {
      //  mapVC.currentCoordinate = self.currentCoordinate;
    }
    
    [self.navigationController pushViewController:mapVC animated:YES];
    [mapVC release];
}

- (void)mapViewControllerWillDisAppear:(JBoMapViewController *)mapView
{
    
}

- (void)mapViewController:(JBoMapViewController *)mapView didLocatedWithInfo:(NSDictionary *)userInfo
{
//    NSString *str = [userInfo objectForKey:_locationInfo_];
//    
//    NSDictionary *coorDic = [JBoImageTextTool getCoordinateFromString:str];
//    
//    _addressLabel.text = [[coorDic allKeys] objectAtIndex:0];
//    NSArray *array = [[coorDic allValues] objectAtIndex:0];
//    
//    NSString *lat = [array objectAtIndex:0];
//    NSString *lon = [array objectAtIndex:1];
    self.isLocation = YES;
    //self.currentCoordinate = CLLocationCoordinate2DMake([lat doubleValue], [lon doubleValue]);
    
}

- (void)finishLocation:(BOOL) success
{
    NSLog(@"定位完成");
    [_actView stopAnimating];
    _addressLabel.hidden = NO;
    if(success)
    {
        self.isLocation = YES;
      //  _addressLabel.text = self.addrInfo;
    }
    else
    {
        self.isLocation = NO;
        _addressLabel.text = @"无法确定您当前的位置";
        
        [JBoUserOperation openSystemSettingsAlertViewWithDelegate:self];
    }
    self.locating = NO;
}

#pragma mark- UIAlertView delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:_alertButtonTitleWhenCannotLocate_])
    {
        [JBoUserOperation openSystemSettings];
    }
}

#pragma mark- BMKGeoSearch delegate

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(error != BMK_SEARCH_NO_ERROR)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        [self viewWillDisAppear];
        return;
    }
    
   // self.addrInfo = result.strAddr;
    self.isLocation = YES;
    [self finishLocation:YES];
    [self viewWillDisAppear];
}

#pragma mark-定位

- (void)location
{
    if([CLLocationManager locationServicesEnabled])
    {
        if(!_locationManager)
        {
            _locationManager = [[BMKLocationService alloc] init];
            _locationManager.delegate = self;
        }

        self.locating = YES;
        [_locationManager startUserLocationService];
    }
    else
    {
        [self finishLocation:NO];
    }
}

#pragma mark- BMKLocationService delegate

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {
        //self.currentCoordinate = userLocation.location.coordinate;
        
        if(!_addrSearch)
        {
            _addrSearch = [[BMKGeoCodeSearch alloc] init];
            _addrSearch.delegate = self;
        }
        
//        if([_addrSearch reverseGeocode:self.currentCoordinate])
//        {
//            NSLog(@"地理反编码");
//        }
        [_locationManager stopUserLocationService];
    }
}


- (void)didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"定位失败");
    [_locationManager stopUserLocationService];
    [self finishLocation:NO];
}



@end

