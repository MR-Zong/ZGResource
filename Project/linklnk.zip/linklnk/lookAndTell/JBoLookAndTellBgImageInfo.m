//
//  JBoLookAndTellBgImageInfo.m
//  连你
//
//  Created by kinghe005 on 14-2-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellBgImageInfo.h"

@implementation JBoLookAndTellBgImageInfo

- (void)dealloc
{
    [_image release];
    [_ID release];
    [_imageURL release];
    
    [super dealloc];
}

@end
