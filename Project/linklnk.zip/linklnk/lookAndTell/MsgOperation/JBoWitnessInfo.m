//
//  JBoWitnessInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoWitnessInfo.h"

@implementation JBoWitnessInfo

- (void)dealloc
{
    [_name release];
    
    [_headImageURL release];
    
    [super dealloc];
}

@end
