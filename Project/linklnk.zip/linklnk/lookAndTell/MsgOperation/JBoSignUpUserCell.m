//
//  JBoSignUpUserCell.m
//  靓咖
//
//  Created by kinghe005 on 14-7-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSignUpUserCell.h"
#import "JBoBasic.h"


@implementation JBoSignUpUserCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_signUpUserCellInterval_, _signUpUserCellInterval_, _signUpUserCellHeadImageSize_, _signUpUserCellHeadImageSize_)];
        [self.contentView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _signUpUserCellInterval_, _headImageView.top, self.width - _signUpUserCellInterval_ * 2 - _headImageView.right, _signUpUserCellNameHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        _signUpInfoLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _nameLabel.bottom, _nameLabel.width, _headImageView.height - _nameLabel.height)];
        _signUpInfoLabel.font = _signUpUserInfoFont_;
        _signUpInfoLabel.backgroundColor = [UIColor clearColor];
        _signUpInfoLabel.textColor = [UIColor blackColor];
        _signUpInfoLabel.recognizeURL = NO;
        
        _signUpInfoLabel.textInset = _signUpUserInfoTextInset_;
        _signUpInfoLabel.minLineHeight = _signUpUserInfoMinLineHeight_;
      //  _signUpInfoLabel.delegate = self;
        [self.contentView addSubview:_signUpInfoLabel];
    }
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    [_headImageView release];
    [_nameLabel release];
    [_signUpInfoLabel release];
    
    [super dealloc];
}

#pragma mark- JBoImageTextLabel delegate

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(signUpUserCell:didSelectedURL:)])
    {
        [self.delegate signUpUserCell:self didSelectedURL:url];
    }
}

- (void)setHideSignupInfo:(BOOL)hideSignupInfo
{
    _hideSignupInfo = hideSignupInfo;
    _signUpInfoLabel.hidden = hideSignupInfo;
}

- (void)layoutSubviews
{
    if(!self.hideSignupInfo)
    {
        CGRect frame = _signUpInfoLabel.frame;
        frame.size.height = _signUpInfoHeight;
        _signUpInfoLabel.frame = frame;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
