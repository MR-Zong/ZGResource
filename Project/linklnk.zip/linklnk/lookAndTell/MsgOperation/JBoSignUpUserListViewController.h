//
//  JBoSignUpUserListViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoLookAndTellListInfo;

/**靓友圈活动报名的人
 */
@interface JBoSignUpUserListViewController : JBoViewController <UITableViewDataSource,UITableViewDelegate>

/**报名关联的说说
 */
@property(nonatomic,retain) JBoLookAndTellListInfo *info;


@end
