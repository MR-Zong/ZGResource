//
//  JBoSignInUserListViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSignInUserListViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoBottomLoadingView.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoSignInUserCell.h"
#import "JBoSignInInfo.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoImageTextTool.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserOperation.h"
#import "UITableView+extraCellLine.h"
#import "JBoDatetimeTool.h"
#import "JBoLuckyDrawView.h"
#import "JBoReuseScrollView.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoImageCacheTool.h"

@interface JBoSignInUserListViewController ()<JBoHttpRequestDelegate,EGORefreshTableHeaderDelegate,JBoLuckyDrawViewDelegate,JBoSignInUserCellDelegate,JBoReuseScrollViewDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
    
    EGORefreshTableHeaderView *_refreshView;
    BOOL _isLoading;
    
    JBoBottomLoadingView *_bottomLoadingView;
    
    //抽奖
    JBoLuckyDrawView *_luckyDrawView;
}

@property(nonatomic,retain) UITableView *tableView;

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) NSMutableArray *infoArray;
@property(nonatomic,assign) BOOL hasInfo;
@property(nonatomic,assign) NSInteger pageIndex;
@property(nonatomic,assign) NSInteger pageSize;

@property(nonatomic,retain) JBoReuseScrollView *reuseScrollView;

//中奖的人
@property(nonatomic,retain) NSMutableArray *luckyArray;

@end

@implementation JBoSignInUserListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        _isLoading = NO;
        self.isRequesting = NO;
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
        self.hasInfo = YES;
        
        self.pageIndex = 1;
        self.pageSize = 30;
        
        self.title = @"签到的人";

        self.black = YES;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    
    [_tableView release];
    [_groupId release];
    
    [_httpRequest release];
    [_refreshView release];
    
    [_bottomLoadingView release];
    [_infoArray release];

    [_luckyDrawView release];
    [_reuseScrollView release];
    [_luckyArray release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
    [_luckyDrawView endLuckyDraw];
}

#pragma mark-httpRequest
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取签到的人失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    NSMutableArray *array = [JBoLookAndTellOperation getSignInUsersFromData:data];
    if(array.count > 0)
    {
        self.pageIndex ++;
        self.hasInfo = array.count == self.pageSize;
        [self.infoArray addObjectsFromArray:array];
        if(!_tableView)
        {
            [self loadInitVew];
        }
        else
        {
            [_tableView reloadData];
        }
    }
    else
    {
        self.hasInfo = NO;
        [JBoUserOperation alertMsg:@"暂无签到的人"];
    }
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.view.backgroundColor = [UIColor whiteColor];
    self.backItem = YES;
    
    [self loadInfo:NO];
}

- (void)loadInitVew
{
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(luckyDraw:) title:@"抽奖" backgroundImage:nil textColor:[UIColor blackColor]];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
}

- (void)loadInfo:(BOOL) hidden
{
    self.isRequesting = YES;
    _appDelegate.dataLoadingView.hidden = hidden;
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation getSignInUsersWithId:self.groupId pageNum:self.pageIndex row:self.pageSize]];
}

#pragma mark-抽奖

- (void)luckyDraw:(id) sender
{
    if(!_luckyDrawView)
    {
        _luckyDrawView = [[JBoLuckyDrawView alloc] initWithFrame:CGRectMake(0, _height_, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        _luckyDrawView.srcArray = self.infoArray;
        _luckyDrawView.groupId = self.groupId;
        _luckyDrawView.delegate = self;
        _luckyDrawView.luckyArray = self.luckyArray;
        _luckyDrawView.navigationController = self.navigationController;
        _luckyDrawView.black = self.black;
        [self.view addSubview:_luckyDrawView];
    }
    
    _luckyDrawView.show = !_luckyDrawView.show;
}

- (void)luckyDrawView:(JBoLuckyDrawView *)luckyDrawView didLuckyAtIndex:(NSInteger)index
{
    NSLog(@"抽奖完成");
    _luckyDrawView.show = NO;
    [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

#pragma mark-tabelview代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return _headImageSize_ + _maxImageHeight_ + _paddding_ * 2;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoSignInUserCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoSignInUserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoSignInInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    cell.nameLabel.text = info.name;
    cell.nameLabel.sex = info.sex;
    cell.headImageView.role = info.role;
    
    [cell.locationImageView getImageWithURL:info.locationImageURL];
    
    cell.headImageView.sex = info.sex;
    cell.headImageView.headImageURL = info.headImageURL;
    
  //  cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.date];
    cell.addressLabel.text = info.address;
    
    return cell;
}

#pragma mark-JBoSignInUserCell代理
- (void)signInUserCellDidSelectedHeadImage:(JBoSignInUserCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoSignInInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    
    JBoRosterInfo *rosterInfo = [_appDelegate.rosterAndUsernameDic objectForKey:info.userId];
    if(rosterInfo)
    {
        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
        detail.rosterInfo = rosterInfo;
        detail.black = self.black;
        [self.navigationController pushViewController:detail animated:YES];
        [detail release];
    }
    else
    {
        JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
        userInfo.userId = info.userId;
        userInfo.black = self.black;
        [self.navigationController pushViewController:userInfo animated:YES];
        [userInfo release];
    }
}

- (void)signInUserCellDidSelectedLocationImage:(JBoSignInUserCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    NSInteger currentIndex = indexPath.row;
    
    self.reuseScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.reuseScrollView.delegate = self;
    self.reuseScrollView.currentIndex = currentIndex;
    [self.reuseScrollView reloadData];
    
    [self.reuseScrollView showInViewController:self];
}


#pragma mark-reuseScrollView代理

- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.infoArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        // NSLog(@"reuse cell");
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    JBoSignInInfo *info = [self.infoArray objectAtIndex:index];
    
    cell.titleLabel.text = info.address;
    cell.titleLabel.frame = CGRectMake(0, _height_ - 30, _width_, 30);
    scrollView.titleLabel.text = info.address;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *image = [cache getImageWithURL:info.locationImageURL thumbnailSize:CGSizeZero];
    
    // NSLog(@"%@",image);
    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:info.locationImageURL forIndex:index];
        }
    }
    //NSLog(@"reuse cell");
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    JBoSignInInfo *info = [self.infoArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *image = [cache getImageWithURL:info.locationImageURL thumbnailSize:CGSizeZero];
    
    if(!image)
    {
        [self downloadImageWithUrl:info.locationImageURL forIndex:index];
    }
}

- (BOOL)resuseScrollView:(JBoReuseScrollView *)scrollView isSameTitleAtIndex:(NSInteger)index withOtherIndex:(NSInteger)otherIndex
{
    if(otherIndex < 0 || otherIndex >= self.infoArray.count || index < 0 || index >= self.infoArray.count)
    {
        return YES;
    }
    
    JBoSignInInfo *info = [self.infoArray objectAtIndex:index];
    JBoSignInInfo *otherInfo = [self.infoArray objectAtIndex:otherIndex];
    
    return [info.Id isEqualToString:otherInfo.Id];
}

- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.reuseScrollView = nil;
    [_tableView reloadData];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];

    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.reuseScrollView cellForIndex:index];

        cell.imageView.image = image;
        [self.reuseScrollView reloadDataAtIndex:index];
    }];
}

#pragma mark-scrollView代理  在用户停止拖动和拖动停止减速时加载图片
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    //NSLog(@"addressBook scrollViewDidEndDragging");
    [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
}


- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [_refreshView egoRefreshScrollViewWillBeginScroll:scrollView];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_refreshView egoRefreshScrollViewDidScroll:scrollView];
    // NSLog(@"addressBook scrollViewDidScroll");
    
    if(scrollView.contentOffset.y < - 10.0)
    {
        _refreshView.hidden = NO;
    }
    else
    {
        _refreshView.hidden = YES;
    }
    //   NSLog(@"%f",scrollView.contentOffset.y);
    
    if(self.hasInfo && !_isLoading && !self.isRequesting)
    {
        if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
        {
            if(!_bottomLoadingView)
            {
                //创建加载更多视图
                _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            }

            _tableView.tableFooterView = _bottomLoadingView;
            [self loadInfo:YES];
        }
    }
}

#pragma mark-刷新数据

// 加载数据
- (void)reloadTableViewDataSource
{
    _isLoading = YES;
    self.pageIndex = 1;
    
    [self loadInfo:YES];
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading
{
    _isLoading = NO;
    
    [_tableView reloadData];
    [_refreshView performSelector:@selector(egoRefreshScrollViewDataSourceDidFinishedLoading:) withObject:_tableView afterDelay:0.1];
    // [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:_tableView];
}

//下拉刷新
- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
