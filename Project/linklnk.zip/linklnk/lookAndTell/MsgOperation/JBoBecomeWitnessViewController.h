//
//  JBoBecomeWitnessViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoBecomeWitnessViewController;

@protocol JBoBecomeWitnessViewControllerDelegate <NSObject>

@optional
- (void)becomeWitnessViewController:(JBoBecomeWitnessViewController*) viewController didFinishedWithInfo:(NSDictionary*) info;

@end

@interface JBoBecomeWitnessViewController : UIViewController

@property(nonatomic,assign) id<JBoBecomeWitnessViewControllerDelegate> delegate;
@property(nonatomic,copy) NSString *groupId;

@end
