//
//  JBoWitnessCell.m
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoWitnessCell.h"
#import "JBoBasic.h"
#import "JBoImageTextTool.h"

#define _iconInterval_ 5

@implementation JBoWitnessCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentFont = [UIFont systemFontOfSize:17];
        self.contentWordHeight = [JBoImageTextTool getFontSize:self.contentFont withString:@"我"].height;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouched:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_rightPadding_ / 2, _topPadding_, _headImageSize_, _headImageSize_)];
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [self.contentView addSubview:_headImageView];
        [tap release];
        
        CGFloat width = _width_ - _headImageView.frame.origin.x - _headImageView.frame.size.width - _rightPadding_ * 2 - _controlInterval_;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _controlInterval_ + _rightPadding_ / 2, _headImageView.frame.origin.y, width / 5 * 3, 30)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat x = _nameLabel.frame.origin.x - _nameLabel.frame.size.width;
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, _nameLabel.frame.origin.y, _width_ - x - _rightPadding_, _nameLabel.frame.size.height)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        
        [self.contentView addSubview:_dateLabel];
        
        
        _multiImageTextView = [[JBoMultiImageTextView alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.origin.y + _nameLabel.frame.size.height, _multiSize_ * _imagesPerRows_ + _controlInterval_ * (_imagesPerRows_ - 1), 0)];
        _multiImageTextView.delegate = self;
        _multiImageTextView.contentFont = self.contentFont;
        [self.contentView addSubview:_multiImageTextView];

    }
    return self;
}

#pragma mark- JBoMultiImageTextView delegate

- (void)multiImageTextView:(JBoMultiImageTextView *)multiImageTextView didSelectedImageAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(witnessCell:imageDidSelectedAtIndex:)])
    {
        [self.delegate witnessCell:self imageDidSelectedAtIndex:index];
    }
}

- (void)multiImageTextView:(JBoMultiImageTextView *)multiImageTextView didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(witnessCell:didSelectedURL:)])
    {
        [self.delegate witnessCell:self didSelectedURL:url];
    }
}

- (void)setContentFont:(UIFont *)contentFont
{
    if(_contentFont != contentFont)
    {
        [_contentFont release];
        _contentFont = [contentFont retain];
        _multiImageTextView.contentFont = _contentFont;
    }
}

- (void)headImageDidTouched:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(witnessCellHeadImageDidSelected:)])
    {
        [self.delegate witnessCellHeadImageDidSelected:self];
    }
}

- (void)dealloc
{
    self.delegate = nil;
    [_multiImageTextView release];
    
    [_headImageView release];
    [_nameLabel release];
    [_dateLabel release];
    
    [_contentFont release];
    
    [super dealloc];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
