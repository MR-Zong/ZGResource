//
//  JBoSignUpInfo.m
//  靓咖
//
//  Created by kinghe005 on 14-7-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSignUpInfo.h"

@implementation JBoSignUpInfo

- (id)init
{
    self = [super init];
    if(self)
    {
       // self.detailInfo = [[[JBoUserDetailInfo alloc] init] autorelease];
        self.componentHeight = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_detailInfo release];
    
    [_realName release];
    [_phoneNum release];
    [_email release];
    [_remark release];
    [_component release];
    [_serialNum release];
    
    [super dealloc];
}

//获取报名信息组合
- (NSString*)getComponent
{
    if(!self.component)
    {
        NSMutableString *ret = [[NSMutableString alloc] init];
        
        if(self.serialNum)
        {
            [ret appendFormat:@"序号：%@\n", self.serialNum];
        }
        
        if(self.realName)
        {
            [ret appendFormat:@"姓名：%@\n", self.realName];
        }
        
        if(self.phoneNum)
        {
            [ret appendFormat:@"手机号：%@\n", self.phoneNum];
        }
        
        if(self.email)
        {
            [ret appendFormat:@"邮箱：%@\n", self.email];
        }
        
        if(self.remark)
        {
            [ret appendFormat:@"备注：%@\n", self.remark];
        }
        
        if(ret.length > 0)
        {
            [ret deleteCharactersInRange:NSMakeRange(ret.length - 1, 1)];
        }
        
        self.component = ret;
        [ret release];
    }
    
    return self.component;
}

@end
