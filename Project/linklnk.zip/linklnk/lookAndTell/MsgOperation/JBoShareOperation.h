//
//  JBoShareOperation.h
//  连你
//
//  Created by kinghe005 on 14-3-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**超友圈分享
 */
@interface JBoShareOperation : NSObject

/**获取所有分享按钮标题
 *@return 数组元素是 NSString
 */
+ (NSArray*)shareTitles;

/**获取所有分享按钮图标
 *@reuturn 数组元素是 UIImage
 */
+ (NSArray*)shareIcons;

@end
