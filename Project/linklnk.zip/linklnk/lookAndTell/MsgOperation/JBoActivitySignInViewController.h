//
//  JBoActivitySignInViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoActivitySignInViewController;

@protocol JBoActivitySignInViewControllerDelegate <NSObject>

@optional
- (void)activitySignInViewControllerDidPFinished:(JBoActivitySignInViewController*) viewController;

@end

@interface JBoActivitySignInViewController : UIViewController

@property(nonatomic,copy) NSString *groupId;
@property(nonatomic,assign) id<JBoActivitySignInViewControllerDelegate> delegate;

- (void)back;

@end
