//
//  JBoMsgOperationInfo.h
//  连你
//
//  Created by kinghe005 on 14-4-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoBasic.h"

/**超友圈信息中的  操作气泡的内容信息
 */
@interface JBoMsgOperationInfo : NSObject

/**志愿者数量
 */
@property(nonatomic,assign) int volunteerCount;

/**捐赠数量
 */
@property(nonatomic,assign) int donateCount;

/**点赞次数
 */
@property(nonatomic,assign) int praiseCount;

/**签到人数
 */
@property(nonatomic,assign) int signInCount;

/**报名人数
 */
@property(nonatomic,assign) int signUpCount;

/**同情次数
 */
@property(nonatomic,assign) int pityCount;

/**证明人数
 */
@property(nonatomic,assign) int witnessCount;

/**申请活动人数
 */
@property(nonatomic,assign) int applyCount;

/**是否已点赞
 */
@property(nonatomic,assign) BOOL good;

/**是否已报名
 */
@property(nonatomic,assign) BOOL signUp;

/**是否已成为证明人
 */
@property(nonatomic,assign) BOOL witness;

/**是否已签到
 */
@property(nonatomic,assign) BOOL signIn;

/**是否已点同情
 */
@property(nonatomic,assign) BOOL pity;

/**已关联
 */
@property(nonatomic,assign) BOOL selected;

/**说说气泡操作类型，不同的类型显示的可操作功能不一样
 */
@property(nonatomic,assign) JBoMsgOperationVStyle style;

/**说说评论 数组元素是 JBoLookAndTellCommentInfo对象 default is ‘空的数组’
 */
@property(nonatomic,retain) NSMutableArray *commentInfoArray;


@end
