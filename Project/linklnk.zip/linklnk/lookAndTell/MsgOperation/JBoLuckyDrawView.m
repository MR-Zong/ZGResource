//
//  JBoLuckyDrawView.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLuckyDrawView.h"
#import "JBoWitnessInfo.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserOperation.h"
#import "JBoSignInInfo.h"
#import "JBoImageCacheTool.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoPublickUserInfoViewController.h"

#define _padding_ 20.0
#define _rowHeight_ 60.0

#define _luckyTime_ 3.0

#define _baseCount_ 100

/**抽奖列表cell
 */
@interface JBoLuckyCell : UITableViewCell
{
    //边框，用来标识抽到的用户
    UIView *_borderView;
}

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**是否是中奖用户
 */
@property(nonatomic,assign) BOOL lucky;

@end

@implementation JBoLuckyCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        CGFloat interval = 10.0;
        CGFloat size = _rowHeight_ - interval * 2;
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(interval, interval, size, size)];
        [self.contentView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.size.width + _headImageView.frame.origin.x + interval, interval, self.bounds.size.width - _headImageView.frame.origin.x - size - interval * 3, size)];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat borderWidth = 2.0;
        CGFloat x = interval - borderWidth - 1;
        
        _borderView = [[UIView alloc] initWithFrame:CGRectMake(x, x, _width_ - _padding_ * 2 - x * 2, _rowHeight_ - x * 2)];
        _borderView.backgroundColor = [UIColor clearColor];
        _borderView.layer.borderWidth = borderWidth;
        _borderView.layer.borderColor = [UIColor colorWithRed:_priceColorR_ green:_priceColorG_ blue:_priceColorB_ alpha:1.0].CGColor;
        [self.contentView addSubview:_borderView];
        _borderView.hidden = YES;
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_borderView release];
    
    [super dealloc];
}

- (void)setLucky:(BOOL)lucky
{
    _lucky = lucky;
    _borderView.hidden = !_lucky;
}

@end


@interface JBoLuckyDrawView ()<UITableViewDataSource,UITableViewDelegate,JBoHttpRequestDelegate>
{
    //抽奖计时器
    NSTimer *_luckyDrawTimer;
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
}

/**签到用户列表
 */
@property(nonatomic,retain) UITableView *tableView;

/**列表上部模糊覆盖视图，只有中奖用户显示在中间
 */
@property(nonatomic,retain) UIView *topIndicatorView;

/**列表下部模糊覆盖视图
 */
@property(nonatomic,retain) UIView *bottomIndicatorView;

/**列表行的数量
 */
@property(nonatomic,assign) NSInteger count;

/**是否正在网络请求
 */
@property(nonatomic,assign) NSInteger isRequesting;

/**抽奖时间
 */
@property(nonatomic,assign) NSTimeInterval timeInterval;

/**抽奖结果 userId
 */
@property(nonatomic,copy) NSString *result;

/**抽中的用户
 */
@property(nonatomic,assign) NSInteger luckyIndex;

@end


@implementation JBoLuckyDrawView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
          UIImage *luckyImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"long_btn_@2x" ofType:_imageType_]];
        
        self.backgroundColor = [UIColor clearColor];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeLucy:)];
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height - _defaultLuckyDrawHeight_)];
        header.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [header addGestureRecognizer:tap];
        [tap release];
        [self addSubview:header];
        [header release];
        
        UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, header.frame.size.height, frame.size.width, frame.size.height - header.frame.size.height)];
        footer.backgroundColor = [UIColor whiteColor];
        [self addSubview:footer];
        [footer release];
        
        self.tableView = [[[UITableView alloc] initWithFrame:CGRectMake(_padding_, _padding_, frame.size.width - _padding_ * 2, _rowHeight_ * 3) style:UITableViewStylePlain] autorelease];
        self.tableView.delegate = self;
        self.tableView.dataSource = self;
        self.tableView.scrollEnabled = NO;
        self.tableView.showsVerticalScrollIndicator = NO;
        self.tableView.showsHorizontalScrollIndicator = NO;
        self.tableView.rowHeight = _rowHeight_;
        self.tableView.layer.cornerRadius = 5.0;
        self.tableView.layer.masksToBounds = YES;
        self.tableView.layer.borderColor = [UIColor grayColor].CGColor;
        self.tableView.layer.borderWidth = 2.0;
        
        [footer addSubview:self.tableView];
        
      
        UIButton *luckyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [luckyButton setBackgroundImage:luckyImage forState:UIControlStateNormal];
        [luckyButton addTarget:self action:@selector(luckyButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [luckyButton setFrame:CGRectMake((frame.size.width - luckyImage.size.width) / 2, self.tableView.frame.origin.y + self.tableView.frame.size.height + _padding_, luckyImage.size.width, luckyImage.size.height)];
        [luckyButton setTitle:@"开始" forState:UIControlStateNormal];
        [footer addSubview:luckyButton];
        
        [luckyImage release];
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        self.topIndicatorView = [[[UIView alloc] initWithFrame:CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y, self.tableView.frame.size.width, _rowHeight_)] autorelease];
        self.topIndicatorView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.7];
        [footer addSubview:self.topIndicatorView];
        
        self.bottomIndicatorView = [[[UIView alloc] initWithFrame:CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y + self.tableView.frame.size.height - _rowHeight_, self.tableView.frame.size.width, _rowHeight_)] autorelease];
        self.bottomIndicatorView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.7];
        [footer addSubview:self.bottomIndicatorView];
        
        self.count = _baseCount_;
        self.luckyIndex = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_luckyArray release];
    [_tableView release];
    [_srcArray release];
    [_groupId release];
    
    [_httpRequest release];
    
    [_topIndicatorView release];
    [_bottomIndicatorView release];
    [_result release];
    
    [super dealloc];
}

#pragma mark-private Method

- (void)luckyButtonAction:(UIButton*) button
{
    [self luckyFromServer];
    [self beginLuckyDraw];
}

- (void)closeLucy:(UITapGestureRecognizer*) tap
{
    self.show = NO;
}

#pragma mark-publick Method

/**开始抽奖
 */
- (void)beginLuckyDraw
{
    [self starTimer];
}

/**结束抽奖
 */
- (void)endLuckyDraw
{
    self.delegate = nil;
    [self stopTimer];
}

/**选择某一行
 */
- (void)selectedAtIndex:(NSInteger)index animated:(BOOL)animated
{
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:animated];
}

/**重新加载签到用户信息
 */
- (void)reloadData
{
    [self.tableView reloadData];
}

- (void)setShow:(BOOL)show
{
    _show = show;
    if(_show)
    {
        [UIView animateWithDuration:0.25 animations:^(void){
            self.frame = CGRectMake(self.frame.origin.x, _height_ - self.frame.size.height - _statuBarHeight_ - _navgateBarHeight_, self.frame.size.width, self.frame.size.height);
        }];
    }
    else
    {
        [self endLuckyDraw];
        [_httpRequest cancelGetRequest];
        [UIView animateWithDuration:0.25 animations:^(void){
            self.frame = CGRectMake(self.frame.origin.x, _height_, self.frame.size.width, self.frame.size.height);
        }];
    }
}

#pragma mark- timer

//开始抽奖计时
- (void)starTimer
{
    if(!_luckyDrawTimer)
    {
        _luckyDrawTimer = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(luckyDraw:) userInfo:nil repeats:YES];
    }
    [_luckyDrawTimer fire];
}

//结束抽奖计时
- (void)stopTimer
{
    if(_luckyDrawTimer != nil && [_luckyDrawTimer isValid])
    {
        [_luckyDrawTimer invalidate];
        _luckyDrawTimer = nil;
    }
}

//抽奖列表来回滚动
- (void)luckyDraw:(NSTimer*) timer
{
    if(_srcArray.count == 0)
        return;
    long index = random() % self.count;
    index = index < 0 ? - index : index;
    self.timeInterval += 0.25;
    [self selectedAtIndex:index animated:YES];
}


#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    JBoSignInInfo *info = [JBoLookAndTellOperation activityLuckyDrawWithGroupFromData:data];
    
    NSInteger luckyIndex = NSNotFound;
    
    if(info)
    {
        for(NSInteger i = 0;i < self.srcArray.count;i ++)
        {
            JBoSignInInfo *temp = [self.srcArray objectAtIndex:i];
            if([info.userId isEqualToString:temp.userId])
            {
                luckyIndex = i;
                break;
            }
        }
        [self.luckyArray addObject:info.userId];
        
        if([NSString isEmpty:self.result])
        {
            self.result = info.userId;
        }
        else
        {
            self.result = [NSString stringWithFormat:@"%@;%@", self.result, info.userId];
        }
        
        if(luckyIndex == NSNotFound)
        {
            NSInteger j = random() % self.srcArray.count;
            j = j >= self.srcArray.count ? self.srcArray.count - 1 : j;
            [self.srcArray insertObject:info atIndex:j];
            luckyIndex = j;
        }
        
    }
    
    if(luckyIndex == NSNotFound)
        luckyIndex = 0;
    
    if(self.timeInterval < _luckyTime_)
    {
        [self performSelector:@selector(resultWithIndex:) withObject:[NSNumber numberWithInteger:luckyIndex] afterDelay:_luckyTime_ - self.timeInterval];
    }
    else
    {
        [self performSelector:@selector(resultWithIndex:) withObject:[NSNumber numberWithInteger:luckyIndex]];
    }
   
}

- (void)resultWithIndex:(NSNumber*) index
{
    [self stopTimer];
    
    NSInteger row = [index integerValue];
    if(self.count == _baseCount_)
    {
        if([index integerValue] == 0)
        {
            row = self.srcArray.count;
        }
    }
    
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
    
   if(row == 0)
    {
        self.tableView.contentInset = UIEdgeInsetsMake(_rowHeight_, 0, 0, 0);
    }
    else if(row == self.count)
    {
        self.tableView.contentInset = UIEdgeInsetsMake(0, 0, _rowHeight_, 0);
    }

    self.luckyIndex = row;
}

- (void)luckyDidFinishWithIndex:(NSNumber*) index
{
    if([self.delegate respondsToSelector:@selector(luckyDrawView:didLuckyAtIndex:)])
    {
        [self.delegate luckyDrawView:self didLuckyAtIndex:[index integerValue]];
    }
}

#pragma mark-tableView 代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(!self.srcArray)
        return 0;
    
    NSInteger count = self.srcArray.count;
    if(count < self.count && self.srcArray.count != 0)
        count = self.count;
    else
        self.count = self.srcArray.count;
    return count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
   // NSLog(@"luck");
    JBoLuckyCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoLuckyCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSInteger count = indexPath.row;
    
    count = count % self.srcArray.count;
    if(count >= self.srcArray.count)
    {
        count = self.srcArray.count - 1;
    }
    
    JBoSignInInfo *info = [self.srcArray objectAtIndex:count];
    cell.headImageView.sex = info.sex;
    cell.headImageView.headImageURL = info.headImageURL;
    
    cell.nameLabel.text = info.name;
    cell.lucky = indexPath.row == self.luckyIndex;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger count = indexPath.row;
    
    count = count % self.srcArray.count;
    if(count >= self.srcArray.count)
    {
        count = self.srcArray.count - 1;
    }
    
    JBoSignInInfo *info = [self.srcArray objectAtIndex:count];
    
    JBoRosterInfo *rosterInfo = [_appDelegate.rosterAndUsernameDic objectForKey:info.userId];
    if(rosterInfo)
    {
        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
        detail.rosterInfo = rosterInfo;
        detail.black = self.black;
        [self.navigationController pushViewController:detail animated:YES];
        [detail release];
    }
    else
    {
        JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
        userInfo.userId = info.userId;
        userInfo.black = self.black;
        [self.navigationController pushViewController:userInfo animated:YES];
        [userInfo release];
    }
}

//从服务器中的签到用户抽奖
- (void)luckyFromServer
{
    if(self.isRequesting)
        return;
    
    if(self.luckyArray.count == self.srcArray.count)
    {
        [self.luckyArray removeAllObjects];
        self.result = nil;
    }

    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    
    self.timeInterval = 0;
    self.isRequesting = YES;
    
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation activityLuckyDrawWithGroupId:self.groupId result:self.result]];
}

@end
