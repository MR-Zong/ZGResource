//
//  JBoBecomeWitnessViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoBecomeWitnessViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoImageOperationView.h"
#import "SSTextView.h"
#import "JBoUserOperation.h"
#import "JBoLookAndTellOperation.h"
#import "JBoWitnessInfo.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageOperationPreviewedViewController.h"
#import "JBoImageTextTool.h"
#import "JBoLookAndTellOperation.h"
#import "JBoFileManager.h"
#import "BMapKit.h"
#import "JBoCustomInsetLabel.h"
#import "JBoDatetimeTool.h"
#import "BMKGeoCodeSearch+Utilities.h"

#define _padding_ 10
#define _imageSize_ 100
#define _controlHeight_ 40
#define _controlInterval_ 5.0

@interface JBoBecomeWitnessViewController ()<JBoHttpRequestDelegate,JBoImageOperationViewDelegate,JBoMutiImagePickerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextViewDelegate,JBoImageOperationPreviewedViewControllerDelegate,UIActionSheetDelegate,BMKGeoCodeSearchDelegate,BMKLocationServiceDelegate>
{
    JBoAppDelegate *_appDelegate;
    
    JBoHttpRequest *_httpRequest;
    
    SSTextView *_textView;
    JBoImageOperationView *_imageOperationView;
    
    //定位
    BMKLocationService *_locationManager;
    //获取当前位置地址

    UIActivityIndicatorView *_actView;
}

//地理反编码
@property(nonatomic,retain) BMKGeoCodeSearch *addrSearch;

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) NSMutableArray *imageArray;
@property(nonatomic,retain) NSMutableArray *albumArray;
@property(nonatomic,retain) NSMutableArray *cameraArray;
@property(nonatomic,retain) NSArray *filesArray;

//地址信息
@property(nonatomic,retain) UILabel *addressLabel;
@property(nonatomic,copy) NSString *addrInfo;
@property(nonatomic,assign) UIButton *iconButton;

//正在定位
@property(nonatomic,assign) BOOL locate;
@property(nonatomic,assign) BOOL locating;

@end

@implementation JBoBecomeWitnessViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"成为证明人";
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
        self.view.userInteractionEnabled = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_groupId release];
    
    [_httpRequest release];
    [_textView release];
    [_imageArray release];
    
    [_albumArray release];
    [_cameraArray release];
    
    [_imageOperationView release];
    
    [_locationManager release];
    [_addrSearch release];
    [_actView release];
    
    [JBoFileManager deleteFiles:_filesArray];
    [_filesArray release];
    
    [_addressLabel release];
    [_addrInfo release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
    
    [_locationManager stopUserLocationService];
    _locationManager.delegate = nil;
    _addrSearch.delegate = nil;
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"上传信息失败"];
    [JBoFileManager deleteFiles:self.filesArray];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoFileManager deleteFiles:self.filesArray];
    if([JBoUserOperation isSuccess:data])
    {
        [JBoUserOperation alertMsg:@"已成为证明人"];
        
        if([self.delegate respondsToSelector:@selector(becomeWitnessViewController:didFinishedWithInfo:)])
        {
            [self.delegate becomeWitnessViewController:self didFinishedWithInfo:nil];
        }
        else
        {
            [self performSelector:@selector(back) withObject:nil afterDelay:0.2];
        }
    }
}

#pragma mark-加载视图

- (void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)finish
{
    if([NSString isEmpty:_textView.text])
    {
        [JBoUserOperation alertMsg:@"描述不能为空"];
        return;
    }
    
    if(self.imageArray.count == 0)
    {
        [JBoUserOperation alertMsg:@"请上传图片"];
        return;
    }
    
    if([NSString isEmpty:self.addrInfo])
    {
        [JBoUserOperation alertMsg:@"还没定位,无法成为证明人"];
        return;
    }
    
    self.isRequesting = YES;
    
    NSMutableArray *imageArray = [[NSMutableArray alloc] initWithCapacity:self.imageArray.count];
    [imageArray addObjectsFromArray:self.albumArray];
    
    CGFloat labelHeight = 20.0;
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    
    JBoCustomInsetLabel *addressLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectZero];
    addressLabel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    addressLabel.adjustsFontSizeToFitWidth = YES;
    addressLabel.text = self.addrInfo;
    addressLabel.textColor = [UIColor whiteColor];
    addressLabel.insets = UIEdgeInsetsMake(0, 10, 0, 10);
    [imageView addSubview:addressLabel];
    [addressLabel release];
    
    JBoCustomInsetLabel *timeLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectZero];
    timeLabel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
    timeLabel.font = [UIFont systemFontOfSize:13.0];
    [timeLabel setTextAlign:JBoTextAlignmentRight];
    
    timeLabel.textColor = [UIColor whiteColor];
    timeLabel.insets = UIEdgeInsetsMake(0, 10, 0, 10);
    timeLabel.text = [JBoDatetimeTool getCurrentTime:@"YYYY-MM-dd HH:mm"];
    [imageView addSubview:timeLabel];
    [timeLabel release];
    
    for(UIImage *image in self.cameraArray)
    {
        imageView.image = image;
        imageView.frame = CGRectMake(0, 0, image.size.width, image.size.height);
        addressLabel.frame = CGRectMake(0, image.size.height - labelHeight * 2, image.size.width, labelHeight);
        timeLabel.frame = CGRectMake(0, image.size.height - labelHeight, image.size.width, labelHeight);
        
        UIImage *thumbnail = [JBoImageTextTool getImageFromView:imageView];
        if(thumbnail)
        {
            [imageArray addObject:thumbnail];
        }
    }
    self.filesArray = [JBoFileManager writeImageInTemporaryFile:imageArray withCompressedScale:0.9];
    
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation witnessActivity] paraDic:[JBoLookAndTellOperation winessActivityInfoWithGroupId:self.groupId content:_textView.text] files:self.filesArray filesKey:_activityWitnessPhoto_];
    
    [imageView release];
    [imageArray release];
}

- (void)reconverKeyborad:(UITapGestureRecognizer*) tap
{
    [_textView resignFirstResponder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBar.translucent = NO;
    UITapGestureRecognizer *reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyborad:)];
    [self.view addGestureRecognizer:reconverGesture];
    [reconverGesture release];
    
    //返回
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back) image:[UIImage imageNamed:@"newsBact.png"]];
    
	self.view.backgroundColor = _mainBackgroundColor_;
    
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(finish) title:@"完成" backgroundImage:nil textColor:[UIColor blackColor]];
    
    //位置地址
    UIImage *icon = [UIImage imageNamed:@"location_icon.png"];
    UIButton *iconButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [iconButton setImage:icon forState:UIControlStateNormal];
    [iconButton setFrame:CGRectMake(_padding_, _padding_ + (_controlHeight_ - icon.size.height) / 2, icon.size.width, icon.size.height)];
    [iconButton addTarget:self action:@selector(location) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:iconButton];
    self.iconButton = iconButton;
    
    
    //位置地址
    self.addressLabel = [[[UILabel alloc] initWithFrame:CGRectMake(iconButton.frame.origin.x + iconButton.frame.size.width + _controlInterval_, _padding_, _width_ - iconButton.frame.origin.x * 2 - iconButton.frame.size.width - _controlInterval_, _controlHeight_)] autorelease];
    //_addressTextView.textAlignment = NSTextAlignmentCenter;
    self.addressLabel.textColor = [UIColor grayColor];
    self.addressLabel.numberOfLines = 0;
    self.addressLabel.font = [UIFont systemFontOfSize:14.0];
    self.addressLabel.hidden = YES;
    [self.view addSubview:self.addressLabel];
    
    
    [self location];
    
    _textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _addressLabel.frame.origin.y + _addressLabel.frame.size.height, _width_ - _padding_ * 2, 112.5)];
    _textView.layer.cornerRadius = 6;
    _textView.layer.borderWidth = 0.2;
    _textView.returnKeyType = UIReturnKeyDone;
    _textView.layer.borderColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0].CGColor;
    _textView.font = [UIFont systemFontOfSize:17];
    _textView.delegate = self;
    //textView.maxCount = _inputFormatLookAndTellNum_;
    _textView.placeholder = @"描述";
    //textView.limitable = YES;
    [self.view addSubview:_textView];

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, _textView.frame.origin.y + _textView.frame.size.height + _padding_, _width_ - _padding_ * 2, 30)];
    label.text = @"上传图片";
    label.textColor = [UIColor grayColor];
    label.backgroundColor = [UIColor clearColor];
    [self.view addSubview:label];
    [label release];
    
    self.imageArray = [[[NSMutableArray alloc] init] autorelease];
    self.cameraArray = [[[NSMutableArray alloc] init] autorelease];
    self.albumArray = [[[NSMutableArray alloc] init] autorelease];
    
    _imageOperationView = [[JBoImageOperationView alloc] initWithFrame:CGRectMake(_padding_, label.frame.origin.y + label.frame.size.height + _padding_, _width_ - _padding_ * 2, _imageOperationDefaultCellSize_) srcArray:self.imageArray imageSize:_imageOperationDefaultCellSize_];
    _imageOperationView.backgroundColor = [UIColor whiteColor];
    _imageOperationView.delegate = self;
    _imageOperationView.maxCount = 9;
    [self.view addSubview:_imageOperationView];
}

#pragma mark-textView代理
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}

#pragma mark-JBoImageOperationView代理
- (void)imageOperationViewDidAddedCell:(JBoImageOperationView *)selectedView
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
    [actionSheet showInView:self.navigationController.view];
    [actionSheet release];
}

- (void)imageOperationView:(JBoImageOperationView *)selctedView didSelectImageAtIndex:(NSInteger)index
{
    JBoImageOperationPreviewedViewController *previewVC = [[JBoImageOperationPreviewedViewController alloc] init];
    previewVC.srcArray = selctedView.srcArray;
    previewVC.currentIndex = index;
    previewVC.delegate = self;
    [self.navigationController pushViewController:previewVC animated:YES];
    [previewVC release];
}

- (void)imageOperationViewDidReloadData:(JBoImageOperationView *)selctedView
{
    _appDelegate.dataLoadingView.hidden = YES;
}

#pragma mark-JBoImageOperationPreviewedViewController代理
- (void)imageOperationPreviewedViewController:(JBoImageOperationPreviewedViewController *)viewController didRemoveImageAtIndex:(NSInteger)index
{
    [_imageOperationView removeImageAtIndex:index];
}

#pragma makr-actionsheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [self getCamera];
    }
    else if(buttonIndex == 1)
    {
        [self getPhotos];
    }
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    NSLog(@"拍照");
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:retImage withSize:size];
        
        [_imageOperationView.srcArray addObject:thumbnail];
        [self.cameraArray addObject:thumbnail];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [_imageOperationView updateContent];
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("camera", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
    
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [_appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)_imageOperationView.maxCount - (int)_imageOperationView.srcArray.count;;
    mutilImagePicker.title = @"相册";
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:mutilImagePicker];
    
    [self presentViewController:nav animated:YES completion:nil];
    
    [mutilImagePicker release];
    [nav release];
}

#pragma mark-JBoMutilImagePickerViewController代理
- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
    {
        if(assetArray.count > 0)
        {
            for(ALAsset *asset in assetArray)
            {
                UIImage *image = [UIImage imageFromAsset:asset];
                CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
                
                [self.imageArray addObject:thumbnail];
                [self.albumArray addObject:thumbnail];
            }
        }
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [_imageOperationView updateContent];
            [self hiddTopView:NO];
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
        
        [self.imageArray addObject:thumbnail];
        [self.albumArray addObject:thumbnail];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [_imageOperationView updateContent];
            [self hiddTopView:NO];
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

#pragma mark-位置
- (void)finishLocation:(BOOL) success
{
    NSLog(@"定位完成");
    [_actView stopAnimating];
    _addressLabel.hidden = NO;
    
    if(success)
    {
        self.locate = YES;
        _addressLabel.text = self.addrInfo;
    }
    else
    {
        if([NSString isEmpty:self.addrInfo])
        {
            self.locate = NO;
            _addressLabel.text = @"无法确定您当前的位置";
        }
        else
        {
            [JBoUserOperation alertMsg:@"无法确定当前位置"];
        }
        
    }
    self.locating = NO;
}

#pragma mark- BMKGeoCodeSearch delegate

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(error != BMK_SEARCH_NO_ERROR)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        return;
    }
    NSLog(@"--%@",result.address);
    self.addrInfo = result.address;
    [self finishLocation:YES];
}

#pragma mark-定位
- (void)location
{
//    if(self.locating)
//        return;
    if([CLLocationManager locationServicesEnabled])
    {
        self.addressLabel.hidden = YES;
        if(!_actView)
        {
            CGFloat size = 30;
            _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            _actView.hidesWhenStopped = YES;
            _actView.frame = CGRectMake(self.iconButton.frame.origin.x + self.iconButton.frame.size.width + _controlInterval_, _addressLabel.frame.origin.y + (_addressLabel.frame.size.height - size) / 2, size, size);
            [self.view addSubview:_actView];
        }
        
        [_actView startAnimating];
        if(!_locationManager)
        {
            _locationManager = [[BMKLocationService alloc] init];
            _locationManager.delegate = self;
        }
        self.locating = YES;
        [_locationManager startUserLocationService];
    }
    else
    {
        [self finishLocation:NO];
    }
}

#pragma mark- BMKLocationService delegate

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {
        if(!_addrSearch)
        {
            self.addrSearch = [BMKGeoCodeSearch sharedInstance];
        }
        
        self.addrSearch.delegate = self;
        
        BMKReverseGeoCodeOption *option = [[[BMKReverseGeoCodeOption alloc] init] autorelease];
        option.reverseGeoPoint = userLocation.location.coordinate;
        
        if([_addrSearch reverseGeoCode:option])
        {
            NSLog(@"地理反编码");
        }
        [_locationManager stopUserLocationService];
    }
}


- (void)didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"定位失败");
    [_locationManager stopUserLocationService];
    [self finishLocation:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
