//
//  JBoMsgOperationItemInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**超友圈信息 气泡操作类型
 */
typedef NS_ENUM(int, JBoMsgOperationItemStyle)
{
    JBoMsgOperationItemStyleTransmit = 0, //转载
    JBoMsgOperationItemStylePraise = 1, //赞
    JBoMsgOperationItemStylePity = 2, //同情
    JBoMsgOperationItemStyleWitness = 3, //证明人
    JBoMsgOperationItemStyleSignUp = 4, //报名
    JBoMsgOperationItemStyleApply = 5, //申请
    JBoMsgOperationItemStyleSignIn = 6, //签到
    JBoMsgOperationItemStyleVoluteer = 7, //志愿者
    JBoMsgOperationItemStyleDonate = 8, //捐物
    JBoMsgOperationItemStyleDelete = 9, //删除
    JBoMsgOperationItemStyleStick = 10, //置顶
    JBoMsgOperationItemStyleComplaint = 11, //投诉
    JBoMsgOperationItemStyleSelected = 12, //选择
    JBoMsgOperationItemStyleVisible = 13, //可见范围
    JBoMsgOperationItemStyleComment = 14, //评论
};

//操作按钮高度
#define _msgOperationItemHeight_ 20.0

//操作按钮边距
#define _msgOperationInnerPadding_ 15.0

/**超友圈信息 气泡操作按钮信息
 */
@interface JBoMsgOperationItemInfo : NSObject

/**内容
 */
@property(nonatomic,copy) NSAttributedString *content;

/**标题 默认蓝色
 */
@property(nonatomic,retain) NSString *title;

/**超友圈信息 气泡操作类型
 */
@property(nonatomic,assign) JBoMsgOperationItemStyle style;

/**内容高度 default is ‘20’
 */
@property(nonatomic,assign) NSInteger titleHeight;

/**评论下标，default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger commentIndex;

@end
