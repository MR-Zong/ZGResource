//
//  JBoShareOperation.m
//  连你
//
//  Created by kinghe005 on 14-3-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoShareOperation.h"
#import "UIImage+customImage.h"
#import "JBoBasic.h"

@implementation JBoShareOperation

/**获取所有分享按钮标题
 *@return 数组元素是 NSString
 */
+ (NSArray*)shareTitles
{
//    NSArray *titles = [NSArray arrayWithObjects:@"QQ空间", @"新浪微博" ,@"百度贴吧", @"百度相册", @"腾讯微博", @"人人网", @"QQ好友", @"一键分享", @"豆瓣网", @"飞信", @"美丽说", @"蘑菇街", @"腾讯朋友", @"天涯社区", @"有道云笔记", @"facebook", @"linkedin", @"twitter", nil];
    NSArray *titles = [NSArray arrayWithObjects:@"分享给好友", [NSString stringWithFormat:@"转载到%@", _lookAndTellName_], nil];
    return titles;
}

/**获取所有分享按钮图标
 *@reuturn 数组元素是 UIImage
 */
+ (NSArray*)shareIcons
{
//     NSArray *icons = [NSArray arrayWithObjects:[UIImage bundleImageWithName:@"qqZone"], [UIImage bundleImageWithName:@"sinaWeibo"], [UIImage bundleImageWithName:@"baiduTieba"], [UIImage bundleImageWithName:@"baiduPhoto"], [UIImage bundleImageWithName:@"tencentWeibo"], [UIImage bundleImageWithName:@"renren"], [UIImage bundleImageWithName:@"qqFriend"], [UIImage bundleImageWithName:@"onekeyShare"], [UIImage bundleImageWithName:@"douban"], [UIImage bundleImageWithName:@"feixin"],  [UIImage bundleImageWithName:@"meilishuo"], [UIImage bundleImageWithName:@"mogujie"], [UIImage bundleImageWithName:@"tencentFriend"], [UIImage bundleImageWithName:@"tianya"], [UIImage bundleImageWithName:@"youdao"], [UIImage bundleImageWithName:@"facebook"], [UIImage bundleImageWithName:@"linkedin"], [UIImage bundleImageWithName:@"twitter"],nil];
    
    NSArray *icons = [NSArray arrayWithObjects:[UIImage imageNamed:@"shareToFriend"], [UIImage imageNamed:@"linklnk.png"], nil];
    return icons;
}

@end
