//
//  JBoMsgOperation.m
//  连你
//
//  Created by kinghe005 on 14-4-8.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMsgOperation.h"
#import "JBoNavigationViewController.h"
#import "JBoRealNameAuthenViewController.h"

@implementation JBoMsgOperation

#pragma mark- 证明人

/**获取证明人列表
 *@param info 证明人关联的超友圈信息
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getWitness:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoWitnessViewController *witnessVC = [[JBoWitnessViewController alloc] init];
    witnessVC.black = black;
    
    witnessVC.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    [viewController.navigationController pushViewController:witnessVC animated:YES];
    [witnessVC release];
}

/**成为证明人 会判断用户是否已实名认证，只有实名认证的用户才能成为证明人
 *@param info 证明人关联的超友圈信息
 *@param viewController 实现 JBoBecomeWitnessViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)becomeWitness:(JBoLookAndTellListInfo*) info viewController:(id<JBoBecomeWitnessViewControllerDelegate>) viewController black:(BOOL)black
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    
    NSString *userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    
    if(![userId isEqualToString:detailInfo.rosterInfo.username])
    {
        if(info.operationInfo.witness)
            return;
        
       // NSLog(@"role %d",info.role);
        if(detailInfo.rosterInfo.role == _rosterRoleNormal_)
        {
            JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
          
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"您还没有实名认证,不能成为证明人" message:realNameAuthenMessage delegate:appDelegate cancelButtonTitle:nil otherButtonTitles:@"取消", goToRealNameAuthen, nil];
            [alertView show];
            [alertView release];
            return;
        }
        
        JBoBecomeWitnessViewController *becomeWitnessVC = [[JBoBecomeWitnessViewController alloc] init];
        becomeWitnessVC.delegate = viewController;
        
        becomeWitnessVC.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
        JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:becomeWitnessVC];
        nav.navigationBar.translucent = NO;
       // JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        [(UIViewController*)viewController presentViewController:nav animated:YES completion:nil];
        [becomeWitnessVC release];
        [nav release];
    }
    else
    {
        [JBoMsgOperation getWitness:info viewController:(UIViewController*)viewController black:black];
    }
}

#pragma mark- 签到

/**活动签到 会判断用户是否已报名，只有报名的用户才能进行签到
 *@param info 所属超友圈活动
 *@param viewController 实现 JBoActivitySignInViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)activitySignIn:(JBoLookAndTellListInfo*) info viewController:(id<JBoActivitySignInViewControllerDelegate>) viewController black:(BOOL)black
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    
    NSString *userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    
    if(![userId isEqualToString:detailInfo.rosterInfo.username])
    {
        if(info.operationInfo.signIn)
            return;
        if(!info.operationInfo.signUp)
        {
            [JBoUserOperation alertMsg:@"你还没报名呢!"];
            return;
        }
        JBoActivitySignInViewController *act = [[JBoActivitySignInViewController alloc] init];
        act.delegate = viewController;
        act.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
        //JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:act];
        nav.navigationBar.translucent = NO;
        [(UIViewController*)viewController presentViewController:nav animated:YES completion:nil];
        [act release];
        [nav release];
    }
    else
    {
        [JBoMsgOperation getSignInPerson:info viewController:(UIViewController*)viewController black:black];
    }
}

/**获取签到用户列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getSignInPerson:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoSignInUserListViewController *signInUser = [[JBoSignInUserListViewController alloc] init];
    signInUser.black = black;
    signInUser.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    [viewController.navigationController pushViewController:signInUser animated:YES];
    [signInUser release];
}

#pragma mark- 报名

/**取消报名
 *@param info 所属超友圈活动
 *@param queue 气泡操作网络请求队列
 */
+ (void)cancelSignUpWithInfo:(JBoLookAndTellListInfo *)info queue:(ASINetworkQueue *)queue
{
    info.operationInfo.signUp = NO;
    info.operationInfo.signUpCount --;
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoLookAndTellOperation updateLookAndTellStatusWithInfo:info]]];
    request.timeOutSeconds = 20.0;
    [queue addOperation:request];
    [queue go];
}

/**报名
 *@param info 所属超友圈活动
 *@param viewController 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)signUpWithInfo:(JBoLookAndTellListInfo*) info viewController:(UIViewController *)viewController black:(BOOL)black
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    
    NSString *userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    
    if(![userId isEqualToString:detailInfo.rosterInfo.username])
    {
        JBoActivitySignUpViewController *signUp = [[JBoActivitySignUpViewController alloc] init];
        signUp.black = black;
        signUp.info = info;
        [signUp showInViewController:viewController animated:YES completion:nil];
        [signUp release];
    }
    else
    {
        [JBoMsgOperation getSignUpPerson:info viewController:viewController black:black];
    }
}

/**获取报名人列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getSignUpPerson:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoSignUpUserListViewController *signUpUser = [[JBoSignUpUserListViewController alloc] init];
    signUpUser.black = black;
    signUpUser.info = info;
    [viewController.navigationController pushViewController:signUpUser animated:YES];
    [signUpUser release];
}

#pragma mark- 活动

/**申请参加活动
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)activityApply:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    
    NSString *userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    
    if(![userId isEqualToString:detailInfo.rosterInfo.username])
    {
        JBoJoinActivityViewController *relaeseVC = [[JBoJoinActivityViewController alloc] init];
        relaeseVC.black = black;
        // NSLog(@"userId = %@", info.userID);
       // NSLog(@"relaeseVC = %d",relaeseVC.black);
        relaeseVC.joinType = JBoReleaseLookAndTellTypeActivity;//info.type == _lookAndTellTypeLays_ ? JBoReleaseLookAndTellTypeLays : JBoReleaseLookAndTellTypeActivity;
        relaeseVC.userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
        relaeseVC.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
        [viewController.navigationController pushViewController:relaeseVC animated:YES];
        [relaeseVC release];
    }
    else
    {
        [JBoMsgOperation getApplyPerson:info viewController:viewController black:black];
    }
}

/**获取参加活动的人
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getApplyPerson:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoActivityActorListViewController *activityActor = [[JBoActivityActorListViewController alloc] init];
    activityActor.black = black;
    activityActor.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    activityActor.type = info.type;
    [viewController.navigationController pushViewController:activityActor animated:YES];
    [activityActor release];
}

#pragma mark- 志愿者

/**参加志愿者
 *@param info 所属超友圈活动
 *@param viewController 实现 JBoLovingVolunteerViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)becomeVolunteer:(JBoLookAndTellListInfo*) info viewController:(id<JBoLovingVolunteerViewControllerDelegate>)viewController black:(BOOL)black
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    
    NSString *userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    
    if(![userId isEqualToString:detailInfo.rosterInfo.username])
    {
        JBoLovingVolunteerViewController *lovingVolunteerVC = [[JBoLovingVolunteerViewController alloc] init];
        lovingVolunteerVC.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
        lovingVolunteerVC.delegate = viewController;
        
       // JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:lovingVolunteerVC];
        nav.navigationBar.translucent = NO;
        [(UIViewController*)viewController presentViewController:nav animated:YES completion:nil];
        [lovingVolunteerVC release];
        [nav release];
    }
    else
    {
        [JBoMsgOperation getVolunteerList:info viewController:(UIViewController*)viewController black:black];
    }
}

/**获取志愿者列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getVolunteerList:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoLovingVolunteerListViewController *lovingVolunteer = [[JBoLovingVolunteerListViewController alloc] init];
    lovingVolunteer.black = black;
    lovingVolunteer.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    [viewController.navigationController pushViewController:lovingVolunteer animated:YES];
    [lovingVolunteer release];
}

#pragma mark- 捐赠

/**捐赠
 *@param info 所属超友圈活动
 *@param viewController 实现 JBoLovingDonateViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)donate:(JBoLookAndTellListInfo*) info viewController:(id<JBoLovingDonateViewControllerDelegate>)viewController black:(BOOL)black
{
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    
    NSString *userId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    
    if(![userId isEqualToString:detailInfo.rosterInfo.username])
    {
        JBoLovingDonateViewController *lovingDonateVC = [[JBoLovingDonateViewController alloc] init];
        lovingDonateVC.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
        lovingDonateVC.delegate = viewController;
        
        //JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:lovingDonateVC];
        nav.navigationBar.translucent = NO;
        [(UIViewController*)viewController presentViewController:nav animated:YES completion:nil];
        [lovingDonateVC release];
        [nav release];
    }
    else
    {
        [JBoMsgOperation getDonateList:info viewController:(UIViewController*) viewController black:black];
    }
}

/**获取捐赠列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getDonateList:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL)black
{
    JBoLovingDonateListViewController *donate = [[JBoLovingDonateListViewController alloc] init];
    donate.groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    donate.black = black;
    if([[JBoUserOperation getUserId] isEqualToString:(info.transmitId == _trasmitNo_ ? info.userID : info.srcGroupId)])
    {
        donate.isSelf = YES;
    }
    [viewController.navigationController pushViewController:donate animated:YES];
    [donate release];
}

#pragma mark- 点赞、同情

/**点赞
 *@param info 所属超友圈活动
 *@param queue 气泡操作网络请求队列
 */
+ (void)setPraiseWithInfo:(JBoLookAndTellListInfo*) info queue:(ASINetworkQueue*) queue
{
    info.operationInfo.good = !info.operationInfo.good;
    
    if(info.operationInfo.good)
    {
        info.operationInfo.praiseCount ++;
    }
    else
    {
        info.operationInfo.praiseCount --;
    }
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoLookAndTellOperation updateLookAndTellStatusWithInfo:info]]];
    request.timeOutSeconds = 20.0;
    [queue addOperation:request];
    [queue go];
}

/**点同情
 *@param info 所属超友圈活动
 *@param queue 气泡操作网络请求队列
 */
+ (void)setPityWithInfo:(JBoLookAndTellListInfo*) info queue:(ASINetworkQueue*) queue
{
    info.operationInfo.pity = !info.operationInfo.pity;
    if(info.operationInfo.pity)
    {
        info.operationInfo.pityCount ++;
    }
    else
    {
        info.operationInfo.pityCount --;
    }
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoLookAndTellOperation updateLookAndTellStatusWithInfo:info]]];
    request.timeOutSeconds = 20.0;
    [queue addOperation:request];
    [queue go];
}



@end
