//
//  JBoMsgOperationView.h
//  连你
//
//  Created by kinghe005 on 14-3-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoTapAnimationView.h"
#import "JBoArrowView.h"
#import "JBoMultiImageTextInfo.h"
#import "JBoMsgOperationItemInfo.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoBasic.h"
#import "JBoAttributedLabel.h"

static NSString *const praise = @"赞";
static NSString *const cancelPraise = @"取消赞";

static NSString *const transmit = @"分享";
static NSString *const alreadTransmit = @"已分享";

static NSString *const pity = @"同情";
static NSString *const cancelPity = @"取消同情";

static NSString *const witness = @"证明人";
static NSString *const alreadWitness = @"已证明";

static NSString *const signUp = @"报名";
static NSString *const alreadSignUp = @"取消报名";

static NSString *const signIn = @"签到";
static NSString *const alreadSignIn = @"已签到";

static NSString *const apply = @"申请";
static NSString *const alreadApply = @"已申请";
static NSString *const applyPerson = @"申请的人";

static NSString *const volunteer = @"志愿者";

static NSString *const donate = @"捐赠";

static NSString *const deleted = @"删除";
static NSString *const stick = @"置顶";
static NSString *const cancelStick = @"取消置顶";

static NSString *const complaint = @"投诉";

static NSString *const sceneSelected = @"关联";
static NSString *const cancelSelected = @"取消关联";

static NSString *const setupPublic = @"设为公开";
static NSString *const setupPrivate = @"设为私密";

static NSString *const lookAndTellComment = @"评论";

#define _msgOperationPadding_ 20.0

#define _msgOperationTitleColor_ _navigationBarBackgroundDefaultColor_
#define _msgOperationFont_ [UIFont systemFontOfSize:13.0]


@interface JBoMsgOperationViewCell : UIButton

@property(nonatomic,assign) NSInteger index;
@property(nonatomic,assign) JBoMsgOperationItemStyle style;

@end

@interface JBoMsgOperationContentItem : UIView<UIGestureRecognizerDelegate>

@property(nonatomic,readonly) JBoAttributedLabel *titleLabel;
@property(nonatomic,assign) JBoMsgOperationItemStyle style;

@property(nonatomic,retain) UIColor *animationColor;
/**有效触摸区域 默认和视图一样大
 */
@property(nonatomic,assign) CGRect validTouchRect;

//评论下标
@property(nonatomic,assign) NSInteger commentIndex;

- (void)addTarget:(id) target singleTapAction:(SEL) selector;



@end

@class JBoMsgOperationContentView;

@protocol JBoMsgOperationContentViewDelegate <NSObject>

@optional
- (void)msgOperationContentView:(JBoMsgOperationContentView*) contentView didSelctedAtItem:(JBoMsgOperationContentItem*) item;

@end


@interface JBoMsgOperationContentView : JBoArrowView

/**数组元素为 JBoMsgOperationItemInfo对象
 */
- (id)initWithFrame:(CGRect)frame arrowPoint:(CGPoint)arrowPoint titles:(NSArray*) titles info:(JBoLookAndTellListInfo*) info;

@property(nonatomic,assign) id<JBoMsgOperationContentViewDelegate> delegate;

@end

@interface JBoMsgOperationTitle : NSObject

@property(nonatomic,copy) NSString *title;
@property(nonatomic,retain) UIImage *icon;
@property(nonatomic,assign) JBoMsgOperationItemStyle style;

+ (JBoMsgOperationTitle*)titleStyle:(JBoMsgOperationItemStyle) style info:(JBoLookAndTellListInfo*) info;

@end

@class JBoMsgOperationView;
@protocol JBoMsgOperationViewDelegate <NSObject>

@optional
- (void)msgOperationView:(JBoMsgOperationView*) view didSelectedAtCell:(JBoMsgOperationViewCell*) cell;
- (void)msgOperationView:(JBoMsgOperationView *)view didSelectedAtItem:(JBoMsgOperationContentItem*) item;

@end

@interface JBoMsgOperationView : UIView<JBoMsgOperationContentViewDelegate>

/**是否可以投诉 default is 'NO'
 */
@property(nonatomic,assign) BOOL canComplaint;
/**是否显示评论的条数 default is '5'
 */
@property(nonatomic,assign) NSInteger showCommentCount;
/**说说内容
 */
@property(nonatomic,retain) JBoLookAndTellListInfo *info;

/**根据说说类型 显示样式
 */
@property(nonatomic,assign) JBoMsgOperationVStyle style;
/**第几行说说
 */
@property(nonatomic,assign) NSInteger index;
@property(nonatomic,assign) id<JBoMsgOperationViewDelegate> delegate;

- (void)setTitle:(NSString*) title atIndex:(NSInteger) index;
- (void)setIcon:(UIImage*) icon atIndex:(NSInteger) index;
- (void)setIcon:(UIImage *) icon title:(NSString*) title atIndex:(NSInteger) index;

//获取视图高度
+ (CGFloat)getHeightWithStyle:(JBoMsgOperationVStyle) style canComplaint:(BOOL) canComplaint needImageText:(BOOL) needImageText;

@end
