//
//  JBoSignUpUserListViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSignUpUserListViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoBottomLoadingView.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoImageTextTool.h"
#import "JBoSignUpUserCell.h"
#import "UITableView+extraCellLine.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoSignUpInfo.h"
#import "JBoUserOperation.h"
#import "JBoWebViewController.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoUserInfoViewController.h"

@interface JBoSignUpUserListViewController ()<JBoHttpRequestDelegate, JBoSignUpUserCellDelegate>
{
    JBoHttpRequest *_httpRequest;
    
    //加载更多
    JBoBottomLoadingView *_bottomLoadingView;
}

@property(nonatomic,retain) UITableView *tableView;
@property(nonatomic,retain) NSMutableArray *infoArray;

@property(nonatomic,assign) BOOL isRequesting;

@property(nonatomic,assign) BOOL hasInfo;

//页码 和 每页数量
@property(nonatomic,assign) NSInteger pageIndex;
@property(nonatomic,assign) NSInteger pageSize;

//计算报名信息高度
@property(nonatomic,retain) JBoImageTextLabel *caculateHeight;

//当前登录用户的信息
@property(nonatomic,retain) JBoUserDetailInfo *myUserDetailInfo;

@end

@implementation JBoSignUpUserListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"报名的人";
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        self.isRequesting = NO;
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
        self.hasInfo = YES;
        
        self.pageIndex = 1;
        self.pageSize = 20;
        
        self.black = YES;
        
        self.caculateHeight = [[[JBoImageTextLabel alloc] init] autorelease];
        self.caculateHeight.font = _signUpUserInfoFont_;
        self.caculateHeight.textInset = _signUpUserInfoTextInset_;
        self.caculateHeight.minLineHeight = _signUpUserInfoMinLineHeight_;
        
        self.myUserDetailInfo = [JBoUserOperation getUserDetailInfo];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_tableView release];
    
    [_info release];
    [_httpRequest release];
    
    [_bottomLoadingView release];
    [_infoArray release];
    
    [_caculateHeight release];
    
    [_myUserDetailInfo release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if(self.isRequesting)
    {
        [self.appDelegate closeAlertView];
    }
}

#pragma mark-httpRequest
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [self alertNetworkMsg:@"获取报名的人失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    NSMutableArray *array = [JBoLookAndTellOperation getSignUpUserFromData:data];
    
    if(array.count > 0)
    {
        self.pageIndex ++;
        self.hasInfo = array.count == self.pageSize;
        [self.infoArray addObjectsFromArray:array];
        if(!_tableView)
        {
            [self loadInitView];
        }
        else
        {
            [_tableView reloadData];
        }
    }
    else
    {
        self.hasInfo = NO;
        [self alertMsg:@"暂无报名的人"];
    }
}

#pragma mark-加载视图

- (void)back
{
    [self canPerformAction:@selector(loadInfo:) withSender:self];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = [NSString stringWithFormat:@"报名的人(%d)", self.info.operationInfo.signUpCount];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setBackItem:YES];
    
    [self loadInfo:[NSNumber numberWithBool:NO]];
}

- (void)loadInfo:(NSNumber*) hidden
{
    if(self.isRequesting)
        return;
    
    self.isRequesting = YES;
    self.appDelegate.dataLoadingView.hidden = [hidden boolValue];
    
    NSString *groupId = self.info.transmitId == _trasmitNo_ ? self.info.groupId : self.info.srcGroupId;
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation getSignUpUsersWithId:groupId pageNum:self.pageIndex row:self.pageSize]];
}

- (void)loadInitView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
}


#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoSignUpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    if([self hideSignupInfo:info])
    {
        return _signUpUserCellInterval_ * 2 + _signUpUserCellHeadImageSize_;
    }
    else
    {
        if(info.componentHeight == NSNotFound)
        {
            CGSize size = [JBoImageTextTool getHeightFromAttributedText:[self.caculateHeight getAttributedTextFromString:[info getComponent]] contraintWidth:_width_ - _signUpUserCellInterval_ * 3 - _signUpUserInfoTextInset_ * 2 - _signUpUserCellHeadImageSize_];
            info.componentHeight = size.height + 5.0;
        }
        
        CGFloat height = info.componentHeight + _signUpUserCellNameHeight_ + _signUpUserCellInterval_ * 2;
        if(height < _signUpUserCellInterval_ * 2 + _signUpUserCellHeadImageSize_)
        {
            height = _signUpUserCellHeadImageSize_ + _signUpUserCellInterval_ * 2;
        }
        return height;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoSignUpUserCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoSignUpUserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoSignUpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    cell.nameLabel.text = info.detailInfo.rosterInfo.name;
    cell.nameLabel.sex = info.detailInfo.rosterInfo.sex;
    cell.headImageView.role = info.detailInfo.rosterInfo.role;
    
    cell.headImageView.sex = info.detailInfo.rosterInfo.sex;
    cell.headImageView.headImageURL = info.detailInfo.rosterInfo.imageURL;
    
    cell.hideSignupInfo = [self hideSignupInfo:info];
    
    if(!cell.hideSignupInfo)
    {
        cell.signUpInfoHeight = info.componentHeight;
        cell.signUpInfoLabel.text = [info getComponent];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    JBoSignUpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    if([info.detailInfo.rosterInfo.username isEqualToString:[JBoUserOperation getUserId]])
    {
        JBoUserInfoViewController *userInfoVC = [[JBoUserInfoViewController alloc] init];
        userInfoVC.black = self.black;
        [self.navigationController pushViewController:userInfoVC animated:YES];
        [userInfoVC release];
    }
    else
    {
        JBoRosterInfo *rosterInfo = [self.appDelegate.rosterAndUsernameDic objectForKey:info.detailInfo.rosterInfo.username];
        if(rosterInfo)
        {
            JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
            detail.rosterInfo = rosterInfo;
            detail.black = self.black;
            [self.navigationController pushViewController:detail animated:YES];
            [detail release];
        }
        else
        {
            JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
            userInfo.userDetailInfo = info.detailInfo;
            userInfo.black = self.black;
            [self.navigationController pushViewController:userInfo animated:YES];
            [userInfo release];
        }
    }
}

- (BOOL)hideSignupInfo:(JBoSignUpInfo*) info
{
    if([info.detailInfo.rosterInfo.username isEqualToString:self.myUserDetailInfo.rosterInfo.username])
    {
        return NO;
    }
    
    NSString *userId = self.info.transmitId == _trasmitNo_ ? self.info.userID : self.info.srcUserId;
    if([userId isEqualToString:self.myUserDetailInfo.rosterInfo.username])
    {
        return NO;
    }
    
    return YES;
}

#pragma mark- JBoSignUpUserCell 代理

- (void)signUpUserCell:(JBoSignUpUserCell *)cell didSelectedURL:(NSURL *)url
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    JBoSignUpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.userId = info.detailInfo.rosterInfo.username;
    web.URL = url;
    web.black = self.black;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(self.hasInfo && !self.isRequesting)
    {
        if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
        {
            if(!_bottomLoadingView)
            {
                //创建加载更多视图
                _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            }

            _tableView.tableFooterView = _bottomLoadingView;
            [self performSelector:@selector(loadInfo:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.5];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];

}

@end
