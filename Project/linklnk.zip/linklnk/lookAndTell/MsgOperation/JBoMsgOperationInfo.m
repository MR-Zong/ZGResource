//
//  JBoMsgOperationInfo.m
//  连你
//
//  Created by kinghe005 on 14-4-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMsgOperationInfo.h"
#import "JBoLookAndTellCommentInfo.h"

@implementation JBoMsgOperationInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.commentInfoArray = [NSMutableArray array];
    }
    
    return self;
}

- (void)dealloc
{
    [_commentInfoArray release];
    [super dealloc];
}

@end
