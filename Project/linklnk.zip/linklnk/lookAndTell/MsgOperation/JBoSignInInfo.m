//
//  JBoSignInInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSignInInfo.h"

@implementation JBoSignInInfo

- (void)dealloc
{
    [_Id release];
    [_userId release];
    
    [_name release];
    [_headImageURL release];
    
    [_locationImageURL release];
    [_address release];
    [_date release];
    
    [super dealloc];
}

@end
