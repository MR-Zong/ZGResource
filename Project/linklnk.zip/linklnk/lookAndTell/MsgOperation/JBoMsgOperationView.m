//
//  JBoMsgOperationView.m
//  连你
//
//  Created by kinghe005 on 14-3-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMsgOperationView.h"
#import "JBoUserOperation.h"

#define _padding_ 10.0
#define _startTag_ 1000
#define _maxCellsPerRow_ 3

#pragma mark-cell

@implementation JBoMsgOperationViewCell


+ (id)buttonWithType:(UIButtonType)buttonType
{
    
    UIButton *button = [super buttonWithType:buttonType];
    [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:10.0];
    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    return button;
}

@end

#pragma mark-

@interface JBoMsgOperationContentItem ()

@property(nonatomic,assign) id tapTarget;
@property(nonatomic,assign) SEL tapSelector;
@property(nonatomic,retain) UIView *hightlightView;

@end

@implementation JBoMsgOperationContentItem

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        _titleLabel = [[JBoAttributedLabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.numberOfLines = 0;
        _titleLabel.textColor = [UIColor grayColor];
        _titleLabel.font = [UIFont systemFontOfSize:12.0];
        [self addSubview:_titleLabel];
        
        [self initialize];
        self.validTouchRect = self.bounds;
    }
    return self;
}

- (void)initialize
{
    self.hightlightView = [[[UIView alloc] initWithFrame:self.bounds] autorelease];
    [self addSubview:self.hightlightView];
    self.hightlightView.hidden = YES;
    
    self.animationColor = [UIColor colorWithWhite:0.667 alpha:0.7];
}

- (void)setAnimationColor:(UIColor *)animationColor
{
    if(_animationColor != animationColor)
    {
        [_animationColor release];
        _animationColor = [animationColor retain];
        self.hightlightView.backgroundColor = _animationColor;
    }
}

- (void)addTarget:(id)target singleTapAction:(SEL)selector
{
    self.tapTarget = target;
    self.tapSelector = selector;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    tap.delegate = self;
    [self addGestureRecognizer:tap];
    [tap release];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    CGPoint point = [touch locationInView:self];
    if(CGRectContainsPoint(self.validTouchRect, point))
    {
        return YES;
    }
    return NO;
}

- (void)tapAction:(UITapGestureRecognizer*) tap
{
    self.hightlightView.hidden = NO;
    [self performSelector:@selector(hidden) withObject:nil afterDelay:0.15];
    [self.tapTarget performSelector:self.tapSelector withObject:tap];
    
}

- (void)hidden
{
    self.hightlightView.hidden = YES;
}

- (void)setValidTouchRect:(CGRect)validTouchRect
{
    _validTouchRect = validTouchRect;
    self.hightlightView.frame = _validTouchRect;
}

- (void)setStyle:(JBoMsgOperationItemStyle)style
{
    _style = style;
    switch (_style)
    {
        case JBoMsgOperationItemStyleTransmit :
        case JBoMsgOperationItemStylePraise :
        case JBoMsgOperationItemStylePity :
            self.userInteractionEnabled = NO;
            break;
        default:
            self.userInteractionEnabled = YES;
            break;
    }
}

- (void)dealloc
{
    [_titleLabel release];
    [_hightlightView release];
    [_animationColor release];
    
    [super dealloc];
}

@end

#pragma mark-JBoMsgOperationContentView

@implementation JBoMsgOperationContentView

- (id)initWithFrame:(CGRect)frame arrowPoint:(CGPoint)arrowPoint titles:(NSArray *)titles info:(JBoLookAndTellListInfo *)info
{
    self = [super initWithFrame:frame arrowPoint:arrowPoint];
    if(self)
    {
        self.contentColor = [UIColor colorWithRed:61.0 / 255.0 green:215.0 / 255.0 blue:21.0 / 255.0 alpha:1.0];
        self.style = JBoArrowViewStyleBorder;
        
        if(titles.count > 0)
        {
            CGFloat padding = _msgOperationInnerPadding_;
            
            CGFloat height = arrowPoint.y + self.arrowSize.height + 5.0;
            for(NSInteger i = 0;i < titles.count;i ++)
            {
                JBoMsgOperationItemInfo *itemInfo = [titles objectAtIndex:i];
                JBoMsgOperationContentItem *item = [[JBoMsgOperationContentItem alloc] initWithFrame:CGRectMake(padding, height, frame.size.width - padding * 2, itemInfo.titleHeight)];
                [item addTarget:self singleTapAction:@selector(itemDidSelected:)];
                item.titleLabel.attributedText_5 = itemInfo.content;
                item.style = itemInfo.style;
                
                if(item.style == JBoMsgOperationItemStyleComment)
                {
                    item.commentIndex = itemInfo.commentIndex;
                    item.validTouchRect = CGRectMake(0, 0, itemInfo.title.length * 15.0, _msgOperationItemHeight_);
                }
                
                [self addSubview:item];
                [item release];
                
                height += itemInfo.titleHeight;
            }
            
            self.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, height);
            
        }
        
    }
    
    return self;
}

- (void)itemDidSelected:(UITapGestureRecognizer*) tap
{
    JBoMsgOperationContentItem *item = (JBoMsgOperationContentItem*) tap.view;
    
    if([self.delegate respondsToSelector:@selector(msgOperationContentView:didSelctedAtItem:)])
    {
        [self.delegate msgOperationContentView:self didSelctedAtItem:item];
    }
}


@end

#pragma mark-msgOperationViewTitle

@implementation JBoMsgOperationTitle

+ (JBoMsgOperationTitle*)titleStyle:(JBoMsgOperationItemStyle)style info:(JBoLookAndTellListInfo *)info
{
    JBoMsgOperationTitle *msgOperationTitle = [[JBoMsgOperationTitle alloc] init];
    msgOperationTitle.style = style;
    
    switch (style)
    {
        case JBoMsgOperationItemStyleTransmit :
        {
            msgOperationTitle.title = transmit;
            msgOperationTitle.icon = [UIImage imageNamed:@"transmit_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleApply :
        {
            msgOperationTitle.title = apply;
            if([info.userID isEqualToString:[JBoUserOperation getUserId]])
                msgOperationTitle.title = applyPerson;
            
            msgOperationTitle.icon = [UIImage imageNamed:@"apply_for.png"];
        }
            break;
        case JBoMsgOperationItemStylePraise :
        {
            msgOperationTitle.title = praise;
            if(info.operationInfo.good)
                msgOperationTitle.title = cancelPraise;
            msgOperationTitle.icon = [UIImage imageNamed:@"praise_icon.png"];
        }
            break;
        case JBoMsgOperationItemStylePity :
        {
            msgOperationTitle.title = pity;
            if(info.operationInfo.pity)
                msgOperationTitle.title = cancelPity;
            msgOperationTitle.icon = [UIImage imageNamed:@"pity_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleSignUp :
        {
            msgOperationTitle.title = signUp;
            if(info.operationInfo.signUp)
                msgOperationTitle.title = alreadSignUp;
            msgOperationTitle.icon = [UIImage imageNamed:@"sign_up.png"];
        }
            break;
        case JBoMsgOperationItemStyleSignIn :
        {
            msgOperationTitle.title = signIn;
            if(info.operationInfo.signIn)
                msgOperationTitle.title = alreadSignIn;
            msgOperationTitle.icon = [UIImage imageNamed:@"sign_in.png"];
        }
            break;
        case JBoMsgOperationItemStyleWitness :
        {
            msgOperationTitle.title = witness;
            if(info.operationInfo.witness)
                msgOperationTitle.title = alreadWitness;
            msgOperationTitle.icon = [UIImage imageNamed:@"witness_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleVoluteer :
        {
            msgOperationTitle.title = volunteer;
            msgOperationTitle.icon = [UIImage imageNamed:@"volunteer_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleDonate :
        {
            msgOperationTitle.title = donate;
            msgOperationTitle.icon = [UIImage imageNamed:@"donate_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleDelete :
        {
            msgOperationTitle.title = deleted;
            msgOperationTitle.icon = [UIImage imageNamed:@"delete_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleStick :
        {
            msgOperationTitle.title = stick;
            if(info.stick == _lookAndTellStickYes_)
                msgOperationTitle.title = cancelStick;
            
            msgOperationTitle.icon = [UIImage imageNamed:@"stick_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleComplaint :
        {
            msgOperationTitle.title = complaint;
            msgOperationTitle.icon = [UIImage imageNamed:@"complaint_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleSelected :
        {
            msgOperationTitle.title = sceneSelected;
            if(info.operationInfo.selected)
                msgOperationTitle.title = cancelSelected;
            msgOperationTitle.icon = [UIImage imageNamed:@"relate_circle_icon.png"];
        }
            break;
        case JBoMsgOperationItemStyleVisible :
        {
            if(info.visible == _lookAndTellVisiblePublic_)
            {
                msgOperationTitle.title = setupPrivate;
                msgOperationTitle.icon = [UIImage imageNamed:@"private_icon.png"];
            }
            else if(info.visible == _lookAndTellVisiblePrivate_)
            {
                msgOperationTitle.title = setupPublic;
                msgOperationTitle.icon = [UIImage imageNamed:@"public_icon.png"];
            }
        }
            break;
        case JBoMsgOperationItemStyleComment :
        {
            msgOperationTitle.title = lookAndTellComment;
            msgOperationTitle.icon = [UIImage imageNamed:@"comment_icon.png"];
        }
            break;
        default:
            break;
    }
    
    return [msgOperationTitle autorelease];
}

- (void)dealloc
{
    [_title release];
    [_icon release];
    [super dealloc];
}

@end

#pragma mark-msgOperationView

@interface JBoMsgOperationView ()

@property(nonatomic,retain) NSMutableArray *titleArray;

@end

@implementation JBoMsgOperationView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.style = NSNotFound;
        self.showCommentCount = _lookAndTellShowCommentCount_;
    }
    return self;
}

- (void)dealloc
{
    [_info release];
    [_titleArray release];
    
    [super dealloc];
}

#pragma mark-publick Method
- (void)setStyle:(JBoMsgOperationVStyle)style
{
    _style = style;
    [self reloadData];
}

//设置cell
- (void)setTitle:(NSString *)title atIndex:(NSInteger)index
{
    JBoMsgOperationViewCell *cell = (JBoMsgOperationViewCell*)[self viewWithTag:_startTag_ + index];
    cell.titleLabel.text = title;
}

- (void)setIcon:(UIImage *)icon atIndex:(NSInteger)index
{
    JBoMsgOperationViewCell *cell = (JBoMsgOperationViewCell*)[self viewWithTag:_startTag_ + index];
    [cell setImage:icon forState:UIControlStateNormal];
}

- (void)setIcon:(UIImage *)icon title:(NSString *)title atIndex:(NSInteger)index
{
    JBoMsgOperationViewCell *cell = (JBoMsgOperationViewCell*)[self viewWithTag:_startTag_ + index];
    [cell setTitle:title forState:UIControlStateNormal];
    [cell setImage:icon forState:UIControlStateNormal];
}

//获取视图高度
+ (CGFloat)getHeightWithStyle:(JBoMsgOperationVStyle) style canComplaint:(BOOL)canComplaint needImageText:(BOOL)needImageText
{
    switch (style)
    {
        case JBoMsgOperationVStyleDefault :
        case JBoMsgOperationVStyleShareLink :
        case JBoMsgOperationVStyleShareShortMovie :
        {
            CGFloat height = _msgOperationItemHeight_ * 2 + _padding_;
            return height;
        }
            break;
        case JBoMsgOperationVStyleMakeFriend :
        case JBoMsgOperationVStyleBusiness :
        case JBoMsgOperationVStyleLifeService :
        {
            CGFloat height = _msgOperationItemHeight_ * 2 + _padding_ * 1;
            if(needImageText || canComplaint)
            {
                height += _msgOperationItemHeight_ + _padding_;
            }
            return height;
        }
            break;
        case JBoMsgOperationVStyleLoving :
        {
            CGFloat height = _msgOperationItemHeight_ * 2 +_padding_;
            if(canComplaint)
                height += _msgOperationItemHeight_ + _padding_;
            return height;
        }
            break;
        case JBoMsgOperationUserOperation :
            return _msgOperationItemHeight_ * 2 + _padding_;
            break;
        case JBoMsgOperationVStyleScene :
            return _msgOperationItemHeight_ + _padding_;
            break;
        case JBoMsgOperationVStyleLoading :
            return 0;
            break;
        default:
            return 0;
            break;
    }
}

#pragma mark-private Method

- (void)setupItems
{
    switch (self.style)
    {
        case JBoMsgOperationVStyleDefault :
        case JBoMsgOperationVStyleShareLink :
        case JBoMsgOperationVStyleShareShortMovie :
        {
            self.titleArray = [NSMutableArray arrayWithObjects:
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleTransmit info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePraise info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePity info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComment info:self.info],
                               nil];
            if(self.canComplaint)
            {
                [self.titleArray addObject:[JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComplaint info:self.info]];
            }
            
        }
            break;
        case JBoMsgOperationVStyleBusiness :
        case JBoMsgOperationVStyleMakeFriend :
        case JBoMsgOperationVStyleLifeService :
        {
            self.titleArray = [NSMutableArray arrayWithObjects:
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleTransmit info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePraise info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePity info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleSignUp info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleSignIn info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComment info:self.info],
                               nil];
            
            if(self.info.needImageText)
            {
                [self.titleArray addObject:[JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleApply info:self.info]];
            }
            
            if(self.canComplaint)
            {
                [self.titleArray insertObject:[JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComplaint info:self.info] atIndex:3];
            }
        }
            break;
        case JBoMsgOperationVStyleLoving :
        {
            self.titleArray = [NSMutableArray arrayWithObjects:
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleTransmit info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePity info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleWitness info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleVoluteer info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleDonate info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComment info:self.info],
                               nil];
            if(self.canComplaint)
            {
                [self.titleArray insertObject:[JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComplaint info:self.info] atIndex:3];
            }
        }
            break;
        case JBoMsgOperationUserOperation :
        {
            self.titleArray = [NSMutableArray arrayWithObjects:
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleDelete info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleStick info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleVisible info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComment info:self.info],
                               nil];
            if(self.info.needImageText)
            {
                [self.titleArray addObject:[JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleApply info:self.info]];
            }
            
        }
            break;
        case JBoMsgOperationVStyleUserInfo :
        {
            self.titleArray = [NSMutableArray arrayWithObjects:
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleTransmit info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePraise info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStylePity info:self.info],
                               [JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleComment info:self.info],
                               nil];
        }
            break;
        case JBoMsgOperationVStyleLoading :
        {
            self.titleArray = [NSMutableArray array];
        }
            break;
        case JBoMsgOperationVStyleScene :
        {
            self.titleArray = [NSMutableArray arrayWithObject:[JBoMsgOperationTitle titleStyle:JBoMsgOperationItemStyleSelected info:self.info]];
        }
            break;
        default :
        {
            self.titleArray = [NSMutableArray array];
        }
            break;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    for(UIView *view in self.subviews)
    {
        [view removeFromSuperview];
    }
    
    CGFloat width = self.bounds.size.width / _maxCellsPerRow_;
    [self setupItems];
    
    CGFloat padding = _padding_;
    NSInteger rows = 0;
    NSInteger column = 0;
    
    for(NSInteger i = 0;i < self.titleArray.count; i ++)
    {
        if(i % _maxCellsPerRow_ == 0)
        {
            rows ++;
            column = 0;
        }
        
      
        CGFloat x = rows % 2 == 0 ? width * column : self.bounds.size.width - width * (column + 1);
        
        JBoMsgOperationViewCell *cell = [JBoMsgOperationViewCell buttonWithType:UIButtonTypeCustom];
        [cell setFrame:CGRectMake(x, (rows - 1) * (_msgOperationItemHeight_ + padding), width, _msgOperationItemHeight_)];
        [cell addTarget:self action:@selector(cellDidSelected:) forControlEvents:UIControlEventTouchUpInside];
    
        cell.index = i;
        cell.tag = _startTag_ + i;
        
        JBoMsgOperationTitle *title = [self.titleArray objectAtIndex:i];

        cell.style = title.style;
        [cell setTitle:title.title forState:UIControlStateNormal];
        [cell setImage:title.icon forState:UIControlStateNormal];
        
        [self addSubview:cell];
        column ++;
    }
    
    UIView *lastView = [self viewWithTag:self.titleArray.count + _startTag_ - 1];
    CGFloat y = lastView != nil ? lastView.frame.origin.y + lastView.frame.size.height : 0;
    JBoMsgOperationContentView *contentView = [[JBoMsgOperationContentView alloc] initWithFrame:CGRectMake(0, y, self.bounds.size.width, 0) arrowPoint:CGPointMake(self.bounds.size.width * 2 / 3, 0) titles:[self.info getMsgOperationInfosWithCommentCount:self.showCommentCount] info:self.info];
    contentView.delegate = self;
    [self addSubview:contentView];
    [contentView release];
    
    
    self.height = contentView.bottom + 10.0;
}

- (void)reloadData
{
    [self setNeedsLayout];
}

#pragma mark-JBoMsgOperationContentView代理
- (void)msgOperationContentView:(JBoMsgOperationContentView *)contentView didSelctedAtItem:(JBoMsgOperationContentItem *)item
{
    if([self.delegate respondsToSelector:@selector(msgOperationView:didSelectedAtItem:)])
    {
        [self.delegate msgOperationView:self didSelectedAtItem:item];
    }
}

- (void)cellDidSelected:(id) sender
{
    JBoMsgOperationViewCell *cell = (JBoMsgOperationViewCell*) sender;
    if([self.delegate respondsToSelector:@selector(msgOperationView:didSelectedAtCell:)])
    {
        [self.delegate msgOperationView:self didSelectedAtCell:cell];
    }
}

@end
