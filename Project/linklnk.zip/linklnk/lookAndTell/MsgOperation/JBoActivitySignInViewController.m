//
//  JBoActivitySignInViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoActivitySignInViewController.h"
#import "BMapKit.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoImageTextTool.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoFileManager.h"
#import "JBoLookAndTellOperation.h"
#import "JBoCustomInsetLabel.h"
#import "BMKGeoCodeSearch+Utilities.h"

#define _padding_ 10.0
#define _controlHeight_ 40
#define _controlInterval_ 5.0

@interface JBoActivitySignInViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,JBoHttpRequestDelegate,BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
    
    //定位
    BMKLocationService *_locationManager;
    
    //获取当前位置地址
    UIActivityIndicatorView *_actView;
}

//地理反编码
@property(nonatomic,retain) BMKGeoCodeSearch *addrSearch;

@property(nonatomic,assign) BOOL isRequesting;
//现场图片
@property(nonatomic,retain) UIImageView *locationImageView;
@property(nonatomic,retain) JBoCustomInsetLabel *timeLabel;
@property(nonatomic,retain) UILabel *alertLabel;
@property(nonatomic,retain) UIImageView *cameraImageView;
@property(nonatomic,retain) NSArray *filesArray;

//地址信息
@property(nonatomic,retain) UILabel *addressLabel;
@property(nonatomic,copy) NSString *addrInfo;
@property(nonatomic,assign) UIButton *iconButton;

//正在定位
@property(nonatomic,assign) BOOL locate;
@property(nonatomic,assign) BOOL locating;

//请求定位
@property(nonatomic,retain) CLLocationManager *sysLocationManager;

@end

@implementation JBoActivitySignInViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"签到";
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        self.locating = NO;
        self.locate = NO;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [JBoFileManager deleteFiles:self.filesArray];
    [_httpRequest release];
    [_groupId release];
    
    [_locationManager release];
    [_addrSearch release];
    [_actView release];
    
    [_locationImageView release];
    [_alertLabel release];
    [_filesArray release];
    
    [_timeLabel release];
    [_addressLabel release];
    [_addrInfo release];
    [_cameraImageView release];
    
    [_sysLocationManager release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
    
    [_locationManager stopUserLocationService];
    _locationManager.delegate = nil;
    _addrSearch.delegate = nil;
}

#pragma mark-httpRequest
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoFileManager deleteFiles:self.filesArray];
    [JBoUserOperation alertmsgWithBadNetwork:@"签到失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoFileManager deleteFiles:self.filesArray];
    if([JBoUserOperation isSuccess:data])
    {
        [JBoUserOperation alertMsg:@"已成功签到"];
        if([self.delegate respondsToSelector:@selector(activitySignInViewControllerDidPFinished:)])
        {
            [self.delegate activitySignInViewControllerDidPFinished:self];
        }
        else
        {
            [self back];
        }
    }
    else
    {
        
    }
}

#pragma mark-内存管理

- (void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)signIn
{
    if(self.locating)
    {
        [JBoUserOperation alertMsg:@"正在定位,请稍后..."];
        return;
    }
    
    if(self.locationImageView.image == nil)
    {
        [JBoUserOperation alertMsg:@"请上传自身位于现场的图片"];
        return;
    }
    
    if([NSString isEmpty:self.addrInfo])
    {
        [JBoUserOperation alertMsg:@"还没定位,无法签到"];
        return;
    }
    
    
    self.isRequesting = YES;
    UIImage *image = [JBoImageTextTool getImageFromView:self.locationImageView];
    self.filesArray = [JBoFileManager writeImageInTemporaryFile:[NSArray arrayWithObject:image] withCompressedScale:_lookAndTellImageCompressedScale_];
    
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation signInActivity] paraDic:[JBoLookAndTellOperation signInActivityInfoWithGroupId:self.groupId address:self.addrInfo] files:self.filesArray filesKey:_signInActivityPhoto_];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBar.translucent = NO;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back) image:[UIImage imageNamed:@"newsBact.png"]];
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(signIn) title:@"完成" backgroundImage:nil textColor:[UIColor blackColor]];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    //位置地址
    
    UIImage *icon = [UIImage imageNamed:@"location_icon.png"];
    UIButton *iconButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [iconButton setImage:icon forState:UIControlStateNormal];
    [iconButton setFrame:CGRectMake(_padding_, _padding_ + (_controlHeight_ - icon.size.height) / 2, icon.size.width, icon.size.height)];
    [iconButton addTarget:self action:@selector(location) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:iconButton];
    self.iconButton = iconButton;
    
    //位置地址
    self.addressLabel = [[[UILabel alloc] initWithFrame:CGRectMake(iconButton.frame.origin.x + iconButton.frame.size.width + _controlInterval_, _padding_, _width_ - iconButton.frame.origin.x * 2 - iconButton.frame.size.width - _controlInterval_, _controlHeight_)] autorelease];
    //_addressTextView.textAlignment = NSTextAlignmentCenter;
    self.addressLabel.textColor = [UIColor grayColor];
    self.addressLabel.numberOfLines = 0;
    self.addressLabel.font = [UIFont systemFontOfSize:14.0];
    self.addressLabel.hidden = YES;
    self.addressLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.addressLabel];
    
   
    [self location];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getCamera)];
    self.locationImageView = [[[UIImageView alloc] initWithFrame:CGRectMake(_padding_, _addressLabel.frame.origin.y + _addressLabel.frame.size.height + _controlInterval_, _width_ - _padding_ * 2, _width_ - _padding_ * 2)] autorelease];
    self.locationImageView.userInteractionEnabled = YES;
    [self.locationImageView addGestureRecognizer:tap];
    [tap release];
    self.locationImageView.backgroundColor = [UIColor lightTextColor];
    [self.view addSubview:self.locationImageView];
    
    JBoCustomInsetLabel *timeLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, self.locationImageView.frame.size.height - 30, self.locationImageView.frame.size.width, 30)];
    timeLabel.text = [JBoDatetimeTool getCurrentTime:@"YYYY-MM-dd HH:mm"];
    //timeLabel.shadowColor = [UIColor blackColor];
    timeLabel.font = [UIFont systemFontOfSize:13.0];
   // timeLabel.shadowOffset = CGSizeMake(2.0, 2.0);
    [timeLabel setTextAlign:JBoTextAlignmentRight];
    
    timeLabel.backgroundColor = [UIColor clearColor];
    timeLabel.textColor = [UIColor whiteColor];
    timeLabel.insets = UIEdgeInsetsMake(0, 0, 0, 20);
    [self.locationImageView addSubview:timeLabel];
    self.timeLabel = timeLabel;
    [timeLabel release];
    
    CGFloat alertWidth = 140;
    UIImage *cameraImage = [UIImage imageNamed:@"camera"];
    self.cameraImageView = [[[UIImageView alloc] initWithFrame:CGRectMake((_width_ - alertWidth - cameraImage.size.width) / 2, (self.locationImageView.bounds.size.width - cameraImage.size.height) / 2, cameraImage.size.width, cameraImage.size.height)] autorelease];;
    self.cameraImageView.image = cameraImage;
    [self.view addSubview:self.cameraImageView];
    
    
    self.alertLabel = [[[UILabel alloc] initWithFrame:CGRectMake(self.cameraImageView.frame.origin.x + self.cameraImageView.frame.size.width, (self.locationImageView.bounds.size.width - _controlHeight_) / 2, alertWidth, _controlHeight_)] autorelease];
    self.alertLabel.textColor = [UIColor grayColor];
    self.alertLabel.backgroundColor = [UIColor clearColor];
    //[self.alertLabel setTextAlign:JBoTextAlignmentCenter];
    
    self.alertLabel.text = @"上传自己现场照";
    [self.view addSubview:self.alertLabel];
    
}


#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    NSLog(@"拍照");
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    _appDelegate.dataLoadingView.hidden = NO;
    //图片选取
    dispatch_block_t block = ^(void)
    {
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        //NSLog(@"%f,%f",retImage.size.width, retImage.size.height);
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:retImage withSize:size];
       
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            self.locationImageView.image = thumbnail;
            
            CGSize retSize = thumbnail.size;
            retSize.width = retSize.width * 0.8;
            retSize.height = retSize.height * 0.8;
            
            self.locationImageView.frame = CGRectMake((_width_ - retSize.width) / 2, self.locationImageView.frame.origin.y, retSize.width, retSize.height);
            self.timeLabel.frame = CGRectMake(0, self.locationImageView.frame.size.height - self.timeLabel.frame.size.height, self.locationImageView.frame.size.width, self.timeLabel.frame.size.height);
            self.timeLabel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
            self.alertLabel.hidden = YES;
            self.cameraImageView.hidden = YES;
            _appDelegate.dataLoadingView.hidden = YES;
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:nil];
        });
    };
   
    dispatch_queue_t queue = dispatch_queue_create("camera", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [_appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}


#pragma mark-位置
- (void)finishLocation:(BOOL) success
{
    NSLog(@"定位完成");
    [_actView stopAnimating];
    _addressLabel.hidden = NO;
    
    if(success)
    {
        self.locate = YES;
        _addressLabel.text = self.addrInfo;
    }
    else
    {
        if([NSString isEmpty:self.addrInfo])
        {
            self.locate = NO;
            _addressLabel.text = @"无法确定您当前的位置";
        }
        else
        {
            [JBoUserOperation alertMsg:@"无法确定当前位置"];
        }
        
    }
    self.locating = NO;
}

#pragma mark- BMKGeoSearch delegate

//BMKSearchDelegate
- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(error != BMK_SEARCH_NO_ERROR)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        return;
    }
   
    self.addrInfo = result.address;
    [self finishLocation:YES];
}

#pragma mark-定位
- (void)location
{
//    if(self.locating)
//        return;
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        if([CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined)
        {
            self.sysLocationManager = [[[CLLocationManager alloc] init] autorelease];
            
            [self.sysLocationManager requestAlwaysAuthorization];
        }
#endif
    }
    
    BOOL canloc = NO;
    
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways;
#endif
    }
    else
    {
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized;
    }
    
    if(canloc)
    {
        self.addressLabel.hidden = YES;
        if(!_actView)
        {
            CGFloat size = 30;
            _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            _actView.hidesWhenStopped = YES;
            _actView.frame = CGRectMake(self.iconButton.frame.origin.x + self.iconButton.frame.size.width + _controlInterval_, _addressLabel.frame.origin.y + (_addressLabel.frame.size.height - size) / 2, size, size);
            [self.view addSubview:_actView];
        }
        
        [_actView startAnimating];
        
        if(!_locationManager)
        {
            _locationManager = [[BMKLocationService alloc] init];
            _locationManager.delegate = self;
        }
        self.locating = YES;
        [_locationManager startUserLocationService];
    }
    else
    {
        [self finishLocation:NO];
    }
}

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {

        if(!_addrSearch)
        {
            self.addrSearch = [BMKGeoCodeSearch sharedInstance];
        }
        self.addrSearch.delegate = self;
        
        BMKReverseGeoCodeOption *option = [[[BMKReverseGeoCodeOption alloc] init] autorelease];
        option.reverseGeoPoint = userLocation.location.coordinate;
        
        if([_addrSearch reverseGeoCode:option])
        {
            NSLog(@"地理反编码");
        }
        
        [_locationManager stopUserLocationService];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
