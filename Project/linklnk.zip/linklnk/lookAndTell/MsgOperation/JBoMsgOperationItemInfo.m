//
//  JBoMsgOperationItemInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMsgOperationItemInfo.h"

@implementation JBoMsgOperationItemInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.titleHeight = _msgOperationItemHeight_;
        self.commentIndex = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_title release];
    [_content release];
    
    [super dealloc];
}

@end
