//
//  JBoWitnessViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JBoWitnessViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UILabel *_hasNoInfoLabel;
}

@property(nonatomic,copy) NSString *groupId;
@property(nonatomic,assign) BOOL black;

@end
