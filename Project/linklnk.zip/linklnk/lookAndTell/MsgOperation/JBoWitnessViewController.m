//
//  JBoWitnessViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

//
//  JBoCircleLookAndTellViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoWitnessViewController.h"
#import "JBoAppDelegate.h"
#import "JBoLookAndTellOperation.h"
#import "JBoBottomLoadingView.h"
#import "JBoImageTextTool.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoUserDetailInfo.h"
#import "JBoImageBrowerViewController.h"
#import "UITableView+extraCellLine.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoReuseScrollViewCell.h"
#import "JBoReuseScrollView.h"
#import "JBoReuseScrollInfo.h"
#import "JBoWebViewController.h"
#import "UIImage+customImage.h"
#import "JBoWitnessCell.h"
#import "JBoWitnessInfo.h"
#import "JBoPublickUserInfoViewController.h"

@interface JBoWitnessViewController ()<JBoHttpRequestDelegate,JBoReuseScrollViewDelegate,JBoWitnessCellDelegate>
{
    JBoAppDelegate *_appDelegate;
    
    JBoBottomLoadingView *_bottomLoadingView;
    BOOL _hasInfo;
    
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,retain) UITableView *tableView;
@property(nonatomic,retain) NSMutableArray *infoArray;

@property(nonatomic,assign) NSInteger pageIndex;
@property(nonatomic,assign) NSInteger pageSize;

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

@property(nonatomic,retain) UIFont *contentFont;
@property(nonatomic,assign) NSInteger currentIndex;

@property(nonatomic,retain) NSMutableArray *imageURLArray;
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;

@end

@implementation JBoWitnessViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"证明人";
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;

        
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
        
        self.pageIndex = 1;
        self.pageSize = 10;
        _hasInfo = YES;
        self.isRequesting = NO;
        
        self.contentFont = _lookAndTellFont_;
        
        //获取用户个人信息
//        NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:_loginDetailUserInfo_];
//        self.userDetailInfo = [NSKeyedUnarchiver unarchiveObjectWithData:data];

        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
//        self.isEnterpriseUser = NO;
//        JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
//        if(info.rosterInfo.role == _rosterRoleEnterprise_)
//        {
//            self.isEnterpriseUser = YES;
//        }
        
        self.black = YES;
    }
    return self;
}

#pragma mark-通知

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        if(!_isRequesting)
        {
            _tableView.tableFooterView = nil;
            _appDelegate.dataLoadingView.hidden = YES;
        }
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoWitnessViewController dealloc");
    [_tableView release];
    [_hasNoInfoLabel release];
    
    [_groupId release];
    
    [_infoArray release];
    
    [_bottomLoadingView release];
    [_httpRequest release];
    
    [_imageURLArray release];
    [_imageScrollView release];
    
    [_userDetailInfo release];
    [_contentFont release];
    
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_appDelegate closeAlertView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

#pragma mark-http代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取数据失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    NSMutableArray *array = [JBoLookAndTellOperation getActivityWinessFromData:data];
    if(array.count > 0)
    {
        _hasInfo = array.count == self.pageSize;
        self.pageIndex ++;
        [_infoArray addObjectsFromArray:array];
        if(!_tableView)
        {
            [self loadInitView];
        }
        else
        {
            [_tableView reloadData];
        }
    }
    else
    {
        _hasInfo = NO;
        if(!_tableView)
        {
            [self loadInitView];
        }
    }
}

#pragma mark-加载视图

- (void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    if(self.black)
    {
        //返回
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(backAction:) image:[UIImage imageNamed:@"newsBact.png"]];
    }
    else
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(backAction:)];
    }
    
	[self loadInfo:NO];
}

- (void)loadInfo:(BOOL) hidden
{
    if(self.isRequesting)
        return ;
    self.isRequesting = YES;
    _appDelegate.dataLoadingView.hidden = hidden;
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation getActivityWitnessWitthGroupId:self.groupId pageNum:self.pageIndex rows:self.pageSize]];
}

- (void)loadInitView
{
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tableView];
    
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
    
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        _tableView.separatorInset = UIEdgeInsetsZero;
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
    }
#endif
    
}

#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(_infoArray.count == 0)
    {
        if(!_hasNoInfoLabel)
        {
            CGFloat height = 30;
            _hasNoInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, (_height_ - _statuBarHeight_ - _navgateBarHeight_- height) / 2, _width_, height)];
            _hasNoInfoLabel.text = @"暂时没有证明人";
            _hasNoInfoLabel.textColor = [UIColor grayColor];
            [_hasNoInfoLabel setTextAlign:JBoTextAlignmentCenter];
            [self.view addSubview:_hasNoInfoLabel];
            [self.view bringSubviewToFront:_hasNoInfoLabel];
        }
        
        // _tableView.hidden = YES;
        _hasNoInfoLabel.hidden = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    else
    {
        _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _hasNoInfoLabel.hidden = YES;
       // NSLog(@"%@",_hasNoInfoLabel);
    }
    
    
    return _infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoWitnessInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    if(info.contentHeight == NSNotFound)
    {
        CGFloat height = 0;
        JBoImageTextLabel *label = [[JBoImageTextLabel alloc] init];
        label.textInset = _defaultMultiImageTextInset_;
        label.minLineHeight = _defaultMultiImageTextLineHeight_;
        label.wordInset = _defaultMultiImageTextWordInset_;
        label.font = _lookAndTellFont_;
        
        for(JBoMultiImageText *text in info.multiInfo)
        {
            NSAttributedString *attributedText = [label getAttributedTextFromString:text.content];
            text.titleHeight = [JBoImageTextTool getHeightFromAttributedText:attributedText contraintWidth:_defaultMultiImageTextViewWidth_].height + _defaultMultiImageTextInset_ * 2;
            text.imageHeight = [JBoMultiImageView getHeightWithCount:text.imageURLArray.count];

            height += text.titleHeight + text.imageHeight + _multiImageInterval_;
        }
    
        [label release];
        info.contentHeight = height;
    }
    
    CGFloat height = _headImageSize_ + _topPadding_ * 2 + info.contentHeight;
   // NSLog(@"%f",height);
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoWitnessCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoWitnessCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    JBoWitnessInfo *info = [_infoArray objectAtIndex:indexPath.row];

    cell.multiImageTextView.srcArray = info.multiInfo;
    
    // NSLog(@"%@",cell.multiImageView);
    cell.nameLabel.text = info.name;
    cell.nameLabel.sex = info.sex;
    //cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.date];
    cell.headImageView.sex = info.sex;
    cell.headImageView.role = info.role;
    cell.headImageView.sex = info.sex;
    cell.headImageView.headImageURL = info.headImageURL;
   
    return cell;
}

#pragma mark-JBoWitnessCell代理
- (void)witnessCell:(JBoWitnessCell *)cell imageDidSelectedAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    NSInteger currentIndex = 0;
    
    NSMutableArray *urlArray = [[NSMutableArray alloc] init];
    for(NSInteger i = 0;i < _infoArray.count;i ++)
    {
        JBoWitnessInfo *info = [_infoArray objectAtIndex:i];
        
        for(JBoMultiImageText *text in info.multiInfo)
        {
            CGFloat titleHeight = [JBoReuseScrollInfo getHeightWithContent:text.content];
            
            for(NSString *url in text.imageURLArray)
            {
                JBoReuseScrollInfo *bigInfo = [[JBoReuseScrollInfo alloc] init];
                bigInfo.msgId = text.msgId;
                bigInfo.title = text.content;
                bigInfo.url = url;
                bigInfo.titleHeight = titleHeight;
                
                [urlArray addObject:bigInfo];
                [bigInfo release];
            }
            
            if(i < indexPath.row)
            {
                currentIndex += text.imageURLArray.count;
            }
            
            if(i == indexPath.row)
            {
                currentIndex += index;
            }
        }
    }
    
    self.imageURLArray = urlArray;
    [urlArray release];
    
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = currentIndex;
    [self.imageScrollView reloadData];
    
    
    [self.imageScrollView showInViewController:self];
}

- (void)witnessCellHeadImageDidSelected:(JBoWitnessCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoWitnessInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
 
    JBoRosterInfo *rosterInfo = [_appDelegate.rosterAndUsernameDic objectForKey:info.userID];
    if(rosterInfo)
    {
        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
        detail.rosterInfo = rosterInfo;
        detail.black = self.black;
        [self.navigationController pushViewController:detail animated:YES];
        [detail release];
    }
    else
    {
        JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
        userInfo.userId = info.userID;
        userInfo.black = self.black;
        [self.navigationController pushViewController:userInfo animated:YES];
        [userInfo release];
    }
}

- (void)witnessCell:(JBoWitnessCell *)cell didSelectedURL:(NSURL *)url
{
    JBoWebViewController *webVC = [[JBoWebViewController alloc] init];
    webVC.URL = url;
    [webVC showInViewController:self animated:YES completion:nil];
    [webVC release];
}

#pragma mark-reuseScrollView代理
- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.imageURLArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        NSLog(@"reuse cell");
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    
    cell.titleLabel.text = info.title;
    cell.titleLabel.frame = CGRectMake(0, _height_ - info.titleHeight, _width_, info.titleHeight);
    scrollView.titleLabel.text = info.title;
    
    // NSLog(@"%@",image);
    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:info.url forIndex:index];
        }
    }
    //NSLog(@"reuse cell");
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    if(!image)
    {
        [self downloadImageWithUrl:info.url forIndex:index];
    }
}

- (BOOL)resuseScrollView:(JBoReuseScrollView *)scrollView isSameTitleAtIndex:(NSInteger)index withOtherIndex:(NSInteger)otherIndex
{
    if(otherIndex < 0 || otherIndex >= self.imageURLArray.count || index < 0 || index >= self.imageURLArray.count)
    {
        return YES;
    }
    
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    JBoReuseScrollInfo *otherInfo = [self.imageURLArray objectAtIndex:otherIndex];
    
    return info.msgId == otherInfo.msgId;
}

- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    self.imageURLArray = nil;
    [_tableView reloadData];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.imageScrollView cellForIndex:index];

        cell.imageView.image = image;
        [self.imageScrollView reloadDataAtIndex:index];
    }];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // NSLog(@"addressBook scrollViewDidScroll");
    if(!self.isRequesting && _hasInfo)
    {
        if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
        {
            if(!_bottomLoadingView)
            {
                //创建加载更多视图
                _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            }
            
            _tableView.tableFooterView = _bottomLoadingView;
            [self loadInfo:YES];
        }
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end

