//
//  JBoWitnessCell.h
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoMultiImageTextView.h"

#define _controlInterval_ 5
#define _controlHeight_ 21
#define _headImageSize_ 50
#define _lookAndTellCellNormalHeight_ 60
#define _tableHeaderViewHeight_ 130
#define _rightPadding_ 22
#define _topPadding_ 20

@class JBoWitnessCell;

@protocol JBoWitnessCellDelegate <NSObject>

@optional

/**点击图片
 *@param index 图片所属组中的下标
 */
- (void) witnessCell:(JBoWitnessCell*) cell imageDidSelectedAtIndex:(NSInteger) index;

/**点击头像
 */
- (void) witnessCellHeadImageDidSelected:(JBoWitnessCell *)cell;

/**点击链接
 */
- (void) witnessCell:(JBoWitnessCell *)cell didSelectedURL:(NSURL*) url;

@end

/**超友圈证明人 cell
 */
@interface JBoWitnessCell : UITableViewCell<JBoMultiImageTextViewDelegate>

/**多图文
 */
@property(nonatomic,readonly) JBoMultiImageTextView *multiImageTextView;

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**成为证明人的日期
 */
@property(nonatomic,readonly) UILabel *dateLabel;

//说说内容每行高度 字体
@property(nonatomic,assign) CGFloat contentWordHeight;
@property(nonatomic,retain) UIFont *contentFont;

@property(nonatomic,assign) id<JBoWitnessCellDelegate> delegate;

@end
