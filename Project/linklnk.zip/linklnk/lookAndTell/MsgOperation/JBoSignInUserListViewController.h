//
//  JBoSignInUserListViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**超友圈活动签到用户列表
 */
@interface JBoSignInUserListViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>

/**超友圈信息 groupId
 */
@property(nonatomic,copy) NSString *groupId;

@end
