//
//  JBoSignUpInfo.h
//  靓咖
//
//  Created by kinghe005 on 14-7-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserDetailInfo.h"

/**超友圈活动报名信息
 */
@interface JBoSignUpInfo : NSObject

/**个人信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *detailInfo;

/**报名真实姓名
 */
@property(nonatomic,copy) NSString *realName;

/**报名手机号
 */
@property(nonatomic,copy) NSString *phoneNum;

/**报名邮箱
 */
@property(nonatomic,copy) NSString *email;

/**报名备注
 */
@property(nonatomic,copy) NSString *remark;

/**报名序列号
 */
@property(nonatomic,copy) NSString *serialNum;

/**报名信息组合
 */
@property(nonatomic,copy) NSString *component;

/**报名信息组合高度
 */
@property(nonatomic,assign) NSInteger componentHeight;

/**获取报名信息组合
 */
- (NSString*)getComponent;

@end
