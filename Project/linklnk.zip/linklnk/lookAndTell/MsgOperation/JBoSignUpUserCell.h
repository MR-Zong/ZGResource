//
//  JBoSignUpUserCell.h
//  靓咖
//
//  Created by kinghe005 on 14-7-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoImageTextLabel.h"

#define _signUpUserCellInterval_ 10.0
#define _signUpUserCellHeadImageSize_ 60.0
#define _signUpUserCellNameHeight_ 25.0

#define _signUpUserInfoMinLineHeight_ 20.0
#define _signUpUserInfoTextInset_ 1.0
#define _signUpUserInfoFont_ [UIFont systemFontOfSize:15.0]

@class JBoSignUpUserCell;

@protocol JBoSignUpUserCellDelegate <NSObject>

/**点击链接
 */
- (void)signUpUserCell:(JBoSignUpUserCell*) cell didSelectedURL:(NSURL*) url;

@end

/**超友圈报名用户cell
 */
@interface JBoSignUpUserCell : UITableViewCell<JBoImageTextLabelDelegate>

/**头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**报名信息
 */
@property(nonatomic,readonly) JBoImageTextLabel *signUpInfoLabel;

/**报名信息高度
 */
@property(nonatomic,assign) NSInteger signUpInfoHeight;

/**是否隐藏报名信息
 */
@property(nonatomic,assign) BOOL hideSignupInfo;

@property(nonatomic,assign) id<JBoSignUpUserCellDelegate> delegate;

@end
