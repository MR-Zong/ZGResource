//
//  JBoSignInUserCell.m
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSignInUserCell.h"
#import "JBoBasic.h"
#import "JBoImageTextTool.h"

#define _controlInterval_ 5

@implementation JBoSignInUserCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouched:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_paddding_, _paddding_, _headImageSize_, _headImageSize_)];
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [self.contentView addSubview:_headImageView];
        [tap release];
        
        CGFloat width = _width_ - _headImageView.frame.origin.x - _headImageView.frame.size.width - _paddding_ * 2 - _controlInterval_;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _controlInterval_, _headImageView.frame.origin.y, width / 5 * 3, 20)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat x = _nameLabel.frame.origin.x - _nameLabel.frame.size.width;
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, _nameLabel.frame.origin.y, _width_ - x - _paddding_, _nameLabel.frame.size.height)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        [self.contentView addSubview:_dateLabel];
        
        CGFloat addressHeight = 40.0;
        
        UIImage *icon = [UIImage imageNamed:@"location_icon.png"];
        UIImageView *iconImage = [[UIImageView alloc] initWithImage:icon];
        iconImage.frame = CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.origin.y + _nameLabel.frame.size.height + (addressHeight - icon.size.height) / 2, icon.size.width, icon.size.height);
        [self.contentView addSubview:iconImage];
        [iconImage release];
        
        CGFloat labelX = iconImage.frame.origin.x + iconImage.frame.size.width + _controlInterval_;
        _addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(labelX, _nameLabel.frame.origin.y + _nameLabel.frame.size.height, _width_ - x - _paddding_, 40)];
        _addressLabel.backgroundColor = [UIColor clearColor];
        _addressLabel.font = [UIFont systemFontOfSize:15.0];
        [self.contentView addSubview:_addressLabel];
        
        UITapGestureRecognizer *locatonTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(locationImageDidSelected:)];
        _locationImageView = [[JBoImageView alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _addressLabel.frame.origin.y + _addressLabel.frame.size.height + _controlInterval_, _maxImageWidth_, _maxImageHeight_)];
        _locationImageView.userInteractionEnabled = YES;
        [_locationImageView addGestureRecognizer:locatonTap];
        [locatonTap release];
        [self.contentView addSubview:_locationImageView];
        
    }
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    [_addressLabel release];
    [_locationImageView release];
    
    [_headImageView release];
    [_nameLabel release];
    [_dateLabel release];
    
    [super dealloc];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    if(_locationImageView.image)
    {
        CGSize size;
        if(_locationImageView.image.size.width == _locationImageView.image.size.height)
        {
            size = CGSizeMake(_maxImageHeight_, _maxImageHeight_);
        }
        else
        {
            size = [JBoImageTextTool shrinkImage:_locationImageView.image WithSize:CGSizeMake(_maxImageWidth_, _maxImageHeight_) type:JBoShrinkImageTypeWidthAndHeight];
        }
        _locationImageView.frame = CGRectMake(_locationImageView.frame.origin.x, _locationImageView.frame.origin.y, size.width, size.height);
    }
    else
    {
        _locationImageView.frame = CGRectMake(_locationImageView.frame.origin.x, _locationImageView.frame.origin.y, _maxImageHeight_, _maxImageHeight_);
    }
}

#pragma mark- private method

//点击头像
- (void)headImageDidTouched:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(signInUserCellDidSelectedHeadImage:)])
    {
        [self.delegate signInUserCellDidSelectedHeadImage:self];
    }
}

//点击签到现场图片
- (void)locationImageDidSelected:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(signInUserCellDidSelectedLocationImage:)])
    {
        [self.delegate signInUserCellDidSelectedLocationImage:self];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
