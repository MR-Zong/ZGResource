//
//  JBoWitnessInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMultiImageTextInfo.h"

/**超友圈 证明人信息
 */
@interface JBoWitnessInfo : JBoMultiImageTextInfo

/**昵称
 */
@property(nonatomic,copy) NSString *name;

/**性别
 */
@property(nonatomic,assign) NSInteger sex;

/**身份
 */
@property(nonatomic,assign) NSInteger role;

/**头像
 */
@property(nonatomic,copy) NSString *headImageURL;

@end
