//
//  JBoMsgOperation.h
//  连你
//
//  Created by kinghe005 on 14-4-8.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoWitnessViewController.h"
#import "JBoBecomeWitnessViewController.h"

#import "JBoSignInUserListViewController.h"
#import "JBoSignUpUserListViewController.h"
#import "JBoActivitySignInViewController.h"
#import "JBoActivitySignUpViewController.h"

#import "JBoActivityActorListViewController.h"
#import "JBoJoinActivityViewController.h"

#import "JBoLovingVolunteerViewController.h"
#import "JBoLovingVolunteerListViewController.h"
#import "JBoLovingDonateViewController.h"
#import "JBoLovingDonateListViewController.h"

#import "JBoLookAndTellListInfo.h"

#import "JBoAppDelegate.h"
#import "JBoUserOperation.h"
#import "JBoLookAndTellOperation.h"
#import "JBoHttpRequest.h"

/**超友圈气泡 操作，点赞、同情等
 */
@interface JBoMsgOperation : NSObject<UIAlertViewDelegate>

@property(nonatomic,assign) UINavigationController *navigationController;

#pragma mark- 证明人

/**获取证明人列表
 *@param info 证明人关联的超友圈信息
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getWitness:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

/**成为证明人 会判断用户是否已实名认证，只有实名认证的用户才能成为证明人
 *@param info 证明人关联的超友圈信息
 *@param viewController 实现 JBoBecomeWitnessViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)becomeWitness:(JBoLookAndTellListInfo*) info viewController:(id<JBoBecomeWitnessViewControllerDelegate>) viewController black:(BOOL) black;

#pragma mark- 活动签到

/**活动签到 会判断用户是否已报名，只有报名的用户才能进行签到
 *@param info 所属超友圈活动
 *@param viewController 实现 JBoActivitySignInViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)activitySignIn:(JBoLookAndTellListInfo*) info viewController:(id<JBoActivitySignInViewControllerDelegate>) viewController black:(BOOL) black;

/**获取签到用户列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getSignInPerson:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

#pragma mark- 活动报名

/**取消报名
 *@param info 所属超友圈活动
 *@param queue 气泡操作网络请求队列
 */
+ (void)cancelSignUpWithInfo:(JBoLookAndTellListInfo*) info queue:(ASINetworkQueue*) queue;

/**报名
 *@param
 *@param viewController 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)signUpWithInfo:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

/**获取报名人列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getSignUpPerson:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

#pragma mark- 活动

/**申请参加活动
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)activityApply:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

/**获取参加活动的人
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getApplyPerson:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

#pragma mark- 志愿者

/**参加志愿者
 *@param info 所属超友圈活动
 *@param viewController 实现 JBoLovingVolunteerViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)becomeVolunteer:(JBoLookAndTellListInfo*) info viewController:(id<JBoLovingVolunteerViewControllerDelegate>) viewController black:(BOOL) black;

/**获取志愿者列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getVolunteerList:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

#pragma mark- 捐赠

/**捐赠
 *@param info 所属超友圈活动
 *@param viewController 实现 JBoLovingDonateViewControllerDelegate 的UIViewController, 用于present
 *@param black 导航栏的内容是否是黑色
 */
+ (void)donate:(JBoLookAndTellListInfo*) info viewController:(id<JBoLovingDonateViewControllerDelegate>) viewController black:(BOOL) black;

/**获取捐赠列表
 *@param info 所属超友圈活动
 *@param viewController 用于 push
 *@param black 导航栏的内容是否是黑色
 */
+ (void)getDonateList:(JBoLookAndTellListInfo*) info viewController:(UIViewController*) viewController black:(BOOL) black;

#pragma mark- 点赞、同情

/**点赞
 *@param info 所属超友圈活动
 *@param queue 气泡操作网络请求队列
 */
+ (void)setPraiseWithInfo:(JBoLookAndTellListInfo*) info queue:(ASINetworkQueue*) queue;

/**点同情
 *@param info 所属超友圈活动
 *@param queue 气泡操作网络请求队列
 */
+ (void)setPityWithInfo:(JBoLookAndTellListInfo*) info queue:(ASINetworkQueue*) queue;


@end
