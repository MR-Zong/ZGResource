//
//  JBoLuckyDrawView.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

//签到界面默认高度
#define _defaultLuckyDrawHeight_ 300.0

@class JBoLuckyDrawView;

/**超友圈活动 签到抽奖界面代理
 */
@protocol JBoLuckyDrawViewDelegate <NSObject>

/**抽奖完成
 *@param index 抽到的用户在 签到列表中的下标
 */
- (void)luckyDrawView:(JBoLuckyDrawView*) luckyDrawView didLuckyAtIndex:(NSInteger) index;

@end

/**超友圈活动 签到抽奖界面
 */
@interface JBoLuckyDrawView : UIView

/**签到用户信息 数组元素是 JBoSignInInfo
 */
@property(nonatomic,retain) NSMutableArray *srcArray;

/**已抽到的用户 数组元素是 userId
 */
@property(nonatomic,retain) NSMutableArray *luckyArray;

/**是否显示抽奖界面
 */
@property(nonatomic,assign) BOOL show;

/**超友圈信息 groupId
 */
@property(nonatomic,copy) NSString *groupId;


@property(nonatomic,assign) id<JBoLuckyDrawViewDelegate> delegate;

/**所关联的导航控制器
 */
@property(nonatomic,assign) UINavigationController *navigationController;

/**导航栏内容是否是黑色的
 */
@property(nonatomic,assign) BOOL black;

/**开始抽奖
 */
- (void)beginLuckyDraw;

/**结束抽奖
 */
- (void)endLuckyDraw;

/**选择某一行
 */
- (void)selectedAtIndex:(NSInteger) index animated:(BOOL) animated;

/**重新加载签到用户信息
 */
- (void)reloadData;


@end
