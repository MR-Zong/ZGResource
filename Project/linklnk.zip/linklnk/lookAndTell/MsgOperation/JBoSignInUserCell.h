//
//  JBoSignInUserCell.h
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"

//头像大小
#define _headImageSize_ 50.0

//签到信息内容边距
#define _paddding_ 20

//签到现场图片的最大宽高
#define _maxImageWidth_ 210
#define _maxImageHeight_ 120

@class JBoSignInUserCell;

@protocol JBoSignInUserCellDelegate <NSObject>

@optional

/**点击签到现场图片
 */
- (void)signInUserCellDidSelectedLocationImage:(JBoSignInUserCell*) cell;

/**点击头像
 */
- (void)signInUserCellDidSelectedHeadImage:(JBoSignInUserCell *)cell;

@end

/**超友圈签到用户 cell
 */
@interface JBoSignInUserCell : UITableViewCell

/**签到日期
 */
@property(nonatomic,readonly) UILabel *dateLabel;

/**签到地址
 */
@property(nonatomic,readonly) UILabel *addressLabel;

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**签到现场图片
 */
@property(nonatomic,readonly) JBoImageView *locationImageView;

@property(nonatomic,assign) id<JBoSignInUserCellDelegate> delegate;

@end
