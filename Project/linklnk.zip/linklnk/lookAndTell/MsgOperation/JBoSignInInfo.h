//
//  JBoSignInInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**超友圈活动 签到信息
 */
@interface JBoSignInInfo : NSObject

/**信息id
 */
@property(nonatomic,copy) NSString *Id;

/**签到用户id
 */
@property(nonatomic,copy) NSString *userId;

/**用户性别
 */
@property(nonatomic,assign) NSInteger sex;

/**用户身份
 */
@property(nonatomic,assign) NSInteger role;

/**用户昵称
 */
@property(nonatomic,copy) NSString *name;

/**用户头像路径
 */
@property(nonatomic,copy) NSString *headImageURL;

/**签到现场图片
 */
@property(nonatomic,copy) NSString *locationImageURL;

/**签到地址
 */
@property(nonatomic,copy) NSString *address;

/**签到日期
 */
@property(nonatomic,copy) NSString *date;

@end
