//
//  JBoLookAndTellOperation.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLookAndTellOperation.h"
#import "JBoBasic.h"
#import "JBoAppDelegate.h"
#import "GTMBase64.h"
#import "JBoUserDetailInfo.h"
#import "JSONKit.h"
#import "JBoUserOperation.h"
#import "NSDictionary+customDic.h"
#import "JBoImageTextTool.h"
#import "JBoLookAndTellBgImageInfo.h"
#import "JBoSignInInfo.h"
#import "JBoWitnessInfo.h"
#import "JBoSignUpInfo.h"
#import "JBoLookAndTellCommentInfo.h"

@interface JBoLookAndTellOperation ()

@end

@implementation JBoLookAndTellOperation

#pragma mark- 靓友圈数据解析

/**解析返回的数据，获取靓友圈信息
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param dataArray 未解析靓友圈信息，数组元素是NSDictionary 对象
 *@param offlineCache 离线缓存
 *@param isSelf 是否是获取自己的靓友圈信息
 *@return 靓友圈信息 数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)getInfoWithMulti:(NSMutableDictionary*) multiInfo fromDatas:(NSArray*) dataArray offlineCache:(JBoOfflineCacheOperation*) offlineCache isSelf:(BOOL) isSelf;
{
    // NSLog(@"%@",dataArray);
    NSMutableArray *infos = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
    for(NSDictionary *dic in dataArray)
    {
        if([dic isEqual:[NSNull null]] || dic == NULL)
        {
            continue;
        }
        
        NSInteger count = [[dic valueWithKey:_lookAndTellCount_] integerValue];
        NSString *groupId = [dic objectWithKey:_lookAndTellGroupId_];
        NSString *content = [dic objectWithKey:_lookAndTellContent_];
        NSString *imageURL = [dic objectWithKey:_lookAndTellImages_];
        
        NSInteger generalId = [[dic valueWithKey:_lookAndTellGerneralId_] integerValue];
        NSInteger transmitId = [[dic valueWithKey:_lookAndTellTransmitId_] integerValue];
        NSInteger enterpriseId = [[dic valueWithKey:_lookAndTellEnterpriseId_] integerValue];
        int type = [[dic valueWithKey:_lookAndTellType_] intValue];
        
        NSInteger joinActivityId = [[dic valueWithKey:_lookAndTellJoinActivityId_] integerValue];
        NSInteger startActivityId = [[dic valueWithKey:_lookAndTellStartActivityId_] integerValue];
        
        
        JBoLookAndTellListInfo *info = nil;
        JBoMultiImageText *text = nil;
        
        if(count <= 1 || [NSString isEmpty:groupId])
        {
            info = [[[JBoLookAndTellListInfo alloc] init] autorelease];
            
            text = [[[JBoMultiImageText alloc] init] autorelease];
            text.content = content;
            text.msgId = [[dic valueWithKey:_lookAndTellID_] longLongValue];
            text.srcMsgId = [[dic valueWithKey:_lookAndTellSrcId_] longLongValue];
            
            if([NSString isEmpty:text.content])
            {
                text.content = @" ";
            }
            
            NSInteger generalId = startActivityId == _laysReviewStateNormal_ ? joinActivityId : startActivityId;
            [JBoLookAndTellOperation addFaceIconWithTransmitId:transmitId type:type generalId:generalId enterpriseId:enterpriseId text:text];
            
            text.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
            info.multiInfo = [NSMutableArray arrayWithObject:text];
            
            [infos addObject:info];
            
            // NSLog(@"%@",text.content);
        }
        else
        {
            info = [multiInfo objectForKey:groupId];
            if(info == nil)
            {
                info = [[[JBoLookAndTellListInfo alloc] init] autorelease];
                info.multiInfo = [NSMutableArray arrayWithCapacity:count];
                [multiInfo setObject:info forKey:groupId];
            }
            
            text = [[[JBoMultiImageText alloc] init] autorelease];
            text.content = content;
            text.msgId = [[dic valueWithKey:_lookAndTellID_] longLongValue];
            
            text.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
            text.order = [[dic objectWithKey:_lookAndTellOrder_] integerValue];
            text.srcMsgId = [[dic valueWithKey:_lookAndTellSrcId_] longLongValue];
            
            if([NSString isEmpty:text.content])
            {
                text.content = @" ";
            }
            
            if(text.order == 0)
            {
                NSInteger generalId = startActivityId == _laysReviewStateNormal_ ? joinActivityId : startActivityId;
                [JBoLookAndTellOperation addFaceIconWithTransmitId:transmitId type:type generalId:generalId enterpriseId:enterpriseId text:text];
            }
            
            [info.multiInfo addObject:text];
            
            if(info.multiInfo.count == count)
            {
                NSArray *result = [info.multiInfo sortedArrayUsingComparator:^(id obj1, id obj2)
                                   {
                                       JBoMultiImageText *text1 = (JBoMultiImageText*)obj1;
                                       JBoMultiImageText *text2 = (JBoMultiImageText*)obj2;
                                       
                                       if(text1.order > text2.order)
                                       {
                                           return NSOrderedDescending;
                                       }
                                       
                                       if(text1.order > text2.order)
                                       {
                                           return NSOrderedAscending;
                                       }
                                       
                                       return NSOrderedSame;
                                   }];
                
                [info.multiInfo removeAllObjects];
                [info.multiInfo addObjectsFromArray:result];
                
                [infos addObject:info];
                [multiInfo removeObjectForKey:groupId];
            }
            //NSLog(@"%@",text.content);
        }
        
        info.allNum = count;
        info.groupId = groupId;
        info.date = [dic objectWithKey:_lookAndTellCreateDate_];
        
        info.generalId = generalId;
        info.enterpriseId = enterpriseId;
        info.srcUserId = [dic objectWithKey:_lookAndTellSrcUserId_];
        
        info.transmitId = transmitId;
        
        info.type = type;
        info.userID = [dic objectWithKey:_rosterUserId_];
        info.userName = [dic objectWithKey:_rosterName_];
        info.role = [[dic valueWithKey:_rosterRole_] integerValue];
        
        info.sex = [[dic valueWithKey:_rosterSex_] integerValue];
        info.headImageURL = [dic objectWithKey:_rosterImageURL_];
        info.srcGroupId = [dic objectWithKey:_lookAndTellSourceGroupId_];
        info.stick = [[dic valueWithKey:_lookAndTellStick_] integerValue];
        
        info.transmitCount = [[dic valueWithKey:_lookAndTellTransmitCount_] integerValue];
        
        info.url = [dic objectWithKey:_lookAndTellURL_];
        info.urlTitle = [dic objectWithKey:_lookAndTellURLTitle_];
        
        info.joinActivityId = joinActivityId;
        info.startActivityId = startActivityId;
        
        info.needImageText = [[dic valueWithKey:_lookAndTellIsUpload_] boolValue];
        info.operationInfo.style = (startActivityId >= _laysReviewStateWeek_ || joinActivityId >= _laysReviewStateWeek_) ? JBoMsgOperationVStyleDefault : type;
        
        info.visible = [[dic valueWithKey:_lookAndTellVisible_] integerValue];
        
        info.operationInfo.pityCount = [[dic valueWithKey:_lookAndTellPitynNum_] intValue];
        info.operationInfo.praiseCount = [[dic valueWithKey:_lookAndTellGoodNum_] intValue];
        info.operationInfo.signInCount = [[dic valueWithKey:_lookAndTellSignInNum_] intValue];
        info.operationInfo.signUpCount = [[dic valueWithKey:_lookAndTellSignUpNum_] intValue];
        info.operationInfo.donateCount = [[dic valueWithKey:_lookAndTellLoveGNum_] intValue];
        info.operationInfo.volunteerCount = [[dic valueWithKey:_lookAndTellLovePNum_] intValue];
        info.operationInfo.witnessCount = [[dic valueWithKey:_lookAndTellWitnessNum_] intValue];
        info.operationInfo.applyCount = [[dic valueWithKey:_lookAndTellApplyNum_] intValue];
        
        NSDictionary *eventDic = [dic objectForKey:_lookAndTellMsgEvent_];
        if([eventDic isKindOfClass:[NSDictionary class]])
        {
            info.operationInfo.good = [[eventDic valueWithKey:_lookAndTellGood_] boolValue];
            info.operationInfo.pity = [[eventDic valueWithKey:_lookAndTellPity_] boolValue];
            info.operationInfo.witness = [[eventDic valueWithKey:_lookAndTellWitness_] boolValue];
            
            info.operationInfo.signUp = [[eventDic valueWithKey:_lookAndTellSignUp_] boolValue];
            info.operationInfo.signIn = [[eventDic valueWithKey:_lookAndTellSignIn_] boolValue];
        }
        
        NSArray *commentArray = [dic objectForKey:_lookAndTellMsgComments_];
        if([commentArray isKindOfClass:[NSArray class]])
        {
            NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:commentArray.count];
            
            JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
            
            for(NSDictionary *dict in commentArray)
            {
                JBoLookAndTellCommentInfo *commentInfo = [[JBoLookAndTellCommentInfo alloc] init];
                
                commentInfo.Id = [[dict valueWithKey:_lookAndTellCommentId_] longLongValue];
                commentInfo.comment = [dict objectWithKey:_lookAndTellCommentContent_];
                commentInfo.time = [dict objectWithKey:_lookAndTellCommentDate_];
                
                commentInfo.userId = [dict objectWithKey:_lookAndTellCommentUser_];
                commentInfo.sex = [[dict valueWithKey:_rosterSex_] integerValue];
                
                NSString *name = [dict objectWithKey:_rosterName_];
                JBoRosterInfo *rosterInfo = [appDelegate.rosterAndUsernameDic objectForKey:commentInfo.userId];
                if(![NSString isEmpty:rosterInfo.remark])
                {
                    name = rosterInfo.remark;
                }
                commentInfo.name = name;
                
                [infoArray addObject:commentInfo];
                [commentInfo release];
            }
            info.operationInfo.commentInfoArray = infoArray;
            [infoArray release];
        }
        
        
        if(offlineCache)
        {
            [offlineCache removeBeautifulCircleWithMsgId:text.msgId isSelf:isSelf];
            [offlineCache insertBeautifulCircle:info multiImageText:text images:imageURL isSelf:isSelf];
        }
    }
    
    //插入评论和操作数
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        if(offlineCache)
        {
            for(JBoLookAndTellListInfo *info in infos)
            {
                [offlineCache deleteCircleOperationWithInfo:info];
                [offlineCache insertCircleOperationWithInfo:info];
                
                NSString *groupId = [info getGroupId];
                [offlineCache removeCircleCommentWithGroupId:groupId];
                for(JBoLookAndTellCommentInfo *commentInfo in info.operationInfo.commentInfoArray)
                {
                    [offlineCache insertCircleComment:commentInfo groupId:groupId];
                }
            }
        }
    });
    
    return [infos autorelease];
}


#pragma mark- 靓友圈信息内容

/**发布靓友圈信息，有图片
 *@return post请求url
 */
+ (NSString*)getReleaseLookAndTellURL
{
    return _releaseLookAndTell_;
}

/**发布靓友圈信息，没图片
 *@return post请求url
 */
+ (NSString*)getReleaseLookAndTellURLWithOutFiles
{
    return _releaseLookAndTellWithoutFiles_;
}

/**获取发布靓友圈信息参数
 *@param content 文本内容
 *@param type 靓友圈信息类型
 *@param groupId 组Id
 *@param order 多图文顺序
 *@param count 多图文数量
 *@param url 分享的链接
 *@param need 参加活动是否需要图文
 *@param visible 可见范围
 *@return post请求参数
 */
+ (NSDictionary*)releaseLookAndTellWithContent:(NSString *)content type:(NSInteger)type groupId:(NSString *)groupId order:(NSInteger)order count:(NSInteger)count url:(NSString *)url needImageText:(BOOL)need visible:(NSInteger)visible
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:content forKey:_lookAndTellContent_];
    [dic setObject:[NSNumber numberWithInteger:type] forKey:_lookAndTellType_];
    [dic setObject:groupId forKey:_lookAndTellGroupId_];
    [dic setObject:[NSNumber numberWithInteger:order] forKey:_lookAndTellOrder_];
    [dic setObject:[NSNumber numberWithInteger:count] forKey:_lookAndTellCount_];
    [dic setObject:[NSNumber numberWithBool:need] forKey:_lookAndTellIsUpload_];
    
    if(![NSString isEmpty:url])
    {
        [dic setObject:url forKey:_lookAndTellURL_];
    }
    
    if(visible == _lookAndTellVisiblePublic_ || visible == _lookAndTellVisiblePrivate_)
    {
        [dic setObject:[NSNumber numberWithInteger:visible] forKey:_lookAndTellVisible_];
    }
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
  //  NSLog(@"%@",dic);
    
    return [dic autorelease];
}

/**分享连接到靓友圈 参数
 *@param content 文本内容
 *@param groupId 组Id
 *@param urlTitle 链接标题
 *@param url 链接
 *@return post请求参数
 */
+ (NSDictionary*)shareLinkWithContent:(NSString*) content groupId:(NSString*) groupId urlTitle:(NSString*) urlTitle url:(NSString*) url
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:6];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:groupId forKey:_lookAndTellGroupId_];
    if(![NSString isEmpty:content])
    {
        [dic setObject:content forKey:_lookAndTellContent_];
    }
    
    if(![NSString isEmpty:urlTitle])
    {
        [dic setObject:urlTitle forKey:_lookAndTellURLTitle_];
    }
    else
    {
        [dic setObject:@"链接" forKey:_lookAndTellURLTitle_];
    }
    
    [dic setObject:url forKey:_lookAndTellURL_];
    
    [dic setObject:[NSNumber numberWithInt:_lookAndTellTypeShareLink_] forKey:_lookAndTellType_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
  //  NSLog(@"%@",dic);
    return [dic autorelease];
}

/**添加靓友圈信息类型图标
 *@param transmitId 是否为转载的
 *@param type 靓友圈信息类型
 *@param generalId 参加活动的审核状态
 *@param enterpriseId
 */
+ (void)addFaceIconWithTransmitId:(NSInteger) transmitId type:(NSInteger) type generalId:(NSInteger) generalId enterpriseId:(NSInteger) enterpriseId text:(JBoMultiImageText*) text
{
    switch (generalId)
    {
        case _laysReviewStateWeek_ :
            text.content = [_lookAndTellLaysPrimaryIcon_ stringByAppendingString:text.content];
            break;
        case _laysReviewStateMonth_ :
            text.content = [_lookAndTellLaysCheckIcon_ stringByAppendingString:text.content];
            break;
        case _laysReviewStateYear_ :
            text.content = [_lookAndTellLaysRunoffIcon_ stringByAppendingString:text.content];
            break;
        default:
            break;
    }
    
//    switch (enterpriseId)
//    {
//        case _laysEnterpriseTransmitWeek_ :
//            text.content = [_lookAndTellLaysPrimaryIcon_ stringByAppendingString:text.content];
//            break;
//        case _laysEnterpriseTransmitMonth_ :
//            text.content = [_lookAndTellLaysCheckIcon_ stringByAppendingString:text.content];
//            break;
//        case _laysEnterpriseTransmitYear_ :
//            text.content = [_lookAndTellLaysRunoffIcon_ stringByAppendingString:text.content];
//            break;
//        default:
//            break;
//    }
    
    switch (type)
    {
        case _sceneTypeBusiness_ :
            text.content = [_lookAndTellBusinessIcon_ stringByAppendingString:text.content];
            break;
        case _sceneTypeLifeService_ :
            text.content = [_lookAndTellLifeIcon_ stringByAppendingString:text.content];
            break;
        case _sceneTypeLoving_ :
            text.content = [_lookAndTellLovingIcon_ stringByAppendingString:text.content];
            break;
        default:
            break;
    }
    
    if(transmitId != _trasmitNo_)
    {
        text.content = [_lookAndTellTransmitIcon_ stringByAppendingString:text.content];
    }
}

/**获取靓友圈信息
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getCircleLookAndTellInfoWithPageNum:(NSInteger)pageNum rows:(NSInteger)rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _seeLookAndTellCircle_, _seeLookAndTellPhone_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取靓友圈信息
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param offineCache 离线缓存
 *@return 数组元素是 JBoLookAndTellListInfo 对象
 */
+ (NSMutableArray*)getCircleLookAndTellInfoFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo offlineCache:(JBoOfflineCacheOperation *)offlineCache
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
  //  NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        return [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:offlineCache isSelf:NO];
    }
    else
    {
        return nil;
    }
}

/**获取某个用户的靓友圈信息
 *@userId 用户id
 *@param pageNum 页码
 *@param rows 每页数量
 *visible 可见范围
 *@return get请求url
 */
+ (NSString*)getUserLookAndTellInfoWithUserId:(NSString *)userId pageNum:(NSInteger)pageNum rows:(NSInteger)rows visible:(NSInteger)visible
{
    NSString *url = nil;
    NSString *uid = [JBoUserOperation getUserId];
    
    if([uid isEqualToString:userId])
    {
         url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _seeUserLookAndTells_, _rosterUserId_, uid, _pageNum_, (int)pageNum, _rows_, (int)rows];
    }
    else
    {
         url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%@", _seeUserLookAndTells_, _rosterUserId_, uid, _pageNum_, (int)pageNum, _rows_, (int)rows, _lookAndTellTargetId_, userId];
    }
    
    if(visible == _lookAndTellVisiblePublic_ || visible == _lookAndTellVisiblePrivate_)
    {
        url = [NSString stringWithFormat:@"%@&%@=%d", url, _lookAndTellVisible_, (int)visible];
    }
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
   
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取某个用户的靓友圈信息
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param offineCache 离线缓存
 *@return 数组元素是 JBoLookAndTellListInfo 对象
 */
+ (NSMutableArray*)getUserLookAndTellInfoFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo offlineCache:(JBoOfflineCacheOperation *)offlineCache
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
 
   // NSLog(@"%@",dic);
  
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
       
        NSMutableArray *infoArray = [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:offlineCache isSelf:YES];
        
        return infoArray;
    }
    else
    {
        return nil;
    }
}

/**删除靓友圈信息
 *@param groupId 组Id
 *@return get请求url
 */
+ (NSString*)getRemoveLookAndTellWithGroupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@", _deleteLookAndTell_, _rosterUserId_, [JBoUserOperation getUserId], _lookAndTellGroupId_, groupId];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    NSLog(@"%@",url);
    return url;
}

/**根据靓友圈信息msgId获取它的详细信息
 *@param msgId 靓友圈信息的msgId
 *@return get请求url
 */
+ (NSString*)getLookAndTellFromMsgId:(NSString*) msgId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getLookAndTellWithId_, _laysReviewMsgId_, msgId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**通过返回的数据获取靓友圈信息
 *@param data 返回的数据
 *@return 靓友圈信息
 */
+ (JBoLookAndTellListInfo*)getLookAndTellFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        
        JBoLookAndTellListInfo *info = [[JBoLookAndTellListInfo alloc] init];
        // info.messageID = [dict objectWithKey:_lookAndTellID_];
        // info.content = [dict objectWithKey:_lookAndTellContent_];
        info.date = [dict objectWithKey:_lookAndTellCreateDate_];
        
        //info.type = [[dict objectWithKey:_lookAndTellType_] integerValue];
        info.generalId = [[dict valueWithKey:_lookAndTellGerneralId_] integerValue];
        info.enterpriseId = [[dict valueWithKey:_lookAndTellEnterpriseId_] integerValue];
        
        info.transmitId = [[dict valueWithKey:_lookAndTellTransmitId_] integerValue];
        info.transmitCount = [[dict valueWithKey:_lookAndTellTransmitCount_] integerValue];
        
        info.joinActivityId = [[dict valueWithKey:_lookAndTellJoinActivityId_] integerValue];
        info.startActivityId = [[dict valueWithKey:_lookAndTellStartActivityId_] integerValue];
        
        info.visible = [[dict valueWithKey:_lookAndTellVisible_] integerValue];
        
        NSString *content = [dict objectWithKey:_lookAndTellContent_];
        NSString *imageURL = [dict objectWithKey:_lookAndTellImages_];
        
        JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
        text.content = content;
        text.msgId = [[dic valueWithKey:_lookAndTellID_] longLongValue];
        
        if([NSString isEmpty:text.content])
        {
            text.content = @" ";
        }
        
        //        if((info.generalId >= _laysReviewStateWeek_)|| info.enterpriseId != _laysEnterpriseTransmitNormal_)
        //        {
        //            text.content = [_lookAndTellContentSpace_ stringByAppendingString:text.content];
        //        }
        //
        //        if(info.transmitId != _trasmitNo_)
        //        {
        //            text.content = [_lookAndTellContentSpace_ stringByAppendingString:text.content];
        //        }
        
        text.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
        
        info.multiInfo = [NSMutableArray arrayWithObject:text];
        
        info.visible = [[dic valueWithKey:_lookAndTellVisible_] integerValue];
        
        info.operationInfo.pityCount = [[dic valueWithKey:_lookAndTellPitynNum_] intValue];
        info.operationInfo.praiseCount = [[dic valueWithKey:_lookAndTellGoodNum_] intValue];
        info.operationInfo.signInCount = [[dic valueWithKey:_lookAndTellSignInNum_] intValue];
        info.operationInfo.signUpCount = [[dic valueWithKey:_lookAndTellSignUpNum_] intValue];
        info.operationInfo.donateCount = [[dic valueWithKey:_lookAndTellLoveGNum_] intValue];
        info.operationInfo.volunteerCount = [[dic valueWithKey:_lookAndTellLovePNum_] intValue];
        info.operationInfo.witnessCount = [[dic valueWithKey:_lookAndTellWitnessNum_] intValue];
        info.operationInfo.applyCount = [[dic valueWithKey:_lookAndTellApplyNum_] intValue];
        
        NSDictionary *eventDic = [dic objectForKey:_lookAndTellMsgEvent_];
        if([eventDic isKindOfClass:[NSDictionary class]])
        {
            info.operationInfo.good = [[eventDic valueWithKey:_lookAndTellGood_] boolValue];
            info.operationInfo.pity = [[eventDic valueWithKey:_lookAndTellPity_] boolValue];
            info.operationInfo.witness = [[eventDic valueWithKey:_lookAndTellWitness_] boolValue];
            
            info.operationInfo.signUp = [[eventDic valueWithKey:_lookAndTellSignUp_] boolValue];
            info.operationInfo.signIn = [[eventDic valueWithKey:_lookAndTellSignIn_] boolValue];
        }
        
        NSArray *commentArray = [dic objectForKey:_lookAndTellMsgComments_];
        if([commentArray isKindOfClass:[NSArray class]])
        {
            NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:commentArray.count];
            
            JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
            
            for(NSDictionary *dict in commentArray)
            {
                JBoLookAndTellCommentInfo *commentInfo = [[JBoLookAndTellCommentInfo alloc] init];
                
                commentInfo.Id = [[dict valueWithKey:_lookAndTellCommentId_] longLongValue];
                commentInfo.comment = [dict objectWithKey:_lookAndTellCommentContent_];
                commentInfo.time = [dict objectWithKey:_lookAndTellCommentDate_];
                
                commentInfo.userId = [dict objectWithKey:_lookAndTellCommentUser_];
                commentInfo.sex = [[dict valueWithKey:_rosterSex_] integerValue];
                
                NSString *name = [dict objectWithKey:_rosterName_];
                JBoRosterInfo *rosterInfo = [appDelegate.rosterAndUsernameDic objectForKey:commentInfo.userId];
                if(![NSString isEmpty:rosterInfo.remark])
                {
                    name = rosterInfo.remark;
                }
                commentInfo.name = name;
                
                [infoArray addObject:commentInfo];
                [commentInfo release];
            }
            info.operationInfo.commentInfoArray = infoArray;
            [infoArray release];
        }
        
        [text release];
        
        return [info autorelease];
        
    }
    else
    {
        return nil;
    }
}

/**通过groupId获取靓友圈信息
 *@param groupId 靓友圈信息的groupId
 *@return get请求url
 */
+ (NSString*)getLookAndtellFromGroupId:(NSString*) groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getLookAndTellWithGroupId_, _lookAndTellGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

#pragma mark- 靓友圈信息状态

/**转载靓友圈信息
 *@param info 靓友圈信息
 *@return qet请求url
 */
+ (NSString*)getTrasmitLookAndTellWithInfo:(JBoLookAndTellListInfo *)info
{
    NSString *targetId = info.transmitId == _trasmitNo_ ? info.userID : info.srcUserId;
    NSString *groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%@", _trasmitLookAndTell_, _rosterUserId_, [JBoUserOperation getUserId], _lookAndTellSourceGroupId_, groupId, _trasmitTargetId_, targetId];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    NSLog(@"%@",url);
    
    return url;
}

/**设置靓友圈信息的置顶状态
 *@param groupId 靓友圈信息的groupId
 *@param state 置顶状态
 *@return get请求url
 */
+ (NSString*)getStickLookAndTellWithGroupId:(NSString *)groupId state:(NSInteger)state
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%d", _stickLookAndTell_, _rosterUserId_, [JBoUserOperation getUserId], _lookAndTellGroupId_, groupId, _stickState_, (int)state];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**获取某个用户的置顶靓友圈信息
 *@param userId 用户的id
 *@return get请求url
 */
+ (NSString*)getStickMsgWithUserId:(NSString*) userId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getStickMsg_, _rosterUserId_, userId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    // NSLog(@"%@",url);
    return url;
}

/**设置靓友圈信息可见范围 url
 *@return post请求url
 */
+ (NSString*)lookAndTellVisibleURL
{
    return _updateLookAndTellVisible_;
}

/**设置靓友圈信息可见范围 参数
 *@param visible 可见范围
 *@param groupId 靓友圈信息的groupId
 *@return post请求参数
 */
+ (NSDictionary*)lookAndTellParaWithVisible:(NSInteger)visible groupId:(NSString *)groupId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:5];
    
    [dic setObject:[NSNumber numberWithInteger:visible] forKey:_lookAndTellVisible_];
    [dic setObject:groupId forKey:_lookAndTellGroupId_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    NSLog(@"%@",dic);
    
    return dic;
}

#pragma mark-靓友圈背景

/**获取靓友圈的背景图片信息
 *@return get请求url
 */
+ (NSString*)getALlLookAndTellBgImage
{
    NSString *url = [JBoUserOperation md5Url:_getAllLookAndTellBgImage_ withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取靓友圈背景图片信息
 *@param data 返回的数据
 *@param titleArray 空的数组，将填充靓友圈背景图片分类标题信息  数组元素是 NSString对象
 *@param infoDic 空的字典，将填充靓友圈背景图片信息，key为标题，value 是 一个数组，数组元素是JBoLookAndTellBigImageInfo对象
 */
+ (void)getAllLookAndTellFromData:(NSData *)data withTitleArray:(NSMutableArray *)titleArray infoDic:(NSMutableDictionary *)infoDic
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];

    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        for(NSDictionary *dict in dataArray)
        {
           // NSLog(@"%@",dic);
            NSString *title = [dict objectWithKey:_lookAndTellImageTitle_];
            if(![titleArray containsObject:title])
            {
                [titleArray addObject:title];
            }
            
            JBoLookAndTellBgImageInfo *info = [[JBoLookAndTellBgImageInfo alloc] init];
            info.ID = [dict objectWithKey:_lookAndTellImageId_];
            info.imageURL = [dict objectWithKey:_lookAndTellImageURl_];
            
            NSMutableArray *array = [infoDic objectForKey:title];
            if(!array)
            {
                array = [NSMutableArray array];
                [infoDic setObject:array forKey:title];
            }
         
            [array addObject:info];
            [info release];
        }
    }
}

/**设置用户的靓友圈背景图片
 *@param imageUrl 图片路径
 *@return get请求url
 */
+ (NSString*)setupUserLookAndTellBgImageWithUrl:(NSString *)imageUrl
{
    NSString *url = [NSString stringWithFormat:_setupUserLookAndTellBgImage_, [JBoUserOperation getUserId], imageUrl];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**获取用户的靓友圈背景图片
 *@param userId 用户的id
 *@return get请求url
 */
+ (NSString*)getUserLookAndTellBgImageWithUserId:(NSString *)usrId
{
    NSString *url = [NSString stringWithFormat:_getUserLookAndTellBgImage_, usrId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**通过返回的数据获取靓友圈的背景图片
 *@param data 返回的数据
 *@return 图片路径
 */
+ (NSString*)getUserLookAndTellBgImageFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
  
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSString *imageUrl = [dic objectWithKey:_data_];
        return imageUrl;
    }
    else
    {
        return nil;
    }
}

#pragma mark- 靓友圈信息评论

/**获取靓友圈信息评论
 *@param groupId 靓友圈信息的groupId
 *@return get请求url
 */
+ (NSString*)getLookAndTellCommentURLWithGroupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getLookAndTellComment_, _lookAndTellGroupId_, groupId];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取靓友圈信息评论内容
 *@param data 返回的数据
 *@return 评论内容 数组元素是JBoLookAndTellCommentInfo对象
 */
+ (NSMutableArray*)getLookAndTellCommetnFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    //    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        
        JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        for(NSDictionary *dict in dataArray)
        {
            JBoLookAndTellCommentInfo *info = [[JBoLookAndTellCommentInfo alloc] init];
            
            info.Id = [[dict valueWithKey:_lookAndTellCommentId_] longLongValue];
            info.comment = [dict objectWithKey:_lookAndTellCommentContent_];
            info.time = [dict objectWithKey:_lookAndTellCommentDate_];
            
            info.userId = [dict objectWithKey:_lookAndTellCommentUser_];
            info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
            
            NSString *name = [dict objectWithKey:_rosterName_];
            JBoRosterInfo *rosterInfo = [appDelegate.rosterAndUsernameDic objectForKey:info.userId];
            if(![NSString isEmpty:rosterInfo.remark])
            {
                name = rosterInfo.remark;
            }
            info.name = name;
            
            [infoArray addObject:info];
            [info release];
        }
        
        return [infoArray autorelease];
    }
    
    return nil;
}

/**评论靓友圈信息 url
 *@return post请求url
 */
+ (NSString*)releaseLookAndTellCommentURL
{
    return _releaseLookAndTellComment_;
}

/**评论靓友圈信息 参数
 *@param groupId 靓友圈信息的groupId
 *@param content 评论内容
 *@return post请求参数
 */
+ (NSDictionary*)releaseLookAndTellCommentParaWithGroupId:(NSString *)groupId content:(NSString *)content
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    [dic setObject:groupId forKey:_lookAndTellGroupId_];
    [dic setObject:content forKey:_lookAndTellCommentContent_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_lookAndTellCommentUser_];
    [dic setObject:[NSNumber numberWithInt:0] forKey:_lookAndTellCommentParentId_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    return dic;
}

#pragma mark- 靓友圈信息操作

/**更新靓友圈信息的 点赞，同情等操作状态
 *@param info 靓友圈信息
 *@return get请求url
 */
+ (NSString*)updateLookAndTellStatusWithInfo:(JBoLookAndTellListInfo*) info
{
    NSString *groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%d&%@=%d&%@=%d", _updateLookAndTellStatus_, _rosterUserId_, [JBoUserOperation getUserId], _lookAndTellSourceGroupId_, groupId, _lookAndTellGood_, info.operationInfo.good, _lookAndTellSignUp_, info.operationInfo.signUp, _lookAndTellPity_, info.operationInfo.pity];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取数量
 *@param data 返回的数据
 *@return 数量
 */
+ (NSInteger)getCountFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSInteger count = [[dic valueWithKey:_data_] integerValue];
        return count;
    }
    else
    {
        return 0;
    }
}

/**获取靓友圈信息点赞数量
 *@param groupId 靓友圈信息的
 *@return get请求url
 */
+ (NSString*)getPraiseCountWithGroupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getPraiseCount_, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    //  NSLog(@"%@",url);
    return url;
}

/**获取靓友圈信息同情总数
 *@param groupId 靓友圈信息
 *@return get请求url
 */
+ (NSString*)getPityCountWithGroupId:(NSString*) groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getPityCount_, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    //  NSLog(@"%@",url);
    return url;
}

/**获取靓友圈信息 点赞，同情等事件状态
 *@param groupId 靓友圈信息的groupId
 *@param userId 用户的id
 *@return get请求url
 */
+ (NSString*)getMsgStateWithGroupId:(NSString*) groupId userId:(NSString *)userId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@", _getMsgState_, _lookAndTellSourceGroupId_, groupId, _rosterUserId_, [JBoUserOperation getUserId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    // NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取 靓友圈信息 点赞，同情等事件状态
 *@param data 返回的数据
 *@param info 靓友圈信息事件状态容器
 */
+ (void)getMsgstateFromData:(NSData *)data withInfo:(JBoMsgOperationInfo *)info
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        if(dict != nil && ![dict isEqual:[NSNull null]])
        {
            info.good = [[dict valueWithKey:_lookAndTellGood_] boolValue];
            info.pity = [[dict valueWithKey:_lookAndTellPity_] boolValue];
            info.witness = [[dict valueWithKey:_lookAndTellWitness_] boolValue];
            
            info.signUp = [[dict valueWithKey:_lookAndTellSignUp_] boolValue];
            info.signIn = [[dict valueWithKey:_lookAndTellSignIn_] boolValue];
        }
    }
}

#pragma mark- 报名签到

/**获取靓友圈信息签到总数
 *@param groupId 靓友圈信息的
 *@return get请求url
 */
+ (NSString*)getSignInCountWithGroupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getSignInCount_, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    // NSLog(@"%@",url);
    return url;
}

/**获取靓友圈信息报名总数
 *@param groupId 靓友圈信息的
 *@return get请求url
 */
+ (NSString*)getSignUpCountWithGroupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getSignUpCount_, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    // NSLog(@"%@",url);
    return url;
}

/**靓友圈信息签到 url
 *@return post请求url
 */
+ (NSString*)signInActivity
{
    return _signInActivity_;
}

/**靓友圈信息签到 参数
 *@param groupId 靓友圈信息groupId
 *@param address 签到的地址
 *@return post请求参数
 */
+ (NSDictionary*)signInActivityInfoWithGroupId:(NSString *)groupId address:(NSString *)address
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:8];
    [dic setObject:groupId forKey:_lookAndTellSourceGroupId_];
    [dic setObject:address forKey:_signInActivityAddress_];
    [dic setObject:[NSNumber numberWithBool:YES] forKey:_signInActivityState_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    
    NSLog(@"%@",dic);
    return [dic autorelease];
}

/**获取靓友圈活动签到的用户
 *@param srcGroupId 靓友圈信息的 groupId
 *@param pageNun 页码
 *@param row 每页数量
 *@return get请求url
 */
+ (NSString*)getSignInUsersWithId:(NSString*) srcGroupId pageNum:(NSInteger)pageNun row:(NSInteger)row
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getLookAndTellSignInUsers_, _lookAndTellSourceGroupId_, srcGroupId, _pageNum_, (int)pageNun, _rows_, (int)row];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**从返回的数据获取靓友圈活动签到的用户
 *@param data 返回的数据
 *@return 数组元素是 JBoSignInInfo对象
 */
+ (NSMutableArray*)getSignInUsersFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoSignInInfo *info = [[JBoSignInInfo alloc] init];
            
            info.headImageURL = [dict objectWithKey:_rosterImageURL_];
            info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
            info.userId = [dict objectWithKey:_rosterUserId_];
            info.name = [dict objectWithKey:_rosterName_];
            info.role = [[dict objectWithKey:_rosterRole_] integerValue];
            
            info.locationImageURL = [dict objectWithKey:_signInPhoto_];
            info.address = [dict objectWithKey:_signInActivityAddress_];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}

/**靓友圈信息签到抽奖
 *@param groupId 靓友圈信息groupId
 *@param result 已抽到的用户
 *@return get请求url
 */
+ (NSString*)activityLuckyDrawWithGroupId:(NSString*) groupId result:(NSString *)result;
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@", _activityLuckyDraw_, _lookAndTellSourceGroupId_, groupId, _activityLuckyResult_, result];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**通过返回的数据获取靓友圈信息签到抽奖结果
 *@param data 返回的数据
 *@return 用户的签到信息
 */
+ (JBoSignInInfo*)activityLuckyDrawWithGroupFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        if(dict == nil || [dict isEqual:[NSNull null]])
            return nil;
        
        JBoSignInInfo *info = [[JBoSignInInfo alloc] init];
        
        
        info.headImageURL = [dict objectWithKey:_rosterImageURL_];
        info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
        info.userId = [dict objectWithKey:_rosterUserId_];
        info.name = [dict objectWithKey:_rosterName_];
        info.role = [[dict objectWithKey:_rosterRole_] integerValue];
        
        info.locationImageURL = [dict objectWithKey:_signInPhoto_];
        info.address = [dict objectWithKey:_signInActivityAddress_];
        
        return [info autorelease];
    }
    else
    {
        return nil;
    }
}

/**获取靓友圈活动报名的用户
 *@param srcGroupId 靓友圈信息的 groupId
 *@param pageNun 页码
 *@param row 每页数量
 *@return get请求url
 */
+ (NSString*)getSignUpUsersWithId:(NSString*) srcGroupId pageNum:(NSInteger)pageNun row:(NSInteger)row
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getLookAndTellSignUpUsers_, _lookAndTellSourceGroupId_, srcGroupId, _pageNum_, (int)pageNun, _rows_, (int)row];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**从返回的数据获取靓友圈活动报名的用户
 *@param data 返回的数据
 *@return 数组元素是 JBoSignUpInfo对象
 */
+ (NSMutableArray*)getSignUpUserFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoSignUpInfo *signupInfo = [[JBoSignUpInfo alloc] init];
            JBoUserDetailInfo *info = [[JBoUserDetailInfo alloc] init];
            
            info.email = [dict objectWithKey:_rosterEmail_];
            info.rosterInfo.jid = [dict objectWithKey:_rosterJid_];
            info.rosterInfo.username = [dict objectWithKey:_rosterUserId_];
            info.rosterInfo.name = [dict objectWithKey:_rosterName_];
            info.rosterInfo.state = [[dict objectWithKey:_rosterState_] boolValue];
            info.rosterInfo.sex = [[dict valueWithKey:_rosterSex_] intValue];
            info.rosterInfo.presence = [dict objectWithKey:_rosterPresence_];
            info.phoneNum = [dict objectWithKey:_rosterPhoneNum_];
            info.rosterInfo.imageURL = [dict objectWithKey:_rosterImageURL_];
            
            info.rosterInfo.role = [[dict objectWithKey:_rosterRole_] integerValue];
            info.rosterInfo.enterpriseTelePhone = [dict objectWithKey:_rosterEnterpriseTelephone_];
            info.rosterInfo.enterpriseName = [dict objectWithKey:_rosterEnterpriseName_];
            info.rosterInfo.enterpriseAddr = [dict objectWithKey:_rosterEnterpriseAddr_];
            
            info.area = [dict objectWithKey:_rosterArea_];
            info.trade = [dict objectWithKey:_rosterTrade_];
            info.vocation = [dict objectWithKey:_rosterVocation_];
            info.status = [[dict objectWithKey:_rosterStatus_] boolValue];
            
            //身高 体重
            info.height = [[dict valueWithKey:_rosterHeight_] integerValue];
            info.weight = [[dict valueWithKey:_rosterWeight_] integerValue];
            
            //三围
            info.bust = [dict objectWithKey:_rosterBust_];
            info.waist = [[dict valueWithKey:_rosterWaist_] integerValue];
            info.hip = [[dict valueWithKey:_rosterHip_] integerValue];
            
            //学历 性格 出生日期
            info.education = [dict objectWithKey:_rosterEducation_];
            info.character = [dict objectWithKey:_rosterCharacter_];
            info.birthday = [dict objectWithKey:_rosterBirthday_];
            
            signupInfo.detailInfo = info;
            
            signupInfo.realName = [dict objectWithKey:_activitySignUpName_];
            signupInfo.phoneNum = [dict objectWithKey:_activitySignUpPhoneNum_];
            signupInfo.email = [dict objectWithKey:_activitySignUpEmail_];
            signupInfo.remark = [dict objectWithKey:_activitySignUpRemark_];
            signupInfo.serialNum = [dict objectWithKey:_activitySignUpSerialNum_];
            
            [infoArray addObject:signupInfo];
            
            [signupInfo release];
            [info release];
        }
        
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}


/**靓友圈活动报名 url
 *@return post请求url
 */
+ (NSString*)getActivitySignupURL
{
    return _activitySignUp_;
}

/**靓友圈活动报名 参数
 *@param name 真实姓名
 *@param phoneNum 手机号码
 *@param email 邮箱
 *@param remark 备注信息
 *@param info 靓友圈信息
 *@return post请求参数
 */
+ (NSDictionary*)getActivitySignupParaWithName:(NSString*) name phoneNum:(NSString*) phoneNum email:(NSString*) email ramrk:(NSString*) remark info:(JBoLookAndTellListInfo*) info
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    [dic setObject:name forKey:_activitySignUpName_];
    [dic setObject:phoneNum forKey:_activitySignUpPhoneNum_];
    [dic setObject:email forKey:_activitySignUpEmail_];
    if(![NSString isEmpty:remark])
    {
        [dic setObject:remark forKey:_activitySignUpRemark_];
    }
    
    NSString *groupId = info.transmitId == _trasmitNo_ ? info.groupId : info.srcGroupId;
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:groupId forKey:_lookAndTellSourceGroupId_];
    [dic setObject:[NSNumber numberWithBool:info.operationInfo.good] forKey:_lookAndTellGood_];
    [dic setObject:[NSNumber numberWithBool:info.operationInfo.pity] forKey:_lookAndTellPity_];
    [dic setObject:[NSNumber numberWithBool:YES] forKey:_lookAndTellSignUp_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    NSLog(@"%@",dic);
    
    return dic;
}

#pragma mark- 靓友圈活动

/**返回申请参加活动用户总数
 *@param 靓友圈活动的groupId
 *@return get请求url
 */
+ (NSString*)getApplyCountWithGroupId:(NSString*) groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getApplyCount_, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    ///  NSLog(@"%@",url);
    return url;
}

/**参加或审核靓友圈活动
 *@param userId 参与者的userId
 *@param msgId 参加活动的靓友圈信息的 msgId
 *@param groupId 参加活动的靓友圈信息的 groupId
 *@param state 参与状态 或 审核结果（初选，复选，决选）
 *@return get请求url
 */
+ (NSString*)joinActivityWithUserId:(NSString *)userId msgId:(NSString *)msgId groupId:(NSString *)groupId state:(NSInteger)state
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%@&%@=%d&%@=%@", _joinActivity_, _rosterUserId_, [JBoUserOperation getUserId], _activityActorTargetId_, userId, _laysReviewMsgId_, msgId, _activityActorState_, (int)state, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**获取所有已成功参加活动的靓友圈信息 (查看自己参加的）
 *@param typeId 活动角色，使用 0，参与者
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getAllActivityActorWithTypeId:(NSInteger) typeId pageNum:(NSInteger) pageNum rows:(NSInteger) rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%d", _getAllActivityActor_, _userId_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows, _activityActorTypeId_, (int)typeId];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    NSLog(@"%@", url);
    
    return url;
}

/**通过返回的数据获取所有已成功参加活动的靓友圈信息 (查看自己参加的）
 *@param  data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param 靓友圈信息，数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)getAllActivityActorFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        return [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:nil isSelf:NO];
    }
    else
    {
        return nil;
    }
}


/**获取某个活动的所有已成功参加活动的靓友圈信息（活动发起人）
 *@param groupId 活动的groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getActivityActorWithGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%@", _getActivityActor_, _userId_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    NSLog(@"%@", url);
    
    return url;
}

/**通过返回的数据 获取某个活动的所有已成功参加活动的靓友圈信息（活动发起人）
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param 靓友圈信息，数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)getActivityActorFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        return [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:nil isSelf:NO];
    }
    else
    {
        return nil;
    }
}

/**筛选某个活动的所有已成功参加活动的靓友圈信息（活动发起人)
 *@param groupId 活动的groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@param filterId 筛选类型 ，初选，复选，决选
 *@return get请求url
 */
+ (NSString*)filterActivityWithGroupId:(NSString *)groupId pageNum:(NSInteger)pageNum rows:(NSInteger)rows filterId:(NSInteger)filterId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%@&%@=%d", _filterActivityActor_, _userId_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows, _lookAndTellSourceGroupId_, groupId, _filterActivityId_, (int)filterId];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    NSLog(@"%@", url);
    
    return url;
}

/**通过返回的数据 筛选某个活动的所有已成功参加活动的靓友圈信息（活动发起人）
 *@param data 返回的数据
 *@param multiInfo 没有加载完的多图文内容 key为 groupId ,value是 JBoLookAndTellListInfo对象
 *@param 靓友圈信息，数组元素是 JBoLookAndTellListInfo对象
 */
+ (NSMutableArray*)filterActivityActorFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        return [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:nil isSelf:NO];
    }
    else
    {
        return nil;
    }
}

#pragma mark- 爱心活动

/**获取爱心活动的证明人总数
 *@param groupId 爱心活动的groupId
 *@return get请求url
 */
+ (NSString*)getWitnessCountWithGroupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getWitnessCount_, _lookAndTellSourceGroupId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    // NSLog(@"%@",url);
    return url;
}

/**成为某个爱心活动的证明人 url
 *@return post请求url
 */
+ (NSString*)witnessActivity
{
    return _witnessActivity_;
}

/**成为某个爱心活动的证明人 参数
 *@param groupId 爱心活动的groupId
 *@param content 证明信息
 *@return post请求参数
 */
+ (NSDictionary*)winessActivityInfoWithGroupId:(NSString *)groupId content:(NSString *)content
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:8];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:groupId forKey:_lookAndTellSourceGroupId_];
    [dic setObject:[NSNumber numberWithBool:YES] forKey:_activityWitness_];
    [dic setObject:content forKey:_activityWitnessContent_];
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    NSLog(@"%@",dic);
    return [dic autorelease];
}

/**获取某个爱心活动的证明人
 *@param groupId 爱心活动的groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getActivityWitnessWitthGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getActivityWitness_, _lookAndTellSourceGroupId_, groupId, _pageNum_, (int)pageNum, _rows_, (int)rows];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取某个爱心活动的证明人
 *@param data 返回的数据
 *@return 数组元素是 JBoWitnessInfo对象
 */
+ (NSMutableArray*)getActivityWinessFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        for(NSDictionary *dict in dataArray)
        {
            JBoWitnessInfo *info = [[JBoWitnessInfo alloc] init];
            
            info.userID = [dict objectWithKey:_rosterUserId_];
            info.name = [dict objectWithKey:_rosterName_];
            info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
            info.role = [[dict objectWithKey:_rosterRole_] integerValue];
            
            info.headImageURL = [dict objectWithKey:_rosterImageURL_];
            NSString *imageURL = [dict objectWithKey:_witnessPhoto_];
            
            JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
            text.content = [dict objectWithKey:_activityWitnessContent_];
            text.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
            
            info.multiInfo = [NSMutableArray arrayWithObject:text];
            [text release];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}

#pragma mark- 视频

/**上传视频 url
 *@return post请求url
 */
+ (NSString*)uploadMovieURL
{
    return _uploadMovie_;
}

/**上传视频参数
 *@param file s视频文件
 *@param post请求参数
 */
+ (NSDictionary*)getUploadMovieDicWithFile:(NSString*) file
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:5];
    [dic setObject:[JBoUserOperation getUserId] forKey:_userId_];
    [dic setObject:file forKey:_uploadMovieFile_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    NSLog(@"%@",dic);
    
    return [dic autorelease];
}

/**从返回的数据获取上传视频结果
 *@param data 返回的参数
 *@return 视频文件的网络url
 */
+ (NSString*)getUploadMovieResultFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSString *path = [resultDic objectWithKey:_uploadMovieResultPath_];
    return path;
}

/**删除视频
 */
+ (NSString*)removeMovieURL
{
    NSString *url = url = [JBoUserOperation md5Url:_removeMovie_ withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

#pragma mark- 活动代言

/**靓友圈代言活动审核
 *@param targetId 审核人，一般是当前登录用户的 userId
 *@param msgId 参加活动的靓友圈信息的 msgId
 *@param state 审核结果 初选，复选，决选
 *@param groupId 参加活动的靓友圈信息的 groupId
 *@return get请求url
 */
+ (NSString*)getLaysReviewWithTargetId:(NSString *)targetId msgId:(NSString *)msgId state:(NSInteger)state groupId:(NSString *)groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%@&%@=%d&%@=%@", _reviewLays_, _rosterUserId_, [JBoUserOperation getUserId], _laysReviewMsgId_, msgId, _laysReviewTargetId_, targetId, _laysReviewState_, (int)state, _lookAndTellSourceGroupId_, groupId];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    NSLog(@"%@",url);
    return url;
}

//获取我的代言
+ (NSString*)getMyLaysWithPageNum:(NSInteger) pageNum rows:(NSInteger) rows
{
    int type = 0;
    JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
    if(info.rosterInfo.role == _rosterRoleEnterprise_)
    {
        type = 1;
    }
    
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%d", _getUserLays_, _userId_, [JBoUserOperation getUserId], _getUserLaysTypeId_, type, _pageNum_, (int)pageNum, _rows_, (int)rows];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    NSLog(@"%@",url);
    return url;
}

+ (NSMutableArray*)getMyLaysFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        return [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:nil isSelf:NO];
    }
    else
    {
        return nil;
    }
}

//筛选代言
+ (NSString*)getMyLaysWithPageNum:(NSInteger)pageNum rows:(NSInteger)rows filter:(NSInteger) filter
{
    int type = 0;
    JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
    if(info.rosterInfo.role == _rosterRoleEnterprise_)
    {
        type = 1;
    }
    
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%d&%@=%d", _filterUserLays_, _userId_, [JBoUserOperation getUserId], _getUserLaysTypeId_, type, _pageNum_, (int)pageNum, _rows_, (int)rows, _getUserLaysFilterId_, (int)filter];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
   // NSLog(@"%@",url);
    return url;
}

//更新代言
+ (NSString*)getUpdateLaysWithMsgId:(NSString*) msgId groupId:(NSString *)groupId state:(NSInteger)state
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%@", _updateLookAndTell_, _lookAndTellSourceGroupId_, groupId, _laysReviewState_, (int)state, _laysReviewMsgId_, msgId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

//根据用户ID筛选已成功参加活动的日志
+ (NSString*)filterAllActivityActorWithTypeId:(NSInteger)typeId pageNum:(NSInteger)pageNum rows:(NSInteger)rows filterId:(NSInteger)filterId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%d&%@=%d", _filterAllActivityActor_, _userId_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows, _activityActorTypeId_, (int)typeId, _filterActivityId_, (int)filterId];
    NSLog(@"%@", url);
    
    return url;
}

+ (NSMutableArray*)filterAllActivityActorFromData:(NSData *)data multiInfo:(NSMutableDictionary *)multiInfo
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        return [JBoLookAndTellOperation getInfoWithMulti:multiInfo fromDatas:dataArray offlineCache:nil isSelf:NO];
    }
    else
    {
        return nil;
    }
}

//代言筛选
+ (NSString*)getLaysActorWithGroupId:(NSString*) groupId pageNum:(NSInteger) pageNum rows:(NSInteger) rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%@", _getLaysActor_, _userId_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows, _lookAndTellSourceGroupId_, groupId];
    
    url = [JBoUserOperation md5Url:url withUserId:NO];
    NSLog(@"%@", url);
    
    return url;
}

+ (NSString*)filterLaysActorWithGroupId:(NSString *)groupId pageNum:(NSInteger)pageNum rows:(NSInteger)rows filterId:(NSInteger)filterId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d&%@=%@&%@=%d", _filterLaysActor_, _userId_, [JBoUserOperation getUserId], _pageNum_, (int)pageNum, _rows_, (int)rows, _lookAndTellSourceGroupId_, groupId, _filterActivityId_, (int)filterId];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    NSLog(@"%@", url);
    
    return url;
}

@end
