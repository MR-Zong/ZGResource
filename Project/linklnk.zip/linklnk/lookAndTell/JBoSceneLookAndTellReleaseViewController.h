//
//  JBoSceneLookAndTellReleaseViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoLookAndTellDelegate.h"


@class JBoSceneMakingImageInfo;


@interface JBoSceneLookAndTellReleaseViewController : UIViewController

/*关联的场景信息
 */
@property(nonatomic,retain) JBoSceneMakingImageInfo *sceneImageInfo;
/**匹配信息
 */
@property(nonatomic,retain) NSDictionary *conditions;

@property(nonatomic,assign) id<JBoLookAndTellDelegate> delegate;

@end
