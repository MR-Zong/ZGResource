//
//  JBoLookAndTellDelegate.h
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JBoLookAndTellListInfo;

@protocol JBoLookAndTellDelegate <NSObject>

@optional
/**说说发布完成
 */
- (void)releaseLookAndTell:(UIViewController*) viewController didFinished:(JBoLookAndTellListInfo*) info;
/**删除说说
 */
- (void)userLookAndTellViewController:(UIViewController*) viewController didDeleteMsgWithGroupId:(NSString*) groupId;

/**选择说说
 */
- (void)userLookAndTellViewController:(UIViewController*) viewController didSelectedMsg:(JBoLookAndTellListInfo*) info;

@end
