//
//  JBoLookAndTellListInfo.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoMultiImageTextInfo.h"
#import "JBoMsgOperationItemInfo.h"
#import "JBoMsgOperationInfo.h"

#define _lookAndTellShowCommentCount_ 5

/**超友圈信息
 */
@interface JBoLookAndTellListInfo : JBoMultiImageTextInfo

/**操作信息，点赞，同情等
 */
@property(nonatomic,retain) JBoMsgOperationInfo *operationInfo;

/**组 id
 */
@property(nonatomic,copy) NSString *groupId;

/**用户昵称
 */
@property(nonatomic,copy) NSString *userName;

/**用户性别
 */
@property(nonatomic,assign) NSInteger sex;

/**用户身份
 */
@property(nonatomic,assign) NSInteger role;

/**用户头像
 */
@property(nonatomic,copy) NSString *headImageURL;

/**超友圈信息类型
 */
@property(nonatomic,assign) int type;

/**参加活动是否需要上传图文
 */
@property(nonatomic,assign) BOOL needImageText;

//普通用户 和 企业用户的审核状态 转发标识 转发次数
@property(nonatomic,assign) NSInteger generalId;
@property(nonatomic,assign) NSInteger enterpriseId;
@property(nonatomic,assign) NSInteger transmitId;
@property(nonatomic,assign) NSInteger transmitCount;

//来源userId 来源用户的昵称 组Id
@property(nonatomic,copy) NSString *srcUserId;
@property(nonatomic,copy) NSString *srcUserName;
@property(nonatomic,copy) NSString *srcGroupId;

//活动状态
@property(nonatomic,assign) NSInteger joinActivityId;
@property(nonatomic,assign) NSInteger startActivityId;

//置顶状态
@property(nonatomic,assign) NSInteger stick;

//可见范围
@property(nonatomic,assign) NSInteger visible;

/**获取说说操作状态信息
 *@param commentCount 要显示的评论数量 传 NSNotFound获取显示全部评论
 *@return 数组元素是 JBoMsgOperationItemInfo 
 */
- (NSArray*)getMsgOperationInfosWithCommentCount:(NSInteger) commentCount;

/**获取说说操作类型的高度
 *@param commentCount 要显示的评论数量 传 NSNotFound获取显示全部评论
 *@return 说说操作气泡内容的高度
 */
- (NSInteger)getMsgOperationHeightWithCommentCount:(NSInteger) commentCount;

/**获取说说内容高度
 *@param width 说说内容宽度限制
 *@param show 是否显示全部内容
 *@return 说说内容高度
 */
- (NSInteger)getContentHeightWithContraintWidth:(CGFloat) width showMultiImageText:(BOOL) show;

/**获取groupId 
 */
- (NSString*)getGroupId;

@end
