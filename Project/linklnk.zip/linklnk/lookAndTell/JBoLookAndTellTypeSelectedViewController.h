//
//  JBoLookAndTellTypeSelectedViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoLookAndTellTypeSelectedViewController,SWRevealViewController,JBoSceneMakingImageInfo;

@protocol JBoLookAndTellTypeSelectedViewControllerDelegate <NSObject>

/**选择某个场景
 */
- (void)lookAndTellTypeSelectedViewController:(JBoLookAndTellTypeSelectedViewController*) viewController didFinishWithInfo:(JBoSceneMakingImageInfo*) info;

@end

/**超友圈信息 发布一语双关 场景信息选择
 */
@interface JBoLookAndTellTypeSelectedViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>

/**侧滑视图控制器
 */
@property(nonatomic,assign) SWRevealViewController *revealVC;
@property(nonatomic,assign) id<JBoLookAndTellTypeSelectedViewControllerDelegate> delegate;

@end
