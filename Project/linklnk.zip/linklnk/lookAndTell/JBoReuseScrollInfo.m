//
//  JBoLookAndTellBigInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoReuseScrollInfo.h"
#import "JBoBasic.h"
#import "JBoImageTextTool.h"

@implementation JBoReuseScrollInfo

- (void)dealloc
{
    [_image release];
    [_title release];
    [_url release];
    
    [super dealloc];
}

+ (CGFloat)getHeightWithContent:(NSString *)content
{
    JBoImageTextLabel *label = [[JBoImageTextLabel alloc] init];
    label.textInset = _reuseScrollViewCellTitleTextInset_;
    label.minLineHeight = _reuseScrollViewCellTitleMinLineHeight_;
    label.font = _lookAndTellFont_;
    
    NSAttributedString *attributedText = [label getAttributedTextFromString:content];
    
    CGFloat titleHeight = [JBoImageTextTool getHeightFromAttributedText:attributedText contraintWidth:_width_ - label.textInset * 2].height + label.textInset * 2;
    
    CGFloat minHeight = _reuseScrollViewCellTitleMinLineHeight_ + _reuseScrollViewCellTitleTextInset_ * 2;
    titleHeight = titleHeight <  minHeight ? minHeight : titleHeight;
    
    titleHeight = titleHeight > _reuseScrollViewCellTitleHeight_ ? _reuseScrollViewCellTitleHeight_ : titleHeight;
    [label release];
    return titleHeight;
}

@end
