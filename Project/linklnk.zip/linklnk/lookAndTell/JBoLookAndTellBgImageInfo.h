//
//  JBoLookAndTellBgImageInfo.h
//  连你
//
//  Created by kinghe005 on 14-2-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**靓友圈背景图片信息
 */
@interface JBoLookAndTellBgImageInfo : NSObject

/**背景图片Id
 */
@property(nonatomic,copy) NSString *ID;

/**图片路径
 */
@property(nonatomic,copy) NSString *imageURL;

/**图片
 */
@property(nonatomic,retain) UIImage *image;

@end
