//
//  JBoReleaseLookAndTellTableHeaderView.h
//  连你
//
//  Created by kinghe005 on 14-3-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoCustomFilterBar.h"
#import "SWRevealViewController.h"
#import <CoreLocation/CoreLocation.h>

@class JBoMapInfo;

typedef enum _JBoReleaseLookAndTellType
{
    JBoReleaseLookAndTellTypeDefault = 0, //发布连说
    JBoReleaseLookAndTellTypeLays = 1, //代言
    JBoReleaseLookAndTellTypeActivity = 2, //活动
}JBoReleaseLookAndTellType;

@class SSTextView;

@interface JBoReleaseLookAndTellTableHeaderView : UIView<UIAlertViewDelegate>

@property(nonatomic,assign) UITableView *tableView;

@property(nonatomic,retain) SSTextView *contentTextView;
@property(nonatomic,retain) SSTextView *secondTextView;
@property(nonatomic,retain) SSTextView *thirdTextView;

@property(nonatomic,assign) UINavigationController *navigationController;
@property(nonatomic,assign) SWRevealViewController *revealVC;

@property(nonatomic,retain) NSMutableArray *imageArray;
@property(nonatomic,retain) NSMutableArray *secondImageArray;
@property(nonatomic,retain) NSMutableArray *thirdImageArray;

@property(nonatomic,assign) NSInteger lookAndTellType;
@property(nonatomic,assign) BOOL needImageText;

@property(nonatomic,retain) JBoCustomFilterBar *filterBar;

@property(nonatomic,readonly) UILabel *activityContentLabel;

//定位
@property(nonatomic,retain) JBoMapInfo *mapInfo;
@property(nonatomic,assign) BOOL isLocation;

- (id)initWithFrame:(CGRect)frame type:(JBoReleaseLookAndTellType) type;

- (void)viewWillDisAppear;
- (void)currentLocation;

@end
