//
//  JBoLookAndTellShareToFriendViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-7-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellShareToFriendViewController.h"
#import "JBoCustomTabBarController.h"
#import "JBoContactListViewController.h"
#import "JBoLettersSearchBar.h"
#import "ChineseToPinyin.h"
#import "GTMBase64.h"
#import "JBoDataPersist.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "NSString+customString.h"
#import "JBoImageTextTool.h"
#import "JBoUserOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoRosterCell.h"
#import "JBoMsgInfo.h"
#import "JBoChatMsgDBOperation.h"
#import "JBoChatOperation.h"
#import "JBoDatetimeTool.h"

#define _shareCellHeight_ 50.0
#define _shareCellInterval_ 10.0

#define _maxSelectedCount_ 10

//搜索栏高度
#define _searchBarHeight_ 40
//section头的高度
#define _sectionHeaderHeight_ 20

@implementation JBoLookAndTellShareCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_shareCellInterval_, _shareCellInterval_, _shareCellHeight_ - _shareCellInterval_ * 2, _shareCellHeight_ - _shareCellInterval_ * 2)];
        [self.contentView addSubview:_headImageView];
        
        CGFloat height = 30.0;
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _shareCellInterval_, (_shareCellHeight_ - height) / 2.0, _width_ - _headImageView.right - _shareCellInterval_ * 3 - height, height)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        UIImage *image = [UIImage imageNamed:@"verify_correct"];
        _checkMarkView = [[UIImageView alloc] initWithImage:image];
        _checkMarkView.frame = CGRectMake(_width_ - height - _shareCellInterval_, (_shareCellHeight_ - image.size.height) / 2.0, image.size.width, image.size.height);
        [self.contentView addSubview:_checkMarkView];
    }
    return self;
}

- (void)dealloc
{
    [_checkMarkView release];
    [_headImageView release];
    
    [_nameLabel release];
    
    [super dealloc];
}

@end


@interface JBoLookAndTellShareToFriendViewController ()

//好友信息
@property(nonatomic,retain) NSMutableDictionary *rosterDic;
//昵称key
@property(nonatomic,retain) NSMutableArray *keywordArray;

//列表 搜索栏
@property(nonatomic,retain) UITableView *tableView;
@property(nonatomic,retain) UISearchBar *searchBar;

//字母筛选栏
@property(nonatomic,retain) JBoLettersSearchBar *lettersView;

//黑色半透明视图
@property(nonatomic,retain) UIView *transparentView;

//搜索结果
@property(nonatomic,retain) NSMutableArray *searchResultArray;

//选中的好友
@property(nonatomic,retain) NSMutableArray *selectedArray;

@property(nonatomic,copy) NSIndexPath *indexPath;
@property(nonatomic,assign) BOOL searching;

@end

@implementation JBoLookAndTellShareToFriendViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"分享给好友";
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoLookAndTellShareToFriendViewController dealloc");
    
    [_info release];
    
    [_keywordArray release];
    [_rosterDic release];
    
    [_tableView release];
    [_lettersView release];
    [_searchBar release];
    
    [_searchResultArray release];
    [_transparentView release];
    
    [_selectedArray release];
    [_indexPath release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)finish
{
    if(self.selectedArray.count == 0)
    {
        [self alertMsg:@"请选择好友"];
        return;
    }
    
    self.appDelegate.dataLoadingView.hidden = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    self.navigationItem.leftBarButtonItem.enabled = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
        
        JBoChatOperation *chat = [[JBoChatOperation alloc] init];
        JBoChatMsgDBOperation *chatDBOperation = [[JBoChatMsgDBOperation alloc] init];
        
        JBoMsgInfo *info = [[JBoMsgInfo alloc] init];
        
        info.groupId = self.info.groupId;
        info.name = detailInfo.rosterInfo.name;
        info.msgType = JBoMsgTypeLookAndTellShare;
        info.time = [JBoDatetimeTool getCurrentTime];
        info.sendState = JBoMsgSendStateNotSend;
        info.isSender = YES;
        
        //获取要发送的说说文本内容
        NSString *content = @" ";
        for(JBoMultiImageText *text in self.info.multiInfo)
        {
            info.laysMsgId = [NSString stringWithFormat:@"%lld", text.msgId];
            if(![NSString isEmpty:text.content])
            {
                content = text.content;
                if(content.length > 30)
                {
                    content = [text.content substringWithRange:NSMakeRange(0, 30)];
                }
                break;
            }
        }
        
        //获取要发送的说说图片
        for(JBoMultiImageText *text in self.info.multiInfo)
        {
            for(NSString *url in text.imageURLArray)
            {
                JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
                UIImage *image = [cache getImageWithURL:url thumbnailSize:CGSizeMake(100.0, 100.0)];
                if(image)
                {
                    NSString *filePath = [JBoDataPersist saveChatImageData:UIImageJPEGRepresentation(image, 1.0)];
                    if(filePath)
                    {
                        info.filePath = filePath;
                        break;
                    }
                }
            }
            
            if(info.filePath)
                break;
        }
        
        info.textMsg = content;
        
        NSString *curTime = [JBoDatetimeTool getCurrentTime];
        //循环发送
        for(JBoRosterInfo *rosterInfo in self.selectedArray)
        {
            info.toJid = [XMPPJID jidWithString:rosterInfo.jid];
            NSString *identifier = [JBoUserOperation getChatIdentifierWithUserId:rosterInfo.username];
            
            //获取最新时间
            NSString *time = [chatDBOperation getNewestTimeForIdentifier:identifier];
            if(![JBoDatetimeTool datetimeTool:time])
            {
                time = nil;
            }
            
            //判断当前时间是否超过3分钟
            if([JBoDatetimeTool isTimeExpired:300 withOldTime:time otherTime:curTime])
            {
                JBoMsgInfo *info = [[[JBoMsgInfo alloc] init] autorelease];
                info.sysMsg = curTime;
                info.msgType = JBoMsgTypeSystem;
                info.isSender = NO;
                info.sendState = JBoMsgSendStateNormal;
                info.time = curTime;
                
                [chatDBOperation saveSystemMsg:info identifier:identifier];
            }
            
            [chatDBOperation saveShareLookAndTellMsg:info identifier:identifier];
            if(info.msgId != _insertMsgError_)
            {
                [self.appDelegate.xmpp.notSendMsgDic setObject:info forKey:[NSNumber numberWithLongLong:info.msgId]];
                [chat sendLookAndTell:info];
                dispatch_async(dispatch_get_main_queue(), ^(void){
                   
                    [[NSNotificationCenter defaultCenter] postNotificationName:_shareNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:info forKey:_shareMsg_]];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:_recentCallUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:JBoRecentCallUpdateTypeUpdateMsg], _recentCallUpdateType_, rosterInfo, _recentCallUpdateRosterInfo_, info, _recentCallUpdateMsgInfo_, nil]];
                });
            }
        }
        
        [info release];
        [chat release];
        [chatDBOperation release];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            self.appDelegate.dataLoadingView.hidden = YES;
            [self alertMsg:@"已分享"];
            [self back];
        });
    });
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setBackItem:YES];
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
    JBoCustomTabBarController *cunstomTabBarVC = (JBoCustomTabBarController*)self.appDelegate.window.rootViewController;
    
    JBoContactListViewController *contactListVC = nil;
    UINavigationController *nav = (UINavigationController*)[cunstomTabBarVC.navigationControllers objectAtIndex:cunstomTabBarVC.addressBookIndex];
    for(UIViewController *VC in nav.viewControllers)
    {
        //NSLog(@"%@",VC);
        if([VC isKindOfClass:[JBoContactListViewController class]])
        {
            contactListVC = (JBoContactListViewController*)VC;
            break;
        }
    }
    
    self.keywordArray = [NSMutableArray arrayWithCapacity:contactListVC.keywordArray.count];
    self.rosterDic = [NSMutableDictionary dictionaryWithCapacity:_rosterDic.count];
    
    [self.keywordArray addObjectsFromArray:contactListVC.keywordArray];
    [self.rosterDic addEntriesFromDictionary:contactListVC.rosterDic];
    
    self.searchResultArray = [NSMutableArray array];
    self.selectedArray = [NSMutableArray array];
    
    //创建tableview
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorColor = [UIColor grayColor];
    tableView.rowHeight = _shareCellHeight_;
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        tableView.separatorInset = UIEdgeInsetsMake(0, _letterViewWidth_, 0, _letterViewWidth_);
    }
#endif
    [tableView setExtraCellLineHidden];
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
    
    
    //创建搜索栏背
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
    searchBar.placeholder = @"搜索";
    searchBar.delegate = self;
    if(!_ios7_0_)
    {
        searchBar.tintColor = _searchBarColor_;
    }
    _tableView.tableHeaderView = searchBar;
    self.searchBar = searchBar;
    [searchBar release];
    
    //创建通讯录字母搜索视图
    
    JBoLettersSearchBar *lettersView = [[JBoLettersSearchBar alloc] initWithFrame:CGRectMake(_width_ - _letterViewWidth_, 0, _letterViewWidth_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    [lettersView addTarget:self action:@selector(letterTouchedAction)];
    [self.view addSubview:lettersView];
    self.lettersView = lettersView;
    [lettersView release];
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
}

//字母选择
- (void)letterTouchedAction
{
    NSString *letter = _lettersView.touchLetter;
    if([_keywordArray containsObject:letter])
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:[_keywordArray indexOfObject:letter]];
        [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

//取消搜索方法
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    if(!_transparentView)
    {
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;
        
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        [self.view addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    _lettersView.hidden = YES;
    [_searchBar setShowsCancelButton:YES animated:YES];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [_searchBar setShowsCancelButton:NO animated:YES];
    _transparentView.hidden = YES;
    _lettersView.hidden = NO;
    [_tableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        char c = [ChineseToPinyin sortSectionTitle:content];
        if(c > 'a' && c < 'z')
            c = c - 32;
        
        NSArray *array = [_rosterDic objectForKey:[NSString stringWithFormat:@"%c",c]];
        
        if(array)
        {
            [_searchResultArray removeAllObjects];
            
            for(JBoRosterInfo *rosterInfo in array)
            {
                NSString *name = [ChineseToPinyin pinyinFromChiniseString:rosterInfo.name];
                if(name.length < pinyin.length)
                {
                    continue;
                }
                
                NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
                if([pinyin isEqualToString:subStr])
                {
                    [_searchResultArray addObject:rosterInfo];
                }
            }
        }
        
        
        for(NSString *str in _keywordArray)
        {
            NSArray *infos = [_rosterDic objectForKey:str];
            
            for(JBoRosterInfo *info in infos)
            {
                NSRange range = [info.name rangeOfString:content];
                
                if(range.length > 0 && (![_searchResultArray containsObject:info]))
                {
                    [_searchResultArray addObject:info];
                }
            }
        }
    }
    if(_searchResultArray.count > 0)
    {
        [_tableView reloadData];
        _transparentView.hidden = YES;
    }
    else
    {
        _transparentView.hidden = NO;
    }
}


#pragma mark-tableview代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
        return 1;
    else
        return _keywordArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = [_rosterDic objectForKey:[_keywordArray objectAtIndex:section]];
    NSInteger count = array.count;
    if(self.searching)
        count = _searchResultArray.count;
    
    return count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    
    JBoLookAndTellShareCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoLookAndTellShareCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoRosterInfo *rosterInfo = nil;
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    
    cell.nameLabel.text = rosterInfo.name;
    cell.nameLabel.sex = rosterInfo.sex;
    cell.headImageView.sex = rosterInfo.sex;
    cell.headImageView.headImageURL = rosterInfo.imageURL;
    
    cell.checkMarkView.hidden = ![self.selectedArray containsObject:rosterInfo];
    
    return cell;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching || section == 0)
        return nil;
    UIView *view = nil;
    NSString *title = [_keywordArray objectAtIndex:section];
    
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"headerIdentifier";
        JBoAddressBookSectionHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[JBoAddressBookSectionHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.headerView.titleLabl.text = title;
        view = header;
#endif
    }
    else
    {
        JBoAddressBookSectionHeaderView *header = [[[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)] autorelease];
        header.titleLabl.text = title;
        view = header;
    }
    
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching || section == 0)
        return 0;
    
    return _sectionHeaderHeight_;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoRosterInfo *rosterInfo = nil;
    
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    
    JBoLookAndTellShareCell *cell = (JBoLookAndTellShareCell*)[self.tableView cellForRowAtIndexPath:indexPath];
    if(cell.checkMarkView.hidden)
    {
        if(self.selectedArray.count >= _maxSelectedCount_)
        {
            [self alertMsg:[NSString stringWithFormat:@"最多可选%d个好友", _maxSelectedCount_]];
            return;
        }
        [self.selectedArray addObject:rosterInfo];
    }
    else
    {
        [self.selectedArray removeObject:rosterInfo];
    }
    
    cell.checkMarkView.hidden = !cell.checkMarkView.hidden;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end

