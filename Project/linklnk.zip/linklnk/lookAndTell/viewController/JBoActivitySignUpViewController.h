//
//  JBoSignUpViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-7-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoLookAndTellListInfo;

@interface JBoActivitySignUpViewController : JBoViewController

/**报名关联的靓友圈信息
 */
@property(nonatomic,retain) JBoLookAndTellListInfo *info;

@end
