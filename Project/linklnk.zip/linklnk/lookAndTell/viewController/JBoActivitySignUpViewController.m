//
//  JBoSignUpViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-7-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoActivitySignUpViewController.h"
#import "JBoHttpRequest.h"
#import "SSTextView.h"
#import "JBoLookAndTellListInfo.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoCheckInputText.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserOperation.h"

#define _padding_ 15.0
#define _controlInterval_ 10.0

@interface JBoActivitySignUpViewController ()<UITextFieldDelegate, UITextViewDelegate, JBoHttpRequestDelegate,UIGestureRecognizerDelegate>
{
    JBoHttpRequest *_httpRequest;
}

//滚动视图
@property(nonatomic,retain) UIScrollView *scrollView;
@property(nonatomic,assign) CGFloat orgHeight;
//姓名
@property(nonatomic,retain) UITextField *nameTextField;
//手机号
@property(nonatomic,retain) UITextField *phoneNumTextField;
//邮箱
@property(nonatomic,retain) UITextField *emailTextField;
//备注
@property(nonatomic,retain) SSTextView *remarkTextView;
//正在请求
@property(nonatomic,assign) BOOL isRequesting;

//回收键盘
@property(nonatomic,retain) UITapGestureRecognizer *reconverKeyboardGesture;
@property(nonatomic,retain) UIView *inputAccessoryView;

@end

@implementation JBoActivitySignUpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"报名";
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        //键盘通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        
        self.black = YES;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- 键盘

- (void)keyboardWillShow:(NSNotification*) notification
{
    self.reconverKeyboardGesture.enabled = YES;
    NSDictionary *dic = [notification userInfo];
    CGFloat duration = [[dic objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    
    [UIView animateWithDuration:duration animations:^(void){
        
        self.scrollView.frame = CGRectMake(self.scrollView.left, self.scrollView.top, self.scrollView.width, self.orgHeight - 216.0);
    }];
}

- (void)keyboardWillHide:(NSNotification*) notification
{
    self.reconverKeyboardGesture.enabled = NO;
    self.scrollView.contentOffset = CGPointZero;
    NSDictionary *dic = [notification userInfo];
    CGFloat duration = [[dic objectForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    
    [UIView animateWithDuration:duration animations:^(void){
        
        self.scrollView.frame = CGRectMake(self.scrollView.left, self.scrollView.top, self.scrollView.width, self.orgHeight);
    }];
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_info release];
    
    [_httpRequest release];
    
    [_scrollView release];
    
    [_nameTextField release];
    [_phoneNumTextField release];
    [_emailTextField release];
    [_remarkTextView release];
    
    [_reconverKeyboardGesture release];
    [_inputAccessoryView release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

#pragma mark- http代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [self alertNetworkMsg:@"报名失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([JBoUserOperation isSuccess:data])
    {
        self.info.operationInfo.signUp = YES;
        self.info.operationInfo.signUpCount ++;
        [self alertMsg:@"报名成功"];
        [self back];
    }
    else
    {
        [self alertNetworkMsg:@"报名失败"];
    }
}

#pragma mark- 加载视图

- (void)back
{
    self.appDelegate.dataLoadingView.hidden = YES;
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)finish
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    if(self.isRequesting)
        return;
    
    if([NSString isEmpty:self.nameTextField.text])
    {
        [self alertMsg:@"请输入真实姓名"];
        return;
    }
    
    if(self.nameTextField.text.length > _inputFormatActivityRealName_)
    {
        [self alertMsg:[NSString stringWithFormat:@"真实姓名不得超过%d字", _inputFormatActivityRealName_]];
        return;
    }
    
    if(![JBoCheckInputText isMobileNumber:self.phoneNumTextField.text])
    {
        [self alertMsg:@"请输入有效手机号"];
        return;
    }
    
    if(![JBoCheckInputText isEmail:self.emailTextField.text])
    {
        [self alertMsg:@"请输入有效邮箱"];
        return;
    }
    
    self.isRequesting = YES;
    [_httpRequest startDataLoading];
    [_httpRequest downloadWithURL:[JBoLookAndTellOperation getActivitySignupURL] dic:[JBoLookAndTellOperation getActivitySignupParaWithName:self.nameTextField.text phoneNum:self.phoneNumTextField.text email:self.emailTextField.text ramrk:self.remarkTextView.text info:self.info]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //回收键盘
    UITapGestureRecognizer *reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyborad:)];
    reconverGesture.delegate = self;
    [self.view addGestureRecognizer:reconverGesture];
    self.reconverKeyboardGesture = reconverGesture;
    self.reconverKeyboardGesture.enabled = NO;
    [reconverGesture release];
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
    view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    
    CGFloat buttonWidth = 60.0;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitle:@"完成" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
    [view addSubview:button];
    
    self.inputAccessoryView = view;
    [view release];
    
    [self setBackItem:YES];
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
    self.view.backgroundColor = _mainBackgroundColor_;
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    scrollView.backgroundColor = [UIColor clearColor];
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:scrollView];
    self.scrollView = scrollView;
    [scrollView release];
    self.orgHeight = self.scrollView.height;
    self.scrollView.contentSize = self.scrollView.frame.size;
    
    //姓名
    UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, 35.0)];
    textField.borderStyle = UITextBorderStyleNone;
    textField.delegate = self;
    textField.layer.cornerRadius = 5.0;
    textField.layer.masksToBounds = YES;
    textField.backgroundColor = [UIColor whiteColor];
    textField.placeholder = @"真实姓名";
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.scrollView addSubview:textField];
    self.nameTextField = textField;
    [textField release];
    
    //手机号
    textField = [[UITextField alloc] initWithFrame:CGRectMake(self.nameTextField.left, self.nameTextField.bottom + _controlInterval_, self.nameTextField.width, self.nameTextField.height)];
    textField.borderStyle = UITextBorderStyleNone;
    textField.delegate = self;
    textField.layer.cornerRadius = 5.0;
    textField.layer.masksToBounds = YES;
    textField.backgroundColor = [UIColor whiteColor];
    textField.placeholder = @"手机号";
    textField.keyboardType = UIKeyboardTypePhonePad;
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.scrollView addSubview:textField];
    self.phoneNumTextField = textField;
    [textField release];
    
    //邮箱
    textField = [[UITextField alloc] initWithFrame:CGRectMake(self.nameTextField.left, self.phoneNumTextField.bottom + _controlInterval_, self.nameTextField.width, self.nameTextField.height)];
    textField.borderStyle = UITextBorderStyleNone;
    textField.delegate = self;
    textField.layer.cornerRadius = 5.0;
    textField.layer.masksToBounds = YES;
    textField.backgroundColor = [UIColor whiteColor];
    textField.placeholder = @"邮箱";
    textField.keyboardType = UIKeyboardTypeEmailAddress;
    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [self.scrollView addSubview:textField];
    self.emailTextField = textField;
    [textField release];
    
    //备注
    SSTextView *textView = [[SSTextView alloc] initWithFrame:CGRectMake(self.nameTextField.left, self.emailTextField.bottom + _controlInterval_, self.nameTextField.width, 70.0)];
    textView.delegate = self;
    textView.layer.cornerRadius = 5.0;
    textView.layer.masksToBounds = YES;
    textView.backgroundColor = [UIColor whiteColor];
    textView.placeholder = @"备注";
    textView.limitable = YES;
    textView.maxCount = _inputFormatActivitySignupRemark_;
    textView.font = textField.font;
    [self.scrollView addSubview:textView];
    self.remarkTextView = textView;
    [textView release];
}

#pragma mark- private method
- (void)reconverKeyborad:(UITapGestureRecognizer*) tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (void)inputFinish:(UIButton*) button
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

#pragma mark- textField代理

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.scrollView.contentOffset = CGPointMake(0, textField.top - 10.0);
}

#pragma mark- textView代理

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.scrollView.contentOffset = CGPointMake(0, textView.top - 10.0);
}

- (void)textViewDidChange:(UITextView *)textView
{
    SSTextView *remark = (SSTextView*) textView;
    if([remark isKindOfClass:[SSTextView class]])
    {
        int length = (int)(remark.maxCount - textView.text.length);
        remark.numLabel.text = [NSString stringWithFormat:@"%d",length < 0 ? 0 : length];
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    SSTextView *remark = (SSTextView*) textView;
    if([remark isKindOfClass:[SSTextView class]])
    {
        NSString *new = [textView.text stringByReplacingCharactersInRange:range withString:text];
        NSInteger res = remark.maxCount - new.length;
        
        remark.numLabel.text = [NSString stringWithFormat:@"%d",(int)(res < 0 ? 0 : res)];
        
        if(res > 0)
        {
            return YES;
        }
        else
        {
            if(new.length > remark.maxCount)
            {
                new = [new substringWithRange:NSMakeRange(0, remark.maxCount)];
                remark.text = new;
            }
            return NO;
        }
    }
    
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
