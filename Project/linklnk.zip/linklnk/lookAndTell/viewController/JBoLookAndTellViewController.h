//
//  JBoLookAndTellViewController.h
//  超咖
//
//  Created by kinghe005 on 14-7-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class
JBoUserDetailInfo,
JBoMovieCacheTool,
JBoOfflineCacheOperation,
ASINetworkQueue,
JBoHttpRequest,
JBoLookAndTellListInfo,
JBoLookAndTellCommentInfo,
JBoActionSheet,
JBoCustomActionSheetCell;

/**超友圈信息列表基类
 */
@interface JBoLookAndTellViewController : JBoViewController<UITableViewDataSource, UITableViewDelegate>

/**以该viewController展现视图 default is 'self'
 */
@property(nonatomic,assign) UIViewController *presentedVC;

/**是否是查看用户自己的说说 defaul is 'NO'
 */
@property(nonatomic,assign) BOOL isSelf;

/**网络操作
 */
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

/**说说数据列表
 */
@property(nonatomic,retain) UITableView *tableView;

/**当没有数据时显示
 */
@property(nonatomic,readonly) UILabel *hasNoInfoLabel;

/**无信息的提示语 default is 'nil'
 */
@property(nonatomic,copy) NSString *hasNoInfoMsg;

/**说说数据源 数组成员是 JBoLookAndTellListInfo对象
 */
@property(nonatomic,readonly) NSMutableArray *infoArray;

/**每一组说说没有请求完的数据 key 是groupId value是 JBoLookAndTellListInfo对象
 */
@property(nonatomic,readonly) NSMutableDictionary *multisInfoDic;

/**上拉加载更多，是否有更多的数据 default is 'YES'
 */
@property(nonatomic,assign) BOOL hasInfo;

/**当前第几页 default is '1'
 */
@property(nonatomic,assign) NSInteger pageIndex;

/**正在请求
 */
@property(nonatomic,assign) BOOL isRequesting;

/**当前选中的说说
 */
@property(nonatomic,assign) NSInteger currentIndex;

/**是否需要加载头像 default is 'NO'
 */
@property(nonatomic,assign) BOOL needLoadHeadImage;

/**是否需要加载所有图片 default is 'NO'
 */
@property(nonatomic,assign) BOOL needLoadAllImage;
 
/**说说操作请求队列
 */
@property(nonatomic,retain) ASINetworkQueue *httpQueue;

/** 当前登录的用户信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *myInfo;

/**视频缓存
 */
@property(nonatomic,retain) JBoMovieCacheTool *movieCacheTool;

/**正在播放视频的 indexPath
 */
@property(nonatomic,retain) NSIndexPath *moviePlayingIndexPath;

/**离线缓存 
 */
@property(nonatomic,retain) JBoOfflineCacheOperation *offlineCache;

/**是否是点击分享
 */
@property(nonatomic,assign) BOOL sharing;


/**判断是否有说说信息，没有提示并显示hasNoInfoLabel
 */
- (void)infoIsNull;

/**关联说说 子类如果有关联的功能必须实现该方法
 */
- (void)relateCircle;

/**置顶说说 子类如果有置顶的功能必须实现该方法
 */
- (void)stickLookAndTell;

/**删除说说 子类如果有删除的功能必须实现该方法
 */
- (void)removeLookAndTell;

/**设定说说的课件范围 子类如果有该功能必须实现该方法
 */
- (void)setLookAndTellVisible;

/**获取说说
 */
- (JBoLookAndTellListInfo*)infoForIndex:(NSInteger) index;

/**超友圈每一行的高度
 */
- (CGFloat)circleHeightForIndexPath:(NSIndexPath*) indexPath;

/**用户说说每一行高度
 */
- (CGFloat)userLookAndTellHeightForIndexPath:(NSIndexPath*) indexPath style:(JBoMsgOperationVStyle) style;

/**查看说说详情
 */
- (void)seeDetailLookAndTellWithIndexPath:(NSIndexPath*) indexPath;

/**查看评论人信息
 */
- (void)seeCommentUserInfoWithCommemtInfo:(JBoLookAndTellCommentInfo*) commentInfo;

#pragma mark- JBoActionSheet delegate

//自定义actionSheet代理
- (JBoCustomActionSheetCell*)cellForActionSheet:(JBoActionSheet *)actionSheet index:(NSInteger)index;
- (void)actionSheet:(JBoActionSheet *)actionSheet didSelectedIndex:(NSInteger)index;

@end
