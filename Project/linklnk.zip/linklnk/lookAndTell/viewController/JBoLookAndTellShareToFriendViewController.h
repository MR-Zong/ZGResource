//
//  JBoLookAndTellShareToFriendViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-7-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoUserNameLabel;
@class JBoUserHeadImageView;
@class JBoLookAndTellListInfo;

@interface JBoLookAndTellShareCell : UITableViewCell

@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

@property(nonatomic,readonly) UIImageView *checkMarkView;

@end

/**超友圈信息分享给好友
 */
@interface JBoLookAndTellShareToFriendViewController : JBoViewController<UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>

/**要发送给好友的说说
 */
@property(nonatomic,retain) JBoLookAndTellListInfo *info;

@end
