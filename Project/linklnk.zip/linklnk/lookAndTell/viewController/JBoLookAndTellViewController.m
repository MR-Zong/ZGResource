//
//  JBoLookAndTellViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-7-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellViewController.h"
#import "JBoReuseScrollView.h"
#import "JBoHttpRequest.h"
#import "JBoMsgOperation.h"
#import "JBoWebViewController.h"
#import "JBoActionSheet.h"
#import "JBoLookAndTellCell.h"
#import "JBoUserOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoMovieCacheTool.h"
#import "JBoOfflineCacheOperation.h"
#import "JBoLookAndTellDetailViewController.h"
#import "JBoShareOperation.h"
#import "JBoComplaintViewController.h"
#import "JBoFileManager.h"
#import "JBoReuseScrollInfo.h"
#import "JBoActivityActorListViewController.h"
#import "JBoUserLookAndTellCell.h"
#import "JBoLookAndTellListCell.h"
#import "JBoLookAndTellCommentInfo.h"
#import "JBoUserInfoViewController.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoLookAndTellShareToFriendViewController.h"

//转载 和 删除
#define _transmitTag_ 1
#define _removeTag_ 2

@interface JBoLookAndTellViewController ()
<JBoMovieCacheToolDelegate,
JBoLookAndTellDetailViewControllerDelegate,
JBoActionSheetDelegate,
JBoBecomeWitnessViewControllerDelegate,
JBoActivitySignInViewControllerDelegate,
JBoLovingDonateViewControllerDelegate,
JBoLovingVolunteerViewControllerDelegate,
JBoReuseScrollViewDelegate,
JBoHttpRequestDelegate,
JBoLookAndTellCellDelegate>

//查看说说大图 数组成员是 JBoLookAndTellBigInfo对象
@property(nonatomic,retain) NSMutableArray *imageURLArray;

//说说大图滚动视图
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;

//说说分享 标题 和 图标
@property(nonatomic,retain) NSArray *shareTitleArray;
@property(nonatomic,retain) NSArray *shareImageArray;

@end

@implementation JBoLookAndTellViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        
        _infoArray = [[NSMutableArray alloc] init];
        _multisInfoDic = [[NSMutableDictionary alloc] init];
        
        self.pageIndex = 1;
        self.hasInfo = YES;
        self.isRequesting = NO;
        
        //获取用户个人信息
        self.myInfo = [JBoUserOperation getUserDetailInfo];
        
        self.movieCacheTool = [[[JBoMovieCacheTool alloc] init] autorelease];
        self.movieCacheTool.delegate = self;
        
        self.offlineCache = [[[JBoOfflineCacheOperation alloc] init] autorelease];
        self.presentedVC = self;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        if(!_isRequesting)
        {
            _tableView.tableFooterView = nil;
            self.appDelegate.dataLoadingView.hidden = YES;
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        }
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoLookAndTellViewController dealloc");
    
    [_httpRequest release];
    
    [_tableView release];
    [_hasNoInfoLabel release];
    [_hasNoInfoMsg release];
    
    [_infoArray release];
    [_multisInfoDic release];
    
    [_httpQueue reset];
    [_httpQueue cancelAllOperations];
    [_httpQueue release];
    
    [_myInfo release];
    
    [_movieCacheTool release];
    [_offlineCache release];
    
    [_imageScrollView release];
    [_imageURLArray release];
    
    [_shareImageArray release];
    [_shareTitleArray release];
    
    [_moviePlayingIndexPath release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if(self.isRequesting)
    {
        [self.appDelegate closeAlertView];
    }
    
    JBoLookAndTellCell *cell = (JBoLookAndTellCell*)[_tableView cellForRowAtIndexPath:self.moviePlayingIndexPath];
    [cell.shareShortMovieView.shortMovieView viewWillDisAppear];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

#pragma mark- public method

- (void)infoIsNull
{
    if(_infoArray.count == 0)
    {
        if(!_hasNoInfoLabel)
        {
            CGFloat height = _height_ - _navgateBarHeight_ - _statuBarHeight_ - _circelBgImageHeight_;
            _hasNoInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
            _hasNoInfoLabel.textColor = [UIColor grayColor];
            _hasNoInfoLabel.backgroundColor = [UIColor whiteColor];
            [_hasNoInfoLabel setTextAlign:JBoTextAlignmentCenter];
            _hasNoInfoLabel.text = self.hasNoInfoMsg;
        }
        
        _tableView.tableFooterView = _hasNoInfoLabel;
    }
    else
    {
        _tableView.tableFooterView = nil;
    }
}

//关联说说
- (void)relateCircle
{
    
}

//置顶说说
- (void)stickLookAndTell
{
    
}

//删除说说
- (void)removeLookAndTell
{
    
}

//设定说说的可见范围
- (void)setLookAndTellVisible
{
    
}

//靓友圈每一行高度
- (CGFloat)circleHeightForIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    
    [info getContentHeightWithContraintWidth:_defaultMultiImageTextViewWidth_ - _defaultMultiImageTextInset_ * 2 showMultiImageText:NO];
    
    CGFloat height = _headImageSize_ + _topPadding_ + info.contentHeight;
    
    height += [JBoMsgOperationView getHeightWithStyle:info.operationInfo.style canComplaint:YES needImageText:info.needImageText];
    
    height += [info getMsgOperationHeightWithCommentCount:_lookAndTellShowCommentCount_];
    
    return height;
}

//用户说说每一行高度
- (CGFloat)userLookAndTellHeightForIndexPath:(NSIndexPath*) indexPath style:(JBoMsgOperationVStyle) style
{
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    
    [info getContentHeightWithContraintWidth:_defaultMultiImageTextViewWidth_ - _defaultMultiImageTextInset_ * 2 showMultiImageText:NO];
    
    CGFloat height = info.contentHeight + _innerPadding_ * 2;
    
    height += [JBoMsgOperationView getHeightWithStyle:style canComplaint:NO needImageText:info.needImageText];
    
    height += [info getMsgOperationHeightWithCommentCount:_lookAndTellShowCommentCount_];
    
    if(info.generalId > _laysReviewStateNormal_ && info.generalId <= _laysReviewStateRefuse_)
    {
        height += _lookAndTellcontrolHeight_;
    }
    
    height = height < _userLookAndTellCellMinHeight_ ? _userLookAndTellCellMinHeight_ : height;
    
    return height;
}

//查看详情

- (void)seeDetailLookAndTellWithIndexPath:(NSIndexPath*) indexPath
{
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    
    JBoLookAndTellDetailViewController *detailVC = [[JBoLookAndTellDetailViewController alloc] init];
    detailVC.black = self.black;
    detailVC.delegate = self;
    detailVC.isSelf = self.isSelf;
    detailVC.info = info;
    [self.navigationController pushViewController:detailVC animated:YES];
    [detailVC release];
}

#pragma mark- httpQueue

//设置 queue
- (ASINetworkQueue*)queue
{
    if(!self.httpQueue)
    {
        self.httpQueue = [ASINetworkQueue queue];
        [self.httpQueue setShouldCancelAllRequestsOnFailure:NO];
        [self.httpQueue setDelegate:self];
        [self.httpQueue setQueueDidFinishSelector:@selector(httpQuqueDidFinish:)];
        [self.httpQueue setRequestDidFailSelector:@selector(requestDidFail:)];
        [self.httpQueue setRequestDidFinishSelector:@selector(requestDidFinish:)];
    }
    return self.httpQueue;
}

//网络请求入队
- (void)enqueueWithURL:(NSString*) url tag:(NSInteger) tag
{
    ASIHTTPRequest *reqeust = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:url]];
    [reqeust setCachePolicy:ASIDoNotReadFromCacheCachePolicy];
    reqeust.tag = tag;
    reqeust.downloadDestinationPath = [JBoFileManager getTemporaryFile];
    
    [[self queue] addOperation:reqeust];
    [[self queue] go];
}

- (void)httpQuqueDidFinish:(ASINetworkQueue*) queue
{
    [self.httpQueue reset];
    self.httpQueue = nil;
}

- (void)requestDidFail:(ASIHTTPRequest*) request
{
    switch (request.tag)
    {
        case _transmitTag_ :
        {
            self.isRequesting = NO;
            [self alertNetworkMsg:@"请重试"];
        }
            break;
        case _removeTag_ :
        {
            
        }
            break;
        default:
            break;
    }
}

- (void)requestDidFinish:(ASIHTTPRequest*) request
{
    switch (request.tag)
    {
        case _transmitTag_ :
        {
            self.isRequesting = NO;
            NSData *data = [NSData dataWithContentsOfFile:request.downloadDestinationPath];
            if([JBoUserOperation isSuccess:data])
            {
                [JBoUserOperation alertMsg:@"已转载"];
              //  [self.offlineCache updateCircleOperationWithInfo:info];
            }
        }
            break;
        case _removeTag_ :
        {
            
        }
            break;
        default:
            break;
    }
}


#pragma mark-JBoMovieCacheTool代理

- (void)movieCacheTool:(JBoMovieCacheTool *)tool canPlayMovieWithURL:(NSURL *)url temporaryFilePath:(NSString *)temporaryFilePath
{
    JBoLookAndTellCell *cell = (JBoLookAndTellCell*)[_tableView cellForRowAtIndexPath:self.moviePlayingIndexPath];
    cell.shareShortMovieView.shortMovieView.playTemporayPath = temporaryFilePath;
    cell.shareShortMovieView.shortMovieView.localURL = url;
    [cell.shareShortMovieView.shortMovieView startPlay];
}

- (void)movieCacheTool:(JBoMovieCacheTool *)tool didFinfishDownloadWithURL:(NSURL *)url
{
    JBoLookAndTellCell *cell = (JBoLookAndTellCell*)[_tableView cellForRowAtIndexPath:self.moviePlayingIndexPath];
    cell.shareShortMovieView.shortMovieView.localURL = url;
    cell.shareShortMovieView.shortMovieView.finishDownload = YES;
    
    if(cell.shareShortMovieView.shortMovieView.playError)
    {
        [cell.shareShortMovieView.shortMovieView startPlay];
    }
}

- (void)movieCacheTool:(JBoMovieCacheTool *)tool didFailDownloadWithURL:(NSURL *)url
{
    JBoLookAndTellCell *cell = (JBoLookAndTellCell*)[_tableView cellForRowAtIndexPath:self.moviePlayingIndexPath];
    cell.shareShortMovieView.shortMovieView.playError = NO;
    [cell.shareShortMovieView.shortMovieView stopPlay];
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (JBoLookAndTellListInfo*)infoForIndex:(NSInteger) index
{
    if(index >= self.infoArray.count)
        return nil;
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:index];
    if([info isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dic = (NSDictionary*) info;
        info = [[dic allValues] firstObject];
    }
    return info;
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}


- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *defaultIdentifier = @"default";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:defaultIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:defaultIdentifier] autorelease];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellCell *tellCell = (JBoLookAndTellCell*) cell;
    if([tellCell isKindOfClass:[JBoLookAndTellCell class]])
    {
        [tellCell.shareShortMovieView.shortMovieView stopPlay];
    }
}

#pragma mark-msgOperation的代理

- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedMsgOperationItem:(JBoMsgOperationContentItem *)item
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    self.currentIndex = indexPath.row;
    
    switch (item.style)
    {
        case JBoMsgOperationItemStyleTransmit :
        {
            
        }
            break;
        case JBoMsgOperationItemStylePraise :
        {
            
        }
            break;
        case JBoMsgOperationItemStylePity :
        {
            
        }
            break;
        case JBoMsgOperationItemStyleWitness :
        {
            [JBoMsgOperation getWitness:info viewController:self black:self.black];
        }
            break;
        case  JBoMsgOperationItemStyleSignIn :
        {
            [JBoMsgOperation getSignInPerson:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleApply :
        {
            [JBoMsgOperation getApplyPerson:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleSignUp :
        {
            [JBoMsgOperation getSignUpPerson:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleDonate :
        {
            [JBoMsgOperation getDonateList:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleVoluteer :
        {
            [JBoMsgOperation getVolunteerList:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleComment :
        {
            if(item.commentIndex < info.operationInfo.commentInfoArray.count)
            {
                JBoLookAndTellCommentInfo *commentInfo = [info.operationInfo.commentInfoArray objectAtIndex:item.commentIndex];
                [self seeCommentUserInfoWithCommemtInfo:commentInfo];
            }
        }
            break;
        default :
            break;
    }
}

- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedMsgOperationCell:(JBoMsgOperationViewCell *)msgCell
{
    
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    self.currentIndex = indexPath.row;
    
    switch (msgCell.style)
    {
        case JBoMsgOperationItemStyleTransmit :
        {
            if(self.isRequesting)
                return;
            
            self.sharing = YES;
            if(!self.shareTitleArray)
            {
                //分享数据
                self.shareTitleArray = [JBoShareOperation shareTitles];
                self.shareImageArray = [JBoShareOperation shareIcons];
            }
            
            JBoActionSheet *myActionSheet = [[JBoActionSheet alloc] initWithItems:self.shareTitleArray.count delegate:self];
            [myActionSheet show];
            [myActionSheet release];
            
        }
            break;
        case JBoMsgOperationItemStylePraise :
        {
            [JBoMsgOperation setPraiseWithInfo:info queue:[self queue]];
            
            [_tableView beginUpdates];
            [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
            
            [self.offlineCache updateCircleOperationWithInfo:info];
        }
            break;
        case JBoMsgOperationItemStylePity :
        {
            [JBoMsgOperation setPityWithInfo:info queue:[self queue]];
            
            [_tableView beginUpdates];
            [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
            
            [self.offlineCache updateCircleOperationWithInfo:info];
        }
            break;
        case JBoMsgOperationItemStyleWitness :
        {
            [JBoMsgOperation becomeWitness:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleSignUp :
        {
            if(!info.operationInfo.signUp)
            {
                [JBoMsgOperation signUpWithInfo:info viewController:self black:self.black];
            }
            else
            {
                [JBoMsgOperation cancelSignUpWithInfo:info queue:[self queue]];
                [_tableView beginUpdates];
                [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                [_tableView endUpdates];
                
                [self.offlineCache updateCircleOperationWithInfo:info];
            }
        }
            break;
        case JBoMsgOperationItemStyleSignIn :
        {
            [JBoMsgOperation activitySignIn:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleApply :
        {
            if(self.isSelf)
            {
                JBoActivityActorListViewController *activityActor = [[JBoActivityActorListViewController alloc] init];
                activityActor.black = YES;
                activityActor.groupId = [NSString isEmpty:info.srcGroupId] ? info.groupId : info.srcGroupId;
                activityActor.type = info.type;
                [self.navigationController pushViewController:activityActor animated:YES];
                [activityActor release];
            }
            else
            {
                [JBoMsgOperation activityApply:info viewController:self black:self.black];
            }
        }
            break;
        case JBoMsgOperationItemStyleDonate :
        {
            [JBoMsgOperation donate:info viewController:self black:YES];
        }
            break;
        case JBoMsgOperationItemStyleVoluteer :
        {
            [JBoMsgOperation becomeVolunteer:info viewController:self black:self.black];
        }
            break;
        case JBoMsgOperationItemStyleComplaint :
        {
            JBoComplaintViewController *complaintVC = [[JBoComplaintViewController alloc] init];
            complaintVC.userId = info.userID;
            [complaintVC showInViewController:self animated:YES completion:nil];
            [complaintVC release];
        }
            break;
        case JBoMsgOperationItemStyleStick :
        {
            [self stickLookAndTell];
        }
            break;
        case JBoMsgOperationItemStyleDelete :
        {
            [self removeLookAndTell];
        }
            break;
        case JBoMsgOperationItemStyleSelected :
        {
            [self relateCircle];
        }
            break;
        case JBoMsgOperationItemStyleVisible :
        {
            [self setLookAndTellVisible];
        }
            break;
        case JBoMsgOperationItemStyleComment :
        {
            [self seeDetailLookAndTellWithIndexPath:indexPath];
        }
            break;
        default:
            break;
    }
    
    
}

//查看评论人信息
- (void)seeCommentUserInfoWithCommemtInfo:(JBoLookAndTellCommentInfo*)commentInfo
{
    if([commentInfo.userId isEqualToString:[JBoUserOperation getUserId]])
    {
        JBoUserInfoViewController *userInfoVC = [[JBoUserInfoViewController alloc] init];
        userInfoVC.black = self.black;
        [self.navigationController pushViewController:userInfoVC animated:YES];
        [userInfoVC release];
    }
    else
    {
        JBoRosterInfo *rosterInfo = [self.appDelegate.rosterAndUsernameDic objectForKey:commentInfo.userId];
        if(rosterInfo)
        {
            JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
            detail.rosterInfo = rosterInfo;
            detail.black = self.black;
            [self.navigationController pushViewController:detail animated:YES];
            [detail release];
        }
        else
        {
            JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
            userInfo.userId = commentInfo.userId;
            userInfo.black = self.black;
            [self.navigationController pushViewController:userInfo animated:YES];
            [userInfo release];
        }
    }
}

#pragma mark-signInActivity代理
- (void)activitySignInViewControllerDidPFinished:(JBoActivitySignInViewController *)viewController
{
    JBoLookAndTellListInfo *info = [self infoForIndex:self.currentIndex];
    
    info.operationInfo.signIn = YES;
    info.operationInfo.signInCount ++;
    [_tableView reloadData];
    [viewController back];
    
    [self.offlineCache updateCircleOperationWithInfo:info];
}

#pragma mark-JBoBecomeWitnessViewController代理
- (void)becomeWitnessViewController:(JBoBecomeWitnessViewController *)viewController didFinishedWithInfo:(NSDictionary *)info
{
    JBoLookAndTellListInfo *listInfo = [self infoForIndex:self.currentIndex];
    
    listInfo.operationInfo.witness = YES;
    listInfo.operationInfo.witnessCount ++;
    [_tableView reloadData];
    [viewController dismissViewControllerAnimated:YES completion:nil];
    
    [self.offlineCache updateCircleOperationWithInfo:listInfo];
}

#pragma mark-JBoLovingVolunteerViewController代理
- (void)lovingVolunteerViewControllerDidFinished:(JBoLovingVolunteerViewController *)viewController
{
    JBoLookAndTellListInfo *info = [self infoForIndex:self.currentIndex];
    
    info.operationInfo.volunteerCount ++;
    [_tableView reloadData];
    [viewController dismissViewControllerAnimated:YES completion:nil];
    
    [self.offlineCache updateCircleOperationWithInfo:info];
}

#pragma mark-JBoLovingDonateViewController代理
- (void)lovingDonateViewControllerDidFinish:(JBoLovingDonateViewController *)viewController
{
    JBoLookAndTellListInfo *info = [self infoForIndex:self.currentIndex];
    
    info.operationInfo.donateCount ++;
    [_tableView reloadData];
    [viewController dismissViewControllerAnimated:YES completion:nil];
    
    [self.offlineCache updateCircleOperationWithInfo:info];
}

#pragma mark-ActionSheet代理

- (JBoCustomActionSheetCell*)cellForActionSheet:(JBoActionSheet *)actionSheet index:(NSInteger)index
{
    JBoCustomActionSheetCell *cell = [[JBoCustomActionSheetCell alloc] initWithImage:[self.shareImageArray objectAtIndex:index] title:[self.shareTitleArray objectAtIndex:index]];
    cell.textLabel.textColor = [UIColor blackColor];
    cell.index = index;
    return [cell autorelease];
}
//功能更多关联方法
- (void)actionSheet:(JBoActionSheet *)actionSheet didSelectedIndex:(NSInteger)index
{
    JBoLookAndTellListInfo *info = [self infoForIndex:self.currentIndex];
    
    switch (index)
    {
        case 0 :
        {
            //
            JBoLookAndTellShareToFriendViewController *share = [[JBoLookAndTellShareToFriendViewController alloc] init];
            share.black = self.black;
            share.info = info;
            [share showInViewController:self.appDelegate.window.rootViewController animated:YES completion:nil];
            [share release];
        }
            break;
        case 1 :
        {
            if([info.userID isEqualToString:self.myInfo.rosterInfo.username] || [info.srcUserId isEqualToString:self.myInfo.rosterInfo.username])
            {
                [self alertMsg:@"已转载"];
            }
            else if(!self.isRequesting)
            {
                [self enqueueWithURL:[JBoLookAndTellOperation getTrasmitLookAndTellWithInfo:info] tag:_transmitTag_];
            }
        }
            break;
        default:
            break;
    }
    [actionSheet disMiss];
}


#pragma mark- JBoLookAndTellCell delegate

- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didLongPressAtIndex:(NSInteger)index
{
    
}

- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedImageAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    NSInteger currentIndex = 0;
    
    NSMutableArray *urlArray = [[NSMutableArray alloc] init];
    for(NSInteger i = 0;i < _infoArray.count;i ++)
    {
        JBoLookAndTellListInfo *info = [self infoForIndex:i];
        if(![info isKindOfClass:[JBoLookAndTellListInfo class]] || info.type == _lookAndTellTypeShareLink_ || info.type == _lookAndTellTypeShortMovie_)
            continue;
        
        NSInteger count = 0;
        for(JBoMultiImageText *text in info.multiInfo)
        {
            CGFloat titleHeight = [JBoReuseScrollInfo getHeightWithContent:text.content];
            
            for(NSString *url in text.imageURLArray)
            {
                JBoReuseScrollInfo *bigInfo = [[JBoReuseScrollInfo alloc] init];
                bigInfo.msgId = text.msgId;
                bigInfo.title = text.content;
                bigInfo.titleHeight = titleHeight;
                bigInfo.url = url;
                
                [urlArray addObject:bigInfo];
                [bigInfo release];
            }
            count += text.imageURLArray.count;
            if(info.hasMoreText)
            {
                break;
            }
        }
        
        if(i < indexPath.row)
        {
            currentIndex += count;
        }
        
        if(i == indexPath.row)
        {
            currentIndex += index;
        }
    }
    
    self.imageURLArray = urlArray;
    [urlArray release];
    
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = currentIndex;
    [self.imageScrollView reloadData];
    [self.imageScrollView showInViewController:self];
}


- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedURL:(NSURL *)url
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    
    
    JBoWebViewController *webVC = [[JBoWebViewController alloc] init];
    webVC.userId = info.userID;
    webVC.URL = url;
    [webVC showInViewController:self animated:YES completion:nil];
    [webVC release];
}

- (void)lookAndTellCellDidSelectedTotalContent:(JBoLookAndTellCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    [self seeDetailLookAndTellWithIndexPath:indexPath];
}

- (void)lookAndTellCellPrepareToPlayMovie:(JBoLookAndTellCell *)cell
{
    NSLog(@"lookAndTellCellPrepareToPlayMovie");
    if(self.moviePlayingIndexPath != nil)
    {
        JBoLookAndTellCell *cell = (JBoLookAndTellCell*)[_tableView cellForRowAtIndexPath:self.moviePlayingIndexPath];
        [cell.shareShortMovieView.shortMovieView stopPlay];
    }
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    self.moviePlayingIndexPath = indexPath;
    
    JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
    
    [_movieCacheTool playMovieWithURL:info.url];
}

- (void)lookAndTellCellWillPlayMovie:(JBoLookAndTellCell *)cell
{
    
}

- (void)lookAndTellCellDidStopPlayMovie:(JBoLookAndTellCell *)cell
{
    NSLog(@"播放完成");
    [_movieCacheTool cancelDownload];
    self.moviePlayingIndexPath = nil;
}

- (void)lookAndTellCellMoviePreviewImageDidLoad:(JBoLookAndTellCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    if(indexPath != nil)
    {
        NSLog(@"lookAndTellCellMoviePreviewImageDidLoad");
        JBoLookAndTellListInfo *info = [self infoForIndex:indexPath.row];
        info.contentHeight = NSNotFound;
        [self.tableView beginUpdates];
        [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        [self.tableView endUpdates];
    }
}

#pragma mark-JBoLookAndTellDetailViewController代理

- (void)detailViewController:(JBoLookAndTellDetailViewController *)viewController didDeletedInfo:(JBoLookAndTellListInfo *)info
{
    [self.offlineCache removeBeautifulCircleWithGroupId:info.groupId];
    
    if(info.transmitId == _trasmitNo_)
    {
        [self.offlineCache removeCircleCommentWithGroupId:[info getGroupId]];
        [self.offlineCache deleteCircleOperationWithInfo:info];
    }
    
    
    [_infoArray removeObject:info];
    [_tableView reloadData];
    [self infoIsNull];
}

- (void)detailViewController:(JBoLookAndTellDetailViewController *)viewController didStickedInfo:(JBoLookAndTellListInfo *)info
{
    [info retain];
    [_infoArray removeObject:info];
    [_infoArray insertObject:info atIndex:0];
    [info release];
    [_tableView reloadData];
}

#pragma mark-reuseScrollView代理

- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.imageURLArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    
    cell.titleLabel.text = info.title;
    cell.titleLabel.frame = CGRectMake(0, _height_ - info.titleHeight, _width_, info.titleHeight);
    scrollView.titleLabel.text = info.title;
    
    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:info.url forIndex:index];
        }
    }
    
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    if(!image)
    {
        [self downloadImageWithUrl:info.url forIndex:index];
    }
}

- (BOOL)resuseScrollView:(JBoReuseScrollView *)scrollView isSameTitleAtIndex:(NSInteger)index withOtherIndex:(NSInteger)otherIndex
{
    if(otherIndex < 0 || otherIndex >= self.imageURLArray.count || index < 0 || index >= self.imageURLArray.count)
    {
        return YES;
    }
    
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    JBoReuseScrollInfo *otherInfo = [self.imageURLArray objectAtIndex:otherIndex];
    
    return info.msgId == otherInfo.msgId;
}

- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    self.imageURLArray = nil;
    [_tableView reloadData];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.imageScrollView cellForIndex:index];
        cell.imageView.image = image;
        [self.imageScrollView reloadDataAtIndex:index];
    }];
}

@end
