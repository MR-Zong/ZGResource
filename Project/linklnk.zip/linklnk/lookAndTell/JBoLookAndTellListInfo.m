//
//  JBoLookAndTellListInfo.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLookAndTellListInfo.h"
#import "JBoBasic.h"
#import "JBoMultiImageTextView.h"
#import "JBoImageTextTool.h"
#import "JBoShareLinkView.h"
#import <CoreText/CoreText.h>
#import "JBoShareShortMovieView.h"
#import "JBoMsgOperationView.h"
#import "JBoLookAndTellCommentInfo.h"

@implementation JBoLookAndTellListInfo

- (id)init
{
    self  = [super init];
    if(self)
    {
        self.contentHeight = NSNotFound;
        self.operationInfo = [[[JBoMsgOperationInfo alloc] init] autorelease];
    }
    return self;
}

- (void)dealloc
{
    [_operationInfo release];
    [_groupId release];
  
    [_userName release];
    [_headImageURL release];
    
    [_srcUserId release];
    [_srcUserName release];
    [_srcGroupId release];

    [super dealloc];
}

#pragma mark- 

/**获取说说操作状态信息
 *@param commentCount 要显示的评论数量 传 NSNotFound获取显示全部评论
 *@return 数组元素是 JBoMsgOperationItemInfo
 */
- (NSArray*)getMsgOperationInfosWithCommentCount:(NSInteger)commentCount
{
    NSMutableArray *infos = [[NSMutableArray alloc] init];
    
    if(self.transmitCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.transmitCount str:@"人转载" style:JBoMsgOperationItemStyleTransmit]];
    }
    
    if(self.operationInfo.praiseCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.praiseCount str:@"人称赞" style:JBoMsgOperationItemStylePraise]];
    }
    
    if(self.operationInfo.pityCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.pityCount str:@"人同情" style:JBoMsgOperationItemStylePraise]];
    }
    
    if(self.operationInfo.witnessCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.witnessCount str:@"个证明人" style:JBoMsgOperationItemStyleWitness]];
    }
    
    if(self.operationInfo.signUpCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.signUpCount str:@"人报名" style:JBoMsgOperationItemStyleSignUp]];
    }
    
    if(self.operationInfo.signInCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.signInCount str:@"人签到" style:JBoMsgOperationItemStyleSignIn]];
    }
    
    if(self.operationInfo.volunteerCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.volunteerCount str:@"个志愿者" style:JBoMsgOperationItemStyleVoluteer]];
    }
    
    if(self.operationInfo.donateCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.donateCount str:@"人捐赠" style:JBoMsgOperationItemStyleDonate]];
    }
    
    if(self.operationInfo.applyCount > 0)
    {
        [infos addObject:[self getAttributedTextWithNum:self.operationInfo.applyCount str:@"人申请" style:JBoMsgOperationItemStyleApply]];
    }
    
 
    for(NSInteger i = 0; i < self.operationInfo.commentInfoArray.count && i < commentCount; i ++)
    {
        JBoLookAndTellCommentInfo *info = [self.operationInfo.commentInfoArray objectAtIndex:i];
        
        JBoMsgOperationItemInfo *msgInfo = [[JBoMsgOperationItemInfo alloc] init];
        msgInfo.content = [self commentAttributedTextFromInfo:info];
        msgInfo.title = info.name;
        msgInfo.style = JBoMsgOperationItemStyleComment;
        msgInfo.commentIndex = i;
        
        if(info.commentBottmHeight == NSNotFound)
        {
            CGSize size = [JBoImageTextTool getHeightFromAttributedText:[self commentAttributedTextFromInfo:info] contraintWidth:_defaultMultiImageTextViewWidth_];
            info.commentBottmHeight = size.height + 5.0;
        }
        msgInfo.titleHeight = info.commentBottmHeight;
        
        [infos addObject:msgInfo];
        [msgInfo release];
    }
  
    return [infos autorelease];
}

- (JBoMsgOperationItemInfo*) getAttributedTextWithNum:(NSInteger) num str:(NSString*) str style:(JBoMsgOperationItemStyle) style
{
    NSString *numStr = [NSString stringWithFormat:@"%d", (int)num];
    CTFontRef font = CTFontCreateWithName((CFStringRef)_msgOperationFont_.fontName, _msgOperationFont_.pointSize, NULL);
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@", numStr, str]];
    [text addAttribute:(NSString*)kCTFontAttributeName value:(id)font range:NSMakeRange(0, text.string.length)];
    [text addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)_msgOperationTitleColor_.CGColor range:[text.string rangeOfString:numStr]];
    CFRelease(font);
    JBoMsgOperationItemInfo *info = [[JBoMsgOperationItemInfo alloc] init];
    info.content = text;
    info.style = style;
    
    [text release];
    
    return [info autorelease];
}

- (NSAttributedString*)commentAttributedTextFromInfo:(JBoLookAndTellCommentInfo*) info
{
    NSString *str = [NSString stringWithFormat:@"%@：%@", info.name, info.comment];
    
    UIColor *color = info.sex == _sexBoy_ ? _sexBoyTextColor_ : _sexGirlTextColor_;
    
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:str];
    
    CTFontRef font = CTFontCreateWithName((CFStringRef)_msgOperationFont_.fontName, _msgOperationFont_.pointSize, NULL);
    [text addAttribute:(NSString*)kCTFontAttributeName value:(id)font range:NSMakeRange(0, text.string.length)];
    [text addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)color.CGColor range:[str rangeOfString:info.name]];
    [text addAttribute:(NSString*)kCTKernAttributeName value:[NSNumber numberWithFloat:1.0] range:NSMakeRange(0, text.string.length)];
    
    //行距
    CTParagraphStyleSetting lineSpaceMode;
    CGFloat lineSpace = 3.0;
    lineSpaceMode.spec = kCTParagraphStyleSpecifierLineSpacingAdjustment;
    lineSpaceMode.value = &lineSpace;
    lineSpaceMode.valueSize = sizeof(CGFloat);
    
    CTParagraphStyleSetting setting[] = {lineSpaceMode};
    
    CTParagraphStyleRef style = CTParagraphStyleCreate(setting, 1);
    if(style != NULL)
    {
        [text addAttribute:(NSString*)kCTParagraphStyleAttributeName value:(id)style range:NSMakeRange(0, text.string.length)];
        CFRelease(style);
    }
    
    CFRelease(font);
    return [text autorelease];
}

/**获取说说操作类型的高度
 *@param commentCount 要显示的评论数量 传 NSNotFound获取显示全部评论
 *@return 说说操作气泡内容的高度
 */
- (NSInteger)getMsgOperationHeightWithCommentCount:(NSInteger)commentCount
{
    NSInteger count = 0;
    
    if(self.transmitCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.praiseCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.pityCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.witnessCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.signUpCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.signInCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.volunteerCount > 0)
    {
        count ++;
    }
    
    if(self.operationInfo.donateCount > 0)
    {
        count ++;
    }
    
    NSInteger height = count * _msgOperationItemHeight_;
    
    if(self.operationInfo.commentInfoArray.count > 0)
    {
        for(NSInteger i = 0; i < self.operationInfo.commentInfoArray.count && i < commentCount; i ++)
        {
            JBoLookAndTellCommentInfo *info = [self.operationInfo.commentInfoArray objectAtIndex:i];
            
            if(info.commentBottmHeight == NSNotFound)
            {
                CGSize size = [JBoImageTextTool getHeightFromAttributedText:[self commentAttributedTextFromInfo:info] contraintWidth:_defaultMultiImageTextViewWidth_ - _msgOperationInnerPadding_ * 2];
                info.commentBottmHeight = size.height + 5.0;
            }

            height += info.commentBottmHeight;
        }
    }
    
    if(height != 0)
    {
        height += 25.0;
    }
    
    return height;
}

/**获取说说内容高度
 *@param width 说说内容宽度限制
 *@param show 是否显示全部内容
 *@return 说说内容高度
 */
- (NSInteger)getContentHeightWithContraintWidth:(CGFloat) width showMultiImageText:(BOOL) show
{
    if(self.contentHeight == NSNotFound || show)
    {
        CGFloat height = 0;
        JBoImageTextLabel *label = [[JBoImageTextLabel alloc] init];
        label.textInset = _defaultMultiImageTextInset_;
        label.minLineHeight = _defaultMultiImageTextLineHeight_;
        label.wordInset = _defaultMultiImageTextWordInset_;
        label.font = _lookAndTellFont_;
        
        for(JBoMultiImageText *text in self.multiInfo)
        {
            NSAttributedString *attributedText = [label getAttributedTextFromString:text.content];
            text.titleHeight = [JBoImageTextTool getHeightFromAttributedText:attributedText contraintWidth:width].height + _defaultMultiImageTextInset_ * 2;
            
            switch (self.type)
            {
                case _lookAndTellTypeShareLink_ :
                    text.imageHeight = _sharelinkDefaultHeight_;
                    break;
                case _lookAndTellTypeShortMovie_ :
                {
                    height += 25.0;
                    NSString *url = [text.imageURLArray firstObject];
                    text.imageHeight = [JBoShareShortMovieView movieHeightForURL:url];
                }
                    break;
                default:
                {
                    text.imageHeight = self.multiInfo.count > 1 ? [JBoMultiImageView getThumbnailHeightWithCount:text.imageURLArray.count] : [JBoMultiImageView getHeightWithCount:text.imageURLArray.count];
                    if(text.imageURLArray.count > 0)
                    {
                        height += _imageTextPadding_ - _imageTextInterval_;
                    }
                } 
                    break;
            }
            
            
            height += text.titleHeight + text.imageHeight + _imageTextInterval_;

            if(text.imageURLArray.count > 0)
            {
                height += _imageTextPadding_;
            }
        }
    
        if(height >= _lookAndTellMaxImageTextHeight_ && !show)
        {
            self.hasMoreText = YES;
            
            JBoMultiImageText *text = [self.multiInfo firstObject];
            
            CGFloat titleHeight = text.titleHeight;
            if(text.titleHeight > _lookAndTellMaxContentHeight_)
            {
                titleHeight = _lookAndTellMaxContentHeight_;
            }
            
            height = titleHeight + text.imageHeight + _multiImageInterval_ + _defaultMultiImageTextButton_ + _imageTextPadding_;
        }
        
        if(!show)
        {
            self.contentHeight = height;
        }
        
        [label release];
        return height;
    }
    return self.contentHeight;
}

- (NSString*)getGroupId
{
    NSString *groupId = self.transmitId == _trasmitNo_ ? self.groupId : self.srcGroupId;
    
    
    if([NSString isEmpty:groupId])
    {
        if(![NSString isEmpty:self.groupId])
        {
            groupId = self.groupId;
        }
        else
        {
            groupId = self.srcGroupId;
        }
    }
    
    return groupId;
}

@end
