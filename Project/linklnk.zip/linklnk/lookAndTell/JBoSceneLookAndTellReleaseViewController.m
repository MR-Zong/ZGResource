//
//  JBoSceneLookAndTellReleaseViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSceneLookAndTellReleaseViewController.h"
#import "JBosceneLookAndTellReleaseView.h"
#import "JBoStraightlineProgressView.h"

@interface JBoSceneLookAndTellReleaseViewController ()<JBoLookAndTellReleaseBaseViewDelegate>

@property(nonatomic,retain) JBosceneLookAndTellReleaseView *releaseView;

//上传进度
@property(nonatomic,retain) JBoStraightlineProgressView *progressView;

@end

@implementation JBoSceneLookAndTellReleaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_sceneImageInfo release];
    [_releaseView release];
    [_conditions release];
    
    [_progressView release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)back
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)releaseLookAndTell
{
    [self.releaseView finish];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [JBoNavigatioinBarOperation setBlackBackItemWithTarget:self action:@selector(back)];
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(releaseLookAndTell) title:@"发布" backgroundImage:nil textColor:[UIColor blackColor]];
    
    JBosceneLookAndTellReleaseView *view = [[JBosceneLookAndTellReleaseView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) sceneImageInfo:self.sceneImageInfo conditions:self.conditions];
    view.navigationController = self.navigationController;
    view.delegate = self;
    [self.view addSubview:view];
    self.releaseView = view;
    [view release];
}

#pragma mark- JBoLookAndTellReleaseBaseView 代理

- (void)lookAndTellReleaseBaseView:(JBoLookAndTellReleaseBaseView *)releaseView didFinishedWithInfo:(JBoLookAndTellListInfo *)info
{
    if(info)
    {
        if([self.delegate respondsToSelector:@selector(userLookAndTellViewController:didSelectedMsg:)])
        {
            [self.delegate userLookAndTellViewController:self didSelectedMsg:info];
        }
    }
}

- (void)lookAndTellReleaseBaseView:(JBoLookAndTellReleaseBaseView *)releaseView updateUploadProgress:(float)progress
{
    if(!self.progressView)
    {
        CGFloat height = 3.0;
        JBoStraightlineProgressView *view = [[JBoStraightlineProgressView alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
        [self.view addSubview:view];
        self.progressView = view;
        [view release];
    }
    if(progress < 0)
    {
        self.progressView.hidden = YES;
        self.progressView.progress = 0;
    }
    else
    {
        [self.view bringSubviewToFront:self.progressView];
        self.progressView.hidden = NO;
        self.progressView.progress = progress;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
