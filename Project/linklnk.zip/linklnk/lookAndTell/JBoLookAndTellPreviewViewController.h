//
//  JBoLookAndTellPreviewViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoLookAndTellListInfo;
@class JBoSceneMakingInfo;

@interface JBoLookAndTellPreviewViewController : UIViewController

- (id)initWithLookAndTell:(JBoLookAndTellListInfo*) lookAndTell sceneMakingInfo:(JBoSceneMakingInfo*) info;

@end
