//
//  JBoCircleBgViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@interface JBoCircleBgViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
{
    NSMutableArray *_sectionArray;
    NSMutableDictionary *_imageDic;
}


@end
