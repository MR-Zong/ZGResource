//
//  JBoLookAndTellViewController.h
//  简宝
//
//  Created by kinghe005 on 13-11-18.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLookAndTellViewController.h"
#import "JBoLookAndTellDelegate.h"

@class JBoOfflineCacheOperation;
@class JBoSceneMakingImageInfo;


@interface JBoUserLookAndTellViewController : JBoLookAndTellViewController

/**说说代理
 */
@property(nonatomic,assign) id<JBoLookAndTellDelegate> delegate;

@property(nonatomic,assign) JBoMsgOperationVStyle operationStyle;

/**关联的场景信息
 */
@property(nonatomic,retain) JBoSceneMakingImageInfo *sceneImageInfo;
/**匹配信息
 */
@property(nonatomic,retain) NSDictionary *conditions;

/**已关联的说说
 */
@property(nonatomic,copy) NSString *relateGroupId;

- (void)cancel;

@end
