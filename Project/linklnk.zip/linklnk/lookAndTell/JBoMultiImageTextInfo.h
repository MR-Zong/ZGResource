//
//  JBoMultiImageTextInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

#define _imageTextInterval_ 5.0
#define _imageTextPadding_ 20.0

/**超友圈多图文信息
 */
@interface JBoMultiImageText : NSObject

/**超友圈信息Id
 */
@property(nonatomic,assign) long long msgId;

/**超友圈信息 源Id
 */
@property(nonatomic,assign) long long srcMsgId;

/**超友圈信息文本内容
 */
@property(nonatomic,copy) NSString *content;

/**图片路径 图片 数组元素是NSString对象
 */
@property(nonatomic,retain) NSArray *imageURLArray;

/**文本内容高度 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger titleHeight;

/**图片内容高度
 */
@property(nonatomic,assign) NSInteger imageHeight;

/**多图文排列顺序
 */
@property(nonatomic,assign) NSInteger order;

@end

/**多图文信息基类
 */
@interface JBoMultiImageTextInfo : NSObject

/**多图文信息 数组元素是 JBoMultiImageText对象
 */
@property(nonatomic,retain) NSMutableArray *multiInfo;

/**图文数量
 */
@property(nonatomic,assign) NSInteger allNum;

/**发布日期
 */
@property(nonatomic,copy) NSString *date;

/**发布用户
 */
@property(nonatomic,copy) NSString *userID;

/**图文内容高度 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger contentHeight;

/**链接标题
 */
@property(nonatomic,copy) NSString *urlTitle;

/**链接
 */
@property(nonatomic,copy) NSString *url;

/**是否具有更多内容，用于查看超友圈信息详情
 */
@property(nonatomic,assign) BOOL hasMoreText;

@end
