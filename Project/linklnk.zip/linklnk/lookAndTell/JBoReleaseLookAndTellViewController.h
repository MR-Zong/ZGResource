//
//  JBoReleaseLookAndTellViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"
#import "SWRevealViewController.h"
#import <CoreLocation/CoreLocation.h>
#import "JBoLookAndTellDelegate.h"

/**发布超友圈发布方式
 */
typedef NS_ENUM(NSInteger, JBoReleaseLookAndTellStyle)
{
    JBoReleaseLookAndTellStyleNormal = 0, // 正常发布
    JBoReleaseLookAndTellStyleScene = 1, // 场景关联
};

@class JBoLookAndTellListInfo,JBoOfflineCacheOperation,JBoSceneMakingImageInfo;

/**发布超友圈信息
 */
@interface JBoReleaseLookAndTellViewController : JBoViewController<UIScrollViewDelegate>

/**超友圈信息离线缓存
 */
@property(nonatomic,retain) JBoOfflineCacheOperation *offlineCache;

/**侧滑视图控制器
 */
@property(nonatomic,assign) SWRevealViewController *revealVC;

@property(nonatomic,assign) id<JBoLookAndTellDelegate> delegate;

/**发布超友圈发布方式
 */
@property(nonatomic,assign) JBoReleaseLookAndTellStyle style;

/**关联的场景信息
 */
@property(nonatomic,retain) JBoSceneMakingImageInfo *sceneInfo;

/**关联的场景 所属地址信息
 */
@property(nonatomic,retain) NSString *addr;

/**关联的场景 所属地址坐标
 */
@property(nonatomic,assign) CLLocationCoordinate2D coordinate;

@end
