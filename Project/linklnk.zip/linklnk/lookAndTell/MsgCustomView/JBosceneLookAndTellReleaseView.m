//
//  JBosceneLookAndTellReleaseView.m
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBosceneLookAndTellReleaseView.h"
#import "JBoSceneConditionHeader.h"
#import "JBoSceneMakingImageInfo.h"
#import "JBoImageOperationView.h"
#import "JBoImageOperationPreviewedViewController.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageTextTool.h"
#import "JBoNavigationViewController.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoSceneMakingInfo.h"
#import "JBoLookAndTellPreviewViewController.h"
#import "JBoDatetimeTool.h"
#import "JBoFileManager.h"
#import "SSTextView.h"

#define _topPadding_ 20.0
#define _leftPadding_ 10.0

@interface JBosceneLookAndTellReleaseView ()<JBoImageOperationViewDelegate, JBoImageOperationPreviewedViewControllerDelegate, JBoMutiImagePickerDelegate>

//场景信息
@property(nonatomic,retain) JBoSceneMakingImageInfo *sceneImageInfo;

// 滚动视图
@property(nonatomic,retain) UIScrollView *scrollConditions;
@property(nonatomic,assign) CGFloat orgHeight;

@property(nonatomic,retain) SSTextView *textView;

//图片选择
@property(nonatomic,retain) JBoImageOperationView *imageOperationView;
@property(nonatomic,retain) UILabel *uploadLabel;

//预览
@property(nonatomic,assign) UIButton *previewButton;
@property(nonatomic,retain) JBoSceneMakingInfo *previewInfo;

//是否发布
@property(nonatomic,assign) BOOL isRelease;

@end

@implementation JBosceneLookAndTellReleaseView

- (id)initWithFrame:(CGRect)frame sceneImageInfo:(JBoSceneMakingImageInfo *)sceneImageInfo conditions:(NSDictionary *)conditions
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.sceneImageInfo = sceneImageInfo;
        
        UIScrollView *bottomView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        bottomView.showsVerticalScrollIndicator = NO;
        bottomView.showsVerticalScrollIndicator = NO;
        bottomView.backgroundColor = [UIColor clearColor];
        [bottomView.panGestureRecognizer requireGestureRecognizerToFail:self.reconverGesture];
        [self addSubview:bottomView];
        self.scrollConditions = bottomView;
        [bottomView release];
        self.orgHeight = self.scrollConditions.height;
        
        
        SSTextView *textView = [[SSTextView alloc] initWithFrame:CGRectMake(_leftPadding_, 20.0, _width_ - _leftPadding_ * 2, self.contentHeight)];
        textView.layer.cornerRadius = 6;
        textView.layer.borderWidth = 0.2;
        
        textView.inputAccessoryView = self.inputAccessoryView;
        textView.automaticallyScroll = YES;
        
        textView.layer.borderColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0].CGColor;
        textView.font = [UIFont systemFontOfSize:17];
        textView.placeholder = self.generPlaceHolder;
        textView.delegate = self;
        textView.textColor = [UIColor blackColor];
        
        //textView.maxCount = _inputFormatLookAndTellNum_;
        [self.scrollConditions addSubview:textView];
        self.textView = textView;
        [textView release];
        
        //图片选择
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(self.textView.left, self.textView.bottom + _conditionInterval_, self.textView.width, 30.0)];
        label.text = @"上传图片";
        label.font = _lookAndTellReleaseFont_;
        label.textColor = [UIColor grayColor];
        label.backgroundColor = [UIColor clearColor];
        [self.scrollConditions addSubview:label];
        self.uploadLabel = label;
        [label release];
        
        JBoImageOperationView *imageOperationView = [[JBoImageOperationView alloc] initWithFrame:CGRectMake(self.textView.left, self.uploadLabel.bottom, self.textView.width, _imageOperationDefaultCellSize_) srcArray:[NSMutableArray array] imageSize:_imageOperationDefaultCellSize_];
        imageOperationView.backgroundColor = [UIColor whiteColor];
        imageOperationView.delegate = self;
        imageOperationView.maxCount = 9;
        [self.scrollConditions addSubview:imageOperationView];
        self.imageOperationView = imageOperationView;
        [imageOperationView release];
        
        CGFloat buttonWidth = 100.0;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(self.width - buttonWidth - _leftPadding_, self.imageOperationView.bottom + _conditionInterval_, buttonWidth, 30.0)];
        [button addTarget:self action:@selector(preview:) forControlEvents:UIControlEventTouchUpInside];
        button.backgroundColor = _navigationBarBackgroundDefaultColor_;
        button.layer.cornerRadius = 5.0;
        button.layer.masksToBounds = YES;
        [button setTitle:@"预览" forState:UIControlStateNormal];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setShowsTouchWhenHighlighted:YES];
        [self.scrollConditions addSubview:button];
        self.previewButton = button;
        
        [self.visibleCondition removeFromSuperview];
        self.visibleCondition = nil;
        [self.protocolView removeFromSuperview];
        [self.scrollConditions addSubview:self.protocolView];
        
        [self setNeedsLayout];
        
        self.previewInfo = [[[JBoSceneMakingInfo alloc] init] autorelease];
        self.previewInfo.sceneId = self.sceneImageInfo.ID;
        self.previewInfo.userDetailInfo = [JBoUserOperation getUserDetailInfo];
        self.previewInfo.conditions = conditions;
        
        self.protocolView.frame = CGRectMake(self.protocolView.left, self.previewButton.bottom + _conditionInterval_ * 2, self.protocolView.width, self.protocolView.height);
        self.scrollConditions.contentSize = CGSizeMake(self.scrollConditions.width, self.protocolView.bottom + _conditionInterval_ * 2);
    }
    return self;
}

- (void)layoutSubviews
{
    self.protocolView.frame = CGRectMake(self.protocolView.left, self.previewButton.bottom + _conditionInterval_ * 2, self.protocolView.width, self.protocolView.height);
    self.scrollConditions.contentSize = CGSizeMake(self.scrollConditions.width, self.protocolView.bottom + _conditionInterval_ * 2);
}

- (void)setNavigationController:(UINavigationController *)navigationController
{
    _navigationController = navigationController;
}

- (UINavigationController*)navigationController
{
    return _navigationController;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_sceneImageInfo release];
    
    [_scrollConditions release];
    
    [_imageOperationView release];
    [_uploadLabel release];
    [_textView release];
    
    [_previewInfo release];
    
    [super dealloc];
}

#pragma mark- 发布

- (BOOL)finish
{
    if(self.isRequesting)
        return NO;
    
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    if([NSString isEmpty:self.textView.text] && self.imageOperationView.srcArray.count == 0)
    {
        [JBoUserOperation alertMsg:@"图文内容不能为空"];
        return NO;
    }
    return [self releaseLookAndTell];
}

- (BOOL)releaseLookAndTell
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    if(self.textView.text.length > _inputFormatLookAndTellNum_ )
    {
        [self alert];
        
        [self.textView setContentOffset:CGPointMake(0, _inputFormatLookAndTellNum_ / (self.textView.frame.size.width / 17.0) * 22) animated:YES];
        return NO;
    }
    
    self.info.date = [JBoDatetimeTool getCurrentTime];
    self.info.type = _lookAndTellTypeNormal_;
    self.info.groupId = [JBoDatetimeTool getTimeAndRandom];
    self.info.visible = self.visible;
    
    [NSThread detachNewThreadSelector:@selector(writeImageToFile) toTarget:self withObject:nil];
    return YES;
}

- (void)writeImageToFile
{
    self.isRequesting = YES;
    NSMutableArray *multis = [[NSMutableArray alloc] init];
    
    JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
    NSString *content = self.textView.text;
    if([NSString isEmpty:content])
        content = @" ";
    
    text.content = content;
    
    if(self.imageOperationView.srcArray.count > 0)
    {
        NSArray *files = [JBoFileManager writeImageInTemporaryFile:self.imageOperationView.srcArray withCompressedScale:_lookAndTellImageCompressedScale_];
        text.imageURLArray = files;
    }
    [multis addObject:text];
    [text release];
    
    [self performSelectorOnMainThread:@selector(uplaodWithInfos:) withObject:multis waitUntilDone:NO];
    
    [multis release];
}

- (void)uplaodWithInfos:(NSMutableArray*) infos
{
    if(infos.count > 0)
    {
        for(NSInteger i = 0;i < infos.count; i ++)
        {
            JBoMultiImageText *text  = [infos objectAtIndex:i];
            [self.imageNameArray addObjectsFromArray:text.imageURLArray];
            
            JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
            httpRequest.startImmediately = NO;
            
            NSString *url = [JBoLookAndTellOperation getReleaseLookAndTellURL];
            if(text.imageURLArray.count == 0)
            {
                url = [JBoLookAndTellOperation getReleaseLookAndTellURLWithOutFiles];
            }
            
            ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
            [request setTimeOutSeconds:30.0];
            
            NSDictionary *paraDic = [JBoLookAndTellOperation releaseLookAndTellWithContent:text.content type:self.info.type groupId:self.info.groupId order:i count:infos.count url:nil needImageText:NO visible:self.visible];
            
            [paraDic enumerateKeysAndObjectsUsingBlock:^(id key, id vaule, BOOL *stop)
             {
                 [request setPostValue:vaule forKey:key];
             }];
            
            for(NSString *str in text.imageURLArray)
            {
                [request addFile:str forKey:_lookAndTellImagesFile_];
            }
            
            [self.httpQueue addOperation:request];
        }
        
        self.info.multiInfo = infos;
        self.success = YES;
        [self.httpQueue go];
    }
}

#pragma mark- http代理

//解析
- (void)releaseData:(NSData *)data
{
    NSArray *array = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:[NSMutableDictionary dictionary] offlineCache:nil];
    if(array.count > 0)
    {
        JBoLookAndTellListInfo *info = [array firstObject];
        
        JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
        
        for(NSInteger i = 0; i < info.multiInfo.count && i < self.info.multiInfo.count; i ++)
        {
            JBoMultiImageText *text = [info.multiInfo objectAtIndex:i];
            JBoMultiImageText *oldText = [self.info.multiInfo objectAtIndex:i];

            [JBoFileManager moveFiles:oldText.imageURLArray withURLs:text.imageURLArray suffix:cache.imageSuffix toPath:cache.normalCachePath];
        }
        
        self.info = info;
        [self sendSuccess:YES];
    }
    else
    {
        [self sendSuccess:NO];
    }
}

#pragma mark- private method

- (void)reconverKeyboard:(UITapGestureRecognizer*) tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (void)preview:(UIButton*) button
{
    self.isRelease = NO;
    
    JBoLookAndTellListInfo *info = [self lookAndTellInfo];
    
    JBoLookAndTellPreviewViewController *preview = [[JBoLookAndTellPreviewViewController alloc] initWithLookAndTell:info sceneMakingInfo:self.previewInfo];
    
    [_navigationController pushViewController:preview animated:YES];
    [preview release];
}

- (JBoLookAndTellListInfo*)lookAndTellInfo
{
    JBoLookAndTellListInfo *info = [[JBoLookAndTellListInfo alloc] init];
  
    info.type = _lookAndTellTypeNormal_;
    info.userName = self.previewInfo.userDetailInfo.rosterInfo.name;
    info.headImageURL = self.previewInfo.userDetailInfo.rosterInfo.imageURL;
    info.sex = self.previewInfo.userDetailInfo.rosterInfo.sex;
    info.role = self.previewInfo.userDetailInfo.rosterInfo.role;
    
    JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
    text.content = self.textView.text;
    text.imageURLArray = self.imageOperationView.srcArray;
    info.multiInfo = [NSMutableArray arrayWithObject:text];
    [text release];
    
    return [info autorelease];
}

#pragma mark-JBoImageOperationView代理

- (void)imageOperationViewDidAddedCell:(JBoImageOperationView *)selectedView
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
    [actionSheet showInView:self];
    [actionSheet release];
}

- (void)imageOperationView:(JBoImageOperationView *)selctedView didSelectImageAtIndex:(NSInteger)index
{
    JBoImageOperationPreviewedViewController *previewVC = [[JBoImageOperationPreviewedViewController alloc] init];
    previewVC.srcArray = selctedView.srcArray;
    previewVC.currentIndex = index;
    previewVC.delegate = self;
    [self.navigationController pushViewController:previewVC animated:YES];
    [previewVC release];
}

- (void)imageOperationViewDidReloadData:(JBoImageOperationView *)selctedView
{
    self.appDelegate.dataLoadingView.hidden = YES;
}

#pragma mark-JBoImageOperationPreviewedViewController代理

- (void)imageOperationPreviewedViewController:(JBoImageOperationPreviewedViewController *)viewController didRemoveImageAtIndex:(NSInteger)index
{
    [self.imageOperationView removeImageAtIndex:index];
}

#pragma makr-actionsheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [self getCamera];
    }
    else if(buttonIndex == 1)
    {
        [self getPhotos];
    }
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        [self.imageOperationView.srcArray addObject:[JBoImageTextTool getThumbnailFromImage:retImage withSize:size]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("album", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [self.appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)self.imageOperationView.maxCount - (int)self.imageOperationView.srcArray.count;;
    mutilImagePicker.title = @"相册";
    
    [mutilImagePicker showInViewController:self.navigationController animated:YES completion:^(void){
        
        [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
    }];
    
    [mutilImagePicker release];
}

#pragma mark-JBoMutilImagePickerViewController代理
- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       if(assetArray.count > 0)
                       {
                           for(ALAsset *asset in assetArray)
                           {
                               // NSLog(@"开始2");
                               UIImage *image = [UIImage imageFromAsset:asset];
                               CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                               UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
                               if(thumbnail)
                               {
                                   [self.imageOperationView.srcArray addObject:thumbnail];
                               }
                               
                           }
                       }
                       
                       dispatch_async(dispatch_get_main_queue(), ^(void){
                           [viewController dismissViewControllerAnimated:YES completion:^(void)
                            {
                                [self.imageOperationView updateContent];
                                self.appDelegate.dataLoadingView.hidden = YES;
                            }];
                       });
                   });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        
        [self.imageOperationView.srcArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

@end
