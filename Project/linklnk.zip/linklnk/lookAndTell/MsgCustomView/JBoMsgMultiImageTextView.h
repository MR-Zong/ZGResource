//
//  JBoMsgMultiImageTextView.h
//  靓咖
//
//  Created by kinghe005 on 14-5-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "JBoLookAndTellReleaseBaseView.h"
#import "SWRevealViewController.h"
#import "JBoLookAndTellTypeSelectedViewController.h"

@class JBoMapInfo;
@class JBoSceneMakingImageInfo;
@class JBoTextView;

/**靓友圈信息发布，一语双关
 */
@interface JBoMsgMultiImageTextView : JBoLookAndTellReleaseBaseView<SWRevealViewControllerDelegate,JBoLookAndTellTypeSelectedViewControllerDelegate,UIAlertViewDelegate>


@property(nonatomic,assign) SWRevealViewController *revealVC;

@property(nonatomic,assign) BOOL needImageText;

/**关联的场景
 */
@property(nonatomic,readonly) UILabel *activityContentLabel;

//定位
@property(nonatomic,retain) JBoMapInfo *mapInfo;
@property(nonatomic,assign) BOOL isLocation;


- (void)viewWillDisAppear;
- (void)currentLocation;

- (BOOL)finish;

/**设置地址和坐标
 */
- (void)setAddr:(NSString*) addr coordinate:(CLLocationCoordinate2D) coordinate;

/**设置场景信息
 */
- (void)setSceneInfo:(JBoSceneMakingImageInfo*) info;

@end
