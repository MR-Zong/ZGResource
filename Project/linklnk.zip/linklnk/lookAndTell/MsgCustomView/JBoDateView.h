//
//  JBoLookAndTellDateView.h
//  靓咖
//
//  Created by kinghe005 on 14-5-6.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _lookAndTellDateViewDefaultHeight_ 60.0

@interface JBoDateView : UIView

@property(nonatomic,retain) NSString *time;
@property(nonatomic,assign) BOOL sameDay;

@end
