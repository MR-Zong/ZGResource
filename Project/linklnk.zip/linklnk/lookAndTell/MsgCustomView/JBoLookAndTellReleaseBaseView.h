//
//  JBoLookAndTellReleaseBaseView.h
//  靓咖
//
//  Created by kinghe005 on 14-5-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSTextView.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoImageCacheTool.h"
#import "JBoFileManager.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserOperation.h"
#import "JBoSceneConditionPickerSelected.h"
#import "JBoSceneConditionPicker.h"

#define _lookAndTellReleaseFont_ [UIFont systemFontOfSize:14.0]

@class JBoLookAndTellReleaseBaseView,JBoLookAndTellListInfo;

@protocol JBoLookAndTellReleaseBaseViewDelegate <NSObject>

/**说说发布完成
 *@param info 新的说说信息
 */
- (void)lookAndTellReleaseBaseView:(JBoLookAndTellReleaseBaseView*) releaseView didFinishedWithInfo:(JBoLookAndTellListInfo*) info;


/**更新上传进度
 *@param progress 当前进度，小于0时进度条隐藏
 */
- (void)lookAndTellReleaseBaseView:(JBoLookAndTellReleaseBaseView *)releaseView updateUploadProgress:(float) progress;

@end

/**说说发布基类
 */
@interface JBoLookAndTellReleaseBaseView : UIView<UITextViewDelegate, UIActionSheetDelegate, UIGestureRecognizerDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, JBoHttpRequestDelegate, JBoSceneConditionPickerDelegate>


@property(nonatomic,assign) UINavigationController *navigationController;

//用户协议和回收键盘手势
@property(nonatomic,retain) UIView *protocolView;
@property(nonatomic,retain) UITapGestureRecognizer *reconverGesture;

//键盘
@property(nonatomic,retain) UIView *inputAccessoryView;

//父视图  父视图初始高度
@property(nonatomic,assign) UIScrollView *scrollView;
@property(nonatomic,assign) CGFloat scrollViewHeight;

@property(nonatomic,readonly) JBoAppDelegate *appDelegate;

//输入框提示内容
@property(nonatomic,copy) NSString *generPlaceHolder;
@property(nonatomic,copy) NSString *activityPlaceHolder;

//输入框的高度
@property(nonatomic,assign) CGFloat contentHeight;
@property(nonatomic,assign) CGFloat labelHeight;

//http请求
@property(nonatomic,retain) ASINetworkQueue *httpQueue;
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//网络请求 是否成功
@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,assign) BOOL success;

// 连说 临时文件
@property(nonatomic,retain) JBoLookAndTellListInfo *info;
@property(nonatomic,retain) NSMutableArray *imageNameArray;

//可见范围
@property(nonatomic,retain) JBoSceneConditionPickerSelected *visibleCondition;
@property(nonatomic,assign) NSInteger visible;
@property(nonatomic,retain) JBoSceneConditionPicker *picker;

@property(nonatomic,assign) id<JBoLookAndTellReleaseBaseViewDelegate> delegate;

- (void)alert;
- (void)sendSuccess:(BOOL) success;
- (void)releaseData:(NSData*) data;

/**更新上传进度
 *@param progress 当前进度，小于0时进度条隐藏
 */
- (void)updateUploadProgress:(float) progress;

@end
