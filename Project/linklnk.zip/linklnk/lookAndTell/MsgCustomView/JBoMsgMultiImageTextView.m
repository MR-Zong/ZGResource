//
//  JBoMsgMultiImageTextView.m
//  靓咖
//
//  Created by kinghe005 on 14-5-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMsgMultiImageTextView.h"
#import "SSTextView.h"
#import "JBoAppDelegate.h"
#import "JBoLookAndTellOperation.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoFileManager.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoCheckBoxTextView.h"
#import "JBoNavigationViewController.h"
#import "JBoImageTextTool.h"
#import "JBoLookAndTellTypeSelectedViewController.h"
#import "JBoMapViewController.h"
#import "JBoCustomFilterBar.h"
#import "JBoSceneMakingOperation.h"
#import "JBoSceneConditionsBase.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoTextView.h"
#import "JBoTextAttachment.h"
#import "JBoTextViewTextInfo.h"
#import "JBoTextStorage.h"
#import "BMKGeoCodeSearch+Utilities.h"
#import "JBoSceneMakingImageInfo.h"

#define _padding_ 10
#define _controlInterval_ 5
#define _controlHeight_ 30

#define _maxMultis_ 3
#define _bottomViewTag_ 3000

#define _sceneMatchTag_ 10

#define _actionSheetImageOperationTag_ 100


@interface JBoMsgMultiImageTextView ()<JBoCheckBoxTextViewDelegate,JBoMutiImagePickerDelegate,BMKGeoCodeSearchDelegate,BMKLocationServiceDelegate,JBoMapViewControllerDelegate,JBoTextViewDelegate>
{
    BMKLocationService *_locationManager;
}

/**地理反编码
 */
@property(nonatomic,retain) BMKGeoCodeSearch *addrSearch;

//活动类型
@property(nonatomic,retain) UIView *typeSelectedView;
@property(nonatomic,readonly) UILabel *activityTypeLabel;
@property(nonatomic,retain) UIImageView *arrowImageView;

//活动是否需要图文
@property(nonatomic,readonly) JBoCheckBoxTextView *needTextImageCheckBox;

//位置
@property(nonatomic,readonly) UILabel *addressLabel;

//当前位置，其他位置
@property(nonatomic,readonly) UIButton *currentLocationButton;
@property(nonatomic,readonly) UIButton *otherLocationButton;
@property(nonatomic,readonly) UIActivityIndicatorView *actView;

//位置信息容器
@property(nonatomic,retain) UIView *locationView;

//信息分割线
@property(nonatomic,retain) UIView *separatorLine;

//是否定位
@property(nonatomic,assign) BOOL locating;

//场景信息
@property(nonatomic,retain) JBoSceneMakingImageInfo *sceneMakingInfo;
@property(nonatomic,assign) BOOL needSendScene;

//当前登录的用户信息
@property(nonatomic,retain) JBoUserDetailInfo *userDetailinfo;

//请求定位
@property(nonatomic,retain) CLLocationManager *sysLocationManager;

/**编辑器
 */
@property(nonatomic,retain) JBoTextView *textView;

//编辑器起始frame
@property(nonatomic,assign) CGRect originalTextFrame;

/**图片信息 数组元素是 JBoTextAttachment
 */
@property(nonatomic,retain) NSMutableArray *attachments;

/**文本输入光标的位置
 */
@property(nonatomic,assign) NSRange selectedRange;

/**长按操作的图片
 */
@property(nonatomic,retain) JBoTextAttachment *longPressedTextAttachment;

/**图片所在段落下标
 */
@property(nonatomic,assign) NSInteger paragraphIndex;

/**图片信息 数组元素是 UIImage 对象
 */
@property(nonatomic,retain) NSArray *images;

@end

@implementation JBoMsgMultiImageTextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.userDetailinfo = [JBoUserOperation getUserDetailInfo];
        
        self.needSendScene = YES;
        self.clipsToBounds = YES;
        self.reconverGesture.delegate = self;

        
        CGFloat width = _width_ - _padding_ * 2;
        CGFloat controHeight = 30.0;
        
        UIView *typeView = [[UIView alloc] initWithFrame:CGRectZero];
        typeView.backgroundColor = [UIColor whiteColor];
        typeView.layer.cornerRadius = 5.0;
        [self addSubview:typeView];
        self.typeSelectedView = typeView;
        [typeView release];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(activityTypeSelected:)];
        _activityTypeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_padding_ / 2, 0, width / 3, controHeight + _padding_)];
        _activityTypeLabel.font = _lookAndTellReleaseFont_;
        _activityTypeLabel.userInteractionEnabled = YES;
        [_activityTypeLabel addGestureRecognizer:tap];
        [tap release];
        _activityTypeLabel.backgroundColor = [UIColor clearColor];
        _activityTypeLabel.text = @"关联目的场景";
        [typeView addSubview:_activityTypeLabel];
        
        UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(activityTypeSelected:)];
        _activityContentLabel = [[UILabel alloc] initWithFrame:CGRectMake(width / 3 , 0, width * 2 / 3 - 25, _activityTypeLabel.frame.size.height)];
        _activityContentLabel.font = _lookAndTellReleaseFont_;
        _activityContentLabel.userInteractionEnabled = YES;
        [_activityContentLabel addGestureRecognizer:tap2];
        [tap2 release];
        _activityContentLabel.backgroundColor = [UIColor clearColor];
        _activityContentLabel.textColor = [UIColor grayColor];
        [_activityContentLabel setTextAlign:JBoTextAlignmentRight];
        [typeView addSubview:_activityContentLabel];

        
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        imageView.frame = CGRectMake(_activityContentLabel.frame.origin.x + _activityContentLabel.frame.size.width + 5.0, (_activityContentLabel.frame.size.height - image.size.height) / 2, image.size.width, image.size.height);
        [typeView addSubview:imageView];
        self.arrowImageView = imageView;
        [imageView release];
        
        typeView.frame = CGRectMake(_padding_, _padding_, width, _activityContentLabel.frame.origin.y + _activityContentLabel.frame.size.height);

        CGFloat y = typeView.frame.origin.y + typeView.frame.size.height + _padding_;
        
        int maxTextCount = 2000;
        int maxImageCount = 20;
        
        self.attachments = [NSMutableArray array];
        self.reconverGesture.enabled = NO;
        
        
        JBoTextView *textView = [[JBoTextView alloc] initWithFrame:CGRectMake(_padding_, y, _width_ - _padding_ * 2, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _defaultFilterBarHeight_ - _padding_ * 2)];
        textView.textDelegate = self;
        textView.font = [UIFont systemFontOfSize:_openPlatformTextFontSize_];
        textView.maxImageCount = maxImageCount;
        textView.maxCount = maxTextCount;
        textView.maxParagraphCount = _maxMultis_;
        textView.enableEidtTextStyle = NO;
        textView.placeHolder = [NSString stringWithFormat:@"关联场景后，陌生人可通过场景匹配找到你，支持%d段图文混排。一次最多上传%d字，%d张图片；超出部分红色显示", _maxMultis_, maxTextCount, maxImageCount];
        [textView setupDefaultInputAccessoryView];
        textView.layer.cornerRadius = 5.0;
        textView.layer.masksToBounds = YES;
        [self addSubview:textView];
        self.textView = textView;
        [textView release];
        
//        NSString *str = [JBoTextStorage attachmentMarkedString];
//        textView.text = [NSString stringWithFormat:@"我%@们", str];
        
        self.originalTextFrame = self.textView.frame;
        
        self.visibleCondition.frame = CGRectMake(self.visibleCondition.left, self.textView.bottom + _controlHeight_, self.visibleCondition.width, self.visibleCondition.height);
        
        
        UIView *locationView = [[UIView alloc] initWithFrame:CGRectMake(_padding_, self.visibleCondition.bottom + _padding_, self.visibleCondition.width, 0)];
        locationView.backgroundColor = [UIColor whiteColor];
        locationView.layer.cornerRadius = 5.0;
        locationView.layer.masksToBounds = YES;
        locationView.tag = _bottomViewTag_;
        [self addSubview:locationView];
        self.locationView = locationView;
        [locationView release];
        
        
        CGFloat buttonWidth = 85.0;
        CGFloat buttonHeight = 30.0;
        UIButton *locButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [locButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [locButton setTitle:@"匹配位置" forState:UIControlStateNormal];
        locButton.titleLabel.font = _lookAndTellReleaseFont_;
        [locButton setImage:[UIImage imageNamed:@"conditions_map"] forState:UIControlStateNormal];
        [locButton setFrame:CGRectMake(0, (_conditionHeight_ - buttonHeight) / 2.0, buttonWidth, buttonHeight)];
        [locationView addSubview:locButton];
        
        _currentLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _currentLocationButton.titleLabel.font = _lookAndTellReleaseFont_;
        [_currentLocationButton setTitle:@"当前位置" forState:UIControlStateNormal];
        [_currentLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_currentLocationButton setImage:[UIImage imageNamed:@"sceneNormal_gray"] forState:UIControlStateNormal];
        [_currentLocationButton setImage:[UIImage imageNamed:@"sceneSelected"] forState:UIControlStateSelected];
        [_currentLocationButton addTarget:self action:@selector(currentLocation) forControlEvents:UIControlEventTouchUpInside];
        [_currentLocationButton setFrame:CGRectMake(locButton.right + 10.0, locButton.top, buttonWidth, buttonHeight)];
        [locationView addSubview:_currentLocationButton];
        
        _otherLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _otherLocationButton.titleLabel.font = _lookAndTellReleaseFont_;
        [_otherLocationButton setTitle:@"其他位置" forState:UIControlStateNormal];
        [_otherLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_otherLocationButton setImage:[UIImage imageNamed:@"sceneNormal_gray"] forState:UIControlStateNormal];
        [_otherLocationButton setImage:[UIImage imageNamed:@"sceneSelected"] forState:UIControlStateSelected];
        [_otherLocationButton addTarget:self action:@selector(otherLocation) forControlEvents:UIControlEventTouchUpInside];
        [_otherLocationButton setFrame:CGRectMake(width - buttonWidth, locButton.top, buttonWidth, buttonHeight)];
        [locationView addSubview:_otherLocationButton];
        
        //分割线
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, _conditionHeight_, locationView.width, _conditionSeparatorLineHeight_)];
        line.backgroundColor = _conditionSeparatorLineColor_;
        [locationView addSubview:line];
        [line release];
        
        //位置地址
        
        CGFloat x = locButton.right - 30.0;
        _addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, _conditionHeight_, width - x - _controlInterval_, _conditionHeight_)];
        //_addressTextView.textAlignment = NSTextAlignmentCenter;
        _addressLabel.textColor = [UIColor blackColor];
        _addressLabel.numberOfLines = 0;
        _addressLabel.font = _lookAndTellReleaseFont_;
        _addressLabel.hidden = YES;
        [locationView addSubview:_addressLabel];
        

        line = [[UIView alloc] initWithFrame:CGRectMake(0, _addressLabel.bottom, locationView.width, _conditionSeparatorLineHeight_)];
        line.backgroundColor = _conditionSeparatorLineColor_;
        [locationView addSubview:line];
        self.separatorLine = line;
        [line release];
        
        _needTextImageCheckBox = [[JBoCheckBoxTextView alloc] initWithFrame:CGRectMake(_controlInterval_, _addressLabel.bottom + (_conditionHeight_ - controHeight) / 2.0, width, controHeight) title:@"参加活动是否需要上传图文"];
        _needTextImageCheckBox.delegate = self;
        
        _needTextImageCheckBox.titleLabel.font = _lookAndTellReleaseFont_;
        [locationView addSubview:_needTextImageCheckBox];
        
        locationView.frame = CGRectMake(locationView.left, locationView.top, locationView.width, _needTextImageCheckBox.bottom);
        
        self.protocolView.frame = CGRectMake(self.protocolView.left, locationView.bottom + _padding_, self.protocolView.width, self.protocolView.height);
        
        self.frame = CGRectMake(0, 0, _width_, self.protocolView.bottom + _padding_);
        self.mapInfo = [[[JBoMapInfo alloc] init] autorelease];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    [super setIsRequesting:isRequesting];
    self.textView.editable = !self.isRequesting;
}

- (void)layoutSubviews
{
    self.visibleCondition.top = self.textView.bottom + _controlHeight_;
    self.locationView.top = self.visibleCondition.bottom + _padding_;
    self.separatorLine.frame = CGRectMake(self.separatorLine.left, self.addressLabel.bottom, self.separatorLine.width, self.separatorLine.height);
    _needTextImageCheckBox.frame = CGRectMake(_needTextImageCheckBox.left, _addressLabel.bottom + (_conditionHeight_ - _needTextImageCheckBox.height) / 2.0, _needTextImageCheckBox.width, _needTextImageCheckBox.height);
    self.locationView.frame = CGRectMake(self.locationView.left, self.locationView.top, self.locationView.width, _needTextImageCheckBox.bottom);
    
    self.protocolView.top = self.locationView.bottom + _padding_;
    self.frame = CGRectMake(0, 0, _width_, self.protocolView.bottom + _padding_);
    self.scrollView.contentSize = self.bounds.size;
}

#pragma mark- 键盘

/**键盘高度改变
 */
- (void)keyboardWillChangeFrame:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    CGRect frame = [[dic objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    frame = [self.superview convertRect:frame fromView:nil];
    
    if(frame.origin.y < self.superview.height)
    {
        CGFloat keyboardHeight = frame.size.height;
        CGRect frame = self.originalTextFrame;
        frame.size.height -= keyboardHeight;
        self.textView.frame = frame;
    }
    else
    {
        self.textView.frame = self.originalTextFrame;
    }
    [self setNeedsLayout];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoMsgMultiImageTextView dealloc");
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
    
    [_activityContentLabel release];
    [_activityTypeLabel release];
    [_arrowImageView release];
    [_needTextImageCheckBox release];
    
    [_addressLabel release];
    [_actView release];
    [_locationManager release];
    [_addrSearch release];
    [_mapInfo release];
    
    [_sceneMakingInfo release];
    
    [_locationView release];
    [_separatorLine release];
    
    [_sysLocationManager release];
    
    [_textView release];
    [_attachments release];
    [_longPressedTextAttachment release];
    
    [super dealloc];
}

- (void)viewWillDisAppear
{
    self.locating = NO;
    [_actView stopAnimating];
    
    if(_locationManager)
    {
        [_locationManager stopUserLocationService];
        _locationManager.delegate = nil;
        
        [_locationManager release];
        _locationManager = nil;
    }
    
    if(_addrSearch)
    {
        _addrSearch.delegate = nil;
    }
}

- (void)activityTypeSelected:(UITapGestureRecognizer*) tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    [self.revealVC setFrontViewPosition:FrontViewPositionLeftSide animated:YES];
}


- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if([touch.view isEqual:self.typeSelectedView] || [touch.view isEqual:self.activityContentLabel] || [touch.view isEqual:self.activityTypeLabel] || [touch.view isKindOfClass:[JBoCustomFilterBar class]] || [touch.view isKindOfClass:[UIButton class]] || [touch.view isKindOfClass:[JBoSceneConditionPickerSelected class]] || [touch.view isKindOfClass:[JBoSceneConditionPicker class]])
    {
        return NO;
    }
    return YES;
}


#pragma mark- JBoCheckBoxTextView代理

- (void)selectedStateDidChanged:(JBoCheckBoxTextView *)checkBox
{
    self.needImageText = checkBox.checkBox.selected;
}

#pragma mark- public method

/**设置地址和坐标
 */
- (void)setAddr:(NSString*) addr coordinate:(CLLocationCoordinate2D) coordinate
{
    self.mapInfo.addr = addr;
    self.mapInfo.coordinate = coordinate;
    self.isLocation = YES;
    [self finishLocation:YES];
}

/**设置场景信息
 */
- (void)setSceneInfo:(JBoSceneMakingImageInfo*) info
{
    self.sceneMakingInfo = info;
    self.activityContentLabel.text = info.title;
    self.activityContentLabel.userInteractionEnabled = NO;
    self.activityTypeLabel.userInteractionEnabled = NO;
    self.arrowImageView.hidden = YES;
}

#pragma mark-发送

- (BOOL)finish
{
    if(self.revealVC.frontViewPosition == FrontViewPositionLeftSide)
    {
        [self.revealVC setFrontViewPosition:FrontViewPositionLeft animated:YES];
        return NO;
    }
    
    if(self.isRequesting)
        return NO;
    
    if([NSString isEmpty:self.textView.text])
    {
        [JBoUserOperation alertMsg:@"图文内容不能为空"];
        return NO;
    }
 
    if(!self.sceneMakingInfo)
    {
        [JBoUserOperation alertMsg:@"请选择目的场景"];
        return NO;
    }
    
    return [self releaseLookAndTell];
}

- (BOOL)releaseLookAndTell
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    self.info.date = [JBoDatetimeTool getCurrentTime];
    self.info.type = self.sceneMakingInfo.typeId;
    self.info.groupId = [JBoDatetimeTool getTimeAndRandom];
    self.info.visible = self.visible;
    
    [NSThread detachNewThreadSelector:@selector(writeImageToFile) toTarget:self withObject:nil];
    return YES;
}

/**获取编辑器中所有图片图片
 *@return 数组元素是 UIImage 对象
 */
- (NSMutableArray*)getImages
{
    NSArray *attachments = [self.textView attachments];
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:attachments.count];
    for(JBoTextAttachment *attachment in attachments)
    {
        if(attachment.image)
        {
            [array addObject:attachment.image];
        }
    }
    
    return array;
}

- (void)writeImageToFile
{
    self.isRequesting = YES;
    NSMutableArray *multis = [[NSMutableArray alloc] init];
    
    //获取文本和图片信息
    NSArray *textInfos = [self.textView getSeparatedTextInfo];
    self.images = [self getImages];
    
    NSInteger loc = 0;
    for(NSInteger i = 0;i < textInfos.count && i < self.textView.maxParagraphCount;i ++)
    {
        JBoTextViewTextInfo *info = [textInfos objectAtIndex:i];
        JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
        
        NSString *content = info.content;
        
        if([NSString isEmpty:content])
            content = @" ";
        
        text.content = content;
        
        if(info.imageCount > 0)
        {
            NSRange range = NSMakeRange(loc, info.imageCount);
            if(range.location + range.length <= self.images.count)
            {
                NSArray *files = [JBoFileManager writeImageInTemporaryFile:[self.images objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:range]] withCompressedScale:_lookAndTellImageCompressedScale_];
                text.imageURLArray = files;
            }
        }
        [multis addObject:text];
        [text release];
        loc += info.imageCount;
    }
    
    [self performSelectorOnMainThread:@selector(uplaodWithInfos:) withObject:multis waitUntilDone:NO];
    
    [multis release];
}

- (void)uplaodWithInfos:(NSMutableArray*) infos
{
    if(infos.count > 0)
    {
        BOOL needImageText = self.needImageText;
        if(self.sceneMakingInfo.typeId == _scentTypeMakeFriend_ || self.sceneMakingInfo.typeId == _sceneTypeLoving_)
        {
            needImageText = NO;
        }
        
        for(NSInteger i = 0;i < infos.count; i ++)
        {
            JBoMultiImageText *text  = [infos objectAtIndex:i];
            [self.imageNameArray addObjectsFromArray:text.imageURLArray];
            
            NSString *url = [JBoLookAndTellOperation getReleaseLookAndTellURL];
            if(text.imageURLArray.count == 0)
            {
                url = [JBoLookAndTellOperation getReleaseLookAndTellURLWithOutFiles];
            }
            
            ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:url]];
            [request setTimeOutSeconds:30.0];
            
            NSDictionary *paraDic = [JBoLookAndTellOperation releaseLookAndTellWithContent:text.content type:self.info.type groupId:self.info.groupId order:i count:infos.count url:nil needImageText:needImageText visible:self.visible];
            
            [paraDic enumerateKeysAndObjectsUsingBlock:^(id key, id vaule, BOOL *stop)
             {
                 [request setPostValue:vaule forKey:key];
             }];
            
            for(NSString *str in text.imageURLArray)
            {
                [request addFile:str forKey:_lookAndTellImagesFile_];
            }
            
            [self.httpQueue addOperation:request];
        }
        
//        if(self.info.type != 0 && self.needSendScene)
//        {
//            ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[JBoSceneMakingOperation getSceneMakingMatchURL]]];
//            request.tag = _sceneMatchTag_;
//            NSMutableDictionary *dic = [JBoSceneMakingOperation getSceneMakingPostDataWithCoordinate:self.mapInfo.coordinate sceneId:self.sceneMakingInfo.ID radius:2000 pageNum:1 row:1 lastSceneMsgId:0 lastSceneMsgTime:nil curSceneMsgId:0];
//            
//            [dic setObject:self.info.groupId forKey:_lookAndTellGroupId_];
//           // [dic addEntriesFromDictionary:self.sceneConditions];
//            
//            if([JBoSceneMakingOperation canFiterWithSceneImageInfo:self.sceneMakingInfo conditions:dic needChangSex:YES])
//            {
//                [dic removeObjectForKey:_sexId_];
//            }
//            
//            [dic enumerateKeysAndObjectsUsingBlock:^(id key, id vaule, BOOL *stop)
//             {
//                 [request setPostValue:vaule forKey:key];
//             }];
//            [self.httpQueue addOperation:request];
//        }
        
        self.info.multiInfo = infos;
        self.success = YES;
        [self.httpQueue go];
    }
}

#pragma mark-http代理

- (void)releaseData:(NSData *)data
{
    NSArray *array = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:[NSMutableDictionary dictionary] offlineCache:nil];
    if(array.count > 0)
    {
        JBoLookAndTellListInfo *info = [array firstObject];
        
        NSInteger loc = 0;
        JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
        for(NSInteger i = 0; i < info.multiInfo.count && i < self.info.multiInfo.count; i ++)
        {
            JBoMultiImageText *text = [info.multiInfo objectAtIndex:i];
            JBoMultiImageText *oldText = [self.info.multiInfo objectAtIndex:i];
            
            NSRange range = NSMakeRange(loc, text.imageURLArray.count);

            //把图片移到缓存文件夹
            if(range.location + range.length <= self.images.count)
            {
                NSArray *imageArray = [self.images objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:range]];
                loc += imageArray.count;
                
                [JBoFileManager moveFiles:oldText.imageURLArray withURLs:text.imageURLArray suffix:cache.imageSuffix toPath:cache.normalCachePath];
            }
        }
        
        self.info = info;
        [self sendSuccess:YES];
    }
    else
    {
        [self sendSuccess:NO];
    }
}

#pragma mark- textView代理

- (void)customTextViewDidBeginEditing:(JBoTextView *)textView
{
    [self.scrollView setContentOffset:CGPointMake(0, textView.top - _padding_) animated:YES];
}

- (void)customTextViewDidInsertImage:(JBoTextView *)textView
{
    if(self.isRequesting)
        return;
    
    self.longPressedTextAttachment = nil;
    self.paragraphIndex = NSNotFound;
    NSInteger count = textView.maxImageCount - [self attachments].count;
    if(count <= 0)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"每块图片集合您最多只能选择%d张图片", (int)textView.maxImageCount] message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    self.selectedRange = textView.selectedRange;
    
    [self showImagePickerActionSheet];
}

- (void)customTextView:(JBoTextView *)textView didInsertAttachemtsInWithTextLength:(NSInteger)length
{
    self.textView.selectedRange = NSMakeRange(MIN(self.selectedRange.location + length, self.textView.text.length), 0);
    self.selectedRange = NSMakeRange(NSNotFound, 0);
}

- (void)customTextView:(JBoTextView *)textView willDeleteAttachments:(NSArray *)attachments
{
    [self.attachments removeObjectsInArray:attachments];
    self.longPressedTextAttachment = nil;
    self.paragraphIndex = NSNotFound;
}

- (void)customTextView:(JBoTextView *)textView didPasteAttachemts:(NSArray *)attachments
{
    [self.attachments addObjectsFromArray:attachments];
}

- (NSArray*)customTextViewDidGetAttachments:(JBoTextView *)textView
{
    return self.attachments;
}

- (void)customTextView:(JBoTextView *)textView WillReplaceAttachemt:(JBoTextAttachment *)attachment withAttachemnt:(JBoTextAttachment *)otherAttachment
{
    if(otherAttachment != nil && attachment != nil)
    {
        NSInteger index = [self.attachments indexOfObject:attachment];
        if(index != NSNotFound)
        {
            [self.attachments replaceObjectAtIndex:index withObject:otherAttachment];
        }
    }
    self.longPressedTextAttachment = nil;
    self.paragraphIndex = NSNotFound;
}

- (void)customTextView:(JBoTextView *)textView didLongPressAttachemt:(JBoTextAttachment *)attachment atParagraphIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    self.paragraphIndex = index;
    self.longPressedTextAttachment = attachment;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"图片操作" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"更改图片", @"删除图片", nil];
    actionSheet.tag = _actionSheetImageOperationTag_;
    actionSheet.destructiveButtonIndex = 1;
    [actionSheet showInView:self];
    [actionSheet release];
}

- (void)customTextViewDidUndo:(JBoTextView *)textView
{
    [self.attachments removeAllObjects];
    [self.attachments addObjectsFromArray:[textView attachments]];
}

- (void)customTextViewDidRedo:(JBoTextView *)textView
{
    [self.attachments removeAllObjects];
    [self.attachments addObjectsFromArray:[textView attachments]];
}

#pragma mark- actionsheet代理


- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(actionSheet.tag == _actionSheetImageOperationTag_)
    {
        switch (buttonIndex)
        {
            case 0 :
            {
                [self showImagePickerActionSheet];
            }
                break;
            case 1 :
            {
                [self.textView replaceAttachment:self.longPressedTextAttachment withAttachment:nil paragraphIndex:self.paragraphIndex];
                self.longPressedTextAttachment = nil;
            }
                break;
            default:
            {
                self.longPressedTextAttachment = nil;
                self.paragraphIndex = NSNotFound;
            }
                break;
        }
    }
    else
    {
        switch (buttonIndex)
        {
            case 0:
            {
                [self getCamera];
            }
                break;
            case 1 :
            {
                [self getPhotos];
            }
                break;
            default:
                break;
        }
    }
}

//图片选择
- (void)showImagePickerActionSheet
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"图片添加文字请在选中状态点击靓+" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", @"纯色背景文字", nil];
    [actionSheet showInView:self.navigationController.view];
    [actionSheet release];
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机无法拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void){
        
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:retImage withSize:size];
        
        JBoTextAttachment *attachment = [self.textView attachmentWithImage:thumbnail];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 if(attachment)
                 {
                     [self operationAttachments:[NSArray arrayWithObject:attachment]];
                 }
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [self.appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

#pragma mark- 相册

//发送图片 打开相册选着图片
- (void)getPhotos
{
    NSInteger count = (self.longPressedTextAttachment != nil && self.paragraphIndex != NSNotFound) ? 1 : self.textView.maxImageCount - self.attachments.count;
    
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)count;
    mutilImagePicker.title = @"相册";
    [mutilImagePicker showInViewController:self.navigationController animated:YES completion:nil];
    
    [mutilImagePicker release];
}


- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       NSMutableArray *attachments = [NSMutableArray arrayWithCapacity:assetArray.count];
                       if(assetArray.count > 0)
                       {
                           for(ALAsset *asset in assetArray)
                           {
                               UIImage *image = [UIImage imageFromAsset:asset];
                               CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                               
                               UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
                               JBoTextAttachment *attachment = [self.textView attachmentWithImage:thumbnail];
                               if(attachment)
                               {
                                   [attachments addObject:attachment];
                               }
                           }
                       }
                       
                       dispatch_async(dispatch_get_main_queue(), ^(void){
                           [viewController dismissViewControllerAnimated:YES completion:^(void)
                            {
                                [self operationAttachments:attachments];
                                self.appDelegate.dataLoadingView.hidden = YES;
                            }];
                       });
                   });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
        
        JBoTextAttachment *attachment = [self.textView attachmentWithImage:thumbnail];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 if(attachment)
                 {
                     [self operationAttachments:[NSArray arrayWithObject:attachment]];
                 }
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

#pragma mark- private method

//操作附件
- (void)operationAttachments:(NSArray*) attachments
{
    if(attachments.count == 0)
        return;
    if(self.longPressedTextAttachment != nil && self.paragraphIndex != NSNotFound)
    {
        [self.textView replaceAttachment:self.longPressedTextAttachment withAttachment:[attachments firstObject] paragraphIndex:self.paragraphIndex];
    }
    else
    {
        [self.textView insertAttachments:attachments atIndex:self.selectedRange.location];
        [self.attachments addObjectsFromArray:attachments];
    }
}

#pragma mark-位置
//位置
- (void)currentLocation
{
    
    if(![NSString isEmpty:self.userDetailinfo.defaultAddr])
    {
        self.mapInfo.coordinate = CLLocationCoordinate2DMake(self.userDetailinfo.defalutAddrLat, self.userDetailinfo.defaultAddrLon);
        NSDictionary *dic = [self.userDetailinfo strAddrAndPoiAddr];
        self.mapInfo.strAddr = [dic objectForKey:mapStrAddrKey];
        self.mapInfo.poiAddr = [dic objectForKey:mapPoiAddrKey];
        self.isLocation = YES;
        _addressLabel.hidden = NO;
        _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.mapInfo];
        [self setCurSelected:YES];
    }
    else
    {
        _addressLabel.hidden = YES;
        if(!_actView)
        {
            CGFloat size = 30;
            _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            _actView.hidesWhenStopped = YES;
            _actView.frame = CGRectMake(_addressLabel.frame.origin.x, _addressLabel.frame.origin.y + (_addressLabel.frame.size.height - size) / 2, size, size);
            UIView *view = [self viewWithTag:_bottomViewTag_];
            [view addSubview:_actView];
        }
        
        [_actView startAnimating];
        [self location];
    }
}

- (void)otherLocation
{
    [self viewWillDisAppear];
    
    JBoMapViewController *mapVC = [[JBoMapViewController alloc] init];
    mapVC.delegate = self;
    mapVC.isSender = YES;
    mapVC.black = YES;
    if(self.isLocation)
    {
        mapVC.coordinate = self.mapInfo.coordinate;
        mapVC.detailAddr = self.mapInfo.strAddr;
        mapVC.poiInfo = self.mapInfo.poiAddr;
    }
    
    [self.navigationController pushViewController:mapVC animated:YES];
    [mapVC release];
}

- (void)mapViewControllerWillDisAppear:(JBoMapViewController *)mapView
{
    
}

- (void)mapViewController:(JBoMapViewController *)mapView didLocatedWithInfo:(NSDictionary *)userInfo
{
    JBoMapInfo *info = [userInfo objectForKey:_locationInfo_];
    
    
    _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:info];
    CGSize size = [JBoImageTextTool getStringSize:self.addressLabel.text withFont:self.addressLabel.font andContraintSize:CGSizeMake(self.addressLabel.width, _maxFloat_)];
    CGFloat height = size.height + 10.0;
    if(height > _conditionHeight_)
    {
        self.addressLabel.frame = CGRectMake(self.addressLabel.left, self.addressLabel.top, self.addressLabel.width, height);
        [self setNeedsLayout];
    }
    [self setCurSelected:NO];

    self.isLocation = YES;
    self.mapInfo = info;
    
}

- (void)finishLocation:(BOOL) success
{
    NSLog(@"定位完成");
    [_actView stopAnimating];
    _addressLabel.hidden = NO;
    if(success)
    {
        self.isLocation = YES;
        _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.mapInfo];
        [self setCurSelected:YES];
        
        //保存默认位置
        if([NSString isEmpty:self.userDetailinfo.defaultAddr])
        {
            if(_addressLabel.text == nil)
                return;
            
            self.userDetailinfo.defaultAddr = _addressLabel.text;
            self.userDetailinfo.defalutAddrLat = self.mapInfo.coordinate.latitude;
            self.userDetailinfo.defaultAddrLon = self.mapInfo.coordinate.longitude;
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 _addressLabel.text, _rosterDefaultAddr_,
                                 [NSNumber numberWithDouble:self.mapInfo.coordinate.latitude], _rosterDefaultLat_,
                                 [NSNumber numberWithDouble:self.mapInfo.coordinate.longitude], _rosterDefaultLon_, nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:_saveDefaultAddrNotification_ object:self userInfo:dic];
        }
    }
    else
    {
        self.isLocation = NO;
        _addressLabel.text = @"无法确定您当前的位置";
        
        [JBoUserOperation openSystemSettingsAlertViewWithDelegate:self];
    }
    self.locating = NO;
}

- (void)setCurSelected:(BOOL)selected
{
    _currentLocationButton.selected = selected;
    _otherLocationButton.selected = !selected;
}

#pragma mark- UIAlertView delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:_alertButtonTitleWhenCannotLocate_])
    {
        [JBoUserOperation openSystemSettings];
    }
}

#pragma mark-

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(error != BMK_SEARCH_NO_ERROR)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        [self viewWillDisAppear];
        return;
    }
    
    self.mapInfo.strAddr = result.address;
    BMKPoiInfo *pointInfo = [result.poiList firstObject];
    self.mapInfo.poiAddr = pointInfo.name;
    
    self.isLocation = YES;
    [self finishLocation:YES];
    [self viewWillDisAppear];
}

#pragma mark-定位
- (void)location
{
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        if([CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined)
        {
            self.sysLocationManager = [[[CLLocationManager alloc] init] autorelease];
            
            [self.sysLocationManager requestAlwaysAuthorization];
        }
#endif
    }
    
    BOOL canloc = NO;
    
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways;
#endif
    }
    else
    {
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized;
    }
    
    if(canloc)
    {
        if(!_locationManager)
        {
            _locationManager = [[BMKLocationService alloc] init];
            _locationManager.delegate = self;
        }
        
        self.locating = YES;
        [_locationManager startUserLocationService];
    }
    else
    {
        [JBoUserOperation cannotUserLocationService];
        [self finishLocation:NO];
    }
}

#pragma mark- BMKLocationService delegate

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {
        self.mapInfo.coordinate = userLocation.location.coordinate;
        
        if(!_addrSearch)
        {
            self.addrSearch = [BMKGeoCodeSearch sharedInstance];
        }
        
        self.addrSearch.delegate = self;
        
        BMKReverseGeoCodeOption *option = [[[BMKReverseGeoCodeOption alloc] init] autorelease];
        option.reverseGeoPoint = self.mapInfo.coordinate;
        if([_addrSearch reverseGeoCode:option])
        {
            NSLog(@"地理反编码");
        }
        [_locationManager stopUserLocationService];
    }
}


- (void)didFailToLocateUserWithError:(NSError *)error
{
    NSLog(@"定位失败");
    [_locationManager stopUserLocationService];
    [self finishLocation:NO];
}

#pragma mark- JBoLookAndTellTypeSelectedViewController delegate

- (void)lookAndTellTypeSelectedViewController:(JBoLookAndTellTypeSelectedViewController *)viewController didFinishWithInfo:(JBoSceneMakingImageInfo *)info
{
    self.sceneMakingInfo = info;
    self.activityContentLabel.text = info.title;
    if(!self.isLocation)
    {
        [self currentLocation];
    }
}

#pragma mark- SWRevealViewController delegate

- (void)revealController:(SWRevealViewController *)revealController willMoveToPosition:(FrontViewPosition)position
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    if(position == FrontViewPositionLeftSide)
    {
        self.textView.editable = NO;
    }
    
    if(position == FrontViewPositionLeft)
    {
        self.textView.editable = YES;
    }
}

@end


