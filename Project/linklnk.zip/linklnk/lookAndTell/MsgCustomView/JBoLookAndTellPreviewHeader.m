//
//  JBoLookAndTellPreviewHeader.m
//  靓咖
//
//  Created by kinghe005 on 14-7-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellPreviewHeader.h"
#import "JBoSceneMakingInfo.h"
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoAppDelegate.h"
#import "JBoImageTextTool.h"
#import "JBoDatetimeTool.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoSceneMakingConditionCell.h"
#import "JBoSceneMakingConditionView.h"


#define _paddingLeftAndRight_ 10
#define _paddingTop_ 10

#define _cellHeight_ _sceneMakingConditionHeight_

#undef _controlHeight_

#define _controlHeight_ 20
#define _controlInterval_ 5

#define _buttonWidth_ 20
#define _buttonHeight_ 100


@interface JBoLookAndTellPreviewHeader ()

@property(nonatomic,retain) JBoSceneMakingInfo *info;

@end

@implementation JBoLookAndTellPreviewHeader

- (id)initWithFrame:(CGRect)frame info:(JBoSceneMakingInfo *)info
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.info = info;
        
        [self loadInitView];
    }
    return self;
}

- (void)dealloc
{
    [_info release];
    
    [super dealloc];
}

- (void)loadInitView
{
    UIView *infoView = [[UIView alloc] initWithFrame:CGRectMake(0, _paddingTop_, self.width, _defaultImageSize_)];
    infoView.backgroundColor = [UIColor whiteColor];
    [self addSubview:infoView];
    [infoView release];
    
    //头像
    JBoUserHeadImageView *headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_paddingLeftAndRight_, 0, _defaultImageSize_, _defaultImageSize_)];
    headImageView.sex = self.info.userDetailInfo.rosterInfo.sex;
    headImageView.role = self.info.userDetailInfo.rosterInfo.role;
    
    headImageView.userInteractionEnabled = YES;
    [infoView addSubview:headImageView];
    [headImageView release];
    
    JBoUserDetailInfo *info = [JBoUserDetailInfo userDetailInfoFromUserDetaults];
    if(info.rosterInfo.image)
    {
        headImageView.imageView.image = info.rosterInfo.image;
    }
    
    
    //昵称
    JBoUserNameLabel *nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(headImageView.right + _controlInterval_, headImageView.top, _width_ - headImageView.right - _paddingLeftAndRight_, _defaultImageSize_)];
    nameLabel.text = self.info.userDetailInfo.rosterInfo.name;
    nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
    nameLabel.backgroundColor = [UIColor clearColor];
    nameLabel.sex = self.info.userDetailInfo.rosterInfo.sex;
    [infoView addSubview:nameLabel];
    [nameLabel release];
    
    
    UIView *linesView = [[UIView alloc] initWithFrame:CGRectMake(0, infoView.bottom + _controlInterval_, _width_, 0.3)];
    linesView.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:linesView];
    [linesView release];
    
    //标题
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, linesView.bottom + _controlHeight_, self.width, 25.0)];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.text = [self.info title];
    
    titleLabel.font = [UIFont boldSystemFontOfSize:17.0];
    [titleLabel setTextAlign:JBoTextAlignmentCenter];
    [self addSubview:titleLabel];
    [titleLabel release];
    
    CGFloat height = 0;

    //匹配条件
    JBoSceneMakingConditionView *view = [[JBoSceneMakingConditionView alloc] initWithFrame:CGRectMake(0, titleLabel.bottom + _controlInterval_, self.width, 0) info:self.info operation:JBoSceneMakingConditionOperaionPreview];
    view.navigationController = self.navigationController;
    [self addSubview:view];
    [view release];

    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, view.bottom + _paddingTop_, _width_, 0.3)];
    lineView.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:lineView];
    [lineView release];
    height = lineView.bottom;
    
    
    self.height = height;
}


@end

