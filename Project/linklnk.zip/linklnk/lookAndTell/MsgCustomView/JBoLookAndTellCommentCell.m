//
//  JBoLookAndTellCommentCell.m
//  靓咖
//
//  Created by kinghe005 on 14-7-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellCommentCell.h"
#import "JBoBasic.h"
#import <QuartzCore/QuartzCore.h>

@implementation JBoLookAndTellCommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouch:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_lookAndTellCommentContentInterval_, _lookAndTellCommentContentInterval_, _lookAndTellCommentImageSize_, _lookAndTellCommentImageSize_)];
        _headImageView.layer.cornerRadius = 17.0;
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [tap release];
        [self.contentView addSubview:_headImageView];
        
        CGFloat width = _width_ - _headImageView.right- _lookAndTellCommentContentInterval_ * 2;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _lookAndTellCommentContentInterval_, _headImageView.top, width / 2, _lookAndTellCommentContentHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _nameLabel.bottom, width , _lookAndTellCommentContentHeight_)];
        _contentLabel.recognizeURL = NO;
        _contentLabel.textInset = _lookAndTellCommentContentTextInset_;
        _contentLabel.font = _lookAndTellCommentContentFont_;
        _contentLabel.minLineHeight = _lookAndTellCommentContentMinLineHeight_;
        _contentLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_contentLabel];
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_contentLabel release];
    
    [super dealloc];
}

- (void)headImageDidTouch:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCommentCellDidTapHeadImage:)])
    {
        [self.delegate lookAndTellCommentCellDidTapHeadImage:self];
    }
}

- (void)layoutSubviews
{
    _contentLabel.height = self.contentHeight;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
