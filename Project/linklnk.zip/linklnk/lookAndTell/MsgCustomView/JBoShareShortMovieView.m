//
//  JBoShareShortMovieView.m
//  靓咖
//
//  Created by kinghe005 on 14-5-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoShareShortMovieView.h"
#import "JBoMultiImageTextView.h"
#import "JBoBasic.h"
#import "NSString+customString.h"
#import "JBoImageTextTool.h"
#import "JBoImageCacheTool.h"

#define _thumbnail_ @"thumbnail"

@implementation JBoShareShortMovieView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UILabel *idLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 20.0)];
        idLabel.textColor = [UIColor grayColor];
        idLabel.text = @"分享了一个视频";
        idLabel.font = [UIFont systemFontOfSize:13.0];
        idLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:idLabel];
        [idLabel release];
        
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(0, idLabel.frame.size.height, frame.size.width, 0)];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.delegate = self;
        _contentLabel.font = _lookAndTellFont_;
        _contentLabel.textInset = _defaultMultiImageTextInset_;
        _contentLabel.minLineHeight = _defaultMultiImageTextLineHeight_;
        _contentLabel.wordInset = _defaultMultiImageTextWordInset_;
        [self addSubview:_contentLabel];
        
        _shortMovieView = [[JBoShortMovieView alloc] initWithFrame:CGRectZero];
        _shortMovieView.delegate = self;
        _shortMovieView.firstImageView.thumbnailSize = CGSizeMake(_maxChatBubbleWidth_, _maxFloat_);
        _shortMovieView.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:0.5];
        [self addSubview:_shortMovieView];
    }
    return self;
}


- (void)dealloc
{
    [_shortMovieView release];
    [_contentLabel release];
    
    self.delegate = nil;
    self.layoutView = nil;
    
    [super dealloc];
}

- (void)setSrcArray:(NSArray *)srcArray
{
    if(_srcArray != srcArray)
    {
        [_srcArray release];
        _srcArray = [srcArray retain];
        [self setNeedsLayout];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    for(NSInteger i = 0;i < _srcArray.count;i ++)
    {
        JBoMultiImageText *info = [_srcArray objectAtIndex:i];
        
        _contentLabel.frame = CGRectMake(0, _contentLabel.frame.origin.y, self.bounds.size.width, info.titleHeight + _contentLabel.textInset * 2);
        _contentLabel.text = info.content;
    }
    
    JBoMultiImageText *info = [_srcArray firstObject];
    NSString *url = [info.imageURLArray firstObject];
    [self reloadImageWithURL:url];
    
    CGFloat width = _shortMovieView.bounds.size.width;
    CGFloat height = _shortMovieView.bounds.size.height;
    width = width == 0 ? 200.0 : width;
    height = height == 0 ? _shareShortMovieDefaultSize_ : height;

    
    _shortMovieView.frame = CGRectMake(0, _contentLabel.frame.origin.y + _contentLabel.frame.size.height + _multiImageInterval_, width, height);
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, _shortMovieView.frame.origin.y + _shortMovieView.frame.size.height + _multiImageInterval_);
    
    [self.layoutView setNeedsLayout];
    [_shortMovieView setNeedsLayout];
}

- (void)reloadImageWithURL:(NSString *)url
{
    if([NSString isEmpty:url])
        return;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *thumbnail = [cache imageForURL:url thumbnailSize:CGSizeMake(_maxChatBubbleWidth_, _maxFloat_)];
    if(thumbnail)
    {
        [_shortMovieView setImage:thumbnail];
    }
    else
    {
        NSLog(@"%@", NSStringFromCGSize(_shortMovieView.firstImageView.thumbnailSize));
        [_shortMovieView.firstImageView getImageWithURL:url];
    }
}

+ (CGFloat)movieHeightForURL:(NSString*) url
{
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *thumbnail = [cache imageForURL:url thumbnailSize:CGSizeMake(_maxChatBubbleWidth_, _maxFloat_)];
    
    if(thumbnail)
    {
        CGSize size = [JBoImageTextTool shrinkImage:thumbnail WithSize:CGSizeMake(_maxChatBubbleWidth_, _maxFloat_) type:JBoShrinkImageTypeWidthAndHeight];
        return size.height;
    }
    else
        return _shareShortMovieDefaultSize_;
}


#pragma mark-JBoImageTextLabel代理

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(shareShortMovieView:didSelectedURL:)])
    {
        [self.delegate shareShortMovieView:self didSelectedURL:url];
    }
}

#pragma mark-JBoShortMovieView代理

- (void)shortMovieViewDidFinishedPlayed:(JBoShortMovieView *)shortMovieView
{
    if([self.delegate respondsToSelector:@selector(shareShortMovieViewDidStopPlayMovie:)])
    {
        [self.delegate shareShortMovieViewDidStopPlayMovie:self];
    }
}

- (void)shortMovieViewWillPlayed:(JBoShortMovieView *)shortMovieView
{
    if([self.delegate respondsToSelector:@selector(shareShortMovieViewWillPlayMovie:)])
    {
        [self.delegate shareShortMovieViewWillPlayMovie:self];
    }
}

- (void)shortMovieViewPrepareToPlay:(JBoShortMovieView *)shortMovieView
{
    if([self.delegate respondsToSelector:@selector(shareShortMovieViewPrepareToPlayMovie:)])
    {
        [self.delegate shareShortMovieViewPrepareToPlayMovie:self];
    }
}

- (void)shortMovieViewFirstImageDidLoad:(JBoShortMovieView *)shortMovieView
{
    if([self.delegate respondsToSelector:@selector(shareShortMovieViewDidLoadFirstImage:)])
    {
        [self.delegate shareShortMovieViewDidLoadFirstImage:self];
    }
}

@end
