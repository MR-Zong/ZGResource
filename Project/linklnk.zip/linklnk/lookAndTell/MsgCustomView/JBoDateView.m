//
//  JBoLookAndTellDateView.m
//  靓咖
//
//  Created by kinghe005 on 14-5-6.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoDateView.h"
#import "JBoDatetimeTool.h"
#import "JBoAttributedLabel.h"
#import <CoreText/CoreText.h>

static NSString *const dateKey = @"date";
static NSString *const yearKey = @"year";
static NSString *const timeKey = @"time";

#define _yearFontName_ @"Baskerville-Bold"
#define _yearFontSize_ 14.0

#define _dateHeight_ 27.0
#define _yearHeight_ 14.0
#define _timeHeight_ 17.0

@interface JBoDateView ()

@property(nonatomic,retain) JBoAttributedLabel *dateLabel;
@property(nonatomic,retain) UILabel *timeLabel;

@property(nonatomic,assign) BOOL currentYear;

@end

@implementation JBoDateView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.dateLabel = [[[JBoAttributedLabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, _dateHeight_)] autorelease];
        self.dateLabel.backgroundColor = [UIColor clearColor];
        self.dateLabel.verticalAlignmentCenter = YES;
        self.dateLabel.horizontalAlignmentCenter = YES;
        [self addSubview:self.dateLabel];
        
        self.timeLabel = [[[UILabel alloc] initWithFrame:CGRectZero] autorelease];
        [self.timeLabel setTextAlign:JBoTextAlignmentRight];
        self.timeLabel.font = [UIFont fontWithName:@"Arial-BoldMT" size:15.0];
        self.timeLabel.textColor = [UIColor grayColor];
        self.timeLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:self.timeLabel];
    }
    return self;
}

- (void)dealloc
{
    [_time release];
    [_dateLabel release];
    [_timeLabel release];
    
    [super dealloc];
}

- (void)setTime:(NSString *)time
{
    if(_time != time)
    {
        [_time release];
        _time = [time retain];
        [self setNeedsLayout];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    for(UIView *view in self.subviews)
    {
        if(![view isEqual:self.timeLabel] && ![view isEqual:self.dateLabel])
        {
            [view removeFromSuperview];
        }
    }

    NSDictionary *timeInfo = [self timeInfo];
    
    self.dateLabel.hidden = NO;
    
    if(!self.currentYear)
    {
        self.dateLabel.attributedText_5 = [timeInfo objectForKey:dateKey];
        UILabel *yearLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, self.dateLabel.bottom, self.bounds.size.width, _yearHeight_)];
        yearLabel.backgroundColor = [UIColor clearColor];
        [yearLabel setTextAlign:JBoTextAlignmentRight];
        yearLabel.text = [timeInfo objectForKey:yearKey];
        yearLabel.font = [UIFont fontWithName:_yearFontName_ size:_yearFontSize_];
        [self addSubview:yearLabel];
        [yearLabel release];
        
        self.timeLabel.frame = CGRectMake(0, yearLabel.bottom, self.bounds.size.width, _timeHeight_);
        self.timeLabel.text = [timeInfo objectForKey:timeKey];
    }
    else if(!self.sameDay)
    {
        self.dateLabel.attributedText_5 = [timeInfo objectForKey:dateKey];
        self.timeLabel.frame = CGRectMake(0, self.dateLabel.bottom, self.bounds.size.width, _timeHeight_);
        self.timeLabel.text = [timeInfo objectForKey:timeKey];
    }
    else
    {
        self.dateLabel.hidden = YES;
        self.timeLabel.frame = CGRectMake(0, 0, self.bounds.size.width, _timeHeight_);
        self.timeLabel.text = [timeInfo objectForKey:timeKey];
    }
    
}

- (NSDictionary*)timeInfo
{
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/BeiJing"]];
    
    NSDate *date = [formatter dateFromString:self.time];
    if(date == nil)
        return nil;
    
    NSArray *array = [self.time componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"- "]];
    if(array.count < 4)
        return nil;
    
    NSString *currentTime = [formatter stringFromDate:[NSDate date]];
    NSArray *currentArray =[currentTime componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"- "]];
    NSString *currentYear = [currentArray firstObject];
    
    
    NSString *year = [array firstObject];
    NSString *month = [array objectAtIndex:1];
    NSString *day = [array objectAtIndex:2];
    day = [NSString stringWithFormat:@"%d",[day intValue]];
    NSString *time = [array objectAtIndex:3];

    self.currentYear = [currentYear isEqualToString:year];
    
    time = [time stringByReplacingOccurrencesOfString:@" " withString:@""];
    if(time.length > 5)
    {
        time = [time substringWithRange:NSMakeRange(0, 5)];
    }
    
    
    month = [JBoDatetimeTool getChineseMonthFormNum:[month integerValue]];
    
    CTFontRef monthFont = CTFontCreateWithName((CFStringRef)@"Arial-BoldMT", 12.0, NULL);//[UIFont fontWithName: size:20.0];
    CTFontRef dayFont = CTFontCreateWithName((CFStringRef)@"Avenir-Black", 20.0, NULL);//[UIFont fontWithName:@"Avenir-Black" size:20.0];
    
    //日期
   // month = @"十一月";
    NSString *dateStr = [NSString stringWithFormat:@"%@%@", day, month];
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:dateStr];
    [attributedText addAttribute:(NSString*)kCTFontAttributeName value:(id)monthFont range:[dateStr rangeOfString:month]];
    [attributedText addAttribute:(NSString*)kCTFontAttributeName value:(id)dayFont range:[dateStr rangeOfString:day]];

    //对齐方式
    CTParagraphStyleSetting alignmentSetting;
    CTTextAlignment textAlignment = kCTRightTextAlignment;
    alignmentSetting.spec = kCTParagraphStyleSpecifierAlignment;
    alignmentSetting.value = &textAlignment;
    alignmentSetting.valueSize = sizeof(CTTextAlignment);
    
    CTParagraphStyleSetting setting[] = {alignmentSetting};
    CTParagraphStyleRef style = CTParagraphStyleCreate(setting, 1);
    
    [attributedText addAttribute:(NSString*)kCTParagraphStyleAttributeName value:(id)style range:NSMakeRange(0, attributedText.length)];
    CFRelease(style);
    
    NSMutableDictionary *info = [[NSMutableDictionary alloc] initWithCapacity:3];
    [info setObject:year forKey:yearKey];
    [info setObject:attributedText forKey:dateKey];
    [info setObject:time forKey:timeKey];
    
   
    [attributedText release];
    CFRelease(monthFont);
    CFRelease(dayFont);
    
    
    return [info autorelease];
}

@end
