//
//  JBoLookAndTellCommentCell.h
//  靓咖
//
//  Created by kinghe005 on 14-7-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoImageTextLabel.h"
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"

#define _lookAndTellCommentContentHeight_ 25
#define _lookAndTellCommentContentInterval_ 10
#define _lookAndTellCommentImageSize_ 30.0
#define _lookAndTellCommentContentTextInset_ 1.0
#define _lookAndTellCommentContentFont_ [UIFont systemFontOfSize:12.0]
#define _lookAndTellCommentContentMinLineHeight_ 17.0

@class JBoLookAndTellCommentCell;

@protocol JBoLookAndTellCommentCellDelegate <NSObject>

/**点击头像
 */
- (void)lookAndTellCommentCellDidTapHeadImage:(JBoLookAndTellCommentCell*) cell;

@end

@interface JBoLookAndTellCommentCell : UITableViewCell

@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;
@property(nonatomic,assign) CGFloat contentHeight;

@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

@property(nonatomic,assign) id<JBoLookAndTellCommentCellDelegate> delegate;

@end
