//
//  JBoUserTableHeaderView.h
//  连你
//
//  Created by kinghe005 on 14-2-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoAsyncImageView.h"

#define _tableHeaderViewHeight_ 130

//表头
@class JBoUserTableHeaderView;

/**用户部分信息表头 代理
 */
@protocol JBoUserTableHeaderViewDelegate <NSObject>

@optional
/**点击头像
 */
- (void)tableHeaderView:(JBoUserTableHeaderView*) tableHeaderView headImageDidTapped:(JBoUserHeadImageView*) headImageView;

/**点击背景图片
 */
- (void)tableHeaderView:(JBoUserTableHeaderView*) tableHeaderView bgImageDidTapped:(UIView*) view;

/**点击左边按钮
 */
- (void)tableHeaderViewDidSelectLeftButton:(JBoUserTableHeaderView*) tableHeaderView;
@end

/**用户部分信息表头
 */
@interface JBoUserTableHeaderView : UIView

/**靓友圈背景图片
 */
@property(nonatomic,readonly) JBoAsyncImageView *bgImageView;

/**用户昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**分割线 default is 'nil'
 */
@property(nonatomic,readonly) UIView *separatorLine;

@property(nonatomic,assign) id<JBoUserTableHeaderViewDelegate> delegate;

/**左边按钮 default is 'nil'
 */
@property(nonatomic,readonly) UIButton *leftButton;

/**添加分割线 默认没有分割线
 */
- (void)addSeparatorLine;

/**添加左边按钮 默认没有标题和图片，13号字体，字体颜色 [UIColor colorWithRed:62.0 / 255.0 green:215.0 / 255.0 blue:21.0 / 255.0 alpha:1.0]
 */
- (void)addLeftButton;

@end
