//
//  JBosceneLookAndTellReleaseView.h
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellReleaseBaseView.h"

@class JBoSceneMakingImageInfo;

@interface JBosceneLookAndTellReleaseView : JBoLookAndTellReleaseBaseView
{
    UINavigationController *_navigationController;
}


@property(nonatomic,assign) UINavigationController *navigationController;

- (id)initWithFrame:(CGRect)frame sceneImageInfo:(JBoSceneMakingImageInfo*) sceneImageInfo conditions:(NSDictionary*) conditions;

- (BOOL)finish;

@end
