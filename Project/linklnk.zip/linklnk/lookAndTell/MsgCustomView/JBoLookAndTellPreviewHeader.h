//
//  JBoLookAndTellPreviewHeader.h
//  靓咖
//
//  Created by kinghe005 on 14-7-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoSceneMakingInfo;

@interface JBoLookAndTellPreviewHeader : UIView

@property(nonatomic,assign) UINavigationController *navigationController;

- (id)initWithFrame:(CGRect)frame info:(JBoSceneMakingInfo *)info;

@end
