//
//  JBoLookAndTellPreviewView.h
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoLookAndTellListInfo;

@interface JBoLookAndTellPreviewView : UIView

@property(nonatomic,retain) UITableView *tableView;

@property(nonatomic,assign) UINavigationController *navigationController;

- (id)initWithFrame:(CGRect)frame lookAndTellInfo:(JBoLookAndTellListInfo*) info;

- (void)reloadData;

@end
