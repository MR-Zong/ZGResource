//
//  JBoCircleBgImageCell.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoCircleBgImageCell.h"
#import "JBoBasic.h"

#define _controlInterval_ 5
#define _controlHeight_ 30



@implementation JBoCircleBgImageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _bgImageView = [[JBoImageView alloc] initWithFrame:CGRectMake(0, _controlInterval_, _width_, _circleBgImageCellHeight_ - _controlInterval_ * 2)];
        [self.contentView addSubview:_bgImageView];
    }
    return self;
}

- (void)dealloc
{
    [_bgImageView release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
