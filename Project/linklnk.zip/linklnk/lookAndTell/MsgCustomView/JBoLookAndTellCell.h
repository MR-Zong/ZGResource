//
//  JBoLookAndTellCell.h
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoMultiImageTextView.h"
#import "JBoShareLinkView.h"
#import "JBoMsgOperationView.h"
#import "JBoShareShortMovieView.h"

#define _lookAndTellcontrolInterval_ 5
#define _lookAndTellcontrolHeight_ 17
#define _headImageSize_ 50
#define _lookAndTellCellNormalHeight_ 60
#define _tableHeaderViewHeight_ 130

typedef enum _JBoLookAndTellCellStyle
{
    JBoLookAndTellCellStyleNone = -1, //什么都没
    JBoLookAndTellCellStyleDefault = 0, //默认
    JBoLookAndTellCellStyleLinkShare = 1, //分享链接
    JBoLookAndTellCellStyleShortMovie = 2 //短视频
}JBoLookAndTellCellStyle;

@class JBoLookAndTellCell;

@protocol JBoLookAndTellCellDelegate <NSObject>

@optional
/**点击缩略图查看大图
 */
- (void)lookAndTellCell:(JBoLookAndTellCell*) cell didSelectedImageAtIndex:(NSInteger) index;
/**点击链接
 */
- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedURL:(NSURL*) url;
/**查看全文
 */
- (void)lookAndTellCellDidSelectedTotalContent:(JBoLookAndTellCell *)cell;

/**查看该条连说的操作的人,如报名人列表
 */
- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedMsgOperationItem:(JBoMsgOperationContentItem*) item;
/**操作该条说说，如点赞，删除
 */
- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedMsgOperationCell:(JBoMsgOperationViewCell*) msgCell;

/**视频预览图片加载完成
 */
- (void)lookAndTellCellMoviePreviewImageDidLoad:(JBoLookAndTellCell*) cell;

/**视频将要播放
 */
- (void)lookAndTellCellWillPlayMovie:(JBoLookAndTellCell *)cell;
/**视频停止播放
 */
- (void)lookAndTellCellDidStopPlayMovie:(JBoLookAndTellCell *)cell;
/**视频准备播放
 */
- (void)lookAndTellCellPrepareToPlayMovie:(JBoLookAndTellCell *)cell;

@end

@interface JBoLookAndTellCell : UITableViewCell<JBoMsgOperationViewDelegate, JBoMultiImageTextViewDelegate, JBoShareLinkViewDelegate, JBoShareShortMovieViewDelegate>

/**操作视图，显示该条说说的可操作类型，操作的数量
 */
@property(nonatomic,readonly) JBoMsgOperationView *msgOperationView;
/**多图文
 */
@property(nonatomic,readonly) JBoMultiImageTextView *multiImageTextView;
/**分享链接
 */
@property(nonatomic,readonly) JBoShareLinkView *linkView;
/**视频
 */
@property(nonatomic,readonly) JBoShareShortMovieView *shareShortMovieView;

@property(nonatomic,assign) id<JBoLookAndTellCellDelegate> delegate;

/**以说说类型初始化
 */
- (id)initWithCellStyle:(JBoLookAndTellCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;

@end
