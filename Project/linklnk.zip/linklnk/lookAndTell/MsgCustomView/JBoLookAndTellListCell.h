//
//  JBoLookAndTellListCell.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoLookAndTellCell.h"

#define _rightPadding_ 22
#define _topPadding_ 20


@class JBoLookAndTellListCell;

@protocol JBoLookAndTellListCellDelegate <NSObject,JBoLookAndTellCellDelegate>

@optional
//选中头像
- (void)lookAndTellListCellHeadImageDidSelected:(JBoLookAndTellListCell *)cell;

@end

@interface JBoLookAndTellListCell : JBoLookAndTellCell

//用户头像 昵称 说说日期
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;
@property(nonatomic,readonly) UILabel *dateLabel;

@property(nonatomic,assign) id<JBoLookAndTellListCellDelegate> delegate;


@end
