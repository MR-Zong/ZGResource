//
//  JBoLookAndTellCell.m
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellCell.h"

@interface JBoLookAndTellCell ()

@property(nonatomic,assign) JBoLookAndTellCellStyle style;


//复制菜单
@property(nonatomic,retain) UIView *overlayView;
@property(nonatomic,copy) NSString *needCopyMsg;
@property(nonatomic,retain) UILabel *copysLabel;

@end

@implementation JBoLookAndTellCell

- (id)initWithCellStyle:(JBoLookAndTellCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentView.backgroundColor = [UIColor whiteColor];
        self.style = style;
        
        CGFloat width = _defaultMultiImageTextViewWidth_;
        switch (style)
        {
            case JBoLookAndTellCellStyleDefault :
            {
                _multiImageTextView = [[JBoMultiImageTextView alloc] initWithFrame:CGRectMake(0, 0, width, 0)];
                _multiImageTextView.delegate = self;
                _multiImageTextView.layoutView = self;
                _multiImageTextView.contentFont = _lookAndTellFont_;
                [self.contentView addSubview:_multiImageTextView];
            }
                break;
            case JBoLookAndTellCellStyleLinkShare :
            {
                _linkView = [[JBoShareLinkView alloc] initWithFrame:CGRectMake(0, 0, width, 0)];
                _linkView.delegate = self;
                _linkView.layoutView = self;
                [self.contentView addSubview:_linkView];
            }
                break;
            case JBoLookAndTellCellStyleShortMovie :
            {
                _shareShortMovieView = [[JBoShareShortMovieView alloc] initWithFrame:CGRectMake(0, 0, width, 0)];
                _shareShortMovieView.delegate = self;
                _shareShortMovieView.layoutView = self;
                [self.contentView addSubview:_shareShortMovieView];
            }
                break;
            default:
                break;
        }
        
        if(self.style != JBoLookAndTellCellStyleNone)
        {
            _msgOperationView = [[JBoMsgOperationView alloc] initWithFrame:CGRectMake(0, 0, width, 20)];
            _msgOperationView.delegate = self;
            [self.contentView addSubview:_msgOperationView];
        }
    }
    return self;
}

- (void)dealloc
{
    [_msgOperationView release];
    [_multiImageTextView release];
    [_linkView release];
    [_shareShortMovieView release];
    
    [_overlayView release];
    [_needCopyMsg release];
    [_copysLabel release];
    
    [super dealloc];
}

#pragma mark-JBoMultiImageTextView代理

- (void)multiImageTextView:(JBoMultiImageTextView *)multiImageTextView didSelectedImageAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedImageAtIndex:)])
    {
        [self.delegate lookAndTellCell:self didSelectedImageAtIndex:index];
    }
}

- (void)multiImageTextView:(JBoMultiImageTextView *)multiImageTextView didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedURL:)])
    {
        [self.delegate lookAndTellCell:self didSelectedURL:url];
    }
}

- (void)multiImageTextViewDidSeletedTotalContent:(JBoMultiImageTextView *)multiImageTextView
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCellDidSelectedTotalContent:)])
    {
        [self.delegate lookAndTellCellDidSelectedTotalContent:self];
    }
}

- (void)multiImageTextView:(JBoMultiImageTextView *)multiImageTextView didLongPressAtLabel:(UILabel *)label atIndex:(NSInteger)index
{
    [self showOverlayView];
    
    NSString *str = label.text;
    self.copysLabel = label;
    self.copysLabel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];

    if(index == 0)
    {
        if(str.length > 1)
        {
            NSString *sub = [str substringWithRange:NSMakeRange(0, 1)];
            if([sub isEqualToString:@" "])
            {
                str = [str substringFromIndex:1];
            }
        }
        NSRange range = [str rangeOfString:_lookAndTellLovingIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellLovingIcon_ withString:@""];
        }
        
        range = [str rangeOfString:_lookAndTellBusinessIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellBusinessIcon_ withString:@""];
        }
        
        range = [str rangeOfString:_lookAndTellTransmitIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellTransmitIcon_ withString:@""];
        }
        
        range = [str rangeOfString:_lookAndTellLifeIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellLifeIcon_ withString:@""];
        }
        
        range = [str rangeOfString:_lookAndTellLaysPrimaryIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellLaysPrimaryIcon_ withString:@""];
        }
        
        range = [str rangeOfString:_lookAndTellLaysCheckIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellLaysCheckIcon_ withString:@""];
        }
        
        range = [str rangeOfString:_lookAndTellLaysRunoffIcon_];
        if(range.length > 0)
        {
            str = [str stringByReplacingOccurrencesOfString:_lookAndTellLaysRunoffIcon_ withString:@""];
        }
    }
    
    self.needCopyMsg = str;
    
    NSMutableArray *itemArray = [NSMutableArray array];
    
    UIMenuItem *copy = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyMsg:)];
    [itemArray addObject:copy];
    [copy release];
    
    
    [self becomeFirstResponder];
    
    CGRect rect = CGRectMake(label.left, self.top + label.top + multiImageTextView.top, label.width, label.height);
    UIMenuController *menu = [UIMenuController sharedMenuController];
    [menu setMenuItems:itemArray];
    [menu setTargetRect:rect inView:self.superview];
    [menu setMenuVisible:YES animated:YES];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(menuWillDismiss:) name:UIMenuControllerWillHideMenuNotification object:nil];
}

#pragma mark- 复制菜单

- (void)showOverlayView
{
    if(!self.overlayView)
    {
        self.overlayView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
        self.overlayView.backgroundColor = [UIColor clearColor];
        
        UITapGestureRecognizer *dismissMenuTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissMenu:)];
        [self.overlayView addGestureRecognizer:dismissMenuTap];
        [dismissMenuTap release];
    }
    
    UIView *view = nil;
    
    if([self.delegate isKindOfClass:[UIView class]])
    {
        view = (UIView*)self.delegate;
    }
    else if([self.delegate isKindOfClass:[UIViewController class]])
    {
        view = [(UIViewController*)self.delegate view];
    }

    [view addSubview:self.overlayView];
}

- (void)dismissMenu:(UITapGestureRecognizer*) tap
{
    [self resignFirstResponder];
}

- (void)menuWillDismiss:(NSNotification*) notification
{
    [self.overlayView removeFromSuperview];
    self.overlayView = nil;
    self.needCopyMsg = nil;
    self.copysLabel.backgroundColor = [UIColor clearColor];
    self.copysLabel = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIMenuControllerWillHideMenuNotification object:nil];
}

- (void)copyMsg:(id) sender
{
    if([NSString isEmpty:self.needCopyMsg])
    {
        self.needCopyMsg = @" ";
    }
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = self.needCopyMsg;
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if(action == @selector(copyMsg:))
    {
        return YES;
    }
    return NO;
}

#pragma mark-JBoMsgOperationView代理

- (void)msgOperationView:(JBoMsgOperationView *)view didSelectedAtCell:(JBoMsgOperationViewCell *)cell
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedMsgOperationCell:)])
    {
        [self.delegate lookAndTellCell:self didSelectedMsgOperationCell:cell];
    }
}

- (void)msgOperationView:(JBoMsgOperationView *)view didSelectedAtItem:(JBoMsgOperationContentItem *)item
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedMsgOperationItem:)])
    {
        [self.delegate lookAndTellCell:self didSelectedMsgOperationItem:item];
    }
}

#pragma mark-JBoShareLinkView代理

- (void)shareLinkView:(JBoShareLinkView *)linkView didSelectedImageAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedImageAtIndex:)])
    {
        [self.delegate lookAndTellCell:self didSelectedImageAtIndex:index];
    }
}

- (void)shareLinkView:(JBoShareLinkView *)linkView didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedURL:)])
    {
        [self.delegate lookAndTellCell:self didSelectedURL:url];
    }
}

#pragma mark-shortMovieView代理

- (void)shareShortMovieView:(JBoShareShortMovieView *)view didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCell:didSelectedURL:)])
    {
        [self.delegate lookAndTellCell:self didSelectedURL:url];
    }
}

- (void)shareShortMovieViewDidStopPlayMovie:(JBoShareShortMovieView *)view
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCellDidStopPlayMovie:)])
    {
        [self.delegate lookAndTellCellDidStopPlayMovie:self];
    }
}

- (void)shareShortMovieViewWillPlayMovie:(JBoShareShortMovieView *)view
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCellWillPlayMovie:)])
    {
        [self.delegate lookAndTellCellWillPlayMovie:self];
    }
}

- (void)shareShortMovieViewPrepareToPlayMovie:(JBoShareShortMovieView *)view
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCellPrepareToPlayMovie:)])
    {
        [self.delegate lookAndTellCellPrepareToPlayMovie:self];
    }
}

- (void)shareShortMovieViewDidLoadFirstImage:(JBoShareShortMovieView *)view
{
    if([self.delegate respondsToSelector:@selector(lookAndTellCellMoviePreviewImageDidLoad:)])
    {
        [self.delegate lookAndTellCellMoviePreviewImageDidLoad:self];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
