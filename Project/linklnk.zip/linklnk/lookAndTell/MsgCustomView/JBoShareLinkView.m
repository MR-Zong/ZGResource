//
//  JBoShareLinkView.m
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoShareLinkView.h"
#import "JBoBasic.h"
#import "JBoMultiImageTextView.h"
#import "NSString+customString.h"
#import "JBoImageTextTool.h"

#define _thumbnail_ @"thumbnail"

@implementation JBoShareLinkView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        UILabel *idLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, 20.0)];
        idLabel.textColor = [UIColor grayColor];
        idLabel.text = @"分享了一个链接";
        idLabel.font = [UIFont systemFontOfSize:13.0];
        idLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:idLabel];
        [idLabel release];
        
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(0, idLabel.frame.size.height, frame.size.width, 0)];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.delegate = self;
        _contentLabel.font = _lookAndTellFont_;
        _contentLabel.textInset = _defaultMultiImageTextInset_;
        _contentLabel.minLineHeight = _defaultMultiImageTextLineHeight_;
        _contentLabel.wordInset = _defaultMultiImageTextWordInset_;
        [self addSubview:_contentLabel];
        
        _shareView = [[JBoLinkShareView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, _multiSize_)];
        [_shareView addTarget:self singleTapAction:@selector(shareURLDidSelected:)];
//        _shareView.layer.cornerRadius = 6;
//        _shareView.layer.masksToBounds = YES;
//        _shareView.backgroundColor = [UIColor whiteColor];
        [self addSubview:_shareView];
        
        UITapGestureRecognizer *imageTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTap:)];
        [self.shareView.htmlImageView addGestureRecognizer:imageTap];
        [imageTap release];
    }
    return self;
}

- (void)dealloc
{
    [_shareURL release];
    [_srcArray release];
    [_shareView release];
    [_contentLabel release];
    
    self.delegate = nil;
    self.layoutView = nil;
    
    [super dealloc];
}

- (void)setSrcArray:(NSArray *)srcArray
{
    if(_srcArray != srcArray)
    {
        [_srcArray release];
        _srcArray = [srcArray retain];
        [self setNeedsLayout];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    for(NSInteger i = 0;i < _srcArray.count;i ++)
    {
        JBoMultiImageText *info = [_srcArray objectAtIndex:i];
        
        _contentLabel.frame = CGRectMake(0, _contentLabel.frame.origin.y, self.bounds.size.width, info.titleHeight + _contentLabel.textInset * 2);
        _contentLabel.text = info.content;
        
        NSString *url = [info.imageURLArray firstObject];
        [self reloadImageWithURL:url];
    }
    
    _shareView.frame = CGRectMake(0, _contentLabel.frame.origin.y + _contentLabel.frame.size.height + _multiImageInterval_, self.bounds.size.width, _shareView.frame.size.height);
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, _shareView.frame.origin.y + _shareView.frame.size.height + _multiImageInterval_);
    
    [self.layoutView setNeedsLayout];
}

- (void)reloadImageWithURL:(NSString *)url
{
    if([NSString isEmpty:url])
        return;
 
    [_shareView.htmlImageView getImageWithURL:url];
}

#pragma mark-private method

- (void)imageTap:(UITapGestureRecognizer*) tap
{
//    if([self.delegate respondsToSelector:@selector(shareLinkView:didSelectedImageAtIndex:)])
//    {
//        [self.delegate shareLinkView:self didSelectedImageAtIndex:0];
//    }
    
    if([self.delegate respondsToSelector:@selector(shareLinkView:didSelectedURL:)])
    {
        [self.delegate shareLinkView:self didSelectedURL:[NSURL URLWithString:self.shareURL]];
    }
}

- (void)shareURLDidSelected:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(shareLinkView:didSelectedURL:)])
    {
        [self.delegate shareLinkView:self didSelectedURL:[NSURL URLWithString:self.shareURL]];
    }
}

#pragma mark-JBoImageTextLabel代理

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(shareLinkView:didSelectedURL:)])
    {
        [self.delegate shareLinkView:self didSelectedURL:url];
    }
}

@end
