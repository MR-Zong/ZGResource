//
//  JBoCircleBgImageCell.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoImageView.h"

#define _circleBgImageHeaderHeight_ 40
#define _circleBgImageCellHeight_ 110


@interface JBoCircleBgImageHeader : UIView

@end

@interface JBoCircleBgImageCell : UITableViewCell

@property(nonatomic,readonly) JBoImageView *bgImageView;

@end
