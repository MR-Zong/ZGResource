//
//  JBoShareLinkView.h
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoImageTextLabel.h"
#import "JBoLinkShareView.h"

#define _sharelinkDefaultHeight_ 85.0

@class JBoShareLinkView;

@protocol JBoShareLinkViewDelegate <NSObject>

@optional
- (void)shareLinkView:(JBoShareLinkView*) linkView didSelectedImageAtIndex:(NSInteger) index;
- (void)shareLinkView:(JBoShareLinkView *)linkView didSelectedURL:(NSURL*) url;

@end

@interface JBoShareLinkView : UIView<JBoImageTextLabelDelegate>

@property(nonatomic,copy) NSString *shareURL;
@property(nonatomic,readonly) JBoLinkShareView *shareView;
@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;

@property(nonatomic,retain) NSArray *srcArray;
@property(nonatomic,assign) UIView *layoutView;

@property(nonatomic,assign) id<JBoShareLinkViewDelegate> delegate;

- (void)reloadImageWithURL:(NSString*) url;

@end
