//
//  JBoUserLookAndTellCell.m
//  连你
//
//  Created by kinghe005 on 14-2-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserLookAndTellCell.h"
#import "JBoBasic.h"
#import "JBoImageTextTool.h"

#define _rightPadding_ 5
#define _topPadding_ 10

#define _iconInterval_ 5
#define _iconSize_ 15.0

@interface JBoUserLookAndTellCell ()

@property(nonatomic,assign) JBoLookAndTellCellStyle style;

@end

@implementation JBoUserLookAndTellCell

@synthesize delegate;

- (id)initWithCellStyle:(JBoLookAndTellCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithCellStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {

        self.contentView.backgroundColor = [UIColor whiteColor];
        self.style = style;
        
        _dateView = [[JBoDateView alloc] initWithFrame:CGRectMake(_rightPadding_, _innerPadding_, _dateLabelWidth_, _lookAndTellDateViewDefaultHeight_)];
        _dateView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_dateView];
     
        
        self.multiImageTextView.frame = CGRectMake(_dateView.frame.origin.x + _dateView.frame.size.width + _lookAndTellcontrolInterval_ * 2, _dateView.frame.origin.y + 3.0, self.multiImageTextView.frame.size.width, 0);
        
        self.linkView.frame = CGRectMake(_dateView.frame.origin.x + _dateView.frame.size.width + _lookAndTellcontrolInterval_ * 2, _dateView.frame.origin.y + 3.0, self.linkView.frame.size.width, 0);
        
        self.shareShortMovieView.frame = CGRectMake(_dateView.frame.origin.x + _dateView.frame.size.width + _lookAndTellcontrolInterval_ * 2, _dateView.frame.origin.y + 3.0, self.shareShortMovieView.frame.size.width, 0);
        
        self.msgOperationView.frame = CGRectMake(_dateView.frame.origin.x + _dateView.frame.size.width + _lookAndTellcontrolInterval_ * 2, _dateView.frame.origin.y + 3.0, self.msgOperationView.frame.size.width, 0);
        
        
        _statusImageLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.msgOperationView.frame.origin.x, 0, self.msgOperationView.frame.size.width, 25)];
        _statusImageLabel.textColor = [UIColor grayColor];
        [_statusImageLabel setTextAlign:JBoTextAlignmentRight];
        
        _statusImageLabel.font = [UIFont systemFontOfSize:10.0];
        [self.contentView addSubview:_statusImageLabel];
        _statusImageLabel.hidden = YES;
    }
    return self;
}


- (void)setStatus:(NSInteger)status
{
    _status = status;

    switch (_status)
    {
        case 0 :
            _statusImageLabel.hidden = YES;
            break;
        case 1 :
            _statusImageLabel.hidden = NO;
            _statusImageLabel.text = @"等待审核";
            break;
        case 2 :
            _statusImageLabel.hidden = NO;
            _statusImageLabel.text = @"申请被拒绝";
            break;
        default:
            _statusImageLabel.hidden = YES;
            break;
    }
}


- (void)layoutSubviews
{
    [super layoutSubviews];

    CGFloat y = 0;
    switch (self.style)
    {
        case JBoLookAndTellCellStyleDefault:
            y = self.multiImageTextView.frame.origin.y + self.multiImageTextView.frame.size.height;
            break;
        case JBoLookAndTellCellStyleLinkShare :
            y = self.linkView.frame.origin.y + self.linkView.frame.size.height;
            break;
        case JBoLookAndTellCellStyleShortMovie :
            y = self.shareShortMovieView.frame.origin.y + self.shareShortMovieView.frame.size.height;
            break;
        default:
            break;
    }
    
    _statusImageLabel.frame = CGRectMake(_statusImageLabel.frame.origin.x, y, _statusImageLabel.frame.size.width, _statusImageLabel.frame.size.height);
    CGFloat msgY = _statusImageLabel.hidden ? y : _statusImageLabel.frame.size.height + _statusImageLabel.frame.origin.y;
    
     self.msgOperationView.frame = CGRectMake(self.msgOperationView.frame.origin.x, msgY, self.msgOperationView.frame.size.width, self.msgOperationView.frame.size.height);
}

- (void)dealloc
{
    [_dateView release];
    [_statusImageLabel release];
    
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
