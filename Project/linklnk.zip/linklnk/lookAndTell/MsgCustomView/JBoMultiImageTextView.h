//
//  JBoMultiImageTextCell.h
//  连你
//
//  Created by kinghe005 on 14-3-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoMultiImageView.h"
#import "JBoImageTextLabel.h"
#import "JBoMultiImageTextInfo.h"


#define _defaultMultiImageTextViewWidth_  _multiSize_ * _imagesPerRows_ + _multiImageInterval_ * (_imagesPerRows_ - 1)
#define _defaultMultiImageTextInset_ 1.0
#define _defaultMultiImageTextLineHeight_ 20.0
#define _defaultMultiImageTextWordInset_ 1.0
#define _defaultMultiImageTextButton_ 30.0

@class JBoMultiImageTextView;

@protocol JBoMultiImageTextViewDelegate <NSObject>

@optional
- (void)multiImageTextView:(JBoMultiImageTextView*) multiImageTextView didSelectedImageAtIndex:(NSInteger) index;
- (void)multiImageTextView:(JBoMultiImageTextView *)multiImageTextView didSelectedURL:(NSURL*) url;
- (void)multiImageTextViewDidSeletedTotalContent:(JBoMultiImageTextView *)multiImageTextView;

/**长按
 */
- (void)multiImageTextView:(JBoMultiImageTextView*) multiImageTextView didLongPressAtLabel:(UILabel*) label atIndex:(NSInteger) index;

@end

/**靓友圈缩略图相框 和文本
 */
@interface JBoMultiImageTextView : UIView


@property(nonatomic,assign) BOOL onluThumbnail;
@property(nonatomic,readonly) JBoMultiImageView *multiImageView;
@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;

@property(nonatomic,assign) BOOL hasMoreText;

@property(nonatomic,retain) NSArray *srcArray;
@property(nonatomic,retain) UIFont *contentFont;
@property(nonatomic,assign) UIView *layoutView;

@property(nonatomic,assign) id<JBoMultiImageTextViewDelegate> delegate;

- (void)reloadRow:(NSInteger) row atIndex:(NSInteger) index withURL:(NSString*) url;

/**通过给的图片显示
 */
- (void)reloadRow:(NSInteger) row withImages:(NSArray*) images;


@end
