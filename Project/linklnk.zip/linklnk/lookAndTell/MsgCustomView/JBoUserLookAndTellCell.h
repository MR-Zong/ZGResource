//
//  JBoUserLookAndTellCell.h
//  连你
//
//  Created by kinghe005 on 14-2-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoMultiImageView.h"
#import "JBoChatMsgLabel.h"
#import "JBoMultiImageTextView.h"
#import "JBoMsgOperationView.h"
#import "JBoLookAndTellCell.h"
#import "JBoDateView.h"

#define _dateLabelWidth_ 60
#define _dateLabelHeight_ 19.0
#define _innerPadding_ 15.0

#define _userLookAndTellCellMinHeight_ (_dateLabelHeight_ * 3 + _innerPadding_ * 2)

@class JBoUserLookAndTellCell;

@protocol JBoUserLookAndTellCellDelegate <NSObject,JBoLookAndTellCellDelegate>


@end

@interface JBoUserLookAndTellCell : JBoLookAndTellCell

//说说日期
@property(nonatomic,readonly) JBoDateView *dateView;

//代言标志
@property(nonatomic,assign) NSInteger status;
@property(nonatomic,readonly) UILabel *statusImageLabel;

@property(nonatomic,assign) id<JBoUserLookAndTellCellDelegate> delegate;

@end
