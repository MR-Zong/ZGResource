//
//  JBoMultiImageView.m
//  连你
//
//  Created by kinghe005 on 14-2-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMultiImageView.h"
#import "JBoImageTextTool.h"
#import "JBoBasic.h"
#import "JBoImageCacheTool.h"
#import <QuartzCore/QuartzCore.h>

#define _thumbnail_ @"thumbnail"
#define _controlInterval_ 5
#define _startTag_ 1000

#define _orgImage_ @"orgImage"
#define _needSize_ @"needSize"
#define _orgCell_ @"cell"
#define _reload_ @"reload"
#define _thumbnail_ @"thumbnail"

@implementation JBoMultiImageViewCellLogo

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        _logoStyle = JBoMultiImageViewCellLogoStyleNone;
    }
    return self;
}

- (void)setLogoStyle:(JBoMultiImageViewCellLogoStyle)logoStyle
{
    if(_logoStyle != logoStyle)
    {
        _logoStyle = logoStyle;
        switch (self.logoStyle)
        {
            case JBoMultiImageViewCellLogoStyleNone :
            {
                self.image = nil;
            }
                break;
            case JBoMultiImageViewCellLogoStyleURL :
            {
                self.image = [UIImage imageNamed:@"cloundURL_icon"];
            }
                break;
            default:
                break;
        }
    }
}


@end

@implementation JBoMultiImageViewCell

- (id)initWithFrame:(CGRect)frame target:(id)target action:(SEL)selector
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:target action:selector];
        [self addGestureRecognizer:tap];
        [tap release];
        
        CGFloat size = 30.0;
        _logo = [[JBoMultiImageViewCellLogo alloc] initWithFrame:CGRectMake(0, 0, size, size)];
        [self addSubview:_logo];
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    _indexLabel.center = CGPointMake(self.width - _indexLabel.width / 2.0, self.height - _indexLabel.height / 2.0);
}

- (void)setShowIndex:(BOOL)showIndex
{
    if(_showIndex != showIndex)
    {
        _showIndex = showIndex;
        if(_showIndex)
        {
            if(!self.indexLabel)
            {
                CGFloat size = 20.0;
                _indexLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.width - size, self.height - size, size, size)];
                _indexLabel.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
                _indexLabel.textColor = [UIColor whiteColor];
                _indexLabel.font = [UIFont systemFontOfSize:13.0];
                _indexLabel.textAlign = JBoTextAlignmentCenter;
                [self addSubview:_indexLabel];
            }
            
            self.indexLabel.hidden = NO;
        }
        else
        {
            self.indexLabel.hidden = YES;
        }
    }
}

- (void)dealloc
{
    [_indexLabel release];
    [_logo release];
    [super dealloc];
}

@end

@interface JBoMultiImageView ()<JBoImageViewDelegate>

@end

@implementation JBoMultiImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        self.enableLongPressGesture = NO;
        self.imageCountPerRow = _imagesPerRows_;
        self.beginIndex = 1;
        self.showIndex = NO;
        self.thumbnailSize = _multiSize_;
    }
    return self;
}

- (void)dealloc
{
    [_images release];
    [super dealloc];
}

#pragma mark- public method

- (void)reloadCellAtIndex:(NSInteger)index withURL:(NSString *)url
{
    JBoMultiImageViewCell *cell = (JBoMultiImageViewCell*)[self viewWithTag:_startTag_ + index];
    
    if(!cell)
    {
        NSLog(@"空的cell");
        return;
    }
    
    if(_images.count == 1 && !self.onlythumbnail)
    {
        cell.frame = [self getFrameFromURL:url];
    }
    
    [cell getImageWithURL:url];
}

/**设置cell的logo
 *@param logoStyle 图片logo类型
 */
- (void)setupCellLogoStyle:(JBoMultiImageViewCellLogoStyle) logoStyle atIndex:(NSInteger)index
{
    JBoMultiImageViewCell *cell = (JBoMultiImageViewCell*)[self viewWithTag:_startTag_ + index];
    cell.logo.logoStyle = logoStyle;
}

- (void)reloadWithImages:(NSArray*) images
{
    for(NSInteger i = 0;i < images.count;i ++)
    {
        JBoMultiImageViewCell *cell = (JBoMultiImageViewCell*)[self viewWithTag:_startTag_ + i];
        
        if(cell.image)
            return;
        
        UIImage *image = [images objectAtIndex:i];
        UIImage *subImage = [JBoImageTextTool getSubImageFromImage:image withSize:cell.frame.size];
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:subImage withSize:cell.frame.size];
        
        cell.image = thumbnail;
    }
}

- (void)setImages:(NSArray *)images
{
    if(_images != images)
    {
        [_images release];
        _images = [images retain];
        [self reloadData];
        self.hidden = _images.count == 0;
    }
}

- (void)reloadData
{
    CGFloat height = 0;
    if(self.onlythumbnail)
    {
        height = [JBoMultiImageView getThumbnailHeightWithCount:self.images.count imageCountPerRow:self.imageCountPerRow];
    }
    else
    {
        height = [JBoMultiImageView getHeightWithCount:self.images.count imageCountPerRow:self.imageCountPerRow];
    }
    self.height = height;
    
    
    [self setNeedsLayout];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    for(UIView *view in self.subviews)
    {
        [view removeFromSuperview];
    }
    
    if(self.images.count == 0)
    {
        self.frame = CGRectZero;
    }
    else if(self.images.count == 1 && !self.onlythumbnail)
    {
        CGRect frame = [self getFrameFromURL:[self.images firstObject]];
        
        JBoMultiImageViewCell *cell = [[JBoMultiImageViewCell alloc] initWithFrame:frame target:self action:@selector(cellDidSelected:)];
        if(!self.onlythumbnail)
        {
            cell.delegate = self;
        }
        if(_enableLongPressGesture)
        {
            UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(cellDidLongPress:)];
            [cell addGestureRecognizer:longPress];
            [longPress release];
        }
        
        id obj = [self.images firstObject];
        
        if([obj isKindOfClass:[UIImage class]])
        {
            NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:obj, _orgImage_, [NSValue valueWithCGSize:cell.frame.size], _needSize_ , cell, _orgCell_, nil];
            [self getThumbnailFromDic:userInfo];
        }
        else if([obj isKindOfClass:[NSString class]])
        {
            [cell getImageWithURL:obj];
        }
        
        cell.index = 0;
        cell.showIndex = self.showIndex;
        if(self.showIndex)
        {
            cell.indexLabel.text = [NSString stringWithFormat:@"%d", self.beginIndex];
        }
        
        
        cell.tag = _startTag_;
        [self addSubview:cell];
        [cell release];
    }
    else
    {
        NSInteger rows = 0;
        NSInteger columns = 0;
        for(int i = 0;i < self.images.count;i ++)
        {
            if(i % _imageCountPerRow == 0)
            {
                rows ++;
                columns = 0;
            }
            
            CGRect frame = CGRectMake(columns * (_thumbnailSize + _controlInterval_), (rows - 1) * (_thumbnailSize + _controlInterval_), _thumbnailSize, _thumbnailSize);
            JBoMultiImageViewCell *cell = [[JBoMultiImageViewCell alloc] initWithFrame:frame target:self action:@selector(cellDidSelected:)];
            
            if(_enableLongPressGesture)
            {
                UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(cellDidLongPress:)];
                [cell addGestureRecognizer:longPress];
                [longPress release];
            }
            
            id obj = [self.images objectAtIndex:i];
            
            if([obj isKindOfClass:[UIImage class]])
            {
                NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:obj, _orgImage_, [NSValue valueWithCGSize:cell.frame.size], _needSize_ , cell, _orgCell_, nil];
                [self getThumbnailFromDic:userInfo];
            }
            else if([obj isKindOfClass:[NSString class]])
            {
                [cell getImageWithURL:obj];
            }
            
            cell.index = i;
            cell.showIndex = self.showIndex;
            if(self.showIndex)
            {
                cell.indexLabel.text = [NSString stringWithFormat:@"%d", self.beginIndex + i];
            }
            
            cell.tag = _startTag_ + i;
            [self addSubview:cell];
            [cell release];
            columns ++;
        }
    }
}

- (void)getThumbnailFromDic:(NSDictionary*) dic
{
    UIImage *image = [dic objectForKey:_orgImage_];
 
    if([image isKindOfClass:[UIImage class]])
    {
        CGSize size = [[dic objectForKey:_needSize_] CGSizeValue];
        JBoMultiImageViewCell *cell = [dic objectForKey:_orgCell_];
        
        UIImage *subImage = [JBoImageTextTool getSubImageFromImage:image withSize:size];
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:subImage withSize:size];
        cell.image = thumbnail;
    }
}

- (CGRect)getFrameFromURL:(NSString*) url
{
    CGRect frame;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *image = [cache imageForURL:url thumbnailSize:CGSizeZero];
    
    if(image.size.width == image.size.height)
    {
        frame = CGRectMake(0, 0, _singleSquareSize_, _singleSquareSize_);
    }
    else
    {
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_singleRectangleWidth_, _singleRectangleHeight_) type:JBoShrinkImageTypeWidthAndHeight];
        frame = CGRectMake(0, 0, size.width, size.height);
    }
    return frame;
}

#pragma mark- cell operation

- (void)cellDidSelected:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(multiImageView:didSelectedAtIndex:)])
    {
        JBoMultiImageViewCell *cell = (JBoMultiImageViewCell*)tap.view;
        if(cell.image == nil)
            return;
        [self.delegate multiImageView:self didSelectedAtIndex:cell.index];
    }
}

- (void)cellDidLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        if([self.delegate respondsToSelector:@selector(multiImageView:didLongPressedAtIndex:)])
        {
            JBoMultiImageViewCell *cell = (JBoMultiImageViewCell*)longPress.view;
            if(cell.image == nil)
                return;
            [self.delegate multiImageView:self didLongPressedAtIndex:cell.index];
        }
    }
}

#pragma mark- JBoImageView delegate

- (void)imageView:(JBoImageView *)imageView didFinishLoadImage:(UIImage *)image
{
    CGSize size = [JBoImageTextTool shrinkImage:image WithSize:imageView.thumbnailSize type:JBoShrinkImageTypeWidthAndHeight];
    CGRect frame = imageView.frame;
    frame.size = size;
    imageView.frame = frame;
}

#pragma mark- class method

/**通过图片数量获取视图高度
 *@param count 图片数量
 */
+ (CGFloat)getHeightWithCount:(NSInteger)count
{
    if(count == 0)
    {
        return 0;
    }
    else if(count == 1)
    {
        return _singleSquareSize_;
    }
    else
    {
        NSInteger rows = ((count - 1) / _imagesPerRows_ + 1);
        return rows * _multiSize_ + (rows - 1) * _controlInterval_;
    }
}

/**通过图片总数量和每行图片数量获取视图高度
 *@param count 图片总数量
 *@param imageCountPerRow 每行图片数量
 *@return 总的图片高度
 */
+ (CGFloat)getHeightWithCount:(NSInteger) count imageCountPerRow:(NSInteger) imageCountPerRow
{
    if(count == 0)
    {
        return 0;
    }
    else if(count == 1)
    {
        return _singleSquareSize_;
    }
    else
    {
        NSInteger rows = ((count - 1) / imageCountPerRow + 1);
        return rows * _multiSize_ + (rows - 1) * _controlInterval_;
    }
}

/**通过图片数量获取视图高度,这时所有图片的显示方式都是正方形的缩略图
 *@param count 图片数量
 */
+ (CGFloat)getThumbnailHeightWithCount:(NSInteger)count
{
    if(count == 0)
    {
        return 0;
    }
    else
    {
        NSInteger rows = ((count - 1) / _imagesPerRows_ + 1);
        return rows * _multiSize_ + (rows - 1) * _controlInterval_;
    }
}

/**通过图片总数量和每行图片数量获取视图高度 这时所有图片的显示方式都是正方形的缩略图
 *@param count 图片总数量
 *@param imageCountPerRow 每行图片数量
 *@return 总的图片高度
 */
+ (CGFloat)getThumbnailHeightWithCount:(NSInteger) count imageCountPerRow:(NSInteger) imageCountPerRow
{
    if(count == 0)
    {
        return 0;
    }
    else
    {
        NSInteger rows = ((count - 1) / imageCountPerRow + 1);
        return rows * _multiSize_ + (rows - 1) * _controlInterval_;
    }
}

@end
