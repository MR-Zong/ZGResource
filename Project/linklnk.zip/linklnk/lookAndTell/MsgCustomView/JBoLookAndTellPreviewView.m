//
//  JBoLookAndTellPreviewView.m
//  靓咖
//
//  Created by kinghe005 on 14-6-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellPreviewView.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoLookAndTellListCell.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoReuseScrollView.h"
#import "JBoReuseScrollInfo.h"
#import "JBoWebViewController.h"

@interface JBoLookAndTellPreviewView ()<UITableViewDataSource, UITableViewDelegate, JBoLookAndTellListCellDelegate, JBoReuseScrollViewDelegate>
{
    JBoAppDelegate *_appDelegate;
    
}

@property(nonatomic,retain) JBoLookAndTellListInfo *info;


//图片预览
@property(nonatomic,retain) NSMutableArray *imageURLArray;
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;

@end

@implementation JBoLookAndTellPreviewView

- (id)initWithFrame:(CGRect)frame lookAndTellInfo:(JBoLookAndTellListInfo *)info
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        self.info = info;
        
        
        
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) style:UITableViewStylePlain];
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self addSubview:tableView];
        self.tableView = tableView;
        [tableView release];
    }
    return self;
}


#pragma mark- 内存管理

- (void)dealloc
{
    [_info release];
    [_tableView release];
    
    [_imageURLArray release];
    [_imageScrollView release];
    
    [super dealloc];
}


#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = self.info;
    
    [info getContentHeightWithContraintWidth:_defaultMultiImageTextViewWidth_ - _defaultMultiImageTextInset_ * 2 showMultiImageText:NO];
    
    CGFloat height = _headImageSize_ + _topPadding_ + info.contentHeight;
  
    height += [JBoMsgOperationView getHeightWithStyle:info.operationInfo.style canComplaint:YES needImageText:info.needImageText];
    
    height += [info getMsgOperationHeightWithCommentCount:_lookAndTellShowCommentCount_] + _msgOperationPadding_;
    
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = self.info;
    
    static NSString *defaultIdentifier = @"default";
    static NSString *shareLinkIdentifier = @"shareLink";
    static NSString *shortMovieIdentifier = @"shortMovie";
    
    NSString *cellIdentifier = defaultIdentifier;
    JBoLookAndTellCellStyle style = JBoLookAndTellCellStyleDefault;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cellIdentifier = shareLinkIdentifier;
            style = JBoLookAndTellCellStyleLinkShare;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cellIdentifier = shortMovieIdentifier;
            style = JBoLookAndTellCellStyleShortMovie;
        }
            break;
        default:
            break;
    }

    JBoLookAndTellListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoLookAndTellListCell alloc] initWithCellStyle:style reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.msgOperationView.canComplaint = YES;
    }
    
    
    cell.msgOperationView.info = info;
    cell.msgOperationView.style = info.operationInfo.style;
    
    cell.msgOperationView.index = indexPath.row;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cell.linkView.shareView.htmlTitleLabel.text = info.urlTitle;
            cell.linkView.shareURL = info.url;
            cell.linkView.srcArray = info.multiInfo;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cell.shareShortMovieView.srcArray = info.multiInfo;
        }
            break;
        default:
        {
            cell.multiImageTextView.hasMoreText = info.hasMoreText;
            cell.multiImageTextView.srcArray = info.multiInfo;
        }
            break;
    }
    
    cell.nameLabel.text = info.userName;
    cell.nameLabel.sex = info.sex;
    cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.date];
    cell.headImageView.sex = info.sex;
    cell.headImageView.role = info.role;
    
    JBoUserDetailInfo *userInfo = [JBoUserOperation getUserDetailInfo];
    if(userInfo.rosterInfo.image)
    {
        cell.headImageView.imageView.image = userInfo.rosterInfo.image;
    }
    
    if(!tableView.dragging && !tableView.decelerating)
    {
        [self dowloadImageForIndexPath:indexPath];
    }
    
    return cell;
}

- (void)reloadData
{
    NSArray *indexPaths = [_tableView indexPathsForVisibleRows];
    
    for(NSIndexPath *indexPath in indexPaths)
    {
        [self dowloadImageForIndexPath:indexPath];
    }
}

- (void)dowloadImageForIndexPath:(NSIndexPath*) indexPath
{
    JBoLookAndTellListCell *cell1 = (JBoLookAndTellListCell*)[_tableView cellForRowAtIndexPath:indexPath];
    for(NSInteger i = 0;i < self.info.multiInfo.count;i ++ )
    {
        JBoMultiImageText *text  = [self.info.multiInfo objectAtIndex:i];
        [cell1.multiImageTextView reloadRow:i withImages:text.imageURLArray];
    }
}


#pragma mark- cell代理

- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedImageAtIndex:(NSInteger)index
{
    NSInteger currentIndex = index;
    
    NSMutableArray *urlArray = [[NSMutableArray alloc] init];
    
    JBoLookAndTellListInfo *info = self.info;
    
    NSInteger count = 0;
    for(JBoMultiImageText *text in info.multiInfo)
    {
        CGFloat titleHeight = [JBoReuseScrollInfo getHeightWithContent:text.content];
        
        for(UIImage *image in text.imageURLArray)
        {
            JBoReuseScrollInfo *bigInfo = [[JBoReuseScrollInfo alloc] init];
            bigInfo.msgId = text.msgId;
            bigInfo.title = text.content;
            bigInfo.titleHeight = titleHeight;
            bigInfo.image = image;
            
            [urlArray addObject:bigInfo];
            [bigInfo release];
        }
        count += text.imageURLArray.count;
    }
    
    self.imageURLArray = urlArray;
    [urlArray release];
    
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = currentIndex;
    [self.imageScrollView reloadData];
    
    [self.imageScrollView showInViewController:self.navigationController];
}


- (void)lookAndTellCell:(JBoLookAndTellCell *)cell didSelectedURL:(NSURL *)url
{
    JBoWebViewController *webVC = [[JBoWebViewController alloc] init];
    webVC.URL = url;
    [webVC showInViewController:self.navigationController animated:YES completion:nil];
    [webVC release];
}

#pragma mark-reuseScrollView代理

- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.imageURLArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];

    
    cell.titleLabel.text = info.title;
    cell.titleLabel.frame = CGRectMake(0, _height_ - info.titleHeight, _width_, info.titleHeight);
    scrollView.titleLabel.text = info.title;
    
    cell.imageView.image = info.image;
    
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    
}

- (BOOL)resuseScrollView:(JBoReuseScrollView *)scrollView isSameTitleAtIndex:(NSInteger)index withOtherIndex:(NSInteger)otherIndex
{
    if(otherIndex < 0 || otherIndex >= self.imageURLArray.count || index < 0 || index >= self.imageURLArray.count)
    {
        return YES;
    }
    
    JBoReuseScrollInfo *info = [self.imageURLArray objectAtIndex:index];
    JBoReuseScrollInfo *otherInfo = [self.imageURLArray objectAtIndex:otherIndex];
    
    return info.msgId == otherInfo.msgId;
}

- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    self.imageURLArray = nil;
    [_tableView reloadData];
}


@end
