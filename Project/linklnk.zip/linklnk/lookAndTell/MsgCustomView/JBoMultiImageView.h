//
//  JBoMultiImageView.h
//  连你
//
//  Created by kinghe005 on 14-2-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageView.h"

#define _singleRectangleWidth_ 210
#define _singleRectangleHeight_ 120
#define _singleSquareSize_ 120
#define _multiSize_ 70
#define _imagesPerRows_ 3
#define _multiImageInterval_ 5

//logo类型
typedef enum _JBoMultiImageViewCellLogoStyle
{
    JBoMultiImageViewCellLogoStyleNone = 0, //没有logo
    JBoMultiImageViewCellLogoStyleURL = 1, //链接
}JBoMultiImageViewCellLogoStyle;

@interface JBoMultiImageViewCellLogo : UIImageView

//logo类型 default is 'JBoMultiImageViewCellLogoStyleNone'
@property(nonatomic,assign) JBoMultiImageViewCellLogoStyle logoStyle;

@end

@interface JBoMultiImageViewCell : JBoImageView

- (id)initWithFrame:(CGRect)frame target:(id) target action:(SEL) selector;

/**是否显示图片下标
 */
@property(nonatomic,assign) BOOL showIndex;

/**图片下标
 */
@property(nonatomic,readonly) UILabel *indexLabel;

//下标
@property(nonatomic,assign) NSInteger index;

//logo
@property(nonatomic,readonly) JBoMultiImageViewCellLogo *logo;

@end

@class JBoMultiImageView;

@protocol JBoMultiImageViewDelegate <NSObject>

/**选中图片
 */
- (void)multiImageView:(JBoMultiImageView*) multiImageView didSelectedAtIndex:(NSInteger) index;

@optional
/**长按图片
 */
- (void)multiImageView:(JBoMultiImageView*) multiImageView didLongPressedAtIndex:(NSInteger) index;

@end

/**多张图片缩略图显示，正方形
 */
@interface JBoMultiImageView : UIView

/**缩略图片大小 default is '70.0'
 */
@property(nonatomic,assign) CGFloat thumbnailSize;

/**每行图片的数量 defult is '3'
 */
@property(nonatomic,assign) NSInteger imageCountPerRow;

/**只显示缩略图
 */
@property(nonatomic,assign) BOOL onlythumbnail;

/**图片路径 数组元素是 NSString 对象 或者 UIImage 对象
 */
@property(nonatomic,retain) NSArray *images;

/**在整个图片不居中 居于第几行
 */
@property(nonatomic,assign) NSInteger row;

/**是否允许长按功能 default is 'NO'
 */
@property(nonatomic,assign) BOOL enableLongPressGesture;

/**是否显示图片下标
 */
@property(nonatomic,assign) BOOL showIndex;

/**图片起始下标 default is '1'
 */
@property(nonatomic,assign) int beginIndex;

@property(nonatomic,assign) id<JBoMultiImageViewDelegate> delegate;

/**重新加载图片
 *@param index cell的下标
 *@param url cell显示的图片的路径
 */
- (void)reloadCellAtIndex:(NSInteger) index withURL:(NSString*) url;

/**设置cell的logo
 *@param logoStyle 图片logo类型
 *@param index cell的下标
 */
- (void)setupCellLogoStyle:(JBoMultiImageViewCellLogoStyle) logoStyle atIndex:(NSInteger) index;


/**
 通过给的图片显示 数组元素是 UIImage对象
 */
- (void)reloadWithImages:(NSArray*) images;

#pragma mark- class method

/**通过图片数量获取视图高度
 *@param count 图片数量
 */
+ (CGFloat)getHeightWithCount:(NSInteger) count;

/**通过图片总数量和每行图片数量获取视图高度
 *@param count 图片总数量
 *@param imageCountPerRow 每行图片数量
 *@return 总的图片高度
 */
+ (CGFloat)getHeightWithCount:(NSInteger) count imageCountPerRow:(NSInteger) imageCountPerRow;

/**通过图片数量获取视图高度,这时所有图片的显示方式都是正方形的缩略图
 *@param count 图片数量
 */
+ (CGFloat)getThumbnailHeightWithCount:(NSInteger) count;

/**通过图片总数量和每行图片数量获取视图高度 这时所有图片的显示方式都是正方形的缩略图
 *@param count 图片总数量
 *@param imageCountPerRow 每行图片数量
 *@return 总的图片高度
 */
+ (CGFloat)getThumbnailHeightWithCount:(NSInteger) count imageCountPerRow:(NSInteger) imageCountPerRow;

@end
