//
//  JBoUserTableHeaderView.m
//  连你
//
//  Created by kinghe005 on 14-2-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserTableHeaderView.h"
#import "JBoBasic.h"

#define _controlInterval_ 5
#define _controlHeight_ 25

@implementation JBoUserTableHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        CGFloat headSize = 60.0;
        CGFloat bgViewHeight = 100;
        self.backgroundColor = [UIColor whiteColor];
        
        //靓友圈背景图片
        _bgImageView = [[JBoAsyncImageView alloc] initWithFrame:CGRectMake(0, 0, _width_, bgViewHeight)];
        _bgImageView.userInteractionEnabled = YES;
        [self addSubview:_bgImageView];
        
        //头像
        UITapGestureRecognizer *headImageTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTap:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(frame.size.width - _controlInterval_ - headSize, frame.size.height - headSize - _controlInterval_, headSize, headSize)];
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:headImageTap];
        [headImageTap release];
        [self addSubview:_headImageView];
        
        //昵称
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(0, _headImageView.frame.origin.y + headSize - _controlHeight_,frame.size.width - headSize - _controlInterval_ * 2, _controlHeight_)];
      //  _nameLabel.userInteractionEnabled = YES;
        [_nameLabel setTextAlign:JBoTextAlignmentRight];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_nameLabel];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bgImageDidTap:)];
        self.userInteractionEnabled = YES;
        [_bgImageView addGestureRecognizer:tap];
        [tap release];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(circleBgSelectedAction:) name:_circleBgImageSelectedNotification_ object:nil];
       
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_bgImageView release];
    [_headImageView release];
    [_nameLabel release];
    
    [_separatorLine release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_circleBgImageSelectedNotification_ object:nil];
    [super dealloc];
}

#pragma mark- 通知

//靓友圈背景图片选择完成
- (void)circleBgSelectedAction:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    UIImage *image = [dic objectForKey:_circleBgImageName_];
    self.bgImageView.image = image;
}

#pragma mark- private method

- (void)leftButtonAction:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(tableHeaderViewDidSelectLeftButton:)])
    {
        [self.delegate tableHeaderViewDidSelectLeftButton:self];
    }
}

//点击头像
- (void)headImageDidTap:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(tableHeaderView:headImageDidTapped:)])
    {
        [self.delegate tableHeaderView:self headImageDidTapped:(JBoUserHeadImageView*) tap.view];
    }
}

//点击背景图片
- (void)bgImageDidTap:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(tableHeaderView:bgImageDidTapped:)])
    {
        [self.delegate tableHeaderView:self bgImageDidTapped:tap.view];
    }
}

#pragma mark- public method

/**添加分割线 默认没有分割线
 */
- (void)addSeparatorLine
{
    if(!self.separatorLine)
    {
        _separatorLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.height - _defaultSeparatorLineSize_, _width_, _defaultSeparatorLineSize_)];
        _separatorLine.backgroundColor = _defaultSeparatorLineColor_;
        [self addSubview:_separatorLine];
    }
}

/**添加左边按钮 默认没有标题和图片
 */
- (void)addLeftButton
{
    if(!self.leftButton)
    {
        _leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_leftButton setTitleColor:[UIColor colorWithRed:62.0 / 255.0 green:215.0 / 255.0 blue:21.0 / 255.0 alpha:1.0] forState:UIControlStateNormal];
        [_leftButton setAdjustsImageWhenHighlighted:NO];
        _leftButton.titleLabel.font = [UIFont boldSystemFontOfSize:13.0];
        [_leftButton setFrame:CGRectMake(0, _nameLabel.top, 100.0, _nameLabel.height)];
        [_leftButton addTarget:self action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_leftButton];
        
        CGRect frame = _nameLabel.frame;
        frame.origin.x = _leftButton.right;
        frame.size.width -= _leftButton.width;
        _nameLabel.frame = frame;
    }
}

@end
