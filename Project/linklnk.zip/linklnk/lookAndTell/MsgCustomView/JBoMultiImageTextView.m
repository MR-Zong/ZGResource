//
//  JBoMultiImageTextCell.m
//  连你
//
//  Created by kinghe005 on 14-3-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMultiImageTextView.h"
#import "JBoBasic.h"


#define _labelStartTag_ 100
#define _multiImageViewStartTag_ 10
#define _controlInterval_ 5

@interface JBoMultiImageTextView ()<JBoImageTextLabelDelegate,JBoMultiImageViewDelegate>

@end

@implementation JBoMultiImageTextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.contentFont = [UIFont systemFontOfSize:17.0];
        
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectZero];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.delegate = self;
        
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
        [_contentLabel addGestureRecognizer:longPress];
        [longPress release];
        [_contentLabel.tapGesture requireGestureRecognizerToFail:longPress];
        
        _contentLabel.tag = _labelStartTag_;
        _contentLabel.font = self.contentFont;
        [self addSubview:_contentLabel];
        
        
        _multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectZero];
        _multiImageView.delegate = self;
        _multiImageView.tag = _multiImageViewStartTag_;
        [self addSubview:_multiImageView];
    }
    return self;
}

- (void)dealloc
{
    [_contentFont release];
    [_srcArray release];
    
    [_contentLabel release];
    [_multiImageView release];
    
    self.layoutView = nil;
    self.delegate = nil;
    
    [super dealloc];
}

- (void)setContentFont:(UIFont *)contentFont
{
    if(_contentFont != contentFont)
    {
        [_contentFont release];
        _contentFont = [contentFont retain];
    }
}

- (void)reloadRow:(NSInteger) row atIndex:(NSInteger) index withURL:(NSString*) url
{
    JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:_multiImageViewStartTag_ + row];
    [multiImageView reloadCellAtIndex:index withURL:url];
}

- (void)reloadRow:(NSInteger) row withImages:(NSArray*) images
{
    JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:_multiImageViewStartTag_ + row];
    [multiImageView reloadWithImages:images];
}

- (void)setSrcArray:(NSArray *)srcArray
{
    if(_srcArray != srcArray)
    {
        [_srcArray release];
        _srcArray = [srcArray retain];
        
        for(UIView *view in self.subviews)
        {
            if(![view isEqual:_contentLabel] && ![view isEqual:_multiImageView])
            {
                [view removeFromSuperview];
            }
        }
        
        CGFloat height = 0;
        
        self.onluThumbnail = _srcArray.count > 1;
        
        //NSLog(@"%d",_srcArray.count);
        for(NSInteger i = 0;i < _srcArray.count;i ++)
        {
            JBoMultiImageText *info = [_srcArray objectAtIndex:i];
            
            JBoImageTextLabel *contentLabel = _contentLabel;
            
            if(i != 0)
            {
                contentLabel = [[[JBoImageTextLabel alloc] initWithFrame:CGRectZero] autorelease];
                contentLabel.backgroundColor = [UIColor clearColor];
                contentLabel.delegate = self;
                [self addSubview:contentLabel];
            }
            
            CGFloat contentHeight = info.titleHeight;
            if(self.hasMoreText && contentHeight > _lookAndTellMaxContentHeight_)
                contentHeight = _lookAndTellMaxContentHeight_;
            
            contentLabel.textInset = _defaultMultiImageTextInset_;
            contentLabel.minLineHeight = _defaultMultiImageTextLineHeight_;
            contentLabel.wordInset = _defaultMultiImageTextWordInset_;
            contentLabel.font = self.contentFont;
            contentLabel.frame = CGRectMake(0, height, self.bounds.size.width, contentHeight + contentLabel.textInset * 2);
            contentLabel.tag = _labelStartTag_ + i;
            contentLabel.text = info.content;
            
            if(![contentLabel isEqual:_contentLabel])
            {
                UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
                [contentLabel addGestureRecognizer:longPress];
                [longPress release];
                [contentLabel.tapGesture requireGestureRecognizerToFail:longPress];
            }
            
            //NSLog(@"%@",contentLabel);
            
            height += contentHeight + _imageTextInterval_;
            
            if(self.hasMoreText)
            {
                CGFloat buttonWidth = 100.0;
                UIButton *totalButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [totalButton setFrame:CGRectMake(self.bounds.size.width - buttonWidth, height, buttonWidth, _defaultMultiImageTextButton_)];
                [totalButton setTitle:@"阅读全文" forState:UIControlStateNormal];
                totalButton.titleLabel.font = [UIFont systemFontOfSize:14.0];
                [totalButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                [totalButton addTarget:self action:@selector(totalText:) forControlEvents:UIControlEventTouchUpInside];
                [self addSubview:totalButton];
                height += _defaultMultiImageTextButton_;
            }
            
            if(info.imageURLArray.count > 0)
            {
                if(i == 0)
                {
                    _multiImageView.hidden = NO;
                }
                
                JBoMultiImageView *multiImageView = _multiImageView;
                if(i != 0)
                {
                    multiImageView = [[[JBoMultiImageView alloc] initWithFrame:CGRectZero] autorelease];
                    multiImageView.delegate = self;
                    [self addSubview:multiImageView];
                }
               
                multiImageView.row = i;
                multiImageView.onlythumbnail = self.onluThumbnail;
                multiImageView.frame = CGRectMake(0, height + _imageTextInterval_, self.bounds.size.width, info.imageHeight);
                multiImageView.tag = _multiImageViewStartTag_ + i;
                multiImageView.images = info.imageURLArray;
                height += info.imageHeight + _imageTextPadding_;
                
            }
            else
            {
                _multiImageView.hidden = YES;
            }
                
            if(self.hasMoreText)
                break;
        }
        
        
        self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, height + _imageTextInterval_);
        
        [self.layoutView setNeedsLayout];
    }
}

#pragma mark-JBoChatMsgLabel代理
- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(multiImageTextView:didSelectedURL:)])
    {
        [self.delegate multiImageTextView:self didSelectedURL:url];
    }
}

#pragma mark-JBoMultiImageView代理
- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(multiImageTextView:didSelectedImageAtIndex:)])
    {
        NSInteger indexs = 0;
        for(NSInteger i = 0;i < multiImageView.row;i ++)
        {
            JBoMultiImageText *text = [self.srcArray objectAtIndex:i];
            //NSLog(@"%@",text.imageURLArray);
            indexs += text.imageURLArray.count;
        }
        
        indexs += index;
       // NSLog(@"%d",indexs);
        [self.delegate multiImageTextView:self didSelectedImageAtIndex:indexs];
    }
}

- (void)totalText:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(multiImageTextViewDidSeletedTotalContent:)])
    {
        [self.delegate multiImageTextViewDidSeletedTotalContent:self];
    }
}

- (void)longPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        if([self.delegate respondsToSelector:@selector(multiImageTextView:didLongPressAtLabel:atIndex:)])
        {
            NSInteger index = longPress.view.tag - _labelStartTag_;
            [self.delegate multiImageTextView:self didLongPressAtLabel:(UILabel*)longPress.view atIndex:index];
        }
    }
}

@end
