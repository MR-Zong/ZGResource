//
//  JBoLookAndTellTypeSelectedCell.h
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoImageView.h"

#define _lookAndTellTypeSelectedCellHeight_ 60.0
#define _lookAndTellTypeSelectedCellInterval_ 5.0

#define _sectionHeaderHeight_ 35.0


@interface JBoLookAndTellTypeSelectedCell : UITableViewCell

@property(nonatomic,readonly) JBoImageView *iconImageView;
@property(nonatomic,readonly) UILabel *titleLabel;

@end
