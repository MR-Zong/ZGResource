//
//  JBoMsgSingleImageTextView.h
//  靓咖
//
//  Created by kinghe005 on 14-5-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellReleaseBaseView.h"

@class SSTextView;

/**超友圈信息发布 普通图文
 */
@interface JBoMsgSingleImageTextView : JBoLookAndTellReleaseBaseView

/**文本信息
 */
@property(nonatomic,retain) SSTextView *textView;

/**选择的图片，数组元素是 UIImage
 */
@property(nonatomic,retain) NSMutableArray *imageArray;

/**发布
 */
- (BOOL)finish;

@end
