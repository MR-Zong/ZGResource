//
//  JBoLookAndTellTypeSelectedCell.m
//  连你
//
//  Created by kinghe005 on 14-4-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellTypeSelectedCell.h"
#import "JBoBasic.h"

@implementation JBoLookAndTellTypeSelectedCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _iconImageView = [[JBoImageView alloc] initWithFrame:CGRectMake(_lookAndTellTypeSelectedCellInterval_, _lookAndTellTypeSelectedCellInterval_, _lookAndTellTypeSelectedCellHeight_ - _lookAndTellTypeSelectedCellInterval_ * 2, _lookAndTellTypeSelectedCellHeight_ - _lookAndTellTypeSelectedCellInterval_ * 2)];
        [self.contentView addSubview:_iconImageView];
        
        CGFloat labelHeight = 30.0;
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_iconImageView.frame.size.height + _iconImageView.frame.origin.x + _lookAndTellTypeSelectedCellInterval_ * 3, (_lookAndTellTypeSelectedCellHeight_ - labelHeight) / 2, self.bounds.size.width - _lookAndTellTypeSelectedCellInterval_ - _lookAndTellTypeSelectedCellHeight_, labelHeight)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
    }
    return self;
}

- (void)dealloc
{
    [_iconImageView release];
    [_titleLabel release];
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
