//
//  JBoShareShortMovieView.h
//  靓咖
//
//  Created by kinghe005 on 14-5-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoShortMovieView.h"
#import "JBoImageTextLabel.h"

#define _shareShortMovieDefaultSize_ 100.0

@class JBoShareShortMovieView;

@protocol JBoShareShortMovieViewDelegate <NSObject>

- (void)shareShortMovieView:(JBoShareShortMovieView*) view didSelectedURL:(NSURL*) url;

- (void)shareShortMovieViewWillPlayMovie:(JBoShareShortMovieView *)view;
- (void)shareShortMovieViewDidStopPlayMovie:(JBoShareShortMovieView *)view;
- (void)shareShortMovieViewPrepareToPlayMovie:(JBoShareShortMovieView *)view;

/**视频预览图加载完成
 */
- (void)shareShortMovieViewDidLoadFirstImage:(JBoShareShortMovieView*) view;


@end

/**靓友圈分享视频视图
 */
@interface JBoShareShortMovieView : UIView<JBoShortMovieViewDelegate, JBoImageTextLabelDelegate>

@property(nonatomic,readonly) JBoShortMovieView *shortMovieView;
@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;

@property(nonatomic,retain) NSArray *srcArray;
@property(nonatomic,assign) UIView *layoutView;

@property(nonatomic,assign) id<JBoShareShortMovieViewDelegate> delegate;

- (void)reloadImageWithURL:(NSString*) url;


+ (CGFloat)movieHeightForURL:(NSString*) url;

@end
