//
//  JBoLookAndTellReleaseBaseView.m
//  靓咖
//
//  Created by kinghe005 on 14-5-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLookAndTellReleaseBaseView.h"
#import "JBoUserPrivacyViewController.h"
#import "JBoBasic.h"
#import "JBoSceneConditionPicker.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoCustomFilterBar.h"
#import "JBoFileManager.h"

#define _padding_ 10

static NSString *const activityPlaceHolder = @"写点东西吧！\n每段限1000字,超出部分以灰色显示";
static NSString *const generalPlaceHolder = @"写点东西吧！\n每段限1000字,超出部分以灰色显示";

static NSString *const activityPlaceHolder_5 = @"关联场景后,陌生人可通过场景匹配找到你,每段限1000字";
static NSString *const generalPlaceHolder_5 = @"写点东西吧！\n每段限1000字";


@implementation JBoLookAndTellReleaseBaseView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        self.contentHeight = 112.5;
        self.labelHeight = 20.0;
        
        if(_ios6_0_)
        {
            self.generPlaceHolder = generalPlaceHolder;
            self.activityPlaceHolder = activityPlaceHolder;
        }
        else
        {
            self.generPlaceHolder = generalPlaceHolder_5;
            self.activityPlaceHolder = activityPlaceHolder_5;
        }
        
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        UITapGestureRecognizer *reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyborad:)];
        reconverGesture.delegate = self;
        [self addGestureRecognizer:reconverGesture];
        self.reconverGesture = reconverGesture;
        [reconverGesture release];
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
        view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        
        CGFloat buttonWidth = 60.0;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [button setTitle:@"完成" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
        [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
        [view addSubview:button];
        
        self.inputAccessoryView = view;
        [view release];
        
        //使用条款
        self.protocolView = [JBoUserOperation getProtocolViewWithFrame:CGRectMake(_padding_, 0, self.width - _padding_ * 2, 0) target:self action:@selector(serverProtocolAction:)];
        [self addSubview:self.protocolView];
        
        //可见范围
        self.visible = _lookAndTellVisiblePublic_;
        JBoSceneConditionPickerSelected *slider = [[JBoSceneConditionPickerSelected alloc] initWithFrame:CGRectMake(_padding_, 0, _width_ - _padding_ * 2, 40.0) title:@"可见范围" icon:nil];
        slider.layer.cornerRadius = 5.0;
        slider.layer.masksToBounds = YES;
        slider.contentLabel.text = @"公开";
        [slider addTarget:self action:@selector(selectVisible:)];
        [self addSubview:slider];
        self.visibleCondition = slider;
        [slider release];
       
        
        self.info = [[[JBoLookAndTellListInfo alloc] init] autorelease];
        self.imageNameArray = [NSMutableArray array];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- 内存管理

- (void)dealloc
{
    self.delegate = nil;
    [JBoFileManager deleteFiles:self.imageNameArray];
    
    [_reconverGesture release];
    [_inputAccessoryView release];
    [_protocolView release];
    
    [_generPlaceHolder release];
    [_activityPlaceHolder release];
    
    [_httpQueue reset];
    [_httpQueue cancelAllOperations];
    [_httpQueue release];
    
    [_httpRequest release];
    
    [_info release];
    [_imageNameArray release];
    
    [_visibleCondition release];
    [_picker release];
    
    [super dealloc];
}

#pragma mark-publick method

- (void)alert
{
    
    NSString *title = _ios6_0_ ? @"您发表的内容已超过字数限制,超出部分标示为红色" : @"您发表的内容已超过字数限制";
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertView show];
    [alertView release];
    self.appDelegate.dataLoadingView.hidden = YES;
}

- (void)sendSuccess:(BOOL) success
{
    [self updateUploadProgress:1.0];
    [JBoFileManager deleteFiles:self.imageNameArray];
    
    JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
    self.info.userID = detailInfo.rosterInfo.username;
    self.info.headImageURL = detailInfo.rosterInfo.imageURL;
    self.info.userName = detailInfo.rosterInfo.name;
    self.info.sex = detailInfo.rosterInfo.sex;
    self.info.role = detailInfo.rosterInfo.role;
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:_releaseLookAndTellNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:self.info forKey:_releaseLookAdnTellInfo_]];
    
    [JBoUserOperation alertMsg:@"发布成功"];
    self.isRequesting = NO;
    
    if([self.delegate respondsToSelector:@selector(lookAndTellReleaseBaseView:didFinishedWithInfo:)])
    {
        [self.delegate lookAndTellReleaseBaseView:self didFinishedWithInfo:self.info];
    }
}

/**更新上传进度
 *@param progress 当前进度
 */
- (void)updateUploadProgress:(float) progress
{
    if([self.delegate respondsToSelector:@selector(lookAndTellReleaseBaseView:updateUploadProgress:)])
    {
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self.delegate lookAndTellReleaseBaseView:self updateUploadProgress:progress];
        });
    }
}

#pragma mark- http代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        [self sendSuccess:NO];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        [self releaseData:data];
        return;
    }
}

- (void)releaseData:(NSData *)data
{
    
}

- (void)requestDidFail:(ASIHTTPRequest*) request
{
    NSLog(@"失败");
    self.success = NO;
}

- (void)httpQuqueDidFinish:(ASINetworkQueue*) queue
{
    //[JBoUserOperation alertMsg:@"发布成功"];
    [self.httpQueue reset];
    self.httpQueue = nil;
    
    if(self.success)
    {
        self.isRequesting = YES;
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self identifier:_getUserLookAndTellIdentifier_] autorelease];
        [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getLookAndtellFromGroupId:self.info.groupId]];
    }
    else
    {
        [self updateUploadProgress:-1];
        self.isRequesting = NO;
        if([self.delegate respondsToSelector:@selector(lookAndTellReleaseBaseView:didFinishedWithInfo:)])
        {
            [self.delegate lookAndTellReleaseBaseView:self didFinishedWithInfo:nil];
        }
    }
}

//更新上传进度
- (void)httpQueueDidUpdateProgress:(ASINetworkQueue*) queue
{
    float progress = (double)queue.bytesUploadedSoFar / (double)queue.totalBytesToUpload;
    [self updateUploadProgress:progress * 0.95];
}

//设置 queue
- (ASINetworkQueue*)httpQueue
{
    if(!_httpQueue)
    {
        _httpQueue = [[ASINetworkQueue alloc] init];
        [_httpQueue setDelegate:self];
        [_httpQueue setQueueDidFinishSelector:@selector(httpQuqueDidFinish:)];
        [_httpQueue setRequestDidFailSelector:@selector(requestDidFail:)];
        [_httpQueue setDelegate:self];
        [_httpQueue setShowAccurateProgress:YES];
        [_httpQueue setQueueDidUpdateProgerssSelector:@selector(httpQueueDidUpdateProgress:)];
    }
    return _httpQueue;
}

#pragma mark-协议

- (void)serverProtocolAction:(UIButton*) button
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    JBoUserPrivacyViewController *userPrivacy = [[JBoUserPrivacyViewController alloc] init];
    [self.navigationController pushViewController:userPrivacy animated:YES];
    [userPrivacy release];
}

- (void)reconverKeyborad:(UITapGestureRecognizer*) tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (void)inputFinish:(UIButton*) button
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

#pragma mark- gesture 代理

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if([touch.view isKindOfClass:[JBoCustomFilterBar class]] || [touch.view isKindOfClass:[UIButton class]] || [touch.view isKindOfClass:[JBoSceneConditionPickerSelected class]] || [touch.view isKindOfClass:[JBoSceneConditionPicker class]])
    {
        return NO;
    }
    return YES;
}

#pragma mark-textView代理

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.scrollViewHeight = self.scrollView.frame.size.height;
    self.scrollView.frame = CGRectMake(self.scrollView.frame.origin.x, self.scrollView.frame.origin.y, self.scrollView.frame.size.width, self.scrollView.frame.size.height - 216);
    self.scrollView.contentOffset = CGPointMake(0, textView.frame.origin.y - _padding_);
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.scrollView.frame = CGRectMake(self.scrollView.frame.origin.x, self.scrollView.frame.origin.y, self.scrollView.frame.size.width, self.scrollViewHeight);
    CGFloat y = textView.frame.origin.y - 216;
    self.scrollView.contentOffset = CGPointMake(0, y < 0 ? 0 : y);
}

- (void)textViewDidChange:(UITextView *)textView
{
    if(textView.markedTextRange)
        return;
    NSString *text = textView.text;
    
    if(text.length > _inputFormatLookAndTellNum_)
    {
        if(_ios6_0_)
        {
#ifdef __IPHONE_6_0
            
            SSTextView *sst = (SSTextView*)textView;
            NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
            [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor] range:NSMakeRange(_inputFormatLookAndTellNum_, text.length - _inputFormatLookAndTellNum_)];
            [attributedText addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:17.0] range:NSMakeRange(0, text.length)];
            sst.scrollEnabled = NO;
            NSRange range = sst.selectedRange;
            sst.attributedText = attributedText;
            sst.selectedRange = range;
            sst.scrollEnabled = YES;
            [attributedText release];
#endif
        }
        else
        {
            textView.text = [text substringToIndex:_inputFormatLookAndTellNum_];
        }
    }
}



#pragma mark- 可见范围

- (void)selectVisible:(id) sender
{
    self.scrollViewHeight = self.scrollView.frame.size.height;
    self.scrollView.frame = CGRectMake(self.scrollView.frame.origin.x, self.scrollView.frame.origin.y, self.scrollView.frame.size.width, self.scrollView.frame.size.height - _sceneConditionPickerHeight_);
    self.scrollView.contentOffset = CGPointMake(0, self.visibleCondition.top - _padding_);
    
    JBoSceneConditionPicker *picker = [[JBoSceneConditionPicker alloc] initWithSuperView:self.navigationController.view style:JBoSceneConditionPickerStyleLookAndTellVisible];
//    picker.finishLabel.backgroundColor = self.inputAccessoryView.backgroundColor;
    [picker showWithAnimated:YES completion:nil];
    picker.delegate = self;
    self.picker = picker;
    [picker release];
}

- (void)conditionPicker:(JBoSceneConditionPicker *)picker didFinisedWithConditions:(NSDictionary *)conditions
{
    NSString *value = [conditions objectForKey:[NSNumber numberWithInteger:picker.style]];
    self.visibleCondition.contentLabel.text = value;
    if([value isEqualToString:@"公开"])
    {
        self.visible = _lookAndTellVisiblePublic_;
    }
    else
    {
        self.visible = _lookAndTellVisiblePrivate_;
    }
    [picker dismissWithAnimated:YES completion:nil];
}

- (void)conditionPickerWillDismiss:(JBoSceneConditionPicker *)picker
{
    self.picker = nil;
    self.scrollView.frame = CGRectMake(self.scrollView.frame.origin.x, self.scrollView.frame.origin.y, self.scrollView.frame.size.width, self.scrollViewHeight);
    CGFloat y = self.visibleCondition.top - _sceneConditionPickerHeight_;
    self.scrollView.contentOffset = CGPointMake(0, y < 0 ? 0 : y);
}

//- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
//{
//    // NSLog(@"--%@-- %d",text,range.length);
//    if([text isEqualToString:@"\n"])
//    {
//        [textView resignFirstResponder];
//        return NO;
//    }
//    return YES;
//}


@end
