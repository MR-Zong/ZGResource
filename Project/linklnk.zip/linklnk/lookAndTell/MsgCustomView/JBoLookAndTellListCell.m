//
//  JBoLookAndTellListCell.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLookAndTellListCell.h"
#import "JBoImageTextTool.h"
#import "JBoBasic.h"

#define _iconInterval_ 5
#define _iconSize_ 15.0

@interface JBoLookAndTellListCell ()

@property(nonatomic,assign) JBoLookAndTellCellStyle style;

@end


@implementation JBoLookAndTellListCell

@synthesize delegate;

- (id)initWithCellStyle:(JBoLookAndTellCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithCellStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        self.style = style;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouched:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_rightPadding_ / 2, _topPadding_, _headImageSize_, _headImageSize_)];
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [self.contentView addSubview:_headImageView];
        [tap release];
        
        CGFloat width = _width_ - _headImageView.right - _rightPadding_ * 2 - _lookAndTellcontrolInterval_;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _lookAndTellcontrolInterval_ + _rightPadding_ / 2, _headImageView.frame.origin.y, width / 5 * 3, 30)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat x = _nameLabel.frame.origin.x - _nameLabel.frame.size.width;
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, _nameLabel.frame.origin.y, _width_ - x - _rightPadding_, _nameLabel.frame.size.height)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        
        [self.contentView addSubview:_dateLabel];
        
        self.multiImageTextView.frame = CGRectMake(_nameLabel.frame.origin.x, _nameLabel.bottom, self.multiImageTextView.frame.size.width, 0);
 
        self.linkView.frame = CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.origin.y + _nameLabel.frame.size.height, self.linkView.frame.size.width, 0);
        
        self.shareShortMovieView.frame = CGRectMake(_nameLabel.frame.origin.x, _nameLabel.bottom, self.shareShortMovieView.frame.size.width, 0);
        
        self.msgOperationView.frame = CGRectMake(_nameLabel.frame.origin.x, _nameLabel.bottom, self.msgOperationView.frame.size.width, 0);
        
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_dateLabel release];

    [super dealloc];
    
}

//点击头像
- (void)headImageDidTouched:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(lookAndTellListCellHeadImageDidSelected:)])
    {
        [self.delegate lookAndTellListCellHeadImageDidSelected:self];
    }
}

#pragma mark-layoutSubViews

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat y = 0;
    switch (self.style)
    {
        case JBoLookAndTellCellStyleDefault:
            y = self.multiImageTextView.frame.origin.y + self.multiImageTextView.frame.size.height;
            break;
        case JBoLookAndTellCellStyleLinkShare :
            y = self.linkView.frame.origin.y + self.linkView.frame.size.height;
            break;
        case JBoLookAndTellCellStyleShortMovie :
            y = self.shareShortMovieView.frame.origin.y + self.shareShortMovieView.frame.size.height;
            break;
        default:
            break;
    }
    
    self.msgOperationView.frame = CGRectMake(self.msgOperationView.frame.origin.x, y, self.msgOperationView.frame.size.width, self.msgOperationView.frame.size.height);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
