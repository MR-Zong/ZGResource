//
//  JBoEvaluteLevelView.h
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoBasic.h"

#define _evaluteViewWidth_ (_evaluteIconCount_ * (_evaluteIconSize_ + _evaluteIconInterval_)  + _evaluteTitleWidth_)

@class JBoEvaluteLevelView;

@protocol JBoEvaluteLevelViewDelegate <NSObject>

- (void)evaluteLevelView:(JBoEvaluteLevelView*) evaluteLevelView gradeDidChanged:(NSInteger) grade;

@end

@interface JBoEvaluteLevelView : UIView

//选中 未选中
@property(nonatomic,retain) UIImage *normalImage;
@property(nonatomic,retain) UIImage *selectedImage;
//标题
@property(nonatomic,readonly) UILabel *titleLabel;

@property(nonatomic,assign) NSInteger grade;

@property(nonatomic,assign) id<JBoEvaluteLevelViewDelegate> delegate;

@property(nonatomic,assign) BOOL editable;


- (id)initWithFrame:(CGRect)frame title:(NSString*) title normalImage:(UIImage*) normalImage selectedImage:(UIImage*) selectedImage;

@end
