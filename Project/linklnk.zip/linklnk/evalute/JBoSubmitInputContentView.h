//
//  JBoSubmitCommentView.h
//  连客
//
//  Created by kinghe005 on 13-12-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSTextView.h"

@class JBoSubmitInputContentView;

@protocol JBoSubmitInputContentViewDelegate <NSObject>

- (void)submitDidFinished:(NSString*) content;
- (void)submitViewWillDismiss:(JBoSubmitInputContentView*) view;

@end



@interface JBoSubmitInputContentView : UIView
{
    //回收键盘
    UITapGestureRecognizer *_reconverGesture;
    
    //
    UIView *_blackBgView;
    UIView *_whiteBgView;
}

@property(nonatomic,assign) id<JBoSubmitInputContentViewDelegate> delegate;
@property(nonatomic,readonly) SSTextView *newsCommentTextView;

- (id)initWithFrame:(CGRect)frame maxCommentCount:(NSInteger) maxCount;

- (void)beginComment;

@end
