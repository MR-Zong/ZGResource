//
//  JBoEvaluteView.m
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSubmitEvaluteView.h"
#import "JBoSubmitEvaluteCell.h"
#import "JBoSubmitEvaluteInfo.h"
#import "JBoAppDelegate.h"
#import "JBoAsyncDownloadOperation.h"
#import "JBoGoodsInfoOpeartion.h"

@interface JBoSubmitEvaluteView ()<JBoSubmitEvaluteCellDelegate>
{
    JBoAppDelegate *_appDelegate;
    
    //加载图片
    NSMutableDictionary *_downloadProgressDic;
    JBoGoodsInfoOpeartion *_goodsInfoOperation;
}

@property(nonatomic,assign) NSInteger currentIndex;

@end
@implementation JBoSubmitEvaluteView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        _downloadProgressDic = [[NSMutableDictionary alloc] init];
        _goodsInfoOperation = [[JBoGoodsInfoOpeartion alloc] init];
        
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        
        _scrollView.bounces = YES;
        _scrollView.pagingEnabled = YES;
        _scrollView.delegate = self;
        _scrollView.userInteractionEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator= NO;
        _scrollView.showsVerticalScrollIndicator= NO;
        [self addSubview:_scrollView];
        
        _recyleViews = [[NSMutableSet alloc] init];
        _visibleViews = [[NSMutableSet alloc] init];
        
        
        _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, 20)];
        [_pageControl addTarget:self action:@selector(pageChange:) forControlEvents:UIControlEventValueChanged];
        _pageControl.hidesForSinglePage = YES;
        [self addSubview:_pageControl];
        
    }
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoSubmitEvaluteView dealloc");
    [_visibleViews release];
    [_recyleViews release];
    [_srcArray release];
    
    [_pageControl release];
    [_scrollView release];
    
    [_goodsInfoOperation release];
    [_downloadProgressDic release];
    
    [super dealloc];
}

- (void)nextView
{
    if(_pageControl.currentPage < _pageControl.numberOfPages - 1)
    {
        _pageControl.currentPage ++;
    }
    else
    {
        _pageControl.currentPage = 0;
    }
    [self pageChange:_pageControl];
}

- (void)setSrcArray:(NSArray *)srcArray
{
    if(_srcArray != srcArray)
    {
        [_srcArray release];
        _srcArray = [srcArray retain];
        
         _pageControl.numberOfPages = _srcArray.count;
        _scrollView.contentSize = CGSizeMake(self.frame.size.width * _srcArray.count, self.frame.size.height);
         [self tilePages];
    }
}

- (void)pageChange:(UIPageControl*) pageControl
{
    [_scrollView scrollRectToVisible:CGRectMake(_scrollView.frame.size.width * pageControl.currentPage, 0, _scrollView.frame.size.width, _scrollView.frame.size.height) animated:pageControl.currentPage != 0 ? YES : NO];
}


//视图滑动时
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    //  NSLog(@"----%f",scrollView.contentOffset.x);
    [self tilePages];
    _pageControl.currentPage = scrollView.contentOffset.x / scrollView.frame.size.width;
    if (scrollView.contentOffset.x > scrollView.frame.size.width * ([self.srcArray count] - 1) + 100)
    {
        [scrollView scrollRectToVisible:CGRectMake(scrollView.frame.size.width * 0, 0, scrollView.frame.size.width, scrollView.frame.size.height) animated:NO];
        _pageControl.currentPage = 0;
    }
}

#pragma mark-
#pragma mark-scrollView重用机制-
- (void)tilePages
{
    if(_srcArray.count <= 0)
        return;
    // Calculate which pages are visible
    //NSLog(@"图片数量 %d",self.srcArray.count);
    CGRect visibleBounds = _scrollView.bounds;
    int firstNeededPageIndex = floorf(CGRectGetMinX(visibleBounds) / CGRectGetWidth(visibleBounds));
    int lastNeededPageIndex  = floorf((CGRectGetMaxX(visibleBounds) - 1) / CGRectGetWidth(visibleBounds));
    
    firstNeededPageIndex = MAX(firstNeededPageIndex, 0);
    lastNeededPageIndex  = MIN(lastNeededPageIndex, [self.srcArray count] - 1);
    
    // Recycle no-longer-visible pages
    for (JBoSubmitEvaluteCell *cell in _visibleViews)
    {
        //NSLog(@"page.index=%d",cell.index);
        if (cell.index < firstNeededPageIndex || cell.index > lastNeededPageIndex) {
            [_recyleViews addObject:cell];
            [cell removeFromSuperview];
        }
    }
    [_visibleViews minusSet:_recyleViews];
    
    // add missing pages
    for (int index = firstNeededPageIndex; index <= lastNeededPageIndex; index++)
    {
        if (![self isDisplayingPageForIndex:index]) {
            JBoSubmitEvaluteCell *cell = [self dequeueRecycledPage];
            if (cell == nil)
            {
                // NSLog(@"创建 cell");
                cell = [[[JBoSubmitEvaluteCell alloc] initWithFrame:_scrollView.frame] autorelease];
                cell.userInteractionEnabled = YES;
                cell.delegate = self;
            }
            [self configurePage:cell forIndex:index];
            [_scrollView addSubview:cell];
            [_visibleViews addObject:cell];
        }
    }
    
    // NSLog(@"子视图数量 %d",_scrollView.subviews.count);
}

//JBoSubmitEvaluteCell代理
- (void)evaluteCellDidBeganEdit:(JBoSubmitEvaluteCell *)cell
{
    
}

- (void)evaluteCellDidEndedEdit:(JBoSubmitEvaluteCell *)cell
{
    JBoSubmitEvaluteInfo *submitEvaluteInfo = [self.srcArray objectAtIndex:cell.index];
    submitEvaluteInfo.content = cell.contentTextView.text;
}

- (void)evaluteCellgradeDidChanged:(JBoSubmitEvaluteCell *)cell
{
    JBoSubmitEvaluteInfo *submitEvaluteInfo = [self.srcArray objectAtIndex:cell.index];
    submitEvaluteInfo.grade = cell.grade;
}


- (JBoSubmitEvaluteCell *)dequeueRecycledPage
{
    JBoSubmitEvaluteCell *cell = [_recyleViews anyObject];
    if (cell) {
        [[cell retain] autorelease];
        [_recyleViews removeObject:cell];
    }
    return cell;
}

- (BOOL)isDisplayingPageForIndex:(NSUInteger)index
{
    BOOL foundPage = NO;
    for (JBoSubmitEvaluteCell *cell in _visibleViews)
    {
        if (cell.index == index) {
            foundPage = YES;
            break;
        }
    }
    return foundPage;
}

- (void)configurePage:(JBoSubmitEvaluteCell*)cell forIndex:(NSUInteger)index
{
    self.currentIndex = index;
    cell.index = index;
    
    JBoSubmitEvaluteInfo *evaluteInfo = [_srcArray objectAtIndex:index];
    
    if(evaluteInfo.goodsInfo.goodsImage)
    {
        cell.goodsImageView.image = evaluteInfo.goodsInfo.goodsImage;
    }
    else
    {
        if(evaluteInfo.goodsInfo.goodsImageServerURL != nil)
        {
            if(!_scrollView.dragging && !_scrollView.decelerating)
            {
                [self downloadImageAtRosterInfo:evaluteInfo.goodsInfo forIndex:index];
            }
        }
        else
        {
            evaluteInfo.goodsInfo.goodsImage = _appDelegate.defaultGoodsImage;
        }
        cell.goodsImageView.image = _appDelegate.defaultGoodsImage;
    }
    
    cell.nameLabel.text = evaluteInfo.goodsInfo.goodsName;
    NSString *colorName = [[_appDelegate.colorDic objectForKey:evaluteInfo.goodsInfo.goodsColorID] objectAtIndex:0];
    NSString *sizeName = [_appDelegate.sizeDic objectForKey:evaluteInfo.goodsInfo.goodsSizeID];
    cell.colorAndSizeLabel.text = [NSString stringWithFormat:@"尺寸:%@ 颜色:%@",sizeName, colorName];
    
    cell.numLabel.text = evaluteInfo.goodsInfo.goodsCount;
    cell.priceLabel.text = evaluteInfo.goodsInfo.goodsPrice;
    
    cell.grade = evaluteInfo.grade;
    if(evaluteInfo.grade > 0)
    {
        cell.goodView.grade = evaluteInfo.grade;
        cell.negativeView.grade = 0;
    }
    else if(evaluteInfo.grade < 0)
    {
        cell.negativeView.grade = evaluteInfo.grade;
        cell.goodView.grade = 0;
    }
    else
    {
        cell.negativeView.grade = 0;
        cell.goodView.grade = 0;
    }
    
    cell.contentTextView.text = evaluteInfo.content;
    
    
    cell.frame = CGRectMake(self.frame.size.width * index, 0, self.frame.size.width, self.frame.size.height);
}


//加载图片
- (void)downloadImageAtRosterInfo:(JBoOrderDetailGoodsInfo*) goodsInfo forIndex:(NSInteger) index;
{
    //先判断该头像是否正在下载
    NSString *indexStr = [NSString stringWithFormat:@"%d",index];
    JBoAsyncDownloadOperation *asyncDownloadOperation = [_downloadProgressDic objectForKey:indexStr];
    
    if(!asyncDownloadOperation)
    {
        //创建一个queue来获取头像
        JBoAsyncDownloadOperation *asyncDownloadOperation = [_goodsInfoOperation getGoodsImageFromURL:goodsInfo.goodsImageServerURL withElementID:goodsInfo.goodsID];
        
        __block JBoAsyncDownloadOperation *blockAsyncDownloadOperation = asyncDownloadOperation;
        
        [asyncDownloadOperation setCompletionHandler:^(){
            
            NSData *imageData = [_goodsInfoOperation getGoodsImageFromIQ:blockAsyncDownloadOperation.iq];
            UIImage *image = [[UIImage alloc] initWithData:imageData];
            goodsInfo.goodsImage = image != nil ? image : _appDelegate.defaultGoodsImage;
            [image release];
            
            [self performSelectorOnMainThread:@selector(updataHeaderImage:) withObject:[NSArray arrayWithObjects:goodsInfo, indexStr, nil] waitUntilDone:NO];
            
            [_downloadProgressDic removeObjectForKey:indexStr];
        }];
        
        [_downloadProgressDic setObject:asyncDownloadOperation forKey:indexStr];
        [asyncDownloadOperation startDownload];
    }
}

- (void)updataHeaderImage:(NSArray*) array
{
    NSLog(@"更新图片");
    JBoOrderDetailGoodsInfo *goodsInfo = [array objectAtIndex:0];
    NSInteger index = [[array objectAtIndex:1] integerValue];
    
    if(self.currentIndex == index)
    {
        JBoSubmitEvaluteCell *cell = [self dequeueRecycledPage];
        cell.goodsImageView.image = goodsInfo.goodsImage;
    }
}

@end
