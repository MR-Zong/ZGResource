//
//  JBoEvaluteLevelView.m
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoEvaluteLevelView.h"

#define _iconStartTag_ 1000

@implementation JBoEvaluteLevelView

- (id)initWithFrame:(CGRect)frame title:(NSString *)title normalImage:(UIImage *)normalImage selectedImage:(UIImage *)selectedImage
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.normalImage = normalImage;
        self.selectedImage = selectedImage;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(titleSelected:)];
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _evaluteTitleWidth_, _evaluteIconSize_)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.userInteractionEnabled = YES;
        [_titleLabel addGestureRecognizer:tap];
        [tap release];
        _titleLabel.text = title;
        [self addSubview:_titleLabel];
        
        for(NSInteger i = 0; i < _evaluteIconCount_; i ++)
        {
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageViewTapped:)];
            UIImageView *imageView = [[UIImageView alloc] initWithImage:normalImage];
            imageView.frame = CGRectMake(_titleLabel.frame.origin.x + _titleLabel.frame.size.width + (_evaluteIconSize_ + _evaluteIconInterval_) * i, (frame.size.height - _evaluteIconSize_) / 2, _evaluteIconSize_, _evaluteIconSize_);
            imageView.userInteractionEnabled = YES;
            [imageView addGestureRecognizer:tapGesture];
            [tapGesture release];
            imageView.tag = _iconStartTag_ + i + 1;
            [self addSubview:imageView];
            [imageView release];
            
            
        }
        self.grade = 0;
        self.editable = YES;
    }
    
    return self;
}

- (void)setEditable:(BOOL)editable
{
    if(_editable != editable)
    {
        _editable = editable;
        self.userInteractionEnabled = _editable;
    }
}

- (void)imageViewTapped:(UITapGestureRecognizer*) tap
{
    UIImageView *imageView = (UIImageView*) tap.view;
    self.grade = imageView.tag - _iconStartTag_;
}

- (void)titleSelected:(UITapGestureRecognizer*) tap
{
    self.grade = 0;
}

- (void)setGrade:(NSInteger)grade
{
    if(_grade != grade)
    {
        _grade = grade;
        
        if([self.delegate respondsToSelector:@selector(evaluteLevelView:gradeDidChanged:)])
        {
            [self.delegate evaluteLevelView:self gradeDidChanged:self.grade];
        }
        
        if(_grade == 0)
        {
            for(NSInteger i = 1; i <= _evaluteIconCount_; i ++)
            {
                UIImageView *imageView = (UIImageView*)[self viewWithTag:i + _iconStartTag_];
                if([imageView isKindOfClass:[UIImageView class]])
                {
                    imageView.image = self.normalImage;
                }
            }
            return;
        }
        
        if(_grade > 0 && _grade <= _evaluteIconCount_)
        {
            for(NSInteger i = 1;i <= _grade; i ++)
            {
                UIImageView *imageView = (UIImageView*)[self viewWithTag:i + _iconStartTag_];
                if([imageView isKindOfClass:[UIImageView class]])
                {
                    imageView.image = self.selectedImage;
                }
            }
            for(NSInteger i = _grade + 1; i <= _evaluteIconCount_; i ++)
            {
                UIImageView *imageView = (UIImageView*)[self viewWithTag:i + _iconStartTag_];
                if([imageView isKindOfClass:[UIImageView class]])
                {
                    imageView.image = self.normalImage;
                }
            }
        }
    }
}

- (void)dealloc
{
    [_titleLabel release];
    [_normalImage release];
    [_selectedImage release];
    
    [super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touch began");
    
    //UITouch *touch = [touches anyObject];
//    CGPoint point = [touch locationInView:self];
//    NSLog(@"%f",point.x);
//    //[self selectGradeWithTouch:touch];
//    UIImageView *imageView = (UIImageView*) touch.view;
//    if([imageView isKindOfClass:[UIImageView class]])
//    {
//        self.grade = imageView.tag - _iconStartTag_;
//    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touch cancel");
    
  //  UITouch *touch = [touches anyObject];
   // [self selectGradeWithTouch:touch];
//    CGPoint point = [touch locationInView:self];
//    NSLog(@"%f",point.x);
//   
//    UIImageView *imageView = (UIImageView*) touch.view;
//    if([imageView isKindOfClass:[UIImageView class]])
//    {
//        self.grade = imageView.tag - _iconStartTag_;
//    }
}

//- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
//{
//    UITouch *touch = [touches anyObject];
//    UIImageView *imageView = (UIImageView*) touch.view;
//    if([imageView isKindOfClass:[UIImageView class]])
//    {
//        self.grade = imageView.tag - _iconStartTag_;
//    }
//}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    [self selectGradeWithTouch:touch];
}

- (void)selectGradeWithTouch:(UITouch*) touch
{
    CGPoint point = [touch locationInView:self];
    NSInteger tag = (point.x - _evaluteTitleWidth_) / (_evaluteIconSize_ + _evaluteIconInterval_);
    
    NSLog(@"%d",tag);
    if(tag > _evaluteIconCount_ || tag <= 0)
        return;
    
    UIImageView *imageView = (UIImageView*)[self viewWithTag:_iconStartTag_ + tag];
    NSLog(@"%@ - move %f",imageView,imageView.frame.origin.x);
    
    if([imageView isKindOfClass:[UIImageView class]])
    {
        self.grade = imageView.tag - _iconStartTag_;
    }
}

@end
