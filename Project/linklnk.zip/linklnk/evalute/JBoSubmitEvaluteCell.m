//
//  JBoEvaluteCell.m
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSubmitEvaluteCell.h"
#import "JBoBasic.h"
#import <QuartzCore/QuartzCore.h>

#define _goodsInfoViewHeight_ 100

#define _controlInterval_ 5
#define _controlHeight_ 20
#define _padding_ 20

#define _imageSize_ 80

@interface JBoSubmitEvaluteCell ()<JBoEvaluteLevelViewDelegate>

@property(nonatomic,assign) CGFloat keyboardHeight;
@property(nonatomic,assign) CGFloat scrollViewHeihgt;
@property(nonatomic,assign) BOOL keyboardHidden;

@end

@implementation JBoSubmitEvaluteCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
        
        _scrollView.bounces = YES;
        _scrollView.userInteractionEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator= NO;
        _scrollView.showsVerticalScrollIndicator= NO;
        [self addSubview:_scrollView];
        
        //好评选中 未选中
        _goodNormalImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"good_normal" ofType:_imageType_]];
        _goodSelectedImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"good_selected" ofType:_imageType_]];
        
        //差评选中 未选中
        _negativeNomalImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"neg_normal" ofType:_imageType_]];
        _negativeSelectedImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"neg_selected" ofType:_imageType_]];
        
        //加载商品信息视图
        [self loadGoodsInfoView];
        
        //加载评价视图
        [self loadEvaluteContentView];
        
        [_scrollView setContentSize:CGSizeMake(frame.size.width, _contentTextView.frame.origin.y + _contentTextView.frame.size.height + _padding_)];
        self.scrollViewHeihgt = _scrollView.frame.size.height;
        
        _reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyboard:)];
        [self addGestureRecognizer:_reconverGesture];
        
        self.keyboardHidden = YES;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardAppearance:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameChanged:) name:UIKeyboardDidChangeFrameNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDisappearrance:) name:UIKeyboardWillHideNotification object:nil];
        
        self.grade = 0;
    }
    return self;
}

- (void)dealloc
{
    [_scrollView release];
    
    [_negativeNomalImage release];
    [_negativeSelectedImage release];
    
    [_goodNormalImage release];
    [_goodSelectedImage release];
    
    [_reconverGesture release];
    
    [_goodsImageView release];
    [_nameLabel release];
    [_colorAndSizeLabel release];
    [_numLabel release];
    [_priceLabel release];
    
    [_negativeView release];
    [_goodView release];
    [_contentTextView release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super dealloc];
}

//回收键盘
- (void)reconverKeyboard:(UITapGestureRecognizer*) tap
{
    [_contentTextView resignFirstResponder];
}

- (void)getkeyboardHeightFromNotification:(NSNotification*) notification
{
    //获取键盘高度
    NSDictionary *dic = [notification userInfo];
    NSValue *keyboardValue = [dic objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [keyboardValue CGRectValue];
    self.keyboardHeight = keyboardRect.size.height;
    
    if(!self.keyboardHidden)
    {
        _scrollView.frame = CGRectMake(_scrollView.frame.origin.x, _scrollView.frame.origin.y, _scrollView.frame.size.width, self.scrollViewHeihgt - self.keyboardHeight);
        _scrollView.contentOffset = CGPointMake(0, _contentTextView.frame.origin.y - _padding_);
    }
}

- (void)keyboardAppearance:(NSNotification*) notification
{
    self.keyboardHidden = NO;
    _reconverGesture.enabled = YES;
    [self getkeyboardHeightFromNotification:notification];
}

- (void)keyboardFrameChanged:(NSNotification*) notification
{
     [self getkeyboardHeightFromNotification:notification];
}

- (void)keyboardDisappearrance:(NSNotification*) notification
{
    self.keyboardHidden = YES;
    _reconverGesture.enabled = NO;
    _scrollView.frame = CGRectMake(_scrollView.frame.origin.x, _scrollView.frame.origin.y, _scrollView.frame.size.width, self.scrollViewHeihgt);
    _scrollView.contentOffset = CGPointMake(0, 0);
}


- (void)loadGoodsInfoView
{
    _goodsImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_padding_, (_goodsInfoViewHeight_ - _imageSize_) / 2 + _padding_, _imageSize_, _imageSize_)];
    _goodsImageView.userInteractionEnabled = YES;
    [_scrollView addSubview:_goodsImageView];
    
    CGFloat textWidth = _width_ - _goodsImageView.frame.origin.x - _goodsImageView.frame.size.width - _padding_ * 2;
    
    _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_goodsImageView.frame.origin.x + _goodsImageView.frame.size.width + _controlInterval_, _goodsImageView.frame.origin.y, textWidth, 45)];
    _nameLabel.font = [UIFont fontWithName:@"Avenir-Heavy" size:15];
    _nameLabel.numberOfLines = 0;
    _nameLabel.backgroundColor = [UIColor clearColor];
    [_scrollView addSubview:_nameLabel];
    
    _colorAndSizeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.size.height + _nameLabel.frame.origin.y, textWidth, _controlHeight_)];
    _colorAndSizeLabel.textColor = [UIColor grayColor];
    _colorAndSizeLabel.font = [UIFont systemFontOfSize:14];
    [_scrollView addSubview:_colorAndSizeLabel];
    
    UIFont *numFont = [UIFont systemFontOfSize:14];
    
    UILabel *numLabel = [[UILabel alloc] initWithFrame:CGRectMake(_colorAndSizeLabel.frame.origin.x, _colorAndSizeLabel.frame.origin.y + _colorAndSizeLabel.frame.size.height, 35, _controlHeight_)];
    numLabel.textColor = [UIColor grayColor];
    numLabel.text = @"数量:";
    numLabel.font = numFont;
    numLabel.backgroundColor = [UIColor clearColor];
    [_scrollView addSubview:numLabel];
    [numLabel release];
    
    _numLabel = [[UILabel alloc] initWithFrame:CGRectMake(numLabel.frame.origin.x + numLabel.frame.size.width, numLabel.frame.origin.y, 60, _controlHeight_)];
    _numLabel.backgroundColor = [UIColor clearColor];
    [_numLabel setTextAlign:JBoTextAlignmentCenter];
    
    _numLabel.userInteractionEnabled = YES;
    _numLabel.font = numFont;
    [_scrollView addSubview:_numLabel];
    
    _priceLabel = [[UILabel alloc] initWithFrame:CGRectMake(_numLabel.frame.origin.x + _numLabel.frame.size.width, _numLabel.frame.origin.y, textWidth - _numLabel.frame.size.width - numLabel.frame.size.width, _controlHeight_)];
    _priceLabel.textColor = [UIColor colorWithRed:_priceColorR_ green:_priceColorG_ blue:_priceColorB_ alpha:1.0];
    _priceLabel.backgroundColor = [UIColor clearColor];
    _priceLabel.font = [UIFont fontWithName:_priceFontName_ size:14];
    [_priceLabel setTextAlign:JBoTextAlignmentRight];
    
    [_scrollView addSubview:_priceLabel];
}

//加载评价内容
- (void)loadEvaluteContentView
{
    _goodView = [[JBoEvaluteLevelView alloc] initWithFrame:CGRectMake(_padding_, _priceLabel.frame.origin.y + _priceLabel.frame.size.height + _padding_, _evaluteViewWidth_, _evaluteIconSize_) title:@"好评" normalImage:_goodNormalImage selectedImage:_goodSelectedImage];
    _goodView.delegate = self;
    [_scrollView addSubview:_goodView];
    
    _negativeView = [[JBoEvaluteLevelView alloc] initWithFrame:CGRectMake(_goodView.frame.origin.x, _goodView.frame.origin.y + _goodView.frame.size.height + _controlInterval_, _evaluteViewWidth_, _evaluteIconSize_) title:@"差评" normalImage:_negativeNomalImage selectedImage:_negativeSelectedImage];
    _negativeView.delegate = self;
    [_scrollView addSubview:_negativeView];
    
    _contentTextView = [[SSTextView alloc] initWithFrame:CGRectMake(_goodView.frame.origin.x, _negativeView.frame.origin.y + _negativeView.frame.size.height + _controlInterval_, _width_ - _goodView.frame.origin.x * 2, 70)];
    _contentTextView.placeholder = @"在这里写评价";
    _contentTextView.layer.cornerRadius = 6;
    _contentTextView.layer.borderWidth = 0.2;
    _contentTextView.layer.borderColor = [UIColor grayColor].CGColor;
    _contentTextView.font = [UIFont systemFontOfSize:17];
    _contentTextView.delegate = self;
    [_scrollView addSubview:_contentTextView];
}

//JBoEvaluteLevelView代理
- (void)evaluteLevelView:(JBoEvaluteLevelView *)evaluteLevelView gradeDidChanged:(NSInteger)grade
{
    if(evaluteLevelView == _goodView && grade > 0)
    {
        self.grade = grade;
        _negativeView.grade = 0;
    }
    
    if(evaluteLevelView == _negativeView && grade > 0)
    {
        self.grade = - grade;
        _goodView.grade = 0;
    }
    
    if([self.delegate respondsToSelector:@selector(evaluteCellgradeDidChanged:)])
    {
        [self.delegate evaluteCellgradeDidChanged:self];
    }
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if([self.delegate respondsToSelector:@selector(evaluteCellDidBeganEdit:)])
    {
        [self.delegate evaluteCellDidBeganEdit:self];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    if([self.delegate respondsToSelector:@selector(evaluteCellDidEndedEdit:)])
    {
        [self.delegate evaluteCellDidEndedEdit:self];
    }
}

@end
