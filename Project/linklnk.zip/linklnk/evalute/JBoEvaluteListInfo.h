//
//  JBoEvaluteListInfo.h
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JBoEvaluteListInfo : NSObject

//评论ID 评论人
@property(nonatomic,copy) NSString *evaluteID;
@property(nonatomic,copy) NSString *userName;

//评论内容 时间
@property(nonatomic,copy) NSString *evaluteContent;
@property(nonatomic,copy) NSString *evaluteDate;

//差评 好评
@property(nonatomic,assign) NSInteger grade;

@end
