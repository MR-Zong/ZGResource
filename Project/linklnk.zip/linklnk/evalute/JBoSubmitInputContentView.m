//
//  JBoSubmitCommentView.m
//  连客
//
//  Created by kinghe005 on 13-12-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSubmitInputContentView.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoKeyboardButton.h"
#import "JBoBasic.h"

#define _blackBgViewHeight_ 50
#define _padding_ 20

@interface JBoSubmitInputContentView ()<UITextViewDelegate>


@property(nonatomic,assign) BOOL keyboardHidden;

@end

@implementation JBoSubmitInputContentView

- (id)initWithFrame:(CGRect)frame maxCommentCount:(NSInteger)maxCount
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardAppearance:) name:UIKeyboardWillShowNotification object:nil];
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameChanged:) name:UIKeyboardDidChangeFrameNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDisappearrance:) name:UIKeyboardWillHideNotification object:nil];
        
        _blackBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, _blackBgViewHeight_)];
        _blackBgView.userInteractionEnabled = YES;
        _blackBgView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.4];
        _blackBgView.hidden = YES;
        [self addSubview:_blackBgView];
        
        _whiteBgView = [[UIView alloc] initWithFrame:CGRectMake(0, _blackBgView.frame.origin.y + _blackBgView.frame.size.height, self.frame.size.width, self.frame.size.height - _blackBgViewHeight_)];
        _whiteBgView.userInteractionEnabled = YES;
        _whiteBgView.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        [self addSubview:_whiteBgView];
        
        _newsCommentTextView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, self.frame.size.width - _padding_ * 2, 80)];
        _newsCommentTextView.layer.cornerRadius = 6;
        _newsCommentTextView.layer.borderWidth = 0.2;
        _newsCommentTextView.layer.borderColor = [UIColor grayColor].CGColor;
        _newsCommentTextView.font = [UIFont systemFontOfSize:17];
        _newsCommentTextView.delegate = self;
        _newsCommentTextView.limitable = YES;
        _newsCommentTextView.returnKeyType = UIReturnKeyDone;
        _newsCommentTextView.maxCount = maxCount;
        [_whiteBgView addSubview:_newsCommentTextView];
        
        
        //回收键盘
        _reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyboard:)];
        [_blackBgView addGestureRecognizer:_reconverGesture];
        
        self.keyboardHidden = YES;
        
        
    }
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoSubmitCommentView dealloc");
    [_newsCommentTextView release];
    
    [_reconverGesture release];
    [_blackBgView release];
    [_whiteBgView release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super dealloc];
}

- (void)beginComment
{
    if(self.keyboardHidden)
    {
        [_newsCommentTextView becomeFirstResponder];
    }
    else
    {
        [_newsCommentTextView resignFirstResponder];
    }
}


//textView代理

- (void)textViewDidChange:(UITextView *)textView
{
    int length = (int)(_newsCommentTextView.maxCount - textView.text.length);
    // NSLog(@"length = %d",length);
    _newsCommentTextView.numLabel.text = [NSString stringWithFormat:@"%d",length < 0 ? 0 : length];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        [self finishAction:nil];
        return NO;
    }
    
    NSString *new = [textView.text stringByReplacingCharactersInRange:range withString:text];
    NSInteger res = _newsCommentTextView.maxCount - new.length;
    
    _newsCommentTextView.numLabel.text = [NSString stringWithFormat:@"%d",(int)(res < 0 ? 0 : res)];
    
    if(res > 0)
    {
        return YES;
    }
    else
    {
        NSString *str = [textView.text stringByAppendingString:text];
        NSInteger index = _newsCommentTextView.maxCount >= str.length ? str.length : _newsCommentTextView.maxCount;
        
        NSString *subStr = [str substringToIndex:index];
        textView.text = subStr;
        
        return NO;
    }
}


//完成
- (void)finishAction:(id)sender
{
    [_newsCommentTextView resignFirstResponder];
    if([self.delegate respondsToSelector:@selector(submitDidFinished:)])
    {
        [self.delegate submitDidFinished:_newsCommentTextView.text];
    }
     _newsCommentTextView.text = @"";
}

//回收键盘
- (void)reconverKeyboard:(UITapGestureRecognizer*) tap
{
    [_newsCommentTextView resignFirstResponder];
}

- (void)getkeyboardHeightFromNotification:(NSNotification*) notification
{
    //获取键盘高度
    NSDictionary *dic = [notification userInfo];
//    NSValue *keyboardValue = [dic objectForKey:UIKeyboardFrameEndUserInfoKey];
//    CGRect keyboardRect = [keyboardValue CGRectValue];
    
    CGFloat height = self.keyboardHidden ? _height_ : 0;
    
    if(self.keyboardHidden)
    {
        if([self.delegate respondsToSelector:@selector(submitViewWillDismiss:)])
        {
            [self.delegate respondsToSelector:@selector(submitViewWillDismiss:)];
        }
    }
    
    NSNumber *animateDurationNumber = [dic objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    CGFloat animateDuration = [animateDurationNumber floatValue];
    
    [UIView animateWithDuration:animateDuration animations:^(void)
    {
        self.frame = CGRectMake(self.frame.origin.x, height, self.frame.size.width, self.frame.size.height);
    }completion:^(BOOL finish)
    {
        if(finish)
        {
            _blackBgView.hidden = self.keyboardHidden;
        }
    }];
}

- (void)keyboardAppearance:(NSNotification*) notification
{
    self.keyboardHidden = NO;
    _reconverGesture.enabled = YES;
    [self getkeyboardHeightFromNotification:notification];
}

//- (void)keyboardFrameChanged:(NSNotification*) notification
//{
//   // [self getkeyboardHeightFromNotification:notification];
//}

- (void)keyboardDisappearrance:(NSNotification*) notification
{
    self.keyboardHidden = YES;
    _reconverGesture.enabled = NO;
    [self getkeyboardHeightFromNotification:notification];
}

@end
