//
//  JBoJBoEvaluteLevelStatusView.m
//  连客
//
//  Created by kinghe005 on 13-12-23.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoEvaluteLevelStatusView.h"
#import "JBoBasic.h"

@interface JBoEvaluteLevelStatusView ()

@property(nonatomic,retain) UIImage *goodImage;
@property(nonatomic,retain) UIImage *negativeImage;
@end

@implementation JBoEvaluteLevelStatusView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.goodImage = [UIImage imageNamed:@"good_selected.png"];
        self.negativeImage = [UIImage imageNamed:@"neg_selected.png"];
        
    }
    return self;
}

- (void)setGrade:(NSInteger)grade
{
    if(_grade != grade)
    {
        _grade = grade;
        for(UIView *view in self.subviews)
        {
            if([view isKindOfClass:[UIImageView class]])
            {
                [view removeFromSuperview];
            }
        }
        
        UIImage *image = _grade > 0 ? self.goodImage : self.negativeImage;
        NSLog(@"%@",image);
        
        for(NSInteger i = 0;i < _grade;i ++)
        {
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i * (_evaluteIconSize_ + _evaluteIconInterval_), (self.frame.size.height - _evaluteIconSize_) / 2, _evaluteIconSize_, _evaluteIconSize_)];
            imageView.image = image;
            [self addSubview:imageView];
            [imageView release];
        }
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
