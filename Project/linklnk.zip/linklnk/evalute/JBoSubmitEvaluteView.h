//
//  JBoEvaluteView.h
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>



@protocol JBoEvaluteViewDelegate <NSObject>


@end

@interface JBoSubmitEvaluteView : UIView<UIScrollViewDelegate>
{
    UIScrollView *_scrollView;
    
    NSMutableSet *_recyleViews;
    NSMutableSet *_visibleViews;
    
    UIPageControl *_pageControl;
}
//数据源 元素是 评价内容
@property(nonatomic,retain) NSArray *srcArray;

@property(nonatomic,assign) id<JBoEvaluteViewDelegate> delegate;



@end
