//
//  JBoEvaluteListInfo.m
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoEvaluteListInfo.h"

@implementation JBoEvaluteListInfo

- (void)dealloc
{
    [_evaluteID release];
    [_userName release];
    
    [_evaluteContent release];
    [_evaluteDate release];
    
    [super dealloc];
}
@end
