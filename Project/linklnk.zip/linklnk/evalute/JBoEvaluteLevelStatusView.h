//
//  JBoJBoEvaluteLevelStatusView.h
//  连客
//
//  Created by kinghe005 on 13-12-23.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _evaluteLevelStatusViewWidth_ (_evaluteIconSize_ + _evaluteIconInterval_) * _evaluteIconCount_

@interface JBoEvaluteLevelStatusView : UIView


@property(nonatomic,assign) NSInteger grade;
@end
