//
//  JBoEvaluteCell.h
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoEvaluteLevelView.h"
#import "SSTextView.h"

@class JBoSubmitEvaluteCell;

@protocol JBoSubmitEvaluteCellDelegate <NSObject>

//开始编辑 结束编辑
- (void)evaluteCellDidBeganEdit:(JBoSubmitEvaluteCell*) cell;
- (void)evaluteCellDidEndedEdit:(JBoSubmitEvaluteCell *)cell;
- (void)evaluteCellgradeDidChanged:(JBoSubmitEvaluteCell *)cell;

@end

@interface JBoSubmitEvaluteCell : UIView<UITextViewDelegate>
{
    UIScrollView *_scrollView;
    
    //好评选中 未选中
    UIImage *_goodNormalImage;
    UIImage *_goodSelectedImage;
    
    //差评选中 未选中
    UIImage *_negativeNomalImage;
    UIImage *_negativeSelectedImage;
    
    //回收键盘
    UITapGestureRecognizer *_reconverGesture;
    
}
//商品图片 名称
@property(nonatomic,readonly) UIImageView *goodsImageView;
@property(nonatomic,readonly) UILabel *nameLabel;

//商品颜色 尺寸
@property(nonatomic,readonly) UILabel *colorAndSizeLabel;

//商品价格 数量
@property(nonatomic,readonly) UILabel *priceLabel;
@property(nonatomic,readonly) UILabel *numLabel;

//差评 好评
@property(nonatomic,readonly)JBoEvaluteLevelView *negativeView;
@property(nonatomic,readonly)JBoEvaluteLevelView *goodView;

//评分
@property(nonatomic,assign) NSInteger grade;

//评价内容
@property(nonatomic,readonly) SSTextView *contentTextView;

@property(nonatomic,assign) id<JBoSubmitEvaluteCellDelegate> delegate;

@property(nonatomic,assign) NSInteger index;

@end
