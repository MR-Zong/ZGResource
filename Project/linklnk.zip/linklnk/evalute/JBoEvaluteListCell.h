//
//  JBoEvaluteListCell.h
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoEvaluteLevelStatusView.h"

#define _evaluteListCellHeight_ 70
#define _evaluteContentWidht_ (_width_ - 75)
#define _evaluteContentHeight_ 25

@interface JBoEvaluteListCell : UITableViewCell
{
    UILabel *_contentLabel;
}
//用户头像 昵称
@property(nonatomic,readonly) UIImageView *userImageView;
@property(nonatomic,readonly) UILabel *nameLabel;

//好评 差评
@property(nonatomic,readonly) JBoEvaluteLevelStatusView *evaluteLevelStatusView;

//内容 时间
@property(nonatomic,copy) NSString *content;
@property(nonatomic,readonly) UILabel *dateLabel;

@end
