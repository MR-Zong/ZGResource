//
//  JBoEvaluteListCell.m
//  连客
//
//  Created by kinghe005 on 13-12-21.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoEvaluteListCell.h"
#import "JBoBasic.h"
#import "JBoImageTextTool.h"

#define _imageSize_ 60
#define _controlHeight_ 30
#define _controlInterval_ 5

@interface JBoEvaluteListCell ()

@property(nonatomic,assign) CGFloat contentWordHeight;
@property(nonatomic,retain) UIFont *contentFont;
@end

@implementation JBoEvaluteListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.contentFont = [UIFont systemFontOfSize:17];
        self.contentWordHeight = [JBoImageTextTool getFontSize:self.contentFont withString:@"我"].height;
        
        UIImage *image = [UIImage imageNamed:@"evalute_head.png"];
        _userImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_controlInterval_, _controlInterval_, _imageSize_, _imageSize_)];
        _userImageView.image = image;
        [self.contentView addSubview:_userImageView];
        
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_userImageView.frame.origin.x + _userImageView.frame.size.width + _controlInterval_, _userImageView.frame.origin.y, _width_ - _userImageView.frame.origin.x - _userImageView.frame.size.width - _controlInterval_, _controlHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        _evaluteLevelStatusView = [[JBoEvaluteLevelStatusView alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.size.height + _nameLabel.frame.origin.y, _evaluteLevelStatusViewWidth_, _controlHeight_)];
        [self.contentView addSubview:_evaluteLevelStatusView];
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(_evaluteLevelStatusView.frame.origin.x + _evaluteLevelStatusView.frame.size.width, _evaluteLevelStatusView.frame.origin.y, _width_ - _evaluteLevelStatusView.frame.origin.x - _evaluteLevelStatusView.frame.size.width - _controlInterval_, _controlHeight_)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        _dateLabel.font = [UIFont systemFontOfSize:13];
        _dateLabel.textColor = [UIColor grayColor];
        [self.contentView addSubview:_dateLabel];
        
        _contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _dateLabel.frame.origin.y + _dateLabel.frame.size.height, _nameLabel.frame.size.width , _evaluteContentHeight_)];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.font = self.contentFont;
        _contentLabel.numberOfLines = 0;
        [self.contentView addSubview:_contentLabel];
                                                                  
    }
    return self;
}

- (void)dealloc
{
    [_userImageView release];
    [_nameLabel release];
    [_evaluteLevelStatusView release];
    
    [_content release];
    [_dateLabel release];
    [_contentLabel release];
    
    [_contentFont release];
    
    [super dealloc];
}

- (void)setContent:(NSString *)content
{
    if(_content != content)
    {
        [_content release];
        _content = [content copy];
       
        CGSize size = [JBoImageTextTool getStringSize:content withFont:self.contentFont andContraintSize:CGSizeMake(_contentLabel.frame.size.width, _height_)];
        
        NSInteger lines = size.height / self.contentWordHeight;
        
        _contentLabel.frame = CGRectMake(_contentLabel.frame.origin.x, _contentLabel.frame.origin.y, _contentLabel.frame.size.width, _evaluteContentHeight_ * lines);
        _contentLabel.text = _content;
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
