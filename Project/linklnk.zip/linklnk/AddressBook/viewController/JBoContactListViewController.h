//
//  KingHeContactListViewController.h
//  微喂
//
//  Created by kinghe005 on 13-8-21.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoAddressBookOperation.h"

/**好友列表
 */
@interface JBoContactListViewController : UIViewController

/**用户昵称首字母关键字 数组元素是NSString对象
 */
@property(nonatomic,readonly) NSMutableArray *keywordArray; //表示图header的数据

/**key 是首字母关键字，value是数组，数组元素是 JBoRosterInfo对象
 */
@property(nonatomic,readonly) NSMutableDictionary *rosterDic;  //花名册

/**通讯录数据库操作
 */
@property(nonatomic,readonly) JBoAddressBookOperation *addressBookOperation;

//获取花名册
- (void)getRosterListFromLocation;

//获取黑名单
- (void)getBlacklist;

@end
