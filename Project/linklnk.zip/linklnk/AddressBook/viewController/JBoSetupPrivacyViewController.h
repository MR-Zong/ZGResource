//
//  JBoSetupPrivacyViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-18.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserDetailInfo.h"

/**隐私设置，靓友圈可见
 */
@interface JBoSetupPrivacyViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *_tableView;
    NSArray *_srcArray;
}

/**用户信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

@end
