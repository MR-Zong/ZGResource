 //
//  KingHeContactListViewController.m
//  微喂
//
//  Created by kinghe005 on 13-8-21.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoContactListViewController.h"
#import "JBoAppDelegate.h"
#import "JBoAssociatedUsersView.h"
#import "JBoContactListView.h"
#import "JBoAddContactViewController.h"


//搜索栏高度
#define _searchBarHeight_ 40


@interface JBoContactListViewController ()
{
    JBoAppDelegate *_appDelegate;
}

/**导航栏titleView
 */
@property(nonatomic,retain) UISegmentedControl *seg;

//关注的人
@property(nonatomic,retain) JBoAssociatedUsersView *associatedUsersView;\

//联系人
@property(nonatomic,retain) JBoContactListView *contactListView;

@end

@implementation JBoContactListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        JBoContactListView *contactListView = [[JBoContactListView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        self.contactListView = contactListView;
        [contactListView release];
    }
    return self;
}

#pragma mark- property

- (NSMutableArray*)keywordArray
{
    return self.contactListView.keywordArray;
}

- (NSMutableDictionary*)rosterDic
{
    return self.contactListView.rosterDic;
}

- (JBoAddressBookOperation*)addressBookOperation
{
    return self.contactListView.addressBookOperation;
}

#pragma mark- public method

//获取花名册
- (void)getRosterListFromLocation
{
    [self.contactListView getRosterListFromLocation];
}

- (void)getBlacklist
{
    [self.contactListView getBlacklist];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoContactListViewController dealloc");
    
    [_seg release];
    [_associatedUsersView release];
    [_contactListView release];

    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [_appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
    [_appDelegate hiddenCustomTabBar:NO];
    [self.contactListView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
 
    [_appDelegate hiddenCustomTabBar:YES];
}

- (void)valueDidChanged:(UISegmentedControl*) seg
{
    switch (seg.selectedSegmentIndex)
    {
        case 0 :
        {
            self.contactListView.hidden = NO;
            self.associatedUsersView.hidden = YES;
            [self.view bringSubviewToFront:self.associatedUsersView];
        }
            break;
        case 1 :
        case 2 :
        {
            self.contactListView.hidden = YES;
            self.associatedUsersView.hidden = NO;
            
            if(!self.associatedUsersView)
            {
                JBoAssociatedUsersView *associatedUsersView = [[JBoAssociatedUsersView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _tabBarHeight_)];
                associatedUsersView.black = NO;
                associatedUsersView.seg = self.seg;
                associatedUsersView.navigationController = self.navigationController;
                [self.view addSubview:associatedUsersView];
                self.associatedUsersView = associatedUsersView;
                [associatedUsersView release];
            }
            
            [self.associatedUsersView valueDidChanged:seg];
            
            [self.view bringSubviewToFront:self.contactListView];
        }
            break;
        default:
            break;
    }
}


#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    [self loadInitView];
}

//加载视图
- (void)loadInitView
{
    //设置导航条背景
    [JBoNavigatioinBarOperation setDefaultNavigationBar:self.navigationController.navigationBar];
    
    //创建导航条右边的按钮
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(addContactBarButtonItemAction) title:nil backgroundImage:[UIImage imageNamed:@"addContact_btn.png"] textColor:nil];
    
    [self.view addSubview:self.contactListView];
    self.contactListView.navigationController = self.navigationController;
    
    CGFloat width = 200.0;
    CGFloat height = 30.0;
    
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 260.0, height)];
    titleView.backgroundColor = [UIColor clearColor];
    
    UIColor *tintColor = [UIColor colorWithWhite:0 alpha:0.7];
    NSDictionary *selectedDic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, [UIFont systemFontOfSize:13.0], UITextAttributeFont, nil];
    NSDictionary *norlmalDic = [NSDictionary dictionaryWithObjectsAndKeys:tintColor, UITextAttributeTextColor, [UIFont systemFontOfSize:13.0], UITextAttributeFont, nil];
    
    self.seg = [[[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"通讯录", @"我关注的", @"关注我的", nil]] autorelease];
    self.seg.frame = CGRectMake(0, 0, width, height);
    self.seg.tintColor = tintColor;
    [self.seg addTarget:self action:@selector(valueDidChanged:) forControlEvents:UIControlEventValueChanged];
    self.seg.selectedSegmentIndex = 0;
    
    [self.seg setTitleTextAttributes:selectedDic forState:UIControlStateSelected];
    [self.seg setTitleTextAttributes:norlmalDic forState:UIControlStateNormal];
    [titleView addSubview:self.seg];
    
    self.navigationItem.titleView = titleView;
    [titleView release];
    
    [self valueDidChanged:self.seg];
}

//添加联系人
- (void)addContactBarButtonItemAction
{
    JBoAddContactViewController *addContactVC = [[JBoAddContactViewController alloc] init];
    addContactVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:addContactVC animated:YES];
    [addContactVC release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    NSLog(@"收到内存警告");
    // Dispose of any resources that can be recreated.
}

@end
