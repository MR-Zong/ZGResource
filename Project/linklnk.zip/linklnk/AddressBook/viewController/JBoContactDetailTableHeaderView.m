//
//  JBoContactDetailTableHeaderView.m
//  连你
//
//  Created by kinghe005 on 14-2-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoContactDetailTableHeaderView.h"
#import "JBoImageTextTool.h"
#import <CoreText/CoreText.h>
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"

@implementation JBoContactDetailTableHeaderView


#pragma mark- Private Method

//改变好友名称样式
- (void)changeNameLabel
{
    if(![NSString isEmpty:self.userDetailInfo.rosterInfo.remark])
    {
        NSString *name = [NSString stringWithFormat:@"(%@)",[NSString isEmpty:self.userDetailInfo.rosterInfo.name] ? @"" : self.userDetailInfo.rosterInfo.name];
        
        CTFontRef remarkFont = CTFontCreateWithName((CFStringRef)_userNameFontName_, _userNameFontSize_, NULL);
        CTFontRef nameFont = CTFontCreateWithName((CFStringRef)@"STHeitiSC-Light", 13.0, NULL);
        
        NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@",self.userDetailInfo.rosterInfo.remark, name]];
        
        
        [str addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)self.nameLabel.textColor.CGColor range:NSMakeRange(0, self.userDetailInfo.rosterInfo.remark.length)];
        [str addAttribute:(NSString*)kCTFontAttributeName value:(id)remarkFont range:NSMakeRange(0, self.userDetailInfo.rosterInfo.remark.length)];
        
        [str addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)[UIColor grayColor].CGColor range:NSMakeRange(self.userDetailInfo.rosterInfo.remark.length, name.length)];
        [str addAttribute:(NSString*)kCTFontAttributeName value:(id)nameFont range:NSMakeRange(self.userDetailInfo.rosterInfo.remark.length, name.length)];
        
        CGSize size = [JBoImageTextTool getHeightFromAttributedText:str contraintWidth:self.nameLabel.width];
        
        CGRect frame = self.nameLabel.frame;
        frame.origin.y = self.headImageView.top + (self.headImageView.height - size.height) / 2.0;
        frame.size.height = size.height;
        self.nameLabel.frame = frame;
        
        self.nameLabel.attributedText_5 = str;

        
        [str release];
        CFRelease(remarkFont);
        CFRelease(nameFont);
    }
}


@end
