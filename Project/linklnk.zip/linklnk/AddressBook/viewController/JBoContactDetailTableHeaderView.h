//
//  JBoContactDetailTableHeaderView.h
//  连你
//
//  Created by kinghe005 on 14-2-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserInfoTableHeaderView.h"

/**好友资料
 */
@interface JBoContactDetailTableHeaderView : JBoUserInfoTableHeaderView

/**改变昵称
 */
- (void)changeNameLabel;

@end
