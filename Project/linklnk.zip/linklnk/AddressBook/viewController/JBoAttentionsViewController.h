//
//  JBoAttentionsViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-7-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**关注的人列表
 */
@interface JBoAttentionsViewController : JBoViewController

@end
