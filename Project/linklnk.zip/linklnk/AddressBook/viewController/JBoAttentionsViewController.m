//
//  JBoAttentionsViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-7-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAttentionsViewController.h"
#import "JBoHttpRequest.h"
#import "JBoAttentionsCell.h"
#import "JBoAttentionOperation.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoFileManager.h"
#import "ChineseToPinyin.h"
#import "JBoBottomLoadingView.h"
#import "JBoImageCacheTool.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoQRCodeGenerateViewController.h"
#import "JBoUserOperation.h"

#define _attentionTag_ 1
#define _attentionCountTag_ 2
#define _fansTag_ 3
#define _fansCountTag_ 4
#define _cancellAttentionTag_ 5

@interface JBoAttentionsViewController ()<EGORefreshTableHeaderDelegate,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
{
    JBoImageCacheTool *_imageCacheTool;
}
//网络请求队列
@property(nonatomic,retain) ASINetworkQueue *httpQueue;

//关注的人和我关注的人选择
@property(nonatomic,retain) UISegmentedControl *seg;

//我关注的人
@property(nonatomic,retain) NSMutableArray *attentions;
@property(nonatomic,assign) BOOL attentionsRequest;
@property(nonatomic,assign) BOOL attentionsHasInfo;
@property(nonatomic,assign) NSInteger attentionCount;
@property(nonatomic,assign) int attentionsPageIndex;

//关注我的人
@property(nonatomic,retain) NSMutableArray *fansArray;
@property(nonatomic,assign) BOOL fansHasInfo;
@property(nonatomic,assign) BOOL fansRequest;
@property(nonatomic,assign) int fansPageIndex;
@property(nonatomic,assign) NSInteger fansCount;

//搜索栏
@property(nonatomic,retain) UISearchBar *searchBar;
@property(nonatomic,retain) NSMutableArray *searchResultArray;
@property(nonatomic,assign) BOOL searching;

//黑色半透明视图
@property(nonatomic,retain) UIView *transparentView;

//数据列表
@property(nonatomic,retain) UITableView *tableView;

//下拉刷新
@property(nonatomic,retain) EGORefreshTableHeaderView *refreshView;
@property(nonatomic,assign) BOOL isLoading;

@end

@implementation JBoAttentionsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.attentions = [NSMutableArray array];
        self.fansArray = [NSMutableArray array];
        self.attentionsHasInfo = YES;
        self.fansHasInfo = YES;
        
        self.attentionsPageIndex = 1;
        self.fansPageIndex = 1;
        
        _imageCacheTool = [[JBoImageCacheTool alloc] init];
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_imageCacheTool release];

    [_httpQueue reset];
    [_httpQueue release];
    
    [_seg release];
    
    [_attentions release];
    [_fansArray release];
    
    [_searchBar release];
    [_searchResultArray release];
    
    [_transparentView release];
    
    [_tableView release];
    [_refreshView release];
    
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.appDelegate hiddenCustomTabBar:NO];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.appDelegate hiddenCustomTabBar:YES];
    if(self.attentionsRequest || self.fansRequest)
    {
        self.appDelegate.dataLoadingView.hidden = YES;
    }
}


#pragma mark- 加载视图

//扫二维码
- (void)qrCode
{
    JBoQRCodeGenerateViewController *qrCode = [[JBoQRCodeGenerateViewController alloc] init];
    [self.navigationController pushViewController:qrCode animated:YES];
    [qrCode release];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setGreenNavigationBar];
    [self setRightBarItemWithTitle:@"扫" action:@selector(qrCode)];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = _attentionsCellHeight_;
    tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
    
    [self setTableFooter];
    
    //下拉刷新
    EGORefreshTableHeaderView *refreshView = [[EGORefreshTableHeaderView alloc] initWithFrame:_tableView.frame];
    refreshView.delegate = self;
    refreshView.hidden = YES;
    [self.view insertSubview:refreshView belowSubview:_tableView];
    self.refreshView = refreshView;
    [refreshView release];
    
    //创建搜索栏背
    UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, 40.0)];
    if(!_ios7_0_)
    {
        searchBar.tintColor = _searchBarColor_;
    }
    
    searchBar.placeholder = @"搜索";
    searchBar.delegate = self;
    self.tableView.tableHeaderView = searchBar;
    self.searchBar = searchBar;
    [searchBar release];
    
    
    CGFloat width = 150.0;
    CGFloat height = 30.0;
    
     //关注的人和我关注的人
    UIColor *tintColor = [UIColor colorWithWhite:0 alpha:0.5];
    NSDictionary *selectedDic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, [UIFont systemFontOfSize:13.0], UITextAttributeFont, nil];
    NSDictionary *norlmalDic = [NSDictionary dictionaryWithObjectsAndKeys:tintColor, UITextAttributeTextColor, [UIFont systemFontOfSize:13.0], UITextAttributeFont, nil];
    
    self.seg = [[[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"我关注的", @"关注我的", nil]] autorelease];
    self.seg.frame = CGRectMake(0, 0, width, height);
    self.seg.tintColor = tintColor;
    [self.seg addTarget:self action:@selector(valueDidChanged:) forControlEvents:UIControlEventValueChanged];
    self.seg.selectedSegmentIndex = 0;
    [self.seg setTitleTextAttributes:selectedDic forState:UIControlStateSelected];
    [self.seg setTitleTextAttributes:norlmalDic forState:UIControlStateNormal];
    
    self.navigationItem.titleView = self.seg;
    
    [self valueDidChanged:self.seg];
}

- (void)setTableFooter
{
    self.tableView.tableFooterView = nil;
    UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tabBarHeight_)];
    footer.backgroundColor = [UIColor clearColor];
    self.tableView.tableFooterView = footer;
    [footer release];
}

- (void)valueDidChanged:(UISegmentedControl*) seg
{
    switch (seg.selectedSegmentIndex)
    {
        case 0 :
        {
            [self loadAttentions:NO];
            [self getAttentionsCount];
        }
            break;
        case 1 :
        {
            [self loadFans:NO];
            [self getFansCount];
        }
            break;
        default:
            break;
    }
}

- (void)setAttentionsCount
{
    if(self.seg.selectedSegmentIndex == 0)
    {
        NSInteger count = (self.attentionCount == NSNotFound || self.attentionCount < 0) ? 0 : self.attentionCount;
        _searchBar.placeholder = [NSString stringWithFormat:@"搜索 (共%d人)", (int)count];
    }
}

- (void)setFanCount
{
    if(self.seg.selectedSegmentIndex == 1)
    {
        NSInteger count = (self.fansCount == NSNotFound || self.fansCount < 0) ? 0 : self.fansCount;
        _searchBar.placeholder = [NSString stringWithFormat:@"搜索 (共%d人)", (int)count];
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    [_refreshView removeFromSuperview];
    if(!_transparentView)
    {
        self.searchResultArray = [[[NSMutableArray alloc] init] autorelease];
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + searchBar.height : searchBar.height;
        
        UIView *transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [transparentView addGestureRecognizer:tap];
        transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self.view addSubview:transparentView];
        self.transparentView = transparentView;
        [transparentView release];
        [tap release];
    }
    _transparentView.hidden = NO;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [_searchBar setShowsCancelButton:YES animated:YES];
    
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
    [self.view insertSubview:_refreshView belowSubview:_tableView];
}


//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        
        switch (self.seg.selectedSegmentIndex)
        {
            case 0 :
            {
                [_searchResultArray removeAllObjects];
                for(JBoUserDetailInfo *info in self.attentions)
                {
                    if([self pinyin:pinyin match:info.rosterInfo.name])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
                
                for(JBoUserDetailInfo *info in self.attentions)
                {
                    if([self chinese:content match:info.rosterInfo.name] && ![_searchResultArray containsObject:info])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
            }
                break;
            case 1 :
            {
                [_searchResultArray removeAllObjects];
                for(JBoUserDetailInfo *info in self.fansArray)
                {
                    if([self pinyin:pinyin match:info.rosterInfo.name])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
                
                for(JBoUserDetailInfo *info in self.fansArray)
                {
                    if([self chinese:content match:info.rosterInfo.name] && ![_searchResultArray containsObject:info])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
            }
                break;
            default:
                break;
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
        [_tableView reloadData];
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

- (BOOL)pinyin:(NSString*) pinyin match:(NSString*) str
{
    NSString *name = [ChineseToPinyin pinyinFromChiniseString:str];
    if(name.length < pinyin.length)
    {
        return NO;
    }
    
    NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
    if([pinyin isEqualToString:subStr])
    {
        return YES;
    }
    return NO;
}

- (BOOL)chinese:(NSString*) chinese match:(NSString*) str
{
    NSRange range = [str rangeOfString:chinese];
    if(range.length > 0 && range.location != NSNotFound)
    {
        return YES;
    }
    return NO;
}

#pragma mark- attentions operation

//设置 queue
- (ASINetworkQueue*)queue
{
    if(!self.httpQueue)
    {
        self.httpQueue = [ASINetworkQueue queue];
        self.httpQueue.shouldCancelAllRequestsOnFailure = NO;
        [self.httpQueue setDelegate:self];
        [self.httpQueue setQueueDidFinishSelector:@selector(httpQuqueDidFinish:)];
        [self.httpQueue setRequestDidFailSelector:@selector(requestDidFail:)];
        [self.httpQueue setRequestDidFinishSelector:@selector(requestDidFinish:)];
    }
    return self.httpQueue;
}

- (void)httpQuqueDidFinish:(ASINetworkQueue*) queue
{
    self.appDelegate.dataLoadingView.hidden = YES;
    [self.httpQueue reset];
    self.httpQueue = nil;
}

- (void)requestDidFail:(ASIHTTPRequest*) request
{
    switch (request.tag)
    {
        case 1 :
        {
            if(self.isLoading)
            {
                _refreshView.finishText = @"网络不佳,刷新失败";
                [self tableViewDataSourceDidFinishLoading];
            }
            else
            {
                [self alertNetworkMsg:@"获取关注的人失败"];
            }
        }
            break;
        case 2 :
        {
            
        }
            break;
        case 3 :
        {
            if(self.isLoading)
            {
                _refreshView.finishText = @"网络不佳,刷新失败";
                [self tableViewDataSourceDidFinishLoading];
            }
            else
            {
                [self alertNetworkMsg:@"获取关注我的人失败"];
            }
        }
            break;
        case 4 :
        {
            
        }
            break;
        case 5 :
        {
            
        }
            break;
        default:
            break;
    }
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
}

- (void)requestDidFinish:(ASIHTTPRequest*) request
{
    NSData *data = [NSData dataWithContentsOfFile:request.downloadDestinationPath];
    
    switch (request.tag)
    {
        case 1 :
        {
            self.attentionsRequest = NO;
            self.attentionsPageIndex ++;
            NSMutableArray *array = [JBoAttentionOperation getAttentionsFromData:data];
            self.attentionsHasInfo = array.count == _attentionPageSize_;
            if(self.seg.selectedSegmentIndex == 0 && _isLoading)
            {
                self.attentionsPageIndex = 2;
                self.attentions = array;
                _refreshView.finishText = @"刷新成功";
                [self tableViewDataSourceDidFinishLoading];
            }
            else
            {
                [self.attentions addObjectsFromArray:array];
            }
            
            if(self.seg.selectedSegmentIndex == 0)
            {
                if(self.attentions.count == 0)
                {
                    [self alertMsg:@"你还没有关注人"];
                }
                [_tableView reloadData];
                [self setTableFooter];
            }
            
        }
            break;
        case 2 :
        {
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            self.attentionCount = [JBoAttentionOperation attentionCountFromData:data];
            [self setAttentionsCount];
        }
            break;
        case 3 :
        {
            self.fansRequest = NO;
            self.fansPageIndex ++;
            NSMutableArray *array = [JBoAttentionOperation getFansFromData:data];
            self.fansHasInfo = array.count == _attentionPageSize_;
            
            if(self.seg.selectedSegmentIndex == 1 && _isLoading)
            {
                self.fansPageIndex = 2;
                self.fansArray = array;
                _refreshView.finishText = @"刷新成功";
                [self tableViewDataSourceDidFinishLoading];
            }
            else
            {
                [self.fansArray addObjectsFromArray:array];
            }
            
            if(self.seg.selectedSegmentIndex == 1)
            {
                if(self.fansArray.count == 0)
                {
                    [self alertMsg:@"暂时没有人关注你"];
                }
                [_tableView reloadData];
                [self setTableFooter];
            }
        }
            break;
        case 4 :
        {
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            self.fansCount = [JBoAttentionOperation fansCountFromData:data];
            [self setFanCount];
        }
            break;
        case 5 :
        {
            
        }
            break;
        default:
            break;
    }
    
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
}

//取消关注
- (void)cancelAttentionWithUserId:(NSString*) userId
{
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoAttentionOperation cancelAttentionUser:userId]]];
    [request setCachePolicy:ASIDoNotReadFromCacheCachePolicy];
    [request setTag:_cancellAttentionTag_];
    request.downloadDestinationPath = [JBoFileManager getTemporaryFile];
    [[self queue] addOperation:request];
    [[self queue] go];
}

//获取关注的人
- (BOOL)loadAttentions:(BOOL) hidden
{
    if(self.attentionsRequest)
        return NO;
    
    self.appDelegate.dataLoadingView.hidden = hidden;
    
    int index = self.isLoading ? 1 : self.attentionsPageIndex;
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoAttentionOperation getAttentionsWithPageNum:index row:_attentionPageSize_]]];
    [request setTag:_attentionTag_];
    request.downloadDestinationPath = [JBoFileManager getTemporaryFile];
    [[self queue] addOperation:request];
    [[self queue] go];
 
    self.attentionsRequest = YES;
    return YES;
}

//获取关注的人的数量
- (void)getAttentionsCount
{
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoAttentionOperation getAttentionCount]]];
    [request setCachePolicy:ASIDoNotReadFromCacheCachePolicy];
    [request setTag:_attentionCountTag_];
    request.downloadDestinationPath = [JBoFileManager getTemporaryFile];
    [[self queue] addOperation:request];
    [[self queue] go];
}

//获取关注我的人
- (BOOL)loadFans:(BOOL) hidden
{
    if(self.fansRequest)
        return NO;
    
    self.appDelegate.dataLoadingView.hidden = hidden;
    
    int index = self.isLoading ? 1 : self.fansPageIndex;
    
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoAttentionOperation getFansWithUserId:[JBoUserOperation getUserId] pageNum:index row:_attentionPageSize_]]];
    [request setTag:_fansTag_];
    request.downloadDestinationPath = [JBoFileManager getTemporaryFile];
    [[self queue] addOperation:request];
    [[self queue] go];
    
    self.fansRequest = YES;
    
    return YES;
}

//获取关注我的人的数量
- (void)getFansCount
{
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:[JBoAttentionOperation getFansCount]]];
    [request setCachePolicy:ASIDoNotReadFromCacheCachePolicy];
    [request setTag:_fansCountTag_];
    request.downloadDestinationPath =[JBoFileManager getTemporaryFile];
    [[self queue] addOperation:request];
    [[self queue] go];
}


#pragma mark- tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return _searchResultArray.count;
    }
    else
    {
        NSInteger count = 0;
        switch (self.seg.selectedSegmentIndex)
        {
            case 0 :
            {
                count = self.attentions.count;
            }
                break;
            case 1 :
            {
                count = self.fansArray.count;
            }
                break;
            default:
                break;
        }
        
        return count;
    }
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    
    JBoAttentionsCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoAttentionsCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoUserDetailInfo *info = [self getInfoFromIndexPath:indexPath];
    JBoRosterInfo *rosterInfo = info.rosterInfo;
    
    cell.nameLabel.text = rosterInfo.name;
    cell.headImageView.role = rosterInfo.role;
    
    if(rosterInfo.remark.length > 0)
    {
        cell.nameLabel.text = rosterInfo.remark;
    }
    [cell setPresence:rosterInfo.presence];
    cell.nameLabel.sex = rosterInfo.sex;
    cell.headImageView.sex = rosterInfo.sex;
    //加载头像
    cell.headImageView.headImageURL = rosterInfo.imageURL;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //进入好友详细信息视图
    
    JBoUserDetailInfo *info = [self getInfoFromIndexPath:indexPath];
    
    JBoPublickUserInfoViewController *publicVC = [[JBoPublickUserInfoViewController alloc] init];
    publicVC.userDetailInfo = info;
    publicVC.sendMsgType = JBoSendMsgTypeFans;
    [self.navigationController pushViewController:publicVC animated:YES];
    [publicVC release];
    
    [_searchBar resignFirstResponder];
}

#pragma mark- 加载头像

- (JBoUserDetailInfo*)getInfoFromIndexPath:(NSIndexPath*) indexPath
{
    JBoUserDetailInfo *info = nil;
    if(self.searching)
    {
        info = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        switch (self.seg.selectedSegmentIndex)
        {
            case 0 :
            {
                info = [self.attentions objectAtIndex:indexPath.row];
            }
                
                break;
            case 1 :
            {
                info = [self.fansArray objectAtIndex:indexPath.row];
            }
                break;
            default:
                break;
        }
    }
    return info;
}

#pragma mark- scrollView代理


- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewWillBeginScroll:scrollView];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView.contentOffset.y < - 10)
    {
        _refreshView.hidden = NO;
    }
    else
    {
        _refreshView.hidden = YES;
    }
    
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidScroll:scrollView];
    }
    
    if(!_isLoading)
    {
        if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
        {
            switch (self.seg.selectedSegmentIndex)
            {
                case 0 :
                {
                    if(self.attentionsHasInfo && !self.attentionsRequest)
                    {
                        JBoBottomLoadingView *bottomLoadingView = [[[JBoBottomLoadingView alloc] initWithTabBarLoading:YES] autorelease];
                        self.tableView.tableFooterView = bottomLoadingView;
                        [self loadAttentions:YES];
                    }
                    
                }
                    break;
                case 1 :
                {
                    if(self.attentionsHasInfo && !self.fansRequest)
                    {
                        JBoBottomLoadingView *bottomLoadingView = [[[JBoBottomLoadingView alloc] initWithTabBarLoading:YES] autorelease];
                        self.tableView.tableFooterView = bottomLoadingView;
                        [self loadFans:YES];
                    }
                }
                    break;
                default:
                    break;
            }
        }
    }
}

#pragma mark- 下拉刷新

- (void)reloadTableViewDataSource
{
    _isLoading = YES;
    
    switch (self.seg.selectedSegmentIndex)
    {
        case 0 :
        {
            [self loadAttentions:YES];
        }
            break;
        case 1 :
        {
            [self loadFans:YES];
        }
            break;
        default:
            break;
    }
    
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading
{
    _isLoading = NO;
    [_tableView reloadData];
    [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:_tableView];
}

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
