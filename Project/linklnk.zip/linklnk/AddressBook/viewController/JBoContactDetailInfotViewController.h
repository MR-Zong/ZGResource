//
//  KingHeFunctionListViewController.h
//  微喂
//
//  Created by kinghe005 on 13-8-24.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoLookAndTellViewController.h"

@class JBoRosterInfo;
@class JBoUserHeadImageView;

/**个人资料
 */
@interface JBoContactDetailInfotViewController : JBoLookAndTellViewController<UIAlertViewDelegate>
{
    //更多功能
    NSArray *_moreTitleArray;
    NSArray *_moreImageArray;
    
    //拨号
    UIWebView *_callOutWebView;
}

/**用户信息
 */
@property(retain,nonatomic) JBoRosterInfo *rosterInfo;

/**是否是从消息窗口传入的
 */
@property(nonatomic,assign) BOOL sendMsg;

/**构造方法
 */
- (id)initWithRosterInfo:(JBoRosterInfo*) info;

@end