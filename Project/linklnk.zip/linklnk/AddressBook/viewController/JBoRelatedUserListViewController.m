//
//  JBoRelatedViewController.m
//  linklnk
//
//  Created by kinghe005 on 15-3-17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoRelatedUserListViewController.h"
#import "JBoAttentionOperation.h"
#import "JBoHttpRequest.h"
#import "JBoRelatedUserListCell.h"
#import "JBoPublickUserInfoViewController.h"

//可以获取关联的人的最高层次
#define _maxRelateUserListLevel_ 2

@interface JBoRelatedUserListViewController ()<JBoHttpRequestDelegate,JBoRelatedUserListCellDelegate>

/**需要获取关联的人的id
 */
@property(nonatomic,copy) NSString *targetUserId;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//请求队列
@property(nonatomic,retain) ASINetworkQueue *queue;

//关联的人总数量
@property(nonatomic,assign) int totalCount;

//关联的人的信息 数组元素是 JBoUserDetailInfo
@property(nonatomic,retain) NSMutableArray *infos;

@end

@implementation JBoRelatedUserListViewController

/**构造方法
 *@param userId 需要获取关联的人的id
 *@return 一个实例
 */
- (id)initWithUserId:(NSString*) userId
{
    self = [super initWithStyle:UITableViewStylePlain];
    if(self)
    {
        self.targetUserId = userId;
        self.canGetSecondaryReleateUsers = YES;
        self.curLevel = 0;
    }
    
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_targetUserId release];
    [_httpRequest release];
    
    [_queue reset];
    [_queue release];
    
    [_infos release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.curPage --;
    [self endPullUpLoading];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    [self endPullUpLoading];
    
    NSArray *array = [JBoAttentionOperation getFansFromData:data];
    self.hasInfo = array.count >= _attentionPageSize_;
    [self.infos addObjectsFromArray:array];
   
    [self.tableView reloadData];
}

//获取更多关联的人
- (void)loadMoreInfo
{
    self.curPage ++;
    self.loadingFromNetwork = YES;
    [self.httpRequest downloadWithURL:[JBoAttentionOperation getFansWithUserId:self.targetUserId pageNum:self.curPage row:_attentionPageSize_]];
}

//获取关联的人列表和 人数
- (void)loadRelateUserListAndCount
{
    self.loadingFromNetwork = YES;
    self.showActivityIndicator = YES;
    [self.queue reset];
    
    self.queue = [ASINetworkQueue queue];
    [self.queue setDelegate:self];
    [self.queue setRequestDidFinishSelector:@selector(requestDidFinish:)];
    [self.queue setQueueDidFinishSelector:@selector(queueDidFinish:)];
    
    //获取关联的人的总数量
    ASIHTTPRequest *request = [JBoHttpRequest requestWithURL:[JBoAttentionOperation getFansCount] tag:1];
    [self.queue addOperation:request];
    
    //获取关联的人列表
    request = [JBoHttpRequest requestWithURL:[JBoAttentionOperation getFansWithUserId:self.targetUserId pageNum:self.curPage row:_attentionPageSize_] tag:2];
    [self.queue addOperation:request];
    
    [self.queue go];
}

//单个请求完成
- (void)requestDidFinish:(ASIHTTPRequest*) request
{
    NSData *data = [NSData dataWithContentsOfFile:request.downloadDestinationPath];
    
    switch (request.tag)
    {
        case 1 :
        {
            self.totalCount = [JBoAttentionOperation fansCountFromData:data];
        }
            break;
        case 2 :
        {
            NSArray *array = [JBoAttentionOperation getFansFromData:data];
            self.hasInfo = array.count >= _attentionPageSize_;
            self.infos = [NSMutableArray array];
            [self.infos addObjectsFromArray:array];
        }
            break;
        default:
            break;
    }
    
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
}

//队列完成
- (void)queueDidFinish:(ASINetworkQueue*) queue
{
    if(self.infos != nil)
    {
        [self initialization];
    }
    else if(self.refreshing)
    {
        [self.tableView reloadData];
    }
    else
    {
        [self failToLoadDataFromNetworkWithAlertMessage:nil];
    }
    
    [self.queue reset];
    self.queue = nil;
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    if(!self.curLevel)
    {
        self.title = @"关联我的人";
    }
    else
    {
        self.title = @"关联TA的人";
    }
    
    if(self.curLevel >= _maxRelateUserListLevel_)
    {
        self.canGetSecondaryReleateUsers = NO;
    }
    
    self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
    
    //获取关联的人列表和 人数
    [self loadRelateUserListAndCount];
}

- (void)initialization
{
    [super initialization];
    
    self.enableDropDown = YES;
    self.enablePullUp = YES;
}

- (void)reloadDataFromNetwork
{
    [self loadRelateUserListAndCount];
}

- (void)beginDropDownRefresh
{
    [self loadRelateUserListAndCount];
}

- (void)beginPullUpLoading
{
    [self loadMoreInfo];
}

#pragma mark- UITableView delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infos.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoRelatedUserListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell)
    {
        cell = [[[JBoRelatedUserListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoUserDetailInfo *info = [_infos objectAtIndex:indexPath.row];
    cell.info = info.rosterInfo;
    
    if(self.canGetSecondaryReleateUsers)
    {
        [cell.countButton setTitle:[NSString stringWithFormat:@"297"] forState:UIControlStateNormal];
    }
    else
    {
        cell.countButton.hidden = YES;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    JBoUserDetailInfo *info = [_infos objectAtIndex:indexPath.row];
    
    JBoPublickUserInfoViewController *publicVC = [[JBoPublickUserInfoViewController alloc] init];
    publicVC.userDetailInfo = info;
    publicVC.black = self.black;
    [self.navigationController pushViewController:publicVC animated:YES];
    [publicVC release];
}

#pragma mark- JBoRelatedUserListCell delegate

- (void)relatedUserListCellDidGetSecondaryInfos:(JBoRelatedUserListCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    JBoUserDetailInfo *info = [_infos objectAtIndex:indexPath.row];
    
    JBoRelatedUserListViewController *relatedVC = [[JBoRelatedUserListViewController alloc] initWithUserId:info.rosterInfo.username];
    relatedVC.curLevel = self.curLevel + 1;
    relatedVC.black = self.black;
    [self.navigationController pushViewController:relatedVC animated:YES];
    [relatedVC release];
}

@end
