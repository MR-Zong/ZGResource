////
////  KingHeFunctionListViewController.m
////  微喂
////
////  Created by kinghe005 on 13-8-24.
////  Copyright (c) 2013年 kinghe. All rights reserved.
////
//
#import "JBoContactDetailInfotViewController.h"
#import "JBoActionSheet.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoSendMsgViewController.h"
#import "JBoImageTextTool.h"
#import "JBoCheckInputText.h"
#import "JBoUserHeadImageView.h"
#import "JBoSetupPrivacyViewController.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoUserLocationInfo.h"
#import "JBoContactDetailTableHeaderView.h"
#import "JBoUserLookAndTellCell.h"
#import "JBoLookAndTellListInfo.h"
#import "JBoDatetimeTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoLookAndTellOperation.h"
#import "JBoReuseScrollInfo.h"
#import "JBoCustomToolBar.h"
#import "JBoImageCacheTool.h"
#import "JBoComplaintViewController.h"
#import "JBoNavigationViewController.h"
#import "JBoUserNameLabel.h"
#import "JBoAppointmentOperation.h"
#import "JBoAppointmentInfo.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoAppointmentAddViewController.h"
#import "JBoSceneMakingInfo.h"

//获取预约次数
#define _appointmentTag_ 1

//获取个人信息
#define _userInfoTag_ 2

@interface JBoContactDetailInfotViewController ()<JBoCustomToolBarDelegate,JBoUserLookAndTellCellDelegate,JBoUserInfoTableHeaderViewDelegate,JBoActionSheetDelegate>
{
    JBoContactDetailTableHeaderView *_tableHeaderView;
    
    //加载数据
    JBoBottomLoadingView *_bottomLoadingView;
}

//用户详细信息
@property(nonatomic,retain)JBoUserDetailInfo *userDetailInfo;
//更多功能操作类型
@property(nonatomic,assign) JBoContactMoreOperationType contactMoreOperationType;
//修改的备注名
@property(nonatomic,copy) NSString *modifyRemark;

//底部工具条
@property(nonatomic,retain) JBoCustomToolBar *toolBar;

//请求队列
@property(nonatomic,retain) ASINetworkQueue *queue;

//预约次数信息
@property(nonatomic,retain) JBoAppointmentListInfo *appointmentInfo;

@end

@implementation JBoContactDetailInfotViewController

/**构造方法
 */
- (id)initWithRosterInfo:(JBoRosterInfo*) info
{
    self = [super initWithNibName:nil bundle:nil];
    if (self)
    {
        self.title = @"好友资料";
        
        self.sendMsg = NO;
        self.isRequesting = NO;
        self.hasInfo = NO;
        self.rosterInfo = info;
    }
    return self;
}

#pragma mark-内存管理
- (void)dealloc
{
    NSLog(@"contact detail dealloc");
    
    [_rosterInfo release];
    [_moreImageArray release];
    [_moreTitleArray release];

    [_callOutWebView release];

    [_userDetailInfo release];
    [_modifyRemark release];

    [_tableHeaderView release];
    [_bottomLoadingView release];
    
    [_toolBar release];
    
    [_queue reset];
    [_queue release];
    
    [_appointmentInfo release];
    
    [super dealloc];
}

#pragma mark-视图出现消失
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [JBoNavigatioinBarOperation setDefaultNavigationBar:self.navigationController.navigationBar];
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;

    if([identifier isEqualToString:_modifyContactRemarkIdentifier_])
    {
        [self alertNetworkMsg:@"修改备注失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeContactIdentifier_])
    {
        [self alertNetworkMsg:@"删除失败"];
        return;
    }
    
    if([identifier isEqualToString:_addToBlackListIdentifier_])
    {
        [self alertNetworkMsg:@"添加至黑名单失败"];
        return;
    }
    
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        [self alertNetworkMsg:@"获取好友日志失败"];
        [self.tableView setExtraCellLineHidden];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        BOOL needScroll = self.infoArray.count == 0;
        NSMutableArray *infoArray = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:self.multisInfoDic offlineCache:nil];
        self.hasInfo = infoArray.count != 0;
        
        if(infoArray != nil)
        {
          
            [self.infoArray addObjectsFromArray:infoArray];
            
        }
        else
        {
            self.hasInfo = NO;
        }
        
        if(!self.tableView)
        {
            [self loadInitView];
        }
        else
        {
            [self.tableView reloadData];
        }
        
        [self.tableView setExtraCellLineHidden];
        
        [_tableHeaderView lookAndTellDidLoad:self.infoArray.count != 0];
        if(needScroll && self.infoArray.count > 0)
        {
            [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
    }

    
    if([identifier isEqualToString:_modifyContactRemarkIdentifier_])
    {
        if([JBoUserOperation getModifyContactRemarkFromData:data])
        {
            [self sendUpdateNotification:JBoContactMoreOperationTypeRemark];
            self.userDetailInfo.rosterInfo.remark = self.modifyRemark;
            self.rosterInfo.remark = self.modifyRemark;
            
            NSLog(@"%@", self.modifyRemark);
            
            [_tableHeaderView changeNameLabel];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeContactIdentifier_])
    {
        if([JBoUserOperation getRemoveContactFromData:data])
        {
            //通知通讯录更新
            [self sendUpdateNotification:JBoContactMoreOperationTypeDelete];
            [self performSelector:@selector(backToRoot) withObject:nil afterDelay:0.3];
        }
         return;
    }
    
    if([identifier isEqualToString:_addToBlackListIdentifier_])
    {
        if([JBoUserOperation getAddBlackListFromData:data])
        {
            //通知通讯录更新
            [self sendUpdateNotification:JBoContactMoreOperationTypeAddBlacklist];
            
            [self performSelector:@selector(backToRoot) withObject:nil afterDelay:0.3];
        }
        return;
    }
}

#pragma mark- queue

//获取个人信息
- (void)getUserInfo
{
    self.queue = [ASINetworkQueue queue];
    [self.queue setDelegate:self];
    [self.queue setQueueDidFinishSelector:@selector(queueDidFinish:)];
    [self.queue setRequestDidFinishSelector:@selector(requestDidFinish:)];

    
    [self.httpRequest startDataLoading];
    self.isRequesting = YES;
    
    ASIHTTPRequest *request = [JBoHttpRequest requestWithURL:[JBoUserOperation getSearchUserId:self.rosterInfo.username] tag:_userInfoTag_];
    [self.queue addOperation:request];
    
    request = [JBoHttpRequest requestWithURL:[JBoAppointmentOperation getUserAppointCountWithId:self.rosterInfo.username] tag:_appointmentTag_];
    [self.queue addOperation:request];
    
    [self.queue go];
}

//队列请求完成
- (void)queueDidFinish:(ASINetworkQueue*) queue
{
    self.isRequesting = NO;
    if(!self.userDetailInfo)
    {
        [self alertMsg:@"获取好友资料失败"];
    }
    else
    {
        self.userDetailInfo.appointmentCount = self.appointmentInfo.appointmentCount;
        self.userDetailInfo.notKeepAppointmentCount = self.appointmentInfo.notKeepAppointmentCount;
        self.userDetailInfo.beLateAppointmentCount = self.appointmentInfo.beLateAppointmentCount;
        self.appointmentInfo = nil;
        
        if(!self.tableView)
        {
            [self loadInitView];
        }
    }
}

//单个请求完成
- (void)requestDidFinish:(ASIHTTPRequest*) request
{
    NSData *data = [NSData dataWithContentsOfFile:request.downloadDestinationPath];
    switch (request.tag)
    {
        case _userInfoTag_ :
        {
            self.userDetailInfo = [JBoUserOperation getSearchUserIdResultFromData:data];
            if(self.userDetailInfo)
            {
                self.userDetailInfo.rosterInfo.username = self.rosterInfo.username;
                self.userDetailInfo.rosterInfo.remark = self.rosterInfo.remark;
                
                self.rosterInfo.imageURL = self.userDetailInfo.rosterInfo.imageURL;
                self.rosterInfo.presence = self.userDetailInfo.rosterInfo.presence;
                self.rosterInfo.name = self.userDetailInfo.rosterInfo.name;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:_userInfoUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:self.userDetailInfo.rosterInfo forKey:_userInfoUpdateKey_]];
            }
        }
            break;
        case _appointmentTag_ :
        {
            self.appointmentInfo = [JBoAppointmentOperation getUserAppointCountFromData:data];
        }
            break;
    }
    
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
}

#pragma mark-加载视图
- (void)back
{
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadInfo) object:nil];
    if(self.black)
    {
        [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
        [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)backToRoot
{
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadInfo) object:nil];
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    self.view.backgroundColor = [UIColor colorWithRed:244.0 / 255.0 green:245.0 / 255.0 blue:247.0 / 255.0 alpha:1.0];
    
    [self getUserInfo];
}

- (void)loadInitView
{
    if(![self.rosterInfo.username isEqualToString:_linklnkUserId_])
    {
        //创建功能更多按钮
        [self setRightBarItemWithIcon:[UIImage imageNamed:@"moreSetup.png"] action:@selector(moreBarButtonItemAction)];
    }
    
    _tableHeaderView = [[JBoContactDetailTableHeaderView alloc] initWithUserDetailInfo:self.userDetailInfo relation:JBoUserRelationFriend];
    _tableHeaderView.delegate = self;
    _tableHeaderView.navigationController = self.navigationController;
    [_tableHeaderView changeNameLabel];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _defaultToolBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        tableView.separatorInset = UIEdgeInsetsZero;
    }
#endif
    
    tableView.tableHeaderView = _tableHeaderView;
    [self.view addSubview:tableView];
    
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
    
    JBoCustomToolBar *toolBar= [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _defaultToolBarHeight_, _width_, _defaultToolBarHeight_) items:[NSArray arrayWithObjects:[JBoCustomToolBarItem toolBarItemWithTitle:@"发消息" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:makeAppointment image:nil],[JBoCustomToolBarItem toolBarItemWithTitle:@"发私信" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"拨号" image:nil], nil]];
    toolBar.titleFont = [UIFont boldSystemFontOfSize:14.0];
    toolBar.delegate = self;
    [self.view addSubview:toolBar];
    [toolBar release];
    
    self.toolBar = toolBar;
}

#pragma mark- JBoUserInfoTableHeaderView delegate

- (void)userInfoTableHeaderViewNeedSeeLookAndTell:(JBoUserInfoTableHeaderView *)header
{
    if(self.isRequesting)
    {
        return;
    }
    
    if(!_bottomLoadingView)
    {
        //创建加载更多视图
        _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
        _bottomLoadingView.backgroundColor = [UIColor clearColor];
    }
    
    self.tableView.tableFooterView = _bottomLoadingView;
    CGFloat y = _tableHeaderView.height + _bottomLoadingView.height - self.tableView.height;
   
    [self.tableView setContentOffset:CGPointMake(0, y) animated:YES];
    [self performSelector:@selector(loadInfo) withObject:nil afterDelay:0.25];
}

- (void)loadInfo
{
    if(self.isRequesting)
        return;
    
   // NSLog(@"pageIndex %d", self.pageIndex);
    self.httpRequest.identifier = _getUserLookAndTellIdentifier_;
    self.isRequesting = YES;
    [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getUserLookAndTellInfoWithUserId:self.userDetailInfo.rosterInfo.username pageNum:self.pageIndex rows:_lookAndTellPageSize_ visible:_lookAndTellVisiblePublic_]];
}

#pragma mark-customToolBar代理

- (void)toolBar:(JBoCustomToolBar *)toolBar didSelectedAtIndex:(NSInteger)index
{
    switch (index)
    {
        case 0:
            [self sendMsgWithType:JBoSendMsgTypeNormal];
            break;
        case 1 :
            [self makeAnAppointment];
            break;
        case 2 :
            [self sendMsgWithType:JBoSendMsgTypeFans];
            break;
        case 3 :
            [self phoneButtonAction];
            break;
        default:
            break;
    }
}

//预约
- (void)makeAnAppointment
{
    JBoUserDetailInfo *userDetailInfo = [JBoUserDetailInfo userDetailInfoFromUserDetaults];
    if(userDetailInfo.rosterInfo.role == 0)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"预约%@", realNameAuthenTitle] message:realNameAuthenMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", goToRealNameAuthen, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    JBoSceneMakingInfo *info = [[[JBoSceneMakingInfo alloc] init] autorelease];
    info.userDetailInfo = self.userDetailInfo;
    
    JBoAppointmentAddViewController *add = [[JBoAppointmentAddViewController alloc] initWithInfo:info mapInfo:nil target:JBoAppointmentTargetToStranger];
    [self.navigationController pushViewController:add animated:YES];
    [add release];
}

//发信息
- (void)sendMsgWithType:(JBoSendMsgType) type
{
    if(self.sendMsg)
    {
        [self.navigationController popViewControllerAnimated:YES];
        return;
    }
    
    JBoSendMsgViewController *sendMsgVC = [[JBoSendMsgViewController alloc] init];
    sendMsgVC.rosterInfo = self.userDetailInfo.rosterInfo;
    sendMsgVC.sendMsgType = type;
    [self.navigationController pushViewController:sendMsgVC animated:YES];
    [sendMsgVC release];
}

//拨号
- (void)phoneButtonAction
{
    if(!self.userDetailInfo.phoneState)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"该好友手机号码设置为不公开" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
   
    
    NSURL *phoneURL = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",self.userDetailInfo.phoneNum]];
    if(!_callOutWebView)
    {
        _callOutWebView = [[UIWebView alloc] init];
    }
    [_callOutWebView loadRequest:[NSURLRequest requestWithURL:phoneURL]];
}

#pragma mark-tableView 代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    return [self userLookAndTellHeightForIndexPath:indexPath style:info.operationInfo.style];
}


- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    static NSString *defaultIdentifier = @"default";
    static NSString *shareLinkIdentifier = @"sharelink";
    static NSString *shortMovieIdentifier = @"shortMovie";
    
    NSString *cellIdentifier = defaultIdentifier;
    JBoLookAndTellCellStyle style = JBoLookAndTellCellStyleDefault;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cellIdentifier = shareLinkIdentifier;
            style = JBoLookAndTellCellStyleLinkShare;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cellIdentifier = shortMovieIdentifier;
            style = JBoLookAndTellCellStyleShortMovie;
        }
            break;
        default:
            break;
    }
    
    JBoUserLookAndTellCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoUserLookAndTellCell alloc] initWithCellStyle:style reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.statusImageLabel.hidden = YES;
        cell.msgOperationView.canComplaint = NO;
    }
    
    cell.msgOperationView.info = info;
    cell.msgOperationView.style = info.operationInfo.style;
    
    cell.msgOperationView.index = indexPath.row;
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cell.linkView.shareView.htmlTitleLabel.text = info.urlTitle;
            cell.linkView.shareURL = info.url;
            cell.linkView.srcArray = info.multiInfo;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cell.shareShortMovieView.srcArray = info.multiInfo;
        }
            break;
        default:
        {
            cell.multiImageTextView.hasMoreText = info.hasMoreText;
            cell.multiImageTextView.srcArray = info.multiInfo;
        }
            break;
    }
    
    if(indexPath.row != 0)
    {
        JBoLookAndTellListInfo *listInfo = [self.infoArray objectAtIndex:indexPath.row - 1];
        cell.dateView.sameDay = [JBoDatetimeTool isOnTheSameDay:listInfo.date otherDay:info.date];
    }
    else
    {
        cell.dateView.sameDay = NO;
    }
    cell.dateView.time = info.date;
    
    return cell;
}


#pragma mark-scrollView代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(!self.hasInfo || self.isRequesting)
        return;
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!_bottomLoadingView)
        {
            //创建加载更多视图
            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            _bottomLoadingView.backgroundColor = [UIColor clearColor];
        }

        self.pageIndex ++;
        self.tableView.tableFooterView = _bottomLoadingView;
        [self loadInfo];
    }
}

#pragma mark-私有方法

//通知通讯录更新
- (void)sendUpdateNotification:(JBoContactMoreOperationType) type
{
    NSNumber *number = [NSNumber numberWithInteger:type];

    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:number, _addressBookUpdateType_, self.rosterInfo, _addressBookUpdateRosterInfo_, nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:_addressBookUpdateNotification_ object:self userInfo:dic];
}


#pragma mark-功能更多按钮的方法

- (void)moreBarButtonItemAction
{
    //创建自定义actionSheet
    if(!_moreTitleArray)
    {
        //更多功能
        _moreTitleArray = [[NSArray alloc] initWithObjects:@"设置隐私", @"备注" ,@"删除联系人", @"添加至黑名单", @"投诉", nil];
        
        UIImage *setupPrivacyImage = [UIImage imageNamed:@"setupPrivacy.png"];
        UIImage *noteImage = [UIImage imageNamed:@"note.png"];
        UIImage *deleteContactImage = [UIImage imageNamed:@"deleteContact.png"];
        UIImage *blackListImage = [UIImage imageNamed:@"backList.png"];
        
        UIImage *complaintImage = [UIImage imageNamed:@"complaint.png"];
        
        _moreImageArray = [[NSArray alloc] initWithObjects:setupPrivacyImage, noteImage, deleteContactImage, blackListImage, complaintImage, nil];
    }
    
    self.sharing = NO;
    JBoActionSheet *myActionSheet = [[JBoActionSheet alloc] initWithItems:_moreImageArray.count delegate:self];
    [myActionSheet show];
    [myActionSheet release];
}


#pragma mark-JBoActionSheet代理

- (CGFloat)actionSheet:(JBoActionSheet *)actionSheet heightForRowAtIndex:(NSInteger)index
{
    if(self.sharing)
    {
        return [JBoActionSheet defaultCellHeight];
    }
    else
    {
        return 90.0;
    }
}

- (JBoCustomActionSheetCell*)cellForActionSheet:(JBoActionSheet *)actionSheet index:(NSInteger)index
{
    if(self.sharing)
    {
        return [super cellForActionSheet:actionSheet index:index];
    }
    else
    {
        JBoCustomActionSheetCell *cell = [[JBoCustomActionSheetCell alloc] initWithImage:[_moreImageArray objectAtIndex:index] title:[_moreTitleArray objectAtIndex:index]];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.index = index;
        return [cell autorelease];
    }
}

//功能更多关联方法
- (void)actionSheet:(JBoActionSheet *)actionSheet didSelectedIndex:(NSInteger)index
{
    if(self.sharing)
    {
        [super actionSheet:actionSheet didSelectedIndex:index];
        return;
    }
    
    switch (index)
    {
        case 0 :
        {
            JBoSetupPrivacyViewController *setupPrivacyVC = [[JBoSetupPrivacyViewController alloc] init];
            setupPrivacyVC.userDetailInfo = self.userDetailInfo;
            [self.navigationController pushViewController:setupPrivacyVC animated:YES];
            [setupPrivacyVC release];
             break;
        }
        case 1 :
        {
            self.contactMoreOperationType = JBoContactMoreOperationTypeRemark;
            UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"备注名" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
            alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
            alerView.delegate = self;
            UITextField *textField = [alerView textFieldAtIndex:0];
            textField.placeholder = [NSString stringWithFormat:@"%d个字以内",_inputFormatRemark_];
             if(self.userDetailInfo.rosterInfo.remark.length > 0 && ![self.userDetailInfo.rosterInfo.remark isEqual:[NSNull null]])
             {
                 textField.text = self.userDetailInfo.rosterInfo.remark;
             }
            [alerView show];
            [alerView release];
            
            break;
        }
        case 2 :
        {
            self.contactMoreOperationType = JBoContactMoreOperationTypeDelete;
            NSString *message = [NSString stringWithFormat:@"确定要把%@从通讯录中删除？",_rosterInfo.remark.length > 0 ? _rosterInfo.remark : _rosterInfo.name];
            UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"删除联系人" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
            alerView.delegate = self;
            [alerView show];
            [alerView release];
             break;
        }
        case 3 :
        {
            self.contactMoreOperationType = JBoContactMoreOperationTypeAddBlacklist;
            NSString *message = [NSString stringWithFormat:@"确定要把 %@ 加入黑名单？",_rosterInfo.remark.length > 0 ? _rosterInfo.remark : _rosterInfo.name];
            UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"添加黑名单" message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
            alerView.delegate = self;
            [alerView show];
            [alerView release];
            break;
        }
        case 4 :
        {
            JBoComplaintViewController *complaintVC = [[JBoComplaintViewController alloc] init];
            complaintVC.userId = self.userDetailInfo.rosterInfo.username;
            JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:complaintVC];
            [self.appDelegate.window.rootViewController presentViewController:nav animated:YES completion:nil];
            [nav release];
            [complaintVC release];
        }
            break;
    }
    
    [actionSheet disMiss];
}

#pragma mark-UIAlertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(self.isRequesting)
        return;
    
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    
    if([title isEqualToString:@"取消"])
    {
        return;
    }
    
    if ([title isEqualToString:goToRealNameAuthen])
    {
        JBoRealNameAuthenViewController *realName = [[JBoRealNameAuthenViewController alloc] init];
        realName.black = self.black;
        [self.navigationController pushViewController:realName animated:YES];
        [realName release];
        return;
    }
    
    if(buttonIndex == 0)
    {
        switch (self.contactMoreOperationType) {
            case JBoContactMoreOperationTypeRemark:
            {
                
                UITextField *textField = [alertView textFieldAtIndex:0];
                
                if([textField.text stringByReplacingOccurrencesOfString:@" " withString:@""].length > 0)
                {
                    if(textField.text.length > _inputFormatRemark_)
                    {
                        [self alertMsg:[NSString stringWithFormat:@"备注名不能超过%d字",_inputFormatRemark_]];
                        return;
                    }
                    
                    if([JBoCheckInputText isIncludeSpecialCharacter:textField.text] || ![JBoCheckInputText isSimilarToLinerTeam:textField.text])
                    {
                        [self alertMsg:@"备注名格式不正确"];
                        return;
                    }
                    self.modifyRemark = textField.text;
                    
                    self.isRequesting = YES;
                    self.httpRequest.identifier = _modifyContactRemarkIdentifier_;
                    [self.httpRequest downloadWithURL:[JBoUserOperation getModifyContactRemarkURL] dic:[JBoUserOperation getModifyContactRemarkPostData:_rosterInfo.username remark:textField.text]];
                }
                else
                {
                    [self alertMsg:@"备注名不能为空"];
                }
            }
                break;
            case JBoContactMoreOperationTypeDelete :
            {
                self.isRequesting = YES;
                self.httpRequest.identifier = _removeContactIdentifier_;
                [self.httpRequest downloadWithURL:[JBoUserOperation getRemoveContactURL:_rosterInfo.username]];
            }
                break;
            case JBoContactMoreOperationTypeAddBlacklist :
            {
                self.isRequesting = YES;
                self.httpRequest.identifier = _addToBlackListIdentifier_;
                [self.httpRequest downloadWithURL:[JBoUserOperation getAddBlackListURL:_rosterInfo.username]];
            }
                break;
            default:
                break;
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
