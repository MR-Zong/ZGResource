//
//  JBoRelatedViewController.h
//  linklnk
//
//  Created by kinghe005 on 15-3-17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoTableViewController.h"

/**关联的人列表
 */
@interface JBoRelatedUserListViewController : JBoTableViewController

/**是否可以获取次一级关联的人 default is 'YES'
 */
@property(nonatomic,assign) BOOL canGetSecondaryReleateUsers;

/**当前关联的人的层次 default is '0'
 */
@property(nonatomic,assign) int curLevel;

/**构造方法
 *@param userId 需要获取关联的人的id
 *@return 一个实例
 */
- (id)initWithUserId:(NSString*) userId;

@end
