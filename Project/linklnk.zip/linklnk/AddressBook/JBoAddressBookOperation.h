//
//  JBoAddressBookOperation.h
//  连你
//
//  Created by kinghe005 on 14-5-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "JBoRosterInfo.h"

@interface JBoAddressBookOperation : NSObject

//获取花名册
- (void)getRosterListWithKeywords:(NSMutableArray*) keywords rosterDic:(NSMutableDictionary*) rosterDic rosterAndUsernameDic:(NSMutableDictionary*) rosterAndUsernameDic;

//删除联系人
- (void)removeRosterWithId:(sqlite3_int64) sqlId;
- (void)removeRosterWithUserId:(NSString*) userId;

//新增联系人
- (void)addNewContact:(JBoRosterInfo*) info;

//修改备足
- (void)modifyRemark:(NSString*)remark withId:(sqlite3_int64) sqlId;

//删除所有联系人
- (void)removeAllRoster;

//获取黑名单
- (NSMutableArray*)getBlackList;

//新增黑名单
- (void)addNewBlackList:(JBoRosterInfo*) info;

//删除黑名单
- (void)removeOneBlackListWithUserId:(NSString*) userId;

//删除所有黑名单
- (void)removeAllBlackList;

@end
