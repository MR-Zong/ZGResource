//
//  JBoInstantMsgInfoOperation.m
//  连客
//
//  Created by kinghe005 on 13-11-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoInstantMsgInfoOperation.h"
#import "JBoAppDelegate.h"
#import "GTMBase64.h"
#import "JBoDataPersist.h"
#import "ChineseToPinyin.h"

@interface JBoInstantMsgInfoOperation ()
{
    JBoAppDelegate *_appDelegate;
}

@end

@implementation JBoInstantMsgInfoOperation

- (id)init
{
    self = [super init];
    if(self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
    }
    
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoInstantMsgInfoOperation dealloc");
    [super dealloc];
}

- (void)disconnect
{
    _appDelegate.alertView.message = @"已断开连接";
    [_appDelegate.alertView viewDesalt:_second_];
}


//删除联系人
- (BOOL)deleteContactWithJid:(NSString*) jid
{
    if(_appDelegate.xmpp.xmppStream.isConnected)
    {
        XMPPPresence *presence = [XMPPPresence presenceWithType:_deleteContactType_];
        NSString *from = [[NSUserDefaults standardUserDefaults] objectForKey:_loginJid_];
        [presence addAttributeWithName:_xmppFrom_ stringValue:from];
        [presence addAttributeWithName:_xmppTo_ stringValue:jid];
        
        [_appDelegate.xmpp.xmppStream sendElement:presence];
        return YES;
    }
    else
    {
        [self disconnect];
        return NO;
    }
}


//注销登录
- (void)exitAction
{
    if(_appDelegate.xmpp.xmppStream.isConnected)
    {
        XMPPIQ *iq = [XMPPIQ iqWithType:_xmppTypeSetValue_];
        NSXMLElement *exitElement = [NSXMLElement elementWithName:_logout_ xmlns:_loginXmlnsContent_];
        [iq addChild:exitElement];
        
        [_appDelegate.xmpp.xmppStream sendElement:iq];
    }
    
    [_appDelegate.xmpp disconnect];
}



@end
