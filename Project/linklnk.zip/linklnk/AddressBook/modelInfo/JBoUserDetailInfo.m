//
//  JBoUserDetailInfo.m
//  连客
//
//  Created by kinghe005 on 13-11-28.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserDetailInfo.h"
#import "JBoBasic.h"
#import "JBoUserOperation.h"
#import "JBoDatetimeTool.h"

#define _userInfoEmail_ @"账号:"
#define _userInfoTrade_ @"行业:"
#define _userInfoVocation_ @"职位:"
#define _userInfoArea_ @"地区:"
#define _userInfoPresence_ @"个性签名:"
#define _userInfoCredibility_ @"信誉指数:"
#define _userInfoDealAddr_ @"交易地址"
#define _userInfoPhoneNum_ @"手机号:"
#define _userInfoRole_ @"实名认证:"

#define _userInfoHeight_ @"身高:"
#define _userInfoWeight_ @"体重:"
#define _userInfoBirthday_ @"年龄:"
#define _userInfoBwh_ @"三围:"
#define _userInfoEducation_ @"学历:"
#define _userInfoCharacter_ @"性格:"

#define _userInfoRoleNone_ @"未认证"
#define _userInfoRolePerson_ @"已个人认证"
#define _userInfoRoleEnterprise_ @"已企业认证"

#define _coderRosterInfo_ @"coderRosterInfo"
#define _coderEmail_ @"coderEmail"
#define _coderTrade_ @"coderTrade"
#define _coderVocation_ @"coderVocation"
#define _coderArea_ @"coderArea"
#define _coderAreaID_ @"coderAreaID"
#define _coderCredibility_ @"coderCredibility"
#define _coderLatitude_ @"coderLatitude"
#define _coderLongitude_ @"coderLongitude"
#define _coderDealAddr_ @"coderDealAddr"
#define _coderStatus_ @"coderStatus"
#define _coderPhoneNum_ @"coderPhoneNum"
#define _coderPhoneState_ @"coderPhoneState"

#define _coderHeight_ @"coderHeight"
#define _coderWeight_ @"coderWeight"
#define _coderBust_ @"coderBusts"
#define _coderWaist_ @"codeWaist"
#define _coderHip_ @"hip"
#define _coderBirthday_ @"coderBirthday"
#define _coderCharactor_ @"coderCharactor"
#define _coderEducation_ @"coderEducation"

#define _coderDefaultAddr_ @"coderDefaultAddr"
#define _coderDefaultAddrLat_ @"coderDefaultAddrLat"
#define _coderDefaultAddrLon_ @"coderDefaultAddrLon"

#define _coderNameModifyTime_ @"coderNameModifyTime"

#define _coderAppointmentCount_ @"coderAppointmentCount"
#define _coderNotKeepAppointmentCount_ @"coderNotKeepAppointmentCount"
#define _coderBeLateAppointmentCount_ @"beLateAppointmentCount"

@implementation JBoUserListInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.titleWidth = NSNotFound;
        self.contentHeight = NSNotFound;
    }
    
    return self;
}

+ (id)userListInfoWithTitle:(NSString *)title content:(NSString *)content
{
    JBoUserListInfo *info = [[[JBoUserListInfo alloc] init] autorelease];
    info.title = title;
    info.content = content;
    return info;
}

- (void)dealloc
{
    [_title release];
    [_content release];
    
    [super dealloc];
}

@end

@implementation JBoUserDetailInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        JBoRosterInfo *rosterInfo = [[JBoRosterInfo alloc] init];
        self.rosterInfo = rosterInfo;
        [rosterInfo release];
    }
    
    return self;
}

//获取公开信息
- (NSArray*) getPublicInfo
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    NSString *content = _userInfoRoleNone_;
    if(self.rosterInfo.role == _rosterRolePerson_)
    {
        content = _userInfoRolePerson_;
    }
    else if(self.rosterInfo.role == _rosterRoleEnterprise_)
    {
        content = _userInfoRoleEnterprise_;
    }
    [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoRole_ content:content]];
    
    [self getBodyInfoWithArray:array];
    
    if(![NSString isEmpty:self.area])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoArea_ content:self.area]];
    }
    if(![NSString isEmpty:self.trade])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoTrade_ content:self.trade]];
    }
    if(![NSString isEmpty:self.vocation])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoVocation_ content:self.vocation]];
    }
  
    [array addObjectsFromArray:[self appointmentInfo]];
    
    if(![NSString isEmpty:self.rosterInfo.presence])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoPresence_ content:self.rosterInfo.presence]];
    }
    
    if(![NSString isEmpty:self.phoneNum] && self.phoneState)
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoPhoneNum_ content:self.phoneNum]];
    }
    
    return [array autorelease];
}

- (NSArray*)getInfoList
{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    if(![NSString isEmpty:self.email])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoEmail_ content:[JBoUserOperation getIdFromEmail:self.email]]];
    }
    
    NSString *content = _userInfoRoleNone_;
    if(self.rosterInfo.role == _rosterRolePerson_)
    {
        content = _userInfoRolePerson_;
    }
    else if(self.rosterInfo.role == _rosterRoleEnterprise_)
    {
        content = _userInfoRoleEnterprise_;
    }
    [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoRole_ content:content]];
    
    [self getBodyInfoWithArray:array];
    
    if(![NSString isEmpty:self.trade])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoTrade_ content:self.trade]];
    }
    
    if(![NSString isEmpty:self.vocation])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoVocation_ content:self.vocation]];
    }
    
    //[array addObject:[NSDictionary dictionaryWithObject:self.rosterInfo.username forKey:_userDetailInfoID_]];
    
    if(![NSString isEmpty:self.area])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoArea_ content:self.area]];
    }
    
    [array addObjectsFromArray:[self appointmentInfo]];
    
    if(![NSString isEmpty:self.rosterInfo.presence])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoPresence_ content:self.rosterInfo.presence]];
    }
    
    return [array autorelease];
}

#pragma mark- body

- (void)getBodyInfoWithArray:(NSMutableArray*) array
{
    if(self.height != 0)
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoHeight_ content:self.heightString]];
    }
    
    if(self.weight != 0)
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoWeight_ content:self.weightString]];
    }
    
    if(self.waist != 0)
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoBwh_ content:self.bwhString]];
    }
    
    if(![NSString isEmpty:self.birthday])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoBirthday_ content:[JBoDatetimeTool ageFromDate:self.birthday]]];
    }
    
    if(![NSString isEmpty:self.education])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoEducation_ content:self.education]];
    }
    
    if(![NSString isEmpty:self.character])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:_userInfoCharacter_ content:self.character]];
    }
}

- (NSString*)heightString
{
    return self.height != 0 ? [NSString stringWithFormat:@"%dcm", (int)self.height] : nil;
}

- (NSString*)weightString
{
    return self.weight != 0 ? [NSString stringWithFormat:@"%dkg", (int)self.weight] : nil;
}

- (NSString*)bwhString
{
    NSString *str = nil;
    if(self.waist != 0)
    {
        str = [NSString stringWithFormat:@"%@  %d  %d", self.bust, (int)self.waist, (int)self.hip];
    }
    return str;
}

#pragma mark- appointment

//获取预约次数
- (NSArray*)appointmentInfo
{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:3];
    
    //自己才能查看
    JBoUserDetailInfo *info = [JBoUserDetailInfo userDetailInfoFromUserDetaults];
    if([info.rosterInfo.username isEqualToString:self.rosterInfo.username])
    {
        [array addObject:[JBoUserListInfo userListInfoWithTitle:@"预约:" content:[NSString stringWithFormat:@"%d次", _appointmentCount]]];
    }
    
    [array addObject:[JBoUserListInfo userListInfoWithTitle:@"迟到:" content:[NSString stringWithFormat:@"%d次", _beLateAppointmentCount]]];
    [array addObject:[JBoUserListInfo userListInfoWithTitle:@"未赴约:" content:[NSString stringWithFormat:@"%d次", _notKeepAppointmentCount]]];
    
    return array;
}

/**获取当前登录用户的信息列表
 *@return 数组元素是 JBoUserListInfo
 */
- (NSArray*) getLoginUserInfoList
{
    NSMutableArray *groups = [NSMutableArray arrayWithCapacity:6];
    
    //////
    NSMutableArray *infos1 = [NSMutableArray arrayWithCapacity:4];
    JBoUserListInfo *info = [JBoUserListInfo userListInfoWithTitle:@"头像" content:nil];
    info.editable = YES;
    info.type = JBoUserInfoTypeImage;
    [infos1 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"昵称" content:self.rosterInfo.name];
    info.editable = YES;
    info.type = JBoUserInfoTypeName;
    [infos1 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"性别" content:nil];
    info.type = JBoUserInfoTypeSex;
    [infos1 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"账号" content:[JBoUserOperation getIdFromEmail:self.email]];
    info.type = JBoUserInfoTypeEmail;
    [infos1 addObject:info];
    
    [groups addObject:infos1];
    
    /////////////////
    NSMutableArray *infos2 = [NSMutableArray arrayWithCapacity:3];
    info = [JBoUserListInfo userListInfoWithTitle:@"二维码名片" content:nil];
    info.editable = YES;
    info.type = JBoUserInfoTypeQRCode;
    [infos2 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"我的发布" content:nil];
    info.editable = YES;
    info.type = JBoUserInfoTypeSceneHistory;
    [infos2 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"默认地址" content:self.defaultAddr];
    info.editable = YES;
    info.type = JBoUserInfoTypeDefaultAddr;
    [infos2 addObject:info];

    [groups addObject:infos2];
    
    //////
    NSMutableArray *infos3 = [NSMutableArray arrayWithCapacity:2];
    info = [JBoUserListInfo userListInfoWithTitle:@"手机号" content:nil];
    info.editable = YES;
    info.type = JBoUserInfoTypeID;
    [infos3 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"地区" content:nil];
    info.editable = YES;
    info.type = JBoUserInfoTypeArea;
    [infos3 addObject:info];
    
    [groups addObject:infos3];
    
    /////
    NSMutableArray *infos4 = [NSMutableArray arrayWithCapacity:6];
    info = [JBoUserListInfo userListInfoWithTitle:@"身高" content:self.heightString];
    info.editable = YES;
    info.type = JBoUserInfoTypeHeight;
    [infos4 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"体重" content:self.weightString];
    info.editable = YES;
    info.type = JBoUserInfoTypeWeight;
    [infos4 addObject:info];
    
    if(self.rosterInfo.sex != _sexBoy_)
    {
        info = [JBoUserListInfo userListInfoWithTitle:@"三围" content:self.bwhString];
        info.editable = YES;
        info.type = JBoUserInfoTypeBwh;
        [infos4 addObject:info];
    }
    
    info = [JBoUserListInfo userListInfoWithTitle:@"学历" content:self.education];
    info.editable = YES;
    info.type = JBoUserInfoTypeEducation;
    [infos4 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"出生日期" content:self.birthday];
    info.editable = YES;
    info.type = JBoUserInfoTypeBirthday;
    [infos4 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"行业" content:self.trade];
    info.editable = YES;
    info.type = JBoUserInfoTypeTrade;
    [infos4 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"职位" content:self.vocation];
    info.editable = YES;
    info.type = JBoUserInfoTypeProfession;
    [infos4 addObject:info];
    
    [groups addObject:infos4];
    
    ////
    NSMutableArray *infos5 = [NSMutableArray arrayWithCapacity:2];
    info = [JBoUserListInfo userListInfoWithTitle:@"性格" content:self.character];
    info.editable = YES;
    info.type = JBoUserInfoTypeCharator;
    [infos5 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"个性签名" content:self.rosterInfo.presence];
    info.editable = YES;
    info.type = JBoUserInfoTypePresence;
    [infos5 addObject:info];
    
    info = [JBoUserListInfo userListInfoWithTitle:@"实名认证" content:nil];
    info.editable = YES;
    info.type = JBoUserInfoTypeEnterpriseApply;
    [infos5 addObject:info];
    
    [groups addObject:infos5];
    
    if(self.rosterInfo.role == _rosterRoleEnterprise_ && ![NSString isEmpty:self.rosterInfo.enterpriseName])
    {
        info = [JBoUserListInfo userListInfoWithTitle:@"认证名称" content:self.rosterInfo.enterpriseName];
        info.type = JBoUserInfoTypeEnterpriseName;
        [infos1 insertObject:info atIndex:2];
        
        info = [JBoUserListInfo userListInfoWithTitle:@"认证固话" content:self.rosterInfo.enterpriseTelePhone];
        info.type = JBoUserInfoTypeEnterpriseTelePhone;
        [infos3 insertObject:info atIndex:1];
        
        info = [JBoUserListInfo userListInfoWithTitle:@"认证固话" content:self.rosterInfo.enterpriseAddr];
        info.editable = YES;
        info.type = JBoUserInfoTypeEnterpriseAddr;
        [infos5 insertObject:info atIndex:2];
    }
    
    return groups;
}

- (id)copyWithZone:(NSZone *)zone
{
    JBoUserDetailInfo *userDetailInfo = [[JBoUserDetailInfo allocWithZone:zone] init];
    
    userDetailInfo.rosterInfo = self.rosterInfo;
    userDetailInfo.email = self.email;
    userDetailInfo.trade = self.trade;
    userDetailInfo.vocation = self.vocation;
    userDetailInfo.area = self.area;
    userDetailInfo.areaID = self.areaID;
    userDetailInfo.phoneState = self.phoneState;
  
    userDetailInfo.status = self.status;
    userDetailInfo.phoneNum = self.phoneNum;
    
    userDetailInfo.height = self.height;
    userDetailInfo.weight = self.weight;
    userDetailInfo.bust = self.bust;
    userDetailInfo.waist = self.waist;
    userDetailInfo.hip = self.hip;
    
    userDetailInfo.birthday = self.birthday;
    userDetailInfo.character = self.character;
    userDetailInfo.education = self.education;
    
    userDetailInfo.defaultAddr = self.defaultAddr;
    userDetailInfo.defalutAddrLat = self.defalutAddrLat;
    userDetailInfo.defaultAddrLon = self.defaultAddrLon;
    userDetailInfo.nameModifyTime = self.nameModifyTime;
    
    userDetailInfo.appointmentCount = self.appointmentCount;
    userDetailInfo.notKeepAppointmentCount = self.notKeepAppointmentCount;
    userDetailInfo.beLateAppointmentCount = self.beLateAppointmentCount;
    
    return userDetailInfo;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        self.rosterInfo = [aDecoder decodeObjectForKey:_coderRosterInfo_];
        self.email = [aDecoder decodeObjectForKey:_coderEmail_];
        self.trade = [aDecoder decodeObjectForKey:_coderTrade_];
        self.vocation = [aDecoder decodeObjectForKey:_coderVocation_];
        self.area = [aDecoder decodeObjectForKey:_coderArea_];
        self.areaID = [aDecoder decodeObjectForKey:_coderAreaID_];
    
        self.defalutAddrLat = [aDecoder decodeDoubleForKey:_coderDefaultAddrLat_];
        self.defaultAddrLon = [aDecoder decodeDoubleForKey:_coderDefaultAddrLon_];
        self.defaultAddr = [aDecoder decodeObjectForKey:_coderDefaultAddr_];
        
        self.status = [aDecoder decodeBoolForKey:_coderStatus_];
        self.phoneNum = [aDecoder decodeObjectForKey:_coderPhoneNum_];
        self.phoneState = [aDecoder decodeBoolForKey:_coderPhoneState_];
        
        self.height = [aDecoder decodeIntegerForKey:_coderHeight_];
        self.weight = [aDecoder decodeIntegerForKey:_coderWeight_];
        self.bust = [aDecoder decodeObjectForKey:_coderBust_];
        self.waist = [aDecoder decodeIntegerForKey:_coderWaist_];
        self.hip = [aDecoder decodeIntegerForKey:_coderHip_];
        
        self.birthday = [aDecoder decodeObjectForKey:_coderBirthday_];
        self.character = [aDecoder decodeObjectForKey:_coderCharactor_];
        self.education = [aDecoder decodeObjectForKey:_coderEducation_];
        
        self.nameModifyTime = [aDecoder decodeObjectForKey:_coderNameModifyTime_];
        
        self.appointmentCount = [aDecoder decodeIntForKey:_coderAppointmentCount_];
        self.notKeepAppointmentCount = [aDecoder decodeIntForKey:_coderNotKeepAppointmentCount_];
        self.beLateAppointmentCount = [aDecoder decodeIntForKey:_coderBeLateAppointmentCount_];
    }
    
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.rosterInfo forKey:_coderRosterInfo_];
    [aCoder encodeObject:self.email forKey:_coderEmail_];
    [aCoder encodeObject:self.trade forKey:_coderTrade_];
    [aCoder encodeObject:self.vocation forKey:_coderVocation_];
    
    [aCoder encodeObject:self.area forKey:_coderArea_];
    [aCoder encodeObject:self.areaID forKey:_coderAreaID_];
  
    [aCoder encodeDouble:self.defalutAddrLat forKey:_coderDefaultAddrLat_];
    [aCoder encodeDouble:self.defaultAddrLon forKey:_coderDefaultAddrLon_];
    [aCoder encodeObject:self.defaultAddr forKey:_coderDefaultAddr_];
    [aCoder encodeBool:self.status forKey:_coderStatus_];
    [aCoder encodeObject:self.phoneNum forKey:_coderPhoneNum_];
    [aCoder encodeBool:self.phoneState forKey:_coderPhoneState_];
    
    [aCoder encodeInteger:self.height forKey:_coderHeight_];
    [aCoder encodeInteger:self.weight forKey:_coderWeight_];
    [aCoder encodeObject:self.bust forKey:_coderBust_];
    [aCoder encodeInteger:self.waist forKey:_coderWaist_];
    [aCoder encodeInteger:self.hip forKey:_coderHip_];
    
    [aCoder encodeObject:self.birthday forKey:_coderBirthday_];
    [aCoder encodeObject:self.character forKey:_coderCharactor_];
    [aCoder encodeObject:self.education forKey:_coderEducation_];
    
    [aCoder encodeObject:self.nameModifyTime forKey:_coderNameModifyTime_];
    
    [aCoder encodeInt:self.appointmentCount forKey:_coderAppointmentCount_];
    [aCoder encodeInt:self.notKeepAppointmentCount forKey:_coderNotKeepAppointmentCount_];
    [aCoder encodeInt:self.beLateAppointmentCount forKey:_coderBeLateAppointmentCount_];
}

- (void)dealloc
{
    [_rosterInfo release];
    
    [_email release];
    [_trade release];
    [_vocation release];
    
    [_area release];
    [_areaID release];
    
    [_phoneNum release];
    
    [_bust release];
    
    [_birthday release];
    [_character release];
    [_education release];
    
    [_defaultAddr release];
    [_nameModifyTime release];
    
    [super dealloc];
}

/**分离地址
 */
- (NSDictionary*)strAddrAndPoiAddr
{
    return [JBoMapInfo strAddrAndPoiAddrFromAddress:self.defaultAddr];
}

- (NSString*)strAddr:(NSString *)strAddr andPoiAddr:(NSString *)poiAddr
{
    return [JBoMapInfo strAddr:strAddr andPoiAddr:poiAddr];
}

/**是否可以修改昵称
 */
- (NSString*)canModifyName
{
    if(self.rosterInfo.role == _rosterRoleNormal_)
    {
        return nil;
    }
    else
    {
        if([NSString isEmpty:self.nameModifyTime])
        {
            return nil;
        }
        else
        {
            NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
            [formatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
            [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/BeiJing"]];
            
            NSDate *date = [formatter dateFromString:self.nameModifyTime];
            
            NSTimeInterval interval = -[date timeIntervalSinceNow];
            
            if(interval < _rosterNameUpdateInterval_)
            {
                NSDate *canDate = [NSDate dateWithTimeInterval:_rosterNameUpdateInterval_ sinceDate:date];
                return [formatter stringFromDate:canDate];
            }
            else
            {
                return nil;
            }
        }
    }
}

/**从集合里面获取个人信息
 *@param dic 含有个人信息的字典
 */
- (void)infoFromDictionary:(NSDictionary*) dic
{
    self.phoneNum = [dic objectWithKey:_rosterPhoneNum_];
    self.rosterInfo.sex = [[dic valueWithKey:_rosterSex_] intValue];
    NSString *email = [dic objectWithKey:_rosterEmail_];
    self.email = [JBoUserOperation getEmailFromStr:email];
    self.trade = [dic objectWithKey:_rosterTrade_];
    self.vocation = [dic objectWithKey:_rosterVocation_];
    self.area = [dic objectWithKey:_rosterArea_];
    self.areaID = [dic objectWithKey:_rosterAreaId_];
    self.phoneState = [[dic valueWithKey:_rosterPhoneState_] boolValue];
    
    self.rosterInfo.username = [dic objectWithKey:_rosterUserId_];
    self.rosterInfo.name = [dic objectWithKey:_rosterName_];
    
    self.rosterInfo.role = [[dic valueWithKey:_rosterRole_] integerValue];
    self.rosterInfo.enterpriseAddr = [dic objectWithKey:_rosterEnterpriseAddr_];
    self.rosterInfo.enterpriseName = [dic objectWithKey:_rosterEnterpriseName_];
    self.rosterInfo.enterpriseTelePhone = [dic objectWithKey:_rosterEnterpriseTelephone_];
    self.rosterInfo.realName = [dic objectWithKey:_rosterRealName_];
    
    self.rosterInfo.presence = [dic objectWithKey:_rosterPresence_];
    self.rosterInfo.jid = [dic objectWithKey:_rosterJid_];
    self.rosterInfo.imageURL = [dic objectWithKey:_rosterImageURL_];
    
    //身高 体重
    self.height = [[dic valueWithKey:_rosterHeight_] integerValue];
    self.weight = [[dic valueWithKey:_rosterWeight_] integerValue];
    
    //三围
    self.bust = [dic objectWithKey:_rosterBust_];
    self.waist = [[dic valueWithKey:_rosterWaist_] integerValue];
    self.hip = [[dic valueWithKey:_rosterHip_] integerValue];
    
    //学历 性格 出生日期
    self.education = [dic objectWithKey:_rosterEducation_];
    self.character = [dic objectWithKey:_rosterCharacter_];
    self.birthday = [dic objectWithKey:_rosterBirthday_];
    
    //默认地址
    self.defaultAddr = [dic objectWithKey:_rosterDefaultAddr_];
    self.defalutAddrLat = [[dic valueWithKey:_rosterDefaultLat_] doubleValue];
    self.defaultAddrLon = [[dic valueWithKey:_rosterDefaultLon_] doubleValue];
    
    self.nameModifyTime = [dic objectWithKey:_rosterNameUpdateTime_];
}

/**保存当前登录的用户信息
 */
- (void)saveUserDetailInfoToUserDefaults
{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:self];
    if(data)
    {
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:_loginDetailUserInfo_];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

#pragma mark- class method

/**获取当前登录的用户信息
 */
+ (JBoUserDetailInfo*)userDetailInfoFromUserDetaults
{
    return [JBoUserOperation getUserDetailInfo];
}



@end
