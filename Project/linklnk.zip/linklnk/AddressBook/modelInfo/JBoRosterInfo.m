//
//  JBoRosterInfo.m
//  简宝
//
//  Created by kinghe005 on 13-11-1.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoRosterInfo.h"

#define _coderSqlId_ @"coderSqlId"
#define _coderJid_ @"coderJid"
#define _coderUsername_ @"coderUsername"
#define _coderName_ @"coderName"
#define _coderKey_ @"coderKey"
#define _coderPresence_ @"coderPresence"
#define _coderSex_ @"coderSex"
#define _coderRemark_ @"coderRemark"
#define _coderImage_ @"coderImage"
#define _coderState_ @"coderState"
#define _coderImageURL_ @"coderImageURL"
#define _coderRole_ @"coderRole"
#define _coderEnterpriseName_ @"coderEnterpriseName"
#define _coderEnterpriseAddr_ @"coderEnterpriseAddr"
#define _coderEnterPriseTelePhone_ @"coderEnterPriseTelePhone"
#define _coderRealName_ @"coderRealName"

@implementation JBoRosterInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        
    }
    return self;
}

- (void)dealloc
{
    [_jid release];
    [_username release];
    [_name release];
    
    [_key release];
    [_presence release];
    
    [_remark release];
    [_image release];
    [_imageURL release];
    
    [_enterpriseName release];
    [_enterpriseAddr release];
    [_enterpriseTelePhone release];
    
    [_realName release];
    
    [super dealloc];
}

- (id)copyWithZone:(NSZone *)zone
{
    JBoRosterInfo *rosterInfo = [[JBoRosterInfo allocWithZone:zone] init];
    
    rosterInfo.sqlId = self.sqlId;
    rosterInfo.jid = self.jid;
    rosterInfo.name = self.name;
    rosterInfo.username = self.username;
    rosterInfo.key = self.key;
    rosterInfo.presence = self.presence;
    rosterInfo.sex = self.sex;
    rosterInfo.remark = self.remark;
    rosterInfo.image = self.image;
    rosterInfo.state = self.state;
    rosterInfo.imageURL = self.imageURL;
    
    rosterInfo.role = self.role;
    rosterInfo.enterpriseAddr = self.enterpriseAddr;
    rosterInfo.enterpriseName = self.enterpriseName;
    rosterInfo.enterpriseTelePhone = self.enterpriseTelePhone;
    rosterInfo.realName = self.realName;
    
    return rosterInfo;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super init];
    if(self)
    {
        self.sqlId = [aDecoder decodeInt64ForKey:_coderSqlId_];
        self.jid = [aDecoder decodeObjectForKey:_coderJid_];
        self.username = [aDecoder decodeObjectForKey:_coderUsername_];
        self.name = [aDecoder decodeObjectForKey:_coderName_];
        self.key = [aDecoder decodeObjectForKey:_coderKey_];
        self.presence = [aDecoder decodeObjectForKey:_coderPresence_];
        self.sex = [aDecoder decodeIntForKey:_coderSex_];
        self.remark = [aDecoder decodeObjectForKey:_coderRemark_];
        self.image = [aDecoder decodeObjectForKey:_coderImage_];
        self.state = [aDecoder decodeBoolForKey:_coderState_];
        self.imageURL = [aDecoder decodeObjectForKey:_coderImageURL_];
        
        self.role = [aDecoder decodeIntegerForKey:_coderRole_];
        self.enterpriseName = [aDecoder decodeObjectForKey:_coderEnterpriseName_];
        self.enterpriseAddr = [aDecoder decodeObjectForKey:_coderEnterpriseAddr_];
        self.enterpriseTelePhone = [aDecoder decodeObjectForKey:_coderEnterPriseTelePhone_];
        self.realName = [aDecoder decodeObjectForKey:_coderRealName_];
    }
    
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeInt64:self.sqlId forKey:_coderSqlId_];
    [aCoder encodeObject:self.jid forKey:_coderJid_];
    [aCoder encodeObject:self.username forKey:_coderUsername_];
    [aCoder encodeObject:self.name forKey:_coderName_];
    [aCoder encodeObject:self.key forKey:_coderKey_];
    [aCoder encodeObject:self.presence forKey:_coderPresence_];
    [aCoder encodeInt:self.sex forKey:_coderSex_];
    [aCoder encodeObject:self.remark forKey:_coderRemark_];
    [aCoder encodeObject:self.image forKey:_coderImage_];
    [aCoder encodeBool:self.state forKey:_coderState_];
    [aCoder encodeObject:self.imageURL forKey:_coderImageURL_];
    
    [aCoder encodeInteger:self.role forKey:_coderRole_];
    [aCoder encodeObject:self.enterpriseName forKey:_coderEnterpriseName_];
    [aCoder encodeObject:self.enterpriseAddr forKey:_coderEnterpriseAddr_];
    [aCoder encodeObject:self.enterpriseTelePhone forKey:_coderEnterPriseTelePhone_];
    [aCoder encodeObject:self.realName forKey:_coderRealName_];
}

@end
