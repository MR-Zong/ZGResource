//
//  JBoUserDetailInfo.h
//  连客
//
//  Created by kinghe005 on 13-11-28.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoRosterInfo.h"
#import "JBoBasic.h"

/**展现给用户看的信息
 */
@interface JBoUserListInfo : NSObject

/**信息标题
 */
@property(nonatomic,copy) NSString *title;

/**信息内容
 */
@property(nonatomic,copy) NSString *content;

/**标题宽度 defaulit is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger titleWidth;

/**内容高度 defaulit is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger contentHeight;

/**内容类型
 */
@property(nonatomic,assign) JBoUserInfoType type;

/**是否可以修改 default is 'NO'
 */
@property(nonatomic,assign) BOOL editable;

+ (id)userListInfoWithTitle:(NSString*) title content:(NSString*) content;

@end

@interface JBoUserDetailInfo : NSObject<NSCopying,NSCoding>

@property(nonatomic,retain) JBoRosterInfo *rosterInfo;

//邮箱 行业 职业
@property(nonatomic,copy) NSString *email;
@property(nonatomic,copy) NSString *trade;
@property(nonatomic,copy) NSString *vocation;

//角色 地址
@property(nonatomic,copy) NSString *area;
@property(nonatomic,copy) NSString *areaID;

//是否已关注
@property(nonatomic,assign) BOOL attention;

//手机号 是否公开
@property(nonatomic,copy) NSString *phoneNum;
@property(nonatomic,assign) BOOL phoneState;

//表明添加好友需不需要验证
@property(nonatomic,assign) BOOL status;

//身高cm 体重 三围
@property(nonatomic,assign) NSInteger height;
@property(nonatomic,readonly) NSString *heightString;

@property(nonatomic,assign) NSInteger weight;
@property(nonatomic,readonly) NSString *weightString;

@property(nonatomic,copy) NSString *bust;
@property(nonatomic,assign) NSInteger waist;
@property(nonatomic,assign) NSInteger hip;
@property(nonatomic,readonly) NSString *bwhString;

//出生年月日 性格 学历
@property(nonatomic,copy) NSString *birthday;
@property(nonatomic,copy) NSString *character;
@property(nonatomic,copy) NSString *education;

/**默认地址
 */
@property(nonatomic,copy) NSString *defaultAddr;
@property(nonatomic,assign) double defalutAddrLat;
@property(nonatomic,assign) double defaultAddrLon;

/**预约次数
 */
@property(nonatomic,assign) int appointmentCount;

/**未赴约次数
 */
@property(nonatomic,assign) int notKeepAppointmentCount;

/**迟到次数
 */
@property(nonatomic,assign) int beLateAppointmentCount;

//昵称修改时间
@property(nonatomic,copy) NSString *nameModifyTime;

- (id)init;

//获取用户信息的列表 数组元素时JBoUserListInfo 对象
- (NSArray*)getInfoList;

//获取所有信息列表
//- (NSArray*)getAllInfoList;

//获取公开信息 数组元素时JBoUserListInfo 对象
- (NSArray*) getPublicInfo;

/**获取当前登录用户的信息列表
 *@return 数组元素是数组NSMutableArray, 次级数组元素是JBoUserListInfo
 */
- (NSArray*) getLoginUserInfoList;

/**分离地址
 */
- (NSDictionary*)strAddrAndPoiAddr;

/**合并地址
 */
- (NSString*)strAddr:(NSString*) strAddr andPoiAddr:(NSString*) poiAddr;

/**是否可以修改昵称
 *@return 如果可以修改，返回nil,否则返回可以修改的具体时间
 */
- (NSString*)canModifyName;

/**从集合里面获取个人信息
 *@param dic 含有个人信息的字典
 */
- (void)infoFromDictionary:(NSDictionary*) dic;

/**保存当前登录的用户信息
 */
- (void)saveUserDetailInfoToUserDefaults;

/**获取当前登录的用户信息
 */
+ (JBoUserDetailInfo*)userDetailInfoFromUserDetaults;



@end
