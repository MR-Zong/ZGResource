//
//  JBoUserParentInfo.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**个人信息基类
 */
@interface JBoUserParentInfo : NSObject

/**用户Id
 */
@property(nonatomic,copy) NSString *userId;

/**昵称
 */
@property(nonatomic,copy) NSString *name;

/**性别
 */
@property(nonatomic,assign) NSInteger sex;

/**用户身份
 */
@property(nonatomic,assign) NSInteger role;

/**头像路径
 */
@property(nonatomic,copy) NSString *headImageURL;

/**头像
 */
@property(nonatomic,retain) UIImage *headImage;

@end
