//
//  JBoUserLocationInfo.m
//  连你
//
//  Created by kinghe005 on 14-1-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserLocationInfo.h"

@implementation JBoUserLocationInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.info = [[[JBoMapInfo alloc] init] autorelease];
        self.curLoc = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_info release];
    
    [super dealloc];
}

@end


