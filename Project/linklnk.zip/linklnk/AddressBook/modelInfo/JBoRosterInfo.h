//
//  JBoRosterInfo.h
//  简宝
//
//  Created by kinghe005 on 13-11-1.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JBoRosterInfo : NSObject<NSCopying,NSCoding>

//数据库Id
@property(nonatomic,assign) long long sqlId;

//好友jid 账号 昵称
@property(nonatomic,copy) NSString *jid;
@property(nonatomic,copy) NSString *username;
@property(nonatomic,copy) NSString *name;

//关键字首字母 心情 性别
@property(nonatomic,copy) NSString *key;
@property(nonatomic,copy) NSString *presence;
@property(nonatomic,assign) int sex;

//备注名 头像路径 是否在线
@property(nonatomic,copy) NSString *remark;
@property(nonatomic,retain) UIImage *image;
@property(nonatomic,copy) NSString *imageURL;
@property(nonatomic,assign) BOOL state;

//身份 企业名称 企业地址 企业固话
@property(nonatomic,assign) NSInteger role;
@property(nonatomic,copy) NSString *enterpriseName;
@property(nonatomic,copy) NSString *enterpriseAddr;
@property(nonatomic,copy) NSString *enterpriseTelePhone;

/**个人认证真实姓名
 */
@property(nonatomic,copy) NSString *realName;

@end
