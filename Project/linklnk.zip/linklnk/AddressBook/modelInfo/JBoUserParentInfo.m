//
//  JBoUserParentInfo.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserParentInfo.h"

@implementation JBoUserParentInfo

- (void)dealloc
{
    [_userId release];
    [_name release];
    
    [_headImageURL release];
    [_headImage release];
    
    [super dealloc];
}

@end
