//
//  JBoUserLocationInfo.h
//  连你
//
//  Created by kinghe005 on 14-1-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "JBoMapViewController.h"


@interface JBoUserLocationInfo : NSObject

@property(nonatomic,retain) JBoMapInfo *info;
/**范围
 */
@property(nonatomic,assign) int radius;

/**是否是当前位置 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger curLoc;
/**是否正在定位中
 */
@property(nonatomic,assign) BOOL locating;

@end

