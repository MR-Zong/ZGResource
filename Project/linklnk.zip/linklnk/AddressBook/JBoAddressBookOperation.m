//
//  JBoAddressBookOperation.m
//  连你
//
//  Created by kinghe005 on 14-5-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAddressBookOperation.h"
#import "JBoAppDelegate.h"
#import "JBoImageCacheTool.h"
#import "ChineseToPinyin.h"
#import "FMDatabaseQueue.h"

@interface JBoAddressBookOperation ()
{
    JBoAppDelegate *_appDelegate;
    FMDatabaseQueue *_dbQueue;
}

@end

@implementation JBoAddressBookOperation

- (id)init
{
    self = [super init];
    if(self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        //创建数据库连接
        NSString *sqlitePath = [JBoImageCacheTool getSqlitePathWithSqliteName:_addressBookSqlite_];
        
        _dbQueue = [[FMDatabaseQueue alloc] initWithPath:sqlitePath];
        [_dbQueue inDatabase:^(FMDatabase *db){
            
            db.logsErrors = YES;
            if(![db open])
            {
                NSLog(@"不能打开数据库");
            }
            else
            {
                if(![db executeUpdate:_createRosterTable_])
                {
                    NSLog(@"创建花名册表失败");
                }
                
                if(![db executeUpdate:_createBlackListTable_])
                {
                    NSLog(@"创建黑名单表失败");
                }
            }
        }];
    }
    return self;
}

- (void)dealloc
{
    [_dbQueue close];
    [_dbQueue release];
    
    [super dealloc];
}

#pragma mark-花名册

//获取花名册
- (void)getRosterListWithKeywords:(NSMutableArray *)keywords rosterDic:(NSMutableDictionary *)rosterDic rosterAndUsernameDic:(NSMutableDictionary *)rosterAndUsernameDic
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        db.logsErrors = YES;
        NSMutableArray *tmpKeyArray = [[NSMutableArray alloc] init];
        FMResultSet *rs = [db executeQuery:_selectedRoster_];
        while ([rs next])
        {
            JBoRosterInfo *info = [[[JBoRosterInfo alloc] init] autorelease];
            info.username = [rs stringForColumn:_rosterColumnUserId_];
            if([NSString isEmpty:info.username])
                continue;
            
            info.sqlId = [rs longLongIntForColumn:_rosterColumnId_];
            info.jid = [rs stringForColumn:_rosterColumnJid_];
            info.name = [rs stringForColumn:_rosterColumnName_];
            
            
            info.sex = [rs intForColumn:_rosterColumnSex_];
            info.presence = [rs stringForColumn:_rosterColumnPresence_];
            info.remark = [rs stringForColumn:_rosterColumnRemark_];
            info.state = NO;
            info.imageURL = [rs stringForColumn:_rosterColumnImageURL_];
            info.role = [rs intForColumn:_rosterColumnRole_];
            
            if([info.username isEqualToString:_linklnkUserId_])
            {
                info.key = _linklnkKey_;
            }
            else
            {
                NSString *name = [info.name stringByReplacingOccurrencesOfString:@" " withString:@""];
                char c = [ChineseToPinyin sortSectionTitle:name];
                
                if(c <'A' || c > 'Z')
                    c = '#';
                
                info.key = [NSString stringWithFormat:@"%c",c];
            }
            
            [rosterAndUsernameDic setObject:info forKey:info.username];
            
            NSMutableArray *tmpArray = [rosterDic objectForKey:info.key];
            
            if(tmpArray == nil)
            {
                tmpArray = [[NSMutableArray alloc] init];
                [tmpArray addObject:info];
                [rosterDic setObject:tmpArray forKey:info.key];
                
                [tmpKeyArray addObject:info.key];
                [tmpArray release];
            }
            else
            {
                [tmpArray addObject:info];
            }
        }
        
        //排序关键字
        [keywords addObjectsFromArray:[tmpKeyArray sortedArrayUsingComparator:^(id obj1, id obj2){
            if([obj1 characterAtIndex:0] > [obj2 characterAtIndex:0])
            {
                return (NSComparisonResult)NSOrderedDescending;
            }
            else if([obj1 characterAtIndex:0] < [obj2 characterAtIndex:0])
            {
                return (NSComparisonResult)NSOrderedAscending;
            }
            else
            {
                return (NSComparisonResult)NSOrderedSame;
            }
            
        }]];
        
        [tmpKeyArray release];
        if([keywords containsObject:_linklnkKey_])
        {
            [keywords removeObject:_linklnkKey_];
            [keywords insertObject:_linklnkKey_ atIndex:0];
        }
    }];
}

//删除联系人
- (void)removeRosterWithId:(sqlite3_int64) sqlId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_removeOneFromRoster_, [NSNumber numberWithLongLong:sqlId]])
        {
            NSLog(@"删除一个联系人失败");
        }
    }];
}

- (void)removeRosterWithUserId:(NSString*) userId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_removeOneFromRosterWithUserId_, userId])
        {
             NSLog(@"删除一个联系人失败");
        }
    }];
}

//新增联系人
- (void)addNewContact:(JBoRosterInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_insertRoster_, info.jid, info.username, info.name, [NSNumber numberWithInteger:info.sex], info.presence, info.remark, info.imageURL, [NSNumber numberWithInteger:info.role]])
        {
            sqlite3_int64 rowId = [db lastInsertRowId];
            info.sqlId = rowId;
            NSLog(@"插入一个联系人失败%lld", rowId);
        }
    }];
}

//修改备足
- (void)modifyRemark:(NSString*)remark withId:(sqlite3_int64) sqlId
{
     [_dbQueue inDatabase:^(FMDatabase *db){
         
         db.logsErrors = YES;
         if(![db executeUpdate:_updateRosterRemark_, remark, [NSNumber numberWithLongLong:sqlId]])
         {
             NSLog(@"修改备注名失败");
         }
     }];
}

//删除所有联系人
- (void)removeAllRoster
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_removeAllRoster_])
        {
            NSLog(@"删除所有联系人失败");
        }
    }];
}

#pragma mark-黑名单
//获取黑名单
- (NSMutableArray*)getBlackList
{
    NSMutableArray *blackLists = [[NSMutableArray alloc] init];
    
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        db.logsErrors = YES;
        FMResultSet *rs = [db executeQuery:_selectedBlackList_];
        while ([rs next])
        {
            NSString *userId = [rs stringForColumn:_rosterColumnUserId_];
            if(![NSString isEmpty:userId])
            {
                [blackLists addObject:userId];
            }
        }
    }];
    
    return [blackLists autorelease];
}

//新增黑名单
- (void)addNewBlackList:(JBoRosterInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_insertBlackList_, info.jid, info.username, info.name, [NSNumber numberWithInteger:info.sex], info.presence, info.remark, info.imageURL, [NSNumber numberWithInteger:info.role]])
        {
            NSLog(@"新增黑名单失败");
        }
    }];
}

//删除黑名单
- (void)removeOneBlackListWithUserId:(NSString *)userId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
      
        db.logsErrors = YES;
        if(![db executeUpdate:_removeOneFromBlackList_, userId])
        {
            NSLog(@"删除黑名单失败");
        }
    }];
}

//删除所有黑名单
- (void)removeAllBlackList
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_removeAllBlackList_])
        {
            NSLog(@"删除所有黑名单失败");
        }
    }];
}

@end
