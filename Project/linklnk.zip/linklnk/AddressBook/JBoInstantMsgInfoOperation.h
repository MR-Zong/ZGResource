//
//  JBoInstantMsgInfoOperation.h
//  连客
//
//  Created by kinghe005 on 13-11-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoUserDetailInfo.h"

#define _takeContactToBlacklistElementID_ @"takeContactToBlacklistElementID" //添加至黑名单
#define _modifyContactRemarkElementID_ @"modifyContactRemarkElementID" //修改备注名

#define _getRosterInfoElementID_ @"getRosterInfoElementID" //获取好友花名册
#define _getUserHeadImageElmentID_ @"getUserHeadImageElmentID" //获取用户头像
#define _modifyUserHeadImageElementID_ @"modifyUserHeadImageElementID"  //修改用户头像
#define _getUserDetailInfoElementID_ @"getUserDetailInfoElementID"   //获取个人信息
#define _modifyUserDetailInfoElementID_ @"modifyUserDetailInfoElementID" //修改个人详细信息

#define _getTradeListElementID_ @"getTradeListElementID" //获取行业

@class XMPPIQ;
@interface JBoInstantMsgInfoOperation : NSObject

- (id)init;

//注销登录
- (void)exitAction;

@end
