//
//  JBoContactListView.h
//  靓咖
//
//  Created by kinghe005 on 14-9-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoAddressBookOperation.h"

@class JBoLettersSearchBar;

/**联系人列表
 */
@interface JBoContactListView : UIView<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
{
    UITableView *_tableView;
    //搜索栏
    UISearchBar *_searchBar;
    //搜索栏搜索结果
    NSMutableArray *_searchResultArray;
    //字母搜索栏
    JBoLettersSearchBar *_lettersView;
    
    BOOL _isLoading; //数据是否加载中
    
    //黑色半透明视图
    UIView *_transparentView;
    
}

@property(nonatomic,assign) UINavigationController *navigationController;

@property(nonatomic,readonly) NSMutableArray *keywordArray; //表示图header的数据
@property(nonatomic,readonly) NSMutableDictionary *rosterDic;  //花名册
@property(nonatomic,readonly) JBoAddressBookOperation *addressBookOperation;

//获取花名册
- (void)getRosterListFromLocation;

//获取黑名单
- (void)getBlacklist;

- (void)reloadData;

@end
