//
//  JBoUserHeadImageView.h
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoImageView.h"

/**用户头像
 */
@interface JBoUserHeadImageView : UIView

@property(nonatomic,readonly) JBoImageView *imageView;

@property(nonatomic,assign) NSInteger sex;

//用户身份
@property(nonatomic,assign) NSInteger role;

/**隐藏认证标志
 */
@property(nonatomic,assign) BOOL hiddenIcon;

/**实名认证标志
 */
@property(nonatomic,readonly) UIImageView *iconImageView;

/**图标的位置 default is ‘CGPointZero’
 */
@property(nonatomic,assign) CGPoint iconOffset;

/**头像路径
 */
@property(nonatomic,assign) NSString *headImageURL;

@property(nonatomic,readonly) UIImage *image;

@end
