//
//  JBoRelatedUserListCell.h
//  linklnk
//
//  Created by kinghe005 on 15-3-17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoUserHeadImageView,JBoUserNameLabel,JBoRosterInfo,JBoRelatedUserListCell;

/**关联的人的列表信息代理
 */
@protocol JBoRelatedUserListCellDelegate <NSObject>

/**获取次级关联的人的信息
 */
- (void)relatedUserListCellDidGetSecondaryInfos:(JBoRelatedUserListCell*) cell;

@end

/**关联的人的列表信息
 */
@interface JBoRelatedUserListCell : UITableViewCell

@property(nonatomic,assign) id<JBoRelatedUserListCellDelegate> delegate;

/**头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**个性签名
 */
@property(nonatomic,readonly) UILabel *presentLabel;

/**次级关联的人的人数
 */
@property(nonatomic,readonly) UIButton *countButton;

/**个人信息
 */
@property(nonatomic,assign) JBoRosterInfo *info;

/**行高
 */
+ (CGFloat)rowHeight;

@end
