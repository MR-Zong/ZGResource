//
//  JBoRelatedUserListCell.m
//  linklnk
//
//  Created by kinghe005 on 15-3-17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoRelatedUserListCell.h"
#import "JBoUserHeadImageView.h"
#import "JBoRosterInfo.h"
#import "JBoUserNameLabel.h"
#import "JBoBasic.h"

#define _JBoRelatedUserListCellHeight_ 60
#define _JBoRelatedUserListCellMargin_ 10

@implementation JBoRelatedUserListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        CGFloat contentHeight = _JBoRelatedUserListCellHeight_ - _JBoRelatedUserListCellMargin_ * 2;
        CGFloat width = _width_ - _JBoRelatedUserListCellMargin_ * 3 - contentHeight;
        
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_JBoRelatedUserListCellMargin_, _JBoRelatedUserListCellMargin_, contentHeight, contentHeight)];
        _headImageView.userInteractionEnabled = YES;
        [self.contentView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _JBoRelatedUserListCellMargin_, _JBoRelatedUserListCellMargin_, width / 2.0, contentHeight / 2.0)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        [self.contentView addSubview:_nameLabel];
        
        _presentLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _nameLabel.bottom, width, _nameLabel.width)];
        _presentLabel.backgroundColor = [UIColor clearColor];
        _presentLabel.textColor = [UIColor clearColor];
        _presentLabel.font = [UIFont systemFontOfSize:_userNameFontSize_];
        [self.contentView addSubview:_presentLabel];
        
        UIImage *image = [UIImage imageNamed:@"arrow"];
        _countButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_countButton setFrame:CGRectMake(_nameLabel.right, _nameLabel.top, width / 2.0, _nameLabel.height)];
        [_countButton addTarget:self action:@selector(getSecondaryInfo:) forControlEvents:UIControlEventTouchUpInside];
        [_countButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        _countButton.titleLabel.font = [UIFont systemFontOfSize:13.0];
        [_countButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
        [_countButton setImage:image forState:UIControlStateNormal];
        [_countButton setAdjustsImageWhenDisabled:NO];
        [_countButton setAdjustsImageWhenHighlighted:NO];
        [_countButton setTitleEdgeInsets:UIEdgeInsetsMake(0, - image.size.width, 0, image.size.width)];
        [_countButton setImageEdgeInsets:UIEdgeInsetsMake(0, 27.0, 0, - 27.0)];
        [self.contentView addSubview:_countButton];
    }
    
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    [_headImageView release];
    [_nameLabel release];
    [_presentLabel release];
    
    [super dealloc];
}

- (void)setInfo:(JBoRosterInfo *)info
{
    _headImageView.sex = info.sex;
    _headImageView.headImageURL = info.imageURL;
    _nameLabel.sex = info.sex;
    _nameLabel.text = info.name;
}

/**获取次级关联的人的信息
 */
- (void)getSecondaryInfo:(id) sender
{
    if([self.delegate respondsToSelector:@selector(relatedUserListCellDidGetSecondaryInfos:)])
    {
        [self.delegate relatedUserListCellDidGetSecondaryInfos:self];
    }
}

#pragma mark- class method

/**行高
 */
+ (CGFloat)rowHeight
{
    return _JBoRelatedUserListCellHeight_;
}

@end
