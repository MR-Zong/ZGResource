//
//  JBoUserHeadImageView.m
//  连客
//
//  Created by kinghe005 on 13-12-27.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserHeadImageView.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoBasic.h"

@implementation JBoUserHeadImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.iconOffset = CGPointZero;
        
        _imageView = [[JBoImageView alloc] initWithFrame:self.bounds];
        _imageView.layer.cornerRadius = 3.0;
        _imageView.layer.masksToBounds = YES;
        [self addSubview:_imageView];

        CGFloat size = self.frame.size.width / 5.0;
         CGFloat interval = size / 2.0 > 5.0 ? 5.0 : size / 2.0;
        _iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.frame.size.width - size + interval, - interval, size, size)];
        _iconImageView.userInteractionEnabled = YES;
        [self addSubview:_iconImageView];
        
        self.sex = _sexGirl_;
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    _imageView.frame = self.bounds;
    
    CGFloat size = self.width / 5.0;
    
    CGPoint point = self.iconOffset;
    if(CGPointEqualToPoint(point, CGPointZero))
    {
        CGFloat interval = size / 2.0 > 5.0 ? 5.0 : size / 2.0;
        point = CGPointMake(self.width - size + interval, - interval);
    }
    
    _iconImageView.frame = CGRectMake(point.x, point.y, size, size);
}

- (void)setSex:(NSInteger)sex
{
    if(sex == _sexGirl_)
    {
        self.imageView.placeHolderImage = [UIImage imageNamed:@"default_girl_image"];
    }
    else
    {
        self.imageView.placeHolderImage = [UIImage imageNamed:@"default_boy_image"];
    }
    
}

- (void)setRole:(NSInteger)role
{
    _role = role;
    
    switch (_role)
    {
        case _rosterRoleEnterprise_ :
        {
            _iconImageView.hidden = NO;
            _iconImageView.image = [UIImage imageNamed:@"enterpriseIcon.png"];
        }
            break;
            case _rosterRolePerson_ :
        {
            _iconImageView.hidden = NO;
            _iconImageView.image = [UIImage imageNamed:@"person_icon.png"];
        }
            break;
        default:
            _iconImageView.hidden = YES;
            break;
    }
}

- (void)setHiddenIcon:(BOOL)hiddenIcon
{
    _hiddenIcon = hiddenIcon;
    _iconImageView.hidden = _hiddenIcon;
}

- (void)setHeadImageURL:(NSString *)headImageURL
{
    [self.imageView getImageWithURL:headImageURL useCache:YES cacheType:JBoImageCacheTypeHeadImage];
}

- (UIImage*)image
{
    UIImage *image = self.imageView.placeHolderImage;
    if(_headImageURL)
    {
        JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
        image = [cache imageForURL:_headImageURL thumbnailSize:CGSizeZero];
    }
    else if(self.imageView.image)
    {
        image = self.imageView.image;
    }
    
    return image;
}

- (void)dealloc
{
    [_iconImageView release];
    [_imageView release];
    
    [super dealloc];
}

@end
