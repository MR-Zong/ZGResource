//
//  JBoUserTableHeaderView.h
//  靓咖
//
//  Created by kinghe005 on 14-8-19.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoUserHeadImageView;
@class JBoAsyncImageView;
@class JBoUserNameLabel;
@class JBoAttributedLabel;
@class JBoUserDetailInfo;
@class JBoImageCacheTool;
@class JBoUserInfoTableHeaderView;

/**用户关系
 */
typedef NS_ENUM(NSInteger, JBoUserRelation)
{
    JBoUserRelationFriend = 0, ///好友
    JBoUserRelationStranger = 1, ///陌生人
    JBoUserRelationQRCodeCard = 2, ///二维码名片扫描
    JBoUserRelationNearbySecret = 3, ///附近秘密用户
};

/**个人信息视图代理
 */
@protocol JBoUserInfoTableHeaderViewDelegate <NSObject>

/**用户需要加载靓友圈信息
 */
- (void)userInfoTableHeaderViewNeedSeeLookAndTell:(JBoUserInfoTableHeaderView*) header;

@end

/**个信息视图，tableView的表头
 */
@interface JBoUserInfoTableHeaderView : UIView<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,assign) id<JBoUserInfoTableHeaderViewDelegate> delegate;

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**用户昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**靓友圈背景
 */
@property(nonatomic,readonly) JBoAsyncImageView *circleImageView;

/**要显示的用户信息
 */
@property(nonatomic,readonly,retain) JBoUserDetailInfo *userDetailInfo;

/**状态栏颜色 default is 'NO'
 */
@property(nonatomic,assign) BOOL black;

/**用户信息 数组元素是 JBoUserListInfo对象
 */
@property(nonatomic,retain) NSArray *infoArray;

/**用户信息列表
 */
@property(nonatomic,readonly) UITableView *tableView;

/**跳转导航栏
 */
@property(nonatomic,assign) UINavigationController *navigationController;

/**靓云台链接
 */
@property(nonatomic,readonly,retain) JBoAttributedLabel *linkLabel;

/**靓友圈信息
 */
@property(nonatomic,readonly,retain) JBoAttributedLabel *msgLabel;

/**用户关系
 */
@property(nonatomic,readonly) JBoUserRelation userRelation;

/**以用户信息初始化
 *@param info 用户信息
 *@param imageCacheTool 图片缓存
 *@param relation 用户关系
 *@return 一个初始化的 JBoUserInfoTableHeaderView 对象
 */
- (id)initWithUserDetailInfo:(JBoUserDetailInfo*) info relation:(JBoUserRelation) relation;

/**加载视图
 */
- (void)loadView;

/**获取用户信息列表 默认不做任何事 子类必须实现该方法
 */
- (void)loadUserInfo;

/**靓友圈信息加载完成
 *@param hasInfo 是否有靓友圈信息
 */
- (void)lookAndTellDidLoad:(BOOL) hasInfo;

@end
