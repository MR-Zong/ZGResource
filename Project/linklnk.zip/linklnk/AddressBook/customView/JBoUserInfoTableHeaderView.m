//
//  JBoUserTableHeaderView.m
//  靓咖
//
//  Created by kinghe005 on 14-8-19.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserInfoTableHeaderView.h"
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoAttributedLabel.h"
#import "JBoAsyncImageView.h"
#import "JBoUserDetailInfo.h"
#import "JBoUserInfoCell.h"
#import "JBoImageBrowerViewController.h"
#import "JBoAppDelegate.h"
#import "JBoImageTextTool.h"
#import "JBoWebViewController.h"
#import "JBoImageCacheTool.h"
#import "JBoBasic.h"

#define _paddingLeftAndRight_ 12
#define _paddingTop_ 10

#define _cellHeight_ (_userInfoCellcontrolHeight_ + _userInfoCellcontrolInterval_ * 2)

#undef _controlHeight_

#define _controlHeight_ 20
#define _controlInterval_ 5

#define _buttonWidth_ 20
#define _buttonHeight_ 100

@interface JBoUserInfoTableHeaderView ()

//分割线
@property(nonatomic,retain) UIView *line;

@end

@implementation JBoUserInfoTableHeaderView

/**以用户信息初始化
 *@param info 用户信息
 *@param imageCacheTool 图片缓存
 *@param relation 用户关系
 *@return 一个初始化的 JBoUserInfoTableHeaderView 对象
 */
- (id)initWithUserDetailInfo:(JBoUserDetailInfo*) info relation:(JBoUserRelation) relation
{
    self = [super initWithFrame:CGRectMake(0, 0, _width_, 0)];
    if (self)
    {
        _userRelation = relation;
        _userDetailInfo = [info retain];
        [self loadView];
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    
    [_circleImageView release];
    [_userDetailInfo release];
    
    [_infoArray release];
    [_tableView release];
    
    [_linkLabel release];
    [_msgLabel release];
    
    [_line release];
    
    [super dealloc];
}

#pragma public method

- (void)loadView
{
    JBoAsyncImageView *bgImageView = [[JBoAsyncImageView alloc] initWithFrame:CGRectMake(0, 0, _width_, _circelBgImageHeight_)];
    bgImageView.userInteractionEnabled = YES;
    bgImageView.userId = self.userDetailInfo.rosterInfo.username;
    [self addSubview:bgImageView];
    [bgImageView release];
    
    switch (self.userRelation)
    {
        case JBoUserRelationNearbySecret :
        {
            JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
            
            CGFloat width = _width_ / 2 + 10.0;
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake((_width_ - width) / 2,  bgImageView.bottom, width, _height_ - bgImageView.height - 40.0 -_statuBarHeight_ - _navgateBarHeight_)];
            label.backgroundColor = [UIColor clearColor];
            label.textColor = [UIColor grayColor];
            label.numberOfLines = 0;
            label.text = [NSString stringWithFormat:@"%@会提醒该添加好友请求来自'附近%@'", appDelegate.appName, _helpName_];
            [self addSubview:label];
            [label release];
            self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, label.frame.origin.y + label.frame.size.height);
        }
            break;
        default:
        {
            //头像
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageBecomeBig:)];
            _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_paddingLeftAndRight_, _paddingTop_ + _circelBgImageHeight_, _defaultImageSize_, _defaultImageSize_)];
            _headImageView.sex = self.userDetailInfo.rosterInfo.sex;
            _headImageView.role = self.userDetailInfo.rosterInfo.role;
             _headImageView.headImageURL = self.userDetailInfo.rosterInfo.imageURL;
            _headImageView.userInteractionEnabled = YES;
            [_headImageView addGestureRecognizer:tap];
            [tap release];
            [self addSubview:_headImageView];
           
            
            //昵称
            _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _controlInterval_, _headImageView.top + (_headImageView.height - _controlHeight_) / 2, _width_ - _headImageView.right - _paddingLeftAndRight_, _controlHeight_)];
            _nameLabel.text = self.userDetailInfo.rosterInfo.name;
            _nameLabel.backgroundColor = [UIColor clearColor];
            _nameLabel.sex = self.userDetailInfo.rosterInfo.sex;
            [self addSubview:_nameLabel];
            
            UIView *linesView = [[UIView alloc] initWithFrame:CGRectMake(0, _headImageView.frame.origin.y + _headImageView.frame.size.height + _controlInterval_, _width_, 0.3)];
            linesView.backgroundColor = [UIColor lightGrayColor];
            [self addSubview:linesView];
            [linesView release];
            
            //获取用户信息
            [self loadUserInfo];
            
            CGFloat tableHeight = 0;
            UIFont *font = _userInfoFont_;
            for(JBoUserListInfo *info in self.infoArray)
            {
                if(info.titleWidth == NSNotFound)
                {
                    CGFloat width = [JBoImageTextTool getStringSize:info.title withFont:font andContraintSize:CGSizeMake(_width_, _height_)].width + _userInfoTitle_;
                    info.titleWidth = width;
                }
                
                if(info.contentHeight == NSNotFound)
                {
                    CGSize size = [JBoImageTextTool getStringSize:info.content withFont:font andContraintSize:CGSizeMake(_width_ - info.titleWidth - _userInfoCellcontrolInterval_ * 2, _maxFloat_)];
                    info.contentHeight = size.height + 1.0;
                }
                
                tableHeight += info.contentHeight + _userInfoCellcontrolInterval_ * 2;
            }
            
            //联系人信息
            _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, linesView.bottom + _paddingTop_, _width_, tableHeight) style:UITableViewStylePlain];
            _tableView.delegate = self;
            _tableView.dataSource = self;
            _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
            _tableView.scrollEnabled = NO;
            
            [self addSubview:_tableView];
            
            _msgLabel = [[self attributeLabelWithTitle:@"TA的相册：" content:@"的超级图文" action:@selector(seeLookAndTell:)] retain];
            self.msgLabel.top = _tableView.bottom + _controlInterval_;
            
            CGFloat Y =  self.msgLabel.bottom + _controlInterval_ * 2;
            
//            if(self.userDetailInfo.rosterInfo.role == _rosterRoleEnterprise_)
//            {
                _linkLabel = [[self attributeLabelWithTitle:@"TA的云名片：" content:@"" action:@selector(seeUserLink:)] retain];
                self.linkLabel.top = Y;
                Y = self.linkLabel.bottom + _controlHeight_;
           // }
            
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, Y, _width_, 0.5)];
            lineView.backgroundColor = [UIColor lightGrayColor];
            [self addSubview:lineView];
            self.line = lineView;
            [lineView release];
            
            
            self.height = lineView.bottom;
        }
            break;
    }
}

/**获取用户信息列表
 */
- (void)loadUserInfo
{
    switch (self.userRelation)
    {
        case JBoUserRelationFriend :
        {
            self.infoArray = [self.userDetailInfo getInfoList];
        }
            break;
        case JBoUserRelationStranger :
        {
            self.userDetailInfo.phoneState = NO;
            self.infoArray = [self.userDetailInfo getPublicInfo];
        }
            break;
        case JBoUserRelationNearbySecret :
        {
            
        }
            break;
        case JBoUserRelationQRCodeCard :
        {
            self.infoArray = [self.userDetailInfo getPublicInfo];
        }
            break;
        default:
            break;
    }
}

#pragma mark-tableView 代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoUserListInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    return info.contentHeight + _userInfoCellcontrolInterval_ * 2;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellDefault";
    JBoUserInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoUserInfoCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier width:_width_] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    JBoUserListInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    cell.titleLabel.text = info.title;
    cell.titleWidth = info.titleWidth;
    cell.contentHeight = info.contentHeight;
    cell.contentLabel.text = info.content;
    
    return cell;
}

#pragma mark- private method

//
- (JBoAttributedLabel*)attributeLabelWithTitle:(NSString*) title content:(NSString*) content action:(SEL) action
{
    NSString *str = nil;
    
    switch (self.userRelation)
    {
//        case JBoUserRelationFriend :
//        {
//            if([NSString isEmpty:self.userDetailInfo.rosterInfo.remark])
//            {
//                str = [NSString stringWithFormat:@"%@%@%@", title, self.userDetailInfo.rosterInfo.name, content];
//            }
//            else
//            {
//                str = [NSString stringWithFormat:@"%@%@%@", title, self.userDetailInfo.rosterInfo.remark, content];
//            }
//        }
//            break;
        default:
        {
            str = [NSString stringWithFormat:@"%@%@%@", title, self.userDetailInfo.rosterInfo.name, content];
        }
            break;
    }
    
    UIImage *image = [UIImage imageNamed:@"arrow.png"];
    CGFloat width = _width_ - _paddingLeftAndRight_ * 2 - image.size.width - 3.0;
    
    UIColor *color = self.userDetailInfo.rosterInfo.sex == _sexBoy_ ? _sexBoyTextColor_ : _sexGirlTextColor_;
    
    NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:str];
    
    UIFont *font = [UIFont systemFontOfSize:15.0];
    CTFontRef fontRef = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
    [text addAttribute:(NSString*)kCTFontAttributeName value:(id)fontRef range:NSMakeRange(0, text.string.length)];
    [text addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)[UIColor grayColor].CGColor range:NSMakeRange(0, title.length)];
    [text addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)color.CGColor range:NSMakeRange(title.length, self.userDetailInfo.rosterInfo.name.length)];
    
    CGSize size = [JBoImageTextTool getHeightFromAttributedText:text contraintWidth:width];
    
    JBoAttributedLabel *label = [[JBoAttributedLabel alloc] initWithFrame:CGRectMake(_paddingLeftAndRight_, 0, width, size.height)];
    label.verticalAlignmentCenter = YES;
    label.backgroundColor = [UIColor clearColor];
    label.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:action];
    [label addGestureRecognizer:tap];
    [tap release];
  
    label.attributedText_5 = text;
    [self addSubview:label];
    
    [text release];
    CFRelease(fontRef);
    
    UIImageView *arrow = [[UIImageView alloc] initWithFrame:CGRectMake(size.width + 3.0, (font.lineHeight - image.size.height) / 2.0 + 2.0, image.size.width, image.size.height)];
    arrow.image = image;
    [label addSubview:arrow];
    [arrow release];
    
    return [label autorelease];
}

//靓友圈信息加载完成
- (void)lookAndTellDidLoad:(BOOL)hasInfo
{
    if(!hasInfo)
    {
        NSMutableAttributedString *text = [[NSMutableAttributedString alloc] initWithString:@"暂无超级图文"];
        
        UIFont *font = [UIFont systemFontOfSize:15.0];
        
        CTFontRef fontRef = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
        [text addAttribute:(NSString*)kCTFontAttributeName value:(id)fontRef range:NSMakeRange(0, text.string.length)];
        [text addAttribute:(NSString*)kCTForegroundColorAttributeName value:(id)[UIColor grayColor].CGColor range:NSMakeRange(0, text.string.length)];
        CFRelease(fontRef);
        
//        CGSize size = [JBoImageTextTool getHeightFromAttributedText:text contraintWidth:self.msgLabel.width];
//        CGRect frame = self.msgLabel.frame;
//        frame.size.height = size.height;
//        self.msgLabel.frame = frame;
//        
//        CGFloat Y =  self.msgLabel.bottom + _controlInterval_ * 2;
//        
//        if(self.userDetailInfo.rosterInfo.role == _rosterRoleEnterprise_)
//        {
//            self.linkLabel.top = Y;
//            Y = self.linkLabel.bottom + _controlHeight_;
//        }
//        self.line.top = Y;
        
        
        self.msgLabel.attributedText_5 = text;
        [text release];
    }
    
    for(UIView *view in self.msgLabel.subviews)
    {
        view.hidden = YES;
    }
    self.msgLabel.userInteractionEnabled = NO;
}

//查看用户的云名片信息
- (void)seeUserLink:(id) sender
{
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.needGetOpenPlatformURL = YES;
    web.black = self.black;
    web.userId = self.userDetailInfo.rosterInfo.username;
    [web showInViewController:self.navigationController animated:YES completion:nil];
    [web release];
}

//查看靓友圈信息
- (void)seeLookAndTell:(id) sender
{
    if([self.delegate respondsToSelector:@selector(userInfoTableHeaderViewNeedSeeLookAndTell:)])
    {
        [self.delegate userInfoTableHeaderViewNeedSeeLookAndTell:self];
    }
}

//查看头像大图
- (void)imageBecomeBig:(id)sender
{
    UITapGestureRecognizer *tap = (UITapGestureRecognizer*)sender;
    UIImageView *imageView = (UIImageView*)tap.view;
    UIImage *image = imageView.image;
    if(![NSString isEmpty:self.userDetailInfo.rosterInfo.imageURL])
    {
        UIImage *ret = [[JBoImageCacheTool sharedInstance] getImageWithURL:self.userDetailInfo.rosterInfo.imageURL thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeHeadImage];
        if(ret)
            image = ret;
    }
    
    if(image)
    {
        JBoImageBrowerViewController *detailImageView = [[JBoImageBrowerViewController alloc] init];
        detailImageView.srcArray = [NSArray arrayWithObject:image];
        [detailImageView createImageCell];
        [detailImageView showInViewController:self.navigationController];
        [detailImageView release];
    }
}

@end
