//
//  JBoAddressBookSectionHeader.h
//  linklnk
//
//  Created by kinghe005 on 14-11-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

//section头的高度
#define _sectionHeaderHeight_ 20

/**通讯录分组信息视图 标题为昵称首字母 ios6.0以前用到
 */
@interface JBoAddressBookSectionHeaderView : UIView

/**背景图片
 */
@property(nonatomic,readonly) UIImageView *imageView;

/**标题内容
 */
@property(nonatomic,readonly) UILabel *titleLabl;

@end

#ifdef __IPHONE_6_0

/**通讯录分组信息视图 标题为昵称首字母 ios6.0以后用到
 */
@interface JBoAddressBookSectionHeader : UITableViewHeaderFooterView

/**分组信息视图
 */
@property(nonatomic,readonly) JBoAddressBookSectionHeaderView *headerView;

@end
#endif
