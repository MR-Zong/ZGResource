//
//  JBoUserInfoCell.m
//  连客
//
//  Created by kinghe005 on 13-12-31.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserInfoCell.h"
#import "JBoImageTextTool.h"

#define _iconInterval_ 5
#define _iconSize_ 15.0

@interface JBoUserInfoCell ()

@property(nonatomic,assign) CGFloat width;

@end

@implementation JBoUserInfoCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier width:(CGFloat)width
{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if(self)
    {
        CGFloat width = self.bounds.size.width;
        self.width = width;
        
        UIFont *font = _userInfoFont_;
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, _userInfoCellcontrolInterval_, _userInfoTitleWidth_, font.lineHeight)];
        _titleLabel.font = font;
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.textColor = [UIColor grayColor];
        [_titleLabel setTextAlign:JBoTextAlignmentRight];
        
        [self addSubview:_titleLabel];
        
        _contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(_titleLabel.right + _userInfoCellcontrolInterval_, _titleLabel.frame.origin.y, width - _userInfoCellcontrolInterval_ * 2 -_userInfoTitleWidth_, font.lineHeight)];
        _contentLabel.font = _userInfoFont_;
        _contentLabel.numberOfLines = 0;
        _contentLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_contentLabel];
    }
    
    return self;
}


- (void)setTitleWidth:(NSInteger)titleWidth
{
    if(_titleWidth != titleWidth)
    {
        _titleWidth = titleWidth;
        
        CGRect frame = _titleLabel.frame;
        frame.size.width = _titleWidth;
        _titleLabel.frame = frame;
        
        frame.origin.x = _titleLabel.right + _userInfoCellcontrolInterval_;
        frame.size.width = self.width - _userInfoCellcontrolInterval_ * 2 - _titleWidth;
        _contentLabel.frame = frame;
    }
}

- (void)dealloc
{
    [_titleLabel release];
    [_contentLabel release];
    
    [super dealloc];
}


- (void)setContentHeight:(NSInteger)contentHeight
{
    _contentHeight = contentHeight;
    _contentLabel.height = _contentHeight;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
