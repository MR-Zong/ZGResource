//
//  JBoUserInfoCell.h
//  连客
//
//  Created by kinghe005 on 13-12-31.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _userInfoCellcontrolHeight_ 20
#define _userInfoCellcontrolInterval_ 6
#define _userInfoTitleWidth_ 70
#define _userInfoTitle_ 10.0

#define _userInfoFont_ [UIFont systemFontOfSize:14.0]

/**用户信息
 */
@interface JBoUserInfoCell : UITableViewCell
{
   
}

/**信息标题
 */
@property(nonatomic,readonly) UILabel *titleLabel;
/**标题宽度
 */
@property(nonatomic,assign) NSInteger titleWidth;
/**信息内容
 */
@property(nonatomic,readonly) UILabel *contentLabel;
/**内容高度
 */
@property(nonatomic,assign) NSInteger contentHeight;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier width:(CGFloat) width;

@end
