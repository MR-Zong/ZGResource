//
//  JBoRosterCell.h
//  连客
//
//  Created by kinghe005 on 13-11-23.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoCustomInsetLabel.h"
#import "JBoAddressBookSectionHeader.h"

#define _rosterCellHeight_ 60
#define _rosterCellInteval_ 10


/**好友信息列表
 */
@interface JBoRosterCell : UITableViewCell
{
    JBoCustomInsetLabel *_presenceLabel;
}

//头像和名称 性别
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;


//心情
- (void)setPresence:(NSString*) presence;

@end
