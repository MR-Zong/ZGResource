//
//  JBoRosterCell.m
//  连客
//
//  Created by kinghe005 on 13-11-23.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoRosterCell.h"
#import "JBoImageTextTool.h"
#import "JBoBasic.h"
#import "JBoAppDelegate.h"

#define _labelHeight_ 30
#define _nameLabelWidth_ 110
#define _controlHeight_ 20
#define _controlInterval_ 5

#pragma mark-JBoRosterCell

@interface JBoRosterCell ()

@end

@implementation JBoRosterCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.contentView.backgroundColor = [UIColor whiteColor];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_rosterCellInteval_, _rosterCellInteval_, _rosterCellHeight_ - _rosterCellInteval_ * 2, _rosterCellHeight_ - _rosterCellInteval_ * 2)];
        _headImageView.userInteractionEnabled = YES;
        [self.contentView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _rosterCellInteval_, (_rosterCellHeight_ - _labelHeight_) / 2, _nameLabelWidth_, _labelHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_presenceLabel release];
    
    [super dealloc];
}



//设置心情
- (void)setPresence:(NSString *)presence
{
    if([NSString isEmpty:presence])
    {
        _presenceLabel.hidden = YES;
        return;
    }
    
    _presenceLabel.hidden = NO;
    
    if(!_presenceLabel)
    {
        //心情
        _presenceLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _rosterCellInteval_, (_rosterCellHeight_ - _labelHeight_) / 2, _nameLabelWidth_, _controlHeight_)];
        _presenceLabel.insets = UIEdgeInsetsMake(0, 5, 0, 5);
        _presenceLabel.font = [UIFont fontWithName:_presenceFontName_ size:_presenceFontSize_];
        _presenceLabel.textColor = [UIColor blackColor];
        _presenceLabel.layer.cornerRadius = 5.0;
        _presenceLabel.numberOfLines = 0;
        _presenceLabel.layer.masksToBounds = YES;
        _presenceLabel.backgroundColor = _presenceBgColor_;
        [self.contentView addSubview:_presenceLabel];
    }
    //心情最大宽度
    CGFloat height = _rosterCellHeight_ - _rosterCellInteval_ * 2;
    CGFloat maxPresenceWidth = 110;
    CGSize size = [JBoImageTextTool getStringSize:presence withFont:_presenceLabel.font andContraintSize:CGSizeMake(maxPresenceWidth, height)];
    
    CGFloat labelHeight = size.height + _controlInterval_ > height ? height : size.height + _controlInterval_;
    
    //NSLog(@"--%f",(_rosterCellHeight_ - size.height - _rosterCellInteval_ * 2) / 2);
    CGRect frame = CGRectMake(_width_ - size.width - _rosterCellInteval_ * 2 - 15, _headImageView.frame.origin.y + (_headImageView.frame.size.height - labelHeight) / 2, size.width + _controlInterval_ * 2, labelHeight);
    _presenceLabel.text = presence;
    _presenceLabel.frame = frame;
    
   // NSLog(@"%@",presence);
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
