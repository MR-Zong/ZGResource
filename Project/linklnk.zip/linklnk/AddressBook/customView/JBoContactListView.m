//
//  JBoContactListView.m
//  靓咖
//
//  Created by kinghe005 on 14-9-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoContactListView.h"
#import "JBoLettersSearchBar.h"
#import "FMDatabase.h"
#import "JBoAddContactViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "ChineseToPinyin.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoRosterInfo.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoDataPersist.h"
#import "JBoRosterCell.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoAppDelegate.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoImageTextTool.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoChatMsgDBOperation.h"
#import "JBoUserDetailInfo.h"
#import <CoreText/CoreText.h>
#import "JBoAssociatedUsersView.h"

//搜索栏高度
#define _searchBarHeight_ 40


@interface JBoContactListView ()<EGORefreshTableHeaderDelegate,JBoHttpRequestDelegate,UIActionSheetDelegate>
{
    //xmppStream单例和代理queue
    JBoAppDelegate *_appDelegate;
    
    //下拉刷新
    EGORefreshTableHeaderView *_refreshView;
    
    NSMutableDictionary *_httpRequestDic;
}

@property(nonatomic,retain) NSIndexPath *currentIndexPath;
@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,assign) BOOL searching;

@property(nonatomic,retain) UIView *footerView;

@property(nonatomic,retain) ASINetworkQueue *httpQueue;


@end

@implementation JBoContactListView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
      
        //添加xmppStream代理
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        
        //更新通讯录
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updataAddressBookAction:) name:_addressBookUpdateNotification_ object:nil];
        
        //新好友
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newContactAction:) name:_newContactNotification_ object:nil];
        
        //好友信息更新
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userInfoUpdate:) name:_userInfoUpdateNotification_ object:nil];
        
        _httpRequestDic = [[NSMutableDictionary alloc] init];
        self.searching = NO;
        
        _addressBookOperation = [[JBoAddressBookOperation alloc] init];
        
        _keywordArray = [[NSMutableArray alloc] init];
        _rosterDic = [[NSMutableDictionary alloc] init];
        
        [self loadInitView];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

//获取花名册
- (void)getRosterListFromLocation
{
    [_addressBookOperation getRosterListWithKeywords:self.keywordArray rosterDic:self.rosterDic rosterAndUsernameDic:_appDelegate.rosterAndUsernameDic];
    dispatch_async(dispatch_get_main_queue(), ^(void){
        
        [self setContactCount];
        [self getRosterFromServer];
        [_tableView reloadData];
    });
}

- (void)saveRoster
{
    [[NSNotificationCenter defaultCenter] postNotificationName:_recentCallUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:JBoRecentCallUpdateTypeRosterRefresh] forKey:_recentCallUpdateType_]];
    
    dispatch_block_t block = ^(void)
    {
        [_addressBookOperation removeAllRoster];
        NSArray *keys = [NSArray arrayWithArray:self.keywordArray];
        NSDictionary *rosterDic = [NSDictionary dictionaryWithDictionary:self.rosterDic];
        
        for(NSString *key in keys)
        {
            NSArray *rosters = [rosterDic objectForKey:key];
            for(JBoRosterInfo *info in rosters)
            {
                [_addressBookOperation removeRosterWithUserId:info.username];
                [_addressBookOperation addNewContact:info];
            }
        }
    };
    
    dispatch_queue_t queue = dispatch_queue_create("saveRoster", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

- (void)addRosterWithRosterInfo:(JBoRosterInfo*) info
{
    [_addressBookOperation removeRosterWithUserId:info.username];
    [_addressBookOperation addNewContact:info];
}

- (void)getBlacklist
{
    JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getBlackListIdentifier_];
    httpRequest.startImmediately = NO;
    httpRequest.timeOut = 25.0;
    [httpRequest downloadWithURL:[JBoUserOperation getBlackListURL]];
    
    [_httpRequestDic setObject:httpRequest forKey:_getBlackListIdentifier_];
    [httpRequest addToQueue:[self queue]];
    [[self queue] go];
    [httpRequest release];
}

- (void)saveBlacklist
{
    dispatch_block_t block = ^(void)
    {
        [_addressBookOperation removeAllBlackList];
        for(NSString *userId in _appDelegate.blackListArray)
        {
            JBoRosterInfo *info = [[[JBoRosterInfo alloc] init]autorelease];
            info.username = userId;
            
            [_addressBookOperation addNewBlackList:info];
        }
    };
    
    dispatch_queue_t queue = dispatch_queue_create("saveBlacklist", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

- (void)addToBlacklistWithRosterInfo:(JBoRosterInfo*) info
{
    [_addressBookOperation removeRosterWithUserId:info.username];
    [_addressBookOperation removeOneBlackListWithUserId:info.username];
    [_addressBookOperation addNewBlackList:info];
}

- (void)reloadData
{
    [_tableView reloadData];
}

#pragma mark -通知

//收到通知 更新通讯录
- (void)updataAddressBookAction:(NSNotification*)notification
{
    NSDictionary *dic = [notification userInfo];
    
    JBoRosterInfo *rosterInfo = [dic objectForKey:_addressBookUpdateRosterInfo_];
    JBoContactMoreOperationType type = [[dic valueWithKey:_addressBookUpdateType_] integerValue];
    
    switch (type) {
        case JBoContactMoreOperationTypeRemark :
        {
            [_addressBookOperation modifyRemark:rosterInfo.remark withId:rosterInfo.sqlId];
        }
            break;
        case JBoContactMoreOperationTypeAddBlacklist :
        {
            [self addToBlacklistWithRosterInfo:rosterInfo];
            
            [_appDelegate.blackListArray addObject:rosterInfo.username];
            [_appDelegate.rosterAndUsernameDic removeObjectForKey:rosterInfo.username];
            NSMutableArray *array = [_rosterDic objectForKey:rosterInfo.key];
            [array removeObject:rosterInfo];
            if(array.count == 0)
            {
                [_keywordArray removeObject:rosterInfo.key];
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:_recentCallUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:rosterInfo.username, _recentCallOperationUserId_, [NSNumber numberWithInteger:JBoRecentCallUpdateTypeBlackList], _recentCallUpdateType_, nil]];
            
            [_addressBookOperation removeRosterWithUserId:rosterInfo.username];
            [self deleteChatHistoryWithUserId:rosterInfo.username];
        }
            break;
        case JBoContactMoreOperationTypeRemoveBlacklist :
        {
            [_appDelegate.blackListArray removeObject:rosterInfo.username];
            [_addressBookOperation removeOneBlackListWithUserId:rosterInfo.username];
            
            BOOL isFriend = [[dic objectForKey:_addressBookUpdateIsFriend_] boolValue];
            
            if(isFriend)
            {
                [self newFriend:rosterInfo];
            }
        }
            break;
        case JBoContactMoreOperationTypeDelete :
        {
            [_addressBookOperation removeRosterWithUserId:rosterInfo.username];
            [_appDelegate.rosterAndUsernameDic removeObjectForKey:rosterInfo.username];
            NSMutableArray *array = [_rosterDic objectForKey:rosterInfo.key];
            [array removeObject:rosterInfo];
            if(array.count == 0)
            {
                [_keywordArray removeObject:rosterInfo.key];
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:_recentCallUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:rosterInfo.username, _recentCallOperationUserId_, [NSNumber numberWithInteger:JBoRecentCallUpdateTypeRemoveContact], _recentCallUpdateType_, nil]];
            
            [self deleteChatHistoryWithUserId:rosterInfo.username];
        }
            break;
        case JBoContactMoreOperationTypeLeaveMsg :
        {
            //            dispatch_async(dispatch_get_main_queue(), ^(void){
            //
            //                if(!self.isReadingLeaveMsg)
            //                {
            //                    [self setBadgeViewHidden:NO];
            //                }
            //            });
        }
            break;
        default:
            break;
    }
    
    [_tableView reloadData];
    [self setContactCount];
}



- (void)deleteChatHistoryWithUserId:(NSString*) username
{
    NSString *userId = [[NSUserDefaults standardUserDefaults] objectForKey:_loginUsername_];
    NSString *identifier = [[NSString alloc ] initWithFormat:@"%@_%@", userId, username];
    [JBoChatMsgDBOperation deleteChatHistoryWithIdentifier:identifier];
    [identifier release];
}

//新朋友
- (void)newContactAction:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoRosterInfo *rosterInfo = [[dic allValues] objectAtIndex:0];
    
    [self newFriend:rosterInfo];
}

//有新朋友
- (void)newFriend:(JBoRosterInfo*) rosterInfo
{
    if([_appDelegate.rosterAndUsernameDic objectForKey:rosterInfo.username])
        return;
    
    char c = [ChineseToPinyin sortSectionTitle:rosterInfo.name];
    if(c > 'a' && c < 'z')
        c = c - 32;
    NSString *key = [NSString stringWithFormat:@"%c",c];
    rosterInfo.key = key;
    
    if([self.keywordArray containsObject:key])
    {
        NSMutableArray *array = [self.rosterDic objectForKey:key];
        
        for(JBoRosterInfo *info in array)
        {
            if([info.username isEqualToString:rosterInfo.username])
                return;
        }
        [array addObject:rosterInfo];
    }
    else
    {
        [self.keywordArray addObject:key];
        NSMutableArray *array = [NSMutableArray arrayWithObject:rosterInfo];
        [self.rosterDic setObject:array forKey:key];
    }
    [_appDelegate.rosterAndUsernameDic setObject:rosterInfo forKey:rosterInfo.username];
    
    
    [_tableView reloadData];
    [self setContactCount];
}

//好友信息更新
- (void)userInfoUpdate:(NSNotification*) notification
{
    JBoRosterInfo *rosterInfo = [[notification userInfo] objectForKey:_userInfoUpdateKey_];
    
    JBoRosterInfo *info = [_appDelegate.rosterAndUsernameDic objectForKey:rosterInfo.username];
    if(info)
    {
        info.role = rosterInfo.role;
        info.name = rosterInfo.name;
        info.imageURL = rosterInfo.imageURL;
    }
    [_tableView reloadData];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoContactListViewController dealloc");
    
    [_tableView release];
    [_searchBar release];
    [_lettersView release];
    
    [_searchResultArray release];
    [_transparentView release];
    
    [_rosterDic release];
    [_keywordArray release];
    [_addressBookOperation release];

    [_refreshView release];
    
    [_httpRequestDic release];
    
    [_currentIndexPath release];
    [_footerView release];
    
    [_httpQueue reset];
    [_httpQueue release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_addressBookUpdateNotification_ object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_newContactNotification_ object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_userInfoUpdateNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_getRosterIdentifier_])
    {
        _appDelegate.dataLoadingView.hidden = YES;
        if(_isLoading)
        {
            _refreshView.finishText = [NSString stringWithFormat:@"%@请重试",_alertMsgWhenBadNetwork_];
            [self tableViewDataSourceDidFinishLoading];
        }
        
        [_httpRequestDic removeObjectForKey:_getRosterIdentifier_];
        return;
    }
    
    if([identifier isEqualToString:_removeContactIdentifier_])
    {
        _appDelegate.dataLoadingView.hidden = YES;
        self.isRequesting = NO;
        [JBoUserOperation alertmsgWithBadNetwork:@"请重试"];
        [_httpRequestDic removeObjectForKey:_removeContactIdentifier_];
        return;
    }
    
    if([identifier isEqualToString:_getBlackListIdentifier_])
    {
        [_httpRequestDic removeObjectForKey:_getBlackListIdentifier_];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_getRosterIdentifier_])
    {
        NSMutableArray *keyArray = [[NSMutableArray alloc] init];
        NSMutableDictionary *rosterDic = [[NSMutableDictionary alloc] init];
        NSMutableDictionary *rosterAndUsername = [[NSMutableDictionary alloc] init];
        
        [JBoUserOperation getRosterFormData:data keywords:keyArray rosterDic:rosterDic rosterAndUsernameDic:rosterAndUsername];
        
        [_keywordArray removeAllObjects];
        [_rosterDic removeAllObjects];
        
        [_keywordArray addObjectsFromArray:keyArray];
        [_rosterDic addEntriesFromDictionary:rosterDic];
        
        _appDelegate.rosterAndUsernameDic = rosterAndUsername;
        if(_isLoading)
        {
            _refreshView.finishText = @"刷新成功";
            [self tableViewDataSourceDidFinishLoading];
        }
        else
        {
            [self reloadData];
        }
        [keyArray release];
        [rosterDic release];
        [rosterAndUsername release];
        
        [_httpRequestDic removeObjectForKey:_getRosterIdentifier_];
        [self setContactCount];
        
        [self saveRoster];
        
        return;
    }
    
    if([identifier isEqualToString:_removeContactIdentifier_])
    {
        self.isRequesting = NO;
        if([JBoUserOperation getRemoveContactFromData:data])
        {
            
            JBoRosterInfo *rosterInfo = [[[_rosterDic objectForKey:[_keywordArray objectAtIndex:self.currentIndexPath.section]] objectAtIndex:self.currentIndexPath.row] retain];
            [_addressBookOperation removeRosterWithUserId:rosterInfo.username];
            [_appDelegate.rosterAndUsernameDic removeObjectForKey:rosterInfo.username];
            
            
            NSMutableArray *array = [_rosterDic objectForKey:rosterInfo.key];
            [array removeObjectAtIndex:self.currentIndexPath.row];
            
            if(array.count == 0)
            {
                [_keywordArray removeObjectAtIndex:self.currentIndexPath.section];
                [_rosterDic removeObjectForKey:rosterInfo.key];
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:_recentCallUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:rosterInfo.username, _recentCallOperationUserId_, [NSNumber numberWithInteger:JBoRecentCallUpdateTypeRemoveContact], _recentCallUpdateType_, nil]];
            
            
            [_tableView reloadData];
            self.currentIndexPath = nil;
            
            [self deleteChatHistoryWithUserId:rosterInfo.username];
            [rosterInfo release];
        }
        
        [_httpRequestDic removeObjectForKey:_removeContactIdentifier_];
        return;
    }
    
    if([identifier isEqualToString:_getBlackListIdentifier_])
    {
        NSArray *blacklists = [JBoUserOperation getBlackListFromData:data];
        NSMutableArray *blacklistArray = [[NSMutableArray alloc] initWithCapacity:blacklists.count];
        
        for(JBoRosterInfo *info in blacklists)
        {
            if(![NSString isEmpty:info.username])
            {
                [blacklistArray addObject:info.username];
            }
        }
        _appDelegate.blackListArray = blacklistArray;
        [self saveBlacklist];
        [blacklistArray release];
        return;
    }
}

//设置 queue
- (ASINetworkQueue*)queue
{
    if(!self.httpQueue)
    {
        self.httpQueue = [ASINetworkQueue queue];
        self.httpQueue.shouldCancelAllRequestsOnFailure = NO;
        [self.httpQueue setDelegate:self];
        [self.httpQueue setQueueDidFinishSelector:@selector(httpQuqueDidFinish:)];
        [self.httpQueue setDelegate:self];
    }
    return self.httpQueue;
}

- (void)httpQuqueDidFinish:(ASINetworkQueue*) queue
{
    [self.httpQueue reset];
    self.httpQueue = nil;
}

#pragma mark-加载视图

//加载视图
- (void)loadInitView
{
    self.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    //创建tableview
    _tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorColor = [UIColor colorWithRed:160.0 / 255.0 green:160.0 / 255.0 blue:160.0 / 255.0 alpha:1.0];
    _tableView.rowHeight = _rosterCellHeight_;
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        _tableView.separatorInset = UIEdgeInsetsMake(0, _letterViewWidth_, 0, _letterViewWidth_);
    }
#endif
    [self addSubview:_tableView];
    
    UIView *footView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tabBarHeight_)];
    footView.backgroundColor = [UIColor whiteColor];
    _tableView.tableFooterView = footView;
    [footView release];
    self.footerView = footView;
    
    _refreshView = [[EGORefreshTableHeaderView alloc] initWithFrame:_tableView.frame];
    _refreshView.delegate = self;
    [self insertSubview:_refreshView belowSubview:_tableView];
    
    //创建搜索栏背
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
    if(!_ios7_0_)
    {
        _searchBar.tintColor = _searchBarColor_;
    }
    
    _searchBar.placeholder = @"搜索";
    _searchBar.delegate = self;
    _tableView.tableHeaderView = _searchBar;
    
    //创建通讯录字母搜索视图
    
    _lettersView = [[JBoLettersSearchBar alloc] initWithFrame:CGRectMake(_width_ - _letterViewWidth_, 0, _letterViewWidth_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _tabBarHeight_)];
    [_lettersView addTarget:self action:@selector(letterTouchedAction)];
    [self addSubview:_lettersView];
    
    [self setContactCount];
}

- (void)setContactCount
{
    _searchBar.placeholder = [NSString stringWithFormat:@"搜索 (共%d人)", (int)_appDelegate.rosterAndUsernameDic.count];
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    [_refreshView removeFromSuperview];
    if(!_transparentView)
    {
        _searchResultArray = [[NSMutableArray alloc] init];
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;
        
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    _lettersView.hidden = YES;
    [_searchBar setShowsCancelButton:YES animated:YES];
    [_tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    _lettersView.hidden = NO;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
    [self insertSubview:_refreshView belowSubview:_tableView];
}


//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        // NSLog(@"%@",pinyin);
        char c = [ChineseToPinyin sortSectionTitle:content];
        if(c > 'a' && c < 'z')
            c = c - 32;
        
        [_searchResultArray removeAllObjects];
        
        NSArray *array = [_rosterDic objectForKey:[NSString stringWithFormat:@"%c",c]];
        
        if(array)
        {
            
            for(JBoRosterInfo *rosterInfo in array)
            {
                if([self pinyin:pinyin match:rosterInfo.name])
                {
                    [_searchResultArray addObject:rosterInfo];
                }
            }
        }
        
        
        for(NSString *str in _keywordArray)
        {
            NSArray *infos = [_rosterDic objectForKey:str];
            
            for(JBoRosterInfo *info in infos)
            {
                if([self chinese:content match:info.name] && ![_searchResultArray containsObject:info])
                {
                    [_searchResultArray addObject:info];
                }
            }
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
        [_tableView reloadData];
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

- (BOOL)pinyin:(NSString*) pinyin match:(NSString*) str
{
    NSString *name = [ChineseToPinyin pinyinFromChiniseString:str];
    if(name.length < pinyin.length)
    {
        return NO;
    }
    
    NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
    if([pinyin isEqualToString:subStr])
    {
        return YES;
    }
    return NO;
}

- (BOOL)chinese:(NSString*) chinese match:(NSString*) str
{
    NSRange range = [str rangeOfString:chinese];
    if(range.length > 0 && range.location != NSNotFound)
    {
        return YES;
    }
    return NO;
}

#pragma mark-私有方法

//字母选择
- (void)letterTouchedAction
{
    NSString *letter = _lettersView.touchLetter;
    if([_keywordArray containsObject:letter])
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:[_keywordArray indexOfObject:letter]];
        [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

//添加联系人
- (void)addContactBarButtonItemAction
{
    JBoAddContactViewController *addContactVC = [[JBoAddContactViewController alloc] init];
    addContactVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:addContactVC animated:YES];
    [addContactVC release];
}

#pragma mark-tableview代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
    {
        return 1;
    }
    else
    {
        return _keywordArray.count;
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return _searchResultArray.count;
    }
    else
    {
        NSArray *array = [_rosterDic objectForKey:[_keywordArray objectAtIndex:section]];
        
        return array.count;
    }
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    
    JBoRosterCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoRosterCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoRosterInfo *rosterInfo = [self getInfoFromIndexPath:indexPath];
    
    cell.nameLabel.text = rosterInfo.name;
    cell.headImageView.role = rosterInfo.role;
    
    if(rosterInfo.remark.length > 0)
    {
        cell.nameLabel.text = rosterInfo.remark;
    }
    [cell setPresence:rosterInfo.presence];
    cell.nameLabel.sex = rosterInfo.sex;
    
    if(indexPath.section == 0)
    {
        cell.nameLabel.textColor = [UIColor blackColor];
    }
    
    cell.headImageView.sex = rosterInfo.sex;
    cell.headImageView.headImageURL = rosterInfo.imageURL;
    
    return cell;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching || section == 0)
        return nil;
    
    UIView *view = nil;
    NSString *title = [_keywordArray objectAtIndex:section];
    
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"headerIdentifier";
        JBoAddressBookSectionHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[JBoAddressBookSectionHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.headerView.titleLabl.text = title;
        view = header;
#endif
    }
    else
    {
        JBoAddressBookSectionHeaderView *header = [[[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)] autorelease];
        header.titleLabl.text = title;
        view = header;
    }
    
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching || section == 0)
        return 0;
    
    return _sectionHeaderHeight_;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //进入好友详细信息视图
    
    JBoRosterInfo *rosterInfo = nil;
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        NSString *keyword = [_keywordArray objectAtIndex:indexPath.section];
        rosterInfo = [[_rosterDic objectForKey:keyword] objectAtIndex:indexPath.row];
    }
    
    JBoContactDetailInfotViewController *detailInfoVC = [[JBoContactDetailInfotViewController alloc] initWithRosterInfo:rosterInfo];
    [self.navigationController pushViewController:detailInfoVC animated:YES];
    [detailInfoVC release];
    
    [_searchBar resignFirstResponder];
}

#pragma mark- UITableView edit

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.isRequesting)
        return NO;
    JBoRosterInfo *rosterInfo = [self getInfoFromIndexPath:indexPath];
    return ![rosterInfo.username isEqualToString:_linklnkUserId_];
}

- (NSString*)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.currentIndexPath = indexPath;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定要删除该好友?" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"删除" otherButtonTitles:nil, nil];
    [actionSheet showInView:self];
    [actionSheet release];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        if(self.currentIndexPath.section >= _keywordArray.count)
            return;
        
        JBoRosterInfo *rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:self.currentIndexPath.section]] objectAtIndex:self.currentIndexPath.row];
        
        JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_removeContactIdentifier_];
        httpRequest.startImmediately = NO;
        httpRequest.timeOut = 10.0;
        
        [httpRequest downloadWithURL:[JBoUserOperation getRemoveContactURL:rosterInfo.username]];
        self.isRequesting = YES;
        [_httpRequestDic setObject:httpRequest forKey:_removeContactIdentifier_];
        
        [httpRequest addToQueue:[self queue]];
        [[self queue] go];
        [httpRequest release];
    }
}

#pragma mark-加载头像

- (JBoRosterInfo*)getInfoFromIndexPath:(NSIndexPath*) indexPath
{
    JBoRosterInfo *rosterInfo = nil;
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    return rosterInfo;
}

#pragma mark- scrollView代理

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewWillBeginScroll:scrollView];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidScroll:scrollView];
    }
}


#pragma mark-下拉刷新

- (void)getRosterFromServer
{
    if([_httpRequestDic objectForKey:_getRosterIdentifier_])
        return;
    JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getRosterIdentifier_];
    httpRequest.startImmediately = NO;
    httpRequest.timeOut = 25.0;
    
    [httpRequest downloadWithURL:[JBoUserOperation getRosterURL]];
    [_httpRequestDic setObject:httpRequest forKey:_getRosterIdentifier_];
    [httpRequest addToQueue:[self queue]];
    [[self queue] go];
    
    [httpRequest release];
}

// 加载数据
- (void)reloadTableViewDataSource
{
    _isLoading = YES;
    [self getRosterFromServer];
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading
{
    _isLoading = NO;
    [_tableView reloadData];
    [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:_tableView];
}

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

@end

