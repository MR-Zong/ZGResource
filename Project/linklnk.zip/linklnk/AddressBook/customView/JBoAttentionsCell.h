//
//  JBoAttentionsCell.h
//  靓咖
//
//  Created by kinghe005 on 14-7-12.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoCustomInsetLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"

#define _attentionsCellHeight_ 60
#define _attentionsCellInteval_ 10

/**关注的人信息cell
 */
@interface JBoAttentionsCell : UITableViewCell
{
    JBoCustomInsetLabel *_presenceLabel;
}
//头像和名称 性别
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;


//心情
- (void)setPresence:(NSString*) presence;

@end
