//
//  JBoAddressBookSectionHeader.m
//  linklnk
//
//  Created by kinghe005 on 14-11-24.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAddressBookSectionHeader.h"
#import "JBoBasic.h"

@implementation JBoAddressBookSectionHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        UIImage *image = [UIImage imageNamed:@"abSection_bg.png"];
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)];
        _imageView.image = image;
        _imageView.backgroundColor = [UIColor whiteColor];
        [self addSubview:_imageView];
        
        _titleLabl = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, _width_, _sectionHeaderHeight_)];
        _titleLabl.backgroundColor = [UIColor clearColor];
        _titleLabl.font = [UIFont boldSystemFontOfSize:17.0];
        [self addSubview:_titleLabl];
    }
    return self;
}

- (void)dealloc
{
    [_imageView release];
    [_titleLabl release];
    
    [super dealloc];
}

@end

#ifdef __IPHONE_6_0
@implementation JBoAddressBookSectionHeader

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if(self)
    {
        _headerView = [[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)];
        [self.contentView addSubview:_headerView];
    }
    return self;
}


- (void)dealloc
{
    [_headerView release];
    [super dealloc];
}

@end
#endif