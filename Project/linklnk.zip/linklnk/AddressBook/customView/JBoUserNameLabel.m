//
//  JBoUserNameLabel.m
//  连你
//
//  Created by kinghe005 on 14-1-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserNameLabel.h"
#import "JBoBasic.h"
#import "JBoRosterInfo.h"
#import "JBoUserOperation.h"

@implementation JBoUserNameLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        self.verticalAlignmentCenter = YES;
    }
    return self;
}

- (void)dealloc
{
    [_info release];
    [super dealloc];
}

- (void)setSex:(NSInteger)sex
{
    _sex = sex;
    
    if(_sex == _sexGirl_)
    {
        self.textColor = _sexGirlTextColor_;
    }
    else
    {
        self.textColor = _sexBoyTextColor_;
    }
    
}

- (void)setInfo:(JBoRosterInfo *)info
{
    [_info release];
    _info = [info retain];
    
    self.sex = _info.sex;
    if(![NSString isEmpty:_info.remark])
    {
        self.text = _info.remark;
    }
    else
    {
        self.text = _info.name;
    }
}

@end
