//
//  JBoUserNameLabel.h
//  连你
//
//  Created by kinghe005 on 14-1-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoAttributedLabel.h"

@class JBoRosterInfo;

/**昵称label
 */
@interface JBoUserNameLabel : JBoAttributedLabel

/**性别
 */
@property(nonatomic,assign) NSInteger sex;

/**个人信息
 */
@property(nonatomic,retain) JBoRosterInfo *info;

@end
