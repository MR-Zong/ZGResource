//
//  JBoOfflineCacheOperation.h
//  靓咖
//
//  Created by kinghe005 on 14-6-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoAroundHelpInfo.h"
#import "JBoLookAndTellListInfo.h"

@class JBoHelpCommentInfo;
@class JBoLookAndTellCommentInfo;

/**离线缓存数据库操作
 */
@interface JBoOfflineCacheOperation : NSObject

#pragma mark- 附近匿名

/**获取附近的匿名 按时间降序排序
 *@param secretArray 空的数组 将填充JBoAroundHelpInfo对象
 *@param coordinate 当前坐标
 */
- (void)getAroundSecretWithArray:(NSMutableArray*) secretArray currentCoordinate:(CLLocationCoordinate2D) coordinate;

/**获取自己发布的匿名 按时间降序排序
 *@param secretArray 空的数组 将填充JBoAroundHelpInfo对象
 */
- (void)getMySecretWithArray:(NSMutableArray*) secretArray;;

/**删除附近匿名
 *@param ID 附近匿名的Id
 *@param isSelf 是否是我的匿名管理
 */
- (void)removeSecretWithId:(long long) ID isSelf:(BOOL) isSelf;

/**插入附近匿名
 *@param 附近匿名信息
 *@param isSelf 是否是我的匿名管理
 */
- (void)insertSecret:(JBoAroundHelpInfo*) info isSelf:(BOOL) isSelf;

/**更新附近匿名
 */
- (void)updateSecret:(JBoAroundHelpInfo*) info;

/**插入我发布的匿名
 */
- (void)insertMySecret:(JBoHelpInfo*) info;

/**删除所有附近匿名
 */
- (void)removeAllSecret;

#pragma mark- 靓友圈

/**获取靓友圈数据
 */
- (void)getBeautifulCircleInfoWithArray:(NSMutableArray*) infoArray multisInfo:(NSMutableDictionary*) multisInfo isSelf:(BOOL) isSelf;

/**出入靓友圈数据
 */
- (void)insertBeautifulCircle:(JBoLookAndTellListInfo*) info multiImageText:(JBoMultiImageText*) text images:(NSString*) images isSelf:(BOOL) isSelf;

/**删除靓友圈数据
 */
- (void)removeBeautifulCircleWithMsgId:(long long) msgId isSelf:(BOOL) isSelf;
- (void)removeBeautifulCircleWithGroupId:(NSString*) groupId;
- (void)removeBeautifulCircleWithSelf:(BOOL) isSelf;

/**更新靓友圈数据
 */
- (void)updareBeautifulCircleWithInfo:(JBoLookAndTellListInfo*) info;

#pragma mark- 靓友圈操作数

/**获取靓友圈操作数
 */
- (void)getCircleOperationWithInfo:(JBoLookAndTellListInfo*) info;

/**添加靓友圈操作数
 */
- (void)insertCircleOperationWithInfo:(JBoLookAndTellListInfo*) info;

/**更新靓友圈操作数
 */
- (void)updateCircleOperationWithInfo:(JBoLookAndTellListInfo*) info;
/**删除靓友圈操作数
 */
- (void)deleteCircleOperationWithInfo:(JBoLookAndTellListInfo*) info;

#pragma mark- 靓友圈评论

/**添加靓友圈评论
 */
- (void)insertCircleComment:(JBoLookAndTellCommentInfo*) info groupId:(NSString*) groupId;

/**获取靓友圈评论
 */
- (void)getCircleCommentWithInfo:(JBoLookAndTellListInfo*) info;

/**删除靓友圈评论
 */
- (void)removeCircleCommentWithGroupId:(NSString*) groupId;

#pragma mark- 附近匿名评论

/**通过附近匿名Id 获取它的所有评论
 */
- (NSMutableArray*)getSecretCommentWithId:(long long) Id;

/**通过附近匿名Id 插入评论
 */
- (void)insertIntoSecretCommentWithId:(long long) Id commentInfo:(JBoHelpCommentInfo*) info;

/**删除评论
 */
- (void)deleteSecretCommentWithHelpId:(long long) helpId;

/**更新评论
 */
- (void)updateCommentInfo:(JBoHelpCommentInfo*) info;

/**删除附近匿名评论
 */
- (void)removeAllComment;

@end
