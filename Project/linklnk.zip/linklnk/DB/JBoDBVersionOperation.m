//
//  JBoDBVersionOperation.m
//  linklnk
//
//  Created by kinghe005 on 14-12-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoDBVersionOperation.h"
#import "JBoUserOperation.h"

@implementation JBoDBVersionOperation

/**获取数据库版本和app版本对应
 *@param tableName 表名
 */
+ (NSString*)getSqliteVersionWithTable:(NSString*) tableName
{
    NSString *userId = [JBoUserOperation getUserId];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    

    NSDictionary *sqliteInfo = [defaults objectForKey:_sqliteVersion_];
    
    if([sqliteInfo isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *info = [sqliteInfo objectForKey:userId];
        
        if([info isKindOfClass:[NSDictionary class]])
        {
            return [info objectForKey:tableName];
        }
    }
    
    return nil;
}

/**设置数据库版本
 *@param aVersion 数据库版本
 *@param tableName 表名
 */
+ (void)setSqliteVersion:(NSString*)aVersion table:(NSString*) tableName
{
    if([NSString isEmpty:aVersion] || [NSString isEmpty:tableName])
        return;
    
    NSString *userId = [JBoUserOperation getUserId];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *sqliteInfo = [defaults objectForKey:_sqliteVersion_];
    NSMutableDictionary *sqliteInfoDic = nil;
    NSMutableDictionary *infoDic = nil;
    
    //获取版本信息
    if([sqliteInfo isKindOfClass:[NSDictionary class]])
    {
        sqliteInfoDic = [NSMutableDictionary dictionaryWithDictionary:sqliteInfo];
        NSDictionary *info = [sqliteInfo objectForKey:userId];
        
        if([info isKindOfClass:[NSDictionary class]])
        {
            infoDic = [NSMutableDictionary dictionaryWithDictionary:info];
        }
    }
    
    //版本信息空，创建
    if(sqliteInfoDic == nil)
        sqliteInfoDic = [NSMutableDictionary dictionary];
    if(infoDic == nil)
        infoDic = [NSMutableDictionary dictionary];
    
    [infoDic setObject:aVersion forKey:tableName];
    [sqliteInfoDic setObject:infoDic forKey:userId];
    
    [defaults setObject:sqliteInfoDic forKey:_sqliteVersion_];
    [defaults synchronize];
}

@end
