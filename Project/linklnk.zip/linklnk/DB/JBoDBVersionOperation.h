//
//  JBoDBVersionOperation.h
//  linklnk
//
//  Created by kinghe005 on 14-12-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**数据库版本操作
 */
@interface JBoDBVersionOperation : NSObject

/**获取数据库版本和app版本对应
 *@param tableName 表名
 */
+ (NSString*)getSqliteVersionWithTable:(NSString*) tableName;

/**设置数据库版本
 *@param aVersion 数据库版本
 *@param tableName 表名
 */
+ (void)setSqliteVersion:(NSString*)aVersion table:(NSString*) tableName;

@end
