//
//  JBoOfflineCacheOperation.m
//  靓咖
//
//  Created by kinghe005 on 14-6-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOfflineCacheOperation.h"
#import "JBoAppDelegate.h"
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#import "JBoImageCacheTool.h"
#import "JBoImageTextTool.h"
#import "JBoLookAndTellOperation.h"
#import "JBoHelpCommentDataObject.h"
#import "JBoLookAndTellCommentInfo.h"

@interface JBoOfflineCacheOperation ()
{
    JBoAppDelegate *_appDelegate;
    FMDatabaseQueue *_dbQueue;
}

@end

@implementation JBoOfflineCacheOperation

- (id)init
{
    self = [super init];
    if(self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        //创建数据库连接
        NSString *sqlitePath = [JBoImageCacheTool getSqlitePathWithSqliteName:_offlineCacheSqlite_];
        
        _dbQueue = [[FMDatabaseQueue alloc] initWithPath:sqlitePath];
        [_dbQueue inDatabase:^(FMDatabase *db){
           
            db.logsErrors = YES;
            if(![db open])
            {
                NSLog(@"不能打开数据库");
            }
            else
            {
                if(![db executeUpdate:_createSecretTable_])
                {
                    NSLog(@"创建附近匿名表失败");
                }
                
                if(![db executeUpdate:_createBeautifulCircleTable_])
                {
                    NSLog(@"创建靓友表失败");
                }
                
                if(![db executeUpdate:_createCircleOperationTable_])
                {
                    NSLog(@"创建操作表失败");
                }
                
                if(![db executeUpdate:_createCircleCommentTable_])
                {
                    NSLog(@"创建靓友圈评论表失败");
                }
                
                if(![db executeUpdate:_createSecretCommentTable_])
                {
                    NSLog(@"创建附近匿名评论表失败");
                }
            }
        }];
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_dbQueue close];
    [_dbQueue release];
    
    [super dealloc];
}

#pragma mark- 附近的匿名

//获取附近的匿名
- (void)getAroundSecretWithArray:(NSMutableArray *)secretArray currentCoordinate:(CLLocationCoordinate2D)coordinate
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        FMResultSet *rs = [db executeQuery:_getAroundSecret_];
        while ([rs next])
        {
            JBoAroundHelpInfo *info = [[JBoAroundHelpInfo alloc] init];
            
            info.helpID = [rs longLongIntForColumn:_secretColumnHelpId_];
            info.helpMsg = [rs stringForColumn:_secretColumnMsg_];
            info.helpDate = [rs stringForColumn:_secretColumnTime_];
            
            info.userID = [rs stringForColumn:_secretColumnUserId_];
            info.sex = [rs intForColumn:_secretColumnSex_];
            
            double lat = [rs doubleForColumn:_secretColumnLat_];
            double lon = [rs doubleForColumn:_secretColumnLon_];
            
            info.coordinate = CLLocationCoordinate2DMake(lat, lon);
            info.distance = [JBoImageTextTool getDistanceBetweenCoordinate:coordinate andOtherCoordinate:info.coordinate];
            info.commentCount = [rs intForColumn:_secretColumnCommentCount_];
            
            info.praise = [rs boolForColumn:_secretColumnPraise_];
            info.praiseCount = [rs longLongIntForColumn:_secretColumnPraiseCount_];
            
            NSString *images = [rs stringForColumn:_secretColumnImages_];
            info.imageURLArray = [JBoImageTextTool getImageURLsFromStr:images];
            
            [secretArray addObject:info];
            [info release];
        }
    }];
}

//获取我发布的匿名
- (void)getMySecretWithArray:(NSMutableArray *)secretArray
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        FMResultSet *rs = [db executeQuery:_getMySecret_];
        
        while ([rs next])
        {
            JBoHelpInfo *info = [[JBoHelpInfo alloc] init];
            
            info.helpID = [rs longLongIntForColumn:_secretColumnHelpId_];
            info.helpMsg = [rs stringForColumn:_secretColumnMsg_];
            info.helpDate = [rs stringForColumn:_secretColumnTime_];

            info.commentCount = [rs intForColumn:_secretColumnCommentCount_];
            
            info.praise = [rs boolForColumn:_secretColumnPraise_];
            info.praiseCount = [rs longLongIntForColumn:_secretColumnPraiseCount_];
            
            NSString *images = [rs stringForColumn:_secretColumnImages_];
            info.imageURLArray = [JBoImageTextTool getImageURLsFromStr:images];
            
            [secretArray addObject:info];
            [info release];
        }
    }];
}


//删除附近匿名
- (void)removeSecretWithId:(long long) ID isSelf:(BOOL)isSelf
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        db.logsErrors = YES;
        if(![db executeUpdate:_removeSecret_, [NSNumber numberWithLongLong:ID], [NSNumber numberWithBool:isSelf]])
        {
            NSLog(@"删除附近匿名失败");
        }
    }];
}

//插入附近匿名
- (void)insertSecret:(JBoAroundHelpInfo*) info isSelf:(BOOL)isSelf
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:_insertSecret_,
             [NSNumber numberWithLongLong:info.helpID],
             info.userID,
             info.helpDate,
             [NSNumber numberWithInteger:info.sex],
             [NSNumber numberWithDouble:info.coordinate.latitude],
             [NSNumber numberWithDouble:info.coordinate.longitude],
             info.helpMsg,
             [NSNumber numberWithInteger:info.commentCount],
             [NSNumber numberWithBool:isSelf],
             [NSNumber numberWithLongLong:info.praiseCount],
             [NSNumber numberWithBool:info.praise],
             [JBoImageTextTool imagesFromImageURLArray:info.imageURLArray]
             ])
        {
            NSLog(@"插入附近匿名失败");
        }
    }];
}

//更新附近匿名
- (void)updateSecret:(JBoAroundHelpInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:_updateSecret_, [NSNumber numberWithInteger:info.sex], [NSNumber numberWithLongLong:info.praiseCount], [NSNumber numberWithBool:info.praise], [NSNumber numberWithInteger:info.commentCount], [NSNumber numberWithLongLong:info.helpID]])
        {
            NSLog(@"更新附近匿名失败");
        }
    }];
}

//插入我发布的匿名
- (void)insertMySecret:(JBoHelpInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:_insertMySecret_,
             [NSNumber numberWithLongLong:info.helpID],
             info.helpDate,
             info.helpMsg,
             [NSNumber numberWithInteger:info.commentCount],
             [NSNumber numberWithBool:YES],
             [NSNumber numberWithLongLong:info.praiseCount],
             [NSNumber numberWithBool:info.praise],
             [JBoImageTextTool imagesFromImageURLArray:info.imageURLArray]
             ])
        {
            NSLog(@"插入我的匿名失败");
        }
    }];
}

/**删除所有附近匿名
 */
- (void)removeAllSecret
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_removeAllSecret_])
        {
            NSLog(@"删除所有附近匿名失败");
        }
    }];
}

#pragma mark- 靓友圈

//获取靓友圈数据
- (void)getBeautifulCircleInfoWithArray:(NSMutableArray *)infoArray multisInfo:(NSMutableDictionary *)multisInfo isSelf:(BOOL)isSelf
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        NSString *sql = isSelf ? _getMyCircleInfo_ : _getBeautifulCircleInfo_;
        FMResultSet *rs = [db executeQuery:sql];
        
        while ([rs next])
        {
            NSInteger count = [rs intForColumn:_lookAndTellCount_];
            NSString *groupId = [rs stringForColumn:_lookAndTellGroupId_];
            NSString *content = [rs stringForColumn:_lookAndTellContent_];
            NSString *imageURL = [rs stringForColumn:_lookAndTellImages_];
            
            NSInteger generalId = [rs intForColumn:_lookAndTellGerneralId_];
            NSInteger transmitId = [rs intForColumn:_lookAndTellTransmitId_];
            NSInteger enterpriseId = [rs intForColumn:_lookAndTellEnterpriseId_];
            int type = [rs intForColumn:_lookAndTellType_];
            
            NSInteger joinActivityId = [rs intForColumn:_lookAndTellJoinActivityId_];
            NSInteger startActivityId = [rs intForColumn:_lookAndTellStartActivityId_];
            
            
            JBoLookAndTellListInfo *info = nil;
            
            if(count <= 1 || [NSString isEmpty:groupId])
            {
                info = [[[JBoLookAndTellListInfo alloc] init] autorelease];
                
                JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
                text.content = content;
                text.msgId = [rs longLongIntForColumn:_lookAndTellID_];
                
                if([NSString isEmpty:text.content])
                {
                    text.content = @" ";
                }
                
                text.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
                info.multiInfo = [NSMutableArray arrayWithObject:text];
                [text release];
                
                [infoArray addObject:info];
            }
            else
            {
                info = [multisInfo objectForKey:groupId];
                if(info == nil)
                {
                    info = [[[JBoLookAndTellListInfo alloc] init] autorelease];
                    info.multiInfo = [NSMutableArray arrayWithCapacity:count];
                    [multisInfo setObject:info forKey:groupId];
                }
                
                JBoMultiImageText *text = [[JBoMultiImageText alloc] init];
                text.content = content;
                text.msgId = [rs longLongIntForColumn:_lookAndTellID_];
                
                text.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
                text.order = [rs intForColumn:_lookAndTellOrder_];
                
                if([NSString isEmpty:text.content])
                {
                    text.content = @" ";
                }
                
                [info.multiInfo addObject:text];
                
                [text release];
                
                if(info.multiInfo.count == count)
                {
                    NSArray *result = [info.multiInfo sortedArrayUsingComparator:^(id obj1, id obj2)
                                       {
                                           JBoMultiImageText *text1 = (JBoMultiImageText*)obj1;
                                           JBoMultiImageText *text2 = (JBoMultiImageText*)obj2;
                                           
                                           if(text1.order > text2.order)
                                           {
                                               return NSOrderedDescending;
                                           }
                                           
                                           if(text1.order > text2.order)
                                           {
                                               return NSOrderedAscending;
                                           }
                                           
                                           return NSOrderedSame;
                                       }];
                    
                    [info.multiInfo removeAllObjects];
                    [info.multiInfo addObjectsFromArray:result];
                    
                    [infoArray addObject:info];
                    [multisInfo removeObjectForKey:groupId];
                }
            }
            
            info.groupId = groupId;
            info.date = [rs stringForColumn:_lookAndTellCreateDate_];
            
            info.generalId = generalId;
            info.enterpriseId = enterpriseId;
            info.srcUserId = [rs stringForColumn:_lookAndTellSrcUserId_];
            
            info.transmitId = transmitId;
            
            info.type = type;
            info.userID = [rs stringForColumn:_rosterUserId_];
            info.userName = [rs stringForColumn:_rosterName_];
            info.role = [rs intForColumn:_rosterRole_];
            
            info.sex = [rs intForColumn:_rosterSex_];
            info.headImageURL = [rs stringForColumn:_rosterImageURL_];
            info.srcGroupId = [rs stringForColumn:_lookAndTellSourceGroupId_];
            info.stick = [rs intForColumn:_lookAndTellStick_];
            
            info.transmitCount = [rs intForColumn:_lookAndTellTransmitCount_];
            
            info.url = [rs stringForColumn:_lookAndTellURL_];
            info.urlTitle = [rs stringForColumn:_lookAndTellURLTitle_];
            
            info.joinActivityId = joinActivityId;
            info.startActivityId = startActivityId;
            
            info.needImageText = [rs boolForColumn:_lookAndTellIsUpload_];
            info.operationInfo.style = (startActivityId >= _laysReviewStateWeek_ || joinActivityId >= _laysReviewStateWeek_) ? JBoMsgOperationVStyleDefault : type;
        }
    }];
    
    //获取评论和操作数
    for(JBoLookAndTellListInfo *info in infoArray)
    {
        [self getCircleOperationWithInfo:info];
        [self getCircleCommentWithInfo:info];
    }
}

//出入靓友圈数据
- (void)insertBeautifulCircle:(JBoLookAndTellListInfo*) info multiImageText:(JBoMultiImageText *)text images:(NSString *)images isSelf:(BOOL)isSelf
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        
        if(![db executeUpdate:
         _insertBeautifulCircle_,
         [NSNumber numberWithInteger:info.allNum],
         text.content,
         [NSNumber numberWithInteger:info.transmitCount],
         info.date,
         [NSNumber numberWithInteger:info.enterpriseId],
         [NSNumber numberWithInteger:info.generalId],
         info.groupId,
         images,
         [NSNumber numberWithInteger:info.joinActivityId],
         [NSNumber numberWithLongLong:text.msgId],
         info.userName,
         [NSNumber numberWithInteger:info.sex],
         [NSNumber numberWithInteger:text.order],
         info.headImageURL,
         [NSNumber numberWithInteger:info.stick],
         info.srcGroupId,
         [NSNumber numberWithLongLong:text.srcMsgId],
         info.srcUserId,
         [NSNumber numberWithInteger:info.startActivityId],
         [NSNumber numberWithInteger:info.transmitId],
         [NSNumber numberWithInteger:info.type],
         [NSNumber numberWithInteger:info.role],
         info.url,
         info.urlTitle,
         info.userID,
         [NSNumber numberWithBool:isSelf],
        [NSNumber numberWithBool:info.needImageText]])
        {
            NSLog(@"插入一条靓友圈数据失败");
        }
    }];
}

//删除靓友圈数据
- (void)removeBeautifulCircleWithMsgId:(long long) msgId isSelf:(BOOL) isSelf
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:
         _removeBeautifulCircleByMsgId_,
         [NSNumber numberWithLongLong:msgId],
         [NSNumber numberWithBool:isSelf]])
        {
            NSLog(@"删除靓友圈数据失败");
        }
    }];
}

- (void)removeBeautifulCircleWithGroupId:(NSString *)groupId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:
            _removeBeautifulCircleByGroupId_,
            groupId])
        {
            NSLog(@"删除靓友圈数据失败");
        }
    }];
}

- (void)removeBeautifulCircleWithSelf:(BOOL) isSelf
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:
             _removeBeautifulCircleBySelf_,
             [NSNumber numberWithBool:isSelf]])
        {
            NSLog(@"删除靓友圈数据失败");
        }
    }];
}

//更新靓友圈数据
- (void)updareBeautifulCircleWithInfo:(JBoLookAndTellListInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:
            _updateBeautifulCircle_,
            [NSNumber numberWithInteger:info.transmitCount],
            info.groupId])
        {
            NSLog(@"更新靓友圈数据失败");
        }
    }];
}

#pragma mark- 靓友圈操作数

/**获取靓友圈操作数
 */
- (void)getCircleOperationWithInfo:(JBoLookAndTellListInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){

        FMResultSet *rs = [db executeQuery:_getCircleOperation_, [info getGroupId]];
        while ([rs next])
        {
            info.operationInfo.volunteerCount = [rs intForColumn:_circleOperationColumnVolunteerCount_];
            info.operationInfo.donateCount = [rs intForColumn:_circleOperationColumnDonateCount_];
            info.operationInfo.praiseCount = [rs intForColumn:_circleOperationColumnPraiseCount_];
            info.operationInfo.signInCount = [rs intForColumn:_circleOperationColumnSignInCount_];
            info.operationInfo.signUpCount = [rs intForColumn:_circleOperationColumnSignUpCount_];
            info.operationInfo.pityCount = [rs intForColumn:_circleOperationColumnPityCount_];
            info.operationInfo.witnessCount = [rs intForColumn:_circleOperationColumnWitnessCount_];
            info.operationInfo.applyCount = [rs intForColumn:_circleOperationColumnApplyCount_];
            
            info.operationInfo.good = [rs intForColumn:_circleOperationColumnPraise_];
            info.operationInfo.pity = [rs intForColumn:_circleOperationColumnPity_];
            info.operationInfo.witness = [rs intForColumn:_circleOperationColumnWitness_];
            info.operationInfo.signUp = [rs intForColumn:_circleOperationColumnSignUp_];
            info.operationInfo.signIn = [rs intForColumn:_circleOperationColumnSignIn_];
        }
       
    }];
}

/**添加靓友圈操作数
 */
- (void)insertCircleOperationWithInfo:(JBoLookAndTellListInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        if(![db executeUpdate:
        _insertCircleOperation_,
        [info getGroupId],
        [NSNumber numberWithInteger:info.operationInfo.volunteerCount],
        [NSNumber numberWithInteger:info.operationInfo.donateCount],
        [NSNumber numberWithInteger:info.operationInfo.praiseCount],
        [NSNumber numberWithInteger:info.operationInfo.signInCount],
        [NSNumber numberWithInteger:info.operationInfo.signUpCount],
        [NSNumber numberWithInteger:info.operationInfo.pityCount],
        [NSNumber numberWithInteger:info.operationInfo.witnessCount],
        [NSNumber numberWithInteger:info.operationInfo.applyCount],
        [NSNumber numberWithBool:info.operationInfo.good],
        [NSNumber numberWithBool:info.operationInfo.signUp],
        [NSNumber numberWithBool:info.operationInfo.witness],
        [NSNumber numberWithBool:info.operationInfo.signIn],
         [NSNumber numberWithBool:info.operationInfo.pity]])
        {
            NSLog(@"删除一条靓友圈操作数失败");
        }
    }];
}

/**更新靓友圈操作数
 */
- (void)updateCircleOperationWithInfo:(JBoLookAndTellListInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        if(![db executeUpdate:
             _updateCircleOperation_,
             [NSNumber numberWithInteger:info.operationInfo.volunteerCount],
             [NSNumber numberWithInteger:info.operationInfo.donateCount],
             [NSNumber numberWithInteger:info.operationInfo.praiseCount],
             [NSNumber numberWithInteger:info.operationInfo.signInCount],
             [NSNumber numberWithInteger:info.operationInfo.signUpCount],
             [NSNumber numberWithInteger:info.operationInfo.pityCount],
             [NSNumber numberWithInteger:info.operationInfo.witnessCount],
             [NSNumber numberWithInteger:info.operationInfo.applyCount],
             [NSNumber numberWithBool:info.operationInfo.good],
             [NSNumber numberWithBool:info.operationInfo.signUp],
             [NSNumber numberWithBool:info.operationInfo.witness],
             [NSNumber numberWithBool:info.operationInfo.signIn],
             [NSNumber numberWithBool:info.operationInfo.pity],
             [info getGroupId]])
        {
            NSLog(@"更新一条靓友圈操作数失败");
        }
    }];
}
/**删除靓友圈操作数
 */
- (void)deleteCircleOperationWithInfo:(JBoLookAndTellListInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        if(![db executeUpdate:_deleteCircleOperation_, [info getGroupId]])
        {
            NSLog(@"删除靓友圈操作数失败");
        }
    }];
}

#pragma mark- 靓友圈评论

/**添加靓友圈评论
 */
- (void)insertCircleComment:(JBoLookAndTellCommentInfo*) info groupId:(NSString*) groupId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        if(![db executeUpdate:
        _insertCircleComment_,
        [NSNumber numberWithLongLong:info.Id],
        info.userId,
        [NSNumber numberWithInteger:info.sex],
        info.name,
        info.comment,
        info.time,
        groupId])
        {
            NSLog(@"插入一条靓友圈评论失败");
        }
    }];
}

/**获取靓友圈评论
 */
- (void)getCircleCommentWithInfo:(JBoLookAndTellListInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        FMResultSet *rs = [db executeQuery:_getCircleComment_, [info getGroupId]];
        
        NSMutableArray *infoArray = [NSMutableArray array];
        while ([rs next])
        {
            JBoLookAndTellCommentInfo *commentInfo = [[JBoLookAndTellCommentInfo alloc] init];
            
            commentInfo.Id = [rs longLongIntForColumn:_circleCommentColumnCommentId_];
            commentInfo.name = [rs stringForColumn:_circleCommentColumnName_];
            commentInfo.userId = [rs stringForColumn:_circleCommentColumnUserId_];
            commentInfo.sex = [rs intForColumn:_circleCommentColumnSex_];
            commentInfo.comment = [rs stringForColumn:_circleCommentColumnContent_];
            commentInfo.time = [rs stringForColumn:_circleCommentColumnTime_];
            
            [infoArray addObject:commentInfo];
            [commentInfo release];
        }
        
        info.operationInfo.commentInfoArray = infoArray;
    }];
}

/**删除靓友圈评论
 */
- (void)removeCircleCommentWithGroupId:(NSString*) groupId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
       
        if(![db executeUpdate:_deleteCircleComment_, groupId])
        {
            NSLog(@"删除靓友圈评论失败");
        }
    }];
}

#pragma mark- 附近匿名评论

/**通过附近匿名Id 获取它的所有评论
 */
- (NSMutableArray*)getSecretCommentWithId:(long long) Id
{
    NSMutableArray *infoArray = [NSMutableArray array];
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        FMResultSet *rs = [db executeQuery:_getSecretComment_, [NSNumber numberWithLongLong:Id]];
        while ([rs next])
        {
            JBoHelpCommentInfo *info = [[JBoHelpCommentInfo alloc] init];
            
            info.commentID = [rs longLongIntForColumn:_secretCommentColumnCommentId_];
            info.commentMsg = [rs stringForColumn:_secretCommentColumnMsg_];
            info.commentDate = [rs stringForColumn:_secretCommentColumnTime_];
            
            info.userID = [rs stringForColumn:_secretCommentColumnUserId_];
            info.sex = [rs intForColumn:_secretCommentColumnSex_];
   
            
            [infoArray addObject:info];
            [info release];
        }
    }];
    
    return infoArray;
}

/**通过附近匿名Id 插入评论
 */
- (void)insertIntoSecretCommentWithId:(long long) Id commentInfo:(JBoHelpCommentInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:_insetSecretComment_,
             [NSNumber numberWithLongLong:info.commentID],
             info.userID,
             info.commentDate,
             [NSNumber numberWithInteger:info.sex],
             info.commentMsg,
             [NSNumber numberWithLongLong:Id]
             ])
        {
            NSLog(@"插入附近匿名评论失败");
        }
//        else
//        {
//            NSLog(@"插入一条评论%lld", Id);
//        }
    }];
}


/**删除评论
 */
- (void)deleteSecretCommentWithHelpId:(long long)helpId
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_deleteSecretComment_, [NSNumber numberWithLongLong:helpId]])
        {
            NSLog(@"删除附近匿名评论失败");
        }
    }];
}

/**更新评论
 */
- (void)updateCommentInfo:(JBoHelpCommentInfo*) info
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        db.logsErrors = YES;
        if(![db executeUpdate:_updateSecretComment_, [NSNumber numberWithInteger:info.sex], [NSNumber numberWithLongLong:info.commentID]])
        {
            NSLog(@"更新附近匿名评论失败");
        }
    }];
}

/**删除附近匿名评论
 */
- (void)removeAllComment
{
    [_dbQueue inDatabase:^(FMDatabase *db){
        
        db.logsErrors = YES;
        if(![db executeUpdate:_removeAllSecretComment_])
        {
            NSLog(@"删除所有附近匿名评论失败");
        }
    }];
}

@end
