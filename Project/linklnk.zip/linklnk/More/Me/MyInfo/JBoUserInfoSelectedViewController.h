//
//  JBoUserInfoSelectedViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-9.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

#define _userDetailInfoDidSelectedNofitication_ @"userDetailInfoDidSelectedNofitication"

@class JBoUserDetailInfo;

@interface JBoUserInfoSelectedViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_srcArray;
}

@property(nonatomic,assign) JBoUserInfoType userInfoType;
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

@end
