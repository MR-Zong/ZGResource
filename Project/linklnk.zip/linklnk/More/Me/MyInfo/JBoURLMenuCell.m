//
//  JBoURLMenuCell.m
//  连你
//
//  Created by kinghe005 on 14-3-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoURLMenuCell.h"
#import "JBoBasic.h"

@interface JBoURLMenuCell ()



@end

@implementation JBoURLMenuCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        imageView.frame = CGRectMake(self.bounds.size.width - 15.0 - image.size.width, (_urlMenuCellHeight_ - image.size.height) / 2, image.size.width, image.size.height);
        [self.contentView addSubview:imageView];
        [imageView release];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, imageView.frame.origin.x, _urlMenuCellHeight_)];
        _titleLabel.font = [UIFont fontWithName:_userNameFontName_ size:17.0];
        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
    }
    return self;
}

- (void)dealloc
{
    [_titleLabel release];
    
    [super dealloc];
}

@end
