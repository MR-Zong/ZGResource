//
//  JBoUserInfoModifyViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-9.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoUserDetailInfo,SSTextView,JBoUserInfoModifyViewController;


@protocol JBoUserInfoModifyViewControllerDelegate <NSObject>

/**修改完成
 *@param userInfo 新的信息
 */
- (void)userInfoModifyViewController:(JBoUserInfoModifyViewController*) viewController didModifyUserInfo:(NSDictionary*) userInfo;

@end

/**用户个人信息修改，修改可输入的信息
 */
@interface JBoUserInfoModifyViewController : JBoViewController<UITextViewDelegate>
{
    //单行输入框 用于昵称等修改
    UITextField *_textField;
    
    //多行输入框 用于个性签名等修改
    SSTextView *_textView;
}

/**要修改的用户信息类型
 */
@property(nonatomic,assign) JBoUserInfoType userInfoType;

/**用户详细信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

@property(nonatomic,assign) id<JBoUserInfoModifyViewControllerDelegate> delegate;

@end
