//
//  JBoDealAddrViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserDetailInfo.h"

#define _dealAddrDidFinishedModifiedNotification_ @"dealAddrDidFinishedModifiedNotification"

@class SSTextView;

@interface JBoDealAddrViewController : UIViewController<UITextViewDelegate>
{
    SSTextView *_textView;
    
    //位置
    UIButton *_currentLocationButton;
    UIButton *_otherLocationButton;
    
    UIActivityIndicatorView *_actView;
}

@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

@end
