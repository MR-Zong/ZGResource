//
//  JBoUrlMenuInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUrlMenuInfo.h"

@implementation JBoUrlMenuInfo

- (void)dealloc
{
    [_url release];
    [_title release];
    
    [_childItems release];
    [super dealloc];
}

+ (id)urlMenuInfoWithTitle:(NSString *)title url:(NSString *)url childItems:(NSArray *)childItems
{
    JBoUrlMenuInfo *info = [[JBoUrlMenuInfo alloc] init];
    info.title = title;
    info.url = url;
    info.childItems = childItems;
    return [info autorelease];
}

@end
