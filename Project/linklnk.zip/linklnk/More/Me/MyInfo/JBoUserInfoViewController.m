//
//  JBoUserInfoViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-7.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserInfoViewController.h"
#import "JBoUserDetailInfo.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageTextTool.h"
#import "JBoNavigatioinBarOperation.h"
#import "JBoUserInfoSelectedViewController.h"
#import "JBoUserInfoModifyViewController.h"
#import "JBoImageBrowerViewController.h"
#import "JBoProvinceViewController.h"
#import "JBoMapViewController.h"
#import "JBoImageTextTool.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoFileManager.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "JBoUserHeadImageView.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoQRCodeGenerateViewController.h"
#import "JBoNavigationViewController.h"
#import "JBoURLMenuTitleViewController.h"
#import "JBoImagePickerController.h"
#import "JBoLookAndTellOperation.h"
#import "JBoDatetimeTool.h"
#import "NSDictionary+customDic.h"
#import "JBoSceneConditionPicker.h"
#import "JBoMapViewController.h"
#import "JBoMySceneMathHistoryViewController.h"
#import "JBoAppointmentOperation.h"
#import "JBoAppointmentInfo.h"
#import "JBoTradeViewController.h"

#define _userInfoImage_ @"头像"
#define _userInfoName_ @"昵称"
#define _userInfoSex_ @"性别"
#define _userInfoEmail_ @"账号"

#define _userInfoQRCode_ @"二维码名片"
#define _userInfoSceneHistory_ @"我的发布"

#define _userInfoDefaultAddr_ @"默认地址"
#define _userInfoId_ @"手机号"
#define _userInfoArea_ @"地区"

#define _userInfoTrade_ @"行业"
#define _userInfoProfession_ @"职位"
#define _userInfoPresence_ @"个性签名"
#define _userInfoEnterpirseName_ @"认证名称"
#define _userInfoEnterpriseAddr_ @"认证地址"
#define _userInfoEnterpriseTelePhone_ @"认证固话"
#define _userInfoEnterpriseApply_ @"实名认证"
#define _userInfoServicePlatform_ @"设置服务平台"
#define _userInfoPersonalityService_ @"个性服务"

#define _userInfoHeight_ @"身高"
#define _userInfoWeight_ @"体重"
#define _userInfoBwh_ @"三围"
#define _userInfoBirthday_ @"出生日期"
#define _userInfoCharactor_ @"性格"
#define _userInfoEducation_ @"学历"

#define _controlHeight_ 30
#define _controlInterval_ 5

#define _titleFont_ [UIFont fontWithName:@"Avenir-Black" size:17] //字体

#define _buttonStartTag_ 1000

//获取预约次数
#define _appointmentTag_ 1

//获取实名认证状态
#define _realNameStatusTag_ 2

@interface JBoUserInfoViewController ()<JBoHttpRequestDelegate,JBoRealNameAuthenViewControllerDelegate,UIAlertViewDelegate,JBoUserInfoModifyViewControllerDelegate,UITextFieldDelegate,JBoSceneConditionPickerDelegate,JBoMapViewControllerDelegate,JBoMutiImagePickerDelegate,JBoTradeViewControllerDelegate>
{
    JBoHttpRequest *_httpRequest;
}

//当前要修改的信息类型
@property(nonatomic,assign) JBoUserInfoType currentUserInfoType;

//头像数据
@property(nonatomic,retain) UIImage *headImage;


@property(nonatomic,retain) NSArray *fileArray;

//是否正在请求中  修改的内容
@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,copy) NSDictionary *modifyInfo;

@property(nonatomic,assign) CGFloat fontHeight;

//个人信息
@property(nonatomic,retain)  JBoUserDetailInfo *userDetailInfo;

//实名认证状态
@property(nonatomic,assign) NSInteger realNameAuthenState;

//是否正在获取实名认证状态
@property(nonatomic,assign) BOOL getAuthenState;

//信息选择
@property(nonatomic,retain) JBoSceneConditionPicker *picker;

//请求队列
@property(nonatomic,retain) ASINetworkQueue *queue;

@end

@implementation JBoUserInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"我";
        
        //获取用户个人信息
        self.userDetailInfo = [JBoUserDetailInfo userDetailInfoFromUserDetaults];
        
        if(!_userDetailInfo.rosterInfo.image)
        {
            _userDetailInfo.rosterInfo.image = _userDetailInfo.rosterInfo.sex == _sexBoy_ ? self.appDelegate.boyImage : self.appDelegate.girlImage;
        }
        
        //选择区域
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(areaDidfinishedSelected:) name:_areaDidSelectedNotification_ object:nil];
        
        //信息选择
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDetailInfoDidSelected:) name:_userDetailInfoDidSelectedNofitication_ object:nil];
        
        _userInfoArray = [[NSMutableArray alloc] init];
        
        [self sortUserInfo];
        
        self.fontHeight = [JBoImageTextTool getFontSize:[UIFont systemFontOfSize:17] withString:@"我"].height;
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.realNameAuthenState = _realNameAuthNormal_;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        if(!_isRequesting)
        {
            self.appDelegate.dataLoadingView.hidden = YES;
        }
        _tableView.userInteractionEnabled = !_isRequesting;
    }
}

#pragma mark-通知

//信息选择
- (void)userDetailInfoDidSelected:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    NSDictionary *valueDic = [[dic allValues] objectAtIndex:0];
    
    NSString *value = [[valueDic allKeys] objectAtIndex:0];
    
    NSString *info = [[dic allKeys] objectAtIndex:0];
    NSString *object = value;
    
    if(self.currentUserInfoType == JBoUserInfoTypeTrade)
    {
        object = [[valueDic allValues] objectAtIndex:0];
    }
    self.modifyInfo = [NSDictionary dictionaryWithObject:object forKey:info];
    
    [self modifyUserInfo:[NSDictionary dictionaryWithObject:value forKey:info]];
}


 //选择区域
- (void)areaDidfinishedSelected:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    NSString *area = [dic objectForKey:_areaInfoKey_];
    self.modifyInfo = [NSDictionary dictionaryWithObject:area forKey:_rosterArea_];

    [self modifyUserInfo:self.modifyInfo];
}

- (void)modifyUserInfo:(NSDictionary*) userInfo
{
    _httpRequest.identifier = _modifyUserInfoIdentifier_;
    if([_httpRequest downloadWithURL:[JBoUserOperation getModifyUserInfoURL] dic:[JBoUserOperation getModifyUserInfoWithDic:userInfo]])
    {
        self.isRequesting = YES;
    }
}

#pragma mark- JBoUserInfoModifyViewController代理

- (void)userInfoModifyViewController:(JBoUserInfoModifyViewController *)viewController didModifyUserInfo:(NSDictionary *)userInfo
{
    self.modifyInfo = userInfo;
    [self modifyUserInfo:userInfo];
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_tableView release];
    [_userInfoArray release];
    [_userDetailInfo release];
    
    [_headImage release];
    [_fileArray release];
    [_modifyInfo release];
    [_httpRequest release];
    
    [_picker release];
    [_queue reset];
    [_queue release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_areaDidSelectedNotification_ object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_userDetailInfoDidSelectedNofitication_ object:nil];
    
    [super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if(!self.black)
    {
        [self.appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
    }
}

#pragma mark- httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_uploadHeadImageIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"上传头像失败"];
        [JBoFileManager deleteFiles:self.fileArray];
        return;
    }
    
    if([identifier isEqualToString:_modifyUserInfoIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"修改信息失败"];
        return;
    }
    [_tableView reloadData];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_uploadHeadImageIdentifier_])
    {
        NSString *photoPath = [JBoUserOperation getUploadUserHeadImageFromData:data];
        if(photoPath)
        {
            _userDetailInfo.rosterInfo.image = self.headImage;
            _userDetailInfo.rosterInfo.imageURL = photoPath;
            [_userDetailInfo saveUserDetailInfoToUserDefaults];
            
            [_tableView reloadData];
            [JBoFileManager deleteFiles:self.fileArray];
            
            JBoCustomTabBarController *tabBarController = (JBoCustomTabBarController*)self.appDelegate.window.rootViewController;
            if([tabBarController isKindOfClass:[JBoCustomTabBarController class]])
            {
                tabBarController.headImage = self.headImage;
            }
        }
        return;
    }
    
    if([identifier isEqualToString:_modifyUserInfoIdentifier_])
    {
        if([JBoUserOperation getModifyUserInfoFromData:data])
        {
            switch (self.currentUserInfoType)
            {
                case JBoUserInfoTypeName :
                {
                    _userDetailInfo.nameModifyTime = [JBoDatetimeTool getCurrentTime];
                    _userDetailInfo.rosterInfo.name = [self.modifyInfo objectForKey:_rosterName_];
                }
                    break;
//                case JBoUserInfoTypeSex :
//                    _userDetailInfo.rosterInfo.sex = [[self.modifyInfo objectForKey:_rosterSex_] integerValue];
//                    break;
                case JBoUserInfoTypeArea :
                    _userDetailInfo.area = [self.modifyInfo objectForKey:_rosterArea_];
                    break;
                case JBoUserInfoTypeID :
                {
                    _userDetailInfo.phoneNum = [self.modifyInfo objectForKey:_rosterPhoneNum_];
                    _userDetailInfo.phoneState = [[self.modifyInfo objectForKey:_rosterPhoneState_] boolValue];
                }
                    break;
                case JBoUserInfoTypeTrade :
                    _userDetailInfo.trade = [self.modifyInfo objectForKey:_rosterTrade_];
                    break;
                case JBoUserInfoTypeProfession :
                    _userDetailInfo.vocation = [self.modifyInfo objectForKey:_rosterVocation_];
                    break;
                case JBoUserInfoTypePresence :
                {
                    _userDetailInfo.rosterInfo.presence = [self.modifyInfo objectForKey:_rosterPresence_];
                    
                    _httpRequest.identifier = _releaseLookAndTellIdntifier_;
                    [_httpRequest downloadWithURL:[JBoLookAndTellOperation getReleaseLookAndTellURLWithOutFiles] dic:[JBoLookAndTellOperation releaseLookAndTellWithContent:_userDetailInfo.rosterInfo.presence type:_lookAndTellTypeNormal_ groupId:[JBoDatetimeTool getTimeAndRandom] order:0 count:1 url:nil needImageText:NO visible:_lookAndTellVisiblePublic_]];
                }
                    
                    break;
                case JBoUserInfoTypeEnterpriseAddr :
                    _userDetailInfo.rosterInfo.enterpriseAddr = [self.modifyInfo objectForKey:_rosterEnterpriseAddr_];
                    break;
                case JBoUserInfoTypeEnterpriseTelePhone :
                    _userDetailInfo.rosterInfo.enterpriseTelePhone = [self.modifyInfo objectForKey:_rosterEnterpriseTelephone_];
                    break;
                case JBoUserInfoTypeHeight :
                    _userDetailInfo.height = [[self.modifyInfo valueWithKey:_rosterHeight_] integerValue];
                    break;
                case JBoUserInfoTypeWeight :
                    _userDetailInfo.weight = [[self.modifyInfo valueWithKey:_rosterWeight_] integerValue];
                    break;
                case JBoUserInfoTypeBirthday :
                    _userDetailInfo.birthday = [self.modifyInfo objectForKey:_rosterBirthday_];
                    break;
                case JBoUserInfoTypeBwh :
                {
                    _userDetailInfo.bust = [self.modifyInfo objectWithKey:_rosterBust_];;
                    _userDetailInfo.waist = [[self.modifyInfo valueWithKey:_rosterWaist_] integerValue];
                    _userDetailInfo.hip = [[self.modifyInfo valueWithKey:_rosterHip_] integerValue];
    
                }
                    
                    break;
                case JBoUserInfoTypeCharator :
                    _userDetailInfo.character = [self.modifyInfo objectForKey:_rosterCharacter_];
                    break;
                case JBoUserInfoTypeEducation :
                    _userDetailInfo.education = [self.modifyInfo objectForKey:_rosterEducation_];
                    break;
                case JBoUserInfoTypeDefaultAddr :
                {
                    _userDetailInfo.defaultAddr = [self.modifyInfo objectForKey:_rosterDefaultAddr_];
                    _userDetailInfo.defalutAddrLat = [[self.modifyInfo objectForKey:_rosterDefaultLat_] doubleValue];
                    _userDetailInfo.defaultAddrLon = [[self.modifyInfo objectForKey:_rosterDefaultLon_] doubleValue];
                }
                    break;
                default:
                    break;
            }
            
            [_userDetailInfo saveUserDetailInfoToUserDefaults];
            [_tableView reloadData];
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"修改信息失败"];
        }
        return;
    }
}

#pragma mark- queue

//获取预约次数和认证状态
- (void)getUserInfo
{
    self.queue = [ASINetworkQueue queue];
    [self.queue setDelegate:self];
    [self.queue setQueueDidFinishSelector:@selector(queueDidFinish:)];
    [self.queue setRequestDidFinishSelector:@selector(requestDidFinish:)];
    
    ASIHTTPRequest *request = [JBoHttpRequest requestWithURL:[JBoAppointmentOperation getUserAppointCountWithId:_userDetailInfo.rosterInfo.username] tag:_appointmentTag_];
    [self.queue addOperation:request];
    
    if(_userDetailInfo.rosterInfo.role == _rosterRoleNormal_)
    {
        self.getAuthenState = YES;
        request = [JBoHttpRequest requestWithURL:[JBoUserOperation getRealNameAuthenStatus] tag:_realNameStatusTag_];
        [self.queue addOperation:request];
    }
    
    [self.queue go];
}

//队列请求完成
- (void)queueDidFinish:(ASINetworkQueue*) queue
{
    [_queue reset];
    self.queue = nil;
    self.getAuthenState = NO;
    [_tableView reloadData];
}

//单个请求完成
- (void)requestDidFinish:(ASIHTTPRequest*) request
{
    NSData *data = [NSData dataWithContentsOfFile:request.downloadDestinationPath];
    switch (request.tag)
    {
        case _realNameStatusTag_ :
        {
            self.getAuthenState = NO;
            self.realNameAuthenState = [JBoUserOperation getRealNameAuthenStatusFromData:data];
            [_tableView reloadData];
        }
            break;
        case _appointmentTag_ :
        {
            JBoAppointmentListInfo *info = [JBoAppointmentOperation getUserAppointCountFromData:data];
            _userDetailInfo.appointmentCount = info.appointmentCount;
            _userDetailInfo.notKeepAppointmentCount = info.notKeepAppointmentCount;
            _userDetailInfo.beLateAppointmentCount = info.beLateAppointmentCount;
            [_userDetailInfo saveUserDetailInfoToUserDefaults];
            
            [_tableView reloadData];
        }
            break;
    }
    
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
}


#pragma mark-加载视图

//把个人信息排序
- (void)sortUserInfo
{
    NSMutableArray *firstArray = [NSMutableArray arrayWithObjects:
                                [NSDictionary dictionaryWithObject:_userInfoImage_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeImage]],
                                [NSDictionary dictionaryWithObject:_userInfoName_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeName]],
                                [NSDictionary dictionaryWithObject:_userInfoSex_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeSex]],
                                [NSDictionary dictionaryWithObject:_userInfoEmail_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeEmail]], nil];
    [_userInfoArray addObject:firstArray];
    
    NSMutableArray *sixArray = [NSMutableArray arrayWithObjects:
                                  [NSDictionary dictionaryWithObject:@"预约" forKey:[NSNumber numberWithInteger:JBoUserInfoTypeAppointmentCount]],
                                  [NSDictionary dictionaryWithObject:@"迟到" forKey:[NSNumber numberWithInteger:JBoUserInfoTypeBeLateAppointmentCount]],
                                  [NSDictionary dictionaryWithObject:@"未赴约" forKey:[NSNumber numberWithInteger:JBoUserInfoTypeNotKeepAppointmentCount]], nil];
    
    
    [_userInfoArray addObject:sixArray];
    
    NSMutableArray *secondArrray = [NSMutableArray arrayWithObjects:
                                    [NSDictionary dictionaryWithObject:_userInfoQRCode_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeQRCode]],
//                                    [NSDictionary dictionaryWithObject:_userInfoServicePlatform_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeServicePlatfrom]],
                                    [NSDictionary dictionaryWithObject:_userInfoSceneHistory_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeSceneHistory]],
                                    [NSDictionary dictionaryWithObject:_userInfoDefaultAddr_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeDefaultAddr]],
                                    nil];
    
    [_userInfoArray addObject:secondArrray];
    
    NSMutableArray *thirdArray = [NSMutableArray arrayWithObjects:
                                  [NSDictionary dictionaryWithObject:_userInfoId_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeID]],
                                  [NSDictionary dictionaryWithObject:_userInfoArea_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeArea]],
                                  nil];

    [_userInfoArray addObject:thirdArray];
    
   
    
    NSMutableArray *fourthArray = [NSMutableArray arrayWithObjects:
                                   [NSDictionary dictionaryWithObject:_userInfoHeight_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeHeight]],
                                   [NSDictionary dictionaryWithObject:_userInfoWeight_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeWeight]],
                                   [NSDictionary dictionaryWithObject:_userInfoEducation_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeEducation]],
                                   [NSDictionary dictionaryWithObject:_userInfoBirthday_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeBirthday]],
                                   [NSDictionary dictionaryWithObject:_userInfoTrade_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeTrade]],
                                   [NSDictionary dictionaryWithObject:_userInfoProfession_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeProfession]],
                                   nil];
    
    if(_userDetailInfo.rosterInfo.sex != _sexBoy_)
    {
         [fourthArray insertObject:[NSDictionary dictionaryWithObject:_userInfoBwh_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeBwh]] atIndex:2];
    }
    
    [_userInfoArray addObject:fourthArray];
    
    NSMutableArray *fifthArray = [NSMutableArray arrayWithObjects:
                                  [NSDictionary dictionaryWithObject:_userInfoCharactor_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeCharator]],
                                  [NSDictionary dictionaryWithObject:_userInfoPresence_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypePresence]],
                                  nil];

    [_userInfoArray addObject:fifthArray];
    
    if(_userDetailInfo.rosterInfo.role == _rosterRoleEnterprise_ && ![NSString isEmpty:_userDetailInfo.rosterInfo.enterpriseName])
    {
        [firstArray insertObject:[NSDictionary dictionaryWithObject:_userInfoEnterpirseName_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeEnterpriseName]] atIndex:2];
        [thirdArray insertObject:[NSDictionary dictionaryWithObject:_userInfoEnterpriseTelePhone_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeEnterpriseTelePhone]] atIndex:1];
        
        [fifthArray addObject:[NSDictionary dictionaryWithObject:_userInfoEnterpriseAddr_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeEnterpriseAddr]]];
    }

    [fifthArray addObject:[NSDictionary dictionaryWithObject:_userInfoEnterpriseApply_ forKey:[NSNumber numberWithInteger:JBoUserInfoTypeEnterpriseApply]]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    [self getUserInfo];
    
    self.backItem = YES;
    
	_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorColor = [UIColor colorWithRed:240.0 / 255.0 green:240.0 / 255.0 blue:240.0 / 255.0 alpha:1.0];
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        _tableView.separatorInset = UIEdgeInsetsMake(0, 10.0, 0, 10.0);
    }
#endif
    [self.view addSubview:_tableView];
}

#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = [_userInfoArray objectAtIndex:section];
    return array.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _userInfoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = 40;
    NSArray *array = [_userInfoArray objectAtIndex:indexPath.section];
    NSDictionary *dic = [array objectAtIndex:indexPath.row];
    NSNumber *number = [[dic allKeys] objectAtIndex:0];
    
    JBoUserInfoType userInfoType = [number intValue];
    
    switch (userInfoType) {
        case JBoUserInfoTypeImage :
            height = _defaultImageSize_ + _controlInterval_ * 2;
            break;
         case JBoUserInfoTypePresence :
        {
            CGSize size = [JBoImageTextTool getStringSize:_userDetailInfo.rosterInfo.presence withFont:[UIFont systemFontOfSize:17] andContraintSize:CGSizeMake(200, _maxFloat_)];
            height = size.height + _controlInterval_ * 5;
        }
            break;
        case JBoUserInfoTypeDefaultAddr :
        {
            CGSize size = [JBoImageTextTool getStringSize:_userDetailInfo.defaultAddr withFont:[UIFont systemFontOfSize:17] andContraintSize:CGSizeMake(200, 90)];
            height = size.height + _controlInterval_ * 5;
        }
          break;
        default:
            break;
    }
    
    height = height < 40 ? 40 : height;
    
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellDefaultIndentifier = @"cellDefaultIndentifier";
    static NSString *cellImageIdentifier = @"cellimageIdentifier";
    
    NSString *cellIndentifier = nil;
    
    NSArray *array = [_userInfoArray objectAtIndex:indexPath.section];
    NSDictionary *dic = [array objectAtIndex:indexPath.row];
    NSNumber *number = [[dic allKeys] firstObject];
    
    //标题 和内容
    NSString *title = [[dic allValues] firstObject];
    
    JBoUserInfoType userInfoType = [number intValue];
    
    switch (userInfoType) {
        case JBoUserInfoTypeImage :
        case JBoUserInfoTypeSex :
            cellIndentifier = cellImageIdentifier;
            break;
        default:
            cellIndentifier = cellDefaultIndentifier;
            break;
    }
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIndentifier];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIndentifier] autorelease];
        if([cellIndentifier isEqualToString:cellImageIdentifier])
        {
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageBecomeBig:)];
            JBoUserHeadImageView *headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_width_ - _defaultImageSize_ - _controlInterval_ - 30, _controlInterval_, _defaultImageSize_, _defaultImageSize_)];
            headImageView.role = _userDetailInfo.rosterInfo.role;
            [headImageView addGestureRecognizer:tap];
            [tap release];
            [cell.contentView addSubview:headImageView];
            [headImageView release];
        }
 
        cell.textLabel.backgroundColor = [UIColor clearColor];
        cell.detailTextLabel.backgroundColor = [UIColor clearColor];
        
        UIImage *image = [UIImage imageNamed:@"arrow"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        cell.accessoryView = imageView;
        [imageView release];
    }
    
    
    cell.textLabel.text = title;
    NSString *content = nil;
    
    cell.backgroundColor = [UIColor whiteColor];
    switch (userInfoType) {
        case JBoUserInfoTypeImage :
        {
            cell.detailTextLabel.text = nil;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            JBoUserHeadImageView *headImageView = [cell.contentView.subviews objectAtIndex:0];
            headImageView.userInteractionEnabled = YES;
            headImageView.frame = CGRectMake(_width_ - _defaultImageSize_ - _controlInterval_ - 30, _controlInterval_, _defaultImageSize_, _defaultImageSize_);
            headImageView.imageView.image = _userDetailInfo.rosterInfo.image;
            cell.accessoryView.hidden = YES;
            
        }
            break;
            case JBoUserInfoTypeSex :
        {
            cell.detailTextLabel.text = nil;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            NSInteger sex = _userDetailInfo.rosterInfo.sex;
            
            JBoUserHeadImageView *imageView = [cell.contentView.subviews objectAtIndex:0];
            imageView.userInteractionEnabled = NO;
            NSString *imageName = sex == _sexGirl_ ? @"girlIconNormal@2x" : @"boyIconNormal@2x";
            UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imageName ofType:_imageType_]];
            imageView.imageView.image = image;
            imageView.role = _rosterRoleNormal_;
            imageView.frame = CGRectMake(_width_ - 30 - _controlInterval_ - 30, _controlInterval_, 30, 30);
            [image release];
            
            cell.accessoryView.hidden = YES;
        }
            break;
        case JBoUserInfoTypeName :
        {
            content = _userDetailInfo.rosterInfo.name;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypeArea :
        {
            content = _userDetailInfo.area;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypeID :
        {
            content = _userDetailInfo.phoneNum;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypeEmail :
        {
            content = [JBoUserOperation getIdFromEmail:_userDetailInfo.email];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = YES;
        }
            break;
        case JBoUserInfoTypeTrade :
        {
            content = _userDetailInfo.trade;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypeProfession :
        {
            content = _userDetailInfo.vocation;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypePresence :
        {
            content = _userDetailInfo.rosterInfo.presence;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.numberOfLines = 0;
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
            case JBoUserInfoTypeEnterpriseName :
        {
            content = _userDetailInfo.rosterInfo.enterpriseName;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = YES;
        }
            break;
            case JBoUserInfoTypeEnterpriseTelePhone :
        {
            content = _userDetailInfo.rosterInfo.enterpriseTelePhone;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
            case JBoUserInfoTypeEnterpriseAddr :
        {
            content = _userDetailInfo.rosterInfo.enterpriseAddr;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
            case JBoUserInfoTypeEnterpriseApply :
        {
            NSString *content = nil;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            
            switch (self.realNameAuthenState)
            {
                case _realNameAuthing_ :
                    content = @"审核中";
                    break;
                case _realNameAuthNotpass_ :
                    content = @"审核未通过";
                    break;
                default:
                    break;
            }
            
            switch (_userDetailInfo.rosterInfo.role)
            {
                case _rosterRolePerson_ :
                    content = @"已加V认证";
                    break;
                    case _rosterRoleEnterprise_ :
                {
                    content = @"已金牌认证";
                }
                    
                default:
                    break;
            }

            cell.detailTextLabel.text = content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypeQRCode :
        case JBoUserInfoTypeSceneHistory :
        case JBoUserInfoTypeServicePlatfrom :
        {
            cell.detailTextLabel.text = nil;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
            break;
        case JBoUserInfoTypeDefaultAddr :
        {
            content = _userDetailInfo.defaultAddr;
            cell.detailTextLabel.numberOfLines = 0;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
        }
            break;
        case JBoUserInfoTypeHeight :
        {
            content = _userDetailInfo.height !=0 ? [NSString stringWithFormat:@"%dcm", (int)_userDetailInfo.height] : nil;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = content;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            
        }
            break;
        case JBoUserInfoTypeWeight :
        {
            content = _userDetailInfo.weight !=0 ? [NSString stringWithFormat:@"%dkg", (int)_userDetailInfo.weight] : nil;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = content;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
            break;
        case JBoUserInfoTypeBirthday :
        {
            content = _userDetailInfo.birthday;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
            break;
        case JBoUserInfoTypeBwh :
        {
            if(_userDetailInfo.waist != 0)
            {
                content = [NSString stringWithFormat:@"%@  %d  %d", _userDetailInfo.bust, (int)_userDetailInfo.waist, (int)_userDetailInfo.hip];
            }
            
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
            break;
        case JBoUserInfoTypeCharator :
        {
            content = _userDetailInfo.character;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
            break;
        case JBoUserInfoTypeEducation :
        {
            content = _userDetailInfo.education;
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [content isEqual:[NSNull null]] ? nil : content;
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
            break;
        case JBoUserInfoTypeAppointmentCount :
        {
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%d次", _userDetailInfo.appointmentCount];
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryView.hidden = YES;
        }
            break;
        case JBoUserInfoTypeBeLateAppointmentCount :
        {
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%d次", _userDetailInfo.beLateAppointmentCount];
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryView.hidden = YES;
        }
            break;
        case JBoUserInfoTypeNotKeepAppointmentCount :
        {
            [cell.detailTextLabel setTextAlign:JBoTextAlignmentRight];
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%d次", _userDetailInfo.notKeepAppointmentCount];
            cell.accessoryView.hidden = NO;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.accessoryView.hidden = YES;
        }
            break;
        default:
            break;
    }
    
    [self setInfoRemindWithType:userInfoType cell:cell];
   
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.isRequesting)
        return;
    
    NSArray *array = [_userInfoArray objectAtIndex:indexPath.section];
    NSDictionary *dic = [array objectAtIndex:indexPath.row];
    NSNumber *number = [[dic allKeys] objectAtIndex:0];
    
    //标题 和内容
    NSString *title = [[dic allValues] objectAtIndex:0];
    
    self.currentUserInfoType = [number integerValue];
    
    if(self.currentUserInfoType != JBoUserInfoTypeBirthday &&
       self.currentUserInfoType != JBoUserInfoTypeBwh &&
       self.currentUserInfoType != JBoUserInfoTypeCharator &&
       self.currentUserInfoType != JBoUserInfoTypeEducation &&
       self.currentUserInfoType != JBoUserInfoTypeHeight &&
       self.currentUserInfoType != JBoUserInfoTypeWeight
       )
    {
        [self.picker dismissWithAnimated:YES completion:nil];
    }
    
    switch (self.currentUserInfoType) {
        case JBoUserInfoTypeImage :
        {
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
            [actionSheet showInView:self.view];
            [actionSheet release];
        }
            break;
        case JBoUserInfoTypeName :
        {
            NSString *time = [self.userDetailInfo canModifyName];
            if(time != nil)
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"您已实名认证，不能频繁修改昵称，你可修改昵称的具体时间为:\n%@", time] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                [alertView show];
                [alertView release];
                break;
            }
        }
        case JBoUserInfoTypeProfession :
        case JBoUserInfoTypeID :
        case JBoUserInfoTypePresence :
        case JBoUserInfoTypeEnterpriseTelePhone :
        case JBoUserInfoTypeEnterpriseAddr :
        {
            JBoUserInfoModifyViewController *modifyVC = [[JBoUserInfoModifyViewController alloc] init];
            modifyVC.userInfoType = self.currentUserInfoType;
            modifyVC.title = title;
            modifyVC.black = self.black;
            modifyVC.delegate = self;
            modifyVC.userDetailInfo = _userDetailInfo;
            [self.navigationController pushViewController:modifyVC animated:YES];
            [modifyVC release];
        }
            break;
        case JBoUserInfoTypeArea :
        {
            JBoProvinceViewController *provinceVC = [[JBoProvinceViewController alloc] init];
            provinceVC.rootViewController = self;
            provinceVC.black = self.black;
            [self.navigationController pushViewController:provinceVC animated:YES];
            [provinceVC release]; 
        }
            break;
        case JBoUserInfoTypeTrade :
        {
            JBoTradeViewController *trade = [[JBoTradeViewController alloc] init];
            trade.delegate = self;
            if(![NSString isEmpty:title])
            {
                trade.trades = [NSMutableArray arrayWithObject:title];
            }
            trade.black = self.black;
            [self.navigationController pushViewController:trade animated:YES];
            [trade release];
            
//            JBoUserInfoSelectedViewController *selectedVC = [[JBoUserInfoSelectedViewController alloc] init];
//            selectedVC.userInfoType = self.currentUserInfoType;
//            selectedVC.title = title;
//            selectedVC.black = self.black;
//            selectedVC.userDetailInfo = _userDetailInfo;
//            [self.navigationController pushViewController:selectedVC animated:YES];
//            [selectedVC release];
        }
            break;
        case JBoUserInfoTypeEnterpriseApply:
        {
            [self realNameAuth];
        }
            break;
        case JBoUserInfoTypeQRCode :
        {
            JBoQRCodeGenerateViewController *qrCodeVC = [[JBoQRCodeGenerateViewController alloc] init];
            qrCodeVC.black = self.black;
            [self.navigationController pushViewController:qrCodeVC animated:YES];
            [qrCodeVC release];
        }
            break;
        case JBoUserInfoTypeServicePlatfrom :
        {
            if(self.userDetailInfo.rosterInfo.role == _rosterRoleNormal_)
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"你未通过实名认证，无法设置服务平台" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"去认证", nil];
                [alertView show];
                [alertView release];
                break;
            }
            
            JBoURLMenuTitleViewController *menu = [[JBoURLMenuTitleViewController alloc] init];
            menu.black = self.black;
            [self.navigationController pushViewController:menu animated:YES];
            [menu release];
        }
            break;
        case JBoUserInfoTypeSceneHistory :
        {
            JBoMySceneMathHistoryViewController *history = [[JBoMySceneMathHistoryViewController alloc] init];
            history.black = self.black;
            [self.navigationController pushViewController:history animated:YES];
            [history release];
        }
            break;
        case JBoUserInfoTypeDefaultAddr :
        {
            JBoMapViewController *map = [[JBoMapViewController alloc] init];
            map.delegate = self;
            map.isSender = YES;
            map.black = self.black;
            if(![NSString isEmpty:_userDetailInfo.defaultAddr])
            {
                map.coordinate = CLLocationCoordinate2DMake(_userDetailInfo.defalutAddrLat, _userDetailInfo.defaultAddrLon);
                NSDictionary *dic = [_userDetailInfo strAddrAndPoiAddr];
                map.detailAddr = [dic objectForKey:mapStrAddrKey];
                map.poiInfo = [dic objectForKey:mapPoiAddrKey];
            }
            [self.navigationController pushViewController:map animated:YES];
            [map release];
        }
            break;
        case JBoUserInfoTypeHeight :
        case JBoUserInfoTypeWeight :
        case JBoUserInfoTypeBirthday :
        case JBoUserInfoTypeBwh :
        case JBoUserInfoTypeEducation :
        case JBoUserInfoTypeCharator :
        {
            [_tableView scrollToNearestSelectedRowAtScrollPosition:UITableViewScrollPositionTop animated:YES];
            [self showPicker];
        }
            break;
        default:
            break;
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark- JBoTradeViewController delegate

- (void)tradeViewController:(JBoTradeViewController *)viewController didSelectedTrade:(NSDictionary *)trades
{
    NSString *tradeId = [trades objectForKey:_tradeId_];
    
    self.modifyInfo = [NSDictionary dictionaryWithObject:[trades objectForKey:_tradeName_] forKey:_rosterTrade_];
    
    [self modifyUserInfo:[NSDictionary dictionaryWithObject:tradeId forKey:_rosterTrade_]];
}

#pragma mark- mapViewController代理

- (void)mapViewController:(JBoMapViewController *)mapView didLocatedWithInfo:(NSDictionary *)userInfo
{
    JBoMapInfo *info = [userInfo objectForKey:_locationInfo_];
    
    NSString *str = [_userDetailInfo strAddr:info.strAddr andPoiAddr:info.poiAddr];
    if(str == nil)
        return;
    
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:str, _rosterDefaultAddr_, [NSNumber numberWithDouble:info.coordinate.latitude], _rosterDefaultLat_, [NSNumber numberWithDouble:info.coordinate.longitude], _rosterDefaultLon_, nil];
    
    self.modifyInfo = dic;
    [self modifyUserInfo:self.modifyInfo];
}


#pragma mark-private method

- (void)setInfoRemindWithType:(JBoUserInfoType) type cell:(UITableViewCell*) cell
{
    if(!self.infoNeedInputRemind)
        return;
    
    BOOL result = NO;
    
    switch (type)
    {
        case JBoUserInfoTypeImage :
            result = [NSString isEmpty:_userDetailInfo.rosterInfo.imageURL];
            break;
        case JBoUserInfoTypeBwh :
            result = _userDetailInfo.waist == 0;
            break;
        case JBoUserInfoTypeBirthday :
            result = [NSString isEmpty:_userDetailInfo.birthday];
            break;
        case JBoUserInfoTypeCharator :
            result = [NSString isEmpty:_userDetailInfo.character];
            break;
        case JBoUserInfoTypeEducation :
            result = [NSString isEmpty:_userDetailInfo.education];
            break;
        case JBoUserInfoTypeHeight :
            result = _userDetailInfo.height == 0;
            break;
        case JBoUserInfoTypeWeight :
            result = _userDetailInfo.weight == 0;
            break;
        case JBoUserInfoTypeTrade :
            result = [NSString isEmpty:_userDetailInfo.trade];
            break;
        default:
            break;
    }
    
    if(result)
    {
        cell.backgroundColor = [UIColor colorWithRed:235.0 / 255.0 green:0 blue:0 alpha:0.5];
    }
}

- (void)showPicker
{
    JBoSceneConditionPickerStyle style = JBoSceneConditionPickerStyleBirthday;
    switch (self.currentUserInfoType)
    {
        case JBoUserInfoTypeBirthday :
            style = JBoSceneConditionPickerStyleBirthday;
            break;
        case JBoUserInfoTypeBwh :
            style = JBoSceneConditionPickerStyleBwh;
            break;
        case JBoUserInfoTypeCharator :
            style = JBoSceneConditionPickerStyleCharactor;
            break;
        case JBoUserInfoTypeEducation :
            style = JBoSceneConditionPickerStyleEducation;
            break;
        case JBoUserInfoTypeHeight :
            style = JBoSceneConditionPickerStyleHeightSingle;
            break;
        case JBoUserInfoTypeWeight :
            style = JBoSceneConditionPickerStyleWeightSingle;
            break;
        default:
            break;
    }
    
    if(!self.picker)
    {
        self.picker = [[[JBoSceneConditionPicker alloc] initWithSuperView:self.view style:style] autorelease];
        self.picker.delegate = self;
        
        [self.picker showWithAnimated:YES completion:nil];
    }
    else
    {
        [self.picker reloadDataWithStyle:style];
    }
}

#pragma mark- JBoSceneConditionPicker代理

- (void)conditionPicker:(JBoSceneConditionPicker *)picker didFinisedWithConditions:(NSDictionary *)conditions
{
    [self.picker dismissWithAnimated:YES completion:nil];
    
    NSDictionary *dic = nil;
    switch (picker.style)
    {
        case JBoSceneConditionPickerStyleWeightSingle :
        {
            dic = [NSDictionary dictionaryWithObject:[conditions objectForKey:[NSNumber numberWithInteger:picker.style]] forKey:_rosterWeight_];
        }
            break;
        case JBoSceneConditionPickerStyleHeightSingle :
        {
            dic = [NSDictionary dictionaryWithObject:[conditions objectForKey:[NSNumber numberWithInteger:picker.style]] forKey:_rosterHeight_];
        }
            break;
        default:
            dic = conditions;
            break;
    }
    if(conditions)
    {
        self.modifyInfo = dic;
        [self modifyUserInfo:dic];
    }
}

- (void)conditionPickerWillAppear:(JBoSceneConditionPicker *)picker
{
    [UIView animateWithDuration:0.25 animations:^(void){
       
        _tableView.height = _height_ - _statuBarHeight_ - _navgateBarHeight_ - self.picker.height;
    }];
}

- (void)conditionPickerWillDismiss:(JBoSceneConditionPicker *)picker
{
    [UIView animateWithDuration:0.25 animations:^(void){
       
        _tableView.height = _height_ - _statuBarHeight_ - _navgateBarHeight_;
    }];
}

- (void)conditionPickerDidDismiss:(JBoSceneConditionPicker *)picker
{
    self.picker = nil;
}

#pragma mark- alerView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        [self realNameAuth];
    }
}

- (void)realNameAuth
{
    if(self.realNameAuthenState == _realNameAuthing_)
    {
        [JBoUserOperation alertMsg:@"认证信息正在审核,请耐心等待"];
        return;
    }
    
    if(_userDetailInfo.rosterInfo.role == _rosterRoleNormal_)
    {
        JBoRealNameAuthenViewController *realName = [[JBoRealNameAuthenViewController alloc] init];
        realName.delegate = self;
        realName.black = self.black;
        [self.navigationController pushViewController:realName animated:YES];
        [realName release];
    }
}

#pragma mark-JBoRealNameAuthenViewController代理
- (void)realNameAuthenViewControllerDidFinished:(JBoRealNameAuthenViewController *)viweController
{
    self.realNameAuthenState = _realNameAuthing_;
    [_tableView reloadData];
}

- (void)realNameAuthenViewController:(JBoRealNameAuthenViewController *)viweController DidModifyName:(NSString *)name
{
    _userDetailInfo.rosterInfo.name = name;
    
    [_userDetailInfo saveUserDetailInfoToUserDefaults];
    
    [_tableView reloadData];
}

#pragma mark-enterpriseUser代理
//- (void)enterpriseUserViewControllerDidFinishedApply:(JBoEnterpriseAuthenView *)enterpriseUserVC
//{
//    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:_loginDetailUserInfo_];
//    self.userDetailInfo = [NSKeyedUnarchiver unarchiveObjectWithData:data];
//    [_userInfoArray removeAllObjects];
//    
//    [self sortUserInfo];
//    [_tableView reloadData];
//    [enterpriseUserVC dismissViewControllerAnimated:YES completion:nil];
//}

#pragma mark-图像

//查看头像大图
- (void)imageBecomeBig:(UITapGestureRecognizer*) tap
{
    UIImageView *imageView = (UIImageView*)tap.view;
    UIImage *image = imageView.image;
    if(![NSString isEmpty:self.userDetailInfo.rosterInfo.imageURL])
    {
        UIImage *ret = [[JBoImageCacheTool sharedInstance] getImageWithURL:self.userDetailInfo.rosterInfo.imageURL thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeHeadImage];
        if(ret)
            image = ret;
    }
    
    if(image)
    {
        JBoImageBrowerViewController *detailImageView = [[JBoImageBrowerViewController alloc] init];
        detailImageView.srcArray = [NSArray arrayWithObject:image];
        [detailImageView createImageCell];
        [detailImageView showInViewController:self];
        [detailImageView release];
    }
}

//actionSheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //NSLog(@"%d",buttonIndex);
    switch (self.currentUserInfoType)
    {
        case JBoUserInfoTypeImage :
        {
            if(buttonIndex == 0)
            {
                [self getCamera];
            }
            else if(buttonIndex == 1)
            {
                [self getPhotos];
            }
        }
            break;
            
        default:
            break;
    }
}


//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
   // NSLog(@"拍照");
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    //imagePicker.allowsEditing = YES;
    imagePicker.delegate = self;
    
    [self presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self.appDelegate hiddenStatusBar:YES];
         [self.navigationController setNavigationBarHidden:YES];
     }];
    [imagePicker release];
}

#pragma mark-相机

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        if(image)
        {
            UIImage *retImage = image;
            if(image.imageOrientation != UIImageOrientationUp)
            {
                UIGraphicsBeginImageContext(image.size);
                [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
                retImage = UIGraphicsGetImageFromCurrentImageContext();
                UIGraphicsEndImageContext();
            }
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [self imagePickerDismiss:picker];
                [self uploadHeadImageWithImage:retImage];
            });
            
        }
        else
        {
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [JBoUserOperation alertMsg:@"获取相片失败,请重试"];
                [self imagePickerDismiss:picker];
            });
        }
        
    };
    
    dispatch_queue_t queue = dispatch_queue_create("camera", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}
//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self imagePickerDismiss:picker];
}

- (void)imagePickerDismiss:(UIImagePickerController*) picker
{
    [self.appDelegate hiddenStatusBar:NO];
    [self.navigationController setNavigationBarHidden:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark- 相册

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.title = @"相册";
    mutilImagePicker.delegate = self;
    mutilImagePicker.mutilImagePickType = JBOMutilImagePickTypeSingle;
    mutilImagePicker.cropFrame = CGRectMake(0, (_height_ - _width_) / 2, _width_, _width_);
    mutilImagePicker.imageCount = 1;
    [mutilImagePicker showInViewController:self animated:YES completion:^(void){
        
        [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
    }];
    [mutilImagePicker release];
}

- (void)imagePicker:(UIViewController *)viewControler didCroppedImage:(UIImage *)image
{
    [viewControler dismissViewControllerAnimated:YES completion:^(void){
        
        [self uploadHeadImageWithImage:image];
    }];
}

//上传头像
- (void)uploadHeadImageWithImage:(UIImage*) image
{
    if(image != nil)
    {
        UIImage *retImage = nil;
        CGFloat imageSize = _defaultImageSize_ * 3;
        
        retImage = [JBoImageTextTool getSubImageFromImage:image withSize:CGSizeMake(_defaultImageSize_, _defaultImageSize_)];
        
        if(retImage.size.width > imageSize || retImage.size.height > imageSize)
        {
            
            retImage = [JBoImageTextTool getThumbnailFromImage:retImage withSize:CGSizeMake(imageSize, imageSize)];
            
        }
        
      //  NSLog(@"%f,%f,%f", retImage.size.width, retImage.size.height, retImage.scale);
        
        self.fileArray = [JBoFileManager writeImageInTemporaryFile:[NSArray arrayWithObject:retImage] withCompressedScale:0.9];
        if(self.fileArray.count > 0)
        {
            self.headImage = retImage;

            NSDictionary *fileDic = [NSDictionary dictionaryWithObject:[self.fileArray objectAtIndex:0] forKey:_photoFile_];
            
            [_httpRequest startDataLoading];
            _httpRequest.identifier = _uploadHeadImageIdentifier_;
             self.isRequesting = YES;
            [_httpRequest downloadWithURL:[JBoUserOperation uploadUserHeadImageURL] paraDic:[JBoUserOperation uploadUserHeadImagePara] fileDic:fileDic];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
