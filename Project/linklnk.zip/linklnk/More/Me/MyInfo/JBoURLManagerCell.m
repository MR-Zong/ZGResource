//
//  JBoURLManagerCell.m
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoURLManagerCell.h"
#import "JBoBasic.h"

#define _controlHeight_ 25

@implementation JBoURLManagerCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, _controlHeight_)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];
        
        _contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, _controlHeight_, _width_, _controlHeight_)];
        _contentLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_contentLabel];
    }
    return self;
}

- (void)dealloc
{
    [_titleLabel release];
    [_contentLabel release];
    
    [super dealloc];
}

@end
