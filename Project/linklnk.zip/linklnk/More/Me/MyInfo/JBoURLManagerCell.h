//
//  JBoURLManagerCell.h
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSlideCell.h"

#define _urlManagerCellHeight_ 50

@interface JBoURLManagerCell : JBoSlideCell

@property(nonatomic,readonly) UILabel *titleLabel;
@property(nonatomic,readonly) UILabel * contentLabel;

@end
