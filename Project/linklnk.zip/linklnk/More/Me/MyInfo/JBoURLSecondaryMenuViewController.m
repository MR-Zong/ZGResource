//
//  JBoURLSecondaryMenuViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoURLSecondaryMenuViewController.h"
#import "JBoAppDelegate.h"
#import "JBoUserOperation.h"
#import "JBoURLManagerCell.h"
#import "JBoWebViewController.h"
#import "JBoUrlMenuInfo.h"
#import "JBoHttpRequest.h"
#import "JBoURLMenuOperation.h"

#define _bottomHeight_ 105
#define _maxItems_ 5

@interface JBoURLSecondaryMenuViewController ()<UITextFieldDelegate, UITextViewDelegate,JBoSlideCellDelegate,JBoHttpRequestDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,retain) UITextField *textField;
@property(nonatomic,retain) UITextView *textView;
@property(nonatomic,assign) BOOL keyboardHidden;
@property(nonatomic,assign) CGFloat keyboardHeight;
@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoURLSecondaryMenuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _infoArray = [[NSMutableArray alloc] init];
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.navigationItem.rightBarButtonItem.enabled = !_isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    [_tableView release];
    [_infoArray release];
    [_transparentView release];
    
    [_textField release];
    [_textView release];
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self addKeyboardShowAndHideNotification];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self removeKeyboardShowAndHideNotification];
}

- (void)addKeyboardShowAndHideNotification
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppearance:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillDisAppearance:) name:UIKeyboardWillHideNotification object:nil];
    
    
    //添加键盘frame改变通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameWillChanged:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

- (void)removeKeyboardShowAndHideNotification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_addUserSubMenuItemIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"添加失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_addUserSubMenuItemIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [JBoUserOperation alertMsg:@"添加成功"];
            [self saveUrlMenuItem];
        }
        return;
    }
}

- (void)addMenuItem
{
//    _httpRequest.identifier = _addUserSubMenuItemIdentifier_;
//    if([_httpRequest downloadWithURL:[JBoURLMenuOperation addUserSubMenuItemWithMainId:self.menuId Id:_infoArray.count + 1 title:self.textField.text url:self.textView.text]])
//    {
//        self.isRequesting = YES;
//    }
}



#pragma mark-键盘
//键盘将要出现
- (void)keyboardWillAppearance:(NSNotification*)notification
{
    //  NSLog(@"键盘出现");
    self.keyboardHidden = NO;
    _transparentView.hidden = NO;
    [self bottomBgViewAnimate:notification];
}

//键盘将要消失
- (void)keyboardWillDisAppearance:(NSNotification*)notification
{
    // NSLog(@"键盘消失");
    self.keyboardHidden = YES;
    _transparentView.hidden = YES;
    [self bottomBgViewAnimate:notification];
    
}

//键盘frame 改变
- (void)keyboardFrameWillChanged:(NSNotification*)notification
{
    // NSLog(@"键盘frame 改变");
    [self bottomBgViewAnimate:notification];
}

//底部横条背景视图动画
- (void)bottomBgViewAnimate:(NSNotification*)notification
{
    //获取键盘高度
    NSDictionary *dic = [notification userInfo];
    NSValue *keyboardValue = [dic objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [keyboardValue CGRectValue];
    self.keyboardHeight = keyboardRect.size.height;
    if(self.keyboardHidden)
        self.keyboardHeight = 0;
    //NSLog(@"_keyboardHeight = %f",self.keyboardHeight);
    self.textField.superview.hidden = NO;
    //获取键盘动画时间
    NSNumber *animateDurationNumber = [dic objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    CGFloat animateDuration = [animateDurationNumber floatValue];
    //NSLog(@"ainimation dutation = %f",animateDuration);
    
    [UIView animateWithDuration:animateDuration animations:^(void)
     {
         self.textField.superview.frame = CGRectMake(0, _height_  - _bottomHeight_ - self.keyboardHeight - _statuBarHeight_ - _navgateBarHeight_, _width_, _bottomHeight_);
     }completion:^(BOOL finish)
     {
         if(self.textField.superview.frame.origin.y == _height_ - _bottomHeight_ - _statuBarHeight_ - _navgateBarHeight_)
         {
             self.textField.superview.hidden = YES;
         }
     }];
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	[JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(addMenuTitle) title:@"添加" backgroundImage:nil textColor:[UIColor whiteColor]];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self loadInitView];
}

- (void)loadInitView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = _urlManagerCellHeight_;
    [self.view addSubview:_tableView];
}

- (void)addMenuTitle
{
    if([self.textField isFirstResponder])
    {
        [self.textField resignFirstResponder];
        return;
    }
    
    if(!self.textField)
    {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeEdit:)];
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [_transparentView addGestureRecognizer:tap];
        [tap release];
        [self.view addSubview:_transparentView];
        
        UIView *bottomBgView = [[UIView alloc] initWithFrame:CGRectMake(0, _height_ - _bottomHeight_, _width_, _bottomHeight_)];
        bottomBgView.backgroundColor = _mainBackgroundColor_;
        [self.view addSubview:bottomBgView];
        [bottomBgView release];
        
        CGFloat interval = 5;
        self.textField = [[[UITextField alloc] initWithFrame:CGRectMake(interval, interval, _width_ - interval * 2, _bottomHeight_ - interval * 2)] autorelease];
        self.textField.delegate = self;
        self.textField.returnKeyType = UIReturnKeyDone;
        self.textField.borderStyle = UITextBorderStyleRoundedRect;
       // [self.textField addTarget:self action:@selector(textDidChange:) forControlEvents:UIControlEventEditingChanged];
        [bottomBgView addSubview:self.textField];
        
        self.textView = [[[UITextView alloc] initWithFrame:CGRectMake(interval, interval, _width_, self.textField.bounds.size.height * 2)] autorelease];
        self.textView.delegate = self;
        self.textView.returnKeyType = UIReturnKeyDone;
        self.textView.layer.cornerRadius = 6.0;
        self.textView.layer.masksToBounds = YES;
        [bottomBgView addSubview:self.textView];
    }
    
    [self.textField becomeFirstResponder];
}

#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    CGFloat height = _urlManagerCellHeight_ * _infoArray.count > _height_ - _statuBarHeight_ - _navgateBarHeight_ ? _height_ - _statuBarHeight_ - _navgateBarHeight_ : _urlManagerCellHeight_ * _infoArray.count;
    
    _tableView.frame = CGRectMake(0, 0, _width_, height);
    self.navigationItem.rightBarButtonItem.enabled = _infoArray.count < _maxItems_;
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoURLManagerCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoURLManagerCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.delegate = self;
    }
    
    JBoUrlMenuInfo *info = [_infoArray objectAtIndex:indexPath.row];
    cell.titleLabel.text = info.title;
    cell.contentLabel.text = info.url;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoUrlMenuInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    JBoWebViewController *webVC = [[JBoWebViewController alloc] init];
    webVC.black = NO;
    webVC.URL = [NSURL URLWithString:info.url];
    [webVC showInViewController:self animated:YES completion:nil];
    [webVC release];
}

#pragma mark-JBoSlideCellDelegate代理
- (void)slideCell:(JBoSlideCell *)cell didSelectedExpandedItem:(JBoSlideCellExpandedItem *)item
{
    
}

- (void)slideCellDidExpanded:(JBoSlideCell *)cell
{
    
}

#pragma mark-textField

- (void)closeEdit:(UITapGestureRecognizer*)tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if([NSString isEmpty:self.textField.text] || [NSString isEmpty:self.textView.text])
    {
        [JBoUserOperation alertMsg:@"输入不能为空"];
        return NO;
    }
    
    [self addMenuItem];
    
    self.textField.text = @"";
    [self closeEdit:nil];
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        if([NSString isEmpty:self.textField.text] || [NSString isEmpty:self.textView.text])
        {
            [JBoUserOperation alertMsg:@"输入不能为空"];
            return NO;
        }
        
        [self addMenuItem];
        
        self.textView.text = @"";
        [self closeEdit:nil];
        return NO;
    }
    
    return YES;
}

- (void)saveUrlMenuItem
{
    JBoUrlMenuInfo *info = [JBoUrlMenuInfo urlMenuInfoWithTitle:self.textField.text url:self.textView.text childItems:nil];
    [_infoArray addObject:info];
    [_tableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
