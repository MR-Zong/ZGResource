//
//  JBoURLMenuCell.h
//  连你
//
//  Created by kinghe005 on 14-3-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSlideCell.h"

#define _urlMenuCellHeight_ 50.0

@interface JBoURLMenuCell : JBoSlideCell

@property(nonatomic,readonly) UILabel *titleLabel;

@end
