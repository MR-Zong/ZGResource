//
//  JBoURLMenuOperation.m
//  连你
//
//  Created by kinghe005 on 14-3-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoURLMenuOperation.h"
#import "JBoBasic.h"
#import "JBoUserOperation.h"
#import "NSString+customString.h"
#import "JSONKit.h"
#import "JBoSendMsgUrlMenu.h"
#import "NSDictionary+customDic.h"

@implementation JBoURLMenuOperation

/**返回服务平台信息
 *@param userId 要返回信息的用户
 *@return get请求url
 */
+ (NSString*)getUserMenuWithUserId:(NSString*) userId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getUserMenuItems_, _rosterUserId_, userId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取服务平台信息
 *@param 返回的数据
 *@return 数组元素是 JBoSendMsgUrlMenuItem 对象
 */
+ (NSMutableArray*)getUserMenuFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSDictionary *resultDic = [dic objectForKey:_result_];
  
    NSLog(@"%@",dic);
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic objectForKey:_data_];
        
        NSMutableArray *infoArray = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoSendMsgUrlMenuItem *mainItem = [[JBoSendMsgUrlMenuItem alloc] init];
            mainItem.Id = [[dict valueWithKey:_mainMenuItemId_] longLongValue];
            mainItem.title = [dict objectWithKey:_mainMenuItemTitle_];
            mainItem.url = [dict objectWithKey:_mainMenuItemUrl_];

            
            NSArray *subArray = [dict objectForKey:_secondaryMenuItems_];
            NSMutableArray *subInfos = [[NSMutableArray alloc] initWithCapacity:subArray.count];
            
            for(NSDictionary *subDic in subArray)
            {
                JBoSendMsgUrlMenuItem *subItem = [[JBoSendMsgUrlMenuItem alloc] init];
                subItem.Id = [[subDic valueWithKey:_subMenuItemId_] longLongValue];
                subItem.title = [subDic objectWithKey:_subMenuItemTitle_];
                subItem.url = [subDic objectWithKey:_subMenuItemUrl_];
                
                [subInfos addObject:subItem];
                [subItem release];
            }
            
            mainItem.childItems = subInfos;
            [subInfos release];
            [infoArray addObject:mainItem];
            [mainItem release];
        }
        
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}

/**新增主菜单
 *@param title 菜单标题
 *@param url 菜单链接，可为空
 *@param get请求url
 */
+ (NSString*)addUserMainMenuItemWithTitle:(NSString *)title url:(NSString *)url
{
    NSString *res = nil;
    if([NSString isEmpty:url])
    {
        res = [NSString stringWithFormat:@"%@%@=%@&%@=%@", _addMainMenuItem_, _rosterUserId_, [JBoUserOperation getUserId], _mainMenuItemTitle_, [NSString encodeStr:title]];
    }
    else
    {
        res = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%@", _addMainMenuItem_, _rosterUserId_, [JBoUserOperation getUserId], _mainMenuItemTitle_, [NSString encodeStr:title], _mainMenuItemUrl_, [NSString encodeStr:url]];
    }
    
    res = [JBoUserOperation md5Url:res withUserId:YES];
    
    NSLog(@"%@",res);
    return res;
}

/**从返回的数据获取新增主菜单结果
 *@param data 返回的数据
 *@return 成功返回菜单Id，否则返回0
 */
+ (long long)addUserMainMenuItemResultFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
   
    NSLog(@"%@",dic);
    NSNumber *code = [resultDic objectForKey:_code_];
    if([code integerValue] == _codeSuccess_)
    {
        return [[dic valueWithKey:_mainMenuItemId_] longLongValue];
    }
    else
    {
        return 0;
    }
}

/**新增次级菜单
 *@param mainId 主菜单Id
 *@param title 菜单标题
 *@param url 菜单链接
 *@return get请求url
 */
+ (NSString*)addUserSubMenuItemWithMainId:(long long)mainId title:(NSString *)title url:(NSString *)url
{
    NSString *res = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%lld", _addSubMenuItem_, _subMenuItemTitle_, [NSString encodeStr:title], _subMenuItemUrl_, [NSString encodeStr:url], _mainMenuItemId_, mainId];
    res = [JBoUserOperation md5Url:res withUserId:YES];
    
    NSLog(@"%@",res);
    return res;
}

/**从返回的数据获取次级菜单结果
 *@param data 返回的数据
 *@return 成功返回菜单Id，否则返回0
 */
+ (long long)addUserSubMenuItemResultFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSDictionary *resultDic = [dic objectForKey:_result_];

    NSLog(@"%@",dic);
    NSNumber *code = [resultDic objectForKey:_code_];
    if([code integerValue] == _codeSuccess_)
    {
        return [[dic valueWithKey:_subMenuItemId_] longLongValue];
    }
    else
    {
        return 0;
    }
}

/**删除主菜单
 *@param Id 主菜单Id
 *@return get请求url
 */
+ (NSString*)removeMainMenuWithId:(long long)Id
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%lld", _removeMainMenuItem_, _rosterUserId_, [JBoUserOperation getUserId], _mainMenuItemId_, Id];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**更新主菜单
 *@param Id 要更新的菜单Id
 *@param title 菜单标题
 *@param url 菜单链接
 *@return get请求url
 */
+ (NSString*)updateMainMenuWithId:(long long)Id title:(NSString *)title url:(NSString *)url
{
    NSString *res = [NSString stringWithFormat:@"%@%@=%@&%@=%lld&%@=%@&%@=%@", _updateMainMenuItem_, _rosterUserId_, [JBoUserOperation getUserId], _mainMenuItemId_, Id, _mainMenuItemTitle_, [NSString encodeStr:title], _mainMenuItemUrl_, [NSString encodeStr:[NSString isEmpty:url] ? @" " : url]];
    
    res = [JBoUserOperation md5Url:res withUserId:YES];
    
    NSLog(@"%@",res);
    return res;
}

/**更新子菜单
 *@param Id 要更新的菜单Id
 *@param title 菜单标题
 *@param url 菜单链接
 *@return get请求url
 */
+ (NSString*)updateSubMenuWithId:(long long)Id title:(NSString *)title url:(NSString *)url
{
    NSString *res = [NSString stringWithFormat:@"%@%@=%lld&%@=%@&%@=%@", _updateSubMenuItem_, _subMenuItemId_, Id, _subMenuItemTitle_, [NSString encodeStr:title], _subMenuItemUrl_, [NSString encodeStr:url]];
    res = [JBoUserOperation md5Url:res withUserId:YES];
    
    NSLog(@"%@",res);
    return res;
}

/**删除子菜单
 *@param Id 子菜单Id
 *@return get请求url
 */
+ (NSString*)removeSubMenuWithId:(long long)Id
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%lld", _removeSubMenuItem_, _subMenuItemId_, Id];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

@end
