//
//  JBoUserInfoViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-7.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoViewController.h"

@class JBoUserDetailInfo;

/**个人信息查看及修改
 */
@interface JBoUserInfoViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UITableView *_tableView;
}

//个人信息数组
@property(nonatomic,readonly) NSMutableArray *userInfoArray;

//需要补填的个人信息提示
@property(nonatomic,assign) BOOL infoNeedInputRemind;

@end
