//
//  JBoURLManagerViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoURLMenuTitleViewController.h"
#import "JBoAppDelegate.h"
#import "JBoUserOperation.h"
#import "JBoURLSecondaryMenuViewController.h"
#import "JBoHttpRequest.h"
#import "JBoURLMenuCell.h"
#import "JBoURLMenuOperation.h"
#import "JBoPopupMenu.h"
#import "JBoSendMsgUrlMenu.h"
#import "SSTextView.h"
#import "JBoWebViewController.h"
#import "JBoUserPrivacyViewController.h"

#define _bottomHeight_ 120.0
#define _maxMainItems_ 3
#define _maxSubItems_ 5

#define _menuHeight_ 40.0

typedef enum _JBoMenuOperationType
{
    JBoMenuOperationTypeMain = 0,
    JBoMenuOperationTypeSub = 1,
    JBoMenuOperationTypeMainUpdate = 2,
    JBoMenuOperationTypeSubUpdate = 3
}JBoMenuOperationType;

@interface JBoURLMenuTitleViewController ()<UITextFieldDelegate,JBoHttpRequestDelegate,JBoSlideCellDelegate,JBoPopupMenuDelegate,JBoSendMsgUrlMenuDelegate,UITextViewDelegate,UIActionSheetDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
    
    JBoSendMsgUrlMenu *_sendMsgUrlMenu;
}

@property(nonatomic,retain) UITextField *textField;
@property(nonatomic,retain) SSTextView *textView;
@property(nonatomic,copy) NSString *currentTitle;
@property(nonatomic,copy) NSString *currentURL;

@property(nonatomic,retain) UIView *bottomBgView;

@property(nonatomic,assign) BOOL keyboardHidden;
@property(nonatomic,assign) CGFloat keyboardHeight;

@property(nonatomic,retain) JBoPopupMenu *urlSecondaryMenu;
@property(nonatomic,assign) NSInteger mainMenuCurrentIndex;
@property(nonatomic,assign) NSInteger subMenuCurrentIndex;

@property(nonatomic,assign) NSInteger selectedMainMenuIndex;

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,assign) JBoMenuOperationType operationType;

@property(nonatomic,retain) JBoSendMsgUrlMenuItem *currentMenuItem;

@end

@implementation JBoURLMenuTitleViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
 
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.mainMenuCurrentIndex = NSNotFound;
        self.subMenuCurrentIndex = NSNotFound;
        
        self.title = @"服务平台";
    }
    
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.navigationItem.rightBarButtonItem.enabled = !_isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    [_infoArray release];
    [_transparentView release];
    
    [_httpRequest release];
    
    [_textField release];
    [_textView release];
    [_bottomBgView release];
    
    [_currentTitle release];
    [_currentURL release];
    
    [_sendMsgUrlMenu release];
    [_urlSecondaryMenu release];
    [_currentMenuItem release];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self addKeyboardShowAndHideNotification];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self removeKeyboardShowAndHideNotification];
    [self closeEdit:nil];
}

- (void)addKeyboardShowAndHideNotification
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppearance:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillDisAppearance:) name:UIKeyboardWillHideNotification object:nil];
    
    //添加键盘frame改变通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameWillChanged:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

- (void)removeKeyboardShowAndHideNotification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_addUserMainMenuItemIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"添加失败"];
        return;
    }
    
    if([identifier isEqualToString:_addUserSubMenuItemIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"添加失败"];
        return;
    }
    
    if([identifier isEqualToString:_getUserMenuInfoIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"获取菜单失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeMainMenuIdentifier_] || [identifier isEqualToString:_removeSubMenuIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"删除失败"];
        return;
    }
    
    if([identifier isEqualToString:_updateSubMenuIdentifier_] || [identifier isEqualToString:_updateMainMenuIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"编辑失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_addUserMainMenuItemIdentifier_])
    {
        long long Id = [JBoURLMenuOperation addUserMainMenuItemResultFromData:data];
        if(Id != 0)
        {
            [JBoUserOperation alertMsg:@"添加成功"];
            
            self.currentMenuItem.title = self.currentTitle;
            self.currentMenuItem.url = self.currentURL;
            self.currentMenuItem.Id = Id;
            self.currentMenuItem.add = NO;
            
            [self fillUpMenuItems:YES];
            [_sendMsgUrlMenu reloadMenuItems];
            
            self.mainMenuCurrentIndex = NSNotFound;
            self.textView.text = @"";
            self.textField.text = @"";
        }
        
        return;
    }
    
    if([identifier isEqualToString:_addUserSubMenuItemIdentifier_])
    {
        long long Id = [JBoURLMenuOperation addUserSubMenuItemResultFromData:data];
        if(Id != 0)
        {
            [JBoUserOperation alertMsg:@"添加成功"];
            
            self.currentMenuItem.title = self.currentTitle;
            self.currentMenuItem.url = self.currentURL;
            self.currentMenuItem.add = NO;
            self.currentMenuItem.Id = Id;
            
//            JBoSendMsgUrlMenuItem *item = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
//            [item.childItems removeObject:self.currentMenuItem];
//            [item.childItems addObject:self.currentMenuItem];
            
            
            
            if(self.mainMenuCurrentIndex == self.selectedMainMenuIndex)
            {
               
                JBoPopupMenuItem *item = [self.urlSecondaryMenu.menuItems objectAtIndex:self.subMenuCurrentIndex];
                item.add = NO;
                item.title = self.currentMenuItem.title;
                
                if(self.urlSecondaryMenu.menuItems.count < _maxSubItems_)
                {
                    JBoPopupMenuItem *addItem = [JBoPopupMenuItem menuItemWithIcon:nil title:nil];
                    addItem.add = YES;
                    [self.urlSecondaryMenu.menuItems addObject:addItem];
                }
                
                
                
//                if(self.urlSecondaryMenu.menuItems.count > _maxSubItems_)
//                {
//                   [self.urlSecondaryMenu.menuItems removeObjectAtIndex:self.subMenuCurrentIndex];
//                }
     
                
               // NSLog(@"reloadMenuItems");
            }
            
            [self fillUpMenuItems:NO];
            [self.urlSecondaryMenu reloadMenuItems];
            
            self.textField.text = @"";
            self.textView.text = @"";
        }
        
        return;
    }
    
    if([identifier isEqualToString:_getUserMenuInfoIdentifier_])
    {
        self.infoArray = [JBoURLMenuOperation getUserMenuFromData:data];
        [self loadInitView];
        return;
    }
    
    if([identifier isEqualToString:_removeMainMenuIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [JBoUserOperation alertMsg:@"删除成功"];
            [self.infoArray removeObjectAtIndex:self.selectedMainMenuIndex];

            [self fillUpMenuItems:YES];
            [_sendMsgUrlMenu reloadMenuItems];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeSubMenuIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [JBoUserOperation alertMsg:@"删除成功"];
            JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
            [mainItem.childItems removeObjectAtIndex:self.subMenuCurrentIndex];
            [self.urlSecondaryMenu.menuItems removeObjectAtIndex:self.subMenuCurrentIndex];
  
            if(self.mainMenuCurrentIndex == self.selectedMainMenuIndex && self.urlSecondaryMenu.menuItems.count == _maxSubItems_ - 1)
            {
                JBoPopupMenuItem *addItem = [JBoPopupMenuItem menuItemWithIcon:nil title:nil];
                addItem.add = YES;
                [self.urlSecondaryMenu.menuItems addObject:addItem];
            }
            
            [self fillUpMenuItems:NO];
            [self.urlSecondaryMenu reloadMenuItems];
        }
        return;
    }
    
    if([identifier isEqualToString:_updateMainMenuIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [JBoUserOperation alertMsg:@"更新成功"];
            self.currentMenuItem.title = self.currentTitle;
            self.currentMenuItem.url = self.currentURL;
            
            [_sendMsgUrlMenu reloadMenuItems];
            
            self.mainMenuCurrentIndex = NSNotFound;
            self.textView.text = @"";
            self.textField.text = @"";
        }
        return;
    }
    
    if([identifier isEqualToString:_updateSubMenuIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [JBoUserOperation alertMsg:@"更新成功"];
            self.currentMenuItem.title = self.currentTitle;
            self.currentMenuItem.url = self.currentURL;
            
            if(self.mainMenuCurrentIndex == self.selectedMainMenuIndex)
            {
                JBoPopupMenuItem *item = [self.urlSecondaryMenu.menuItems objectAtIndex:self.subMenuCurrentIndex];
                item.title = self.currentMenuItem.title;
                
                [self.urlSecondaryMenu reloadData];
            }
            
            self.textField.text = @"";
            self.textView.text = @"";
        }
        return;
    }
}

- (void)addMainMenuItem
{
    _httpRequest.identifier = _addUserMainMenuItemIdentifier_;
    if([_httpRequest downloadWithURL:[JBoURLMenuOperation addUserMainMenuItemWithTitle:self.currentTitle url:self.currentURL]])
    {
        self.isRequesting = YES;
    }
}

- (void)updateMainMenuItem
{
    _httpRequest.identifier = _updateMainMenuIdentifier_;
    if([_httpRequest downloadWithURL:[JBoURLMenuOperation updateMainMenuWithId:self.currentMenuItem.Id title:self.currentTitle url:self.currentURL]])
    {
        self.isRequesting = YES;
    }
    
}

- (void)addSubMenuItemWithMainId:(long long) mainId
{
    _httpRequest.identifier = _addUserSubMenuItemIdentifier_;
    if([_httpRequest downloadWithURL:[JBoURLMenuOperation addUserSubMenuItemWithMainId:mainId title:self.currentTitle url:self.currentURL]])
    {
        self.isRequesting = YES;
    }
}

- (void)updateSubMenuItem
{
    _httpRequest.identifier = _updateSubMenuIdentifier_;
    if([_httpRequest downloadWithURL:[JBoURLMenuOperation updateSubMenuWithId:self.currentMenuItem.Id title:self.currentTitle url:self.currentURL]])
    {
        self.isRequesting = YES;
    }
}

#pragma mark-键盘
//键盘将要出现
- (void)keyboardWillAppearance:(NSNotification*)notification
{
    self.keyboardHidden = NO;
    _transparentView.hidden = NO;
    [self bottomBgViewAnimate:notification];
}

//键盘将要消失
- (void)keyboardWillDisAppearance:(NSNotification*)notification
{
    self.keyboardHidden = YES;
    _transparentView.hidden = YES;
    [self bottomBgViewAnimate:notification];
}

//键盘frame 改变
- (void)keyboardFrameWillChanged:(NSNotification*)notification
{
    [self bottomBgViewAnimate:notification];
}

//底部横条背景视图动画
- (void)bottomBgViewAnimate:(NSNotification*)notification
{
    //获取键盘高度
    NSDictionary *dic = [notification userInfo];
    NSValue *keyboardValue = [dic objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [keyboardValue CGRectValue];
    self.keyboardHeight = keyboardRect.size.height;
    if(self.keyboardHidden)
        self.keyboardHeight = 0;
    //NSLog(@"_keyboardHeight = %f",self.keyboardHeight);
    self.textField.superview.hidden = NO;
    //获取键盘动画时间
    NSNumber *animateDurationNumber = [dic objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    CGFloat animateDuration = [animateDurationNumber floatValue];
    //NSLog(@"ainimation dutation = %f",animateDuration);
    
    [UIView animateWithDuration:animateDuration animations:^(void)
     {
         self.textField.superview.frame = CGRectMake(0, _height_  - _bottomHeight_ - self.keyboardHeight - _statuBarHeight_ - _navgateBarHeight_, _width_, _bottomHeight_);
     }completion:^(BOOL finish)
     {
         if(self.textField.superview.frame.origin.y == _height_ - _bottomHeight_ - _navgateBarHeight_ - _statuBarHeight_)
         {
             self.textField.superview.hidden = YES;
         }
     }];
  //  NSLog(@"%@",self.textField.superview);
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.view.backgroundColor = [UIColor whiteColor];
    //返回按钮
    if(self.black)
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back) image:[UIImage imageNamed:@"newsBact.png"]];
    }
    else
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    }
    
    [self getUrlMenuInfo];
}

- (void)getUrlMenuInfo
{
    _httpRequest.identifier = _getUserMenuInfoIdentifier_;
    if([_httpRequest downloadWithURL:[JBoURLMenuOperation getUserMenuWithUserId:[JBoUserOperation getUserId]]])
    {
        self.isRequesting = YES;
    }
}

- (void)loadInitView
{
    
    //使用条款
    CGFloat fontSize = 14.0;
    CGFloat controlHeight = 25.0;
    
    NSString *ruleStr1 = @"使用服务平台表明您已阅读并同意";
    //  CGFloat ruleWidth = fontSize * ruleStr1.length + 25.0;
    UILabel *alertLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 70.0, _width_, controlHeight)];
    alertLabel.text = ruleStr1;
    alertLabel.backgroundColor = [UIColor clearColor];
    [alertLabel setTextAlign:JBoTextAlignmentCenter];
    alertLabel.font = [UIFont systemFontOfSize:fontSize];
    [self.view addSubview:alertLabel];
    [alertLabel release];
    
    NSString *ruleStr2 = [NSString stringWithFormat:@"%@软件许可及服务协议", _appDelegate.appName];
    //    UITapGestureRecognizer *serverProtocolTap = [UITapGestureRecognizer alloc] initWithTarget:self action:@selector()
    UIButton *serverProtocol = [UIButton buttonWithType:UIButtonTypeCustom];
    serverProtocol.titleLabel.font = [UIFont systemFontOfSize:fontSize];
    [serverProtocol setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [serverProtocol setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    [serverProtocol setFrame:CGRectMake(0, alertLabel.frame.origin.y + alertLabel.frame.size.height, _width_, controlHeight)];
    [serverProtocol addTarget:self action:@selector(serverProtocolAction:) forControlEvents:UIControlEventTouchUpInside];
    [serverProtocol setTitle:ruleStr2 forState:UIControlStateNormal];
    [self.view addSubview:serverProtocol];
    
    UILabel *forbidLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, serverProtocol.frame.origin.y + serverProtocol.frame.size.height, _width_, controlHeight)];
    forbidLabel.text = @"严禁发布色情暴力信息";
    forbidLabel.backgroundColor = [UIColor clearColor];
    [forbidLabel setTextAlign:JBoTextAlignmentCenter];
    forbidLabel.font = [UIFont systemFontOfSize:fontSize];
    [self.view addSubview:forbidLabel];
    [forbidLabel release];
    
    UILabel *newsLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, forbidLabel.bottom, _width_, controlHeight)];
    newsLabel.text = @"严禁上传转载时政新闻";
    newsLabel.numberOfLines = 0;
    newsLabel.backgroundColor = [UIColor clearColor];
    
    [newsLabel setTextAlign:JBoTextAlignmentCenter];
    newsLabel.font = [UIFont systemFontOfSize:fontSize];
    [self.view addSubview:newsLabel];
    [newsLabel release];
    
    [self fillUpMenuItems:NO];
    _sendMsgUrlMenu = [[JBoSendMsgUrlMenu alloc] initWithFrame:CGRectMake(0, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _menuHeight_, _width_, _menuHeight_) menuItems:self.infoArray];
    _sendMsgUrlMenu.delegate = self;
    [self.view addSubview:_sendMsgUrlMenu];
   
//    for(NSInteger i = 0;i < _maxMainItems_;i ++)
//    {
//        JBoPopupMenu *menu = [[[JBoPopupMenu alloc] initWithStyle:JBoPopupMenuStylePlainText] autorelease];
//        menu.tintColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
//        menu.menuTitleColor = [UIColor blackColor];
//        menu.separatedLineColor = [UIColor lightGrayColor];
//       // menu.menuItems = menuItems;
//        menu.delegate = self;
//        
//        CGRect relateRect = [_sendMsgUrlMenu getItemFrameAtIndex:i];
//        relateRect.origin.y = _sendMsgUrlMenu.frame.origin.y;
//        relateRect.size.height = _sendMsgUrlMenu.frame.size.height;
//        
//        [menu showInView:self.view relatedRect:relateRect animated:YES overlay:YES];
//        [self.view bringSubviewToFront:menu];
//    }
}

- (void)serverProtocolAction:(UIButton*) button
{
    JBoUserPrivacyViewController *userPrivacy = [[JBoUserPrivacyViewController alloc] init];
    [self.navigationController pushViewController:userPrivacy animated:YES];
    [userPrivacy release];
}

#pragma mark-JBoSendMsgUrlMenu代理
- (void)sendMsgUrlMenu:(JBoSendMsgUrlMenu *)urlMenu didSelectedItem:(JBoSendMsgUrlMenuItemView *)item
{
    
    JBoSendMsgUrlMenuItem *menuItem = [urlMenu.menuItems objectAtIndex:item.index];
    NSInteger mainIndex = self.mainMenuCurrentIndex;
    [self.urlSecondaryMenu dismissMenuWithAnimated:YES];
    
    if(mainIndex != item.index)
    {
        NSMutableArray *menuItems = [[NSMutableArray alloc] initWithCapacity:menuItem.childItems.count];
        NSString *maxLengthTitle = nil;
        
        for(JBoSendMsgUrlMenuItem *tmpItem in menuItem.childItems)
        {
            JBoPopupMenuItem *popupMenuItem = [JBoPopupMenuItem menuItemWithIcon:nil title:tmpItem.title];
            popupMenuItem.add = tmpItem.add;
            [menuItems addObject:popupMenuItem];
            
            if(tmpItem.title.length > maxLengthTitle.length)
            {
                maxLengthTitle = tmpItem.title;
            }
        }
        
        
        self.urlSecondaryMenu = [[[JBoPopupMenu alloc] initWithStyle:JBoPopupMenuStylePlainText] autorelease];
        self.urlSecondaryMenu.tintColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        self.urlSecondaryMenu.menuTitleColor = [UIColor blackColor];
        self.urlSecondaryMenu.separatedLineColor = [UIColor lightGrayColor];
        self.urlSecondaryMenu.menuItems = menuItems;
        CGFloat width = [self.urlSecondaryMenu getMenuWidthFromTitle:maxLengthTitle];
        width = width < item.bounds.size.width - 10 ? item.bounds.size.width - 10 : width;
        self.urlSecondaryMenu.menuWidth = width;
        self.urlSecondaryMenu.delegate = self;
        
        CGRect relateRect = item.frame;
        relateRect.origin.y = urlMenu.frame.origin.y;
        relateRect.size.height = urlMenu.frame.size.height;
        
        [self.urlSecondaryMenu showInView:self.view relatedRect:relateRect animated:YES overlay:YES];
        [self.view bringSubviewToFront:urlMenu];
        self.mainMenuCurrentIndex = item.index;
        [menuItems release];
    }
    else
    {
        self.mainMenuCurrentIndex = NSNotFound;
    }
    
}


- (void)sendMsgUrlMenu:(JBoSendMsgUrlMenu *)urlMenu didAddedAtItem:(JBoSendMsgUrlMenuItemView *)item
{
    if(self.isRequesting)
        return;
   // NSLog(@"addmenuitem");
    self.operationType = JBoMenuOperationTypeMain;
    self.selectedMainMenuIndex = item.index;
    [self addMenuItem];
}

- (void)sendMsgUrlMenu:(JBoSendMsgUrlMenu *)urlMenu didLongPressItem:(JBoSendMsgUrlMenuItemView *)item
{
    if(self.isRequesting)
        return;
    
    [self.urlSecondaryMenu dismissMenuWithAnimated:NO];
    
    JBoSendMsgUrlMenuItem *menuItem = [self.infoArray objectAtIndex:item.index];
    self.selectedMainMenuIndex = item.index;
    self.operationType = JBoMenuOperationTypeMain;
    if(menuItem.add)
    {
        [self addMenuItem];
    }
    else
    {
        [self menuItemOperation];
    }
}

#pragma mark-JBoPopupMenu代理
- (void)popupMenu:(JBoPopupMenu *)menu didSelectedAtIndex:(NSInteger)index
{
    JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.mainMenuCurrentIndex];
    JBoSendMsgUrlMenuItem *subItem = [mainItem.childItems objectAtIndex:index];
    
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.black = NO;
    web.URL = [NSURL URLWithString:subItem.url];
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

- (void)popupMenu:(JBoPopupMenu *)menu didAddedAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    self.selectedMainMenuIndex = self.mainMenuCurrentIndex;
    self.subMenuCurrentIndex = index;
    self.operationType = JBoMenuOperationTypeSub;
    [self addMenuItem];
}

- (void)popupMenu:(JBoPopupMenu *)menu didLongPressAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    
    self.selectedMainMenuIndex = self.mainMenuCurrentIndex;
    JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
    JBoSendMsgUrlMenuItem *subItem = [mainItem.childItems objectAtIndex:index];
    
    self.subMenuCurrentIndex = index;
    self.operationType = JBoMenuOperationTypeSub;
    
    if(subItem.add)
    {
        [self addMenuItem];
    }
    else
    {
        [self menuItemOperation];
    }
}

- (void)popupMenuWillDismiss:(JBoPopupMenu *)menu
{
    self.mainMenuCurrentIndex = NSNotFound;
}

- (void)menuItemOperation
{
    if(self.isRequesting)
        return;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"编辑", @"删除", nil];
    actionSheet.destructiveButtonIndex = 1;
    [actionSheet showInView:self.view];
    [actionSheet release];
}

#pragma mark-actionSheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
  //  NSLog(@"index %d",buttonIndex);
    switch (buttonIndex)
    {
        case 0 :
        {
            [self addMenuItem];
            switch (self.operationType)
            {
                case JBoMenuOperationTypeMain :
                {
                    JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
                    
                    self.textField.text = mainItem.title;
                    self.textView.text = mainItem.url;
                    self.operationType = JBoMenuOperationTypeMainUpdate;
                    
                }
                    break;
                case JBoMenuOperationTypeSub :
                {
                    JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
                    JBoSendMsgUrlMenuItem *subItem = [[mainItem childItems] objectAtIndex:self.subMenuCurrentIndex];
                    
                    self.textField.text = subItem.title;
                    self.textView.text = subItem.url;
                    self.operationType = JBoMenuOperationTypeSubUpdate;
                }
                    break;
                default:
                    break;
            }
        }
            break;
        case 1 :
        {
            switch (self.operationType)
            {
                case JBoMenuOperationTypeMain :
                {
                    JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
                    self.currentMenuItem = mainItem;
                    _httpRequest.identifier = _removeMainMenuIdentifier_;
                    if([_httpRequest downloadWithURL:[JBoURLMenuOperation removeMainMenuWithId:mainItem.Id]])
                    {
                        self.isRequesting = YES;
                    }
                }
                    break;
                case JBoMenuOperationTypeSub :
                {
                    _httpRequest.identifier = _removeSubMenuIdentifier_;
                    JBoSendMsgUrlMenuItem *mainItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
                    JBoSendMsgUrlMenuItem *subItem = [[mainItem childItems] objectAtIndex:self.subMenuCurrentIndex];
                    
                    if([_httpRequest downloadWithURL:[JBoURLMenuOperation removeSubMenuWithId:subItem.Id]])
                    {
                        self.isRequesting = YES;
                    }
                }
                    break;
                default:
                    break;
            }
        }
            break;
        default:
            break;
    }
}



- (void)fillUpMenuItems:(BOOL) main
{
    if(!self.infoArray)
    {
        self.infoArray = [[[NSMutableArray alloc] initWithCapacity:_maxMainItems_] autorelease];
    }
    
    if(!main)
    {
        for(NSInteger i = 0;i < self.infoArray.count;i ++)
        {
            JBoSendMsgUrlMenuItem *item = [self.infoArray objectAtIndex:i];
            
            if(!item.childItems)
            {
                item.childItems = [[[NSMutableArray alloc] initWithCapacity:_maxSubItems_] autorelease];
            }
            
            NSInteger j = item.childItems.count;
            JBoSendMsgUrlMenuItem *tmpItem = [item.childItems lastObject];
            
            if(j < _maxSubItems_ && tmpItem.add == NO)
            {
                JBoSendMsgUrlMenuItem *subItem = [JBoSendMsgUrlMenuItem urlMenuItemWithTitle:nil childItems:nil];
                subItem.add = YES;
                [item.childItems addObject:subItem];
            }
        }
    }
    
    
    NSInteger index = self.infoArray.count;
    JBoSendMsgUrlMenuItem *item = [self.infoArray lastObject];
    
    if(index < _maxMainItems_ && !item.add)
    {
        NSMutableArray *subMenuItems = [[NSMutableArray alloc] initWithCapacity:_maxSubItems_];
       
        JBoSendMsgUrlMenuItem *subItem = [JBoSendMsgUrlMenuItem urlMenuItemWithTitle:nil childItems:nil];
        subItem.add = YES;
        [subMenuItems addObject:subItem];
        
        JBoSendMsgUrlMenuItem *mainMenuItem = [JBoSendMsgUrlMenuItem urlMenuItemWithTitle:nil childItems:subMenuItems];
        mainMenuItem.add = YES;
        [self.infoArray addObject:mainMenuItem];
        [subMenuItems release];
    }
    
}

- (void)addMenuItem
{
    if(self.isRequesting)
    {
        return;
    }
    
    if(!self.textField)
    {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeEdit:)];
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [_transparentView addGestureRecognizer:tap];
        [tap release];
        [self.view addSubview:_transparentView];
        
        UIView *bottomBgView = [[UIView alloc] initWithFrame:CGRectMake(0, _height_ - _bottomHeight_, _width_, _bottomHeight_)];
        bottomBgView.backgroundColor = _mainBackgroundColor_;
        [self.view addSubview:bottomBgView];
        [bottomBgView release];
        self.bottomBgView = bottomBgView;
        
        CGFloat interval = 10;
        self.textField = [[[UITextField alloc] initWithFrame:CGRectMake(interval, interval, _width_ - interval * 2, 30)] autorelease];
        self.textField.delegate = self;
        self.textField.backgroundColor = [UIColor whiteColor];
        self.textField.returnKeyType = UIReturnKeyDone;
        self.textField.borderStyle = UITextBorderStyleNone;
        self.textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.textField.layer.cornerRadius = 6.0;
        self.textField.layer.masksToBounds = YES;
        self.textField.placeholder = @"标题";
        // [self.textField addTarget:self action:@selector(textDidChange:) forControlEvents:UIControlEventEditingChanged];
        [bottomBgView addSubview:self.textField];
        
        self.textView = [[[SSTextView alloc] initWithFrame:CGRectMake(interval, self.textField.bounds.size.height + self.textField.frame.origin.y + interval, _width_ - interval * 2, self.textField.bounds.size.height * 2)] autorelease];
        self.textView.delegate = self;
        self.textView.returnKeyType = UIReturnKeyDone;
        self.textView.keyboardType = UIKeyboardTypeURL;
        self.textView.layer.cornerRadius = 6.0;
        self.textView.layer.masksToBounds = YES;
        self.textView.placeholder = @"网址";
        self.textView.font = self.textField.font;
        [bottomBgView addSubview:self.textView];
    }
    
    
    [self.view bringSubviewToFront:self.bottomBgView];
    [self.textField becomeFirstResponder];
}

#pragma mark-textField

- (void)closeEdit:(UITapGestureRecognizer*)tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if([self addMenuOperation])
    {
         [self closeEdit:nil];
    }
    else
    {
        return NO;
    }
   
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        if([self addMenuOperation])
        {
            [self closeEdit:nil];
        }
        
        return NO;
    }
    
    return YES;
}

- (BOOL)addMenuOperation
{
    self.currentTitle = self.textField.text;
    self.currentURL = self.textView.text;
    
    switch (self.operationType)
    {
        case JBoMenuOperationTypeMain :
        case JBoMenuOperationTypeMainUpdate:
        {
            if([NSString isEmpty:self.textField.text])
            {
                [JBoUserOperation alertMsg:@"输入不能为空"];
                return NO;
            }
            
            self.currentMenuItem = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
            
            if(self.operationType == JBoMenuOperationTypeMain)
            {
                [self addMainMenuItem];
            }
            else
            {
                [self updateMainMenuItem];
            }
        }
            break;
        case JBoMenuOperationTypeSub :
        case JBoMenuOperationTypeSubUpdate:
        {
            if([NSString isEmpty:self.textField.text] || [NSString isEmpty:self.textView.text])
            {
                [JBoUserOperation alertMsg:@"输入不能为空"];
                return NO;
            }
            
            JBoSendMsgUrlMenuItem *item = [self.infoArray objectAtIndex:self.selectedMainMenuIndex];
            self.currentMenuItem = [item.childItems objectAtIndex:self.subMenuCurrentIndex];
            
            if(self.operationType == JBoMenuOperationTypeSub)
            {
                [self addSubMenuItemWithMainId:item.Id];
            }
            else
            {
                [self updateSubMenuItem];
            }
        }
            break;
        default:
            break;
    }
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
