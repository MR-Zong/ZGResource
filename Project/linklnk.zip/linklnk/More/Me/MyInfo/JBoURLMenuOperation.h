//
//  JBoURLMenuOperation.h
//  连你
//
//  Created by kinghe005 on 14-3-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoSendMsgUrlMenu.h"

#define _getUserMenuInfoIdentifier_ @"getUserMenuInfoIdentifier"
#define _addUserMainMenuItemIdentifier_ @"addUserMainMenuItemIdentifier"
#define _addUserSubMenuItemIdentifier_ @"addUserSubMenuItemIdentifier"

#define _removeMainMenuIdentifier_ @"removeMainMenuIdentifier"
#define _removeSubMenuIdentifier_ @"removeSubMenuIdentifier"

#define _updateMainMenuIdentifier_ @"updateMainMenuIdentifier"
#define _updateSubMenuIdentifier_ @"updateSubMenuIdentifier"

/**服务平台网络操作相关方法
 */
@interface JBoURLMenuOperation : NSObject

/**返回服务平台信息
 *@param userId 要返回信息的用户
 *@return get请求url
 */
+ (NSString*)getUserMenuWithUserId:(NSString*) userId;

/**从返回的数据获取服务平台信息
 *@param 返回的数据
 *@return 数组元素是 JBoSendMsgUrlMenuItem 对象
 */
+ (NSMutableArray*)getUserMenuFromData:(NSData*) data;

/**新增主菜单
 *@param title 菜单标题
 *@param url 菜单链接，可为空
 *@param get请求url
 */
+ (NSString*)addUserMainMenuItemWithTitle:(NSString*) title url:(NSString*) url;

/**从返回的数据获取新增主菜单结果
 *@param data 返回的数据
 *@return 成功返回菜单Id，否则返回0
 */
+ (long long)addUserMainMenuItemResultFromData:(NSData*) data;

/**新增次级菜单
 *@param mainId 主菜单Id
 *@param title 菜单标题
 *@param url 菜单链接
 *@return get请求url
 */
+ (NSString*)addUserSubMenuItemWithMainId:(long long) mainId title:(NSString*) title url:(NSString*) url;

/**从返回的数据获取次级菜单结果
 *@param data 返回的数据
 *@return 成功返回菜单Id，否则返回0
 */
+ (long long)addUserSubMenuItemResultFromData:(NSData*) data;

/**删除主菜单
 *@param Id 主菜单Id
 *@return get请求url
 */
+ (NSString*)removeMainMenuWithId:(long long) Id;

/**更新主菜单
 *@param Id 要更新的菜单Id
 *@param title 菜单标题
 *@param url 菜单链接
 *@return get请求url
 */
+ (NSString*)updateMainMenuWithId:(long long) Id title:(NSString*) title url:(NSString*) url;

/**更新子菜单
 *@param Id 要更新的菜单Id
 *@param title 菜单标题
 *@param url 菜单链接
 *@return get请求url
 */
+ (NSString*)updateSubMenuWithId:(long long) Id title:(NSString*) title url:(NSString*) url;

/**删除子菜单
 *@param Id 子菜单Id
 *@return get请求url
 */
+ (NSString*)removeSubMenuWithId:(long long) Id;

@end
