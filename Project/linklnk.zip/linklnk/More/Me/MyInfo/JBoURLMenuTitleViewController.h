//
//  JBoURLManagerViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JBoURLMenuTitleViewController : UIViewController
{
    UIView *_transparentView;
}

@property(nonatomic,retain)NSMutableArray *infoArray;
@property(nonatomic,assign) BOOL black;

@end
