//
//  JBoURLSecondaryMenuViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JBoURLSecondaryMenuViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_infoArray;
    
    UIView *_transparentView;
}

@property(nonatomic,copy) NSString *menuTitle;
@property(nonatomic,assign) NSInteger menuId;

@end
