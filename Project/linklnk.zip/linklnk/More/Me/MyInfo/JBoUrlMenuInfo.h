//
//  JBoUrlMenuInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**服务平台菜单信息
 */
@interface JBoUrlMenuInfo : NSObject

@property(nonatomic,copy) NSString *title;
@property(nonatomic,copy) NSString *url;

@property(nonatomic,retain) NSArray *childItems;

+ (id)urlMenuInfoWithTitle:(NSString*) title url:(NSString*) url  childItems:(NSArray*) childItems;

@end
