//
//  JBoUserInfoModifyViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-9.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserInfoModifyViewController.h"
#import "JBoUserDetailInfo.h"
#import "JBoNavigatioinBarOperation.h"
#import "JBoCheckInputText.h"
#import "SSTextView.h"
#import "JBoCheckBoxTextView.h"


#define _padding_ 20
#define _controlHeight_ 40.0

@interface JBoUserInfoModifyViewController ()

@property(nonatomic,retain) JBoCheckBoxTextView *checkBox;

@end

@implementation JBoUserInfoModifyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoUserInfoModifyViewController dealloc");
    
    self.delegate = nil;
    [_textField release];
    [_textView release];
    
    [_userDetailInfo release];
    [_checkBox release];

    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [_textField becomeFirstResponder];
    [_textView becomeFirstResponder];
}

#pragma mark- 加载视图

- (void)back
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    [self setRightBarItemWithTitle:@"完成" action:@selector(finishAction)];
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    switch (self.userInfoType) {
        case JBoUserInfoTypeName :
        {
            _textField = [[UITextField alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_)];
            _textField.borderStyle = UITextBorderStyleRoundedRect;
            _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            _textField.placeholder = [NSString stringWithFormat:@"不能超过%d个字",_inputFormatName_];
            _textField.text = self.userDetailInfo.rosterInfo.name;
            [self.view addSubview:_textField];
             NSLog(@"昵称");
        }
            break;
        case JBoUserInfoTypeProfession :
        {
            _textField = [[UITextField alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_)];
            _textField.borderStyle = UITextBorderStyleRoundedRect;
            _textField.text = self.userDetailInfo.vocation;
            _textField.placeholder = [NSString stringWithFormat:@"不能超过%d个字",_inputFormatName_];
            _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            [self.view addSubview:_textField];
             NSLog(@"职业");
        }
            break;
        case JBoUserInfoTypeID :
        {
            _textField = [[UITextField alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_)];
            _textField.borderStyle = UITextBorderStyleRoundedRect;
            _textField.text = self.userDetailInfo.phoneNum;
            _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            _textField.keyboardType = UIKeyboardTypeNumberPad;
            [self.view addSubview:_textField];
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, _textField.frame.origin.y + _textField.frame.size.height, _width_ - _padding_ * 2, _controlHeight_)];
            label.backgroundColor = [UIColor clearColor];
            label.text = @"用于找回密码和拨号,请输入有效的手机号";
            label.font = [UIFont systemFontOfSize:14.0];
            [label setTextAlign:JBoTextAlignmentCenter];
            [self.view addSubview:label];
            [label release];
            
            self.checkBox = [[[JBoCheckBoxTextView alloc] initWithFrame:CGRectMake(_padding_, label.bottom, _width_ - _padding_ * 2, 55.0) title:[NSString stringWithFormat:@"公开之后,%@好友可以拨打该手机号,但陌生人无法查看和拨打。云通讯录可跨平台共享", self.appDelegate.appName]] autorelease];
            self.checkBox.titleLabel.font = [UIFont systemFontOfSize:14.0];
            
            CGRect rect = [self.checkBox.titleLabel textRectForBounds:self.checkBox.titleLabel.bounds limitedToNumberOfLines:self.checkBox.titleLabel.numberOfLines];
            
            self.checkBox.checkBox.top = rect.origin.y - 2.0;
        
            if(self.userDetailInfo.phoneState)
            {
                
                [self.checkBox.checkBox checkBoxStateChange:CheckBoxStyleSeclected];
            }
            [self.view addSubview:self.checkBox];
            
            NSLog(@"手机");
        }
            break;
        case JBoUserInfoTypePresence :
        {
            _textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_ * 3)];
            _textView.layer.cornerRadius = 6;
            _textView.layer.borderWidth = 0.2;
            _textView.layer.borderColor = [UIColor grayColor].CGColor;
            _textView.font = [UIFont systemFontOfSize:17];
            _textView.delegate = self;
            _textView.text = self.userDetailInfo.rosterInfo.presence;
            _textView.scrollEnabled = NO;
            _textView.maxCount = _inputFormatPresenceNum_;
            _textView.limitable = YES;
            _textView.placeholder = [NSString stringWithFormat:@"个性签名,将自动同步到%@", _lookAndTellName_];
            [self.view addSubview:_textView];
            
        }
            break;
            case JBoUserInfoTypeEnterpriseAddr :
        {
            _textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_ * 3)];
            _textView.layer.cornerRadius = 6;
            _textView.layer.borderWidth = 0.2;
            _textView.layer.borderColor = [UIColor grayColor].CGColor;
            _textView.font = [UIFont systemFontOfSize:17];
           // _textView.delegate = self;
            _textView.text = self.userDetailInfo.rosterInfo.enterpriseAddr;
            _textView.scrollEnabled = NO;
//            _textView.maxCount = _inputFormatPresenceNum_;
            _textView.limitable = NO;
            _textView.placeholder = @"认证地址";
            [self.view addSubview:_textView];
        }
            break;
            case JBoUserInfoTypeEnterpriseTelePhone :
        {
            _textField = [[UITextField alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_)];
            _textField.borderStyle = UITextBorderStyleRoundedRect;
            _textField.text = self.userDetailInfo.rosterInfo.enterpriseTelePhone;
            _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            _textField.keyboardType = UIKeyboardTypeNumberPad;
            _textField.placeholder = @"认证固话";
            [self.view addSubview:_textField];
        }
            break;
        default:
            break;
    }
    
    _textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
}

#pragma mark-textView代理

- (void)textViewDidChange:(UITextView *)textView
{
    SSTextView *sst = (SSTextView*)textView;
    [sst textDidChange];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    SSTextView *sst = (SSTextView*)textView;
    return [sst shouldChangeTextInRange:range replacementText:text];
}


- (BOOL)empty
{
    if(_textField)
    {
        if([_textField.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0)
        {
            [self alertMessage:@"输入不能为空"];
            return NO;
        }
    }
    
    if(_textView)
    {
        if([_textView.text stringByReplacingOccurrencesOfString:@" " withString:@""].length == 0)
        {
            [self alertMessage:@"输入不能为空"];
            return NO;
        }
    }
    
    return YES;
}

- (BOOL)evaluteLegally
{
    if(![self empty])
    {
        return NO;
    }
    
    NSString *message = nil;
    switch (self.userInfoType) {
        case JBoUserInfoTypeName :
        {
            if(_textField.text.length > _inputFormatName_)
            {
                message = [NSString stringWithFormat:@"昵称字数不能超过%d个字", _inputFormatName_];
            }
            else if([JBoCheckInputText isIncludeSpecialCharacter:_textField.text])
            {
                message = [NSString stringWithFormat:@"昵称不能包含特殊字符"];
            }
        }
            break;
        case JBoUserInfoTypeID :
        {
            if(![JBoCheckInputText isMobileNumber:_textField.text])
            {
                message = [NSString stringWithFormat:@"请输入有效手机号码"];
            }
        }
            break;
        case JBoUserInfoTypeProfession :
        {
            if(_textField.text.length > _inputFromatProfession_)
            {
                message = [NSString stringWithFormat:@"职业字数不能超过%d个字", _inputFromatProfession_];
            }
        }
            break;
        case JBoUserInfoTypePresence :
        {
            if(_textView.text.length > _inputFormatPresenceNum_)
            {
                message = [NSString stringWithFormat:@"个性签名字数不能超过%d个字", _inputFormatPresenceNum_];
            }
        }
            break;
        case JBoUserInfoTypeEnterpriseAddr :
        {
            
        }
            break;
            case JBoUserInfoTypeEnterpriseTelePhone :
        {
            
        }
        default:
            break;
    }
    
    if(message)
    {
        [self alertMessage:message];
        return NO;
    }
    
    return YES;
}

//修改完成
- (void)finishAction
{
   if(![self evaluteLegally])
       return;
    NSString *info = nil;
    NSString *modifyValue = nil;
    
    switch (self.userInfoType)
    {
        case JBoUserInfoTypeName :
            modifyValue = _textField.text;
            info = _rosterName_;
            break;
        case JBoUserInfoTypeID :
            modifyValue = _textField.text;
            info = _rosterPhoneNum_;
            break;
        case JBoUserInfoTypeProfession :
            modifyValue = _textField.text;
            info = _rosterVocation_;
            break;
        case JBoUserInfoTypePresence :
            info = _rosterPresence_;
            modifyValue = _textView.text;
            break;
        case JBoUserInfoTypeEnterpriseTelePhone :
            info = _rosterEnterpriseTelephone_;
            modifyValue = _textField.text;
            break;
        case JBoUserInfoTypeEnterpriseAddr :
            info = _rosterEnterpriseAddr_;
            modifyValue = _textView.text;
            break;
        default:
            break;
    }
    
    if(modifyValue != nil)
    {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObject:modifyValue forKey:info];
        if(self.userInfoType == JBoUserInfoTypeID)
        {
            [dic setObject:[NSNumber numberWithBool:self.checkBox.checkBox.selected] forKey:_rosterPhoneState_];
        }
        
        if([self.delegate respondsToSelector:@selector(userInfoModifyViewController:didModifyUserInfo:)])
        {
            [self.delegate userInfoModifyViewController:self didModifyUserInfo:dic];
        }
    }
    
    [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
