//
//  JBoDealAddrViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoDealAddrViewController.h"
#import "JBoMapViewController.h"
#import "JBoImageTextTool.h"
#import "SSTextView.h"
#import "JBoAppDelegate.h"
#import "BMapKit.h"


#define _padding_ 20
#define _controlHeight_ 30
#define _controlInterval_ 5

@interface JBoDealAddrViewController ()<BMKSearchDelegate,CLLocationManagerDelegate>
{
    JBoAppDelegate *_appDelegate;
    BMKSearch *_addrSearch;
    CLLocationManager *_locationManager;
}

@property(nonatomic,copy) NSString *addrInfo;
@property(nonatomic,assign) CLLocationCoordinate2D currentCoordinate;

@end

@implementation JBoDealAddrViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"交易地址";
        
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        //位置信息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(locationDidSelected:) name:_sendLocationInfoNotification_ object:nil];
    }
    return self;
}

#pragma mark-通知
- (void)locationDidSelected:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    NSString *str = [dic objectForKey:_locationInfo_];
    
    NSDictionary *coorDic = [JBoImageTextTool getCoordinateFromString:str];
    
    self.addrInfo = [[coorDic allKeys] objectAtIndex:0];
    _textView.text = self.addrInfo;
    NSArray *array = [[coorDic allValues] objectAtIndex:0];
    
    NSString *lat = [array objectAtIndex:0];
    NSString *lon = [array objectAtIndex:1];
    
    self.currentCoordinate = CLLocationCoordinate2DMake([lat doubleValue], [lon doubleValue]);
}

#pragma mark-内存管理
- (void)dealloc
{
    [_actView release];
    [_userDetailInfo release];
    
    [_addrInfo release];
    [_addrSearch release];
    [_locationManager release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_sendLocationInfoNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    _addrSearch.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    _addrSearch.delegate = self;
}

- (void)backAction:(id) sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(backAction:)];
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(finishAction:) title:@"完成" backgroundImage:nil textColor:[UIColor whiteColor]];
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    _textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_ * 3)];
    _textView.layer.cornerRadius = 6;
    _textView.layer.borderWidth = 0.2;
    _textView.layer.borderColor = [UIColor grayColor].CGColor;
    _textView.font = [UIFont systemFontOfSize:17];
    _textView.delegate = self;
   // _textView.text = self.userDetailInfo.dealAddr;
    _textView.scrollEnabled = NO;
    _textView.maxCount = _inputFormatDealAddr_;
    _textView.limitable = YES;
    _textView.placeholder = [NSString stringWithFormat:@"不能超过%d个字",_inputFormatPresenceNum_];
    [self.view addSubview:_textView];
    
  //  self.currentCoordinate = CLLocationCoordinate2DMake(self.userDetailInfo.latitude, self.userDetailInfo.longitude);
    
    //位置
    CGFloat locationButtonWidth = 80;
    UIImage *uploadImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"upload_btn@2x" ofType:_imageType_]];
    
    _currentLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_currentLocationButton setTitle:@"默认当前" forState:UIControlStateNormal];
    [_currentLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_currentLocationButton setBackgroundImage:uploadImage forState:UIControlStateNormal];
    [_currentLocationButton addTarget:self action:@selector(currentLocationAction:) forControlEvents:UIControlEventTouchUpInside];
    [_currentLocationButton setFrame:CGRectMake(_padding_, _textView.frame.origin.y + _textView.frame.size.height + _controlInterval_ * 3, locationButtonWidth, _controlHeight_)];
    [self.view addSubview:_currentLocationButton];
    
    _otherLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_otherLocationButton setTitle:@"其他位置" forState:UIControlStateNormal];
    [_otherLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_otherLocationButton setBackgroundImage:uploadImage forState:UIControlStateNormal];
    [_otherLocationButton addTarget:self action:@selector(otherLocationAction:) forControlEvents:UIControlEventTouchUpInside];
    [_otherLocationButton setFrame:CGRectMake(_width_ - _padding_ - locationButtonWidth, _currentLocationButton.frame.origin.y, locationButtonWidth, _controlHeight_)];
    [self.view addSubview:_otherLocationButton];
    [uploadImage release];
}


- (void)finishAction:(id) sender
{
     NSString *location = [NSString stringWithFormat:@"%f,%f[%@]",self.currentCoordinate.latitude,self.currentCoordinate.longitude,self.addrInfo];
    [[NSNotificationCenter defaultCenter] postNotificationName:_dealAddrDidFinishedModifiedNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:location forKey:_locationInfo_]];
    
    [self performSelector:@selector(backAction:) withObject:nil afterDelay:0.3];
}

#pragma mark-位置
- (void)currentLocationAction:(UIButton*) button
{
    if(!_actView)
    {
        CGFloat size = 30;
        _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _actView.hidesWhenStopped = YES;
        _actView.frame = CGRectMake((_width_ - size) / 2,_otherLocationButton.frame.origin.y + (_controlHeight_ - size) / 2, size, size);
        [self.view addSubview:_actView];
    }
    
    [_actView startAnimating];
    [self location];
}

- (void)otherLocationAction:(id) sender
{
    JBoMapViewController *mapVC = [[JBoMapViewController alloc] init];
    mapVC.isSender = YES;
    NSDictionary *dic = BMKBaiduCoorForWgs84(self.currentCoordinate);
    CLLocationCoordinate2D coordinate = BMKCoorDictionaryDecode(dic);
    mapVC.currentCoordinate = coordinate;
    [self.navigationController pushViewController:mapVC animated:YES];
    [mapVC release];
}

- (void)finishLocation:(BOOL) success
{
    [_actView stopAnimating];
    if(success)
    {
        _textView.text = self.addrInfo;
    }
    else
    {
        _appDelegate.alertView.message = @"无法确定您当前的位置";
        [_appDelegate.alertView viewDesalt:_second_];
    }
}

//BMKSearchDelegate
- (void)onGetAddrResult:(BMKAddrInfo *)result errorCode:(int)error
{
    if(error)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        return;
    }
    NSLog(@"--%@",result.strAddr);
    self.addrInfo = result.strAddr;
    [self finishLocation:YES];
}

- (void)location
{
    if([CLLocationManager locationServicesEnabled])
    {
        if(!_locationManager)
        {
            _locationManager = [[CLLocationManager alloc] init];
            _locationManager.delegate = self;
            _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
            _locationManager.distanceFilter = 1000;
        }
        
        [_locationManager startUpdatingLocation];
    }
    else
    {
        [self finishLocation:NO];
    }
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *location = [locations lastObject];
    if(location)
    {
        self.currentCoordinate = location.coordinate;
        NSLog(@"%f,%f",self.currentCoordinate.latitude, self.currentCoordinate.longitude);
        [_locationManager stopUpdatingLocation];
        if(!_addrSearch)
        {
            _addrSearch = [[BMKSearch alloc] init];
            _addrSearch.delegate = self;
        }
        
        NSDictionary *dic = BMKBaiduCoorForWgs84(self.currentCoordinate);
        CLLocationCoordinate2D coordinate = BMKCoorDictionaryDecode(dic);
        [_addrSearch reverseGeocode:coordinate];
    }
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"定位失败");
    [self finishLocation:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
