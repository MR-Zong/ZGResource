//
//  JBoUserInfoSelectedViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-9.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoUserInfoSelectedViewController.h"
#import "JBoUserDetailInfo.h"
#import "JBoNavigatioinBarOperation.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"

@interface JBoUserInfoSelectedViewController ()<JBoHttpRequestDelegate>
{
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoUserInfoSelectedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoUserInfoSelectedViewController dealloc");
    
    [_userDetailInfo release];
    [_tableView release];
    [_srcArray release];
    
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取行业失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    NSArray *array = [JBoUserOperation getTradeListFromData:data];
    if(array)
    {
        [_srcArray addObjectsFromArray:array];
        if(!_tableView)
        {
            [self loadInitView];
        }
    }
}



#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //返回按钮
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)loadInitView
{
    CGFloat cellHeight = 40;
    CGFloat tableViewHeight = _srcArray.count * cellHeight >  _height_ - _navgateBarHeight_ - _statuBarHeight_ ?  _height_ - _navgateBarHeight_ - _statuBarHeight_ : _srcArray.count * cellHeight;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_,tableViewHeight) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
}

- (void)setUserInfoType:(JBoUserInfoType)userInfoType
{
    if(_userInfoType != userInfoType)
    {
        _userInfoType = userInfoType;
        switch (_userInfoType) {
            case JBoUserInfoTypeTrade :
            {
                _srcArray = [[NSMutableArray alloc] init];
                
                _httpRequest = [[JBoHttpRequest alloc] init];
                _httpRequest.delegate = self;
                if([_httpRequest downloadWithURL:[JBoUserOperation getTradeListURL]])
                {
                    self.isRequesting = YES;
                }
            }
                break;
                case JBoUserInfoTypeSex :
            {
                _srcArray = [[NSMutableArray alloc] initWithObjects:[NSDictionary dictionaryWithObject:@"男" forKey:[NSString stringWithFormat:@"%d",_sexBoy_]], [NSDictionary dictionaryWithObject:@"女" forKey:[NSString stringWithFormat:@"%d",_sexGirl_]], nil];
                [self loadInitView];
            }
                break;
            default:
                break;
        }
    }
}

#pragma mark-tableview代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        
        if(self.userInfoType == JBoUserInfoTypeSex)
        {
            UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"verify_correct"]];
            cell.accessoryView = imageView;
            [imageView release];
        }
    }
    
    NSDictionary *dic = [_srcArray objectAtIndex:indexPath.row];
    NSString *key = [[dic allKeys] objectAtIndex:0];
    
    switch (self.userInfoType)
    {
        case JBoUserInfoTypeSex :
        {
            NSString *imageName = indexPath.row == 0 ? @"boyIconNormal@2x" : @"girlIconNormal@2x";
            UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:imageName ofType:_imageType_]];
            cell.imageView.image = image;
            [image release];
            
            cell.accessoryView.hidden = ![key isEqualToString:[NSString stringWithFormat:@"%d",self.userDetailInfo.rosterInfo.sex]];
        }
            break;
        case JBoUserInfoTypeTrade :
        {
            if([key isEqualToString:self.userDetailInfo.trade])
            {
                UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"verify_correct"]];
                cell.accessoryView = imageView;
                [imageView release];
            }
            else
            {
                cell.accessoryView = nil;
            }
        }
            break;
        default:
            break;
    }
  
    cell.textLabel.text = [[dic allValues] objectAtIndex:0];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = [_srcArray objectAtIndex:indexPath.row];
    NSString *key = [[dic allKeys] firstObject];
    
    NSString *info = nil;
    
    switch (self.userInfoType)
    {
        case JBoUserInfoTypeSex :
        {
            if(![key isEqualToString:[NSString stringWithFormat:@"%d",self.userDetailInfo.rosterInfo.sex]])
            {
                info = _rosterSex_;
            }
        }
            break;
        case JBoUserInfoTypeTrade :
        {
            if(![key isEqualToString:self.userDetailInfo.trade])
            {
                info = _rosterTrade_;
            }
        }
            break;
        default:
            break;
    }
    
    if(info)
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:_userDetailInfoDidSelectedNofitication_ object:self userInfo:[NSDictionary dictionaryWithObject:dic forKey:info]];
    }
    
    [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
