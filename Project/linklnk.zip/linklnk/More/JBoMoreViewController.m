//
//  KingHeMoreViewController.m
//  微喂
//
//  Created by kinghe005 on 13-8-21.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoMoreViewController.h"
#import "JBoSystemSetupViewController.h"
#import "JBoCircleLookAndTellViewController.h"
#import "JBoImageTextTool.h"
#import "JBoCustomTabBarController.h"
#import "JBoUserInfoViewController.h"
#import "JBoAroundHelpViewController.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoNewMsgRemindOperation.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoOpenPlatformViewController.h"
#import "JBoTTSViewController.h"
#import "JBoMoreTableViewHeader.h"
#import "JBoMoreInfo.h"
#import "JBoTableViewCell.h"
#import "JBoQRCodeOperation.h"

@interface JBoMoreViewController ()<JBoMoreTableViewHeaderDelegate,JBoHttpRequestDelegate>

@property(nonatomic,retain) JBoNewMsgRemindOperation *newsMsgRemindOperation;
@property(nonatomic,retain) NSTimer *newsMsgRemindTimer;

//靓友圈新 附近秘密 消息标识
@property(nonatomic,retain) NSMutableDictionary *newsMsgRemindDic;
@property(nonatomic,retain) NSDate *lastRequestDate;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;
//默认位置
@property(nonatomic,retain) NSDictionary *defaultAddress;

/**超级世界数据，数组元素是 NSArray ,内部数组元素是 JBoMoreInfo
 */
@property(nonatomic,retain) NSArray *infos;

//表头
@property(nonatomic,retain) JBoMoreTableViewHeader *tableViewHeader;

@end

@implementation JBoMoreViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self)
    {
        [self initData];
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if(self)
    {
        [self initData];
    }
    
    return self;
}

//初始化数据
- (void)initData
{
    self.title = @"超级世界";
    //通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidEnterBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    //保存默认位置
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveDefaultAddr:) name:_saveDefaultAddrNotification_ object:nil];
}

#pragma mark- 通知

- (void)applicationWillEnterForeground:(NSNotification*) notificaton
{
    [self startNewMsgRemind];
}

- (void)applicationDidEnterBackground:(NSNotification*) notification
{
    [self stopNewMsgRemind];
}

//保存默认位置
- (void)saveDefaultAddr:(NSNotification*) notification
{
    self.defaultAddress = [notification userInfo];
    if(![self.defaultAddress objectForKey:_rosterDefaultAddr_])
        return;
    
    self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self identifier:_modifyUserInfoIdentifier_] autorelease];
    self.httpRequest.needAlertMsg = NO;
    [_httpRequest downloadWithURL:[JBoUserOperation getModifyUserInfoURL] dic:[JBoUserOperation getModifyUserInfoWithDic:self.defaultAddress]];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoMoreViewController dealloc");
    
    [_newsMsgRemindTimer release];
    
    [_newsMsgRemindOperation cancle];
    [_newsMsgRemindOperation release];
    
    [_newsMsgRemindDic release];
    [_lastRequestDate release];
    
    [_httpRequest release];
    [_defaultAddress release];
    
    [_infos release];
    [_tableViewHeader release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_saveDefaultAddrNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    //设置导航条背景
    [JBoNavigatioinBarOperation setDefaultNavigationBar:self.navigationController.navigationBar];
    self.navigationController.navigationBar.translucent = NO;
    [self.appDelegate hiddenCustomTabBar:NO];
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate hiddenCustomTabBar:YES];
}

#pragma mark- http代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.httpRequest = nil;
    self.defaultAddress = nil;
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    if([JBoUserOperation isSuccess:data])
    {
        JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
        info.defaultAddr = [self.defaultAddress objectForKey:_rosterDefaultAddr_];
        info.defalutAddrLat = [[self.defaultAddress objectForKey:_rosterDefaultLat_] doubleValue];
        info.defaultAddrLon = [[self.defaultAddress objectForKey:_rosterDefaultLon_] doubleValue];
        
        NSData *arcData = [NSKeyedArchiver archivedDataWithRootObject:info];
        [[NSUserDefaults standardUserDefaults] setObject:arcData forKey:_loginDetailUserInfo_];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    self.httpRequest = nil;
    self.defaultAddress = nil;
}

#pragma makr- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //表头
    JBoMoreTableViewHeader *header = [[JBoMoreTableViewHeader alloc] init];
    header.delegate = self;
    self.tableViewHeader = header;
    [header release];
    
    NSMutableArray *infos = [NSMutableArray arrayWithObjects:
                             [JBoMoreInfo infoWithType:JBoMoreInfoTypeImageEdit],
                             [JBoMoreInfo infoWithType:JBoMoreInfoTypeQRCode], nil];
    
    if(_ios7_0_)
    {
        [infos insertObject:[JBoMoreInfo infoWithType:JBoMoreInfoTypeTTS] atIndex:1];
    }
    
    //表数据
    self.infos = [NSArray arrayWithObjects:
                  infos,
                  [NSArray arrayWithObjects:
                   [JBoMoreInfo infoWithType:JBoMoreInfoTypeMe],
                   [JBoMoreInfo infoWithType:JBoMoreInfoTypeSetup],
                   nil],
                  nil];
    
    [super initialization];
    self.tableView.rowHeight = 45.0;

    self.tableView.tableHeaderView = header;
    
    //表脚
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tabBarHeight_)];
    footerView.backgroundColor = [UIColor clearColor];
    self.tableView.tableFooterView = footerView;
    [footerView release];
    
    [self setNewsMsgRemindState];
}

#pragma mark- JBoMoreTableViewHeader delegate

- (void)moreTableViewHeader:(JBoMoreTableViewHeader *)header didSelectInfoAtIndex:(NSInteger)index
{
    switch (index)
    {
        case 0 :
        {
            [self.newsMsgRemindDic setObject:[NSNumber numberWithBool:NO] forKey:_lookAndTellCircleRemind_];
            [self setNewsMsgRemindState];
            JBoCircleLookAndTellViewController *circleVC = [[JBoCircleLookAndTellViewController alloc] init];
            [self.navigationController pushViewController:circleVC animated:YES];
            [circleVC release];
        }
            break;
        case 1 :
        {
            JBoAroundHelpViewController *myHelpVC = [[JBoAroundHelpViewController alloc] init];
            myHelpVC.hasNewsSecret = [[self.newsMsgRemindDic objectWithKey:_aroundSecretRemind_] boolValue];
            [self.navigationController pushViewController:myHelpVC animated:YES];
            [myHelpVC release];
            [self.newsMsgRemindDic setObject:[NSNumber numberWithBool:NO] forKey:_aroundSecretRemind_];
            [self setNewsMsgRemindState];
        }
            break;
        case 2 :
        {
            JBoOpenPlatformViewController *open = [[JBoOpenPlatformViewController alloc] init];
            [self.navigationController pushViewController:open animated:YES];
            [open release];
        }
            break;
    }
}

#pragma mark-tableview 代理

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 1.0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _infos.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = [_infos objectAtIndex:section];
    return array.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.flatStyle = YES;
        cell.textLabel.font = _JBoMoreFont_;
        
        UIImageView *arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"arrow"]];
        cell.accessoryView = arrow;
        [arrow release];
    }
    
    NSArray *array = [_infos objectAtIndex:indexPath.section];
    JBoMoreInfo *info = [array objectAtIndex:indexPath.row];
    
    cell.imageView.image = info.icon;
    cell.textLabel.text = info.title;
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSArray *array = [_infos objectAtIndex:indexPath.section];
    JBoMoreInfo *info = [array objectAtIndex:indexPath.row];
    
    switch (info.type)
    {
        case JBoMoreInfoTypeSetup :
        {
            JBoSystemSetupViewController *systemSetupVC = [[JBoSystemSetupViewController alloc] init];
            [self.navigationController pushViewController:systemSetupVC animated:YES];
            [systemSetupVC release];
        }
            break;
        case JBoMoreInfoTypeTTS :
        {
            JBoTTSViewController *tts = [[JBoTTSViewController alloc] init];
            tts.black = self.black;
            [self.navigationController pushViewController:tts animated:YES];
            [tts release];
        }
            break;
        case JBoMoreInfoTypeMe :
        {
            JBoUserInfoViewController *userInfoVC = [[JBoUserInfoViewController alloc] init];
            userInfoVC.black = self.black;
            [self.navigationController pushViewController:userInfoVC animated:YES];
            [userInfoVC release];
        }
            break;
        case JBoMoreInfoTypeImageEdit :
        {
            [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
            JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
            mutilImagePicker.mutilImagePickType = JBoMutilImagePickTypeEditor;
            [self.navigationController pushViewController:mutilImagePicker animated:YES];
            [mutilImagePicker release];
        }
            break;
        case JBoMoreInfoTypeQRCode :
        {
            [JBoQRCodeOperation openQRCodeScanWithViewController:self];
        }
            break;
        default:
            break;
    }
}

#pragma mark- 新消息检测

//靓友圈 附近秘密检测
- (void)startNewMsgRemind
{
    if(!self.newsMsgRemindTimer)
    {
        self.newsMsgRemindTimer = [NSTimer scheduledTimerWithTimeInterval:_newMsgRemindInterval_ target:self selector:@selector(newsMsgRemindAction:) userInfo:nil repeats:YES];
        [self.newsMsgRemindTimer fire];
    }
    
    if(!self.newsMsgRemindDic)
    {
        self.newsMsgRemindDic = [NSMutableDictionary dictionaryWithCapacity:2];
        [self.newsMsgRemindDic addEntriesFromDictionary:[JBoNewMsgRemindOperation getNewMsgRemindState]];
        [self setNewsMsgRemindState];
    }
}

- (void)stopNewMsgRemind
{
    if(self.newsMsgRemindTimer != nil && [self.newsMsgRemindTimer isValid])
    {
        [self.newsMsgRemindTimer invalidate];
        self.newsMsgRemindTimer = nil;
        self.newsMsgRemindOperation = nil;
    }
}

//超友圈，附近秘密新消息检测
- (void)newsMsgRemindAction:(id) sender
{
    NSDate *date = [NSDate date];
    if(self.lastRequestDate == nil || [date timeIntervalSinceDate:self.lastRequestDate] >= _newMsgRemindInterval_ / 2.0)
    {
        self.lastRequestDate = date;
        
        JBoNewMsgRemindOperation *operation = [[JBoNewMsgRemindOperation alloc] init];
        self.newsMsgRemindOperation = operation;
        
        self.newsMsgRemindOperation.completionHandler = ^(NSDictionary *dic){
            
            [self.newsMsgRemindDic removeAllObjects];
            [self.newsMsgRemindDic addEntriesFromDictionary:dic];
            [self setNewsMsgRemindState];
            self.newsMsgRemindOperation = nil;
        };
        [self.newsMsgRemindOperation start];
        [operation release];
    }
}

//设置选项卡红点
- (void)setNewsMsgRemindState
{
    BOOL circle = [[self.newsMsgRemindDic valueWithKey:_lookAndTellCircleRemind_] boolValue];
    BOOL secret = [[self.newsMsgRemindDic valueWithKey:_aroundSecretRemind_] boolValue];
    
    if(self.tableViewHeader.infos.count >= 2)
    {
        JBoMoreInfo *info = [self.tableViewHeader.infos firstObject];
        info.hasNewMsg = circle;
        
        info = [self.tableViewHeader.infos objectAtIndex:1];
        info.hasNewMsg = secret;
        [self.tableViewHeader reloadData];
    }
    
    [JBoNewMsgRemindOperation setNewMsgRemindState:self.newsMsgRemindDic];
    [self.tableView reloadData];
    
    JBoCustomTabBarController *customTabBar = (JBoCustomTabBarController*)self.appDelegate.window.rootViewController;
    JBoCustomTabBarItem *tabBarItem = (JBoCustomTabBarItem*)[customTabBar.customTabBar viewWithTag:_tabBarItemStartTag_ + customTabBar.moreIndex];
    tabBarItem.badgeView.point = YES;
    
    if(secret)
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:_newsSecretNotification_ object:self];
    }
    
    tabBarItem.badgeView.hidden = !circle && !secret;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
