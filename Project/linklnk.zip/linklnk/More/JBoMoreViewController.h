//
//  KingHeMoreViewController.h
//  微喂
//
//  Created by kinghe005 on 13-8-21.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoTableViewController.h"

/**超级世界
 */
@interface JBoMoreViewController : JBoTableViewController

//超友圈 附近秘密检测
- (void)startNewMsgRemind;
- (void)stopNewMsgRemind;

@end
