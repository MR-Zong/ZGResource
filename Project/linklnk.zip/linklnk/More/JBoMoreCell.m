//
//  JBoMoreCell.m
//  连你
//
//  Created by kinghe005 on 14-1-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMoreCell.h"
#import "JBoBasic.h"

//行高
#define _JBoMoreCellHeight_ 45.0

@implementation JBoMoreCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        CGFloat margin = 15.0;
        CGFloat imageSize = 25.0;
        
        //图标
        _iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(margin, (_JBoMoreCellHeight_ -imageSize) / 2.0, imageSize, imageSize)];
        [self.contentView addSubview:_iconImageView];
        
        UIImage *image = [UIImage imageNamed:@"arrow"];
        //箭头
        UIImageView *arrow = [[UIImageView alloc] initWithFrame:CGRectMake(_width_ - image.size.width - margin, (_JBoMoreCellHeight_ - image.size.height) / 2.0, image.size.width, image.size.height)];
        arrow.image = image;
        [self.contentView addSubview:arrow];
        [arrow release];
        
        //红点
        CGFloat radius = 5.0;
        _point = [[JBoNumberBadge alloc] initWithFrame:CGRectMake(arrow.left - _badgeViewWidth_, (_JBoMoreCellHeight_ - _badgeViewHeight_) / 2.0, _badgeViewWidth_, _badgeViewHeight_)];
        _point.point = YES;
        _point.pointRadius = radius;
        [self.contentView addSubview:_point];
        _point.hidden = YES;
        
        //标题
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_iconImageView.right + margin, 0, _point.left - _iconImageView.right - margin, _JBoMoreCellHeight_)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.font = [UIFont systemFontOfSize:15.0];
        _titleLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_titleLabel];
        
    }
    return self;
}

- (void)dealloc
{
    [_iconImageView release];
    [_titleLabel release];
    [_point release];
    
    [super dealloc];
}

/**行高
 */
+ (CGFloat)rowHeight
{
    return _JBoMoreCellHeight_;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
