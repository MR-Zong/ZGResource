//
//  JBoMoreInfo.h
//  linklnk
//
//  Created by kinghe005 on 15-3-20.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**超级世界字体
 */
#define _JBoMoreFont_ [UIFont boldSystemFontOfSize:16.0]

/**超级世界列表类型
 */
typedef NS_ENUM(NSInteger, JBoMoreInfoType)
{
    JBoMoreInfoTypeImageEdit = 0, ///超图+
    JBoMoreInfoTypeTTS, ///超级语音助手
    JBoMoreInfoTypeMe, ///我
    JBoMoreInfoTypeSetup, ///系统设置
    JBoMoreInfoTypeQRCode, ///扫一扫
};

/**超级世界列表信息
 */
@interface JBoMoreInfo : NSObject

/**图标
 */
@property(nonatomic,retain) UIImage *icon;

/**标题
 */
@property(nonatomic,copy) NSString *title;

/**类型
 */
@property(nonatomic,assign) JBoMoreInfoType type;

/**是否有新消息 default is 'NO'
 */
@property(nonatomic,assign) BOOL hasNewMsg;

/**便利构造方法
 */
+ (id)infoWithIcon:(UIImage*) icon title:(NSString*) title;

/**便利构造方法
 *@param type 类型，会根据类型设置图标和标题
 *@return 一个实例
 */
+ (id)infoWithType:(JBoMoreInfoType) type;

@end
