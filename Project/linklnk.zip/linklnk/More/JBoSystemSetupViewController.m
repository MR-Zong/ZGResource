//
//  JBoSystemSetupViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-5.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSystemSetupViewController.h"
#import "JBoBasic.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoLoginViewController.h"
#import "JBoAppDelegate.h"
#import "JBoNavigatioinBarOperation.h"

@interface JBoSystemSetupViewController ()

@end

@implementation JBoSystemSetupViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _srcArray = [[NSArray alloc] initWithObjects:@"隐私", @"清除图片缓存", @"关于连客", nil];
    }
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoSystemSetupViewController dealloc");
    [_tableView release];
    [super dealloc];
}

- (void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(backAction:)];
    self.view.backgroundColor = [UIColor whiteColor];
	
    CGFloat cellHeight = 40;
    CGFloat tableViewHeight = _srcArray.count * cellHeight >  _height_ - _navgateBarHeight_ - _statuBarHeight_ ?  _height_ - _navgateBarHeight_ - _statuBarHeight_ : _srcArray.count * cellHeight;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, tableViewHeight) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
    
    //退出按钮
    UIImage *exitImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"red_btn@2x" ofType:_imageType_]];
    UIButton *exitButton = [UIButton buttonWithType:UIButtonTypeCustom];
     [exitButton setBackgroundImage:exitImage forState:UIControlStateNormal];
    [exitButton setFrame:CGRectMake(20,_tableView.frame.origin.y + _tableView.frame.size.height + 20,_width_ - 20 * 2, 44)];
    [exitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [exitButton setTitle:@"退出当前账号" forState:UIControlStateNormal];
    [exitButton addTarget:self action:@selector(exitAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:exitButton];
    [exitImage release];
}

- (void)exitAction:(UIButton*) button
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"退出当前账号", nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    JBoInstantMsgInfoOperation *_instantInfoOperation = [[JBoInstantMsgInfoOperation alloc] init];
    [_instantInfoOperation exitAction];
    [_instantInfoOperation release];
    
    JBoLoginViewController *loginVC = [[JBoLoginViewController alloc] init];
    JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
    appDelegate.window.rootViewController = loginVC;
    [loginVC release];
 
    //活动指示器
    JBoDataLoadingView *dataLoadingView = [[JBoDataLoadingView alloc] initWithHeight:140];
    dataLoadingView.hidden = YES;
    [appDelegate.window addSubview:dataLoadingView];
    [appDelegate.dataLoadingView removeFromSuperview];
    appDelegate.dataLoadingView = dataLoadingView;
    [dataLoadingView release];
    
    //消息提示框
    JBoAlertView *alertView = [[JBoAlertView alloc] initWithMessage:@" " height:140];
    alertView.hidden = YES;
    [appDelegate.window addSubview:alertView];
    [appDelegate.alertView removeFromSuperview];
    appDelegate.alertView = alertView;
    [alertView release];
}

//tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentity = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentity];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentity] autorelease];
        UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"arrow@2x" ofType:_imageType_]];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        cell.accessoryView = imageView;
        [imageView release];
        [image release];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    cell.textLabel.text = [_srcArray objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
