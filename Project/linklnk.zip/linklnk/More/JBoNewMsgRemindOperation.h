//
//  JBoNewMsgRemidOperation.h
//  靓咖
//
//  Created by kinghe005 on 14-6-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

#define _lookAndTellCircleRemind_ @"circle"
#define _aroundSecretRemind_ @"secret"

#define _newMsgRemindInterval_ 60 * 5

/**超友圈，附近秘密新信息检测
 */
@interface JBoNewMsgRemindOperation : NSObject

/**检测完成回调
 */
@property(nonatomic,copy) void(^completionHandler)(NSDictionary *dic);

/**开始检测
 */
- (void)start;

/**取消检测
 */
- (void)cancle;

/**保存消息提醒状态
 */
+ (void)setNewMsgRemindState:(NSDictionary*) state;

/**获取消息提醒状态
 */
+ (NSDictionary*)getNewMsgRemindState;

@end
