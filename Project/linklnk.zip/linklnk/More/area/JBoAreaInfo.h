//
//  JBoAreaInfo.h
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**地区信息
 */
@interface JBoAreaInfo : NSObject

/**地区ID
 */
@property(nonatomic,assign) long long areaID;

/**地区名称
 */
@property(nonatomic,copy) NSString *areaName;

/**所属次一级的地区数量
 */
@property(nonatomic,assign) long long childCount;

@end
