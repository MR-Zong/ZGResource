//
//  JBoCityViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoAreaInfo;

/**城市列表
 */
@interface JBoCityViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,XMPPStreamDelegate>
{
    UITableView *_tableView;
}

/**所属省份信息
 */
@property(nonatomic,retain) JBoAreaInfo *provinceInfo;

/**选择地区的根视图
 */
@property(nonatomic,assign) UIViewController *rootViewController;

@end
