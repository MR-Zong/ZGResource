//
//  JBoCityViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoCityViewController.h"
#import "JBoDistrictViewController.h"
#import "JBoAreaInfo.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"

@interface JBoCityViewController ()<JBoHttpRequestDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

/**城市信息，数组元素是JBoAreaInfo对象
 */
@property(nonatomic,retain) NSMutableArray *cityArray;

//是否正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoCityViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark-视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoCityViewController dealloc");
    
    self.rootViewController = nil;
    [_tableView release];
    [_provinceInfo release];
    
    [_httpRequest release];
    [_cityArray release];
    
    [super dealloc];
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取区域信息失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    self.cityArray = [JBoUserOperation getAreaFromData:data];
    
    if(self.cityArray)
    {
        [self loadInitView];
    }
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    //获取城市
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoUserOperation getAreaURLWithPid:self.provinceInfo.areaID]];
  
}

- (void)loadInitView
{
    CGFloat cellHeight = 40;
	_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cityArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoAreaInfo *areaInfo = [self.cityArray objectAtIndex:indexPath.row];
    cell.textLabel.text = areaInfo.areaName;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoAreaInfo *areaInfo = [self.cityArray objectAtIndex:indexPath.row];
    
    if(areaInfo.childCount > 0)
    {
        JBoDistrictViewController *districtVC = [[JBoDistrictViewController alloc] init];
        districtVC.black = self.black;
        districtVC.provinceInfo = self.provinceInfo;
        districtVC.rootViewController = self.rootViewController;
        districtVC.cityInfo = areaInfo;
        districtVC.title = areaInfo.areaName;
        [self.navigationController pushViewController:districtVC animated:YES];
        [districtVC release];
    }
    else
    {
        NSString *area = [NSString stringWithFormat:@"%@%@",self.provinceInfo.areaName, areaInfo.areaName];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:_areaDidSelectedNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:area forKey:_areaInfoKey_]];
        
        for(UIViewController *VC in self.navigationController.viewControllers)
        {
            if([VC isKindOfClass:[self.rootViewController class]])
            {
                [self.navigationController popToViewController:VC animated:YES];
            }
        }
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
