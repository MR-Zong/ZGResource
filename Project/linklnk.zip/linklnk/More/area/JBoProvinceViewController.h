//
//  JBoProvinceViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**省份信息列表
 */
@interface JBoProvinceViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,XMPPStreamDelegate>
{
    UITableView *_tableView;
}

/**选择地区的根视图
 */
@property(nonatomic,assign) UIViewController *rootViewController;

@end
