//
//  JBoAreaInfo.m
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoAreaInfo.h"

@implementation JBoAreaInfo

- (void)dealloc
{
    [_areaName release];
    
    [super dealloc];
}
@end
