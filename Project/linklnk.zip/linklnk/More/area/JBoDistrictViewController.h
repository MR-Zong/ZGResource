//
//  JBoDistrictViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoAreaInfo;

/**街道及区域信息
 */
@interface JBoDistrictViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,XMPPStreamDelegate>
{
    UITableView *_tableView;
}

/**城市信息
 */
@property(nonatomic,retain) JBoAreaInfo *cityInfo;

/**省份信息
 */
@property(nonatomic,retain) JBoAreaInfo *provinceInfo;

/**地区选择的根视图
 */
@property(nonatomic,assign) UIViewController *rootViewController;

@end
