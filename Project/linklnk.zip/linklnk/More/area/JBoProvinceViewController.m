//
//  JBoProvinceViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-17.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoProvinceViewController.h"
#import "JBoCityViewController.h"
#import "JBoAreaInfo.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"

@interface JBoProvinceViewController ()<JBoHttpRequestDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

//地区省份信息，数组元素是 JBoAreaInfo对象
@property(nonatomic,retain) NSMutableArray *provinceArray;

//是否正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoProvinceViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"地区";

        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        self.isRequesting = NO;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoProvinceViewController dealloc");
    
    self.rootViewController = nil;
    [_tableView release];
    
    [_httpRequest release];
     [_provinceArray release];
    
    [super dealloc];
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取区域信息失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    self.provinceArray = [JBoUserOperation getAreaFromData:data];
    if(self.provinceArray)
    {
        [self loadInitView];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //返回按钮
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    //获取省份
    if([_httpRequest downloadWithURL:[JBoUserOperation getAreaURLWithPid:0]])
    {
        self.isRequesting = YES;
    }
}

- (void)loadInitView
{
    CGFloat cellHeight = 40;
	_tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
}

//tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.provinceArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoAreaInfo *areaInfo = [self.provinceArray objectAtIndex:indexPath.row];
    cell.textLabel.text = areaInfo.areaName;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoAreaInfo *areaInfo = [self.provinceArray objectAtIndex:indexPath.row];
    if(areaInfo.childCount > 0)
    {
        JBoCityViewController *cityVC = [[JBoCityViewController alloc] init];
        cityVC.black = self.black;
        cityVC.title = areaInfo.areaName;
        cityVC.rootViewController = self.rootViewController;
        cityVC.provinceInfo = areaInfo;
        [self.navigationController pushViewController:cityVC animated:YES];
        [cityVC release];
    }
    else
    {
        [[NSNotificationCenter defaultCenter] postNotificationName:_areaDidSelectedNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:areaInfo.areaName forKey:_areaInfoKey_]];
        
        [self back];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
