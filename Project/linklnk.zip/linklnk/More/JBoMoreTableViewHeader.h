//
//  JBoMoreTableViewHeader.h
//  linklnk
//
//  Created by kinghe005 on 15-3-20.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoHighlightView.h"


/**超级世界表头 按钮
 */
@interface JBoMoreTableViewHeaderCell : JBoHighlightView

/**图片
 */
@property(nonatomic,readonly) UIImageView *imageView;

/**标题
 */
@property(nonatomic,readonly) UILabel *titleLabel;

/**红点
 */
@property(nonatomic,readonly) UIView *point;

/**构造方法
 *@param image 正常显示的图片
 *@param title 标题
 *@return 一个初始化的 JBoImageTitleView 对象
 */
- (id)initWithFrame:(CGRect)frame image:(UIImage*) image title:(NSString*) title;

@end

@class JBoMoreTableViewHeader;

/**超级世界表头代理
 */
@protocol JBoMoreTableViewHeaderDelegate <NSObject>

/**选择某个图标
 */
- (void)moreTableViewHeader:(JBoMoreTableViewHeader*) header didSelectInfoAtIndex:(NSInteger) index;

@end

/**超级世界表头
 */
@interface JBoMoreTableViewHeader : UIView

/**数据，数组元素是 JBoMoreInfo
 */
@property(nonatomic,readonly) NSArray *infos;

@property(nonatomic,assign) id<JBoMoreTableViewHeaderDelegate> delegate;

/**重新加载数据
 */
- (void)reloadData;

@end
