//
//  JBoMoreTableViewHeader.m
//  linklnk
//
//  Created by kinghe005 on 15-3-20.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoMoreTableViewHeader.h"
#import "JBoMoreInfo.h"
#import "JBoBasic.h"

#define _titleHeight_ 25.0

#define _startTag_ 1000

@implementation JBoMoreTableViewHeaderCell

/**构造方法
 *@param image 正常显示的图片
 *@param title 标题
 *@return 一个初始化的 JBoImageTitleView 对象
 */
- (id)initWithFrame:(CGRect)frame image:(UIImage*) image title:(NSString*) title
{
    self = [super initWithFrame:frame];
    if(self)
    {
        UIFont *font = [UIFont boldSystemFontOfSize:15.0];
        CGFloat contentHeight = image.size.height + MIN(frame.size.height - _titleHeight_, _titleHeight_);
        CGFloat y =(frame.size.height - contentHeight) / 2.0;
        
        self.backgroundColor = [UIColor whiteColor];
        
        _imageView = [[UIImageView alloc] initWithImage:image];
        _imageView.layer.cornerRadius = 5.0;
        _imageView.layer.masksToBounds = YES;
        _imageView.frame = CGRectMake((frame.size.width - image.size.width) / 2, y, image.size.width, image.size.height);
        _imageView.contentMode = UIViewContentModeCenter;
        [self addSubview:_imageView];
        
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, _imageView.bottom, frame.size.width, _titleHeight_)];
        _titleLabel.text = title;
        [_titleLabel setTextAlign:JBoTextAlignmentCenter];
        _titleLabel.font = font;
        [self addSubview:_titleLabel];
        
        CGFloat size = 10.0;
        _point = [[UIView alloc] initWithFrame:CGRectMake(_imageView.right - size / 2.0, _imageView.top - size / 2.0, size, size)];
        _point.layer.cornerRadius = size / 2.0;
        _point.layer.masksToBounds = YES;
        _point.backgroundColor = [UIColor redColor];
        _point.userInteractionEnabled = NO;
        [self addSubview:_point];
    }
    
    return self;
}

- (void)dealloc
{
    [_imageView release];
    [_titleLabel release];
    [_point release];
    
    [super dealloc];
}

@end

@implementation JBoMoreTableViewHeader

- (id)init
{
    CGFloat height = _titleHeight_ + 75.0;
    self = [super initWithFrame:CGRectMake(0, 0, _width_, height)];
    if(self)
    {
        //分割线
        CGFloat separatorHeight = 18.0;
        
        self.backgroundColor = [UIColor clearColor];
        _infos = [[NSArray alloc ] initWithObjects:
                  [JBoMoreInfo infoWithIcon:[UIImage imageNamed:@"more_friend"] title:@"超友圈"],
                  [JBoMoreInfo infoWithIcon:[UIImage imageNamed:@"more_secret"] title:[NSString stringWithFormat:@"附近%@", _helpName_]],
                  [JBoMoreInfo infoWithIcon:[UIImage imageNamed:@"more_openPlatform"] title:@"云名片"],
                  nil];
        
        CGFloat width = _width_ / _infos.count;
        for(NSInteger i = 0;i < _infos.count;i ++)
        {
            JBoMoreInfo *info = [_infos objectAtIndex:i];
            JBoMoreTableViewHeaderCell *cell = [[JBoMoreTableViewHeaderCell alloc] initWithFrame:CGRectMake(i * width, 0, width, height - separatorHeight) image:info.icon title:info.title];
            cell.point.hidden = !info.hasNewMsg;
            cell.tag = i + _startTag_;
            [cell addTarget:self action:@selector(cellDidSelect:)];
            [self addSubview:cell];
            [cell release];
        }
        
        //分割线
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, height - separatorHeight, _width_, _defaultSeparatorLineSize_)];
        line.backgroundColor = _defaultSeparatorLineColor_;
        [self addSubview:line];
        [line release];
    }
    
    return self;
}

- (void)dealloc
{
    [_infos release];
    self.delegate = nil;
    
    [super dealloc];
}

#pragma mark- public method

/**重新加载数据
 */
- (void)reloadData
{
    for(NSInteger i = 0;i < _infos.count;i ++)
    {
        JBoMoreInfo *info = [_infos objectAtIndex:i];
        JBoMoreTableViewHeaderCell *cell = (JBoMoreTableViewHeaderCell*)[self viewWithTag:_startTag_ + i];
        cell.imageView.image = info.icon;
        cell.titleLabel.text = info.title;
        cell.point.hidden = !info.hasNewMsg;
    }
}

#pragma mark- private method

//选择
- (void)cellDidSelect:(JBoMoreTableViewHeaderCell*) cell
{
    NSInteger index = cell.tag - _startTag_;
    if([self.delegate respondsToSelector:@selector(moreTableViewHeader:didSelectInfoAtIndex:)])
    {
        [self.delegate moreTableViewHeader:self didSelectInfoAtIndex:index];
    }
}

@end
