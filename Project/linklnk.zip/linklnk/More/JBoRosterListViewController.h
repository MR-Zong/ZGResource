//
//  JBoRosterListViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-5.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"
#import "JBoRosterInfo.h"
#import "JBoRosterInfoDelegate.h"

#define _sosContactSelectedNotification_ @"sosContactSelectedNotification"
//好友选择完成
#define _didSelectedContactNotification_ @"didSelectedContactNotification"
#define _selectedRosterInfo_ @"selectedRosterInfo"

@class JBoLettersSearchBar;

/**好友列表
 */
@interface JBoRosterListViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIScrollViewDelegate>
{
    NSMutableArray *_keywordArray;
    NSMutableDictionary *_rosterDic;
    
    UITableView *_tableView;
    JBoLettersSearchBar *_lettersView;
    UISearchBar *_searchBar;
    
    //黑色半透明视图
    UIView *_transparentView;
    
    //搜索栏搜索结果
    NSMutableArray *_searchResultArray;
}

/**对用户信息的操作类型
 */
@property(nonatomic,assign) JBoRosterOperationType rosterOprationType;
@property(nonatomic,assign) id<JBoRosterInfoDelegate> delegate;

@end
