//
//  JBoSystemOperation.h
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

/**封装了关于系统设置内的 一些设置方法和网络请求
 */
@interface JBoSystemOperation : NSObject

#pragma mark- 消息提醒

//获取系统配置文件
+ (NSMutableDictionary*) systemSetup;

/**设置消息是否推送
 */
+ (void)setPushAlert:(BOOL) alert;

/**设置消息是否有声音提醒
 */
+ (void)setPushSound:(BOOL) pushSound;

/**设置手机是否震动
 */
+ (void)setShake:(BOOL) shake;

/**清理所有聊天记录缓存
 */
+ (BOOL)clearCache;

/**获取关于靓咖数据
 */
+ (NSString*)getAboutLinklnk;
+ (NSDictionary*)getAboutLinklnkFromData:(NSData*) data;

/**注册推送
 */
+ (void)registerRemoteNotification;

/**取消注册推送
 */
+ (void)unRegisterRemoteNotification;

#pragma mark- 耳机检查

/**开始耳机检测
 */
+ (void)beginHeadSetListener;

/**是否插入耳机
 */
+ (BOOL)isHeadphone;

/**设置听筒和扬声器
 */
+ (void)setupAudio;

#pragma mark- 靓友圈、附近秘密更新提示

/**获取附近秘密 靓友圈 最后访问时间
 *@return  get请求url
 */
+ (NSString*)getLastRequestTime;

/**从返回数据获取 附近秘密 靓友圈 最后访问时间
 *@param data 返回数据
 *@return 一个字典，里面包含 附近秘密 靓友圈 最后访问时间
 */
+ (NSDictionary*)getLastRequestTimeFromData:(NSData*) data;

/**获取靓友圈数据的最新时间
 *@return get请求url
 */
+ (NSString*)getLookAndTellCircleLastestTime;

/**从返回数据获取靓友圈数据的最新时间
 *@param data 返回数据
 *@return 靓友圈最新时间 格式为 2014-08-08 09:23:34
 */
+ (NSString*)getLookAndTellCircleLastestTimeFromData:(NSData*) data;

/**获取附近秘密数据最新时间
 *@param coordinate 要获取附近秘密的坐标 
 *@param radius 范围 
 *@return get 请求url
 */
+ (NSString*)getAroundSecretLastestTimeWithCoordinate:(CLLocationCoordinate2D) coordinate radius:(int) radius;

/**从返回的数据获取附近秘密数据最新时间
 *@param data 返回的数据
 *@return 附近秘密最新时间 格式为 2014-08-08 09:23:34
 */
+ (NSString*)getAroundSecretLastestTimeFromData:(NSData*) data;

@end
