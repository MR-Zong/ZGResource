//
//  JBoCustomSwitch.m
//  连你
//
//  Created by kinghe005 on 14-1-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCustomSwitch.h"
#import <AVFoundation/AVFoundation.h>

@interface JBoCustomSwitch ()

@property (nonatomic) CGFloat cornerRadius;

@property (nonatomic, retain) CAGradientLayer *frontGradientLayer;

@property (nonatomic, retain) CAGradientLayer *backGradientLayer;

@end

@implementation JBoCustomSwitch

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.onColorLight = [UIColor whiteColor];
        self.onColorDark = [UIColor colorWithRed:37.0 / 255.0 green:172.0 /255.0 blue:1.0 / 255.0 alpha:1.0];
        self.offColor = [UIColor colorWithRed:62.0 / 255.0 green:215.0 / 255.0 blue:21.0 / 255.0 alpha:1.0];
        
        self.cornerRadius = (frame.size.height / 2.0f);
        
        self.layer.backgroundColor = [self.offColor CGColor];
        
        if (!self.frontButton) {
            _frontButton = [self buttonWithCameraPosition:AVCaptureDevicePositionFront];
        }
        
        if (!self.backButton) {
            _backButton = [self buttonWithCameraPosition:AVCaptureDevicePositionBack];
        }
    }
    return self;
}

- (void)dealloc
{
    [_offColor release];
    [_onColorDark release];
    [_onColorLight release];
    
    [_frontGradientLayer release];
    [_backGradientLayer release];
    
    [super dealloc];
}

- (void)clicked:(UIButton *)sender shouldResetTheOtherButton:(BOOL)shouldReset
{
    if(sender == self.frontButton)
    {
        NSLog(@"front");
    }
    else
    {
        NSLog(@"back");
    }
    [UIView animateWithDuration:0.3 animations:^{
        if (CATransform3DEqualToTransform(sender.layer.transform, CATransform3DIdentity)) {
            if (sender == self.frontButton) {
                sender.layer.transform = [self transformWithCameraPosition:AVCaptureDevicePositionFront];
            } else if (sender == self.backButton) {
                sender.layer.transform = [self transformWithCameraPosition:AVCaptureDevicePositionBack];
            }
            if (sender == self.backButton) {
                [self.backButton.layer insertSublayer:self.backGradientLayer below:self.backButton.imageView.layer];
            } else if (sender == self.frontButton) {
                [self.frontButton.layer insertSublayer:self.frontGradientLayer below:self.frontButton.imageView.layer];
            }
        } else {
            if (sender == self.backButton) {
                [self.backGradientLayer removeFromSuperlayer];
            } else if (sender == self.frontButton) {
                [self.frontGradientLayer removeFromSuperlayer];
            }
            sender.layer.transform = CATransform3DIdentity;
        }
    }];
    
    if (shouldReset) {
        [self clicked:(self.frontButton == sender ? self.backButton : self.frontButton) shouldResetTheOtherButton:NO];
    }
}

- (void)setOn:(BOOL)on
{
    _on = on;
    if(_on)
    {
        [self clicked:self.backButton shouldResetTheOtherButton:NO];
    }
    else
    {
        [self clicked:self.frontButton shouldResetTheOtherButton:NO];
    }
}

- (void)clicked:(UIButton *)sender
{
    [self clicked:sender shouldResetTheOtherButton:YES];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(clicked:)]) {
        BOOL isFront = NO;
        if ((CATransform3DEqualToTransform(sender.layer.transform, CATransform3DIdentity) && sender == self.backButton) || (!CATransform3DEqualToTransform(sender.layer.transform, CATransform3DIdentity) && sender == self.frontButton)) {
            isFront = YES;
        }
        [self.delegate clicked:isFront];
    }
}

- (CATransform3D)transformWithCameraPosition:(AVCaptureDevicePosition)cameraPosition
{
    CATransform3D transform = CATransform3DIdentity;
    if (cameraPosition == AVCaptureDevicePositionFront) {
        // Spin
        transform.m34 = 1.0 / -200.0;
    } else if (cameraPosition == AVCaptureDevicePositionBack) {
        // Spin
        transform.m34 = 1.0 / 200.0;
    }
    // Rotate
    transform = CATransform3DRotate(transform, M_PI_4/2.5, 0.0, 1.0, 0.0);
    // Scale
    transform = CATransform3DScale(transform, 0.9, 1, 1);
    return transform;
}

- (CAGradientLayer *)gradientLayerWithBounds:(CGRect)bounds
{
    CAGradientLayer *gradientLayer = [CAGradientLayer layer];
    gradientLayer.frame = bounds;
    gradientLayer.colors = [NSArray arrayWithObjects:
                            (id)[self.onColorLight CGColor],
                            (id)[self.onColorDark CGColor],
                            nil];
    return gradientLayer;
}

- (CAShapeLayer *)maskLayerWithCameraPosition:(AVCaptureDevicePosition)cameraPosition bounds:(CGRect)bounds
{
    UIBezierPath *maskPath = nil;
    if (cameraPosition == AVCaptureDevicePositionFront) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:bounds byRoundingCorners:(UIRectCornerTopLeft | UIRectCornerBottomLeft) cornerRadii:CGSizeMake(self.cornerRadius, self.cornerRadius)];
    } else if (cameraPosition == AVCaptureDevicePositionBack) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:bounds byRoundingCorners:(UIRectCornerTopRight | UIRectCornerBottomRight) cornerRadii:CGSizeMake(self.cornerRadius, self.cornerRadius)];
    }
    
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    maskLayer.path = maskPath.CGPath;
    
    return [maskLayer autorelease];
}

- (UIButton *)buttonWithCameraPosition:(AVCaptureDevicePosition)cameraPosition
{
    if (cameraPosition != AVCaptureDevicePositionBack) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [button addTarget:self action:@selector(clicked:) forControlEvents:UIControlEventTouchUpInside];
        
        if (cameraPosition == AVCaptureDevicePositionFront) {
            button.layer.anchorPoint = CGPointMake(1, 0.5);
            button.frame = CGRectMake(0, 0, (self.bounds.size.width / 2.0f), self.bounds.size.height);
            //[button setImage:[UIImage imageNamed:@"front"] forState:UIControlStateNormal];
        } else if (cameraPosition == AVCaptureDevicePositionBack) {
            button.layer.anchorPoint = CGPointMake(0, 0.5);
            button.frame = CGRectMake((self.bounds.size.width / 2.0f), 0, (self.bounds.size.width / 2.0f), self.bounds.size.height);
            //[button setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        }
        
        button.layer.mask = [self maskLayerWithCameraPosition:cameraPosition bounds:button.bounds];
        button.layer.transform = [self transformWithCameraPosition:cameraPosition];
        [button.layer insertSublayer:[self gradientLayerWithBounds:button.bounds] below:button.imageView.layer];
        
        if (cameraPosition == AVCaptureDevicePositionFront) {
            self.frontGradientLayer = button.layer.sublayers[0];
            self.frontGradientLayer.startPoint = CGPointMake(0, 0);
            self.frontGradientLayer.endPoint = CGPointMake(1, 0);
        } else if (cameraPosition == AVCaptureDevicePositionBack) {
            self.backGradientLayer = button.layer.sublayers[0];
            self.backGradientLayer.startPoint = CGPointMake(1, 0);
            self.backGradientLayer.endPoint = CGPointMake(0, 0);
        }
        [self addSubview:button];
        
        return button;
    }
    return nil;
}

- (void)setCornerRadius:(CGFloat)cornerRadius
{
    if (_cornerRadius == cornerRadius) {
        return;
    }
    
    _cornerRadius = cornerRadius;
    self.layer.cornerRadius = _cornerRadius;
}

- (void)setOnColorLight:(UIColor *)onColorLight
{
    if(_onColorLight != onColorLight)
    {
        [_onColorLight release];
        _onColorLight = [onColorLight retain];
        
        if (self.frontGradientLayer) {
            self.frontGradientLayer.colors = [NSArray arrayWithObjects:
                                              (id)[onColorLight CGColor],
                                              (id)[self.onColorDark CGColor],
                                              nil];
        }
        
        if (self.backGradientLayer) {
            self.backGradientLayer.colors = [NSArray arrayWithObjects:
                                             (id)[onColorLight CGColor],
                                             (id)[self.onColorDark CGColor],
                                             nil];
        }
    }
}

- (void)setOnColorDark:(UIColor *)onColorDark
{
    if(_onColorDark != onColorDark)
    {
        [_onColorDark release];
        _onColorDark = [onColorDark retain];
        
        if (self.frontGradientLayer) {
            self.frontGradientLayer.colors = [NSArray arrayWithObjects:
                                              (id)[self.onColorLight CGColor],
                                              (id)[onColorDark CGColor],
                                              nil];
        }
        
        if (self.backGradientLayer) {
            self.backGradientLayer.colors = [NSArray arrayWithObjects:
                                             (id)[self.onColorLight CGColor],
                                             (id)[onColorDark CGColor],
                                             nil];
        }
    }
}

- (void)setOffColor:(UIColor *)offColor
{
    if(_offColor != offColor)
    {
        [_offColor release];
        _offColor = [offColor retain];
        self.layer.backgroundColor = [offColor CGColor];
        self.backButton.layer.backgroundColor = [offColor CGColor];
    }
}

- (void)setDelegate:(id<JBoCustomSwitchDelegate>)delegate
{
    _delegate = delegate;
    
    // Front is selected by default, when set delegate in controller, we send the default selection.
//    if (_delegate && [_delegate respondsToSelector:@selector(clicked:)]) {
//        [_delegate clicked:YES];
//    }
}

@end
