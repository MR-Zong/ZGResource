//
//  JBoBlackListCell.m
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoBlackListCell.h"
#import "JBoBasic.h"

#define _labelHeight_ 30
#define _nameLabelWidth_ 100
#define _controlInterval_ 5

@implementation JBoBlackListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_rosterCellInteval_, _rosterCellInteval_, _rosterCellHeight_ - _rosterCellInteval_ * 2, _rosterCellHeight_ - _rosterCellInteval_ * 2)];
        _headImageView.userInteractionEnabled = YES;
        [self.contentView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _rosterCellInteval_, (_rosterCellHeight_ - _labelHeight_) / 2, _nameLabelWidth_, _labelHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat buttonWidth = 100;
        CGFloat buttonHeihgt = 35;
        
        UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"gray_btn@2x" ofType:_imageType_]];
        _deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_deleteButton setTitle:@"移出" forState:UIControlStateNormal];
        [_deleteButton addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];
        [_deleteButton setBackgroundImage:image forState:UIControlStateNormal];
        [_deleteButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        [_deleteButton setFrame:CGRectMake(_width_ - buttonWidth - _rosterCellInteval_, _headImageView.frame.origin.y + (_headImageView.frame.size.height - buttonHeihgt) / 2, buttonWidth, buttonHeihgt)];
        [self.contentView addSubview:_deleteButton];
        [image release];
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [super dealloc];
}

- (void)deleteAction:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(blackListCell:didDeleteAtIndex:)])
    {
        [self.delegate blackListCell:self didDeleteAtIndex:self.index];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
