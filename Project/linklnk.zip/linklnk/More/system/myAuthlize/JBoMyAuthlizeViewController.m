//
//  JBoMyAuthlizeViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMyAuthlizeViewController.h"
#import "JBoAuthListViewController.h"
#import "JBoBlackListViewController.h"

#define _startTag_ 1000

@interface JBoMyAuthlizeViewController ()

@end

@implementation JBoMyAuthlizeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"我的授权";
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    [_srcArray release];
    [_tableView release];
    
    [super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
    [appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:250.0 / 255.0 green:250.0 / 255.0 blue:250.0 / 255.0 alpha:1.0];
    //自己定义返回按钮
    self.backItem = YES;
    
    _srcArray = [[NSArray alloc] initWithObjects:[NSString stringWithFormat:@"指定好友无法看我的%@", _lookAndTellName_], [NSString stringWithFormat:@"不看指定好友的%@", _lookAndTellName_], @"黑名单列表", nil];
    
    CGFloat topPadding = 20;
    CGFloat rightPadding = 10;
    CGFloat arrowPadding = 40;
    CGFloat controlHeight = 50;
    
    UIImage *bgImage1 = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"auth1@2x" ofType:_imageType_]];
    UIImageView *bgImageView1 = [[UIImageView alloc] initWithFrame:CGRectMake((_width_ - bgImage1.size.width) / 2, topPadding, bgImage1.size.width, bgImage1.size.height)];
    bgImageView1.userInteractionEnabled = YES;
    bgImageView1.image = bgImage1;
    [self.view addSubview:bgImageView1];
    [bgImageView1 release];
    [bgImage1 release];
    
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    UILabel *contactLabel1 = [[UILabel alloc] initWithFrame:CGRectMake(rightPadding, 0, bgImage1.size.width - arrowPadding, controlHeight)];
    contactLabel1.text = [_srcArray objectAtIndex:0];
    contactLabel1.backgroundColor = [UIColor clearColor];
    contactLabel1.userInteractionEnabled = YES;
    contactLabel1.tag = _startTag_;
    [contactLabel1 addGestureRecognizer:tap1];
    [bgImageView1 addSubview:contactLabel1];
    [tap1 release];
    [contactLabel1 release];
    
    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    UILabel *contactLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(rightPadding, controlHeight - 5, bgImage1.size.width - arrowPadding, controlHeight)];
    contactLabel2.text = [_srcArray objectAtIndex:1];
    contactLabel2.userInteractionEnabled = YES;
    contactLabel2.tag = _startTag_ + 1;
    contactLabel2.backgroundColor = [UIColor clearColor];
    [contactLabel2 addGestureRecognizer:tap2];
    [bgImageView1 addSubview:contactLabel2];
    [tap2 release];
    [contactLabel2 release];
    
//    UIImage *bgImage2 = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"auth2@2x" ofType:_imageType_]];
//    UIImageView *bgImageView2 = [[UIImageView alloc] initWithFrame:CGRectMake((_width_ - bgImage1.size.width) / 2, topPadding + bgImageView1.frame.size.height + bgImageView1.frame.origin.y, bgImage2.size.width, bgImage2.size.height)];
//    bgImageView2.userInteractionEnabled = YES;
//    bgImageView2.image = bgImage2;
//    [self.view addSubview:bgImageView2];
//    [bgImageView2 release];
//    [bgImage2 release];
//    
//    UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
//    UILabel *contactLabel3 = [[UILabel alloc] initWithFrame:CGRectMake(rightPadding, 0, bgImage2.size.width - arrowPadding, controlHeight)];
//    contactLabel3.text = [_srcArray objectAtIndex:2];
//    contactLabel3.userInteractionEnabled = YES;
//    contactLabel3.tag = _startTag_ + 2;
//    [contactLabel3 addGestureRecognizer:tap3];
//    [bgImageView2 addSubview:contactLabel3];
//    [tap3 release];
//    [contactLabel3 release];
    
    UIImage *bgImage3 = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"auth3@2x" ofType:_imageType_]];
    UIImageView *bgImageView3 = [[UIImageView alloc] initWithFrame:CGRectMake((_width_ - bgImage1.size.width) / 2, topPadding + bgImageView1.frame.size.height + bgImageView1.frame.origin.y, bgImage3.size.width, bgImage3.size.height)];
    bgImageView3.userInteractionEnabled = YES;
    bgImageView3.image = bgImage3;
    [self.view addSubview:bgImageView3];
    [bgImageView3 release];
    [bgImage3 release];
    
    UITapGestureRecognizer *tap4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    UILabel *contactLabel4 = [[UILabel alloc] initWithFrame:CGRectMake(rightPadding, 0, bgImage3.size.width - arrowPadding, controlHeight)];
    contactLabel4.text = [_srcArray objectAtIndex:2];
    contactLabel4.userInteractionEnabled = YES;
    contactLabel4.tag = _startTag_ + 2;
    [contactLabel4 addGestureRecognizer:tap4];
    contactLabel4.backgroundColor = [UIColor clearColor];
    [bgImageView3 addSubview:contactLabel4];
    [tap4 release];
    [contactLabel4 release];
    
//    UITapGestureRecognizer *tap5 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
//    UILabel *contactLabel5 = [[UILabel alloc] initWithFrame:CGRectMake(rightPadding, controlHeight, bgImage3.size.width - arrowPadding, controlHeight)];
//    contactLabel5.text = [_srcArray objectAtIndex:3];
//    contactLabel5.userInteractionEnabled = YES;
//    contactLabel5.tag = _startTag_ + 3;
//    [contactLabel5 addGestureRecognizer:tap5];
//    [bgImageView3 addSubview:contactLabel5];
//    [tap5 release];
//    [contactLabel5 release];
    
//    UIImage *bgImage4 = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"auth4@2x" ofType:_imageType_]];
//    UIImageView *bgImageView4 = [[UIImageView alloc] initWithFrame:CGRectMake((_width_ - bgImage1.size.width) / 2, topPadding + bgImageView3.frame.size.height + bgImageView3.frame.origin.y, bgImage4.size.width, bgImage4.size.height)];
//    bgImageView4.userInteractionEnabled = YES;
//    bgImageView4.image = bgImage4;
//    [self.view addSubview:bgImageView4];
//    [bgImageView4 release];
//    [bgImage4 release];
//    
//    UITapGestureRecognizer *tap6 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
//    UILabel *contactLabel6 = [[UILabel alloc] initWithFrame:CGRectMake(rightPadding, 0, bgImage4.size.width - arrowPadding, controlHeight)];
//    contactLabel6.text = [_srcArray objectAtIndex:5];
//    contactLabel6.userInteractionEnabled = YES;
//    contactLabel6.tag = _startTag_ + 5;
//    [contactLabel6 addGestureRecognizer:tap6];
//    [bgImageView4 addSubview:contactLabel6];
//    [tap6 release];
//    [contactLabel6 release];
}

- (void)tapAction:(UITapGestureRecognizer*) tap
{
    NSInteger tag = tap.view.tag - _startTag_;
    JBoAuthlizeType type = NSNotFound;
    NSString *title = [_srcArray objectAtIndex:tag];
    switch (tag)
    {
        case 0 :
            type = JBoAuthlizeTypeDisableSeeLookAndTell;
            break;
        case 1 :
            type = JBoAuthlizeTypeNotSeeLookAndTell;
            break;
//        case 2 :
//            type = JBoAuthlizeTypeEnableSeeLocation;
//            break;
        case 2 :
            type = JBoAuthlizeTypeBlackList;
            break;
        default:
            break;
    }
    
    
    if(type != JBoAuthlizeTypeBlackList)
    {
        JBoAuthListViewController *authVC = [[JBoAuthListViewController alloc] init];
        authVC.authLizeType = type;
        authVC.title = title;
        [self.navigationController pushViewController:authVC animated:YES];
        [authVC release];
    }
    else
    {
        JBoBlackListViewController *blackListVC = [[JBoBlackListViewController alloc] init];
        [self.navigationController pushViewController:blackListVC animated:YES];
        [blackListVC release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
