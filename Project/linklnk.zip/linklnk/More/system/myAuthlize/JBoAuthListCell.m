//
//  JBoAuthListCell.m
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAuthListCell.h"
#import "JBoBasic.h"

#define _labelHeight_ 30
#define _nameLabelWidth_ 100
#define _controlInterval_ 5

@implementation JBoAuthListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_authCellInteval_, _authCellInteval_, _authCellHeight_ - _authCellInteval_ * 2, _authCellHeight_ - _authCellInteval_ * 2)];
        _headImageView.userInteractionEnabled = YES;
        [self.contentView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _authCellInteval_, (_authCellHeight_ - _labelHeight_) / 2, _nameLabelWidth_, _labelHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        UIImage *normalImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"goodsUnselected@2x" ofType:_imageType_]];
        UIImage *selectedImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"goodsSelected@2x" ofType:_imageType_]];
        
        _checkBox = [[JBoCheckBox alloc] initWithFrame:CGRectMake(_width_ - 50, _authCellHeight_ - _selectedCheckBoxSize_ - 10.0, _selectedCheckBoxSize_, _selectedCheckBoxSize_) style:CheckBoxStyleDefault selectedImage:selectedImage unselectedImage:normalImage];
        _checkBox.delegate = self;
        [self.contentView addSubview:_checkBox];
        [normalImage release];
        [selectedImage release];
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_checkBox release];
    
    [super dealloc];
}

- (void)checkBoxStyleDidChanged:(JBoCheckBox *)checkBox
{
    if([self.delegate respondsToSelector:@selector(authListCell:didSelectedAtIndex:)])
    {
        [self.delegate authListCell:self didSelectedAtIndex:self.index];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
