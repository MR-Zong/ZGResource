//
//  JBoBlackListViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**黑名单信息列表
 */
@interface JBoBlackListViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
}

@end
