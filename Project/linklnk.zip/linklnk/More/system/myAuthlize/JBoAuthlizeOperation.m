//
//  JBoAuthlizeOperation.m
//  连你
//
//  Created by kinghe005 on 14-2-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAuthlizeOperation.h"
#import "JBoUserOperation.h"
#import "JBoBasic.h"
#import "JSONKit.h"

@implementation JBoAuthlizeOperation

#pragma mark-靓友圈授权

/**设置靓友圈信息授权
 *@param targetId 要授权的用户
 *@param status YES 是未设置权限，NO 已设置权限
 *@param index 授权标识，0 指定好友无法查看我的靓友圈，1不看他（她）的靓友圈
 *@return get请求url
 */
+ (NSString*)getLookAndTellAuthWithTargetId:(NSString*) targetId status:(BOOL) status index:(int) index
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%d&%@=%d", _setupLookAndTellAuthlize_, _userId_, [JBoUserOperation getUserId], _lookAndTellTargetId_, targetId, _lookAndTellAuthStatus_, status, _lookAndTellAuthIndex_, index];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    NSLog(@"%@",url);
    return url;
}

/**获取他（她）无法查看我的靓友圈用户列表
 *@param get请求url
 */
+ (NSString*)getTheyCannotSeeMyLookAndTellAuthList
{
    NSString *url = [NSString stringWithFormat:_getTheyCannotSeeMyLookAndTellAuthList_, [JBoUserOperation getUserId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回数据获取他（她）无法查看我的靓友圈用户列表
 *@param data 返回数据
 *@return 数组元素是 NSString 对象，用户userId
 */
+ (NSArray*)getTheyCannotSeeMyLookAndTellAuthListFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *resultArray = [dic arrayForKey:_data_];
        return resultArray;
    }
    else
    {
        return nil;
    }
}

/**获取不看他（她）的靓友圈 授权用户列表
 *@return get请求url
 */
+ (NSString*)getNotSeeTheirLookAndTellAuthList
{
    NSString *url = [NSString stringWithFormat:_getNotSeeTheirLookAndTellAuthList_, [JBoUserOperation getUserId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回数据获取 不看他（她）的靓友圈 授权用户列表
 *@param data 返回数据
 *@return 数组元素是 NSString 对象，用户userId
 */
+ (NSArray*)getNotSeeTheirLookAndTellAuthListFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *resultArray = [dic arrayForKey:_data_];
        return resultArray;
    }
    else
    {
        return nil;
    }
}

#pragma mark-地理位置信息授权

//地理位置信息授权
+ (NSString*)getLocationAuthTargetId:(NSString *)targetId status:(BOOL)status
{
    NSString *url = [NSString stringWithFormat:_setupLocationAuthlize_, [JBoUserOperation getUserId], targetId, !status];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

//已授权可查看我的位置列表
+ (NSString*)getLocationAuthList
{
    NSString *url = [NSString stringWithFormat:_getLocationAuthList_, [JBoUserOperation getUserId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

+ (NSArray*)getLocationAuthListFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@", [[dic objectForKey:_result_] objectForKey:_msg_]);
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *resultArray = [dic objectForKey:_data_];
        return resultArray;
    }
    else
    {
        return nil;
    }
}

/**查看某个用户的所有授权状态
 *@param targetId 要查看的对象
 *@return get请求url
 */
+ (NSString*)getUserALlAuth:(NSString *)targetId
{
    NSString *url = [NSString stringWithFormat:_getUserAllAuth_, [JBoUserOperation getUserId], targetId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回数据 获取用户的所有授权状态
 *@param data 返回数据
 *@return 一个字典 授权状态
 */
+ (NSMutableDictionary*)getUserAllAuthFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dataDic = [dic dictionaryForKey:_data_];
        NSMutableDictionary *retDic = [NSMutableDictionary dictionaryWithCapacity:dataDic.count];
        [retDic addEntriesFromDictionary:dataDic];
        
        return retDic;
    }
    else
    {
        return nil;
    }
    
}

@end
