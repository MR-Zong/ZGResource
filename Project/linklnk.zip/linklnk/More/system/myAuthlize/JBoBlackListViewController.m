//
//  JBoBlackListViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoBlackListViewController.h"
#import "JBoBlackListCell.h"
#import "JBoUserOperation.h"
#import "JBoHttpRequest.h"
#import "JBoImageTextTool.h"
#import "JBoSearchContactForAddViewController.h"
#import "JBoAddressBookOperation.h"

@interface JBoBlackListViewController ()<JBoBlackListCellDelegate,JBoHttpRequestDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

//黑名单信息列表 数组元素是JBoRosterInfo对象
@property(nonatomic,retain) NSMutableArray *blackListArray;

//是否正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

//选中的cell
@property(nonatomic,assign) NSInteger currentIndex;

@end

@implementation JBoBlackListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"黑名单";
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_blackListArray release];
    [_tableView release];
    
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getBlackListIdentifier_])
    {
        [self alertNetworkMsg:@"获取黑名单列表失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeBlackListIdentifier_])
    {
        [self alertNetworkMsg:@"移出黑名单失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getBlackListIdentifier_])
    {
        self.blackListArray = [JBoUserOperation getBlackListFromData:data];
        if(self.blackListArray.count > 0)
        {
            [self loadInitView];
        }
        else
        {
            [JBoUserOperation alertMsg:@"黑名单是空的"];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeBlackListIdentifier_])
    {
        BOOL success = NO;
        JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getRemoveBlackListFromData:data removeSuccess:&success];
        if(success)
        {
            NSLog(@"%@",userDetailInfo);
            if(userDetailInfo)
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:_addressBookUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], _addressBookUpdateIsFriend_, userDetailInfo.rosterInfo, _addressBookUpdateRosterInfo_, [NSNumber numberWithInteger:JBoContactMoreOperationTypeRemoveBlacklist], _addressBookUpdateType_, nil]];
            }
            if(self.currentIndex < self.blackListArray.count)
            {
                JBoRosterInfo *info = [self.blackListArray objectAtIndex:self.currentIndex];
                JBoAddressBookOperation *operation = [[JBoAddressBookOperation alloc] init];
                [operation removeOneBlackListWithUserId:info.username];
                [operation release];
                
                [self.appDelegate.blackListArray removeObject:info.username];
                [self.blackListArray removeObjectAtIndex:self.currentIndex];
                
                [_tableView beginUpdates];
                [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.currentIndex inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
                [_tableView endUpdates];
            }
        }
        return;
    }
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    _httpRequest.identifier = _getBlackListIdentifier_;
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoUserOperation getBlackListURL]];
}

- (void)loadInitView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorColor = [UIColor grayColor];
    _tableView.rowHeight = _rosterCellHeight_;
    [self.view addSubview:_tableView];
    
    [_tableView setExtraCellLineHidden];
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.blackListArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    JBoBlackListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoBlackListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoRosterInfo *rosterInfo = [self.blackListArray objectAtIndex:indexPath.row];
    
    cell.nameLabel.text = rosterInfo.name;
    cell.nameLabel.sex = rosterInfo.sex;
    cell.index = indexPath.row;
    cell.headImageView.role = rosterInfo.role;
    cell.headImageView.sex = rosterInfo.sex;
    cell.headImageView.headImageURL = rosterInfo.imageURL;
   
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    JBoRosterInfo *rosterInfo = [self.blackListArray objectAtIndex:indexPath.row];
//    JBoSearchContactForAddViewController *contactVC = [[JBoSearchContactForAddViewController alloc] init];
//    contactVC.userId = rosterInfo.username;
//    [self.navigationController pushViewController:contactVC animated:YES];
//    [contactVC release];
}

#pragma mark-JBoBlackListCell代理

- (void)blackListCell:(JBoBlackListCell *)cell didDeleteAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    self.currentIndex = indexPath.row;
    if(self.currentIndex >= self.blackListArray.count)
        return;
    JBoRosterInfo *info = [self.blackListArray objectAtIndex:self.currentIndex];
    _httpRequest.identifier = _removeBlackListIdentifier_;
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoUserOperation getRemoveBlackListURl:info.username]];

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
