//
//  JBoAuthListViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoLettersSearchBar;

/**靓友圈授权信息 列表
 */
@interface JBoAuthListViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UIScrollViewDelegate>
{
    NSMutableArray *_keywordArray;
    NSMutableDictionary *_rosterDic;
    
    UITableView *_tableView;
    JBoLettersSearchBar *_lettersView;
    UISearchBar *_searchBar;
    
    //黑色半透明视图
    UIView *_transparentView;
    
    //搜索栏搜索结果
    NSMutableArray *_searchResultArray;
}

/**授权类型
 */
@property(nonatomic,assign) JBoAuthlizeType authLizeType;

@end
