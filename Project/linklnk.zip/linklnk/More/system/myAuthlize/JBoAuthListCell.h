//
//  JBoAuthListCell.h
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoCheckBox.h"

#define _authCellHeight_ 60
#define _authCellInteval_ 10

@class JBoAuthListCell;

@protocol JBoAuthListCellDelegate <NSObject>

- (void)authListCell:(JBoAuthListCell*) cell didSelectedAtIndex:(NSInteger) index;

@end

/**我的授权 用户授权设置 cell
 */
@interface JBoAuthListCell : UITableViewCell<JBoCheckBoxDelegate>

//头像和名称 性别
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

@property(nonatomic,readonly) JBoCheckBox *checkBox;
@property(nonatomic,assign) NSInteger index;

@property(nonatomic,assign) id<JBoAuthListCellDelegate> delegate;

@end
