//
//  JBoAuthListViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAuthListViewController.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoContactListViewController.h"
#import "JBoCustomTabBarController.h"
#import "JBoAuthListCell.h"
#import "JBoRosterInfo.h"
#import "JBoLettersSearchBar.h"
#import "ChineseToPinyin.h"
#import "UITableView+extraCellLine.h"
#import "JBoRosterCell.h"
#import "JBoHttpRequest.h"
#import "JBoAuthlizeOperation.h"
#import "JBoUserOperation.h"
#import "JBoAsyncAuthOperation.h"
#import "JBoImageCacheTool.h"

//搜索栏高度
#define _searchBarHeight_ 40
//section头的高度
#define _sectionHeaderHeight_ 20

@interface JBoAuthListViewController ()<JBoAuthListCellDelegate,JBoHttpRequestDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

//已经设置权限的用户 数组元素是 NSString对象，用户 userId
@property(nonatomic,retain) NSMutableArray *authArray;

//正在请求
@property(nonatomic,assign) BOOL isRequesting;

//正在搜索
@property(nonatomic,assign) BOOL searching;

@end

@implementation JBoAuthListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"授权";
    
        JBoCustomTabBarController *cunstomTabBarVC = (JBoCustomTabBarController*)self.appDelegate.window.rootViewController;
        
        JBoContactListViewController *contactListVC = nil;
        UINavigationController *nav = (UINavigationController*)[cunstomTabBarVC.navigationControllers objectAtIndex:cunstomTabBarVC.addressBookIndex];
        for(UIViewController *VC in nav.viewControllers)
        {
            if([VC isKindOfClass:[JBoContactListViewController class]])
            {
                contactListVC = (JBoContactListViewController*)VC;
                break;
            }
        }
        
        _keywordArray = [[NSMutableArray alloc] init];
        [_keywordArray addObjectsFromArray:contactListVC.keywordArray];
        [_keywordArray removeObject:_linklnkKey_];
        
        _rosterDic = [[NSMutableDictionary alloc] init];
        [_rosterDic addEntriesFromDictionary:contactListVC.rosterDic];
        [_rosterDic removeObjectForKey:_linklnkKey_];
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        _searchResultArray = [[NSMutableArray alloc] init];
        self.authArray = [[[NSMutableArray alloc] init] autorelease];
        self.searching = NO;
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoRosterListViewController dealloc");
    [_keywordArray release];
    [_rosterDic release];
    
    [_tableView release];
    [_lettersView release];
    [_searchBar release];
    
    [_searchResultArray release];
    [_transparentView release];
    
    [_httpRequest release];
   
    [_authArray release];

    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.appDelegate.dataLoadingView.hidden = YES;
}


#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.appDelegate.dataLoadingView.hidden = YES;
    [self alertNetworkMsg:@"获取授权信息失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.appDelegate.dataLoadingView.hidden = YES;
    if([identifier isEqualToString:_getLocationAuthListIdentifier_])
    {
        NSArray *array = [JBoAuthlizeOperation getLocationAuthListFromData:data];
        [self.authArray addObjectsFromArray:array];
        [self loadInitView];
        return;
    }
    
    if([identifier isEqualToString:_getNotSeeTheirLookAndTellAuthIdentifier_])
    {
        NSArray *array = [JBoAuthlizeOperation getLocationAuthListFromData:data];
        [self.authArray addObjectsFromArray:array];
        [self loadInitView];
        return;
    }
    
    if([identifier isEqualToString:_getTheyCannotSeeMyLookAndtellAuthIdentifier_])
    {
        NSArray *array = [JBoAuthlizeOperation getLocationAuthListFromData:data];
        [self.authArray addObjectsFromArray:array];
        [self loadInitView];
        return;
    }
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    NSString *url = nil;
    
    switch (self.authLizeType)
    {
        case JBoAuthlizeTypeEnableSeeLocation :
        {
            url = [JBoAuthlizeOperation getLocationAuthList];
            _httpRequest.identifier = _getLocationAuthListIdentifier_;
        }
            break;
        case JBoAuthlizeTypeNotSeeLookAndTell:
        {
            url = [JBoAuthlizeOperation getNotSeeTheirLookAndTellAuthList];
            _httpRequest.identifier = _getNotSeeTheirLookAndTellAuthIdentifier_;
        }
            break;
        case JBoAuthlizeTypeDisableSeeLookAndTell:
        {
            url = [JBoAuthlizeOperation getTheyCannotSeeMyLookAndTellAuthList];
            _httpRequest.identifier = _getTheyCannotSeeMyLookAndtellAuthIdentifier_;
        }
            break;
        default:
            break;
    }
    
    [_httpRequest startDataLoading];
    [_httpRequest downloadWithURL:url];
}

- (void)loadInitView
{
    //创建tableview
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorColor = [UIColor grayColor];
    _tableView.rowHeight = _authCellHeight_;
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        _tableView.separatorInset = UIEdgeInsetsMake(0, _letterViewWidth_, 0, _letterViewWidth_);
    }
#endif
    [self.view addSubview:_tableView];
    
    [_tableView setExtraCellLineHidden];
    
    //创建搜索栏背
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
    _searchBar.placeholder = @"搜索";
    _searchBar.tintColor = _searchBarColor_;
    _searchBar.delegate = self;
    _tableView.tableHeaderView = _searchBar;
    
    //创建通讯录字母搜索视图
    
    _lettersView = [[JBoLettersSearchBar alloc] initWithFrame:CGRectMake(_width_ - _letterViewWidth_, 0, _letterViewWidth_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    [_lettersView addTarget:self action:@selector(letterTouchedAction)];
    [self.view addSubview:_lettersView];
}

//字母选择
- (void)letterTouchedAction
{
    NSString *letter = _lettersView.touchLetter;
    if([_keywordArray containsObject:letter])
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:[_keywordArray indexOfObject:letter]];
        [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    if(!_transparentView)
    {
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;

        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        [self.view addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    _lettersView.hidden = YES;
    [_searchBar setShowsCancelButton:YES animated:YES];
    [_tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [_searchBar setShowsCancelButton:NO animated:YES];
    _transparentView.hidden = YES;
    _lettersView.hidden = NO;
    [_tableView reloadData];
}

//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        char c = [ChineseToPinyin sortSectionTitle:content];
        if(c > 'a' && c < 'z')
            c = c -32;
        
        NSArray *array = [_rosterDic objectForKey:[NSString stringWithFormat:@"%c",c]];
        
        if(array)
        {
            [_searchResultArray removeAllObjects];
            
            for(JBoRosterInfo *rosterInfo in array)
            {
                NSString *name = [ChineseToPinyin pinyinFromChiniseString:rosterInfo.name];
              //  NSLog(@"%@",name);
                if(name.length < pinyin.length)
                {
                    continue;
                }
                
                NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
//                NSLog(@"sub = %@",subStr);
                
                if([pinyin isEqualToString:subStr])
                {
                    [_searchResultArray addObject:rosterInfo];
                }
            }
        }
        
        
        for(NSString *str in _keywordArray)
        {
            NSArray *infos = [_rosterDic objectForKey:str];
            
            for(JBoRosterInfo *info in infos)
            {
                NSRange range = [info.name rangeOfString:content];
                
                if(range.length > 0 && (![_searchResultArray containsObject:info]))
                {
                    [_searchResultArray addObject:info];
                }
            }
        }
    }
    if(_searchResultArray.count > 0)
    {
        [_tableView reloadData];
        _transparentView.hidden = YES;
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

#pragma mark-tableview代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
    {
        return 1;
    }
    else
    {
        return _keywordArray.count;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return _searchResultArray.count;
    }
    else
    {
        NSArray *array = [_rosterDic objectForKey:[_keywordArray objectAtIndex:section]];
        return array.count;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    JBoAuthListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoAuthListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoRosterInfo *rosterInfo = nil;
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    
    
    cell.nameLabel.text = rosterInfo.name;
    cell.nameLabel.sex = rosterInfo.sex;
    
    if([self.authArray containsObject:rosterInfo.username])
    {
        [cell.checkBox checkBoxStateChange:CheckBoxStyleSeclected];
    }
    else
    {
        [cell.checkBox checkBoxStateChange:CheckBoxStyleDefault];
    }
    
    cell.headImageView.sex = rosterInfo.sex;
    cell.headImageView.headImageURL = rosterInfo.imageURL;
    
    return cell;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching)
        return nil;
    UIView *view = nil;
    NSString *title = [_keywordArray objectAtIndex:section];
    
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"headerIdentifier";
        JBoAddressBookSectionHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[JBoAddressBookSectionHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.headerView.titleLabl.text = title;
        view = header;
#endif
    }
    else
    {
        JBoAddressBookSectionHeaderView *header = [[[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)] autorelease];
        header.titleLabl.text = title;
        view = header;
    }
    
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching)
    {
        return 0;
    }
    else
    {
        return _sectionHeaderHeight_;
    }
}

#pragma mark-JBoAuthListCell代理
- (void)authListCell:(JBoAuthListCell *)cell didSelectedAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoRosterInfo *rosterInfo = nil;
    
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    
    JBoAsyncAuthOperation *auth = [[JBoAsyncAuthOperation alloc] init];
    auth.authStatus = cell.checkBox.selected;
    __block JBoAsyncAuthOperation *blockAuth = auth;
    
    auth.completionHandler = ^(void)
    {
        if(blockAuth.success)
        {
            JBoAuthListCell *cell = (JBoAuthListCell*)[_tableView cellForRowAtIndexPath:indexPath];
            if(blockAuth.authStatus)
            {
                [cell.checkBox checkBoxStateChange:CheckBoxStyleSeclected];
                [self.authArray addObject:rosterInfo.username];
            }
            else
            {
                [cell.checkBox checkBoxStateChange:CheckBoxStyleDefault];
                [self.authArray removeObject:rosterInfo.username];
            }
        }
        else
        {
            [self alertNetworkMsg:@"授权失败"];
        }
        
        [blockAuth release];
    };
    
   
    NSString *url = nil;
    
    switch (self.authLizeType)
    {
        case JBoAuthlizeTypeEnableSeeLocation :
        {
            url = [JBoAuthlizeOperation getLocationAuthTargetId:rosterInfo.username status:!cell.checkBox.selected];
        }
            break;
        case JBoAuthlizeTypeNotSeeLookAndTell:
        {
            url = [JBoAuthlizeOperation getLookAndTellAuthWithTargetId:rosterInfo.username status:!cell.checkBox.selected index:1];
        }
            break;
        case JBoAuthlizeTypeDisableSeeLookAndTell:
        {
            url = [JBoAuthlizeOperation getLookAndTellAuthWithTargetId:rosterInfo.username status:!cell.checkBox.selected index:0];
        }
            break;
        default:
            break;
    }
    [auth authWithURL:url];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
