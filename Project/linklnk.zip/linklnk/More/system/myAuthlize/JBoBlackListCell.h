//
//  JBoBlackListCell.h
//  连你
//
//  Created by kinghe005 on 14-1-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"

#define _rosterCellHeight_ 60
#define _rosterCellInteval_ 10

@class JBoBlackListCell;

@protocol JBoBlackListCellDelegate <NSObject>

- (void)blackListCell:(JBoBlackListCell*) cell didDeleteAtIndex:(NSInteger) index;

@end

/**黑名单列表信息
 */
@interface JBoBlackListCell : UITableViewCell
{
    //移出按钮
    UIButton *_deleteButton;
}

//头像和名称 性别
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;
@property(nonatomic,assign) NSInteger index;

@property(nonatomic,assign) id<JBoBlackListCellDelegate> delegate;

@end