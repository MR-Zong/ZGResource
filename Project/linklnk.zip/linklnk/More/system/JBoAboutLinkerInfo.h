//
//  JBoAboutLinkerInfo.h
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**关于靓咖内容信息
 */
@interface JBoAboutLinkerInfo : NSObject

@property(nonatomic,copy) NSString *title;
@property(nonatomic,copy) NSString *content;
@property(nonatomic,copy) NSString *imageURL;

@property(nonatomic,retain) UIImage *image;
@property(nonatomic,assign) NSInteger titleHeight;

@end
