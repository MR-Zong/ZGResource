//
//  JBoClearCacheViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoClearCacheViewController.h"
#import "JBoAppDelegate.h"
#import "JBoImageCacheTool.h"
#import "JBoSystemOperation.h"
#import "JBoUserOperation.h"
#import "JBoMovieCacheTool.h"

@interface JBoClearCacheViewController ()<UIActionSheetDelegate>

//当前选择的功能
@property(nonatomic,assign) NSInteger currentIndex;

@end

@implementation JBoClearCacheViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"清除缓存";
        
        _infoArray = [[NSMutableArray alloc] initWithObjects:@"清除聊天记录", @"清除图片缓存", @"清除视频缓存", nil];
    }
    return self;
}

- (void)dealloc
{
    [_tableView release];
    [_infoArray release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor colorWithRed:243.0 / 255.0 green:245.0 / 255.0 blue:240.0 alpha:1.0];
	
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = 45.0;
    
    [self.view addSubview:_tableView];
    [_tableView setExtraCellLineHidden];
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentity = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentity];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentity] autorelease];
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        cell.accessoryView = imageView;
        [imageView release];
        
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    cell.textLabel.font = [UIFont systemFontOfSize:17.0];
    cell.textLabel.text = [_infoArray objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.row)
    {
        case 0 :
        {
            self.currentIndex = 0;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定清空所有聊天记录?" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"清空聊天记录" otherButtonTitles:nil, nil];
            [actionSheet showInView:self.view];
            [actionSheet release];
        }
            break;
        case 1 :
        {
            self.currentIndex = 1;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定清除所有图片缓存?" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"清除图片缓存" otherButtonTitles:nil, nil];
            [actionSheet showInView:self.view];
            [actionSheet release];
        }
            break;
        case 2 :
        {
            self.currentIndex = 2;
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定清除所有视频缓存?" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"清除视频缓存" otherButtonTitles:nil, nil];
            [actionSheet showInView:self.view];
            [actionSheet release];
        }
            break;
        default:
            break;
    }
}

#pragma mark-actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        switch (self.currentIndex)
        {
            case 0 :
            {
                self.appDelegate.dataLoadingView.hidden = NO;
                if([JBoSystemOperation clearCache])
                {
                    self.appDelegate.dataLoadingView.hidden = YES;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:_recentCallUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:JBoRecentCallUpdateTypeClearAllMsg], _recentCallUpdateType_, nil]];
                    [self alertMsg:@"清空聊天记录成功"];
                }
                else
                {
                    self.appDelegate.dataLoadingView.hidden = YES;
                }
            }
                break;
            case 1 :
            {
                self.appDelegate.dataLoadingView.hidden = NO;
                [JBoImageCacheTool clearCacheImageCompletion:^(void){
                    self.appDelegate.dataLoadingView.hidden = YES;
                    [self alertMsg:@"清除图片缓存成功"];
                }];
            }
                break;
            case 2 :
            {
                self.appDelegate.dataLoadingView.hidden = NO;
                [JBoMovieCacheTool clearCacheMovieWithCompletion:^(void){
                    self.appDelegate.dataLoadingView.hidden = YES;
                    [self alertMsg:@"清除视频缓存成功"];
                }];
            }
                break;
            default:
                break;
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
