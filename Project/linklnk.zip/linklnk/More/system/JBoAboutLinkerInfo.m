//
//  JBoAboutLinkerInfo.m
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAboutLinkerInfo.h"

@implementation JBoAboutLinkerInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.titleHeight = NSNotFound;
        
    }
    return self;
}

- (void)dealloc
{
    [_image release];
    [_imageURL release];
    [_title release];
    [_content release];
    
    [super dealloc];
}

@end
