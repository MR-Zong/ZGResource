//
//  JBoDetectVersion.h
//  连你
//
//  Created by kinghe005 on 14-2-23.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**版本检测
 */
@interface JBoDetectVersion : NSObject

/**版本检测完成后的操作
 */
@property(nonatomic,copy) void(^completionHandler)(void);

/**新版本路径
 */
@property(nonatomic,copy) NSString *trackViewUrl;

/**当前版本
 */
@property(nonatomic,copy) NSString *localVersion;

/**最新版本
 */
@property(nonatomic,copy) NSString *newestVersion;

/**检测版本 如果上一次检测距离现在没有超过 版本检测的时间间隔
 *@param immediate 是否马上检测是否有新版本
 *@return 是否进行版本检测
 */
- (BOOL)detectVersionImmediately:(BOOL) immediate;

/**取消检测
 */
- (void)cancel;


@end
