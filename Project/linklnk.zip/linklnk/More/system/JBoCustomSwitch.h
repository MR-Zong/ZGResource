//
//  JBoCustomSwitch.h
//  连你
//
//  Created by kinghe005 on 14-1-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol JBoCustomSwitchDelegate <NSObject>

@optional

- (void)clicked:(BOOL)isFront;

@end

@interface JBoCustomSwitch : UIView

@property (nonatomic, readonly) UIButton *frontButton;

@property (nonatomic, readonly) UIButton *backButton;

@property (nonatomic, retain) UIColor *offColor;

@property (nonatomic, retain) UIColor *onColorLight;

@property (nonatomic, retain) UIColor *onColorDark;

@property (nonatomic, assign) id<JBoCustomSwitchDelegate> delegate;

@property(nonatomic, assign) BOOL on;

@end