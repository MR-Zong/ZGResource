//
//  JBoSystemOperation.m
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSystemOperation.h"
#import "JBoBasic.h"
#import "FMDatabase.h"
#import "JBoImageCacheTool.h"
#import "JBoChatMsgDBOperation.h"
#import "JSONKit.h"
#import "JBoAboutLinkerInfo.h"
#import "NSDictionary+customDic.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import "JBoUserOperation.h"
#import "JBoDataPersist.h"

@implementation JBoSystemOperation

#pragma mark- 消息提醒

//获取的系统配置文件
+ (NSMutableDictionary*) systemSetup
{
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath = [doc stringByAppendingPathComponent:@"system.plist"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableDictionary *dic = nil;
    
    if([fileManager fileExistsAtPath:filePath])
    {
        dic = [[NSMutableDictionary alloc] initWithContentsOfFile:filePath];
    }
    else
    {
        dic = [[NSMutableDictionary alloc] init];
       
        [dic setObject:[NSNumber numberWithBool:YES] forKey:_pushAlert_];
        [dic setObject:[NSNumber numberWithBool:NO] forKey:_pushShake_];
        [dic setObject:[NSNumber numberWithBool:YES] forKey:_pushSound_];
        [dic writeToFile:filePath atomically:YES];
    }
    
    return [dic autorelease];
}

//保存消息提醒配置文件
+ (void)saveSystemSetup:(NSMutableDictionary*) dic
{
    NSString *doc = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath = [doc stringByAppendingPathComponent:@"system.plist"];
    [dic writeToFile:filePath atomically:YES];
}

/**设置消息是否推送
 */
+ (void)setPushAlert:(BOOL) alert
{
    NSMutableDictionary *dic = [JBoSystemOperation systemSetup];
    
    [dic setObject:[NSNumber numberWithBool:alert] forKey:_pushAlert_];
    [JBoSystemOperation saveSystemSetup:dic];
}

/**设置消息是否有声音提醒
 */
+ (void)setPushSound:(BOOL) pushSound
{
    NSMutableDictionary *dic = [JBoSystemOperation systemSetup];
    
    [dic setObject:[NSNumber numberWithBool:pushSound] forKey:_pushSound_];
    [JBoSystemOperation saveSystemSetup:dic];
}

/**设置手机是否震动
 */
+ (void)setShake:(BOOL) shake
{
    NSMutableDictionary *dic = [JBoSystemOperation systemSetup];
    
    [dic setObject:[NSNumber numberWithBool:shake] forKey:_pushShake_];
    [JBoSystemOperation saveSystemSetup:dic];
}

/**清理所有聊天记录缓存
 */
+ (BOOL)clearCache
{
    JBoChatMsgDBOperation *chatMsgDB = [[[JBoChatMsgDBOperation alloc] init] autorelease];
    if([chatMsgDB deleteAllChatHistory])
    {
        if(![JBoDataPersist removeChatImageDirectory])
        {
            NSLog(@"清理图片失败");
        }
        
        if(![JBoDataPersist removeChatRecordDirectory])
        {
            NSLog(@"清理录音文件失败");
        }
        
        if(![JBoDataPersist removeChatShortMovieDirectory])
        {
            NSLog(@"清除视频文件失败");
        }
        return YES;
    }
    else
    {
        return NO;
    }
}

//获取关于连你数据
+ (NSString*)getAboutLinklnk
{
    NSString *url = [JBoUserOperation md5Url:_aboutLinklnk_ withUserId:YES];
    NSLog(@"%@",url);
    
    return url;
}

+ (NSDictionary*)getAboutLinklnkFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@", [[dic objectForKey:_result_] objectForKey:_msg_]);
    NSLog(@"%@",dic);
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic objectForKey:_data_];
        
        if(dataArray.count > 0)
        {
            NSDictionary *dic = [dataArray firstObject];
            return dic;
        }
        else
        {
            return nil;
        }
    }
    else
    {
        return nil;
    }
}

/**注册推送
 */
+ (void)registerRemoteNotification
{
    NSDictionary *dic = [JBoSystemOperation systemSetup];
    BOOL push = [[dic objectForKey:_pushAlert_] boolValue];
    
    if(push)
    {
        UIApplication *application = [UIApplication sharedApplication];
       // NSLog(@"%@ %d", application, [application enabledRemoteNotificationTypes]);
//        if([application enabledRemoteNotificationTypes])
//        {
        if(_ios8_0_)
        {
#ifdef __IPHONE_8_0
            UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert categories:nil];
            [application registerUserNotificationSettings:settings];
#endif
        }
        else
        {
            [application registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound];
        }
        
        //}
    }
}

/**取消注册推送
 */
+ (void)unRegisterRemoteNotification
{
    [[UIApplication sharedApplication] unregisterForRemoteNotifications];
}

#pragma mark- 耳机检测

/**开始耳机检测
 */
+ (void)beginHeadSetListener
{
    //注册耳机监听回调
    AudioSessionInitialize (NULL, NULL, NULL, NULL);
    AudioSessionAddPropertyListener (kAudioSessionProperty_AudioRouteChange,
                                     audioRouteChangeListenerCallback,
                                     self);
}

void audioRouteChangeListenerCallback (
                                       void                      *inUserData,
                                       AudioSessionPropertyID    inPropertyID,
                                       UInt32                    inPropertyValueSize,
                                       const void                *inPropertyValue
                                       ) {
   // NSLog(@"耳机检测");
    AudioSessionInitialize (NULL, NULL, NULL, NULL);
    if (inPropertyID != kAudioSessionProperty_AudioRouteChange) return;
    // Determines the reason for the route change, to ensure that it is not
    //        because of a category change.
    
    CFNumberRef routeChangeReasonRef = (CFNumberRef)CFDictionaryGetValue((CFDictionaryRef)inPropertyValue, CFSTR (kAudioSession_AudioRouteChangeKey_Reason));
    
    SInt32 routeChangeReason;
    CFNumberGetValue (routeChangeReasonRef, kCFNumberSInt32Type, &routeChangeReason);
    
    if (routeChangeReason == kAudioSessionRouteChangeReason_OldDeviceUnavailable) {
        [[NSUserDefaults standardUserDefaults] setInteger:JBoAudioPlayModeSpeaker forKey:_audioPlayMode_];
    } else if (routeChangeReason == kAudioSessionRouteChangeReason_NewDeviceAvailable) {
        
        [[NSUserDefaults standardUserDefaults] setInteger:JBoAudioPlayModeHook forKey:_audioPlayMode_];
    } else if (routeChangeReason == kAudioSessionRouteChangeReason_NoSuitableRouteForCategory) {
        [[NSUserDefaults standardUserDefaults] setInteger:JBoAudioPlayModeSpeaker forKey:_audioPlayMode_];
    }
    [JBoSystemOperation setupAudio];
}

//是否插入耳机
+ (BOOL)isHeadphone
{
    UInt32 propertySize = sizeof(CFStringRef);
    CFStringRef state = nil;
    AudioSessionGetProperty(kAudioSessionProperty_AudioRoute
                            ,&propertySize,&state);
    //return @"Headphone" or @"Speaker" and so on.
    //根据状态判断是否为耳机状态
    if ([(NSString *)state isEqualToString:@"Headphone"] ||[(NSString *)state isEqualToString:@"HeadsetInOut"])
    {
        if(state != NULL)
            CFRelease(state);
            
        return YES;
    }
    else
    {
        if(state != NULL)
            CFRelease(state);
        return NO;
    } 
}

/**设置听筒和扬声器
 */
+ (void)setupAudio
{
    JBoAudioPlayMode audioPlayMode = [[NSUserDefaults standardUserDefaults] integerForKey:_audioPlayMode_];
    switch (audioPlayMode)
    {
        case JBoAudioPlayModeSpeaker :
        {
            UInt32 audioRountOverride = kAudioSessionOverrideAudioRoute_Speaker;
            AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRountOverride), &audioRountOverride);
        }
            break;
        case JBoAudioPlayModeHook :
        {
            UInt32 audioRountOverride = kAudioSessionOverrideAudioRoute_None;
            AudioSessionSetProperty(kAudioSessionProperty_OverrideAudioRoute, sizeof(audioRountOverride), &audioRountOverride);
        }
            break;
        default:
            break;
    }
}

#pragma mark- 靓友圈、附近秘密更新提示

/**获取附近秘密 靓友圈 最后访问时间
 *@return  get请求url
 */
+ (NSString*)getLastRequestTime
{
    NSString *url = [JBoUserOperation md5Url:_getLastRequestTime_ withUserId:YES];
    NSLog(@"%@",url);
    return url;
}

/**从返回数据获取 附近秘密 靓友圈 最后访问时间
 *@param data 返回数据
 *@return 一个字典，里面包含 附近秘密 靓友圈 最后访问时间
 */
+ (NSDictionary*)getLastRequestTimeFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@",dic);
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic objectForKey:_data_];
        if([dict isKindOfClass:[NSDictionary class]])
        {
            NSMutableDictionary *result = [NSMutableDictionary dictionaryWithCapacity:2];
            
            NSString *circle = [dict objectWithKey:_lookAndTellCircleLastTime_];
            NSString *secret = [dict objectWithKey:_assitLastTime_];
            
            [result setObject:circle withKey:_lookAndTellCircleLastTime_];
            [result setObject:secret withKey:_assitLastTime_];
            
            return result;
        }
    }
    
    return nil;
}

/**获取靓友圈数据的最新时间
 *@return get请求url
 */
+ (NSString*)getLookAndTellCircleLastestTime
{
    NSString *url = [JBoUserOperation md5Url:_getLookAndTellCircleLastestTime_ withUserId:YES];
    
    return url;
}

/**从返回数据获取靓友圈数据的最新时间
 *@param data 返回数据
 *@return 靓友圈最新时间 格式为 2014-08-08 09:23:34
 */
+ (NSString*)getLookAndTellCircleLastestTimeFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@",dic);
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        return [resultDic objectWithKey:_lookAndTellCircleLastTime_];
    }
    return nil;
}

/**获取附近秘密数据最新时间
 *@param coordinate 要获取附近秘密的坐标
 *@param radius 范围
 *@return get 请求url
 */
+ (NSString*)getAroundSecretLastestTimeWithCoordinate:(CLLocationCoordinate2D)coordinate radius:(int)radius
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%f&%@=%f&%@=%d", _getAroundSecretLastestTime_, _helpLatitude_, coordinate.latitude, _helpLongitude_, coordinate.longitude, _helpRadius_, radius];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**从返回的数据获取附近秘密数据最新时间
 *@param data 返回的数据
 *@return 附近秘密最新时间 格式为 2014-08-08 09:23:34
 */
+ (NSString*)getAroundSecretLastestTimeFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        return [resultDic objectWithKey:_assitLastTime_];
    }
    return nil;
}

@end
