//
//  JBoAboutLinkerViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAboutLinkerViewController.h"
#import "JBoAppDelegate.h"
#import "JBoAboutLinkerInfo.h"
#import "JBoImageTextTool.h"
#import "JBoHttpRequest.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoUserOperation.h"
#import "JBoSystemOperation.h"

#define _controlInterval_ 5
#define _controlHeight_ 30
#define _sysIntroNum_ 6
#define _imageHeight_ 200

/**关于靓咖的内容cell
 */
@interface JBoAboutLinkerCell : UITableViewCell

@property(nonatomic,readonly) UILabel *titleLabel;
@property(nonatomic,readonly) UILabel *contentLabel;

@property(nonatomic,assign) NSInteger contentHeight;
@property(nonatomic,readonly) UIImageView *contentImageView;

@end

@implementation JBoAboutLinkerCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
//        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_, _controlInterval_, _width_ - _controlInterval_ * 2, _controlHeight_)];
//        _titleLabel.font = [UIFont fontWithName:@"Avenir-Black" size:19.0];
//        _titleLabel.backgroundColor = [UIColor clearColor];
//        [self.contentView addSubview:_titleLabel];
//        
//        _contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_, _titleLabel.frame.origin.y + _titleLabel.frame.size.height, _width_ - _controlInterval_ * 2, _controlHeight_)];
//        _contentLabel.backgroundColor = [UIColor clearColor];
//        [self.contentView addSubview:_contentLabel];
        
        _contentImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, _controlInterval_, _width_, _imageHeight_)];
        _contentImageView.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:0.5];
        [self.contentView addSubview:_contentImageView];
    }
    return self;
}

- (void)dealloc
{
    
    [_titleLabel release];
    [_contentLabel release];
    [_contentImageView release];
    
    [super dealloc];
}

@end

@interface JBoAboutLinkerViewController ()<JBoHttpRequestDelegate>
{
    JBoHttpRequest *_httpRequest;
    NSMutableDictionary *_imageDic;
    NSMutableDictionary *_downloadProgressDic;
}

@property(nonatomic,copy) NSString *headTitle;
@end

@implementation JBoAboutLinkerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = [NSString stringWithFormat:@"关于%@", self.appDelegate.appName];
        _srcArray = [[NSMutableArray alloc] init];
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        _imageDic = [[NSMutableDictionary alloc] init];
        _downloadProgressDic = [[NSMutableDictionary alloc] init];
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_srcArray release];
    [_tableView release];
    [_headTitle release];
    
    [_httpRequest release];
    [_imageDic release];
    [_downloadProgressDic release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.appDelegate.dataLoadingView.hidden = YES;
}


#pragma mark-httpRquest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.appDelegate.dataLoadingView.hidden = YES;
    [self alertNetworkMsg:@"获取信息失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.appDelegate.dataLoadingView.hidden = YES;
    NSDictionary *dic = [JBoSystemOperation getAboutLinklnkFromData:data];
    if(dic)
    {
        self.headTitle = [dic objectForKey:_aboutTitle_];
        NSString *imageURls = [dic objectForKey:_aboutPhoto_];
        NSArray *array = [JBoImageTextTool getImageURLsFromStr:imageURls];
       
        [_srcArray addObjectsFromArray:array];
        
        [self loadInitView];
    }
    else
    {
        [self alertNetworkMsg:@"获取信息失败"];
    }
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    
    self.view.backgroundColor = [UIColor colorWithRed:243.0 / 255.0 green:245.0 / 255.0 blue:240.0 alpha:1.0];
    
    [_httpRequest startDataLoading];
    [_httpRequest downloadWithURL:[JBoSystemOperation getAboutLinklnk]];
}

- (void)loadInitView
{
    
    UITextView *textView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    textView.backgroundColor = [UIColor whiteColor];
    textView.textColor = [UIColor blackColor];
    textView.font = [UIFont systemFontOfSize:17.0];
    textView.text = self.headTitle;
    textView.editable = NO;
    [self.view addSubview:textView];
    [textView release];
    
//    CGFloat height = [JBoImageTextTool getStringSize:self.headTitle withFont:[UIFont systemFontOfSize:17.0] andContraintSize:CGSizeMake(_width_, _maxFloat_)].height;
//    
//    NSLog(@"%f",height);
//    
//    height += _controlInterval_ * 4;
//    UILabel *header = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
//    header.backgroundColor = [UIColor redColor];
//    header.textColor = [UIColor blackColor];
//    header.text = self.headTitle;
//    header.numberOfLines = 0;
//    
//    [self.view addSubview:header];
//    
//    NSLog(@"--");
	
//    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
//    _tableView.delegate = self;
//    _tableView.dataSource = self;
//    _tableView.rowHeight = _controlInterval_ * 2 + _imageHeight_;
//    _tableView.tableHeaderView = header;
//    [header release];
//    _tableView.separatorStyle = UITableViewCellSelectionStyleNone;
//    [self.view addSubview:_tableView];
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellidentifier = @"cell";
    JBoAboutLinkerCell *cell = [tableView dequeueReusableCellWithIdentifier:cellidentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoAboutLinkerCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellidentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSString *imageURL = [_srcArray objectAtIndex:indexPath.row];
    
//    cell.titleLabel.text = info.title;
//    cell.contentLabel.text = info.content;
    UIImage *image = [_imageDic objectForKey:imageURL];
    if(image)
    {
        cell.contentImageView.image = image;
    }
    else
    {
        cell.contentImageView.image = nil;
        if(!tableView.dragging && !tableView.decelerating)
        {
            [self  downloadImageWithImageURL:imageURL indexPath:indexPath];
        }
        
    }
    
    return cell;
}

//加载图片
- (void)downloadImageWithImageURL:(NSString*) imageURL indexPath:(NSIndexPath*) indexPath
{
    if([NSString isEmpty:imageURL])
        return;
    
   // NSLog(@"%@",imageURL);
    JBoAsyncDownloadImageOperation *download = [_downloadProgressDic objectForKey:indexPath];
    if(!download)
    {
        download = [[JBoAsyncDownloadImageOperation alloc] init];
        
        __block JBoAsyncDownloadImageOperation *blockDownload = download;
        download.completionHandler = ^(void)
        {
            NSData *imageData = blockDownload.data;
            UIImage *image = [[UIImage alloc] initWithData:imageData];
            
            UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:CGSizeMake(_width_, _imageHeight_)];
            
            if(thumbnail)
            {
                [_imageDic setObject:thumbnail forKey:imageURL];
                JBoAboutLinkerCell *cell = (JBoAboutLinkerCell*)[_tableView cellForRowAtIndexPath:indexPath];
                cell.contentImageView.image = thumbnail;
            }
            
            [image release];
            [_downloadProgressDic removeObjectForKey:indexPath];
        };
        
        [_downloadProgressDic setObject:download forKey:indexPath];
        [download downloadWithURL:imageURL];
       // [download release];
    }
}

#pragma mark-加载图片

- (void)loadImageForOnScreenRows
{
    if(_srcArray.count > 0)
    {
        NSArray *indexPathArray = [_tableView indexPathsForVisibleRows];
        for(NSIndexPath *indexPath in indexPathArray)
        {
            NSString *imageURL = [_srcArray objectAtIndex:indexPath.row];

            [self downloadImageWithImageURL:imageURL indexPath:indexPath];
        }
    }
}

#pragma mark-scrollView代理 

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    // NSLog(@"addressBook scrollViewDidEndDragging");
    if(!decelerate)
    {
        [self loadImageForOnScreenRows];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //NSLog(@"addressBook scrollViewDidEndDecelerating");
    [self loadImageForOnScreenRows];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
