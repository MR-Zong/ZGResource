//
//  JBoAboutLinkerViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**关于靓咖
 */
@interface JBoAboutLinkerViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_srcArray;
}
@end
