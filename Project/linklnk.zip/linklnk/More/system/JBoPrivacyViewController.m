//
//  JBoPrivacyViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoPrivacyViewController.h"
#import "JBoAppDelegate.h"
#import "JBoVerifyPhoneNumViewController.h"
#import "JBoUserDetailInfo.h"
#import "JBoUserOperation.h"
#import "JBoHttpRequest.h"
#import "JBoOldPasswordViewController.h"
#import "UITableView+extraCellLine.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import "JBoTouchIdOperation.h"

#define _controlInterval_ 5
#define _controlHeight_ 30

@interface JBoPrivacyViewController ()<JBoHttpRequestDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

//当前登录的用户信息
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

//指纹解锁状态
@property(nonatomic,assign) BOOL touchIdStatus;

@end

@implementation JBoPrivacyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"隐私设置";

        NSMutableArray *retArray = [[NSMutableArray alloc] initWithObjects:@"添加我为好友需要发送请求信息", @"修改密码", @"设置手势密码", nil];
        
        if(_ios8_0_)
        {
#ifdef __IPHONE_8_0
            
             LAContext *context = [[[LAContext alloc] init] autorelease];
            if([context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:nil])
            {
                [retArray addObject:@"使用指纹解锁"];
            }
#endif
        }
        
        _srcArray = [retArray retain];
        [retArray release];
        
        self.userDetailInfo = [JBoUserOperation getUserDetailInfo];
        
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        _touchIdStatus = [JBoTouchIdOperation needTouchIdDeblock];
    }
    return self;
}

- (void)setTouchIdStatus:(BOOL)touchIdStatus
{
    if(_touchIdStatus != touchIdStatus)
    {
        _touchIdStatus = touchIdStatus;
        [JBoTouchIdOperation setTouchIdDeblockStatus:_touchIdStatus];
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_tableView release];
    [_srcArray release];
    [_userDetailInfo release];
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    //[JBoUserOperation alertMsg:@"网络不给力,修改失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor colorWithRed:243.0 / 255.0 green:245.0 / 255.0 blue:240.0 alpha:1.0];
	
    CGFloat cellHeight = 40;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
    
    [_tableView setExtraCellLineHidden];
}


#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if(indexPath.row == 0 || indexPath.row == 3)
    {
        static NSString *cellIdentifier = @"cellSwitch";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if(cell == nil)
        {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
            
            UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, _controlInterval_, 240, _controlHeight_)];
            titleLabel.backgroundColor = [UIColor clearColor];
            titleLabel.adjustsFontSizeToFitWidth = YES;
            titleLabel.font = [UIFont systemFontOfSize:15.0];
            [cell.contentView addSubview:titleLabel];
            [titleLabel release];
            
            
            UISwitch *switchView = [[UISwitch alloc] initWithFrame:CGRectMake(_width_ - (_ios7_0_ ? _switchWidth_7_ : _switchWidth__6_), _controlInterval_, (_ios7_0_ ? _switchWidth_7_ : _switchWidth__6_), _controlHeight_)];
            [switchView addTarget:self action:@selector(homeSelectedAction:) forControlEvents:UIControlEventValueChanged];
            switchView.on = self.userDetailInfo.status;
            [cell.contentView addSubview:switchView];
            [switchView release];
            
        }
        
        UILabel *tilteLabel = [cell.contentView.subviews objectAtIndex:0];
        tilteLabel.text = [_srcArray objectAtIndex:indexPath.row];
        
        UISwitch *switchView = [cell.contentView.subviews objectAtIndex:1];
        switchView.tag = indexPath.row;
        
        if(indexPath.row == 0)
        {
            switchView.on = self.userDetailInfo.status;
        }
        else
        {
            switchView.on = self.touchIdStatus;
        }
        return cell;
    }
    
    static NSString *cellIdentity = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentity];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentity] autorelease];
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        cell.accessoryView = imageView;
        [imageView release];
    }
    
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    
    cell.textLabel.font = [UIFont systemFontOfSize:15.0];
    cell.textLabel.text = [_srcArray objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [_tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 1 :
        {
            JBoOldPasswordViewController *verifyVC = [[JBoOldPasswordViewController alloc] init];
            [self.navigationController pushViewController:verifyVC animated:YES];
            [verifyVC release];
        }
            break;
            case 2 :
        {
            NSString *passwd = [JBoGesturePasswdController getGesturePasswd];
            if(passwd)
            {
                [self.appDelegate showGesturePasswdWithType:JBoGesturePasswdControllerOperationTypeModify];
            }
            else
            {
                [self.appDelegate showGesturePasswdWithType:JBoGesturePasswdControllerOperationTypeNewPasswd];
            }
        }
        default:
            break;
    }
}

#pragma mark-设置

- (void)homeSelectedAction:(UISwitch*) switchView
{
    if(switchView.tag == 0)
    {
        self.userDetailInfo.status = switchView.on;
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:self.userDetailInfo];
        [[NSUserDefaults standardUserDefaults] setObject:data forKey:_loginDetailUserInfo_];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        [_httpRequest downloadWithURL:[JBoUserOperation getModifyUserInfoURL] dic:[JBoUserOperation getModifyUserInfoWithDic:[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:switchView.on] forKey:_rosterStatus_]]];
    }
    else if(switchView.tag == 3)
    {
        self.touchIdStatus = switchView.on;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
