//
//  JBoDetectVersion.m
//  连你
//
//  Created by kinghe005 on 14-2-23.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoDetectVersion.h"
#import "JSONKit.h"
#import "JBoUserOperation.h"
#import "NSDictionary+customDic.h"
#import "JBoDatetimeTool.h"

#define _detectVersionTime_ @"detectVersionTime"
#define _oneDay_ 60 * 60 * 6

//靓咖在appstore的信息 的请求路径
static NSString *const appStoreURL = @"http://itunes.apple.com/lookup?";

//请求参数
static NSString *const appID = @"id";

//靓咖的appId
static NSString *const appIDValue = @"827390903";

//最新版本号
static NSString *const appVersion = @"version";

//更新路径
static NSString *const appURL = @"trackViewUrl";

//本地版本号
static NSString *const appLocalVersion = @"CFBundleShortVersionString";

@interface JBoDetectVersion ()<NSURLConnectionDataDelegate,NSURLConnectionDelegate>

//http链接
@property(nonatomic,retain) NSURLConnection *connection;

//返回的数据
@property(nonatomic,retain) NSMutableData *receiveData;

@end

@implementation JBoDetectVersion

- (id)init
{
    self = [super init];
    if(self)
    {
        
    }
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoDetectVersion dealloc");
    [_receiveData release];
    
    [_connection cancel];
    [_connection release];
    
    [_trackViewUrl release];
    
    [_newestVersion release];
    [_localVersion release];
    
    Block_release(_completionHandler);
    
    [super dealloc];
}

#pragma mark- public method

/**检测版本 如果上一次检测距离现在没有超过 版本检测的时间间隔
 *@param immediate 是否马上检测是否有新版本
 *@return 是否进行版本检测
 */
- (BOOL)detectVersionImmediately:(BOOL)immediate
{
    if([self isOneDay] || immediate)
    {
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@=%@", appStoreURL, appID, appIDValue]];
        NSLog(@"%@",url);
        NSURLRequest *request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:40];

        NSURLConnection *conn = [[NSURLConnection alloc] initWithRequest:request delegate:self];
        self.connection = conn;
        [conn release];
        return YES;
    }
    else
    {
        return NO;
    }
}

/**取消检测
 */
- (void)cancel
{
    [self.connection cancel];
    self.connection = nil;
}

//是否已超过时间间隔
- (BOOL)isOneDay
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *lastTime = [defaults objectForKey:_detectVersionTime_];
    
    NSString *currentTime = [JBoDatetimeTool getCurrentTime];
    
    
    if([JBoDatetimeTool isTimeExpired:_oneDay_ withTime:lastTime])
    {
        [defaults setObject:currentTime forKey:_detectVersionTime_];
        return YES;
    }
    
    return NO;
}

#pragma mark-connection代理

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    self.receiveData = nil;
    [self.connection cancel];
    self.connection = nil;
    
    if(self.completionHandler)
    {
        self.completionHandler();
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    self.receiveData = [NSMutableData data];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [self.receiveData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSDictionary *dic = [self.receiveData objectFromJSONData];
    NSArray *resArray = [dic objectForKey:@"results"];
    
   //  self.trackViewUrl = @"https://itunes.apple.com/us/app/qq-hd-2014/id453718989?mt=8&uo=4";
    NSDictionary *localDic = [[NSBundle mainBundle] infoDictionary];
    // NSLog(@"--%@",localDic);
    self.localVersion = [localDic objectWithKey:appLocalVersion];
    
    if(resArray.count > 0)
    {
        NSDictionary *valueDic = [resArray firstObject];
        NSLog(@"itunes url %@",[valueDic objectWithKey:appURL]);
        
        self.newestVersion = [valueDic objectWithKey:appVersion];
        
        if(![self isNeedUpdate])
        {
            self.trackViewUrl = nil;
        }
        else
        {
            self.trackViewUrl = [valueDic objectWithKey:appURL];
        }
    }
    
    if(self.completionHandler)
    {
        self.completionHandler();
    }
}

#define _versionInterval_ @"."

//是否有新版本
- (BOOL)isNeedUpdate
{
    NSLog(@"---- %@,%@",self.localVersion, self.newestVersion);
    
    NSArray *localArray = [self.localVersion componentsSeparatedByString:_versionInterval_];
    NSArray *newArray = [self.newestVersion componentsSeparatedByString:_versionInterval_];
    
    if(localArray.count != newArray.count)
        return YES;
    
    BOOL need = NO;
    
    for(NSInteger i = 0; i < localArray.count && i < newArray.count;i ++)
    {
        int local = [[localArray objectAtIndex:i] intValue];
        int newVersion = [[newArray objectAtIndex:i] intValue];
        
        NSLog(@"%d,%d", local, newVersion);
        
        if(local < newVersion)
        {
            need = YES;
            break;
        }
        else if(local > newVersion)
        {
            break;
        }
    }
    
    NSLog(@"%d",need);
    return need;
}

@end
