//
//  JBoClearCacheViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-11.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**清除缓存
 */
@interface JBoClearCacheViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
    NSMutableArray *_infoArray;
}

@end
