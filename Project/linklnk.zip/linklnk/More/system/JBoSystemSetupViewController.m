//
//  JBoSystemSetupViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-5.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSystemSetupViewController.h"
#import "JBoLoginViewController.h"
#import "JBoSystemOperation.h"
#import "JBoMsgRemindViewController.h"
#import "JBoPrivacyViewController.h"
#import "JBoAboutLinkerViewController.h"
#import "JBoMyAuthlizeViewController.h"
#import "JBoDetectVersion.h"
#import "JBoUserOperation.h"
#import "JBoClearCacheViewController.h"
#import "JBoMyAuthlizeViewController.h"

#define _controlInterval_ 5
#define _controlHeight_ 30

@interface JBoSystemSetupViewController ()<UIAlertViewDelegate>

//appStore 的超级快连url 更新版本时用到
@property(nonatomic,copy) NSString *url;

//当前版本
@property(nonatomic,copy) NSString *localVersion;

//最新版本
@property(nonatomic,copy) NSString *newestVersion;

//当前选择的功能
@property(nonatomic,assign) NSInteger currentIndex;

//版本检测
@property(nonatomic,retain) JBoDetectVersion *detectVersion;

//是否正在操作
@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoSystemSetupViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _srcArray = [[NSArray alloc] initWithObjects:@"新消息提醒", @"隐私", @"我的授权", @"清除缓存", [NSString stringWithFormat:@"关于%@", self.appDelegate.appName], nil];
        self.title = @"系统设置";
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoSystemSetupViewController dealloc");
    [_srcArray release];
    [_tableView release];
    
    [_url release];
    [_localVersion release];
    [_newestVersion release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [self.appDelegate closeAlertView];
    }
    
    [self.detectVersion cancel];
    self.detectVersion = nil;
    self.isRequesting = NO;
}

#pragma mark- 加载视图

- (void)back
{
    [self.detectVersion cancel];
    self.detectVersion = nil;
    self.isRequesting = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    
    self.view.backgroundColor = [UIColor colorWithRed:243.0 / 255.0 green:245.0 / 255.0 blue:240.0 alpha:1.0];
	
    CGFloat cellHeight = 40;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_ ) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
    
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 100)];
    
    
    //退出按钮
    UIImage *exitImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logout_btn@2x" ofType:_imageType_]];
    UIButton *exitButton = [UIButton buttonWithType:UIButtonTypeCustom];
     [exitButton setBackgroundImage:exitImage forState:UIControlStateNormal];
    [exitButton setFrame:CGRectMake((_width_ - exitImage.size.width) / 2,(footerView.frame.size.height - exitImage.size.height) / 2,exitImage.size.width, exitImage.size.height + 5.0)];
    [exitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [exitButton setTitle:@"退出当前账号" forState:UIControlStateNormal];
    [exitButton addTarget:self action:@selector(exitAction:) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:exitButton];
    [exitImage release];
    
    _tableView.tableFooterView = footerView;
    [footerView release];
}

//退出登录
- (void)exitAction:(UIButton*) button
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"退出当前账号" otherButtonTitles:nil, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [JBoUserOperation loginOutNeedSendMsg:YES];
    }
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    static NSString *cellIdentity = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentity];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentity] autorelease];
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        cell.accessoryView = imageView;
        [imageView release];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    cell.textLabel.text = [_srcArray objectAtIndex:indexPath.row];
    
    if(indexPath.row == _srcArray.count - 1)
    {
        NSDictionary *localDic = [[NSBundle mainBundle] infoDictionary];
        cell.detailTextLabel.text = [NSString stringWithFormat:@"版本%@",[localDic objectForKey:@"CFBundleShortVersionString"]];
    }
    else
    {
        cell.detailTextLabel.text = nil;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0 :
        {
            JBoMsgRemindViewController *msgRemindVC = [[JBoMsgRemindViewController alloc] init];
            [self.navigationController pushViewController:msgRemindVC animated:YES];
            [msgRemindVC release];
        }
            break;
           case 1 :
        {
            JBoPrivacyViewController *privacy = [[JBoPrivacyViewController alloc] init];
            [self.navigationController pushViewController:privacy animated:YES];
            [privacy release];
        }
            break;
        case 2 :
        {
            JBoMyAuthlizeViewController *myAuthlize =[[JBoMyAuthlizeViewController alloc] init];
            [self.navigationController pushViewController:myAuthlize animated:YES];
            [myAuthlize release];
        }
            break;
        case 3 :
        {
            self.currentIndex = 2;
            JBoClearCacheViewController *clearCache = [[JBoClearCacheViewController alloc] init];
            [self.navigationController pushViewController:clearCache animated:YES];
            [clearCache release];
        }
            break;
//        case 4 :
//        {
//            if(self.isRequesting)
//                return;
//            
//            self.isRequesting = YES;
//            self.currentIndex = 3;
//            
//            if(![NSString isEmpty:self.localVersion] && ![NSString isEmpty:self.newestVersion])
//            {
//                if(![NSString isEmpty:self.url])
//                {
//                    [self needToUpdate];
//                }
//                else
//                {
//                    [self isNewest];
//                }
//                
//                self.isRequesting = NO;
//                return;
//            }
//            
//            self.detectVersion = [[[JBoDetectVersion alloc] init] autorelease];
//            __block JBoSystemSetupViewController *blockSelf = self;
//            
//            self.detectVersion.completionHandler = ^(void)
//            {
//                blockSelf.url = blockSelf.detectVersion.trackViewUrl;
//                blockSelf.localVersion = blockSelf.detectVersion.localVersion;
//                blockSelf.newestVersion = blockSelf.detectVersion.newestVersion;
//                
//                if(![NSString isEmpty:blockSelf.url])
//                {
//                    [blockSelf needToUpdate];
//                }
//                else
//                {
//                    [blockSelf isNewest];
//                }
//                blockSelf.isRequesting = NO;
//            };
//            
//            [self.detectVersion detectVersionImmediately:YES];
//        }
//            break;
        case 4 :
        {
            JBoAboutLinkerViewController *abountLinkerVC = [[JBoAboutLinkerViewController alloc] init];
            [self.navigationController pushViewController:abountLinkerVC animated:YES];
            [abountLinkerVC release];
        }
            break;
        default:
            break;
    }
}

#pragma mark-alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch(self.currentIndex)
    {
        case 2 :
        {

        }
            break;
            case 3 :
        {
            if(buttonIndex == 1)
            {
                //去appStore下载
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:self.url]];
            }
        }
        default:
            break;
    }
}

//提示用户是否更新
- (void)needToUpdate
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"有最新版本了,版本号%@,当前版本号 %@ 是否需要更新", self.newestVersion, self.localVersion] delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"更新", nil];
    [alertView show];
    [alertView release];
}

//提示用户已是最新版本
- (void)isNewest
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"当前已是最新版本了,版本号 %@",self.localVersion] delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alertView show];
    [alertView release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
