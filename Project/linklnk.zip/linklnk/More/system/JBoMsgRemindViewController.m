//
//  JBoMsgRemindViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMsgRemindViewController.h"
#import "JBoAppDelegate.h"
#import "JBoSystemOperation.h"
#import "UITableView+extraCellLine.h"

#define _controlInterval_ 5
#define _controlHeight_ 30

@class JBoMsgRemindCell;

@protocol JBoMsgRemindCellDelegate <NSObject>

- (void)msgRemindCellDidSelected:(JBoMsgRemindCell*) cell;

@end

/**消息提醒设置cell
 */
@interface JBoMsgRemindCell : UITableViewCell

/**设置开关
 */
@property(nonatomic,readonly) UISwitch *switchView;

/**设置的内容标题
 */
@property(nonatomic,readonly) UILabel *titleLabel;

@property(nonatomic,assign) id<JBoMsgRemindCellDelegate> delegate;

@end


@implementation JBoMsgRemindCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        CGFloat switchWidth = _ios7_0_ ? _switchWidth_7_ : _switchWidth__6_;
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_ * 3, _controlInterval_, _width_ - _controlInterval_ * 3 - switchWidth, _controlHeight_)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_titleLabel];

        _switchView = [[UISwitch alloc] initWithFrame:CGRectMake(self.bounds.size.width - switchWidth, _controlInterval_, switchWidth, _controlHeight_)];
        [_switchView addTarget:self action:@selector(didSelected:) forControlEvents:UIControlEventValueChanged];
        [self.contentView addSubview:_switchView];
        
        
    }
    
    return self;
}

- (void)didSelected:(UISwitch*) switchView
{
    if([self.delegate respondsToSelector:@selector(msgRemindCellDidSelected:)])
    {
        [self.delegate msgRemindCellDidSelected:self];
    }
}

- (void)dealloc
{
    [_titleLabel release];
    [_switchView release];
    
    [super dealloc];
}

@end

@interface JBoMsgRemindViewController ()<JBoMsgRemindCellDelegate>

/**消息设置内容
 */
@property(nonatomic,retain) NSMutableDictionary *setupDic;

@end

@implementation JBoMsgRemindViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"新消息提醒";
        _srcArray = [[NSArray alloc] initWithObjects:@"接受新消息推送", @"开启声音", @"开启震动", nil];
        
        self.setupDic = [JBoSystemOperation systemSetup];
    }
    return self;
}

- (void)dealloc
{
    [_srcArray release];
    [_tableView release];
    
    [_setupDic release];
    
    [super dealloc];
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor colorWithRed:243.0 / 255.0 green:245.0 / 255.0 blue:240.0 alpha:1.0];
	
    CGFloat cellHeight = 40;
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_ ) style:UITableViewStyleGrouped];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = cellHeight;
    [self.view addSubview:_tableView];
    
    [_tableView setExtraCellLineHidden];
}

#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoMsgRemindCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoMsgRemindCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    cell.titleLabel.text = [_srcArray objectAtIndex:indexPath.row];
    switch (indexPath.row)
    {
        case 0 :
        {
            cell.switchView.on = [[self.setupDic objectForKey:_pushAlert_] boolValue];
        }
            break;
        case 1 :
        {
            cell.switchView.on = [[self.setupDic objectForKey:_pushSound_] boolValue];
        }
            break;
        case 2 :
        {
            cell.switchView.on = [[self.setupDic objectForKey:_pushShake_] boolValue];
        }
            break;
        default:
            break;
    }
    return cell;
}

#pragma mark-JBoMsgRemindCell代理

- (void)msgRemindCellDidSelected:(JBoMsgRemindCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    
    switch (indexPath.row)
    {
        case 0 :
        {
            [JBoSystemOperation setPushAlert:cell.switchView.on];
            
            if(cell.switchView.on)
            {
                [JBoSystemOperation registerRemoteNotification];
            }
            else
            {
                [JBoSystemOperation unRegisterRemoteNotification];
            }
        }
            break;
            case 1 :
        {
            [JBoSystemOperation setPushSound:cell.switchView.on];
        }
            break;
            case 2 :
        {
            [JBoSystemOperation setShake:cell.switchView.on];
        }
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
