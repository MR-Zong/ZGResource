//
//  JBoPrivacyViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**隐私设置
 */
@interface JBoPrivacyViewController : JBoViewController<UITableViewDelegate,UITableViewDataSource>
{
    UITableView *_tableView;
    NSArray *_srcArray;
}

@end
