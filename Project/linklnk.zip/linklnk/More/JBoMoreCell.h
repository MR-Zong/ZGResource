//
//  JBoMoreCell.h
//  连你
//
//  Created by kinghe005 on 14-1-9.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoTableViewCell.h"
#import "JBoNumberBadge.h"

/**超级世界列表cell
 */
@interface JBoMoreCell : JBoTableViewCell

/**图标
 */
@property(nonatomic,readonly) UIImageView *iconImageView;

/**文本
 */
@property(nonatomic,readonly) UILabel *titleLabel;

/**红点
 */
@property(nonatomic,readonly) JBoNumberBadge *point;

/**行高
 */
+ (CGFloat)rowHeight;

@end
