//
//  JBoSystemSetupViewController.h
//  连客
//
//  Created by kinghe005 on 13-12-5.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JBoSystemSetupViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>
{
    UITableView *_tableView;
    NSArray *_srcArray;
}
@end
