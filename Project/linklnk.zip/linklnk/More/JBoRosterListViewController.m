//
//  JBoRosterListViewController.m
//  连客
//
//  Created by kinghe005 on 13-12-5.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoRosterListViewController.h"
#import "JBoCustomTabBarController.h"
#import "JBoContactListViewController.h"
#import "JBoLettersSearchBar.h"
#import "JBoRosterCell.h"
#import "ChineseToPinyin.h"
#import "GTMBase64.h"
#import "JBoDataPersist.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoImageTextTool.h"
#import "JBoUserOperation.h"


//搜索栏高度
#define _searchBarHeight_ 40
//section头的高度
#define _sectionHeaderHeight_ 20

@interface JBoRosterListViewController ()

@property(nonatomic,copy) NSIndexPath *indexPath;
@property(nonatomic,assign) BOOL searching;

@end

@implementation JBoRosterListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"通讯录";
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoRosterListViewController dealloc");
    
    [_keywordArray release];
    [_rosterDic release];
    
    [_tableView release];
    [_lettersView release];
    [_searchBar release];
    
    [_searchResultArray release];
    [_transparentView release];

    [_indexPath release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

#pragma mark-加载视图

- (void)cancelAction:(id) sender
{
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    JBoCustomTabBarController *cunstomTabBarVC = (JBoCustomTabBarController*)self.appDelegate.window.rootViewController;
    
    JBoContactListViewController *contactListVC = nil;
    UINavigationController *nav = (UINavigationController*)[cunstomTabBarVC.navigationControllers objectAtIndex:cunstomTabBarVC.addressBookIndex];
    for(UIViewController *VC in nav.viewControllers)
    {
        if([VC isKindOfClass:[JBoContactListViewController class]])
        {
            contactListVC = (JBoContactListViewController*)VC;
            break;
        }
    }
    
    _keywordArray = [[NSMutableArray alloc] init];
    _rosterDic = [[NSMutableDictionary alloc] init];

    _searchResultArray = [[NSMutableArray alloc] init];
    
    if(self.rosterOprationType != JBoRosterOperationTypeLinkCloundURL)
    {
        self.black = NO;
        [self setGreenNavigationBar];
        [self setRightBarItemWithTitle:@"取消" action:@selector(cancelAction:)];
    }
    else
    {
        self.backItem = YES;
    }
        
    //过滤掉普通用户
    switch (self.rosterOprationType)
    {
        case JBoRosterOperationTypeSharelink:
        {
            [_keywordArray addObjectsFromArray:contactListVC.keywordArray];
            [_rosterDic addEntriesFromDictionary:contactListVC.rosterDic];
        }
            break;
        case JBoRosterOperationTypeLinkCloundURL :
        case JBoRosterOperationTypeLogoDownload :
        {
            {
                for(NSString *key in contactListVC.keywordArray)
                {
                    NSArray *array = [contactListVC.rosterDic objectForKey:key];
                    
                    NSMutableArray *infoArray = [[NSMutableArray alloc] init];
                    for(JBoRosterInfo *info in array)
                    {
                        if(info.role != _rosterRoleNormal_)
                        {
                            [infoArray addObject:info];
                        }
                    }
                    if(infoArray.count > 0)
                    {
                        [_keywordArray addObject:key];
                        [_rosterDic setObject:infoArray forKey:key];
                    }
                    
                    [infoArray release];
                }
//                [_keywordArray removeObject:_linklnkKey_];
//                [_rosterDic removeObjectForKey:_linklnkKey_];
            }
        }
            break;
        default:
        {
            [_keywordArray addObjectsFromArray:contactListVC.keywordArray];
            [_rosterDic addEntriesFromDictionary:contactListVC.rosterDic];
        }
            break;
    }
    
    if(_keywordArray.count == 0)
    {
        switch (self.rosterOprationType)
        {
            case JBoRosterOperationTypeLinkCloundURL :
            case JBoRosterOperationTypeLogoDownload :
            {
                [self alertMsg:@"您还没实名认证的好友"];
            }
                break;
                
            default:
                break;
        }
    }
    else
    {
        //创建tableview
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorColor = [UIColor grayColor];
        _tableView.rowHeight = _rosterCellHeight_;
#ifdef __IPHONE_7_0
        if(_ios7_0_)
        {
            _tableView.separatorInset = UIEdgeInsetsMake(0, _letterViewWidth_, 0, _letterViewWidth_);
        }
#endif
        [_tableView setExtraCellLineHidden];
        [self.view addSubview:_tableView];
        
        
        //创建搜索栏背
        _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
        _searchBar.placeholder = @"搜索";
        _searchBar.delegate = self;
        if(!_ios7_0_)
        {
            _searchBar.tintColor = _searchBarColor_;
        }
        _tableView.tableHeaderView = _searchBar;
        
        //创建通讯录字母搜索视图
        _lettersView = [[JBoLettersSearchBar alloc] initWithFrame:CGRectMake(_width_ - _letterViewWidth_, 0, _letterViewWidth_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        [_lettersView addTarget:self action:@selector(letterTouchedAction)];
        [self.view addSubview:_lettersView];
    }
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
   
}

//字母选择
- (void)letterTouchedAction
{
    NSString *letter = _lettersView.touchLetter;
    if([_keywordArray containsObject:letter])
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:[_keywordArray indexOfObject:letter]];
        [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

//取消搜索方法
- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    if(!_transparentView)
    {
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;

        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        [self.view addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    _lettersView.hidden = YES;
    [_searchBar setShowsCancelButton:YES animated:YES];
    [_tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [_searchBar setShowsCancelButton:NO animated:YES];
    _transparentView.hidden = YES;
    _lettersView.hidden = NO;
    [_tableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        char c = [ChineseToPinyin sortSectionTitle:content];
        if(c > 'a' && c < 'z')
            c = c - 32;
        
        NSArray *array = [_rosterDic objectForKey:[NSString stringWithFormat:@"%c",c]];
        
        if(array)
        {
            [_searchResultArray removeAllObjects];
            
            for(JBoRosterInfo *rosterInfo in array)
            {
                NSString *name = [ChineseToPinyin pinyinFromChiniseString:rosterInfo.name];
                NSLog(@"%@",name);
                if(name.length < pinyin.length)
                {
                    continue;
                }
                
                NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
                NSLog(@"sub = %@",subStr);
                if([pinyin isEqualToString:subStr])
                {
                    [_searchResultArray addObject:rosterInfo];
                }
            }
        }
        
        
        for(NSString *str in _keywordArray)
        {
            NSArray *infos = [_rosterDic objectForKey:str];
            
            for(JBoRosterInfo *info in infos)
            {
                NSRange range = [info.name rangeOfString:content];
                
                if(range.length > 0 && (![_searchResultArray containsObject:info]))
                {
                    [_searchResultArray addObject:info];
                }
            }
        }
    }
    if(_searchResultArray.count > 0)
    {
        [_tableView reloadData];
        _transparentView.hidden = YES;
    }
    else
    {
        _transparentView.hidden = NO;
    }
}


#pragma mark-tableview代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
        return 1;
    else
        return _keywordArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *array = [_rosterDic objectForKey:[_keywordArray objectAtIndex:section]];
    NSInteger count = array.count;
    if(self.searching)
        count = _searchResultArray.count;
    
    return count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    
    JBoRosterCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoRosterCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoRosterInfo *rosterInfo = nil;
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    
    cell.nameLabel.text = rosterInfo.name;
    cell.nameLabel.sex = rosterInfo.sex;
    cell.headImageView.role = rosterInfo.role;
    
    [cell setPresence:rosterInfo.presence];
    
    cell.headImageView.sex = rosterInfo.sex;
    cell.headImageView.headImageURL = rosterInfo.imageURL;

    return cell;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching || section == 0)
        return nil;
    UIView *view = nil;
    NSString *title = [_keywordArray objectAtIndex:section];
    
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"headerIdentifier";
        JBoAddressBookSectionHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[JBoAddressBookSectionHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.headerView.titleLabl.text = title;
        view = header;
#endif
    }
    else
    {
        JBoAddressBookSectionHeaderView *header = [[[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)] autorelease];
        header.titleLabl.text = title;
        view = header;
    }
    
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching || section == 0)
        return 0;
    
    return _sectionHeaderHeight_;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    JBoRosterInfo *rosterInfo = nil;
    
    if(self.searching)
    {
        rosterInfo = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        rosterInfo = [[_rosterDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    
    if([self.delegate respondsToSelector:@selector(viewController:didSelectRosterInfo:)])
    {
        [self.delegate viewController:self didSelectRosterInfo:rosterInfo];
        return;
    }
    
    switch (self.rosterOprationType)
    {
        case JBoRosterOperationTypeLogoDownload :
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:_didSelectedContactNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:rosterInfo forKey:_selectedRosterInfo_]];
        }
        default:
            break;
    }
    
    [self cancelAction:nil];
    [_searchBar resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
