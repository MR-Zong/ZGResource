//
//  JBoMoreInfo.m
//  linklnk
//
//  Created by kinghe005 on 15-3-20.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoMoreInfo.h"

@implementation JBoMoreInfo

- (void)dealloc
{
    [_icon release];
    [_title release];
    
    [super dealloc];
}

/**遍历构造方法
 */
+ (id)infoWithIcon:(UIImage*) icon title:(NSString*) title
{
    JBoMoreInfo *info = [[[JBoMoreInfo alloc] init] autorelease];
    info.icon = icon;
    info.title = title;
    
    return info;
}

/**便利构造方法
 *@param type 类型，会根据类型设置图标和标题
 *@return 一个实例
 */
+ (id)infoWithType:(JBoMoreInfoType) type
{
    NSString *title = nil;
    NSString *imageName = nil;
    
    JBoMoreInfo *info = [[[JBoMoreInfo alloc] init] autorelease];
    info.type = type;
    
    switch (info.type)
    {
        case JBoMoreInfoTypeImageEdit :
        {
            title = @"超图+";
            imageName = @"more_imageEdit";
        }
            break;
        case JBoMoreInfoTypeMe :
        {
            title = @"我";
            imageName = @"more_me";
        }
            break;
        case JBoMoreInfoTypeQRCode :
        {
            title = @"扫一扫";
            imageName = @"more_qrcode";
        }
            break;
        case JBoMoreInfoTypeTTS :
        {
            title = @"超语音+";
            imageName = @"more_speek";
        }
            break;
        case JBoMoreInfoTypeSetup :
        {
            title = @"系统设置";
            imageName = @"more_setup";
        }
            break;
        default:
            break;
    }
    
    info.icon = [UIImage imageNamed:imageName];
    info.title = title;
    
    return info;
}

@end
