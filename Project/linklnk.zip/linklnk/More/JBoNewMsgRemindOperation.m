//
//  JBoNewMsgRemidOperation.m
//  靓咖
//
//  Created by kinghe005 on 14-6-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoNewMsgRemindOperation.h"
#import "ASINetworkQueue.h"
#import "ASIHTTPRequest.h"
#import "JBoSystemOperation.h"
#import "JBoLookAndTellOperation.h"
#import "JBoHelpOperation.h"
#import <CoreLocation/CoreLocation.h>
#import "JBoFileManager.h"
#import "JSONKit.h"
#import "JBoDatetimeTool.h"
#import "JBoUserOperation.h"
#import "BMapKit.h"

#define _lastTimeTag_ 1
#define _circleTag_ 2
#define _secretTag_ 3

static NSString *const newMsgRemindState = @"newMsgRemind";

@interface JBoNewMsgRemindOperation ()

@property(nonatomic,retain) ASINetworkQueue *queue;

//附近秘密和靓友圈的最后访时间
@property(nonatomic,retain) NSDictionary *lastTimeDic;

//靓友圈的最新消息时间
@property(nonatomic,copy) NSString *circleLastTime;
//附近秘密的最新消息时间
@property(nonatomic,copy) NSString *secretLastTime;

@end

@implementation JBoNewMsgRemindOperation

- (id)init
{
    self = [super init];
    if(self)
    {
        
    }
    return self;
}

- (void)dealloc
{
    NSLog(@"JBoNewsMsgRemidOperation dealloc");
    [_queue reset];
    [_queue release];
    
    [_lastTimeDic release];
    
    [_circleLastTime release];
    [_secretLastTime release];
    
    Block_release(_completionHandler);
    
    [super dealloc];
}

#pragma mark- public method

- (void)start
{
    if(self.queue)
        return;
  
    [self requestMsg];
}

- (void)cancle
{
    [self.queue reset];
    self.queue = nil;
}

#pragma mark- private method

- (void)requestMsg
{
    if(self.queue)
        return;
    
    self.queue = [ASINetworkQueue queue];
    [self.queue setDelegate:self];
    [self.queue setRequestDidFinishSelector:@selector(reuquestDidFinished:)];
    [self.queue setQueueDidFinishSelector:@selector(queueDidFinish:)];
    
    //获取最后访问时间
    [self requestWithURL:[JBoSystemOperation getLastRequestTime] tag:_lastTimeTag_];
    
    JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
    
    //获取最新的附近秘密
    [self requestWithURL:[JBoSystemOperation getAroundSecretLastestTimeWithCoordinate:CLLocationCoordinate2DMake(info.defalutAddrLat, info.defaultAddrLon) radius:_helpRadiusDefaultValue_] tag:_secretTag_];
    
    //获取最新靓友圈信息
    [self requestWithURL:[JBoSystemOperation getLookAndTellCircleLastestTime] tag:_circleTag_];
    [self.queue go];
}

- (void)requestWithURL:(NSString*) url tag:(NSInteger) tag
{
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:url]];
    request.timeOutSeconds = 30.0;
    request.cachePolicy = ASIDoNotReadFromCacheCachePolicy;
    request.tag = tag;
    request.downloadDestinationPath = [JBoFileManager getTemporaryFile];
    [self.queue addOperation:request];
}

- (void)reuquestDidFinished:(ASIHTTPRequest*) request
{
    NSData *data = [NSData dataWithContentsOfFile:request.downloadDestinationPath];
    switch (request.tag)
    {
        case _lastTimeTag_ :
        {
            self.lastTimeDic = [JBoSystemOperation getLastRequestTimeFromData:data];
        }
            break;
        case _secretTag_ :
        {
            self.secretLastTime = [JBoSystemOperation getAroundSecretLastestTimeFromData:data];
        }
            break;
        case _circleTag_ :
        {
            self.circleLastTime = [JBoSystemOperation getLookAndTellCircleLastestTimeFromData:data];
        }
            break;
        default:
            break;
    }
}

- (void)queueDidFinish:(ASINetworkQueue*) queue
{
    if(self.completionHandler)
    {
        NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:2];
        
        BOOL circleResult = NO;
        if(self.circleLastTime != nil)
        {
            circleResult = [JBoDatetimeTool isTimeExpired:1 withOldTime:[self.lastTimeDic objectForKey:_lookAndTellCircleLastTime_] otherTime:self.circleLastTime];
            
            NSLog(@"%d",circleResult);
        }
        
        
        [dic setObject:[NSNumber numberWithBool:circleResult] forKey:_lookAndTellCircleRemind_];
        NSLog(@"circle %d", circleResult);
        
        BOOL secretResult = NO;
        if(self.secretLastTime != nil)
        {
            secretResult = [JBoDatetimeTool isTimeExpired:1 withOldTime:[self.lastTimeDic objectForKey:_assitLastTime_] otherTime:self.secretLastTime];
        }
        
        [dic setObject:[NSNumber numberWithBool:secretResult] forKey:_aroundSecretRemind_];
        NSLog(@"secret %d",secretResult);
        
        self.completionHandler(dic);
    }
}


//#pragma mark- 定位
//
//- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
//{
//    NSLog(@"定位失败");
//    self.locationFail = YES;
//    [manager stopUpdatingLocation];
//    manager.delegate = nil;
//    [self requestMsg];
//}
//
//- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
//{
//    CLLocation *location = [locations firstObject];
//    NSDictionary *dic = BMKBaiduCoorForWgs84(location.coordinate);
//    self.coordinate = BMKCoorDictionaryDecode(dic);
//    NSLog(@"%f,%f,", _coordinate.latitude, _coordinate.longitude);
//    
//    [manager stopUpdatingLocation];
//    manager.delegate = nil;
//    [self requestMsg];
//}
//
//- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
//{
//    NSDictionary *dic = BMKBaiduCoorForWgs84(newLocation.coordinate);
//    self.coordinate = BMKCoorDictionaryDecode(dic);
//    
//    NSLog(@"%f,%f,", _coordinate.latitude, _coordinate.longitude);
//    
//    [manager stopUpdatingLocation];
//    manager.delegate = nil;
//    [self requestMsg];
//}

#pragma mark- class method

//设置标记
+ (void)setNewMsgRemindState:(NSDictionary *)state
{
    if(![state isKindOfClass:[NSDictionary class]])
        return;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *histroyDic = [defaults objectForKey:newMsgRemindState];
    
    NSMutableDictionary *mutableHistoryDic = nil;
    
    if([histroyDic isKindOfClass:[NSDictionary class]])
    {
        mutableHistoryDic = [NSMutableDictionary dictionaryWithDictionary:histroyDic];
    }
    else
    {
        mutableHistoryDic = [NSMutableDictionary dictionaryWithCapacity:1];
    }
    
    [mutableHistoryDic setObject:state forKey:[JBoUserOperation getUserId]];
    [defaults setObject:mutableHistoryDic forKey:newMsgRemindState];
    [defaults synchronize];
}

+ (NSDictionary*)getNewMsgRemindState
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *histroyDic = [defaults objectForKey:newMsgRemindState];
    
    if([histroyDic isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *state = [histroyDic objectForKey:[JBoUserOperation getUserId]];
        if([state isKindOfClass:[NSDictionary class]])
        {
            return state;
        }
    }
    return nil;
}

@end
