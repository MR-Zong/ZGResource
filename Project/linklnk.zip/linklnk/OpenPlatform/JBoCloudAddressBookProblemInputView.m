//
//  JBoCloudAddressBookProblemInputView.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookProblemInputView.h"
#import "JBoAppDelegate.h"
#import "JBoCloudAddressBookProblemInfo.h"
#import "JBoCustomInsetLabel.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoImageTextTool.h"
#import "JBoUserOperation.h"
#import "SSTextView.h"

#define _padding_ 15.0
#define _controlHeight_ 35.0

@interface JBoCloudAddressBookProblemInputView ()

//验证问题信息 infos 数组元素是JBoCloudAddressBookProblemInfo对象
@property(nonatomic,retain) NSArray *infos;

//确定按钮
@property(nonatomic,assign) UIButton *confirmButton;

//取消按钮
@property(nonatomic,assign) UIButton *cancelButton;

//需要回答的问题
@property(nonatomic,retain) JBoCustomInsetLabel *problemLabel;

//选中的问题
@property(nonatomic,assign) NSInteger selectedIndex;

//问题选择列表
@property(nonatomic,retain) UITableView *tableView;

//选择问题按钮
@property(nonatomic,retain) UIImageView *moreImageView;

//键盘是否隐藏
@property(nonatomic,assign) BOOL keyboardHidden;

//视图本身原始高度
@property(nonatomic,assign) CGFloat orgHeight;

@end

@implementation JBoCloudAddressBookProblemInputView

/**以问题信息初始化
 *@param infos 数组元素是JBoCloudAddressBookProblemInfo对象
 *@param style 云通讯录验证问题信息输入类型
 */
- (id)initWithFrame:(CGRect)frame infos:(NSArray *)infos style:(JBoCloudAddressBookProblemInputStyle)style
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //添加键盘监听
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppearance:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillDisAppearance:) name:UIKeyboardWillHideNotification object:nil];
        //添加键盘frame改变通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameWillChanged:) name:UIKeyboardWillChangeFrameNotification object:nil];
        
        self.orgHeight = self.height;
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        self.infos = infos;
        _style = style;
        
        CGFloat y = 0;
        if(style != JBoCloudAddressBookProblemInputStyleReply)
        {
            //问题输入框
            _problemTextView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, _controlHeight_ * 2)];
            _problemTextView.layer.cornerRadius = 6;
            //_problemTextView.layer.borderWidth = 0.2;
            //_problemTextView.layer.borderColor = [UIColor grayColor].CGColor;
            _problemTextView.font = [UIFont systemFontOfSize:17];
            _problemTextView.delegate = self;
            _problemTextView.maxCount = _inputFormatCloudAddressBookProbleName_;
            _problemTextView.limitable = YES;
            _problemTextView.placeholder = @"问题";
            _problemTextView.returnKeyType = UIReturnKeyDone;
            [self addSubview:_problemTextView];
    
            y = _problemTextView.bottom + _padding_;
        }
        else
        {
            UILabel *alertLabel = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, 0, _width_ - _padding_ * 2, 45.0)];
            alertLabel.backgroundColor = [UIColor clearColor];
            alertLabel.font = [UIFont systemFontOfSize:14.0];
            alertLabel.textColor = [UIColor blackColor];
            //alertLabel.textAlign = JBoTextAlignmentCenter;
            alertLabel.text = @"该用户已设置了安全验证问题，您需要验证后才能添加";
            alertLabel.numberOfLines = 0;
            [self addSubview:alertLabel];
            [alertLabel release];
            
            JBoCustomInsetLabel *label = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(_padding_, alertLabel.bottom + _padding_, _width_ - _padding_ * 2, _controlHeight_)];
            label.backgroundColor = [UIColor whiteColor];
            label.insets = UIEdgeInsetsMake(0, 5.0, 0, 30.0);
            label.textColor = [UIColor blackColor];
            
            JBoCloudAddressBookProblemInfo *info = [self.infos firstObject];
            label.text = info.problem;
            self.selectedIndex = 0;
            [self setViewLayer:label];
            
            [self addSubview:label];
            self.problemLabel = label;
            [label release];
            y = label.bottom + _padding_;
            
            //添加点击手势
            UITapGestureRecognizer *more = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectProblem)];
            label.userInteractionEnabled = YES;
            [label addGestureRecognizer:more];
            [more release];
            
            //右边查看更多问题
            UIImage *normalImage = [UIImage imageNamed:@"down_Arrow"];
            UIImageView *imageView = [[UIImageView alloc] initWithImage:normalImage];
            [label addSubview:imageView];
            self.moreImageView = imageView;
            [imageView release];
            
            [self setNeedsLayout];
        }
        
        //答案输入框
        _answerTextView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, y, _width_ - _padding_ * 2, _controlHeight_ * 2)];
        _answerTextView.layer.cornerRadius = 6;
       // _answerTextView.layer.borderWidth = 0.2;
       // _answerTextView.layer.borderColor = [UIColor grayColor].CGColor;
        _answerTextView.font = [UIFont systemFontOfSize:17];
        _answerTextView.delegate = self;
        _answerTextView.maxCount = _inputFormatCloudAddressBookProbleName_;
        _answerTextView.limitable = YES;
        _answerTextView.placeholder = @"答案";
        _answerTextView.returnKeyType = UIReturnKeyDone;
        [self addSubview:_answerTextView];
        
        CGFloat buttonWidth = 100.0;
        CGFloat buttonHeight = 35.0;
        CGFloat interval = (self.width - buttonWidth * 2) / 3.0;
        
        //取消按钮
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:@"取消" forState:UIControlStateNormal];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn setBackgroundColor:_navigationBarBackgroundDefaultColor_];
        btn.layer.cornerRadius = 5.0;
        btn.layer.masksToBounds = YES;
        [btn setShowsTouchWhenHighlighted:YES];
        [btn addTarget:self action:@selector(close:) forControlEvents:UIControlEventTouchUpInside];
        [btn setFrame:CGRectMake(interval, _answerTextView.bottom + _padding_ * 2, buttonWidth, buttonHeight)];
        [self addSubview:btn];
        self.cancelButton = btn;
        
        //完成按钮
        btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setTitle:@"确定" forState:UIControlStateNormal];
        [btn setFrame:CGRectMake(self.width - interval - buttonWidth, self.cancelButton.top, self.cancelButton.width, self.cancelButton.height)];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn setBackgroundColor:_navigationBarBackgroundDefaultColor_];
        btn.layer.cornerRadius = 5.0;
        btn.layer.masksToBounds = YES;
        [btn setShowsTouchWhenHighlighted:YES];
        [btn addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:btn];
        self.confirmButton = btn;
        
        self.contentSize = CGSizeMake(self.width, self.confirmButton.bottom + _padding_ * 2);
    }
    return self;
}


- (void)dealloc
{
    self.delegate = nil;
    [_infos release];
    
    [_problemTextView release];
    [_answerTextView release];
    [_problemLabel release];
    [_tableView release];
    [_moreImageView release];
    
    self.confirmButton = nil;
    self.cancelButton = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
    
    [super dealloc];
}

#pragma mark- 键盘

- (void)keyboardWillAppearance:(NSNotification*) notification
{
    self.keyboardHidden = NO;
    [self setupTableViewFrameWithUserInfo:[notification userInfo]];
}

- (void)keyboardWillDisAppearance:(NSNotification*) notification
{
    self.keyboardHidden = YES;
    [self setupTableViewFrameWithUserInfo:[notification userInfo]];
}

- (void)keyboardFrameWillChanged:(NSNotification*) notification
{
    [self setupTableViewFrameWithUserInfo:[notification userInfo]];
}

- (void)setupTableViewFrameWithUserInfo:(NSDictionary*) userInfo
{
    //获取键盘高度
    NSValue *keyboardValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [keyboardValue CGRectValue];
    
    //获取键盘动画时间
    NSNumber *animateDurationNumber = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    float animationDuration = [animateDurationNumber floatValue];
    CGFloat height = keyboardRect.size.height;
    
    if(self.keyboardHidden)
        height = 0;
    [UIView animateWithDuration:animationDuration animations:^(void)
     {
         self.height = self.orgHeight - height;
     }completion:^(BOOL finish)
     {
         if(self.keyboardHidden)
         {
            [self setContentOffset:CGPointZero animated:YES];
         }
     }];
}

#pragma mark- public method

/**显示视图
 */
- (void)showInView:(UIView *)view
{
    [view addSubview:self];
    self.top = _height_;
    [UIView animateWithDuration:0.25 animations:^(void){
        self.top = 0;
    }];
}

/**关闭视图
 */
- (void)dismiss
{
    [UIView animateWithDuration:0.25 animations:^(void){
        
        self.top = _height_;
    }completion:^(BOOL finish){
       
        [self removeFromSuperview];
        if([self.inputDelegate respondsToSelector:@selector(cloudAddressBookProblemInputViewDidDismiss:)])
        {
            [self.inputDelegate cloudAddressBookProblemInputViewDidDismiss:self];
        }
    }];
}

#pragma mark- private method

- (void)setViewLayer:(UIView*) view
{
    view.layer.cornerRadius = 5.0;
    view.layer.masksToBounds = YES;
}

//关闭
- (void)close:(id) sender
{
    [self dismiss];
}

//完成
- (void)confirmAction:(id) sender
{
    switch (self.style)
    {
        case JBoCloudAddressBookProblemInputStyleAdd :
        case JBoCloudAddressBookProblemInputStyleModify :
        {
            if([NSString isEmpty:_problemTextView.text])
            {
                [JBoUserOperation alertMsg:@"问题不能为空"];
                return;
            }
            
            if(_problemTextView.text.length > _inputFormatCloudAddressBookProbleName_)
            {
                [JBoUserOperation alertMsg:[NSString stringWithFormat:@"问题不能超过%d个字", _inputFormatCloudAddressBookProbleName_]];
                return;
            }
            
            if([NSString isEmpty:_answerTextView.text])
            {
                [JBoUserOperation alertMsg:@"答案不能为空"];
                return;
            }
            
            if(_answerTextView.text.length > _inputFormatCloudAddressBookProbleAnswer_)
            {
                [JBoUserOperation alertMsg:[NSString stringWithFormat:@"答案不能超过%d个字", _inputFormatCloudAddressBookProbleAnswer_]];
                return;
            }
            
            if([self.inputDelegate respondsToSelector:@selector(cloudAddressBookProblemInputViewDidFinish:)])
            {
                [self.inputDelegate cloudAddressBookProblemInputViewDidFinish:self];
            }
        }
            break;
        case JBoCloudAddressBookProblemInputStyleReply :
        {
            if([NSString isEmpty:_answerTextView.text])
            {
                [JBoUserOperation alertMsg:@"答案不能为空"];
                return;
            }
            
            JBoCloudAddressBookProblemInfo *info = [self.infos objectAtIndex:self.selectedIndex];
            if(![_answerTextView.text isEqualToString:info.answer])
            {
                [JBoUserOperation alertMsg:@"答案不正确"];
                return;
            }
            
            if([self.inputDelegate respondsToSelector:@selector(cloudAddressBookProblemInputViewDidFinish:)])
            {
                [self.inputDelegate cloudAddressBookProblemInputViewDidFinish:self];
            }
        }
            break;
        default:
            break;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    if(self.problemLabel)
    {
        CGSize size = [JBoImageTextTool getStringSize:self.problemLabel.text withFont:self.problemLabel.font andContraintSize:CGSizeMake(self.problemLabel.width - self.problemLabel.insets.left - self.problemLabel.insets.right, _maxFloat_)];
        if(size.height < _controlHeight_)
        {
            size.height = _controlHeight_;
        }
        
        self.problemLabel.height = size.height;
        self.moreImageView.center = CGPointMake(self.problemLabel.width - self.moreImageView.width, self.problemLabel.height / 2.0);
        self.answerTextView.top = self.problemLabel.bottom + _padding_;
        
        self.cancelButton.top = self.answerTextView.bottom + _padding_ * 2;
        self.confirmButton.top = self.cancelButton.top;
        
        self.contentSize = CGSizeMake(self.width, self.confirmButton.bottom + _padding_ * 2);
    }
}

//选择问题
- (void)selectProblem
{
    CGFloat rowHeight = 35.0;
    if(!_tableView)
    {
        CGRect frame = _problemLabel.frame;
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(frame.origin.x + 1, frame.origin.y + frame.size.height + 1, frame.size.width - 2, 0) style:UITableViewStylePlain];
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.rowHeight = rowHeight;
        tableView.layer.cornerRadius = 5.0;
        tableView.layer.masksToBounds = YES;
        tableView.hidden = YES;
        [self.problemLabel.superview addSubview:tableView];
        self.tableView = tableView;
        [tableView release];
    }
    
    NSInteger rows = _infos.count > 3 ? 3 : _infos.count;
    _tableView.frame = CGRectMake(_tableView.frame.origin.x, _tableView.frame.origin.y, _tableView.frame.size.width, rowHeight * rows);
    _tableView.hidden = !_tableView.hidden;
}

#pragma mark- tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infos.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.textLabel.font = [UIFont systemFontOfSize:15.0];
    }
    
    JBoCloudAddressBookProblemInfo *info = [self.infos objectAtIndex:indexPath.row];
    
    cell.textLabel.text = info.problem;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.selectedIndex = indexPath.row;
    
    JBoCloudAddressBookProblemInfo *info = [self.infos objectAtIndex:indexPath.row];
    self.problemLabel.text = info.problem;
    [self selectProblem];
    [self setNeedsLayout];
}

#pragma mark- textView代理

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self setContentOffset:CGPointMake(0, textView.top - _padding_ * 2) animated:YES];
}

- (void)textViewDidChange:(UITextView *)textView
{
    SSTextView *sst = (SSTextView*)textView;
    [sst textDidChange];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    
    SSTextView *sst = (SSTextView*)textView;
    
    return [sst shouldChangeTextInRange:range replacementText:text];
}

@end
