//
//  JBoOpenPlatformSubscribeInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**云名片预约信息
 */
@interface JBoOpenPlatformSubscribeInfo : NSObject

/**信息Id
 */
@property(nonatomic,assign) long long Id;

/**电话号码
 */
@property(nonatomic,copy) NSString *tel;

/**名称
 */
@property(nonatomic,copy) NSString *name;

/**时间
 */
@property(nonatomic,copy) NSString *time;

@end
