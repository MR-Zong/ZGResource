//
//  JBoCloudAddressBookProblemInfo.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**云通讯录验证问题信息
 */
@interface JBoCloudAddressBookProblemInfo : NSObject

/**信息Id
 */
@property(nonatomic,assign) long long Id;

/**问题
 */
@property(nonatomic,copy) NSString *problem;

/**答案
 */
@property(nonatomic,copy) NSString *answer;

@end
