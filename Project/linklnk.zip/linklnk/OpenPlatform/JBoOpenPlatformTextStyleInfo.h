//
//  JBoOpenPlatformTextStyleInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-10-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**小字体
 */
#define _JBoOpenPlatformTextStyleFontSmallSize_ 13.0

/**中字体
 */
#define _JBoOpenPlatformTextStyleFontMiddleSize_ 16.0

/**大字体
 */
#define _JBoOpenPlatformTextStyleFontBigSize_ 20.0

/**云名片文本样式信息
 */
@interface JBoOpenPlatformTextStyleInfo : NSObject

/**字体颜色
 */
@property(nonatomic,retain) UIColor *textColor;

/**样式名称
 */
@property(nonatomic,copy) NSString *styleName;

/**是否是粗体
 */
@property(nonatomic,assign) BOOL bold;

/**样式范围
 */
@property(nonatomic,assign) NSRange textRange;

/**字体大小 defualt is '中字体'
 */
@property(nonatomic,assign) int fontSize;

/**背景颜色 default is 'nil'
 */
@property(nonatomic,retain) UIColor *backgroundColor;

/**获取范围的字符串
 */
- (NSString*)stringRange;

/**获取样式字典
 *@param length 所属文本的长度
 *@param flag 显示字体的控件是否是使用coreText的
 */
- (NSDictionary*)attributesWithContentLength:(NSInteger) length isCoreText:(BOOL) flag;

/**是否是默认值 普通字段，黑色
 */
- (BOOL)isDefaultValue;

#pragma mark- class method

/**把重复的样式设置分离出来
 *@param infos 原有的样式，数组元素是 JBoOpenPlatformTextStyleInfo 对象
 *@param textLength 文本长度
 */
+ (void)resetWithTextStyleInfos:(NSMutableArray*) infos textLength:(NSInteger) textLength;

/**从字符串中获取范围
 *@param string 字符串
 *@return NSRange范围
 */
+ (NSRange)rangeFromString:(NSString*) string;

/**文本改变，样式范围修复
 *@param infos 原有的样式，数组元素是 JBoOpenPlatformTextStyleInfo 对象
 *@param 要改变的范围
 *@param text 新的文本
 */
+ (void)adjustTextStyleInfos:(NSMutableArray*) infos WithRange:(NSRange) range replacedText:(NSString*) text;

/**样式排序
 *@param infos 原有的样式，数组元素是 JBoOpenPlatformTextStyleInfo 对象
 */
+ (void)sortTextStyleInfos:(NSMutableArray*) infos;

/**从文本中提取样式
 *@param 样式文本attributedString
 *@return 数组元素是 JBoOpenPlatformTextStyleInfo 对象
 */
+ (NSMutableArray*)textStyleInfosFromAttributedString:(NSAttributedString*) attributedString;

/**默认文本属性
 */
+ (NSDictionary*)defaultOpenPlatformAttributes;


/**支持的字体颜色
 *@return 数组元素是 UIColor 
 */
+ (NSArray*)supportedTextColors;

/**支持的字体
 *@return 数组元素是 NSString fontName
 */
+ (NSArray*)supportedFontNames;

/**支持的字体大小
 *@return 数组元素是 NSNumber floatValue
 */
+ (NSArray*)supportedFontSizes;

@end
