//
//  JBoOpenPlatformCell.h
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoDateView.h"
#import "JBoCheckBox.h"
#import "JBoImageTextLabel.h"
#import "JBoOpenPlatformMultiTextView.h"
#import "JBoLinkShareView.h"

#define _openPlatformDateLabelWidth_ 60
#define _openPlatformDateInnerPadding_ 15.0
#define _openPlatformDateButtonHeight_ 30.0

#define _openPlatformQRCodeImageWidth_ 30.0
#define _openPlatformQRCodeImageHeight_ 30.0

#define _openPlatformImageWitdh_ (_multiSize_ * _imagesPerRows_ + _multiImageInterval_ * (_imagesPerRows_ - 1))

#define _openPlatformAddressFont_ [UIFont systemFontOfSize:12.0]
#define _openPlatformAddressIconWidth_ 20.0
#define _openPlatformAddressMinHeight_ 20.0
#define _openPlatformAddressWitdh_ (_openPlatformImageWitdh_ - _openPlatformAddressIconWidth_)

//文字与图片的距离
#define _openPlatformTextImagePadding_ 10.0

//链接样式的高度
#define _openPlatformLinkViewHeight_ 70.0

/**云名片信息cell的类型
 */
typedef NS_ENUM(NSInteger, JBoOpenPlatformCellStyle)
{
    JBoOpenPlatformCellStyleImageText = 0, //图文
    JBoOpenPlatformCellStyleLink = 1, //链接
    JBoOpenPlatformCellStyleMall = 2, //商城
};

@class JBoOpenPlatformCell;
@class JBoCustomInsetLabel;

/**云名片信息cell的代理
 */
@protocol JBoOpenPlatformCellDelegate <NSObject>

/**选择图片
 */
- (void)openPlatformCell:(JBoOpenPlatformCell*) cell didSelectedImageAtIndex:(NSInteger) index;

/**长按图片
 */
- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didLongPressedImageAtIndex:(NSInteger)index;

/**删除信息
 */
- (void)openPlatformCellDidDelete:(JBoOpenPlatformCell *)cell;

/**设置可见范围
 */
- (void)openPlatformCellSetupVisible:(JBoOpenPlatformCell *)cell;

/**置顶
 */
- (void)openPlatformCellSetupStick:(JBoOpenPlatformCell*) cell;

/**更新排序
 */
- (void)openPlatformCellUpdateOrder:(JBoOpenPlatformCell *)cell;

/**移动排序
 */
- (void)openPlatformCellDidMove:(JBoOpenPlatformCell *)cell;

/**选中checkBox
 */
- (void)openplatformCellDidSelectedCheckBox:(JBoOpenPlatformCell*) cell;

/**删除文本信息
 */
- (void)openPlatformCell:(JBoOpenPlatformCell*) cell didRemoveTextInfoAtIndex:(NSInteger) index;

/**修改文本信息
 */
- (void)openPlatformCell:(JBoOpenPlatformCell*) cell didModifyTextInfoAtIndex:(NSInteger) index;

/**添加文本信息
 */
- (void)openPlatformCell:(JBoOpenPlatformCell*) cell didAddTextInfoAtIndex:(NSInteger) index;

/**添加图片信息
 */
- (void)openPlatformCellDidAddImage:(JBoOpenPlatformCell *)cell;

/**修改样式
 */
- (void)openPlatformCellDidModifyWebStyle:(JBoOpenPlatformCell*) cell;

/**修改云名片标题
 */
- (void)openPlatformCellDidModifyTitle:(JBoOpenPlatformCell*) cell;

/**云名片信息展开状态改变
 */
- (void)openPlatformCellExpandDidChanged:(JBoOpenPlatformCell*) cell;

/**点击链接
 */
- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didSelectURL:(NSURL*) url;

/**查看预约的人
 */
- (void)openPlatformCellDidSubscribe:(JBoOpenPlatformCell *)cell;

/**点击二维码图片
 */
- (void)openplatformCellDidSelectQRCodeImage:(JBoOpenPlatformCell*) cell;

/**更新地址
 */
- (void)openPlatformCellDidUpdateAddress:(JBoOpenPlatformCell *)cell;

/**选择云名片信息
 */
- (void)openPlatformCell:(JBoOpenPlatformCell*) cell didSelect:(BOOL) select;

/**选择分组
 */
- (void)openPlatformCellDidSelectGroup:(JBoOpenPlatformCell *)cell;

@end

/**云名片信息cell
 */
@interface JBoOpenPlatformCell : UITableViewCell<JBoCheckBoxDelegate,JBoOpenPlatformMultiTextViewDelegate>

/**二维码图片
 */
@property(nonatomic,readonly) UIImageView *qrCodeImageView;

/**日期
 */
@property(nonatomic,readonly) JBoDateView *dateView;

/**云名片信息标题
 */
@property(nonatomic,readonly) UILabel *titleLabel;

/**商品价格
 */
@property(nonatomic,readonly) UILabel *priceLabel;

/**详情按钮
 */
@property(nonatomic,readonly) UIButton *topDetailButton;

/**云名片信息
 */
@property(nonatomic,retain) JBoOpenPlatformInfo *info;

/**平台信息内容
 */
@property(nonatomic,readonly) JBoOpenPlatformMultiTextView *multiTextView;

/**移动cell
 */
@property(nonatomic,assign) BOOL showCheckBox;
/**移动选项
 */
@property(nonatomic,readonly) JBoCheckBox *checkBox;

/**云名片样式
 */
@property(nonatomic,readonly) UIButton *webStyleButton;

/**详情按钮
 */
@property(nonatomic,readonly) UIButton *bottomDetailButton;

/**地址信息
 */
@property(nonatomic,readonly) UILabel *addrLabel;

/**地址信息图标
 */
@property(nonatomic,readonly) UIImageView *addrIconImageView;

/**地址添加按钮
 */
@property(nonatomic,readonly) UIButton *addrAddButton;

/**cell的类型
 */
@property(nonatomic,readonly) JBoOpenPlatformCellStyle cellStyle;

/**是否允许添加文字
 */
@property(nonatomic,assign) BOOL canAddTextInfo;

/**链接
 */
@property(nonatomic,readonly) JBoLinkShareView *linkView;

/**是否选中
 */
@property(nonatomic,assign) BOOL isSelectedInfo;

/**云名片操作类型
 */
@property(nonatomic,readonly) JBoOpenPlatformOperationType operationType;

/**云名片分组
 */
@property(nonatomic,readonly) UIButton *groupButton;

@property(nonatomic,assign) id<JBoOpenPlatformCellDelegate> delegate;

/**构造方法
 *@param reuseIdentifier 重用标识
 *@param cellStyle cell的类型
 *@param type 云名片操作类型
 *@return 一个初始化的 JBoOpenPlatformCell 对象
 */
- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier cellStyle:(JBoOpenPlatformCellStyle) cellStyle operationType:(JBoOpenPlatformOperationType) type;

@end
