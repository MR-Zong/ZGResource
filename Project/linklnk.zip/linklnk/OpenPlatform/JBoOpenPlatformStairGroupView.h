//
//  JBoOpenPlatformStairGroupView.h
//  linklnk
//
//  Created by kinghe005 on 14-10-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _openPlatformStairGroupViewHeight_ 45.0

/**一级分组按钮
 */
@interface JBoOpenPlatformStairGroupButton : UIView

/**按钮
 */
@property(nonatomic,readonly) UIButton *btn;

/**高亮视图
 */
@property(nonatomic,readonly) UIView *highlightView;

@end

@class JBoOpenPlatformStairGroupView;

/**云名片一级分组代理
 */
@protocol JBoOpenPlatformStairGroupViewDelegate <NSObject>

/**点击
 */
- (void)openPlatformStairGroupView:(JBoOpenPlatformStairGroupView*) view didSelectGroupAtIndex:(NSInteger) index;

/**添加
 */
- (void)openPlatformStairGroupViewDidAddGroup:(JBoOpenPlatformStairGroupView*) view;

/**长按
 */
- (void)openPlatformStairGroupView:(JBoOpenPlatformStairGroupView*) view didLongPressGroupAtIndex:(NSInteger) index;

@end

/**云名片一级分组
 */
@interface JBoOpenPlatformStairGroupView : UIView

/**一级分组信息，数组元素是JBoOpenPlatformGroupInfo对象
 */
@property(nonatomic,retain) NSArray *infos;

/**最大数量 default is '3'
 */
@property(nonatomic,assign) NSInteger maxCount;

/**是否可编辑 default is 'YES'
 */
@property(nonatomic,assign) BOOL editable;

@property(nonatomic,assign) id<JBoOpenPlatformStairGroupViewDelegate> delegate;


/**重新加载信息
 */
- (void)reload;

/**通过下标获取button
 */
- (JBoOpenPlatformStairGroupButton*)buttonForIndex:(NSInteger) index;

@end
