//
//  JBoLocalAddressBookSyncCell.m
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLocalAddressBookSyncCell.h"
#import "JBoBasic.h"
#import "JBoLettersSearchBar.h"

@interface JBoLocalAddressBookSyncCell ()

/**云通讯录联系人以存在
 */
@property(nonatomic,retain) UILabel *existLabel;

/**备注标题
 */
@property(nonatomic,retain) UILabel *remarkTitleLabel;

@end

@implementation JBoLocalAddressBookSyncCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        CGFloat existWidth = 50.0;
        CGFloat contentWidth = _width_ - _localAddressBookSyncCellMargin_ * 2 - _letterViewWidth_;

        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_localAddressBookSyncCellMargin_, _localAddressBookSyncCellMargin_, contentWidth - existWidth, _localAddressBookSyncCellControlHeight_)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont boldSystemFontOfSize:17.0];
        _nameLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_nameLabel];
        
        UILabel *existLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.right, _nameLabel.top, existWidth, _nameLabel.height)];
        existLabel.font = [UIFont systemFontOfSize:13.0];
        existLabel.textColor = [UIColor grayColor];
        existLabel.backgroundColor = [UIColor clearColor];
        existLabel.textAlign = JBoTextAlignmentRight;
        existLabel.text = @"已存在";
        existLabel.hidden = YES;
        [self.contentView addSubview:existLabel];
        self.existLabel = existLabel;
        [existLabel release];
        
        _phoneNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _nameLabel.bottom, contentWidth, _nameLabel.height)];
        _phoneNumLabel.backgroundColor = [UIColor clearColor];
        _phoneNumLabel.textColor = [UIColor blackColor];
        _phoneNumLabel.font = [UIFont systemFontOfSize:15.0];
        _phoneNumLabel.numberOfLines = 0;
        [self.contentView addSubview:_phoneNumLabel];
        
        CGFloat remarkTitleWidth = 45.0;
        UILabel *remarkTitleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _phoneNumLabel.bottom, remarkTitleWidth, _nameLabel.height)];
        remarkTitleLabel.font = [UIFont systemFontOfSize:15.0];
        remarkTitleLabel.textColor = [UIColor grayColor];
        remarkTitleLabel.backgroundColor = [UIColor clearColor];
        remarkTitleLabel.text = @"备注：";
        [self.contentView addSubview:remarkTitleLabel];
        self.remarkTitleLabel = remarkTitleLabel;
        [remarkTitleLabel release];
        
        _remarkLabel = [[UILabel alloc] initWithFrame:CGRectMake(_remarkTitleLabel.right, _phoneNumLabel.bottom, contentWidth, _nameLabel.height)];
        _remarkLabel.backgroundColor = [UIColor clearColor];
        _remarkLabel.textColor = [UIColor blackColor];
        _remarkLabel.font = [UIFont systemFontOfSize:15.0];
        [self.contentView addSubview:_remarkLabel];
    }
    return self;
}

- (void)dealloc
{
    [_nameLabel release];
    [_existLabel release];
    
    [_phoneNumLabel release];
    [_remarkLabel release];
    
    [super dealloc];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    _remarkTitleLabel.hidden = [NSString isEmpty:_remarkLabel.text];
}

- (void)setExist:(BOOL)exist
{
    if(_exist != exist)
    {
        _exist = exist;
        _existLabel.hidden = !_exist;
    }
}

@end
