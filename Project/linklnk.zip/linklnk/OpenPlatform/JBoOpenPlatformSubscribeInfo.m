//
//  JBoOpenPlatformSubscribeInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformSubscribeInfo.h"

@implementation JBoOpenPlatformSubscribeInfo

- (void)dealloc
{
    [_tel release];
    [_name release];
    [_time release];
    
    [super dealloc];
}

@end
