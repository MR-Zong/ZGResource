//
//  JBoOpenPlatformImageView.h
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoMultiImageView.h"

#define _PlatformImageSectionInterval_ 20.0
#define _openPlatformAddImageButtonHeight_ 80.0

//cell未展开时显示图片的数量
#define _openPlatformShowImageCountWhenClose_ 3

@class JBoOpenPlatformImageView;
@class JBoOpenPlatformInfo;

@protocol JBoOpenPlatformImageViewDelegate <NSObject>

/**选择图片
 */
- (void)openPlatformImageView:(JBoOpenPlatformImageView*) imageView didSelectedImageAtIndex:(NSInteger) index;

@optional

/**长按图片
 */
- (void)openPlatformImageView:(JBoOpenPlatformImageView*) imageView didLongPressedImageAtIndex:(NSInteger) index;

/**添加图片
 */
- (void)openPlatformImageViewDidAddImage:(JBoOpenPlatformImageView*) imageView;

@end

@interface JBoOpenPlatformImageView : UIView

/**云名片信息
 */
@property(nonatomic,retain) JBoOpenPlatformInfo *info;

/**图片是否具有长按手势 default is 'YES'
 */
@property(nonatomic,assign) BOOL enableLongPressGesture;

/**添加图片按钮
 */
@property(nonatomic,readonly) UIButton *addImageButton;

@property(nonatomic,assign) id<JBoOpenPlatformImageViewDelegate> delegate;

/**重新加载数据
 */
- (void)reloadData;

/**重新加载图片
 */
- (void)reloadImageAtIndex:(NSInteger) index withURL:(NSString*) URL;

/**设置logo
 */
- (void)setupLogoStyle:(JBoMultiImageViewCellLogoStyle) logoStyle atIndex:(NSInteger) index;

/**根据图片数量获取高度
 */
+ (CGFloat)heightForImageCount:(NSInteger) count;

@end
