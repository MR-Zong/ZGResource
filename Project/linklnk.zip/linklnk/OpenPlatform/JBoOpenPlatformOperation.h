//
//  JBoOpenPlatformOperation.h
//  靓咖
//
//  Created by kinghe005 on 14-8-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoBasic.h"

@class JBoOpenPlatformInfo;
@class JBoMapInfo;
@class JBoOpenPlatformTextInfo;

#define _getUserOpenPlatformInfoIdentifier_ @"getUserOpenPlatformInfo"
#define _uploadOpenPlatformInfoIdentifier_ @"uploadOpenPlatformInfo"

#define _modifyOpenPlatformInfoVisibleIdentifier_ @"modifyOpenPlatformInfoVisible"
#define _removeOpenPlatformInfoIdentifier_ @"removeOpenPlatformInfo"

#define _removeOneImageAtOpenPlatformIdentifier_ @"removeOneImageAtOpenPlatform"
#define _updateOneImageAtOpenPlatformIdentifier_ @"updateOneImageAtOpenPlatform"

#define _setupOpenPlatformInfoStickIdentifier_ @"setupOpenPlatformInfoStick"

#define _updateOpenPlatformInfoOrderIdentifier_ @"updateOpenPlatformInfoOrder"

#define _moveOpenPlatformInfoOrderIdentifier_ @"moveOpenPlatformInfoOrder"

#define _updateOpenPlatformInfoImageRelatedURLIdentifier_ @"updateOpenPlatformInfoImageRelatedURL"
#define _removeOpenPlatformInfoImageRelatedURLIdentifier_ @"removeOpenPlatformInfoImageRelatedURL"

#define _removeOpenPlatformTextInfoIdentifier_ @"removeOpenPlatformTextInfo"
#define _modifyOpenPlatformTextInfoIdentifier_ @"modifyOpenPlatformTextInfo"

#define _modifyOpenPlatformWebStyleIdentifier_ @"modifyOpenPlatformWebStyle"

#define _modifyOpenPlatformTitleIdentifier_ @"modifyOpenPlatformTitle"

#define _getOpenPlatfromWebStyleIdentifier_ @"getOpenPlatfromWebStyle"
#define _modifyOpenPlatformWebStyleIdentifier_ @"modifyOpenPlatformWebStyle"

@interface JBoOpenPlatformOperation : NSObject

#pragma mark- 获取名片信息

/**获取我的云名片信息 可通过可见范围筛选
 *@param pageNum 页码
 *@param rows 每页的数量
 *@param visible 可见范围 当传入NSNotFound时 表示该参数不上传
 *@param lastId 最新的名片信息Id
 */
+ (NSString*)getUserOpenPlatformInfoWithLastId:(long long) lastId rows:(int) rows visible:(NSInteger) visible;

/**解析我的云名片信息
 *@return 数组元素是 JBoOpenPlatformInfo 对象
 */
+ (NSMutableArray*)getUserOpenPlatformInfoFromData:(NSData*) data;

#pragma mark- 上传名片信息

/**上传云名片信息 URL
 */
+ (NSString*)uploadOpenPlatformInfo;

/**上传云名片信息参数 图文
 *@param visible 可见范围
 *@param widths 图片宽度组合 用;分开
 *@param heights 图片高度组合 用;分开
 *@param content 内容
 *@param Id 云名片信息Id 没有则为0
 *@param title 云名片信息标题
 *@param imageCountAfterText 云名片文本信息后面的图片数量
 *@param imageIndex 选中的图片下标，添加图片时用到，值为NSNotFound时，不传
 *@param imagePosition 图片插入的位置，添加图片时用到，值为NSNotFound时，不传
 *@param imageCountAfterTitle 云名片标题后面的图片数量
 *@param font 信息内容字体
 *@param textColor 信息内容颜色
 *@param styleRange 信息样式范围
 *@param fontSize 信息内容字体大小
 *@param addrInfo 地址信息
 *@param groupId 分组Id
 *@param price 商品价格
 *@return post请求参数
 */
+ (NSDictionary*)uploadOpenPlatformInfoParamWithVisible:(NSInteger) visible widths:(NSString*) widths heights:(NSString*) heights content:(NSString*) content webStyleId:(long long) webStyleId Id:(long long) Id title:(NSString*) title imageCountAfterText:(NSString*) imageCountAfterText imageIndex:(NSInteger) imageIndex imagePosition:(NSInteger) imagePosition imageCountAfterTitle:(NSString*) imageCountAfterTitle font:(NSString*) font textColor:(NSString*) textColor styleRange:(NSString*) styleRange fontSize:(NSString*) fontSize addrInfo:(JBoMapInfo*) addrInfo groupId:(long long) groupId price:(float) price;

/**上传云名片信息 链接
 *@param title 链接标题
 *@param url 链接
 *@param width 链接的图片宽度
 *@param height 链接的图片高度
 *@param groupId 分组Id
 *return post 请求参数
 */
+ (NSDictionary*)uploadOPenPlatformLinkInfoParamWithTitle:(NSString*) title url:(NSString*) url width:(int) width height:(int) height groupId:(long long) groupId;

/**解析上传云名片信息返回数据
 *@return nil时表示上传失败 否则上传成功
 */
+ (JBoOpenPlatformInfo*)uploadOpenPlatformInfoFromData:(NSData*) data;

#pragma mark- 修改名片信息

/**修改可见范围 URL
 */
+ (NSString*)modifyOpenPlatformInfo;

/**修改可见范围 参数
 *@param visible 可见范围
 *@param Id 信息标识
 */
+ (NSDictionary*)modifyOpenPlatformInfoParamWithVisible:(NSInteger) visible withId:(long long) Id;

/**删除名片信息 URL
 */
+ (NSString*)removeOpenPlatformInfo;

/**删除名片信息 参数
 *@param Id 信息标识
 */
+ (NSDictionary*)removeOpenPlatformInfoParamWithId:(long long) Id;

/**删除名片信息的某张图片 URL
 */
+ (NSString*)removeOneImageAtOpenPlatform;

/**删除名片信息的某张图片 参数
 *@param info 云名片信息
 *@param index 要删除的图片所在下标
 *@param textIndex 图片所属的文本下标
 *@return post请求参数
 */
+ (NSDictionary*)removeOneImageAtOpenPlatformParamWithInfo:(JBoOpenPlatformInfo*) info atIndex:(NSInteger) index textIndex:(NSInteger) textIndex;

/**更新名片信息的某张图片 URL
 */
+ (NSString*)updateOneImageAtOpenPlatform;

/**更新名片信息的某张图片 参数
 *@param Id 信息标识
 *@param updatedImageURL 要更新的图片路径
 *@param images 所有图片路径
 *@param size 要上传的图片宽度和高度
 */
+ (NSDictionary*)updateOneImageAtOpenPlatformParamWithId:(long long) Id updatedImageURL:(NSString*) updatedImageURL images:(NSString*) images imageSize:(CGSize) size;

/**解析更新名片信息的某张图片 返回数据
 *@param data 返回的数据
 *@return 缩略图和原图路径
 */
+ (NSDictionary*)getUpdaeOneImageFromData:(NSData*) data;

/**设置名片信息的置顶状态 URL
 */
+ (NSString*)setupOpenPlatformInfoStick;

/**设置名片信息的置顶状态 参数
 *@param stick 置顶状态 'NO' 是取消置顶 'YES' 是置顶
 *@param Id 信息标识
 */
+ (NSDictionary*)setupOpenPlatformInfoStick:(BOOL) stick withId:(long long) Id;

/**更新名片信息的顺序 URL
 */
+ (NSString*)updateOpenPlatformInfoOrder;

/**更新名片信息的顺序 参数
 *@param Id 信息标识
 */
+ (NSDictionary*)updateOpenPlatformInfoOrderParamWithId:(long long) Id;

/**更新移动名片信息的顺序返回数据
 *return 新的名片信息排序ID
 */
+ (double)updateOpenPlatformInfoOrderResultFromData:(NSData*) data;

/**移动名片信息的顺序 URL
 */
+ (NSString*)moveOpenPlatformInfoOrder;

/**移动名片信息的顺序 参数
 *@param moveId 要移动的名片信息 标识
 *@param frontSortId 要排在之后的名片信息 排序Id
 */
+ (NSDictionary*)moveOpenPlatformInfoOrderParamWithMoveId:(long long) moveId frontSortId:(double) frontSortId;

/**解析移动名片信息的顺序返回数据
 *@return 新的名片信息排序ID
 */
+ (double)moveOpenPlatformInfoOrderResultFromData:(NSData*) data;

#pragma mark- 图片关联的链接

/**更新名片图片链接 URL
 */
+ (NSString*)updateOpenPlatformInfoImageRelatedURL;

/**更新名片图片链接 参数
 *@param Id 名片信息标识
 *@param imageURL 关联的图片的图片路径
 *@param userId 关联的用户 userId
 *@param linkURL 关联的链接
 */
+ (NSDictionary*)updateOpenPlatformInfoImageRelatedURLParamWithId:(long long) Id imageURL:(NSString*) imageURL relatedUserId:(NSString*) userId linkURL:(NSString*) url;

/**解析更新名片图片链接 返回的数据
 *@param data 返回的数据
 *@return 更新成功后的关联链接
 */
+ (NSString*)updateOpenPlatformInfoImageRelatedURLResultFromData:(NSData*) data;

/**删除名片图片链接 URL
 */
+ (NSString*)removeOpenPlatformInfoImageRelatedURL;

/**删除名片图片链接 参数
 *@param Id 名片信息标识
 *@param relatedURL 关联的链接
 */
+ (NSDictionary*)removeOpenPlatformInfoImageRelatedURLParamWithId:(long long) Id relatedURL:(NSString*) relatedURL;

#pragma mark- 云名片文本

/**删除云名片文本信息 URL
 *@return post 请求url
 */
+ (NSString*)removeOpenPlatformTextInfo;

/**删除云名片文本信息 参数
 *@param Id 云名片信息Id
 *@param text 要删除的云名片文本信息
 *@param index 要删除的云名片文本下标
 *@return post请求参数
 */
+ (NSDictionary*)removeOpenPlatformTextInfoParamWithId:(long long) Id text:(NSString*) text index:(NSInteger) index;

/**修改云名片文本信息 URL
 *@return post 请求url
 */
+ (NSString*)modifyOpenPlatformTextInfo;

/**修改云名片文本信息 参数
 *@param Id 云名片信息Id
 *@param oldText 旧的云名片文本信息
 *@param newsText 新的云名片文本信息
 *@param index 要修改的云名片文本下标
 *@param imageNum 云名片文本信息后面的图片数量
 *@param position 信息插入的位置，为NSNotFound时不传
 *@param font 信息内容字体
 *@param textColor 信息内容颜色
 *@param styleRange 信息样式范围
 *@param fontSize 信息内容字体大小
 *@return post 请求参数
 */
+ (NSDictionary*)modifyOpenPlatformTextInfoParamWithId:(long long) Id oldText:(NSString*) oldText newsText:(NSString*) newsText index:(NSInteger) index imageNumAfterText:(NSString*) imageNum position:(NSInteger) position font:(NSString*) font textColor:(NSString*) textColor styleRange:(NSString*) styleRange fontSize:(NSString*) fontSize;

/**修改云名片标题 url
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformTitle;

/**修改云名片标题 参数
 *@param Id 云名片Id
 *@param title 新的云名片标题
 *@param imageNum 云名片标题后面的图片数量
 *@param price 商品价格
 *@return post 请求参数
 */
+ (NSDictionary*)modifyOpenPlatformTitleParamWithId:(long long) Id title:(NSString*) title imageNumAfterTitle:(int) imageNum price:(float) price;

/**更新云名片信息 url
 *@return post请求url
 */
+ (NSString*)updateOpenPlatformInfo;

/**更新云名片信息 参数
 *@param info  云名片信息
 *@param index  需要更新的文本下标 或新的文本信息插入的位置
 *@param newTextInfos 新的文本信息 数组元素是 JBoOpenPlatformTextInfo对象
 *@param type 云名片编辑类型
 *@param newImageInfos 新的图片信息
 *@param imageIndex 所属文本的图片的下标
 @return post请求参数
 */
+ (NSDictionary*)updateOpenPlatformInfoParamWithInfo:(JBoOpenPlatformInfo*) info atIndex:(NSInteger) index newTextInfos:(NSArray*) newTextInfos type:(JBoOpenPlatformEditType) type newImageInfos:(NSArray*) newImageInfos imageIndex:(int) imageIndex;

/**从返回的数据获取已更新的云名片信息
 *@param data 返回的数据
 *@return 新的云名片信息
 */
+ (JBoOpenPlatformInfo*)updatedOpenPlatformInfoFromData:(NSData*) data;

#pragma mark- 云名片样式

/**获取云名片样式
 *@return get请求url
 */
+ (NSString*)getOpenPlatformWebStyle;

/**从返回的数据获取云名片样式信息
 *@param data 返回的数据
 *@return 数组元素是 JBoOpenPlatformWebStyleGroupInfo对象
 */
+ (NSMutableArray*)getOpenPlatformWebStyleFromData:(NSData*) data;

/**修改云名片样式 URL
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformWebStyle;

/**修改云名片样式 url
 *@param Id 云名片信息Id
 *@param webStyleId 云名片信息样式Id
 *@return post请求参数
 */
+ (NSDictionary*)modifyOpenPlatformWebStyleParamWithId:(long long) Id webStyleId:(long long) webStyleId;

#pragma mark- 云名片预约

/**获取云名片信息预约的人
 *@param Id 云名片信息Id
 *@return get请求url
 */
+ (NSString*)getOpenPlatFormSubscribeInfoWithId:(long long) Id;

/**从返回的数据获取预约的人的信息
 *@param data 返回的数据
 *@reuturn 数组元素是 JBoOpenPlatformSubscribeInfo对象
 */
+ (NSMutableArray*)getOpenPlatFormSubscribeInfoFromData:(NSData*) data;


#pragma mark- 云名片链接二维码图片

/**获取云名片链接的二维码图片
 *@param image 二维码图片
 *@param info 云名片信息
 *@param headImage 头像
 *@param linkIcon 靓咖标记
 *@param margin 二维码边界
 *@return 一个 UIImage对象
 */
+ (UIImage*)getOpenPlatformQRCodeImageFormImage:(UIImage*) image info:(JBoOpenPlatformInfo*) info headImage:(UIImage*) headImage linkIcon:(UIImage*) linkIcon margin:(CGFloat) margin;

#pragma mark- 云名片位置

/**更新云名片位置信息 url
 *@return post请求url
 */
+ (NSString*)updateOpenPlatformAddress;

/**更新云名片位置信息 参数
 *@param Id 云名片信息Id
 *@param addrInfo 位置信息
 *@return post请求参数
 */
+ (NSDictionary*)updateOpenPlatformAddressParamWithId:(long long) Id addrInfo:(JBoMapInfo*) addrInfo;

#pragma mark- 云名片订单

/**获取订单列表信息
 *@param lastId 整个列表中最后一条订单信息的Id，第一页传0
 *@param rows 每页数量
 *@param type 订单类型
 *@return get请求url
 */
+ (NSString*)getOpenPlatformOrderListWithLastId:(long long) lastId rows:(int) rows type:(int) type;

/**从返回的数据获取订单列表信息
 *@param data 返回的数据
 *@return 数组元素是 JBoOrderListInfo
 */
+ (NSMutableArray*)getOpenPlatformOrderListFromData:(NSData*) data;

#pragma mark- 云名片链接识别

/**是否是云名片链接
 *@param url 一个http链接
 */
+ (BOOL)isOpenPlatformURL:(NSString*) url;

/**云名片post请求
 *@param url 请求路径
 */
+ (NSURLRequest*)requestWithURL:(NSString*) url;

@end
