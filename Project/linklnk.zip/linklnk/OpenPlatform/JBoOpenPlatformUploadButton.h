//
//  JBoOpenPlatformUploadButton.h
//  linklnk
//
//  Created by kinghe005 on 14-10-13.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**云平台信息上传按钮
 */
@interface JBoOpenPlatformUploadButton : UIView

/**添加单击手势
 */
- (void)addTapGestureWithTarget:(id) target action:(SEL) action;

/**添加长按手势
 */
- (void)addLongPressGestureWithTarget:(id) target action:(SEL) action;

@end
