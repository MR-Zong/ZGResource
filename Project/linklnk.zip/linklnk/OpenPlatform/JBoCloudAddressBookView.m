//
//  JBoCloundAddressBookView.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookView.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoImageCacheTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoHttpRequest.h"
#import "JBoAppDelegate.h"
#import "JBoCloudAddressBookInfo.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoCloudAddressBookCell.h"
#import "ChineseToPinyin.h"
#import "JBoCloudAddressBookProblemManagerViewController.h"
#import "JBoCloudAddressBookGroupManagerViewController.h"
#import "JBoCloudAddressBookGroupInfoViewController.h"
#import "JBoCloudAddressBookOperation.h"
#import "JBoUserOperation.h"
#import "JBoWebViewController.h"
#import "JBoCloudAddressBookSharedViewController.h"
#import "JBoCloudAddressBookSyncViewController.h"
#import "JBoImageTextTool.h"
#import "JBoLocalAddressBookSyncViewController.h"


//搜索栏高度
#define _searchBarHeight_ 40

@interface JBoCloudAddressBookView ()<JBoHttpRequestDelegate,EGORefreshTableHeaderDelegate,JBoSlideCellDelegate,JBoCloudAddressBookHeaderDelegate,JBoCloudAddressBookGroupInfoViewControllerDelegate>
{
    UITableView *_tableView;
    //搜索栏
    UISearchBar *_searchBar;
    //搜索栏搜索结果
    NSMutableArray *_searchResultArray;
    
    BOOL _isLoading; //数据是否加载中
    
    //黑色半透明视图
    UIView *_transparentView;
    
    //下拉刷新
    EGORefreshTableHeaderView *_refreshView;
    
    //清理
    JBoImageCacheTool *_imageCacheTool;
}

//正在搜索
@property(nonatomic,assign) BOOL searching;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

@property(nonatomic,assign) JBoAppDelegate *appDelegate;

//滑出的cell
@property(nonatomic,retain) NSIndexPath *slideIndexPath;

//要操作的cell
@property(nonatomic,retain) NSIndexPath *selectedIndexPath;

//移动到新的分组
@property(nonatomic,assign) NSInteger groupSelectedIndex;

//云名片夹链接
@property(nonatomic,copy) NSString *cloudAddressBookURL;

//当前登录用户的信息
@property(nonatomic,retain) JBoUserDetailInfo *myInfo;

//拨号
@property(nonatomic,retain) UIWebView *callOutWebView;

@end

@implementation JBoCloudAddressBookView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.black = YES;
        _groupArray = [[NSMutableArray alloc] init];
        _searchResultArray = [[NSMutableArray alloc] init];
        
        _imageCacheTool = [[JBoImageCacheTool alloc] init];
        
        self.appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        
        self.myInfo = [JBoUserOperation getUserDetailInfo];
        
        [self loadInitView];
        
        //云名片夹联系人添加通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(contactDidAdd:) name:_addCloudAddressBookContactNotification_ object:nil];
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    _tableView.frame = self.bounds;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark- 通知

//有新联系人
- (void)contactDidAdd:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    
    JBoCloudAddressBookGroupInfo *groupInfo = [dic objectForKey:_addCloudAddressBookContactGroupInfo_];
    JBoCloudAddressBookInfo *bookInfo = [dic objectForKey:_addCloudAddressBookContactUserInfo_];
    
    if(groupInfo == nil || bookInfo == nil)
        return;
    
    BOOL exist = NO;
    for(JBoCloudAddressBookGroupInfo *info in self.groupArray)
    {
        if(info.Id == groupInfo.Id)
        {
            [info.infos addObject:bookInfo];
            exist = YES;
            break;
        }
    }
    
    if(!exist)
    {
        [self.groupArray addObject:groupInfo];
        [groupInfo.infos addObject:bookInfo];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^(void){
        
        [_tableView reloadData];
    });
}

#pragma mark- dealloc

- (void)dealloc
{
    self.appDelegate = nil;
    
    [_groupArray release];
    
    [_tableView release];
    [_searchBar release];
    [_searchResultArray release];
    
    [_transparentView release];
    [_refreshView release];
    [_imageCacheTool release];
    
    [_httpRequest release];
    [_slideIndexPath release];
    [_selectedIndexPath release];
    
    [_cloudAddressBookURL release];
    
    [_myInfo release];
    
    [_callOutWebView release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_addCloudAddressBookContactNotification_ object:nil];
    
    [super dealloc];
}

/**取消网络请求
 */
- (void)cancelHttpRequest
{
    self.httpRequest = nil;
    [_imageCacheTool cancelAllDownload];
    [self tableViewDataSourceDidFinishLoading];
    self.isRequesting = NO;
}

/**重新加载数据
 */
- (void)reloadData
{
    [_tableView reloadData];
}

/**加载数据
 */
- (void)loadData
{
    [_refreshView beginRefresh];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getCloudAddressBookContactInfoIdentifier_])
    {
        _refreshView.finishText = [NSString stringWithFormat:@"%@,刷新失败", _alertMsgWhenBadNetwork_];
        [self tableViewDataSourceDidFinishLoading];
        return;
    }
    
    if([identifier isEqualToString:_moveCloudAddressBookContactIentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeCloudAddressBookContactIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"删除失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getCloudAddressBookContactInfoIdentifier_])
    {
        NSMutableArray *array = [NSMutableArray array];
        self.cloudAddressBookURL = [JBoCloudAddressBookOperation getCloudAddressBookContactInfoFromData:data withArray:array];
        if(self.cloudAddressBookURL)
        {
            [self.groupArray removeAllObjects];
            
            [self.groupArray addObjectsFromArray:array];
            [self addMyInfo];
            
            _refreshView.finishText = @"刷新成功";
            
        }
        else
        {
            _refreshView.finishText = [NSString stringWithFormat:@"%@,刷新失败", _alertMsgWhenBadNetwork_];
        }
        [self tableViewDataSourceDidFinishLoading];
        return;
    }
    
    if([identifier isEqualToString:_moveCloudAddressBookContactIentifier_])
    {
        long long Id = [JBoCloudAddressBookOperation moveCloudAddressBookContactProblemResultFromData:data];
        if(Id != -1)
        {

            [JBoUserOperation alertMsg:@"分组成功"];
            
            JBoCloudAddressBookGroupInfo *groupInfo1 = [self.groupArray objectAtIndex:self.selectedIndexPath.section - 1];
            JBoCloudAddressBookGroupInfo *groupInfo2 = [self.groupArray objectAtIndex:self.groupSelectedIndex];
            
            JBoCloudAddressBookInfo *bookInfo = [[groupInfo1.infos objectAtIndex:self.selectedIndexPath.row] retain];
            [groupInfo1.infos removeObjectAtIndex:self.selectedIndexPath.row];
            
            [groupInfo2.infos addObject:bookInfo];
            
             self.slideIndexPath = nil;
            [bookInfo release];
            [_tableView reloadData];
        }
        else
        {

            [JBoUserOperation alertmsgWithBadNetwork:@"分组失败"];
        }
        
        return;
    }
    
    if([identifier isEqualToString:_removeCloudAddressBookContactIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {

            [JBoUserOperation alertMsg:@"删除成功"];
            
            JBoCloudAddressBookGroupInfo *groupInfo = [self.groupArray objectAtIndex:self.selectedIndexPath.section - 1];
            [groupInfo.infos removeObjectAtIndex:self.selectedIndexPath.row];
            
            if(groupInfo.open)
            {
                [_tableView beginUpdates];
                [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
                [_tableView endUpdates];
            }
            else
            {
                [_tableView reloadData];
            }
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"删除失败"];
        }
        
        self.slideIndexPath = nil;
        return;
    }
}

- (void)loadInfo
{
    if(self.isRequesting)
        return;
    _httpRequest.identifier = _getCloudAddressBookContactInfoIdentifier_;
    [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation getCloudAddressBookContactInfo]];
}

#pragma mark-加载视图

//添加自己信息
- (void)addMyInfo
{
//    for(JBoCloudAddressBookGroupInfo *groupInfo in self.groupArray)
//    {
//        if(groupInfo.Id == _cloudAddressBookGroupDefaultId_)
//        {
//            JBoCloudAddressBookInfo *info = [[JBoCloudAddressBookInfo alloc] init];
//            
//            info.Id = _cloudAddressBookContactIdMeValue_;
//            info.name = self.myInfo.rosterInfo.name;
//            info.role = self.myInfo.rosterInfo.role;
//            info.userId = self.myInfo.rosterInfo.username;
//            info.imageURL = self.myInfo.rosterInfo.imageURL;
//            info.sex = self.myInfo.rosterInfo.sex;
//            info.phoneNum = self.myInfo.phoneNum;
//            info.telePhone = self.myInfo.rosterInfo.enterpriseTelePhone;
//            
//            [groupInfo.infos insertObject:info atIndex:0];
//            [info release];
//            break;
//        }
//    }
}

//加载视图
- (void)loadInitView
{
    //创建导航条右边的按钮
    
    self.backgroundColor = [UIColor whiteColor];
    
    //创建tableview
    _tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorColor = [UIColor colorWithRed:160.0 / 255.0 green:160.0 / 255.0 blue:160.0 / 255.0 alpha:1.0];
    [self addSubview:_tableView];
    [_tableView setExtraCellLineHidden];
    
    _refreshView = [[EGORefreshTableHeaderView alloc] initWithFrame:_tableView.frame];
    _refreshView.delegate = self;
    _refreshView.scrollView = _tableView;
    _refreshView.hidden = YES;
    [self insertSubview:_refreshView belowSubview:_tableView];
    
    //创建搜索栏背
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
    if(!_ios7_0_)
    {
        _searchBar.tintColor = _searchBarColor_;
    }
    
    _searchBar.placeholder = @"搜索";
    _searchBar.delegate = self;
    
    _tableView.tableHeaderView = _searchBar;
}

#pragma mark- private method

//拨号
- (void)callOutWithPhoneNum:(NSString*) phoneNum
{
    NSURL *phoneURL = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",phoneNum]];
    if(!self.callOutWebView)
    {
        self.callOutWebView = [[[UIWebView alloc] init] autorelease];
    }
    [_callOutWebView loadRequest:[NSURLRequest requestWithURL:phoneURL]];
}
//
////添加管理内容
//- (void)addManagerContent
//{
//    JBoCloudAddressBookGroupInfo *groupInfo = [_groupArray firstObject];
//    if(groupInfo == nil || groupInfo.Id != -1)
//    {
//        JBoCloudAddressBookGroupInfo *info = [[[JBoCloudAddressBookGroupInfo alloc] init] autorelease];
//        info.Id = -1;
//        [_groupArray insertObject:info atIndex:0];
//    }
//}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    [_refreshView removeFromSuperview];
    if(!_transparentView)
    {
        _searchResultArray = [[NSMutableArray alloc] init];
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;
        
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [_searchBar setShowsCancelButton:YES animated:YES];
    [_tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
    [self insertSubview:_refreshView belowSubview:_tableView];
    [_tableView setExtraCellLineHidden];
}


//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    [self beginSearch];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self beginSearch];
}

//开始搜索
- (void)beginSearch
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        
        [_searchResultArray removeAllObjects];
        
        for(JBoCloudAddressBookGroupInfo *info in self.groupArray)
        {
            for(JBoCloudAddressBookInfo *bookInfo in info.infos)
            {
                if([self pinyin:pinyin match:bookInfo.name])
                {
                    [_searchResultArray addObject:bookInfo];
                }
                
                if([self chinese:content match:bookInfo.name] && ![_searchResultArray containsObject:bookInfo])
                {
                    [_searchResultArray addObject:bookInfo];
                }
            }
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
        [_tableView reloadData];
        [_tableView setExtraCellLineHidden];
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

//拼音是否匹配
- (BOOL)pinyin:(NSString*) pinyin match:(NSString*) str
{
    NSString *name = [ChineseToPinyin pinyinFromChiniseString:str];
    if(name.length < pinyin.length)
    {
        return NO;
    }
    
    NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
    if([pinyin isEqualToString:subStr])
    {
        return YES;
    }
    return NO;
}

//中文是否匹配
- (BOOL)chinese:(NSString*) chinese match:(NSString*) str
{
    NSRange range = [str rangeOfString:chinese];
    if(range.length > 0 && range.location != NSNotFound)
    {
        return YES;
    }
    return NO;
}

#pragma mark- sectionHeader

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
    {
        return 1;
    }
    else
    {
        return _groupArray.count + 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching)
        return 0;
    else
        return section == 0 ? _cloudAddressBookFirstHeaderHeight_ : _cloudAddressBookHeaderHeight_;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching)
        return nil;
    
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        
        if(section == 0)
        {
            static NSString *firstHeaderIdentifier = @"firstHeader";
            JBoCloudAddressBookFirstHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:firstHeaderIdentifier];
            
            if(header == nil)
            {
                header = [[[JBoCloudAddressBookFirstHeader alloc] initWithReuseIdentifier:firstHeaderIdentifier] autorelease];
                header.headerView.delegate = self;
            }
            
            header.headerView.section = section;
            
            return header;
        }
        else
        {
            JBoCloudAddressBookGroupInfo *info = [self.groupArray objectAtIndex:section - 1];
            
            static NSString *headerIdentifier = @"header";
            JBoCloudAddressBookHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
            
            if(header == nil)
            {
                header = [[[JBoCloudAddressBookHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
                header.headerView.delegate = self;
            }
            
            header.headerView.section = section;
            header.headerView.rightIndicateIcon.selected = info.open;
            header.headerView.nameLabel.text = info.groupName;
            header.headerView.countLabel.text = [NSString stringWithFormat:@"%d", (int)info.infos.count];
            
            return header;
        }
#endif
    }
    else
    {
        if(section == 0)
        {
            JBoCloudAddressBookFirstHeaderView *header = [[[JBoCloudAddressBookFirstHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookFirstHeaderHeight_)] autorelease];
            header.delegate = self;
            
            header.section = section;

            return header;
        }
        else
        {
            JBoCloudAddressBookGroupInfo *info = [self.groupArray objectAtIndex:section - 1];
            
            JBoCloudAddressBookHeaderView *header = [[[JBoCloudAddressBookHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookHeaderHeight_)] autorelease];
            header.delegate = self;
            
            header.section = section;
            header.rightIndicateIcon.selected = info.open;
            header.nameLabel.text = info.groupName;
            header.countLabel.text = [NSString stringWithFormat:@"%d", (int)info.infos.count];
            
            return header;
        }
    }
}

#pragma mark- header 代理

- (void)headerDidCloseAtSection:(NSInteger)section
{
    JBoCloudAddressBookGroupInfo *info = [self.groupArray objectAtIndex:section - 1];
    info.open = NO;
    
    NSMutableArray *deleteIndexPaths = [[NSMutableArray alloc] initWithCapacity:info.infos.count];

    for(NSInteger i = 0;i < info.infos.count;i ++)
    {
        [deleteIndexPaths addObject:[NSIndexPath indexPathForRow:i inSection:section]];
    }
    
    [_tableView beginUpdates];
    [_tableView deleteRowsAtIndexPaths:deleteIndexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
    [deleteIndexPaths release];
}

- (void)headerDidOpenAtSection:(NSInteger)section
{
    JBoCloudAddressBookGroupInfo *info = [self.groupArray objectAtIndex:section - 1];
    info.open = YES;
    
    NSMutableArray *insertIndexPaths = [[NSMutableArray alloc] initWithCapacity:info.infos.count];

    for(NSInteger i = 0;i < info.infos.count;i ++)
    {
        [insertIndexPaths addObject:[NSIndexPath indexPathForRow:i inSection:section]];
    }
    
    [_tableView beginUpdates];
    [_tableView insertRowsAtIndexPaths:insertIndexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
    [insertIndexPaths release];
}

- (void)headerGroupManagerAtSection:(NSInteger)section
{
    JBoCloudAddressBookGroupManagerViewController *group = [[JBoCloudAddressBookGroupManagerViewController alloc] init];
    group.black = self.black;
    group.infoArray = self.groupArray;
    [self.navigationController pushViewController:group animated:YES];
    [group release];
}

- (void)headerProblemManagerAtSection:(NSInteger)section
{
    JBoCloudAddressBookProblemManagerViewController *problem = [[JBoCloudAddressBookProblemManagerViewController alloc] init];
    problem.black = self.black;
    [self.navigationController pushViewController:problem animated:YES];
    [problem release];
}

- (void)headerDidSyncLocalAddressBookAtSection:(NSInteger)section
{
    JBoCloudAddressBookSyncViewController *sync = [[JBoCloudAddressBookSyncViewController alloc] init];
    sync.groupInfos = self.groupArray;
    sync.black = self.black;
    [self.navigationController pushViewController:sync animated:YES];
    [sync release];
}

- (void)headerDidShareCloudAddressBookAtSection:(NSInteger)section
{
    JBoCloudAddressBookSharedViewController *share = [[JBoCloudAddressBookSharedViewController alloc] init];
    share.groupInfos = self.groupArray;
    share.black = self.black;
    share.url = self.cloudAddressBookURL;
    [self.navigationController pushViewController:share animated:YES];
    [share release];
}

- (void)headerDidSyncToServerAtSection:(NSInteger)section
{
    JBoLocalAddressBookSyncViewController *localAddressBookSync = [[JBoLocalAddressBookSyncViewController alloc] init];
    localAddressBookSync.black = self.black;
    localAddressBookSync.cloundAddresBookInfos = self.groupArray;
    [self.navigationController pushViewController:localAddressBookSync animated:YES];
    [localAddressBookSync release];
}

#pragma mark-tableview代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
        return 0;
    JBoCloudAddressBookGroupInfo *info = [_groupArray objectAtIndex:indexPath.section - 1];
    
    if(info.Id == _cloudAddressBookWebSubmitInfoGroupId_)
    {
        CGFloat height = _cloudAddressBookCellHeight_ - _cloudAddessBookInterval_ * 2;
        JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:indexPath];
        if(bookInfo.remarkHeight == 0 && ![NSString isEmpty:bookInfo.remark])
        {
            CGSize size = [JBoImageTextTool getStringSize:[bookInfo remarkMsg] withFont:_cloundAddressBookRemarkFont_ andContraintSize:CGSizeMake(_width_ - _cloudAddressBookCellHeight_ - _cloudAddessBookInterval_ * 2 - _cloudAddressBookPhoneIconSize_, _maxFloat_)];
            bookInfo.remarkHeight = MAX(size.height + 3.0, height / 2.0);
        }

        return _cloudAddessBookInterval_ * 2 + height + bookInfo.remarkHeight;
    }
    else
    {
        return _cloudAddressBookCellHeight_;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return _searchResultArray.count;
    }
    else
    {
        if(section == 0)
            return 0;
        JBoCloudAddressBookGroupInfo *info = [_groupArray objectAtIndex:section - 1];
        
        NSInteger count = info.open ? info.infos.count : 0;
        return count;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    JBoCloudAddressBookCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoCloudAddressBookCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        cell.delegate = self;
    }
    
    cell.editable = !self.searching;
    
    JBoCloudAddressBookGroupInfo *groupInfo = [self groupInfoForSection:indexPath.section];
    JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:indexPath];
    
    if(groupInfo.Id == _cloudAddressBookWebSubmitInfoGroupId_)
    {
        cell.expandedItemTitles = [NSArray arrayWithObject:@"删除"];
        cell.expandWidth = 60.0;
        cell.phoneNumLabel.text = [NSString stringWithFormat:@"电话号码：%@", bookInfo.phoneNum];
        cell.timeLabel.text = bookInfo.time;
    }
    else
    {
        cell.expandedItemTitles = [NSArray arrayWithObjects:@"分组", @"删除", nil];
        cell.expandWidth = 120.0;
        cell.phoneNumLabel.text = nil;
        cell.timeLabel.text = nil;
    }
    
    cell.nameLabel.text = bookInfo.name;
    cell.headImageView.role = bookInfo.role;
    cell.nameLabel.sex = bookInfo.sex;
    
    cell.remarkLabel.text = [bookInfo remarkMsg];
    
    cell.info = bookInfo;
    
   // cell.editable = bookInfo.Id != _cloudAddressBookContactIdMeValue_;
    
    if(bookInfo.phoneState)
    {
        cell.phoneStateImageView.image = [UIImage imageNamed:@"phoneAble"];
    }
    else
    {
        cell.phoneStateImageView.image = [UIImage imageNamed:@"phoneDisable"];
    }
    
    cell.headImageView.sex = bookInfo.sex;
    cell.headImageView.headImageURL = bookInfo.imageURL;
    
    if(self.slideIndexPath != nil && self.slideIndexPath.section == indexPath.section && self.slideIndexPath.row == indexPath.row)
    {
        cell.position = JBoSlideCellPositionExpanded;
    }
    else
    {
        cell.position = JBoSlideCellPositionNormal;
    }
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //进入好友详细信息视图
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoCloudAddressBookCell *cell = (JBoCloudAddressBookCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    if(cell.position == JBoSlideCellPositionExpanded)
    {
        cell.position = JBoSlideCellPositionNormal;
        return;
    }
    
    JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:indexPath];
    JBoCloudAddressBookGroupInfo *groupInfo = [self.groupArray objectAtIndex:indexPath.section - 1];
    
    if(groupInfo.Id == _cloudAddressBookWebSubmitInfoGroupId_)
    {
        self.selectedIndexPath = indexPath;
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:@"拨号", @"复制电话号码", nil];
        
        if(![NSString isEmpty:bookInfo.remark])
        {
            [actionSheet addButtonWithTitle:@"复制备注信息"];
        }
        
        actionSheet.cancelButtonIndex = [actionSheet addButtonWithTitle:@"取消"];
        
        actionSheet.tag = 1000;
        [actionSheet showInView:self];
        [actionSheet release];
    }
    else
    {
        JBoWebViewController *web = [[JBoWebViewController alloc] init];
        web.black = self.black;
        
      //  NSLog(@"%@", bookInfo.cloudURL);
        
//        if(bookInfo.cloudURL)
//        {
//            web.URL = [NSURL URLWithString:bookInfo.cloudURL];
//        }
//        else
//        {
            web.needGetOpenPlatformURL = YES;
        //}
        web.userId = bookInfo.userId;
        [web showInViewController:self.navigationController animated:YES completion:nil];
        [web release];
    }
    
    [_searchBar resignFirstResponder];
}

#pragma mark- JBoSlideCell代理

- (void)slideCell:(JBoSlideCell *)cell didSelectedExpandedItem:(JBoSlideCellExpandedItem *)item
{
    if(self.isRequesting)
        return;
    
    self.selectedIndexPath = [_tableView indexPathForCell:cell];
    
    NSString *title = [item titleForState:UIControlStateNormal];
    
    if([title isEqualToString:@"删除"])
    {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定删除该联系人？" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"删除" otherButtonTitles:nil, nil];
        [actionSheet showInView:self];
        [actionSheet release];
    }
    else
    {
        JBoCloudAddressBookGroupInfoViewController *group = [[JBoCloudAddressBookGroupInfoViewController alloc] init];
        group.delegate = self;
        group.black = self.black;
        group.groupInfos = self.groupArray;
        group.selectedIndex = self.slideIndexPath.section - 1;
        
        [self.navigationController pushViewController:group animated:YES];
        [group release];
    }
}

- (void)slideCellDidExpanded:(JBoSlideCell *)cell
{
    //收缩上一个滑出的cell
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    if(self.slideIndexPath != nil && self.slideIndexPath.section != indexPath.section && self.slideIndexPath.row != indexPath.row)
    {
        JBoCloudAddressBookCell *cell = (JBoCloudAddressBookCell*)[_tableView cellForRowAtIndexPath:self.slideIndexPath];
        cell.position = JBoSlideCellPositionNormal;
    }
    
    self.slideIndexPath = indexPath;
}

#pragma mark- actionSheet
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(actionSheet.tag == 1000)
    {
        JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:self.selectedIndexPath];
        switch (buttonIndex)
        {
            case 0 :
            {
                [self callOutWithPhoneNum:bookInfo.phoneNum];
            }
                break;
            case 1 :
            {
                UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
                if(![NSString isEmpty:bookInfo.phoneNum])
                {
                    pasteboard.string = bookInfo.phoneNum;
                }
                
                [JBoUserOperation alertMsg:[NSString stringWithFormat:@"%@成功",[actionSheet buttonTitleAtIndex:buttonIndex]]];
            }
                break;
            case 2 :
            {
                if(![[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"取消"])
                {
                    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
                    if(![NSString isEmpty:bookInfo.remark])
                    {
                        pasteboard.string = bookInfo.remark;
                    }
                    
                    [JBoUserOperation alertMsg:[NSString stringWithFormat:@"%@成功",[actionSheet buttonTitleAtIndex:buttonIndex]]];
                }
                else
                {
                    self.selectedIndexPath = nil;
                }
            }
                break;
            default:
            {
                self.selectedIndexPath = nil;
            }
                break;
        }
    }
    else
    {
        switch (buttonIndex)
        {
            case 0 :
            {
                JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:self.selectedIndexPath];
                JBoCloudAddressBookGroupInfo *groupInfo = [self groupInfoForSection:self.selectedIndexPath.section];
                self.isRequesting = YES;
                _httpRequest.identifier = _removeCloudAddressBookContactIdentifier_;
                
                [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation removeCloudAddressBookContact] dic:[JBoCloudAddressBookOperation removeCloudAddressBookContactParamWithId:bookInfo.Id groupId:groupInfo.Id]];
            }
                break;
                
            default:
                break;
        }
    }
}

#pragma mark- JBoCloudAddressBookGroupInfoViewController代理

- (void)cloudAddressBookGroupInfoViewController:(JBoCloudAddressBookGroupInfoViewController *)viewController didSelectInfo:(JBoCloudAddressBookGroupInfo *)info
{
    [viewController back];
    
    self.isRequesting = YES;

    JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:self.selectedIndexPath];
    self.groupSelectedIndex = [self.groupArray indexOfObject:info];
    
    _httpRequest.identifier = _moveCloudAddressBookContactIentifier_;
    [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation moveCloudAddressBookContact] dic:[JBoCloudAddressBookOperation moveCloudAddressBookContactParamWithId:bookInfo.Id groupId:info.Id groupName:nil]];
    
    [_tableView reloadData];
}

#pragma mark- 获取每一行的数据

//获取通讯录数据
- (JBoCloudAddressBookInfo*)infoForIndexPath:(NSIndexPath*) indexPath
{
    if(self.searching)
    {
        JBoCloudAddressBookInfo *bookInfo = [_searchResultArray objectAtIndex:indexPath.row];
        return bookInfo;
    }
    else
    {
        JBoCloudAddressBookGroupInfo *info = [self.groupArray objectAtIndex:indexPath.section - 1];
        JBoCloudAddressBookInfo *bookInfo = [info.infos objectAtIndex:indexPath.row];
        return bookInfo;
    }
}

- (JBoCloudAddressBookGroupInfo*)groupInfoForSection:(NSInteger) section
{
    return [self.groupArray objectAtIndex:section - 1];
}


#pragma mark- scrollView代理

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewWillBeginScroll:scrollView];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidScroll:scrollView];
        _refreshView.hidden = scrollView.contentOffset.y >= 0;
    }
}


#pragma mark-下拉刷新

// 加载数据
- (void)reloadTableViewDataSource
{
    _isLoading = YES;
    [self loadInfo];
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading
{
    _isLoading = NO;
    [_tableView reloadData];
    [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:_tableView];
    [_tableView setExtraCellLineHidden];
}

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

@end
