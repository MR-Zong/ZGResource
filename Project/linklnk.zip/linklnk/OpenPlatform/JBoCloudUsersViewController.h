//
//  JBoCloudUsersViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-8-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**云通讯录
 */
@interface JBoCloudUsersViewController : JBoViewController


@end
