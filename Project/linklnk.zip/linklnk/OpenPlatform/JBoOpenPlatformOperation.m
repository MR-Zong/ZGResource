//
//  JBoOpenPlatformOperation.m
//  靓咖
//
//  Created by kinghe005 on 14-8-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformOperation.h"
#import "JBoBasic.h"
#import "JBoUserOperation.h"
#import "JBoOpenPlatformInfo.h"
#import "JSONKit.h"
#import "JBoImageTextTool.h"
#import "JBoOpenPlatformWebStyleInfo.h"
#import "JBoOpenPlatformSubscribeInfo.h"
#import "JBoOrderListInfo.h"
#import "NSMutableURLRequest+utilities.h"

@implementation JBoOpenPlatformOperation

#pragma mark- 获取名片信息

/**获取我的云名片信息 可通过可见范围筛选
 *@param pageNum 页码
 *@param rows 每页的数量
 *@param visible 可见范围 当传入NSNotFound时 表示该参数不上传
 */
+ (NSString*)getUserOpenPlatformInfoWithLastId:(long long)lastId rows:(int)rows visible:(NSInteger)visible
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%d&%@=%@", _getUserOpenPlatformInfo_, _rows_, rows, _rosterUserId_, [JBoUserOperation getUserId]];
    if(visible != NSNotFound)
    {
        url = [NSString stringWithFormat:@"%@&%@=%d", url, _openPlatformVisible_, (int)visible];
    }
    
    if(lastId != 0)
    {
        url = [NSString stringWithFormat:@"%@&%@=%lld", url, _openPlatformId_, lastId];
    }
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    return url;
}

/**解析我的云名片信息
 *@return 数组元素是 JBoOpenPlatformInfo 对象
 */
+ (NSMutableArray*)getUserOpenPlatformInfoFromData:(NSData*) data
{
    if(data == nil)
        return nil;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    
    if(![dic isKindOfClass:[NSDictionary class]])
        return nil;
    
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"--- %@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoOpenPlatformInfo *info = [[JBoOpenPlatformInfo alloc] init];
            [info infoFromDictionary:dict];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return infoArray;
    }
    
    return nil;
}

#pragma mark- 上传名片信息

/**上传云名片信息 URL
 */
+ (NSString*)uploadOpenPlatformInfo
{
    NSString *url = _uploadOpenPlatformInfo_;
    
    return url;
}

/**上传云名片信息参数 图文
 *@param visible 可见范围
 *@param widths 图片宽度组合 用;分开
 *@param heights 图片高度组合 用;分开
 *@param content 内容
 *@param Id 云名片信息Id 没有则为0
 *@param title 云名片信息标题
 *@param imageCountAfterText 云名片文本信息后面的图片数量
 *@param imageIndex 选中的图片下标，添加图片时用到，值为NSNotFound时，不传
 *@param imagePosition 图片插入的位置，添加图片时用到，值为NSNotFound时，不传
 *@param imageCountAfterTitle 云名片标题后面的图片数量
 *@param font 信息内容字体
 *@param textColor 信息内容颜色
 *@param styleRange 信息样式范围
 *@param fontSize 信息内容字体大小
 *@param addrInfo 地址信息
 *@param groupId 分组Id
 *@param price 商品价格
 *@return post请求参数
 */
+ (NSDictionary*)uploadOpenPlatformInfoParamWithVisible:(NSInteger) visible widths:(NSString *)widths heights:(NSString *)heights content:(NSString *)content webStyleId:(long long)webStyleId Id:(long long)Id title:(NSString *)title imageCountAfterText:(NSString *)imageCountAfterText imageIndex:(NSInteger)imageIndex imagePosition:(NSInteger)imagePosition imageCountAfterTitle:(NSString*) imageCountAfterTitle font:(NSString *)font textColor:(NSString *)textColor styleRange:(NSString *)styleRange fontSize:(NSString *)fontSize addrInfo:(JBoMapInfo *)addrInfo groupId:(long long)groupId price:(float) price
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:[NSNumber numberWithInteger:_openPlatformTypeImageAndText_] forKey:_openPlatformType_];
    [dic setObject:[NSNumber numberWithInteger:visible] forKey:_openPlatformVisible_];
    
    if(![NSString isEmpty:widths])
    {
        [dic setObject:widths forKey:_openPlatformWidths_];
    }
    
    if(![NSString isEmpty:heights])
    {
        [dic setObject:heights forKey:_openPlatformHeights_];
    }
    
    if(![NSString isEmpty:content])
    {
        [dic setObject:content forKey:_openPlatformContent_];
    }
    
    if(![NSString isEmpty:imageCountAfterText])
    {
        [dic setObject:imageCountAfterText forKey:_openPlatformImageCountAfterText_];
    }
    
    [dic setObject:[NSNumber numberWithLongLong:webStyleId] forKey:_openPlatformWebStyleId_];
    
    if(Id != 0)
    {
        [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    }
    
    if(![NSString isEmpty:title])
    {
        [dic setObject:title forKey:_openPlatformTitle_];
    }
    
    if(imageIndex != NSNotFound)
    {
        [dic setObject:[NSNumber numberWithInteger:imageIndex] forKey:_openPlatformUpdateImageIndex_];
    }
    
    if(imagePosition != NSNotFound)
    {
        [dic setObject:[NSNumber numberWithInteger:imagePosition] forKey:_openPlatformUpdateImagePosition_];
    }
    
    if(![NSString isEmpty:imageCountAfterTitle])
    {
        [dic setObject:imageCountAfterTitle forKey:_openPlatformImageCountAfterTitle_];
    }
    
    if(![NSString isEmpty:font])
    {
        [dic setObject:font forKey:_openPlatformContentFontStyle_];
    }
    
    if(![NSString isEmpty:fontSize])
    {
        [dic setObject:fontSize forKey:_openPlatformContentFontSize_];
    }
    
    if(![NSString isEmpty:textColor])
    {
        [dic setObject:textColor forKey:_openPlatformContentTextColor_];
    }
    
    if(![NSString isEmpty:styleRange])
    {
        [dic setObject:styleRange forKey:_openPlatformContentStyleRange_];
    }
    
    NSString *str = [addrInfo addr];
    if(str != nil)
    {
        [dic setObject:str forKey:_openPlatformAddr_];
        [dic setObject:[NSNumber numberWithDouble:addrInfo.coordinate.latitude] forKey:_openPlatformLat_];
        [dic setObject:[NSNumber numberWithDouble:addrInfo.coordinate.longitude] forKey:_openPlatformLon_];
    }
    
    if(groupId > 0)
    {
        [dic setObject:[NSNumber numberWithLongLong:groupId] forKey:_openPlatformRelateGroupId_];
    }
    
    if(price != 0)
    {
        [dic setObject:[NSNumber numberWithInt:_openPlatformTypeMall_] forKey:_openPlatformType_];
        [dic setObject:[NSNumber numberWithFloat:price] forKey:_openPlatformPrice_];
    }
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**上传云名片信息 链接
 *@param title 链接标题
 *@param url 链接
 *@param width 链接的图片宽度
 *@param height 链接的图片高度
 *@param groupId 分组Id
 *return post 请求参数
 */
+ (NSDictionary*)uploadOPenPlatformLinkInfoParamWithTitle:(NSString*) title url:(NSString*) url width:(int)width height:(int)height groupId:(long long)groupId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:[NSNumber numberWithInteger:_openPlatformTypeLink_] forKey:_openPlatformType_];
    [dic setObject:[NSNumber numberWithInteger:_openPlatformVisibleShow_] forKey:_openPlatformVisible_];
    
 
    [dic setObject:[NSString stringWithFormat:@"%d", width] forKey:_openPlatformWidths_];

    [dic setObject:[NSString stringWithFormat:@"%d", height] forKey:_openPlatformHeights_];
    
    if(![NSString isEmpty:url])
    {
        [dic setObject:url forKey:_openPlatformContent_];
    }

    [dic setObject:@"0" forKey:_openPlatformImageCountAfterText_];
    
    [dic setObject:[NSNumber numberWithLongLong:0] forKey:_openPlatformWebStyleId_];
    
    
    if(![NSString isEmpty:title])
    {
        [dic setObject:title forKey:_openPlatformTitle_];
    }

    [dic setObject:@"0" forKey:_openPlatformImageCountAfterTitle_];
    
    if(groupId > 0)
    {
        [dic setObject:[NSNumber numberWithLongLong:groupId] forKey:_openPlatformRelateGroupId_];
    }
    
    NSLog(@"%@", dic);
    
    return dic;
}

/**解析上传云名片信息返回数据
 *@return nil时表示上传失败 否则上传成功
 */
+ (JBoOpenPlatformInfo*)uploadOpenPlatformInfoFromData:(NSData*) data
{
    if(data == nil)
        return nil;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    
    if(![dic isKindOfClass:[NSDictionary class]])
        return nil;
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        JBoOpenPlatformInfo *info = [[JBoOpenPlatformInfo alloc] init];
        [info infoFromDictionary:dict];
        
        return [info autorelease];
    }
    
    return nil;
}


#pragma mark- 修改名片信息

/**修改可见范围 URL
 */
+ (NSString*)modifyOpenPlatformInfo
{
    return _modifyOpenPlatformInfoVisible_;
}

/**修改可见范围
 *@param visible 可见范围
 *@param Id 信息标识
 */
+ (NSDictionary*)modifyOpenPlatformInfoParamWithVisible:(NSInteger)visible withId:(long long)Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithInteger:visible] forKey:_openPlatformVisible_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**删除名片信息 URL
 */
+ (NSString*)removeOpenPlatformInfo
{
    return _removeOpenPlatformInfo_;
}

/**删除名片信息
 *@param Id 信息标识
 */
+ (NSDictionary*)removeOpenPlatformInfoParamWithId:(long long)Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**删除名片信息的某张图片 URL
 */
+ (NSString*)removeOneImageAtOpenPlatform
{
    return _removeOneImageAtOpenPlatform_;
}

/**删除名片信息的某张图片 参数
 *@param info 云名片信息
 *@param index 要删除的图片所在下标
 *@param textIndex 图片所属的文本下标
 *@return post请求参数
 */
+ (NSDictionary*)removeOneImageAtOpenPlatformParamWithInfo:(JBoOpenPlatformInfo*) info atIndex:(NSInteger) index textIndex:(NSInteger)textIndex
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:info.Id] forKey:_openPlatformId_];

    JBoOpenPlatformTextInfo *textInfo = [info.contentInfos objectAtIndex:textIndex];
    JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:index];
    
    //判断图片是否删完。删完则和下个一文本合并
    if(textInfo.imageCount == 1 && textIndex != info.contentInfos.count - 1)
    {
        JBoOpenPlatformTextInfo *textInfo2 = [info.contentInfos objectAtIndex:textIndex + 1];
        JBoOpenPlatformTextInfo *newTextInfo = [JBoOpenPlatformTextInfo combineInfo:textInfo withOther:textInfo2];
        
        NSMutableArray *textInfos = [NSMutableArray arrayWithArray:info.contentInfos];
        [textInfos insertObject:newTextInfo atIndex:textIndex];
        [textInfos removeObject:textInfo];
        [textInfos removeObject:textInfo2];
        
        NSDictionary *textParam = [JBoOpenPlatformInfo textParamFromTextInfos:textInfos];
        [dic addEntriesFromDictionary:textParam];
    }
    else
    {
        NSString *separator = _openPlatformSeprator_;
        NSMutableString *imageCount = [NSMutableString string];
        for(JBoOpenPlatformTextInfo *textInfo in info.contentInfos)
        {
            int count = textInfo.imageCount;
            if([textInfo isEqual:textInfo])
            {
                count = textInfo.imageCount - 1;
            }
            
            if(count < 0)
                count = 0;
            
            [imageCount appendFormat:@"%d%@", count, separator];
        }
        
        [imageCount removeLastCharacter];
        [dic setObject:imageCount forKey:_openPlatformImageCountAfterText_];
    }
    
    //获取图片信息参数
    NSMutableArray *imageInfos = [NSMutableArray arrayWithArray:info.imageInfos];
    [imageInfos removeObjectAtIndex:index];
    [dic addEntriesFromDictionary:[JBoOpenPlatformInfo imageParamFromImageInfos:imageInfos]];
    
    if(![NSString isEmpty:imageInfo.thumbnailURL])
    {
        [dic setObject:imageInfo.thumbnailURL forKey:_openPlatformRemoveOneThumbnailURL_];
    }
    
    if(![NSString isEmpty:imageInfo.imageURL])
    {
        [dic setObject:imageInfo.imageURL forKey:_openPlatformRemoveOneImageURL_];
    }
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**更新名片信息的某张图片 URL
 */
+ (NSString*)updateOneImageAtOpenPlatform
{
    return _updateOneImageAtOpenPlatform_;
}

/**更新名片信息的某张图片 参数
 *@param Id 信息标识
 *@param updatedImageURL 要更新的图片路径
 *@param images 所有图片路径
 */
+ (NSDictionary*)updateOneImageAtOpenPlatformParamWithId:(long long) Id updatedImageURL:(NSString*) updatedImageURL images:(NSString*) images imageSize:(CGSize)size
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    
    if(![NSString isEmpty:updatedImageURL])
    {
        [dic setObject:updatedImageURL forKey:_openPlatformUpdatedImage_];
    }
    
    [dic setObject:images forKey:_openPlatformImages_];
    [dic setObject:[NSString stringWithFormat:@"%d", (int)size.width] forKey:_openPlatformUpdateImageWidth_];
    [dic setObject:[NSString stringWithFormat:@"%d", (int)size.height] forKey:_openPlatformUpdateImageHeight_];
    
    return dic;
}

/**解析更新名片信息的某张图片 返回数据
 */
+ (NSDictionary*)getUpdaeOneImageFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        
        return dict;
    }
    
    return nil;
}

/**设置名片信息的置顶状态 URL
 */
+ (NSString*)setupOpenPlatformInfoStick
{
    return _setupOpenPlatformInfoStick_;
}

/**设置名片信息的置顶状态 参数
 *@param stick 置顶状态 'NO' 是取消置顶 'YES' 是置顶
 *@param Id 信息标识
 */
+ (NSDictionary*)setupOpenPlatformInfoStick:(BOOL) stick withId:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:[NSNumber numberWithBool:stick] forKey:_openPlatformStick_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    
    return dic;
}

/**更新名片信息的顺序 URL
 */
+ (NSString*)updateOpenPlatformInfoOrder
{
    return _updateOpenPlatformInfoOrder_;
}

/**更新名片信息的顺序 参数
 *@param Id 信息标识
 */
+ (NSDictionary*)updateOpenPlatformInfoOrderParamWithId:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    return dic;
}

/**解析更新名片信息的顺序返回数据
 *return 新的名片信息排序ID
 */
+ (double)updateOpenPlatformInfoOrderResultFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
   // NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        double sortId = [[dict valueWithKey:_openPlatformSortId_] doubleValue];
        
        return sortId;
    }
    
    return 0;
}

/**移动名片信息的顺序 URL
 */
+ (NSString*)moveOpenPlatformInfoOrder
{
    return _moveOpenPlatformInfoOrder_;
}

/**移动名片信息的顺序 参数
 *@param moveId 要移动的名片信息 标识
 *@param frontId 要排在之后的名片信息 标识
 */
+ (NSDictionary*)moveOpenPlatformInfoOrderParamWithMoveId:(long long) moveId frontSortId:(double)frontSortId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    [dic setObject:[NSNumber numberWithLongLong:moveId] forKey:_openPlatformMoveId_];
    [dic setObject:[NSNumber numberWithDouble:frontSortId] forKey:_openPlatformFrontId_];
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**解析移动名片信息的顺序返回数据
 *return 新的名片信息排序ID
 */
+ (double)moveOpenPlatformInfoOrderResultFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
  
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        double sortId = [[dict valueWithKey:_openPlatformSortId_] doubleValue];
        
        return sortId;
    }
    
    return 0;
}

#pragma mark- 图片关联的链接

/**更新名片图片链接 URL
 */
+ (NSString*)updateOpenPlatformInfoImageRelatedURL
{
    return _updateOpenPlatformInfoRelatedURL_;
}

/**更新名片图片链接 参数
 *@param Id 名片信息标识
 *@param imageURL 关联的图片的图片路径
 *@param userId 关联的用户 userId
 *@param linkURL 关联的链接
 */
+ (NSDictionary*)updateOpenPlatformInfoImageRelatedURLParamWithId:(long long) Id imageURL:(NSString*) imageURL relatedUserId:(NSString*) userId linkURL:(NSString*) url
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:imageURL forKey:_openPlatformRelatedURL_];
    
    if(userId != nil)
    {
        [dic setObject:userId forKey:_openPlatformRelatedUserId_];
    }
    else
    {
        [dic setValue:url forKey:_openPlatformReleatedCustomerURL_];
    }
    
    return dic;
}

/**解析更新名片图片链接 返回的数据
 *@param data 返回的数据
 *@return 更新成功后的关联链接
 */
+ (NSString*)updateOpenPlatformInfoImageRelatedURLResultFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        NSString *url = [dict objectWithKey:_openPlatformRelatedResult_];
        
        return url;
    }
    
    return nil;
}

/**删除名片图片链接 URL
 */
+ (NSString*)removeOpenPlatformInfoImageRelatedURL
{
    return _removeOpenPlatformInfoRelatedURL_;
}

/**删除名片图片链接 参数
 *@param Id 名片信息标识
 *@param relatedURL 关联的链接
 */
+ (NSDictionary*)removeOpenPlatformInfoImageRelatedURLParamWithId:(long long) Id relatedURL:(NSString*) relatedURL
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:relatedURL forKey:_openPlatformRelatedURL_];
    
    NSLog(@"%@",dic);
    
    return dic;
}

#pragma mark- 云名片文本

/**删除云名片文本信息 URL
 *@return post 请求url
 */
+ (NSString*)removeOpenPlatformTextInfo
{
    return _removeOpenPlatformTextInfo_;
}

/**删除云名片文本信息 参数
 *@param Id 云名片信息Id
 *@param text 要删除的云名片文本信息
 *@return post请求参数
 */
+ (NSDictionary*)removeOpenPlatformTextInfoParamWithId:(long long) Id text:(NSString*) text index:(NSInteger)index
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:text forKey:_openPlatformOldTextInfo_];
    [dic setObject:[NSNumber numberWithInteger:index] forKey:_openPlatformTextIndex_];
    
    return dic;
}

/**修改云名片文本信息 URL
 *@return post 请求url
 */
+ (NSString*)modifyOpenPlatformTextInfo
{
    return _modifyOpenPlatformTextInfo_;
}

/**修改云名片文本信息 参数
 *@param Id 云名片信息Id
 *@param oldText 旧的云名片文本信息
 *@param newsText 新的云名片文本信息
 *@param index 要修改的云名片文本下标
 *@param imageNum 云名片文本信息后面的图片数量
 *@param position 信息插入的位置，为NSNotFound时不传
 *@param font 信息内容字体
 *@param textColor 信息内容颜色
 *@param styleRange 信息样式范围
 *@param fontSize 信息内容字体大小
 *@return post 请求参数
 */
+ (NSDictionary*)modifyOpenPlatformTextInfoParamWithId:(long long) Id oldText:(NSString*) oldText newsText:(NSString*) newsText index:(NSInteger)index imageNumAfterText:(NSString*)imageNum position:(NSInteger)position font:(NSString*)font textColor:(NSString *)textColor styleRange:(NSString *)styleRange fontSize:(NSString *)fontSize
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    
    if(![NSString isEmpty:oldText])
    {
        [dic setObject:oldText forKey:_openPlatformOldTextInfo_];
    }
    
    if(![NSString isEmpty:newsText])
    {
        [dic setObject:newsText forKey:_openPlatformNewsTextInfo_];
    }
    
    [dic setObject:[NSNumber numberWithInteger:index] forKey:_openPlatformTextIndex_];
    
    if(![NSString isEmpty:imageNum])
    {
        [dic setObject:imageNum forKey:_openPlatformUpdateImageNumAfterText_];
    }
    
    if(position != NSNotFound)
    {
        [dic setObject:[NSNumber numberWithInteger:position] forKey:_openPlatformTextPosition_];
    }
    
    if(![NSString isEmpty:font])
    {
        [dic setObject:font forKey:_openPlatformContentFontStyle_];
    }
    
    if(![NSString isEmpty:fontSize])
    {
        [dic setObject:fontSize forKey:_openPlatformContentFontSize_];
    }
    
    if(![NSString isEmpty:textColor])
    {
        [dic setObject:textColor forKey:_openPlatformContentTextColor_];
    }
    
    if(![NSString isEmpty:styleRange])
    {
        [dic setObject:styleRange forKey:_openPlatformContentStyleRange_];
    }
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**修改云名片标题 url
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformTitle
{
    return _modifyOpenPlatformTitle_;
}

/**修改云名片标题 参数
 *@param Id 云名片Id
 *@param title 新的云名片标题
 *@param imageNum 云名片标题后面的图片数量
 *@param price 商品价格
 *@return post 请求参数
 */
+ (NSDictionary*)modifyOpenPlatformTitleParamWithId:(long long)Id title:(NSString *)title imageNumAfterTitle:(int)imageNum price:(float)price
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:title forKey:_openPlatformTitle_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:[NSString stringWithFormat:@"%d", imageNum] forKey:_openPlatformImageCountAfterTitle_];
    
    if(price != 0)
    {
        [dic setObject:[NSNumber numberWithFloat:price] forKey:_openPlatformPrice_];
    }
    
    NSLog(@"%@", dic);
    
    return dic;
}

/**更新云名片信息 url
 *@return post请求url
 */
+ (NSString*)updateOpenPlatformInfo
{
   // NSLog(@"%@",_updateOpenPlatformInfo_);
    return _updateOpenPlatformInfo_;
}

/**更新云名片信息 参数
 *@param info  云名片信息
 *@param index  需要更新的文本下标 或新的文本信息插入的位置
 *@param newTextInfos 新的文本信息 数组元素是 JBoOpenPlatformTextInfo对象
 *@param type 云名片编辑类型
 *@param newImageInfos 新的图片信息
 *@param imageIndex 所属文本的图片的下标
 @return post请求参数
 */
+ (NSDictionary*)updateOpenPlatformInfoParamWithInfo:(JBoOpenPlatformInfo*) info atIndex:(NSInteger) index newTextInfos:(NSArray*) newTextInfos type:(JBoOpenPlatformEditType) type newImageInfos:(NSArray*) newImageInfos imageIndex:(int) imageIndex
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    [dic setObject:[NSNumber numberWithLongLong:info.Id] forKey:_openPlatformId_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    NSMutableArray *textInfos = [NSMutableArray arrayWithArray:info.contentInfos];
    
    JBoOpenPlatformTextInfo *textInfo1 = nil;
    JBoOpenPlatformTextInfo *textInfo2 = nil;
    
    
    
    //添加或更改
    if(newTextInfos.count > 0)
    {
//        NSLog(@"imageIndex %d",imageIndex);
//        NSLog(@"index = %d", index);
//        NSLog(@"type = %d", type);
        
        NSInteger idex = index;
        switch (type)
        {
            case JBoOpenPlatformEditTypeModifyText :
            {
                // 更改文本
                JBoOpenPlatformTextInfo *textInfo = [info.contentInfos objectAtIndex:index];
                textInfo1 = [newTextInfos lastObject];
                textInfo1.imageCount += textInfo.imageCount;
                
                [textInfos removeObjectAtIndex:index];
            }
                break;
            case JBoOpenPlatformEditTypeAddAfterImage :
            case JBoOpenPlatformEditTypeAddBeforeImage :
            {
                idex ++;
                //重新划分文本后面的图片数量
                if(index < info.contentInfos.count)
                {
                    JBoOpenPlatformTextInfo *tf1 = [info.contentInfos objectAtIndex:index];
                    JBoOpenPlatformTextInfo *tf2 = [newTextInfos lastObject];
                    
                    tf2.imageCount += tf1.imageCount - imageIndex;
                    tf1.imageCount = imageIndex;
                }
            }
                break;
            case JBoOpenPlatformEditTypeAddAfterText :
            {
                idex ++;
            }
                break;
            default:
                break;
        }
        
        if(idex < textInfos.count)
        {
            [textInfos insertObjects:newTextInfos atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(idex, newTextInfos.count)]];
        }
        else
        {
            [textInfos addObjectsFromArray:newTextInfos];
        }
      
        [JBoOpenPlatformInfo combineTextInfos:textInfos];
    }
    else
    {
        switch (type)
        {
            case JBoOpenPlatformEditTypeDeleteText :
            {
                //删除文本
                JBoOpenPlatformTextInfo *textInfo = [info.contentInfos objectAtIndex:index];
                
                textInfo1 = [[[JBoOpenPlatformTextInfo alloc] init] autorelease];
                textInfo1.content = textInfo.content;
                textInfo1.imageCount = textInfo.imageCount;
                textInfo1.textStyleInfos = textInfo.textStyleInfos;
                
                if(index > 0)
                {
                    //文本图片数量上移
                    textInfo2 = [textInfos objectAtIndex:index - 1];
                    textInfo2.imageCount += textInfo1.imageCount;
                    [textInfos removeObjectAtIndex:index];
                }
                else
                {
                    textInfo1.content = @"";
                    textInfo1.textStyleInfos = nil;
                    [textInfos replaceObjectAtIndex:index withObject:textInfo1];
                }
            }
                break;
            default:
                break;
        }
    }
    
    if(newImageInfos.count > 0)
    {
        NSInteger num = 0;
        for(NSInteger i = 0;i < index && i < info.contentInfos.count;i ++)
        {
            JBoOpenPlatformTextInfo *tmp = [info.contentInfos objectAtIndex:i];
            num += tmp.imageCount;
        }
        num = MIN(num, info.imageInfos.count);
        num += imageIndex;

        [dic setObject:[NSNumber numberWithInteger:num] forKey:_updateOpenPlatformImagePositon_];
        
        NSMutableArray *imageInfos = [NSMutableArray arrayWithArray:info.imageInfos];
        if(num < imageInfos.count)
        {
            [imageInfos insertObjects:newImageInfos atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(num, newImageInfos.count)]];
        }
        else
        {
            [imageInfos addObjectsFromArray:newImageInfos];
        }
        
        NSDictionary *imageParam = [JBoOpenPlatformInfo imageParamFromImageInfos:imageInfos];
        
        [dic addEntriesFromDictionary:imageParam];
        
        if(newTextInfos.count == 0)
        {
            if(index < info.contentInfos.count)
            {
                textInfo1 = [info.contentInfos objectAtIndex:index];
            }
            else
            {
                textInfo1 = [[[JBoOpenPlatformTextInfo alloc] init] autorelease];
                textInfo1.content = @"";
            }
            
            textInfo1.imageCount += (int)newImageInfos.count;
        }
    }
    
    NSDictionary *textParam = [JBoOpenPlatformInfo textParamFromTextInfos:textInfos];
    [dic addEntriesFromDictionary:textParam];

    //还原图片数量
    textInfo2.imageCount -= textInfo1.imageCount;
    if(newTextInfos.count == 0 && textInfo1 != nil)
    {
        textInfo1.imageCount -= (int)newImageInfos.count;
    }
    
    NSLog(@"%@",dic);
    
    return dic;
}

/**从返回的数据获取已更新的云名片信息
 *@param data 返回的数据
 *@return 新的云名片信息
 */
+ (JBoOpenPlatformInfo*)updatedOpenPlatformInfoFromData:(NSData*) data
{
    if(data == nil)
        return nil;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    
    if(![dic isKindOfClass:[NSDictionary class]])
        return nil;
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        JBoOpenPlatformInfo *info = [[JBoOpenPlatformInfo alloc] init];
        [info infoFromDictionary:dict];
        
        return [info autorelease];
    }
    
    return nil;
}

#pragma mark- 云名片样式

/**获取云名片样式
 *@return get请求url
 */
+ (NSString*)getOpenPlatformWebStyle
{
    return [JBoUserOperation md5Url:_getOpenPlatformWebStyleInfo_ withUserId:YES];
}

/**从返回的数据获取云名片样式信息
 *@param data 返回的数据
 *@return 数组元素是 JBoOpenPlatformWebStyleInfo对象
 */
+ (NSMutableArray*)getOpenPlatformWebStyleFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        
        for(NSDictionary *groupDic in dataArray)
        {
            JBoOpenPlatformWebStyleGroupInfo *groupInfo = [[JBoOpenPlatformWebStyleGroupInfo alloc] init];
            groupInfo.Id = [[groupDic valueWithKey:_openPlatformWebStyleGroupId_] longLongValue];
            groupInfo.name = [groupDic objectWithKey:_openPlatformWebStyleGroupName_];
            
            NSArray *groupInfoArray = [groupDic arrayForKey:_openPlatformWebStyleGroupInfo_];
            NSMutableArray *infos = [NSMutableArray arrayWithCapacity:groupInfoArray.count];
            
            for(NSDictionary *dict in groupInfoArray)
            {
                JBoOpenPlatformWebStyleInfo *info = [[JBoOpenPlatformWebStyleInfo alloc] init];
                
                info.Id = [[dict valueWithKey:_openPlatformWebStyleId_] longLongValue];
                info.name = [dict objectWithKey:_openPlatformWebStyleName_];
                info.intro = [dict objectWithKey:_openPlatformWebStyleIntro_];
                
                NSString *urls = [dict objectWithKey:_openPlatformWebStyleImage_];
                info.imageURLs = [JBoImageTextTool getImageURLsFromStr:urls];
                
                NSString *widths = [dict objectWithKey:_openPlatformWebStyleImageWidth_];
                info.imageWidths = [JBoImageTextTool getImageURLsFromStr:widths];
                
                NSString *heights = [dict objectWithKey:_openPlatformWebStyleImageHeight_];
                info.imageHeights = [JBoImageTextTool getImageURLsFromStr:heights];
                
                info.imageCount = [[dict valueWithKey:_openPlatformWebStyleImageCount_] integerValue];
                info.textCount = [[dict valueWithKey:_openPlatformWebStyleTextCount_] integerValue];
                
                [infos addObject:info];
                [info release];
            }
            
            groupInfo.webStyleInfos = infos;
            [infoArray addObject:groupInfo];
            [groupInfo release];
        }
        
        return infoArray;
    }
    
    return nil;
}

/**修改云名片样式 URL
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformWebStyle
{
    return _modifyOpenPlatformWebStyle_;
}

/**修改云名片样式 url
 *@param Id 云名片信息Id
 *@param webStyleId 云名片信息样式Id
 *@return post请求参数
 */
+ (NSDictionary*)modifyOpenPlatformWebStyleParamWithId:(long long) Id webStyleId:(long long) webStyleId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:[NSNumber numberWithLongLong:webStyleId] forKey:_openPlatformWebStyleId_];
    
    return dic;
}

#pragma mark- 云名片预约

/**获取云名片信息预约的人
 *@param Id 云名片信息Id
 *@return get请求url
 */
+ (NSString*)getOpenPlatFormSubscribeInfoWithId:(long long) Id
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%lld", _getOpenplatformSubscribeInfo_, _openPlatformId_, Id];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    return url;
}

/**从返回的数据获取预约的人的信息
 *@param data 返回的数据
 *@reuturn 数组元素是 JBoOpenPlatformSubscribeInfo对象
 */
+ (NSMutableArray*)getOpenPlatFormSubscribeInfoFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoOpenPlatformSubscribeInfo *info = [[JBoOpenPlatformSubscribeInfo alloc] init];
            
            info.tel = [dict objectWithKey:_openplatformSubscribeTel_];
            info.name = [dict objectWithKey:_openplatformSubscribeName_];
            info.time = [dict objectWithKey:_openplatformSubscribeTime_];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return infoArray;
    }
    
    return nil;
}

#pragma mark- 云名片链接二维码图片

/**获取云名片链接的二维码图片
 *@param image 二维码图片
 *@param info 云名片信息
 *@param headImage 头像
 *@param linkIcon 靓咖标记
 *@param margin 二维码边界
 *@return 一个 UIImage对象
 */
+ (UIImage*)getOpenPlatformQRCodeImageFormImage:(UIImage*) image info:(JBoOpenPlatformInfo*) info headImage:(UIImage *)headImage linkIcon:(UIImage *)linkIcon margin:(CGFloat)margin
{
    if(image == nil)
        return nil;
    UIFont *font = [UIFont boldSystemFontOfSize:14.0];
    
    CGSize size = CGSizeZero;
    if(![NSString isEmpty:info.title])
    {
        size =  [JBoImageTextTool getStringSize:info.title withFont:font andContraintSize:image.size];
    }
    
    CGFloat height = 0;
    CGFloat padding = 10.0;
    if(size.height > padding)
    {
        height = size.height - padding;
    }
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(image.size.width, image.size.height + height + margin - padding * 2), NO, 0.0f);
    CGRect imageRect = CGRectMake(0.0, 0.0, image.size.width, image.size.height);
    [image drawInRect:imageRect];
    
    CGFloat iconSize = headImage.size.width;
    [headImage drawInRect:CGRectMake((image.size.width - iconSize) / 2.0, (image.size.height - iconSize) / 2.0, iconSize, iconSize)];
    iconSize = linkIcon.size.width;
    [linkIcon drawInRect:CGRectMake(image.size.width - iconSize - margin, image.size.height - iconSize - margin, iconSize, iconSize)];
    
    if(![NSString isEmpty:info.title])
    {
        
        CGPoint textPt = CGPointMake((image.size.width - size.width) / 2.0, image.size.height - padding);
        UIColor *textColor = [UIColor blackColor];
        if(_ios7_0_)
        {
#if __IPHONE_7_0
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, textColor, NSForegroundColorAttributeName, nil];
            [info.title drawAtPoint:textPt withAttributes:attributes];
#endif
        }
        else
        {
            [textColor set];
            [info.title drawAtPoint:textPt withFont:font];
        }
    }
    
    UIImage *thumbnail = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    NSData *data = UIImageJPEGRepresentation(thumbnail, 1.0);
    
    UIImage *ret = nil;
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        ret = [UIImage imageWithData:data scale:thumbnail.scale];
#endif
    }
    else
    {
        ret = [UIImage imageWithData:data];
    }
    
    if(ret.imageOrientation != UIImageOrientationUp)
    {
        ret = [UIImage imageWithCGImage:ret.CGImage scale:ret.scale orientation:UIImageOrientationUp];
    }
    
    return ret == nil ? thumbnail : ret;
}

#pragma mark- 云名片位置

/**更新云名片位置信息 url
 *@return post请求url
 */
+ (NSString*)updateOpenPlatformAddress
{
    return _updateOpenPlatformAddress_;
}

/**更新云名片位置信息 参数
 *@param Id 云名片信息Id
 *@param addrInfo 位置信息
 *@return post请求参数
 */
+ (NSDictionary*)updateOpenPlatformAddressParamWithId:(long long) Id addrInfo:(JBoMapInfo*) addrInfo
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformId_];
    [dic setObject:[addrInfo addr] forKey:_openPlatformAddr_];
    [dic setObject:[NSNumber numberWithDouble:addrInfo.coordinate.latitude] forKey:_openPlatformLat_];
    [dic setObject:[NSNumber numberWithDouble:addrInfo.coordinate.longitude] forKey:_openPlatformLon_];
    
    return dic;
}

#pragma mark- 云名片订单

/**获取订单列表信息
 *@param lastId 整个列表中最后一条订单信息的Id，第一页传0
 *@param rows 每页数量
 *@param type 订单类型
 *@return get请求url
 */
+ (NSString*)getOpenPlatformOrderListWithLastId:(long long) lastId rows:(int) rows type:(int) type
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%d&%@=%d&%@=%@", _getOpenPlatfomOrderList_, _rows_, rows, _openPlatformOrderType_, type, _rosterUserId_, [JBoUserOperation getUserId]];
    if(lastId != 0)
    {
        url = [NSString stringWithFormat:@"%@&%@=%lld", url, _openPlatformOrderLastId_, lastId];
    }
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@", url);
    
    return url;
}

/**从返回的数据获取订单列表信息
 *@param data 返回的数据
 *@return 数组元素是 JBoOrderListInfo
 */
+ (NSMutableArray*)getOpenPlatformOrderListFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoOrderListInfo *info = [[JBoOrderListInfo alloc] init];
            
            [info infoFromDictionary:dict];
            [infoArray addObject:info];
            
            [info release];
        }
        
        return infoArray;
    }
    
    return nil;
}

#pragma mark- 云名片链接识别

/**是否是云名片链接
 *@param url 一个http链接
 */
+ (BOOL)isOpenPlatformURL:(NSString*) url
{
    if([NSString isEmpty:url])
        return NO;
    
    NSString *prefix = [NSString stringWithFormat:@"%@platformInfo", _domainName_];
    if([url hasPrefix:prefix])
    {
        return YES;
    }
    
    prefix = [NSString stringWithFormat:@"%@userPlatform", _domainName_];
    if([url hasPrefix:prefix])
    {
        return YES;
    }
    
    return NO;
}

/**云名片post请求
 *@param url 请求路径
 */
+ (NSURLRequest*)requestWithURL:(NSString*) url
{
    return [NSMutableURLRequest postRequestWithURL:url param:[NSDictionary dictionaryWithObject:[JBoUserOperation getUserId] forKey:_openPlatformAccessUserId_]];
}

@end
