//
//  JBoOpenPlatformTextStyleViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-10-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformTextStyleInfo;
@class JBoOpenPlatformTextStyleViewController;

/**云名片文本信息字体样式选择代理
 */
@protocol JBoOpenPlatformTextStyleViewControllerDelegate <NSObject>

/**完成颜色和字体选择
 */
- (void)openPlatformTextStyleDidSelect:(JBoOpenPlatformTextStyleViewController*) viewController;

@end

/**云名片文本信息字体样式选择
 */
@interface JBoOpenPlatformTextStyleViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,assign) id<JBoOpenPlatformTextStyleViewControllerDelegate> delegte;

//选择文本信息样式
@property(nonatomic,readonly) JBoOpenPlatformTextStyleInfo *selectedTextStyleInfo;

///**选中的样式信息
// */
//@property(nonatomic,retain) JBoOpenPlatformTextStyleInfo *textStyleInfo;

@end
