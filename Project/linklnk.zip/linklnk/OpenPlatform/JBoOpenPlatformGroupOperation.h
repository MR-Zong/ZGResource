//
//  JBoOpenPlatformGroupOperation.h
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

#define _addOpenPlatformGroupIdentifier_ @"addOpenPlatformGroup"
#define _addOpenPlatformSecondaryGroupIdentifier_ @"addOpenPlatformSecondaryGroup"
#define _removeOpenPlatformGroupIdentifier_ @"removeOpenPlatformGroup"
#define _removeOpenPlatformSecondaryGroupIdentifier_ @"removeOpenPlatformSecondaryGroup"
#define _modifyOpenPlatformGroupIdentifier_ @"modifyOpenPlatformGroup"
#define _modifyOpenPlatformSecondaryGroupIdentifier_ @"modifyOpenPlatformSecondaryGroup"
#define _getOpenPlatformGroupInfoIdentifier_ @"getOpenPlatformGroupInfo"
#define _moveOpenPlatformToGroupIdentifier_ @"moveOpenPlatformToGroup"

@class JBoOpenPlatformGroupInfo;
@class JBoOpenPlatformInfo;

/**云名片分组网络操作
 */
@interface JBoOpenPlatformGroupOperation : NSObject

/**添加云名片一级分组 url
 *@return post请求url
 */
+ (NSString*)addOpenPlatformGroup;

/**添加云名片一级分组参数
 *@param name 分组名称
 *@return post请求参数
 */
+ (NSDictionary*)addOpenPlatformGroupParamWithName:(NSString*) name;

/**从返回的数据获取新添加的云名片分组信息
 *@param data 返回的数据
 *@param error 错误码
 *@return 云名片一级分组信息
 */
+ (JBoOpenPlatformGroupInfo*)additionOpenPlatformGroupInfoFromData:(NSData*) data error:(NSInteger*) error;

/**添加云名片二级级分组 url
 *@return post请求url
 */
+ (NSString*)addOpenPlatformSecondaryGroup;

/**添加云名片二级级分组参数
 *@param name 分组名称
 *@param groupId 一级分组Id
 *@return post请求参数
 */
+ (NSDictionary*)addOpenPlatformSecondaryGroupParamWithName:(NSString*) name groupId:(long long) groupId;

/**从返回的数据获取新添加的云名片二级分组信息
 *@param data 返回的数据
 *@param error 错误码
 *@return 云名片二级级分组信息
 */
+ (JBoOpenPlatformGroupInfo*)additionOpenPlatformSecondaryGroupInfoFromData:(NSData*) data error:(NSInteger*) error;

/**删除云名片一级分组 url
 *@return post请求url
 */
+ (NSString*)removeOpenPlatformGroup;

/**删除云名片一级分组参数
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)removeOpenPlatformGroupParamWithId:(long long) Id;

/**删除云名片二级级分组 url
 *@return post请求url
 */
+ (NSString*)removeOpenPlatformSecondaryGroup;

/**删除云名片二级级分组参数
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)removeOpenPlatformSecondaryGroupParamWithId:(long long) Id;

/**修改云名片一级分组名称 url
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformGroup;

/**修改云名片一级分组名称 参数
 *@param name 新的分组名称
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)modifyOpenPlatformGroupParamWithName:(NSString*) name Id:(long long) Id;

/**修改云名片二级分组名称 url
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformSecondaryGroup;

/**修改云名片二级分组名称 参数
 *@param name 新的分组名称
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)modifyOpenPlatformSecondaryGroupParamWithName:(NSString*) name Id:(long long) Id;

/**获取云名片分组信息
 *@return get请求url
 */
+ (NSString*)getOpenPlatformGroupInfo;

/**从返回的数据获取云名片分组信息
 *@param data 返回的数据
 *@return 数组元素是 JBoOpenPlatformGroupInfo对象
 */
+ (NSMutableArray*)getOpenPlatformGroupInfoFromData:(NSData*) data;

/**移动云名片到另一个分组 参数
 *@return  post请求url
 */
+ (NSString*)moveOpenPlatformToGroup;

/**移动云名片到另一个分组 参数
 *@param info 云名片信息
 *@param groupInfo 云名片分组信息
 *@return post请求参数
 */
+ (NSDictionary*)moveOpenPlatformToGroupParamWithInfo:(JBoOpenPlatformInfo*) info groupInfo:(JBoOpenPlatformGroupInfo*) groupInfo;

@end
