//
//  JBoLocalAddressBookSyncInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLocalAddressBookSyncInfo.h"
#import "JBoCloudAddressBookGroupInfo.h"

@implementation JBoLocalAddressBookSyncInfo

- (void)dealloc
{
    [_cloudGroupInfo release];
    [super dealloc];
}

/**要显示的电话号码
 */
- (NSString*)displayPhoneNum
{
    if(self.phoneNums.count != 0)
    {
        NSMutableString *string = [NSMutableString string];
        
        NSInteger count = 0;
        for(NSString *str in self.phoneNums)
        {
            count ++;
            if(count > _syncPhoneNumMaxCount_)
                break;
            [string appendFormat:@"%@、", str];
        }
        [string removeLastStringWithString:@"、"];
        
        return string;
    }
    return nil;
}

@end
