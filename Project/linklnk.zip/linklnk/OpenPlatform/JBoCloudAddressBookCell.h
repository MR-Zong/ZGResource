//
//  JBoCloudAddressBookCell.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSlideCell.h"
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoArrowPointingView.h"
#import "JBoCloudAddressBookInfo.h"
#import "JBoHighlightView.h"

/**云名片夹备足信息字体
 */
#define _cloundAddressBookRemarkFont_ [UIFont systemFontOfSize:14.0]

/**手机图标大小
 */
#define _cloudAddressBookPhoneIconSize_ 25

/**云名片夹 sectionHeader的高度
 */
#define _cloudAddressBookHeaderHeight_ 40.0

/**云名片夹第一个section 的高度
 */
#define _cloudAddressBookFirstHeaderHeight_ 85.0

/**云名片夹 cell的高度
 */
#define _cloudAddressBookCellHeight_ 60

/**云名片夹内容与边框的间隔
 */
#define _cloudAddessBookInterval_ 10.0

#pragma mark- serctionHeader

@protocol JBoCloudAddressBookHeaderDelegate <NSObject>

/**分组展开
 *@param section 分组所在位置
 */
- (void)headerDidOpenAtSection:(NSInteger) section;

/**分组收缩
 *@param section 分组所在位置
 */
- (void)headerDidCloseAtSection:(NSInteger) section;

@optional

/**分组管理
 */
- (void)headerGroupManagerAtSection:(NSInteger) section;

/**验证问题管理
 */
- (void)headerProblemManagerAtSection:(NSInteger) section;

/**分享云名片夹
 */
- (void)headerDidShareCloudAddressBookAtSection:(NSInteger) section;

/**同步到本地通讯录
 */
- (void)headerDidSyncLocalAddressBookAtSection:(NSInteger) section;

/**本地通讯录上传到服务器
 */
- (void)headerDidSyncToServerAtSection:(NSInteger) section;

@end

#ifdef __IPHONE_6_0

@class JBoCloudAddressBookHeaderView;

/**云名片夹内的分组内容 ,ios 6.0以上才能用 tableSectionHeader
 */
@interface JBoCloudAddressBookHeader : UITableViewHeaderFooterView
/**内容
 */
@property(nonatomic,readonly) JBoCloudAddressBookHeaderView *headerView;

@end

#endif

/**云名片夹内的分组内容 ,ios 6.0以下用 tableSectionHeader
 */
@interface JBoCloudAddressBookHeaderView : JBoHighlightView

/**所在section
 */
@property(nonatomic,assign) NSInteger section;

/**左边边指示图标，表示分组是否展开
 */
@property(nonatomic,readonly) JBoArrowPointingView *rightIndicateIcon;

/**分组名称
 */
@property(nonatomic,readonly) UILabel *nameLabel;

/**分组数据数量
 */
@property(nonatomic,readonly) UILabel *countLabel;

/**关联的 sectionHeader ios6以下为 nil
 */
@property(nonatomic,assign) UIView *sectionHeader;

@property(nonatomic,assign) id<JBoCloudAddressBookHeaderDelegate> delegate;

@end



#ifdef __IPHONE_6_0

@class JBoCloudAddressBookFirstHeaderView;
/**云名片夹内的管理内容 ,ios 6.0以上才能用 tableSectionHeader
 */
@interface JBoCloudAddressBookFirstHeader : UITableViewHeaderFooterView
/**内容
 */
@property(nonatomic,readonly) JBoCloudAddressBookFirstHeaderView *headerView;

@end

#endif

/**云名片夹内的分组内容 ,ios 6.0以下用 tableSectionHeader
 */
@interface JBoCloudAddressBookFirstHeaderView : UIView

/**所在section
 */
@property(nonatomic,assign) NSInteger section;


@property(nonatomic,assign) id<JBoCloudAddressBookHeaderDelegate> delegate;

@end


#pragma mark- cell

/**云名片夹内的 tableViewCell
 */
@interface JBoCloudAddressBookCell : JBoSlideCell

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**用户名称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**备注信息
 */
@property(nonatomic,readonly) UILabel *remarkLabel;

/**手机号码
 */
@property(nonatomic,readonly) UILabel *phoneNumLabel;

/**提交时间
 */
@property(nonatomic,readonly) UILabel *timeLabel;

/**号码公开状态
 */
@property(nonatomic,readonly) UIImageView *phoneStateImageView;


/**云名片夹信息
 */
@property(nonatomic,retain) JBoCloudAddressBookInfo *info;

@end
