//
//  JBoCloudAddressBookGroupInfo.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookGroupInfo.h"

@implementation JBoCloudAddressBookGroupInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.infos = [NSMutableArray array];
    }
    
    return self;
}

- (void)dealloc
{
    [_groupName release];
    [_infos release];
    [_url release];
    
    [super dealloc];
}

@end
