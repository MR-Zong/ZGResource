//
//  JBoOpenPlatformTextInfoModifyVieController.h
//  linklnk
//
//  Created by kinghe005 on 14-10-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformEditViewController.h"

@class JBoOpenPlatformInfo;
@class JBoTextView;
@class JBoOpenPlatformInfoModifyVieController;

/**云名片信息修改
 */
@interface JBoOpenPlatformInfoModifyVieController : JBoOpenPlatformEditViewController<UITextFieldDelegate,UITextViewDelegate>

/**要修改的靓云台信息
 */
@property(nonatomic,readonly,retain) JBoOpenPlatformInfo *info;

/**要修改的文本信息下标
 */
@property(nonatomic,readonly) NSInteger modifyIndex;

/**图片下标
 */
@property(nonatomic,readonly) int imageIndex;

/**修改类型
 */
@property(nonatomic,readonly) JBoOpenPlatformEditType type;

/**构造方法
 *@param info 靓云台信息
 *@param index 要修改的文本信息下标或新信息插入的位置
 *@param imageIndex 图片的下标
 *@param type 编辑类型
 *@return 一个初始化的 JBoOpenPlatformTextInfoModifyVieController
 */
- (id)initWithInfo:(JBoOpenPlatformInfo*) info modifyIndex:(NSInteger) index imageIndex:(int) imageIndex type:(JBoOpenPlatformEditType) type;

@end
