//
//  JBoLocationSelectView.m
//  linklnk
//
//  Created by kinghe005 on 14-10-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLocationSelectView.h"
#import "JBoMapViewController.h"
#import "JBoMapInfo.h"
#import "JBoImageTextTool.h"
#import "JBoUserOperation.h"
#import "BMKGeoCodeSearch+Utilities.h"

#define _controlHeight_ 40.0

@interface JBoLocationSelectView ()<BMKGeoCodeSearchDelegate,BMKLocationServiceDelegate>

//当前位置
@property(nonatomic,retain) UIButton *curButton;

//其他位置
@property(nonatomic,retain) UIButton *otherButton;

//详细地址
@property(nonatomic,retain) UILabel *addressLabel;

//加载指示器
@property(nonatomic,retain) UIActivityIndicatorView *actView;

//定位
@property(nonatomic,retain) BMKLocationService *locationManager;

//位置信息
@property(nonatomic,retain) JBoMapInfo *addrInfo;

//地理反编码
@property(nonatomic,retain) BMKGeoCodeSearch *search;

//正在定位
@property(nonatomic,assign) BOOL locating;

//系统定位工具
@property(nonatomic,retain) CLLocationManager *sysLocationManager;

@end

@implementation JBoLocationSelectView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor whiteColor];
        self.black = YES;
        UIFont *font = [UIFont systemFontOfSize:15.0];
        //位置
        CGFloat buttonWidth = 85.0;
        CGFloat buttonHeight = 30.0;
        UIButton *locButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [locButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [locButton setTitle:@"位置" forState:UIControlStateNormal];
        [locButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        locButton.titleLabel.font = font;
        [locButton setImage:[UIImage imageNamed:@"conditions_map"] forState:UIControlStateNormal];
        [locButton setFrame:CGRectMake(10.0 / 2.0, (_controlHeight_ - buttonHeight) / 2.0, buttonWidth, buttonHeight)];
        [self addSubview:locButton];
        
        //当前位置
        self.curButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_curButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_curButton setTitle:@"当前位置" forState:UIControlStateNormal];
        _curButton.titleLabel.font = font;
        [_curButton setImage:[UIImage imageNamed:@"sceneNormal_gray"] forState:UIControlStateNormal];
        [_curButton setImage:[UIImage imageNamed:@"sceneSelected"] forState:UIControlStateSelected];
        [_curButton setFrame:CGRectMake(locButton.right + 5.0, locButton.top, buttonWidth, buttonHeight)];
        [_curButton addTarget:self action:@selector(currentLocationAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_curButton];
        
        
        //其他位置
        self.otherButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_otherButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_otherButton setTitle:@"其他位置" forState:UIControlStateNormal];
        _otherButton.titleLabel.font = font;
        [_otherButton setImage:[UIImage imageNamed:@"sceneNormal_gray"] forState:UIControlStateNormal];
        [_otherButton setImage:[UIImage imageNamed:@"sceneSelected"] forState:UIControlStateSelected];
        [_otherButton setFrame:CGRectMake(self.width - buttonWidth, locButton.top, buttonWidth, buttonHeight)];
        [_otherButton addTarget:self action:@selector(otherLocationAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_otherButton];
        
        //分割线
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, _controlHeight_ - 0.5, self.width, 0.5)];
        line.backgroundColor = [UIColor colorWithWhite:0.8 alpha:1.0];
        [self addSubview:line];
        [line release];
        
        CGFloat interval = 5.0;
        //位置地址
        self.addressLabel = [[[UILabel alloc] initWithFrame:CGRectMake(interval, line.bottom, self.width - interval * 2, _controlHeight_)] autorelease];
        _addressLabel.textColor = [UIColor grayColor];
        _addressLabel.backgroundColor = [UIColor clearColor];
        _addressLabel.numberOfLines = 0;
        _addressLabel.font = [UIFont systemFontOfSize:14.0];
        [self addSubview:_addressLabel];
        
        self.height = _addressLabel.bottom;
        
        self.search = [BMKGeoCodeSearch sharedInstance];
    }
    return self;
}

- (void)setLocating:(BOOL)locating
{
    if(_locating != locating)
    {
        _locating = locating;
        
        if(_locating)
        {
            if(!self.actView)
            {
                self.actView = [[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray] autorelease];
                _actView.hidesWhenStopped = YES;
                [self addSubview:_actView];
            }
            
            _actView.center = CGPointMake(self.width / 2.0, _addressLabel.top + _addressLabel.height / 2.0);
            _addressLabel.hidden = YES;
            [_actView startAnimating];
        }
        else
        {
            [_actView stopAnimating];
            _addressLabel.hidden = NO;
        }
    }
}

- (void)setUseDefaultAddr:(BOOL)useDefaultAddr
{
    if(_useDefaultAddr != useDefaultAddr)
    {
        _useDefaultAddr = useDefaultAddr;
        if(_useDefaultAddr)
        {
            JBoUserDetailInfo *detailInfo = [JBoUserOperation getUserDetailInfo];
            
            if(![NSString isEmpty:detailInfo.defaultAddr])
            {
                self.addrInfo = [[[JBoMapInfo alloc] init] autorelease];
                self.addrInfo.coordinate = CLLocationCoordinate2DMake(detailInfo.defalutAddrLat, detailInfo.defaultAddrLon);
                [self.addrInfo setAddr:detailInfo.defaultAddr];
                [self viewWillDisappear];
                self.locating = NO;
                _addressLabel.text = detailInfo.defaultAddr;
            }
        }
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    NSLog(@"JBoLocationSelectView dealloc");
    [self viewWillDisappear];
    
    [_sysLocationManager release];
    self.navigationController = nil;
    [_curButton release];
    [_otherButton release];
    [_addressLabel release];
    [_actView release];
    
    [super dealloc];
}

#pragma mark- public method

/**视图消失，必须在视图被dealloc之前调用，否则会造成内存泄露
 * 比如在 viewController viewWillDisappear
 */
- (void)viewWillDisappear
{
    [self.locationManager stopUserLocationService];
    self.search.delegate = nil;
    self.locationManager.delegate = nil;
    self.locating = NO;
}

/**视图出现
 */
- (void)viewWillAppear
{
    self.search.delegate = self;
    self.locationManager.delegate = self;
}

/**获取地址信息
 *@return 没有则返回nil
 */
- (JBoMapInfo*)getAddressInfo
{
    return self.addrInfo;
}

/**设置地址信息
 */
- (void)setAddressInfo:(JBoMapInfo*) info
{
    self.addrInfo = info;
    self.locating = NO;
    [self viewWillDisappear];
    _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.addrInfo];
}

#pragma mark- JBoMapViewController代理

- (void)mapViewController:(JBoMapViewController *)mapView didLocatedWithInfo:(NSDictionary *)userInfo
{
    self.addrInfo = [userInfo objectForKey:_locationInfo_];
    _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.addrInfo];
    
    [self setCurLocation:NO];
}

#pragma mark-位置

- (void)setCurLocation:(BOOL) cur
{
    _curButton.selected = cur;
    _otherButton.selected = !cur;
}
//位置
- (void)currentLocationAction:(UIButton*) button
{
    if(self.locating)
        return;
    [self location];
}

- (void)otherLocationAction:(UIButton*) button
{
    [self viewWillDisappear];
    
    JBoMapViewController *mapVC = [[JBoMapViewController alloc] init];
    mapVC.delegate = self;
    mapVC.isSender = YES;
    mapVC.black = self.black;
    
    if(self.addrInfo)
    {
        mapVC.coordinate = self.addrInfo.coordinate;
        mapVC.detailAddr = self.addrInfo.strAddr;
        mapVC.poiInfo = self.addrInfo.poiAddr;
    }
    
    [self.navigationController pushViewController:mapVC animated:YES];
    [mapVC release];
}

- (void)finishLocation:(BOOL) success
{
    if(success)
    {
        _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.addrInfo];
        [self setCurLocation:YES];
        
        //保存默认位置
//        if([NSString isEmpty:self.info.defaultAddr])
//        {
//            if(_addressLabel.text == nil)
//                return;
//            
//            self.info.defaultAddr = _addressLabel.text;
//            self.info.defalutAddrLat = self.addrInfo.coordinate.latitude;
//            self.info.defaultAddrLon = self.addrInfo.coordinate.longitude;
//            
//            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
//                                 _addressLabel.text, _rosterDefaultAddr_,
//                                 [NSNumber numberWithDouble:self.addrInfo.coordinate.latitude], _rosterDefaultLat_,
//                                 [NSNumber numberWithDouble:self.addrInfo.coordinate.longitude], _rosterDefaultLon_, nil];
//            [[NSNotificationCenter defaultCenter] postNotificationName:_saveDefaultAddrNotification_ object:self userInfo:dic];
//        }
    }
    else
    {
        _addressLabel.text = @"无法确定您当前的位置";
        self.addrInfo = nil;
        
        [JBoUserOperation openSystemSettingsAlertViewWithDelegate:self];
    }
    self.locating = NO;
}

#pragma mark- UIAlertView delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:_alertButtonTitleWhenCannotLocate_])
    {
        [JBoUserOperation openSystemSettings];
    }
}

- (void)layoutAddress
{
    CGSize size = [JBoImageTextTool getStringSize:_addressLabel.text withFont:_addressLabel.font andContraintSize:CGSizeMake(_addressLabel.width, _height_)];
    _addressLabel.height = size.height + 3.0;
}

#pragma mark- BMKGeoSearch delegate

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(error != BMK_SEARCH_NO_ERROR)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        return;
    }
    
    self.addrInfo.strAddr = result.address;
    BMKPoiInfo *info = [result.poiList firstObject];
    self.addrInfo.poiAddr = info.name;

    [self finishLocation:YES];
}

- (void)onGetGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    NSLog(@"onGetGeoCodeResult");
}

#pragma mark-定位
- (void)location
{
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        if([CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined)
        {
            self.sysLocationManager = [[[CLLocationManager alloc] init] autorelease];
            
            [self.sysLocationManager requestAlwaysAuthorization];
        }
#endif
    }
    
    BOOL canloc = NO;
    
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways;
#endif
    }
    else
    {
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized;
    }
    
    if(canloc)
    {
        if(!self.locationManager)
        {
            self.locationManager = [[[BMKLocationService alloc] init] autorelease];
        }
        
        self.locationManager.delegate = self;
        [self.locationManager startUserLocationService];
        self.locating = YES;
    }
    else
    {
        [JBoUserOperation cannotUserLocationService];
        [self finishLocation:NO];
    }
}

#pragma mark- BMKLocationService delegate

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
   // NSLog(@"%f,%f",userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude);
     if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {
        if(!self.addrInfo)
        {
            self.addrInfo = [[[JBoMapInfo alloc] init] autorelease];
        }
        self.addrInfo.coordinate = userLocation.location.coordinate;
        
        self.search.delegate = self;
        
        BMKReverseGeoCodeOption *option = [[[BMKReverseGeoCodeOption alloc] init] autorelease];
        option.reverseGeoPoint = self.addrInfo.coordinate;
        
        if(![self.search reverseGeoCode:option])
        {
            NSLog(@"地理反编码失败");
            [self finishLocation:NO];
        }
        
        [self.locationManager stopUserLocationService];
    }
}

- (void)didFailToLocateUserWithError:(NSError *)error
{
    [self.locationManager stopUserLocationService];
    [self finishLocation:NO];
}

@end
