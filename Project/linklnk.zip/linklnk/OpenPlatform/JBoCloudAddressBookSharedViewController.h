//
//  JBoCloudAddressBookSharedViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@interface JBoCloudAddressBookSharedViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>

/**信息内容 数组元素是JBoCloudAddressBookGroupInfo对象
 */
@property(nonatomic,retain) NSMutableArray *groupInfos;

/**云名片夹链接
 */
@property(nonatomic,copy) NSString *url;

@end
