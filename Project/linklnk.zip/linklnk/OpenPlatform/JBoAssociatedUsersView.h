//
//  JBoAssociatedUsersView.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**关注我的人或我关注的人
 */
@interface JBoAssociatedUsersView : UIView<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>

/**是否正在进行网络请求
 */
@property(nonatomic,assign) BOOL isRequesting;

/**导航栏内容是否为黑色 default is 'YES'
 */
@property(nonatomic,assign) BOOL black;

/**关注的seg
 */
@property(nonatomic,assign) UISegmentedControl *seg;

@property(nonatomic,assign) UINavigationController *navigationController;

/**seg选项改变
 */
- (void)valueDidChanged:(UISegmentedControl*) seg;

/**取消网络请求
 */
- (void)cancelHttpRequest;



@end
