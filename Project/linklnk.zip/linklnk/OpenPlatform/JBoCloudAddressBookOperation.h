//
//  JBoCloudAddressBookOperation.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

#define _addCloudAddressBookGroupIdentifier_ @"addCloudAddressBookGroup"
#define _removeCloudAddressBookGroupIdentifier_ @"removeCloudAddressBookGroup"
#define _updateCloudAddressBookGroupIdentifier_ @"updateCloudAddressBookGroup"
#define _getCloudAddressBookGroupIdentifier_ @"getCloudAddressBookGroup"

#define _addCloudAddressBookProblemIdentifier_ @"addCloudAddressBookGroupProblem"
#define _removeCloudAddressBookProblemIdentifier_ @"removeCloudAddressBookProblem"
#define _updateCloudAddressBookProblemIdentifier_ @"updateCloudAddressBookProblem"
#define _getCloudAddressBookProblemIdentifier_ @"getCloudAddressBookProblem"

#define _addCloudAddressBookContactIdentifier_ @"addCloudAddressBookContact"
#define _removeCloudAddressBookContactIdentifier_ @"removeCloudAddressBookContact"
#define _getCloudAddressBookContactInfoIdentifier_ @"getCloudAddressBookContactInfo"
#define _moveCloudAddressBookContactIentifier_ @"moveCloudAddressBookContact"

@class JBoCloudAddressBookInfo;
@class JBoCloudAddressBookGroupInfo;

/**封装了云通讯录网络操作的方法
 */
@interface JBoCloudAddressBookOperation : NSObject

#pragma mark- 分组

/**添加云通讯录分组 url
 */
+ (NSString*)addCloudAddressBookGroup;

/**添加云通讯录分组 参数
 *@param name 分组名称
 *@return post参数
 */
+ (NSDictionary*)addCloudAddressBookGroupParamWithName:(NSString*) name;

/**获取添加云通讯录分组结果
 *@param 返回数据
 *@param info 新分组信息，将新的填充分组信息
 *@return 返回是否成功
 */
+ (BOOL)addCloudAddressBookGroupResultFromData:(NSData*) data withInfo:(JBoCloudAddressBookGroupInfo*) info;

/**删除云通讯录分组 url
 */
+ (NSString*)removeCloudAddressBookGroup;

/**删除云通讯录分组 参数
 *@param Id 分组Id
 *@return post参数
 */
+ (NSDictionary*)removeCloudAddressBookGroupParamWithId:(long long) Id;

/**更新云通讯录分组 url
 */
+ (NSString*)updateCloudAddressBookGroup;

/**更新云通讯录分组 参数
 *@param Id 分组Id
 *@param name 分组新名称
 *@return post参数
 */
+ (NSDictionary*)updateCloudAddressBookGroupParamWithId:(long long) Id name:(NSString*) name;

/**获取用户的所有云通讯录分组
 *@return get请求url
 */
+ (NSString*)getCloudAddressBookGroup;

/**从返回数据中获取用户的云通讯录分组信息
 *@param data 返回数据
 *@return 数组元素是 JBoCloudAddressBookGroupInfo对象
 */
+ (NSMutableArray*)getCloudAddressBookGroupFromData:(NSData*) data;

#pragma mark- 验证问题

/**添加云通讯录验证问题 url
 */
+ (NSString*)addCloudAddressBookProblem;

/**添加云通讯录验证问题 参数
 *@param problem 问题
 *@param answer 答案
 *@return post 参数
 */
+ (NSDictionary*)addCloudAddressBookProblemParam:(NSString*) problem answer:(NSString*) answer;

/**获取添加云通讯录验证问题结果
 *@param 返回数据
 *@return 成功返回问题Id 否则返回0
 */
+ (long long)addCloudAddressBookProblemResultFromData:(NSData*) data;

/**删除云通讯录验证问题 url
 */
+ (NSString*)removeCloudAddressBookProblem;

/**删除云通讯录验证问题 参数
 *@param Id 问题Id
 *@return post参数
 *@return post参数
 */
+ (NSDictionary*)removeCloudAddressBookProblemParamWithId:(long long) Id;

/**更新云通讯录验证问题 url
 */
+ (NSString*)updateCloudAddressBookProblem;

/**更新云通讯录验证问题 参数
 *@param Id 问题Id
 *@param problem 新问题
 *@param answer 新答案
 *@return post参数
 */
+ (NSDictionary*)updateCloudAddressBookProblemParamWithId:(long long) Id problem:(NSString*) problem answer:(NSString*) answer;

/**获取某个用户的云通讯录验证问题
 *@param userId 验证问题的用户的userid
 *@return get请求url
 */
+ (NSString*)getCloudAddressBookProblemWithUserId:(NSString*) userId;

/**从返回数据中获取用户的云通讯录验证问题信息
 *@param data 返回数据
 *@return 数组元素是 JBoCloundAddressBookProblemInfo对象
 */
+ (NSMutableArray*)getCloudAddressBookProblemFromData:(NSData*) data;

#pragma mark- 云通讯录信息

/**添加云通讯录联系人 url
 */
+ (NSString*)addCloudAddressBookContact;

/**添加云通讯录联系人 参数
 *@param groudId 添加到的分组Id
 *@param userId 新增的用户
 *@return post参数
 */
+ (NSDictionary*)addCloudAddressBookContactParamWithGroupId:(long long) groudId userId:(NSString*) userId;

/**获取添加云通讯录联系人结果
 *@param 返回数据
 *@return key为result  成功 value 为 新联系人的信息，否则value为 失败错误码
 */
+ (NSDictionary*)addCloudAddressBookContactResultFromData:(NSData*) data;

/**删除云通讯录联系人 url
 */
+ (NSString*)removeCloudAddressBookContact;

/**删除云通讯录联系人 参数
 *@param Id 联系人的Id
 *@param groupId 分组Id
 *@return post参数
 */
+ (NSDictionary*)removeCloudAddressBookContactParamWithId:(long long) Id groupId:(long long) groupId;

/**获取用户的云通讯录联系人信息
 *@return get请求url
 */
+ (NSString*)getCloudAddressBookContactInfo;

/**从返回数据中获取用户的云通讯录联系人信息
 *@param data 返回的数据
 *@param groupInfos 空的数组，将填充 JBoCloudAddressBookGroupInfo对象
 *@return 云通讯录链接
 */
+ (NSString*)getCloudAddressBookContactInfoFromData:(NSData*) data withArray:(NSMutableArray*) groupInfos;

/**移动云通讯录联系人到某一分组 url
 */
+ (NSString*)moveCloudAddressBookContact;

/**移动云通讯录联系人到某一分组 参数
 *@param Id 联系人Id
 *@param groupId 分组Id
 *@param groupName 新的分组名称 ，可以为空
 *@return post参数
 */
+ (NSDictionary*)moveCloudAddressBookContactParamWithId:(long long) Id groupId:(long long) groupId groupName:(NSString*) groupName;

/**获取移动云通讯录联系人到某一分组结果
 *@param 返回数据
 *@return 成功返回分组Id(当是添加到新分组时） 或0 否则返回-1
 */
+ (long long)moveCloudAddressBookContactProblemResultFromData:(NSData*) data;

@end
