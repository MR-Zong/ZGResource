//
//  JBoAssociatedUsersView.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAssociatedUsersView.h"

#import "JBoAppDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "ChineseToPinyin.h"
#import "JBoRosterInfo.h"
#import "JBoRosterCell.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoImageCacheTool.h"
#import "JBoImageTextTool.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoBottomLoadingView.h"
#import "JBoUserDetailInfo.h"
#import "JBoAttentionOperation.h"

#define _attentionSegIndex_ 1
#define _fansSegIndex_ 2

//搜索栏高度
#define _searchBarHeight_ 40

@interface JBoAssociatedUsersView ()<EGORefreshTableHeaderDelegate,JBoHttpRequestDelegate>

{
    UITableView *_tableView;
    //搜索栏
    UISearchBar *_searchBar;
    //搜索栏搜索结果
    NSMutableArray *_searchResultArray;
    
    BOOL _isLoading; //数据是否加载中
    
    //黑色半透明视图
    UIView *_transparentView;
    //加载数据进程
    NSMutableDictionary *_downloadProgressDic;
    
    //下拉刷新
    EGORefreshTableHeaderView *_refreshView;
    
    NSMutableDictionary *_httpRequestDic;
    
    JBoBottomLoadingView *_bottomLoadingView;
}

//正在搜索
@property(nonatomic,assign) BOOL searching;

//关注
@property(nonatomic,retain) ASINetworkQueue *httpQueue;

//我关注的人
@property(nonatomic,retain) NSMutableArray *attentions;
@property(nonatomic,assign) BOOL attentionsRequest;
@property(nonatomic,assign) BOOL attentionsHasInfo;
@property(nonatomic,assign) NSInteger attentionCount;
@property(nonatomic,assign) int attentionsPageIndex;

//关注我的人
@property(nonatomic,retain) NSMutableArray *fansArray;
@property(nonatomic,assign) BOOL fansHasInfo;
@property(nonatomic,assign) BOOL fansRequest;
@property(nonatomic,assign) int fansPageIndex;
@property(nonatomic,assign) NSInteger fansCount;

@property(nonatomic,assign) JBoAppDelegate *appDelegate;

@end

@implementation JBoAssociatedUsersView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.black = YES;
        _downloadProgressDic = [[NSMutableDictionary alloc] init];
        
        _httpRequestDic = [[NSMutableDictionary alloc] init];
        self.searching = NO;
        
        self.attentionsHasInfo = YES;
        self.fansHasInfo = YES;
        self.attentionsPageIndex = 1;
        self.fansPageIndex = 1;
        
        self.attentions = [[[NSMutableArray alloc] init] autorelease];
        self.fansArray = [[[NSMutableArray alloc] init] autorelease];
        
        //关注
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addAttention:) name:_addAttentionNotification_ object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelAttention:) name:_cancelAttentionNotification_ object:nil];
        
        self.appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        [self loadInitView];
    }
    return self;
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    _tableView.frame = self.bounds;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark -通知

- (void)addAttention:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoUserDetailInfo *info = [dic objectForKey:_attentionUserInfo_];
    [self.attentions insertObject:info atIndex:0];
    
    if(self.attentionCount != NSNotFound)
    {
        self.attentionCount ++;
        [self setAttentionsCount];
    }
    if(self.seg.selectedSegmentIndex == _attentionSegIndex_)
    {
        [_tableView reloadData];
        [_tableView setExtraCellLineHidden];
    }
}

- (void)cancelAttention:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoUserDetailInfo *info = [dic objectForKey:_attentionUserInfo_];
    [self.attentions removeObject:info];
    
    if(self.attentionCount != NSNotFound)
    {
        self.attentionCount --;
        [self setAttentionsCount];
    }
    if(self.seg.selectedSegmentIndex == _attentionSegIndex_)
    {
        [_tableView reloadData];
        [_tableView setExtraCellLineHidden];
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoCloudUsersViewController dealloc");
    
    self.seg = nil;
    self.appDelegate = nil;
    
    [_tableView release];
    [_searchBar release];
    
    [_searchResultArray release];
    [_transparentView release];
    
    [_downloadProgressDic release];
    [_refreshView release];

    [_httpRequestDic release];
    [_bottomLoadingView release];
    
    [_httpQueue reset];
    [_httpQueue release];
    
    [_attentions release];
    [_fansArray release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_addAttentionNotification_ object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_cancelAttentionNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark- public method

- (void)valueDidChanged:(UISegmentedControl*) seg
{
    switch (seg.selectedSegmentIndex)
    {
        case _attentionSegIndex_ :
        {
            if(_isLoading)
            {
                [self  tableViewDataSourceDidFinishLoading];
                [_httpRequestDic removeObjectForKey:_getFansIdentifier_];
                [_httpRequestDic removeObjectForKey:_getRosterIdentifier_];
                self.attentionsRequest = NO;
            }
            [self.appDelegate closeAlertView];
            if(self.attentions.count == 0 && self.attentionsHasInfo)
            {
                [_tableView reloadData];
                [_refreshView beginRefresh];
            }
            else
            {
                if(self.attentions.count == 0)
                {
                    [JBoUserOperation alertMsg:@"你没有关注别人"];
                }
                [_tableView reloadData];
            }
            [self getAttentionsCount];
            [self setAttentionsCount];
            [_tableView setExtraCellLineHidden];
        }
            break;
        case _fansSegIndex_ :
        {
            if(_isLoading)
            {
                [self  tableViewDataSourceDidFinishLoading];
                [_httpRequestDic removeObjectForKey:_getAttentionsIdentifier_];
                [_httpRequestDic removeObjectForKey:_getRosterIdentifier_];
                self.fansRequest = NO;
            }
            [self.appDelegate closeAlertView];
            
            if(self.fansArray.count == 0 && self.fansHasInfo)
            {
                [_tableView reloadData];
                [_refreshView beginRefresh];
            }
            else
            {
                if(self.fansArray.count == 0)
                {
                    [JBoUserOperation alertMsg:@"暂时没有人关注你"];
                }
                [_tableView reloadData];
            }
            [self getFansCount];
            [self setFanCount];
            [_tableView setExtraCellLineHidden];
        }
            break;
        default:
            break;
    }
}

/**取消网络请求
 */
- (void)cancelHttpRequest
{
    [_httpQueue reset];
    [self tableViewDataSourceDidFinishLoading];
    self.isRequesting = NO;
}


#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_getAttentionsIdentifier_])
    {
        self.appDelegate.dataLoadingView.hidden = YES;
        self.attentionsRequest = NO;
        if(self.seg.selectedSegmentIndex == _attentionSegIndex_)
        {
            if(!_isLoading)
            {
                [JBoUserOperation alertmsgWithBadNetwork:@"请重试"];
            }
            else
            {
                _refreshView.finishText = [NSString stringWithFormat:@"%@请重试",_alertMsgWhenBadNetwork_];
                [self tableViewDataSourceDidFinishLoading];
            }
        }
        
        [_httpRequestDic removeObjectForKey:_getAttentionsIdentifier_];
        [_tableView setExtraCellLineHidden];
        return;
    }
    
    if([identifier isEqualToString:_getFansIdentifier_])
    {
        self.appDelegate.dataLoadingView.hidden = YES;
        self.fansRequest = NO;
        if(self.seg.selectedSegmentIndex == _fansSegIndex_)
        {
            if(!_isLoading)
            {
                [JBoUserOperation alertmsgWithBadNetwork:@"请重试"];
            }
            else
            {
                _refreshView.finishText = [NSString stringWithFormat:@"%@请重试",_alertMsgWhenBadNetwork_];
                [self tableViewDataSourceDidFinishLoading];
            }
        }
        [_httpRequestDic removeObjectForKey:_getFansIdentifier_];
        [_tableView setExtraCellLineHidden];
        return;
    }
    
    if([identifier isEqualToString:_cancelAttentionIdentifier_])
    {
        self.appDelegate.dataLoadingView.hidden = YES;
        [_httpRequestDic removeObjectForKey:_cancelAttentionIdentifier_];
        return;
    }
    
    
    if([identifier isEqualToString:_getAttentionCountIdentifier_])
    {
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        [_httpRequestDic removeObjectForKey:_getAttentionCountIdentifier_];
        return;
    }
    
    if([identifier isEqualToString:_getFansCountIdentifier_])
    {
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        [_httpRequestDic removeObjectForKey:_getFansCountIdentifier_];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    
    if([identifier isEqualToString:_getAttentionsIdentifier_])
    {
        if(_isLoading)
        {
            self.attentionsPageIndex = 1;
        }
        
        self.appDelegate.dataLoadingView.hidden = YES;
        self.attentionsRequest = NO;
        self.attentionsPageIndex ++;
        NSMutableArray *array = [JBoAttentionOperation getAttentionsFromData:data];
        self.attentionsHasInfo = array.count == _attentionPageSize_;
        
        if(self.seg.selectedSegmentIndex == _attentionSegIndex_ && _isLoading)
        {
            self.attentions = array;
            _refreshView.finishText = @"刷新成功";
            
            [self tableViewDataSourceDidFinishLoading];
        }
        else
        {
            [self.attentions addObjectsFromArray:array];
        }
        
        if(self.seg.selectedSegmentIndex == _attentionSegIndex_)
        {
            if(self.attentions.count == 0)
            {
                [JBoUserOperation alertMsg:@"你没有关注别人"];
            }
            [_tableView reloadData];
        }
        
        [_httpRequestDic removeObjectForKey:_getAttentionsIdentifier_];
        [self setAttentionsCount];
        [_tableView setExtraCellLineHidden];
        return;
    }
    
    if([identifier isEqualToString:_getFansIdentifier_])
    {
        if(_isLoading)
        {
            self.fansPageIndex = 1;
        }
        
        self.fansRequest = NO;
        self.appDelegate.dataLoadingView.hidden = YES;
        self.fansPageIndex ++;
        NSMutableArray *array = [JBoAttentionOperation getFansFromData:data];
        self.fansHasInfo = array.count == _attentionPageSize_;
        
        if(self.seg.selectedSegmentIndex == _fansSegIndex_ && _isLoading)
        {
            self.fansArray = array;
            _refreshView.finishText = @"刷新成功";
            [self tableViewDataSourceDidFinishLoading];
        }
        else
        {
            [self.fansArray addObjectsFromArray:array];
        }
        
        if(self.seg.selectedSegmentIndex == _fansSegIndex_)
        {
            if(self.fansArray.count == 0)
            {
                [JBoUserOperation alertMsg:@"暂时没有人关注你"];
            }
            [_tableView reloadData];
        }
        
        [_httpRequestDic removeObjectForKey:_getFansIdentifier_];
        
        [self setFanCount];
        [_tableView setExtraCellLineHidden];
        return;
    }
    
    if([identifier isEqualToString:_cancelAttentionIdentifier_])
    {
        self.appDelegate.dataLoadingView.hidden = YES;
        [_httpRequestDic removeObjectForKey:_cancelAttentionIdentifier_];
        return;
    }
    
    if([identifier isEqualToString:_getAttentionCountIdentifier_])
    {
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        self.attentionCount = [JBoAttentionOperation attentionCountFromData:data];
        [self setAttentionsCount];
        [_httpRequestDic removeObjectForKey:_getAttentionCountIdentifier_];
        return;
    }
    
    if([identifier isEqualToString:_getFansCountIdentifier_])
    {
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        self.fansCount = [JBoAttentionOperation fansCountFromData:data];
        [self setFanCount];
        [_httpRequestDic removeObjectForKey:_getFansCountIdentifier_];
        return;
    }
}

//设置 queue
- (ASINetworkQueue*)queue
{
    if(!self.httpQueue)
    {
        self.httpQueue = [ASINetworkQueue queue];
        self.httpQueue.shouldCancelAllRequestsOnFailure = NO;
        [self.httpQueue setDelegate:self];
        [self.httpQueue setQueueDidFinishSelector:@selector(httpQuqueDidFinish:)];
        [self.httpQueue setDelegate:self];
    }
    return self.httpQueue;
}

- (void)httpQuqueDidFinish:(ASINetworkQueue*) queue
{
    [self.httpQueue reset];
    self.httpQueue = nil;
}

//取消关注
- (void)cancelAttentionWithUserId:(NSString*) userId
{
    JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_cancelAttentionIdentifier_];
    httpRequest.startImmediately = NO;
    [httpRequest downloadWithURL:[JBoAttentionOperation cancelAttentionUser:userId]];
    [httpRequest addToQueue:[self queue]];
    [[self queue] go];
    [_httpRequestDic setObject:httpRequest forKey:_cancelAttentionIdentifier_];
    [httpRequest release];
}

//获取关注的人
- (BOOL)loadAttentions
{
    if(self.attentionsRequest)
        return NO;
    
    JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getAttentionsIdentifier_];
    httpRequest.startImmediately = NO;
    if(![httpRequest downloadWithURL:[JBoAttentionOperation getAttentionsWithPageNum:self.attentionsPageIndex row:_attentionPageSize_]])
    {
        return NO;
    }
    
    [_downloadProgressDic setObject:httpRequest forKey:_getAttentionsIdentifier_];
    [httpRequest addToQueue:[self queue]];
    [[self queue] go];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [httpRequest release];
    self.attentionsRequest = YES;
    return YES;
}

//获取关注的人的数量
- (void)getAttentionsCount
{
    if(![_downloadProgressDic objectForKey:_getAttentionCountIdentifier_])
    {
        JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getAttentionCountIdentifier_];
        httpRequest.startImmediately = NO;
        [httpRequest downloadWithURL:[JBoAttentionOperation getAttentionCount]];
        
        [_downloadProgressDic setObject:httpRequest forKey:_getAttentionCountIdentifier_];
        [httpRequest addToQueue:[self queue]];
        [[self queue] go];
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
        [httpRequest release];
    }
}

//获取关注我的人
- (BOOL)loadFans
{
    if(self.fansRequest)
        return NO;
    
    JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getFansIdentifier_];
    httpRequest.startImmediately = NO;
    if(![httpRequest downloadWithURL:[JBoAttentionOperation getFansWithUserId:[JBoUserOperation getUserId] pageNum:self.fansPageIndex row:_attentionPageSize_]])
    {
        return NO;
    }
    
    [_downloadProgressDic setObject:httpRequest forKey:_getFansIdentifier_];
    [httpRequest addToQueue:[self queue]];
    [[self queue] go];
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    [httpRequest release];
    self.fansRequest = YES;
    return YES;
}

//获取关注我的人的数量
- (void)getFansCount
{
    if(![_downloadProgressDic objectForKey:_getFansCountIdentifier_])
    {
        JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getFansCountIdentifier_];
        httpRequest.startImmediately = NO;
        [httpRequest downloadWithURL:[JBoAttentionOperation getFansCount]];
        
        [_downloadProgressDic setObject:httpRequest forKey:_getFansCountIdentifier_];
        [httpRequest addToQueue:[self queue]];
        [[self queue] go];
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
        [httpRequest release];
    }
}

#pragma mark-加载视图

//加载视图
- (void)loadInitView
{
    //创建导航条右边的按钮
    
    self.backgroundColor = [UIColor whiteColor];
   
    //创建tableview
    _tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorColor = [UIColor colorWithRed:160.0 / 255.0 green:160.0 / 255.0 blue:160.0 / 255.0 alpha:1.0];
    _tableView.rowHeight = _rosterCellHeight_;
    [self addSubview:_tableView];
    [_tableView setExtraCellLineHidden];
    
    _refreshView = [[EGORefreshTableHeaderView alloc] initWithFrame:_tableView.frame];
    _refreshView.delegate = self;
    _refreshView.scrollView = _tableView;
    _refreshView.hidden = YES;
    [self insertSubview:_refreshView belowSubview:_tableView];
    
    //创建搜索栏背
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
    if(!_ios7_0_)
    {
        _searchBar.tintColor = _searchBarColor_;
    }
    
    _searchBar.placeholder = @"搜索";
    _searchBar.delegate = self;
    _tableView.tableHeaderView = _searchBar;
}

- (void)setAttentionsCount
{
    if(self.seg.selectedSegmentIndex == _attentionSegIndex_)
    {
        NSInteger count = (self.attentionCount == NSNotFound || self.attentionCount < 0) ? 0 : self.attentionCount;
        _searchBar.placeholder = [NSString stringWithFormat:@"搜索 (共%d人)", (int)count];
    }
}

- (void)setFanCount
{
    if(self.seg.selectedSegmentIndex == _fansSegIndex_)
    {
        NSInteger count = (self.fansCount == NSNotFound || self.fansCount < 0) ? 0 : self.fansCount;
        _searchBar.placeholder = [NSString stringWithFormat:@"搜索 (共%d人)", (int)count];
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    [_refreshView removeFromSuperview];
    if(!_transparentView)
    {
        _searchResultArray = [[NSMutableArray alloc] init];
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;
        
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [_searchBar setShowsCancelButton:YES animated:YES];
    
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
    [self insertSubview:_refreshView belowSubview:_tableView];
    [_tableView setExtraCellLineHidden];
}


//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        
        switch (self.seg.selectedSegmentIndex)
        {
            case _attentionSegIndex_ :
            {
                [_searchResultArray removeAllObjects];
                for(JBoUserDetailInfo *info in self.attentions)
                {
                    if([self pinyin:pinyin match:info.rosterInfo.name])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
                
                for(JBoUserDetailInfo *info in self.attentions)
                {
                    if([self chinese:content match:info.rosterInfo.name] && ![_searchResultArray containsObject:info])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
            }
                break;
            case _fansSegIndex_ :
            {
                [_searchResultArray removeAllObjects];
                for(JBoUserDetailInfo *info in self.fansArray)
                {
                    if([self pinyin:pinyin match:info.rosterInfo.name])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
                
                for(JBoUserDetailInfo *info in self.fansArray)
                {
                    if([self chinese:content match:info.rosterInfo.name] && ![_searchResultArray containsObject:info])
                    {
                        [_searchResultArray addObject:info];
                    }
                }
            }
                break;
            default:
                break;
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
        [_tableView reloadData];
        [_tableView setExtraCellLineHidden];
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

- (BOOL)pinyin:(NSString*) pinyin match:(NSString*) str
{
    NSString *name = [ChineseToPinyin pinyinFromChiniseString:str];
    if(name.length < pinyin.length)
    {
        return NO;
    }
    
    NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
    if([pinyin isEqualToString:subStr])
    {
        return YES;
    }
    return NO;
}

- (BOOL)chinese:(NSString*) chinese match:(NSString*) str
{
    NSRange range = [str rangeOfString:chinese];
    if(range.length > 0 && range.location != NSNotFound)
    {
        return YES;
    }
    return NO;
}

#pragma mark-tableview代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return _searchResultArray.count;
    }
    else
    {
        NSInteger count = 0;
        switch (self.seg.selectedSegmentIndex)
        {
            case _attentionSegIndex_ :
            {
                count = self.attentions.count;
            }
                break;
            case _fansSegIndex_ :
            {
                count = self.fansArray.count;
            }
                break;
            default:
                break;
        }
        
        return count;
    }
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    
    JBoRosterCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoRosterCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        //  NSLog(@"cell 创建");
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoRosterInfo *rosterInfo = [self getInfoFromIndexPath:indexPath];
    
    cell.nameLabel.text = rosterInfo.name;
    cell.headImageView.role = rosterInfo.role;
    
    if(rosterInfo.remark.length > 0)
    {
        cell.nameLabel.text = rosterInfo.remark;
    }
    [cell setPresence:rosterInfo.presence];
    cell.nameLabel.sex = rosterInfo.sex;
    
    cell.headImageView.sex = rosterInfo.sex;
    cell.headImageView.headImageURL = rosterInfo.imageURL;

    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //进入好友详细信息视图
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (self.seg.selectedSegmentIndex)
    {
        case _attentionSegIndex_ :
        {
            JBoUserDetailInfo *info = nil;
            if(self.searching)
            {
                info = [_searchResultArray objectAtIndex:indexPath.row];
            }
            else
            {
                info = [self.attentions objectAtIndex:indexPath.row];
            }
            
            JBoPublickUserInfoViewController *publicVC = [[JBoPublickUserInfoViewController alloc] init];
            publicVC.userDetailInfo = info;
            publicVC.black = self.black;
            publicVC.sendMsgType = JBoSendMsgTypeFans;
            [self.navigationController pushViewController:publicVC animated:YES];
            [publicVC release];
        }
            break;
        case _fansSegIndex_ :
        {
            JBoUserDetailInfo *info = nil;
            if(self.searching)
            {
                info = [_searchResultArray objectAtIndex:indexPath.row];
            }
            else
            {
                info = [self.fansArray objectAtIndex:indexPath.row];
            }
            
            JBoPublickUserInfoViewController *publicVC = [[JBoPublickUserInfoViewController alloc] init];
            publicVC.userDetailInfo = info;
            publicVC.black = self.black;
            [self.navigationController pushViewController:publicVC animated:YES];
            [publicVC release];
        }
            break;
        default:
            break;
    }
    
    [_searchBar resignFirstResponder];
}

#pragma mark-加载头像

- (JBoRosterInfo*)getInfoFromIndexPath:(NSIndexPath*) indexPath
{
    JBoRosterInfo *rosterInfo = nil;
    if(self.searching)
    {
        rosterInfo = [[_searchResultArray objectAtIndex:indexPath.row] rosterInfo];
    }
    else
    {
        switch (self.seg.selectedSegmentIndex)
        {
            case _attentionSegIndex_ :
            {
                JBoUserDetailInfo *info = [self.attentions objectAtIndex:indexPath.row];
                rosterInfo = info.rosterInfo;
            }
                
                break;
            case _fansSegIndex_ :
            {
                JBoUserDetailInfo *info = [self.fansArray objectAtIndex:indexPath.row];
                rosterInfo = info.rosterInfo;
            }
                break;
            default:
                break;
        }
    }
    return rosterInfo;
}

#pragma mark- scrollView代理

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewWillBeginScroll:scrollView];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(!self.searching)
    {
        [_refreshView egoRefreshScrollViewDidScroll:scrollView];
        _refreshView.hidden = scrollView.contentOffset.y >= 0;
        
    }
    
    if(!_isLoading)
    {
        if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
        {
            if(!_bottomLoadingView)
            {
                //创建加载更多视图
                _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, _bottomLoadingViewHeight_)];
            }
            
            switch (self.seg.selectedSegmentIndex)
            {
                case _attentionSegIndex_ :
                {
                    if(self.attentionsHasInfo)
                    {
                        [self loadAttentions];
                    }
                    
                }
                    break;
                case _fansSegIndex_ :
                {
                    if(self.attentionsHasInfo)
                    {
                        [self loadFans];
                    }
                }
                    break;
                default:
                    break;
            }
        }
    }
}


#pragma mark-下拉刷新

// 加载数据
- (void)reloadTableViewDataSource
{
    _isLoading = YES;
    
    switch (self.seg.selectedSegmentIndex)
    {
        case _attentionSegIndex_ :
        {
            JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getAttentionsIdentifier_];
            httpRequest.startImmediately = NO;
            httpRequest.timeOut = 25.0;
            [httpRequest downloadWithURL:[JBoAttentionOperation getAttentionsWithPageNum:1 row:_attentionPageSize_]];

            [_httpRequestDic setObject:httpRequest forKey:_getAttentionsIdentifier_];
            [httpRequest addToQueue:[self queue]];
            [[self queue] go];
            
            [httpRequest release];
        }
            break;
        case _fansSegIndex_ :
        {
            JBoHttpRequest *httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self identifier:_getFansIdentifier_];
            httpRequest.startImmediately = NO;
            httpRequest.timeOut = 25.0;
            [httpRequest downloadWithURL:[JBoAttentionOperation getFansWithUserId:[JBoUserOperation getUserId] pageNum:1 row:_attentionPageSize_]];

            [_httpRequestDic setObject:httpRequest forKey:_getFansIdentifier_];
            [httpRequest addToQueue:[self queue]];
            [[self queue] go];
            [httpRequest release];
        }
            break;
        default:
            break;
    }
    
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading
{
    _isLoading = NO;
    [_tableView reloadData];
    [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:_tableView];
    [_tableView setExtraCellLineHidden];
}

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

@end
