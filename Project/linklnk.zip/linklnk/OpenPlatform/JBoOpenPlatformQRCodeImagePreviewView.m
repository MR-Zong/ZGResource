//
//  JBoOpenPlatformQRCodeImagePreviewView.m
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformQRCodeImagePreviewView.h"
#import "JBoAppDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoUserOperation.h"

@interface JBoOpenPlatformQRCodeImagePreviewView ()

//二维码图片
@property(nonatomic,retain) UIImage *image;

@property(nonatomic,retain) UIImageView *imageView;

//正在保存
@property(nonatomic,assign) BOOL saving;

@end

@implementation JBoOpenPlatformQRCodeImagePreviewView

/**构造方法
 *@param frame 视图大小
 *@param image 二维码图片
 *@return 一个 初始化的 JBoOpenPlatformQRCodeImagePreviewView 对象
 */
- (id)initWithFrame:(CGRect)frame image:(UIImage *)image
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.image = image;
        
        CGFloat padding = 10.0;
        CGFloat width = frame.size.width - padding * 2;
        CGFloat height = image.size.height * (width / image.size.width);
        
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        
        CGFloat buttonWidth = frame.size.width - padding * 2;
        CGFloat buttonHeight = 40.0;
        
        //取消按钮
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(padding, frame.size.height - buttonHeight -padding, buttonWidth, buttonHeight)];
        [button setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.9]];
        [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [button setTitle:@"取消" forState:UIControlStateNormal];
        button.layer.cornerRadius = 5.0;
        button.layer.masksToBounds = YES;
        [button addTarget:self action:@selector(cancel:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
  
        //保存按钮
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(padding, frame.size.height - buttonHeight * 2 - padding * 2, buttonWidth, buttonHeight)];
        [button setBackgroundColor:[UIColor colorWithWhite:1.0 alpha:0.9]];
        [button setTitleColor:[UIColor colorWithRed:0 green:0 blue:125.0 alpha:0.8] forState:UIControlStateNormal];
        [button setTitle:@"保存到相册" forState:UIControlStateNormal];
        button.layer.cornerRadius = 5.0;
        button.layer.masksToBounds = YES;
        [button addTarget:self action:@selector(save:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(padding, (button.top - height) / 2.0, width, height)];
        imageView.image = image;
        imageView.opaque = NO;
        self.imageView = imageView;
        [imageView release];
    }
    
    return self;
}

- (void)setSaving:(BOOL)saving
{
    if(_saving != saving)
    {
        _saving = saving;
        JBoAppDelegate *appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        appDelegate.dataLoadingView.hidden = !_saving;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_image release];
    [_imageView release];
    
    [super dealloc];
}

#pragma mark- public Method

- (void)showInView:(UIView *)view
{
    self.top = view.height;
    self.backgroundColor = [UIColor clearColor];
    [view addSubview:self];
    
    [UIView animateWithDuration:0.25 animations:^(void){
        self.top = 0;
        
    }completion:^(BOOL finish){
        
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
       
        [self addSubview:self.imageView];
    }];
}

#pragma mark- private method

- (void)dismiss
{
    [UIView animateWithDuration:0.25 animations:^(void){
        self.top = self.superview.height;
    }completion:^(BOOL finish){
        [self removeFromSuperview];
    }];
}

- (void)cancel:(id) sender
{
    if(self.saving)
        return;
    [self dismiss];
}

- (void)save:(id) sender
{
    if(self.saving)
        return;
    self.saving = YES;
    UIImageWriteToSavedPhotosAlbum(self.image, self, @selector(image:didFinishedSaveWithError:contextInfo:), nil);
}

//保存到相册结果
- (void)image:(UIImage*) image didFinishedSaveWithError:(NSError*) error contextInfo:(void*) contextInfo
{
    self.saving = NO;
    
    if(!error)
    {
        [JBoUserOperation alertMsg:@"已保存到相册"];
    }
    else
    {
        [JBoUserOperation alertMsg:@"保存到相册失败"];
    }
}

@end
