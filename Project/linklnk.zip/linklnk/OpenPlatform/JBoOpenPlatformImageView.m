//
//  JBoOpenPlatformImageView.m
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformImageView.h"
#import "JBoOpenPlatformInfo.h"

//每一块图片的数量
#define _numberOfPhotosAtSection_ 9

#define _startTag_ 2000

@interface JBoOpenPlatformImageView ()<JBoMultiImageViewDelegate>

//当前有多少块图片集合
@property(nonatomic,assign) int numberOfSection;

@end

@implementation JBoOpenPlatformImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.numberOfSection = 0;
        self.enableLongPressGesture = YES;
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_info release];
    
    [super dealloc];
}

- (void)setInfo:(JBoOpenPlatformInfo *)info
{
    [_info release];
    _info = [info retain];
    [self reloadData];
}

- (void)reloadImageAtIndex:(NSInteger)index withURL:(NSString *)URL
{
    NSInteger section = index / _numberOfPhotosAtSection_;
    NSInteger indexs = index % _numberOfPhotosAtSection_;
    
    JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:_startTag_ + section];
    [multiImageView reloadCellAtIndex:indexs withURL:URL];
}

/**设置logo
 */
- (void)setupLogoStyle:(JBoMultiImageViewCellLogoStyle)logoStyle atIndex:(NSInteger)index
{
    NSInteger section = index / _numberOfPhotosAtSection_;
    NSInteger indexs = index % _numberOfPhotosAtSection_;
    
    JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:_startTag_ + section];
    [multiImageView setupCellLogoStyle:logoStyle atIndex:indexs];
}

#pragma mark- public

//重新加载数据
- (void)reloadData
{
    if(self.info.imageInfos.count == 0)
    {
        for(UIView *view in self.subviews)
        {
            if(![view isEqual:self.addImageButton])
            {
                [view removeFromSuperview];
            }
        }
        
        if(self.info.expand)
        {
            if(!self.addImageButton)
            {
                UIImage *image = [UIImage imageNamed:@"imageAdded"];
                _addImageButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [_addImageButton addTarget:self action:@selector(addImage:) forControlEvents:UIControlEventTouchUpInside];
                [_addImageButton setShowsTouchWhenHighlighted:YES];
                [_addImageButton setImage:image forState:UIControlStateNormal];
                [_addImageButton setFrame:CGRectMake(0, 0, _openPlatformAddImageButtonHeight_, _openPlatformAddImageButtonHeight_)];
                [self addSubview:_addImageButton];
                
            }
            
            self.addImageButton.hidden = NO;
            self.height = _addImageButton.height;
        }
        else
        {
            self.addImageButton.hidden = YES;
            self.height = 0;
        }
        self.numberOfSection = 0;
        
        return;
    }
    
    self.addImageButton.hidden = YES;
    
    
    //共有几大块图片
    int numberOfSection = 1;
    if(self.info.expand)
    {
        numberOfSection = (int)(self.info.imageInfos.count - 1) / _numberOfPhotosAtSection_ + 1;
    }
    
    BOOL onlyThumbnail = YES;
    
    CGFloat totalHeight = 0;
    
    for(int i = 0;i < numberOfSection;i ++)
    {
        //重用已存在的 multiImageView
        JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:i + _startTag_];
        multiImageView.showIndex = YES;
        multiImageView.beginIndex = MAX(_numberOfPhotosAtSection_ * i + 1, 1);
        
        if(multiImageView)
        {
            multiImageView.onlythumbnail = onlyThumbnail;
            
            NSArray *array = [self imageURLArrayForSection:i];
            
            CGFloat height = onlyThumbnail ? [JBoMultiImageView getThumbnailHeightWithCount:array.count] : [JBoMultiImageView getHeightWithCount:array.count];
            
            multiImageView.frame = CGRectMake(0, totalHeight, self.width, height);
            multiImageView.images = array;
            
            totalHeight += height + _PlatformImageSectionInterval_;
        }
    }
    
    if(self.numberOfSection > numberOfSection)
    {
        //移出多余的 multiImageView
        for(NSInteger i = numberOfSection;i < self.numberOfSection;i ++)
        {
            JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:i + _startTag_];
            [multiImageView removeFromSuperview];
        }
    }
    else
    {
        for(int i = self.numberOfSection;i < numberOfSection;i ++)
        {
            //添加 multiImageView
            NSArray *array = [self imageURLArrayForSection:i];
            
            CGFloat height = onlyThumbnail ? [JBoMultiImageView getThumbnailHeightWithCount:array.count] : [JBoMultiImageView getHeightWithCount:array.count];
            
            JBoMultiImageView *multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectMake(0, totalHeight, self.width, height)];
            multiImageView.showIndex = YES;
            multiImageView.beginIndex = MAX(_numberOfPhotosAtSection_ * i + 1, 1);
            multiImageView.clipsToBounds = YES;
            multiImageView.delegate = self;
            multiImageView.row = i;
            multiImageView.enableLongPressGesture = self.enableLongPressGesture;
            multiImageView.tag = _startTag_ + i;
            multiImageView.images = array;
            multiImageView.onlythumbnail = onlyThumbnail;
            [self addSubview:multiImageView];
            [multiImageView release];
            
            totalHeight += height + _PlatformImageSectionInterval_;
        }
    }
    
    totalHeight -= _PlatformImageSectionInterval_;
    self.numberOfSection = numberOfSection;
    
    self.height = totalHeight;
}

//通过图片集合的行数 获取图片路径
- (NSArray*)imageURLArrayForSection:(NSInteger) section
{
    NSArray *imageinfos = nil;
    if(!self.info.expand)
    {
        NSInteger len = MIN(_openPlatformShowImageCountWhenClose_, self.info.imageInfos.count);

        imageinfos = [self.info.imageInfos objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, len)]];
    }
    else
    {
        NSInteger loc = section * _numberOfPhotosAtSection_;
        NSInteger length = loc + _numberOfPhotosAtSection_ < self.info.imageInfos.count ? _numberOfPhotosAtSection_ : self.info.imageInfos.count - loc;
        
        if(loc + length <= self.info.imageInfos.count)
        {
            imageinfos = [self.info.imageInfos objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(loc, length)]];
        }
    }
    
    if(imageinfos)
    {
        return [JBoOpenPlatformImageInfo getThumbnailURLsFromImageInfos:imageinfos];
    }
    return nil;
}

/**添加图片
 */
- (void)addImage:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformImageViewDidAddImage:)])
    {
        [self.delegate openPlatformImageViewDidAddImage:self];
    }
}

#pragma mark- multiImageView 代理

- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(openPlatformImageView:didSelectedImageAtIndex:)])
    {
        NSInteger idex = multiImageView.row * _numberOfPhotosAtSection_ + index;
        [self.delegate openPlatformImageView:self didSelectedImageAtIndex:idex];
    }
}

- (void)multiImageView:(JBoMultiImageView *)multiImageView didLongPressedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(openPlatformImageView:didLongPressedImageAtIndex:)])
    {
        NSInteger idex = multiImageView.row * _numberOfPhotosAtSection_ + index;
        [self.delegate openPlatformImageView:self didLongPressedImageAtIndex:idex];
    }
}

#pragma mark- class method

/**根据图片数量获取高度
 */
+ (CGFloat)heightForImageCount:(NSInteger)count
{
    NSInteger numberOfSection = count / _numberOfPhotosAtSection_;
    NSInteger remainder = count % _numberOfPhotosAtSection_;
    
    BOOL onlyThumbnail = YES;
    
    CGFloat height = 0;
    if(numberOfSection == 0)
    {
        height = onlyThumbnail ? [JBoMultiImageView getThumbnailHeightWithCount:count] : [JBoMultiImageView getHeightWithCount:count];
    }
    else
    {
        CGFloat tmpHeight = [JBoMultiImageView getThumbnailHeightWithCount:_numberOfPhotosAtSection_] * numberOfSection ;
        height += tmpHeight + (onlyThumbnail ? [JBoMultiImageView getThumbnailHeightWithCount:remainder] : [JBoMultiImageView getHeightWithCount:remainder]);
    }
    
    return height + numberOfSection * _PlatformImageSectionInterval_;
}

@end
