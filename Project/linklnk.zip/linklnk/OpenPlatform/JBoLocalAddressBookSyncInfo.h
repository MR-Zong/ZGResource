//
//  JBoLocalAddressBookSyncInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAddressBookPersonInfo.h"

//本地通讯录同步的号码最大数量
#define _syncPhoneNumMaxCount_ 2

@class JBoCloudAddressBookGroupInfo;

/**本地通讯录同步到服务器信息
 */
@interface JBoLocalAddressBookSyncInfo : JBoAddressBookPersonInfo

/**联系人在云通讯录中是否已存在, 存在的云通讯录分组信息
 */
@property(nonatomic,retain) JBoCloudAddressBookGroupInfo *cloudGroupInfo;

/**要显示的电话号码
 */
- (NSString*)displayPhoneNum;


@end
