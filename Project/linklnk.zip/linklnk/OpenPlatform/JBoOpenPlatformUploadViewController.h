//
//  JBoOpenPlatformEidtViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-11-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformEditViewController.h"

/**云名片信息上传
 */
@interface JBoOpenPlatformUploadViewController : JBoOpenPlatformEditViewController<UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextViewDelegate,UIAlertViewDelegate>

/**云名片样式信息 数组元素是 JBoOpenPlatformWebStyleInfo对象
 */
@property(nonatomic,retain) NSMutableArray *styleInfoArray;

/**预设内容
 */
@property(nonatomic,copy) NSAttributedString *preAttributedText;

@end
