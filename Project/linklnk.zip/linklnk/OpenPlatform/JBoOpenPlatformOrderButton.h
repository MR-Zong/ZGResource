//
//  JBoOpenPlatformOrderButton.h
//  linklnk
//
//  Created by kinghe005 on 15-3-5.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**订单管理按钮
 */
@interface JBoOpenPlatformOrderButton : UIView

/**按钮图标
 */
@property(nonatomic,readonly) UIButton *button;

/**是否有红点
 */
@property(nonatomic,assign) BOOL redPoint;

@end
