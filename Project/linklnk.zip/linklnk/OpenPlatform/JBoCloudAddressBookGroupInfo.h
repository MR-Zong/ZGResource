//
//  JBoCloudAddressBookGroupInfo.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**云通讯录分组信息
 */
@interface JBoCloudAddressBookGroupInfo : NSObject

/**分组Id
 */
@property(nonatomic,assign) long long Id;

/**分组名称
 */
@property(nonatomic,copy) NSString *groupName;

/**分组链接
 */
@property(nonatomic,copy) NSString *url;

/**是否已展开
 */
@property(nonatomic,assign) BOOL open;

/**分组内的信息 数组元素是 JBoCloudAddressBookInfo对象
 */
@property(nonatomic,retain) NSMutableArray *infos;

@end
