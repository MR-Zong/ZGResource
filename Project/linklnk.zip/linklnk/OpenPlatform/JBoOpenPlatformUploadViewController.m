//
//  JBoOpenPlatformEidtViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-11-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformUploadViewController.h"
#import "JBoTextView.h"
#import "JBoOpenPlatformTextStyleInfo.h"
#import "JBoImageTextTool.h"
#import "JBoSceneConditionSelected.h"
#import "JBoSceneConditionPickerSelected.h"
#import "JBoSceneConditionPicker.h"
#import "JBoOpenPlatformGroupInfo.h"
#import "JBoLocationSelectView.h"
#import "JBoFileManager.h"
#import "JBoStraightlineProgressView.h"
#import "JBoOpenPlatformWebStyleViewController.h"
#import "JBoOpenPlatformGroupInfoViewController.h"
#import "JBoUserOperation.h"
#import "JBoOpenPlatformWebStyleInfo.h"
#import "JBoUserPrivacyViewController.h"
#import "JBoTextStorage.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoOpenPlatformOperation.h"
#import "JBoImageCacheTool.h"
#import "SSTextView.h"

@interface JBoOpenPlatformUploadViewController ()
<JBoSceneConditionPickerDelegate,
JBoOpenPlatformWebStyleViewControllerDelegate,
JBoOpenPlatformGroupInfoViewControllerDelegate>

//可见范围选择
@property(nonatomic,retain) JBoSceneConditionPickerSelected *visibleCondition;

//当前可见范围
@property(nonatomic,assign) NSInteger visible;

//可见范围选择器
@property(nonatomic,retain) JBoSceneConditionPicker *picker;

//图文样式
@property(nonatomic,retain) JBoSceneConditionSelected *styleSelected;

//选中的图文样式
@property(nonatomic,retain) JBoOpenPlatformWebStyleInfo *selectedStyleInfo;

//云名片分组
@property(nonatomic,retain) JBoSceneConditionSelected *groupSelected;

//选择的云名片分组信息
@property(nonatomic,retain) JBoOpenPlatformGroupInfo *groupInfo;

//位置
@property(nonatomic,retain) JBoLocationSelectView *locationSelected;

/**滚动视图
 */
@property(nonatomic,retain) UIScrollView *scrollView;

//使用条款
@property(nonatomic,retain) UIView *protocolView;

/**标题
 */
@property(nonatomic,retain) SSTextView *titleTextView;

/**价格
 */
@property(nonatomic,retain) UITextField *priceTextField;


@end

@implementation JBoOpenPlatformUploadViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self)
    {
        self.title = @"编辑云名片信息";
    }
    
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    self.delegate = nil;
    
    [_styleInfoArray release];
    
    [_preAttributedText release];
    
    [_visibleCondition release];
    [_picker release];
    [_styleSelected release];
    [_selectedStyleInfo release];
    
    [_groupSelected release];
    [_groupInfo release];
    [_locationSelected release];
    
    [_scrollView release];
    
    [_protocolView release];
    [_titleTextView release];
    [_priceTextField release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.locationSelected viewWillAppear];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.locationSelected viewWillDisappear];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    [super httpRequest:request didFailed:error identifier:identifier];
    if([identifier isEqualToString:_uploadOpenPlatformInfoIdentifier_])
    {
        [self alertNetworkMsg:@"上传云名片信息失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.progressView.progress = 1.0;
    
    if([identifier isEqualToString:_uploadOpenPlatformInfoIdentifier_])
    {
        JBoOpenPlatformInfo *info = [JBoOpenPlatformOperation uploadOpenPlatformInfoFromData:data];
        if(info)
        {
            [self alertMsg:@"上传成功"];
        
            JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
            NSMutableArray *thumbnailURLs = [NSMutableArray arrayWithCapacity:info.imageInfos.count];
            
            for(NSInteger i = 0;i < self.thumbnails.count && i < info.imageInfos.count;i ++)
            {
                JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:i];
                
                if(![NSString isEmpty:imageInfo.thumbnailURL])
                {
                    [thumbnailURLs addObject:imageInfo.thumbnailURL];
                }
            }
 
            [JBoFileManager moveFiles:self.thumbnailFiles withURLs:thumbnailURLs suffix:cache.imageSuffix toPath:cache.normalCachePath];

            [JBoFileManager deleteFiles:self.thumbnailFiles];
            self.thumbnailFiles = nil;
            
            self.progressView.hidden = YES;
            self.isRequesting = NO;
            self.files = nil;

            if([self.delegate respondsToSelector:@selector(openPlatformEidtViewController:didFinishWithInfo:)])
            {
                [self.delegate openPlatformEidtViewController:self didFinishWithInfo:info];
            }
            
            [self close];
        }
        else
        {
            self.isRequesting = NO;
            self.progressView.hidden = YES;
            
            [JBoFileManager deleteFiles:self.files];
            self.files = nil;
            
            [JBoFileManager deleteFiles:self.thumbnailFiles];
            self.thumbnailFiles = nil;
            
            [self alertNetworkMsg:@"上传云名片信息失败"];
        }
        return;
    }
}

#pragma mark- 加载视图

- (void)uploadContent
{
    if(self.isRequesting)
        return;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    if([NSString isEmpty:self.titleTextView.text])
    {
        [self alertMsg:[NSString stringWithFormat:@"%@不能为空", self.titleTextView.placeholder]];
        return;
    }
    
    if([NSString isEmpty:self.textView.text])
    {
        [self alertMsg:@"内容不能为空"];
        return;
    }
    
    float price = 0;
    
    //如果样式是商品，价格不能为空
    if(self.selectedStyleInfo.Id == _openPlatformMallId_)
    {
        if([NSString isEmpty:self.priceTextField.text])
        {
            [self alertMsg:@"价格不能为空"];
            return;
        }
        
        price = [self.priceTextField.text floatValue];
        if(price == 0)
        {
            [self alertMsg:@"请输入商品价格"];
            return;
        }
        
        if(self.attachments.count == 0)
        {
            [self alertMsg:@"最少上传1张图片"];
            return;
        }
    }
    
    self.isRequesting = YES;
    
    if(!self.progressView)
    {
        JBoStraightlineProgressView *progressView = [[JBoStraightlineProgressView alloc] initWithFrame:CGRectMake(0, 0, _width_, 3.0)];
        [self.view addSubview:progressView];
        self.progressView = progressView;
        [progressView release];
    }
    self.progressView.hidden = NO;
    self.progressView.progress = 0;
    
    [self.httpRequest startDataLoading];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){

        NSDictionary *dic = [self textParam];
        
        NSString *content = [dic objectForKey:_openPlatformContent_];
        NSString *imageCount = [dic objectForKey:_openPlatformImageCountAfterText_];
        NSString *color = [dic objectForKey:_openPlatformContentTextColor_];
        NSString *font = [dic objectForKey:_openPlatformContentFontStyle_];
        NSString *fontSize = [dic objectForKey:_openPlatformContentFontSize_];
        NSString *range = [dic objectForKey:_openPlatformContentStyleRange_];
        
        dic = [self imageParam];
        NSString *widths = [dic objectForKey:_openPlatformWidths_];
        NSString *heights = [dic objectForKey:_openPlatformHeights_];
  
        
        self.httpRequest.startImmediately = NO;
        self.httpRequest.totalBytesSent = self.totalSize;
        self.totalSize = 0;
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            long long webStyleId = self.selectedStyleInfo.Id;
            NSInteger visible = self.visible;
            NSInteger imageIndex = NSNotFound;
            NSInteger imagePosotion = NSNotFound;
            
            self.httpRequest.identifier = _uploadOpenPlatformInfoIdentifier_;
            [self.httpRequest downloadWithURL:[JBoOpenPlatformOperation uploadOpenPlatformInfo] paraDic:[JBoOpenPlatformOperation uploadOpenPlatformInfoParamWithVisible:visible widths:widths heights:heights content:content webStyleId:webStyleId Id:0 title:self.titleTextView.text imageCountAfterText:imageCount imageIndex:imageIndex imagePosition:imagePosotion imageCountAfterTitle:nil font:font textColor:color styleRange:range fontSize:fontSize addrInfo:[self.locationSelected getAddressInfo] groupId:self.groupInfo.Id price:price] files:self.files filesKey:_openPlatformImagesFile_];
            [self.httpRequest addFiles:self.thumbnailFiles forKey:_openPlatformThumbnails_];
            [self.httpRequest startDownload];
            self.httpRequest.startImmediately = YES;
        });
    });
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self setRightBarItemWithTitle:@"完成" action:@selector(uploadContent)];
    
    self.backItem = YES;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    scrollView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:scrollView];
    self.scrollView = scrollView;
    [scrollView release];
    
    //图文样式
    JBoSceneConditionSelected *selected = [[JBoSceneConditionSelected alloc] initWithFrame:CGRectMake(_margin_, _margin_, _width_ - _margin_ * 2, 40.0) title:@"图文样式" icon:nil];
    selected.layer.cornerRadius = 5.0;
    selected.layer.masksToBounds = YES;
    [selected addTarget:self action:@selector(selectStyle:)];
    [self.scrollView addSubview:selected];
    self.styleSelected = selected;
    [selected release];
    
    selected = [[JBoSceneConditionSelected alloc] initWithFrame:CGRectMake(self.styleSelected.left, self.styleSelected.bottom + _controlInterval_, self.styleSelected.width, self.styleSelected.height) title:@"分组" icon:nil];
    selected.layer.cornerRadius = 5.0;
    selected.layer.masksToBounds = YES;
    [selected addTarget:self action:@selector(selectGroup:)];
    [self.scrollView addSubview:selected];
    self.groupSelected = selected;
    [selected release];
    
    //标题
    SSTextView *textView = [[SSTextView alloc] initWithFrame:CGRectMake(_margin_, self.groupSelected.bottom + _controlInterval_, _width_ - _margin_ * 2, 60.0)];
    textView.layer.cornerRadius = 6;
    textView.layer.borderWidth = 0.2;
    textView.inputAccessoryView = self.inputAccessoryView;
    textView.layer.borderColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0].CGColor;
    textView.font = _openPlatformTitleFont_;
    textView.textColor = [UIColor blackColor];
    textView.delegate = self;
    textView.placeholderOffset = CGPointMake(2.0, 8.0);
    
    //文本输入框
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
    view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    
    CGFloat buttonWidth = 60.0;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitle:@"完成" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
    [view addSubview:button];
    textView.inputAccessoryView = view;
    [view release];
    
    textView.maxCount = _inputFormatOpenplatformTitle_;
    textView.limitable = YES;
    textView.placeholder = @"标题";
    
    [self.scrollView addSubview:textView];
    self.titleTextView = textView;
    [textView release];
    
    //预设内容 用于寻宝场景
    if(self.preAttributedText != nil)
    {
        self.textView.attributedText = self.preAttributedText;
    }
    
    
    self.textView.top = self.titleTextView.bottom + _controlInterval_;
    [self.scrollView addSubview:self.textView];
    
    self.originalTextFrame = self.textView.frame;
    
    //位置
    JBoLocationSelectView *loc = [[JBoLocationSelectView alloc] initWithFrame:CGRectMake(self.styleSelected.left, self.textView.bottom + _controlInterval_, self.styleSelected.width, self.styleSelected.height)];
    loc.layer.cornerRadius = 5.0;
    loc.layer.masksToBounds = YES;
    loc.useDefaultAddr = YES;
    loc.navigationController = self.navigationController;
    loc.black = self.black;
    [self.scrollView addSubview:loc];
    self.locationSelected = loc;
    [loc release];
    
    //可见范围
    self.visible = _lookAndTellVisiblePublic_;
    JBoSceneConditionPickerSelected *slider = [[JBoSceneConditionPickerSelected alloc] initWithFrame:CGRectMake(self.locationSelected.left, self.locationSelected.bottom + _controlInterval_, self.locationSelected.width, self.styleSelected.height) title:@"可见范围" icon:nil];
    slider.layer.cornerRadius = 5.0;
    slider.layer.masksToBounds = YES;
    slider.contentLabel.text = @"公开";
    [slider addTarget:self action:@selector(selectVisible:)];
    [self.scrollView addSubview:slider];
    self.visibleCondition = slider;
    [slider release];
    
    //使用条款
    self.protocolView = [JBoUserOperation getProtocolViewWithFrame:CGRectMake(0, self.visibleCondition.bottom + _controlInterval_, _width_, 0) target:self action:@selector(serverProtocolAction:)];
    [self.scrollView addSubview:self.protocolView];
    
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width, self.protocolView.bottom + _controlInterval_);
}

#pragma mark- 键盘

- (void)inputFinish:(id) sender
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

/**键盘高度改变
 */
- (void)keyboardWillChangeFrame:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    CGRect frame = [[dic objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    frame = [self.view convertRect:frame fromView:nil];

    if(frame.origin.y < self.view.height)
    {
        CGFloat keyboardHeight = frame.size.height;
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, keyboardHeight, 0)];
        CGRect frame = self.originalTextFrame;
        frame.size.height -= keyboardHeight;
        self.textView.frame = frame;
    }
    else
    {
        [self.scrollView setContentInset:UIEdgeInsetsZero];
        self.textView.frame = self.originalTextFrame;
    }
    [self layoutSubView];
}

- (void)layoutSubView
{
    self.locationSelected.top = self.textView.bottom + _controlInterval_;
    self.visibleCondition.top = self.locationSelected.bottom + _controlInterval_;
    self.protocolView.top = self.visibleCondition.bottom + _controlInterval_;
    self.scrollView.contentSize = CGSizeMake(self.scrollView.width, self.protocolView.bottom + _controlInterval_);
}

#pragma mark- textView 代理


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [self.scrollView setContentOffset:CGPointMake(0, textView.top - _margin_) animated:YES];
}

- (void)textViewDidChange:(UITextView *)textView
{
    SSTextView *sst = (SSTextView*)textView;
    [sst textDidChange];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    SSTextView *sst = (SSTextView*)textView;
    return [sst shouldChangeTextInRange:range replacementText:text];
}

#pragma mark- customTextView代理

- (void)customTextViewDidBeginEditing:(JBoTextView *)textView
{
    [self.scrollView setContentOffset:CGPointMake(0, textView.top - _margin_) animated:YES];
}


#pragma mark- private method

- (void)serverProtocolAction:(UIButton*) button
{
    JBoUserPrivacyViewController *userPrivacy = [[JBoUserPrivacyViewController alloc] init];
    userPrivacy.black = self.black;
    [self.navigationController pushViewController:userPrivacy animated:YES];
    [userPrivacy release];
}

//选择图文样式
- (void)selectStyle:(id) sender
{
    JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
    if(info.rosterInfo.role != _rosterRoleEnterprise_)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"只有%@才能选择图文样式", _rosterGodenUser_] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    JBoOpenPlatformWebStyleViewController *webStyle = [[JBoOpenPlatformWebStyleViewController alloc] initWithInfo:self.selectedStyleInfo infoArray:self.styleInfoArray operation:JBoOpenPlatformWebStyleOperationSelected];
    webStyle.delegate = self;
    webStyle.black = self.black;
    [self.navigationController pushViewController:webStyle animated:YES];
    [webStyle release];
}

//选择分组
- (void)selectGroup:(id) sender
{
    JBoOpenPlatformGroupInfoViewController *groupInfoVC = [[JBoOpenPlatformGroupInfoViewController alloc] init];
    groupInfoVC.delegate = self;
    groupInfoVC.groupInfo = self.groupInfo;
    groupInfoVC.black = self.black;
    [self.navigationController pushViewController:groupInfoVC animated:YES];
    [groupInfoVC release];
}

#pragma mark- JBoOpenPlatformWebStyleViewController代理

- (void)openPlatformWebStyleViewController:(JBoOpenPlatformWebStyleViewController *)viewController didSelectInfo:(JBoOpenPlatformWebStyleInfo *)info
{
    self.selectedStyleInfo = info;
    self.styleSelected.contentLabel.text = self.selectedStyleInfo.name;
    
    if(self.selectedStyleInfo.Id == _openPlatformMallId_)
    {
        if(!self.priceTextField)
        {
            CGRect frame = self.styleSelected.frame;
            UITextField *textField = [[UITextField alloc] initWithFrame:frame];
            textField.borderStyle = UITextBorderStyleNone;
            textField.layer.cornerRadius = self.styleSelected.layer.cornerRadius;
            textField.layer.masksToBounds = YES;
            textField.placeholder = @"价格(元)";
            textField.backgroundColor = self.styleSelected.backgroundColor;
            textField.font = self.styleSelected.contentLabel.font;
            textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            textField.inputAccessoryView = self.titleTextView.inputAccessoryView;
            textField.keyboardType = UIKeyboardTypeDecimalPad;
            //[textField addTarget:self action:@selector(priceDidChange:) forControlEvents:UIControlEventEditingChanged];
            [textField addTarget:self action:@selector(priceDidEndEdit:) forControlEvents:UIControlEventEditingDidEnd];
            [self.scrollView addSubview:textField];
            self.priceTextField = textField;
            [textField release];
        }
        
        self.priceTextField.hidden = NO;
        self.priceTextField.top = self.titleTextView.bottom + _controlInterval_;
        self.textView.top = self.priceTextField.bottom + _controlInterval_;
        self.originalTextFrame = self.textView.frame;
        self.titleTextView.placeholder = @"商品名称";
    }
    else
    {
        [self.priceTextField resignFirstResponder];
        self.priceTextField.hidden = YES;
        self.textView.top = self.titleTextView.bottom + _controlInterval_;
        self.originalTextFrame = self.textView.frame;
        self.titleTextView.placeholder = @"标题";
    }
    
    
    [self layoutSubView];
}

//商品价格改变
- (void)priceDidChange:(UITextField*) textField
{
    if(textField.text.length > 0)
    {
        textField.leftViewMode = UITextFieldViewModeAlways;
    }
    else
    {
        textField.leftViewMode = UITextFieldViewModeNever;
    }
}

//价格编辑完成
- (void)priceDidEndEdit:(UITextField*) textField
{
    if(textField.text.length > 0)
    {
        float price = [textField.text floatValue];
        
        if(price < _inputFormatOpenPlatformMinPrice_)
        {
            price = _inputFormatOpenPlatformMinPrice_;
            textField.text = [NSString stringWithFormat:@"%0.2f", price];
        }
        else if(price > _inputFormatOpenPlatformMaxPirce_)
        {
            price = _inputFormatOpenPlatformMaxPirce_;
            textField.text = [NSString stringWithFormat:@"%0.2f", price];
        }
    }
}

#pragma mark- JBoOpenPlatformGroupInfoViewController 代理

- (void)openPlatformGroupInfoViewController:(JBoOpenPlatformGroupInfoViewController *)viewController didSelectGroupInfo:(JBoOpenPlatformGroupInfo *)info
{
    self.groupInfo = info;
    self.groupSelected.contentLabel.text = [self.groupInfo title];
}

#pragma mark- 可见范围

- (void)selectVisible:(id) sender
{
    JBoSceneConditionPicker *picker = [[JBoSceneConditionPicker alloc] initWithSuperView:self.view style:JBoSceneConditionPickerStyleLookAndTellVisible];
    picker.closeWhenTouchMargin = YES;
    NSMutableArray *array = [picker.source firstObject];
    [array replaceObjectAtIndex:1 withObject:@"隐藏"];
    [picker showWithAnimated:YES completion:nil];
    picker.delegate = self;
    self.picker = picker;
    [picker release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
