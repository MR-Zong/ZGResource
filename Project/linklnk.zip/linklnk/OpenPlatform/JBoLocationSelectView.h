//
//  JBoLocationSelectView.h
//  linklnk
//
//  Created by kinghe005 on 14-10-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoMapInfo;

/**定位，可以获取当前位置，选择其他位置
 */
@interface JBoLocationSelectView : UIView<UIAlertViewDelegate>

//视图跳转
@property(nonatomic,assign) UINavigationController *navigationController;

//导航栏字体颜色是否为黑色 default is 'YES'
@property(nonatomic,assign) BOOL black;

/**是否使用默认地址 default is ’NO‘
 */
@property(nonatomic,assign) BOOL useDefaultAddr;

/**视图消失，必须在视图被dealloc之前调用，否则会造成内存泄露
 * 比如在 viewController viewWillDisappear
 */
- (void)viewWillDisappear;

/**视图出现
 */
- (void)viewWillAppear;

/**获取地址信息
 *@return 没有则返回nil
 */
- (JBoMapInfo*)getAddressInfo;

/**设置地址信息
 */
- (void)setAddressInfo:(JBoMapInfo*) info;

@end
