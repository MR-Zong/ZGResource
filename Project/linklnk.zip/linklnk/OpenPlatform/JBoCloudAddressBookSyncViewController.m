//
//  JBoCloundAddressSyncViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookSyncViewController.h"
#import <AddressBook/AddressBook.h>
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoCloudAddressBookInfo.h"
#import "JBoCheckInputText.h"
#import "JBoCloudAddressBookSyncCell.h"
#import "JBoCloudAddressBookCell.h"
#import "JBoImageCacheTool.h"
#import "ChineseToPinyin.h"
#import "JBoCustomToolBar.h"
#import "JBoImageTextTool.h"

#define _searchBarHeight_ 40.0

@interface JBoCloudAddressBookSyncViewController ()<JBoCloudAddressBookSyncCellDelegate, JBoCloudAddressBookHeaderDelegate,JBoCustomToolBarDelegate>
{
    //通讯录内容
    CFArrayRef _addressBookArray;
    
    //通讯录
    ABAddressBookRef _addressBook;
    
    //搜索栏搜索结果
    NSMutableArray *_searchResultArray;
    
    //黑色半透明视图
    UIView *_transparentView;
}
//信息列表
@property(nonatomic,retain) UITableView *tableView;

//搜索栏
@property(nonatomic,retain) UISearchBar *searchBar;

//是否允许访问通讯录
@property(nonatomic,assign) BOOL enableAccess;

//正在搜索
@property(nonatomic,assign) BOOL searching;

//选中的数据 数组元素是 JBoCloundAddressBookInfo对象
@property(nonatomic,retain) NSMutableArray *selectedArray;

//底部工具条
@property(nonatomic,retain) JBoCustomToolBar *toolBar;

@end

@implementation JBoCloudAddressBookSyncViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"同步到手机通讯录";
        
        _searchResultArray = [[NSMutableArray alloc] init];
        
        self.selectedArray = [NSMutableArray array];
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_groupInfos release];
    
    if(_addressBookArray != NULL)
        CFRelease(_addressBookArray);
    if(_addressBook != NULL)
        CFRelease(_addressBook);
    
    [_searchResultArray release];
    [_transparentView release];
    
    [_tableView release];
    [_searchBar release];
    
    [_selectedArray release];
    
    [_toolBar release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

//完成选择 开始同步
- (void)finish
{
    if(self.navigationItem.leftBarButtonItem.enabled == NO)
        return;
    
    if(self.selectedArray.count == 0)
    {
        [self alertMsg:@"请选择要同步的联系人"];
        return;
    }
    self.appDelegate.dataLoadingView.hidden = NO;
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.view.userInteractionEnabled = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        for(JBoCloudAddressBookInfo *info in self.selectedArray)
        {
            switch (info.operation)
            {
                case JBoCloudAddressBookRecordOperationAdd :
                {
                    [self addRecordWithInfo:info];
                }
                    break;
                case JBoCloudAddressBookRecordOperationAddAllNum :
                case JBoCloudAddressBookRecordOperationAddPhoneNum :
                case JBoCloudAddressBookRecordOperationAddTelePhoneNum :
                {
                    [self updateRecordWithInfo:info];
                }
                    break;
                default:
                    break;
            }
            info.operation = JBoCloudAddressBookRecordOperationNone;
        }
        
        [self.selectedArray removeAllObjects];
        ABAddressBookSave(_addressBook, NULL);
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            self.appDelegate.dataLoadingView.hidden = YES;
            self.navigationItem.leftBarButtonItem.enabled = YES;
            self.view.userInteractionEnabled = YES;
            [_tableView reloadData];
        });
    });
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];

    //判断当前设备系统的版本 IOS6以后的通讯录要授权才能操作
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        if(ABAddressBookGetAuthorizationStatus() != kABAuthorizationStatusAuthorized)
        {
            _addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
            //等待同意后向下执行
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            
            ABAddressBookRequestAccessWithCompletion(_addressBook, ^(bool granted, CFErrorRef error)
                                                     {
                                                         dispatch_semaphore_signal(sema);
                                                         self.enableAccess = granted;
                                                         [self getInfoFromLocalAddressBook:_addressBook];
                                                     });
            
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
            dispatch_release(sema);
        }
        else
        {
            _addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
            self.enableAccess = YES;
            [self getInfoFromLocalAddressBook:_addressBook];
        }
#endif
    }
    else
    {
        _addressBook = ABAddressBookCreate();
        self.enableAccess = YES;
        [self getInfoFromLocalAddressBook:_addressBook];
    }
}

- (void)loadInitView
{
    if(!self.enableAccess)
    {
        self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        [label setTextAlign:JBoTextAlignmentCenter];
        label.backgroundColor = [UIColor clearColor];
        label.numberOfLines = 0;
        label.text = @"您的手机通信录并没有授权，请在设置--隐私--通信录内设置";
        [self.view addSubview:label];
        [label release];
    }
    else
    {
        [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
        
        CGFloat toolBarHeight = 45.0;
        
        //创建tableview
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_ - toolBarHeight) style:UITableViewStylePlain];
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.separatorColor = [UIColor colorWithRed:160.0 / 255.0 green:160.0 / 255.0 blue:160.0 / 255.0 alpha:1.0];
        tableView.sectionHeaderHeight = _cloudAddressBookHeaderHeight_;
        [self.view addSubview:tableView];
        self.tableView = tableView;
        [tableView release];
        [tableView setExtraCellLineHidden];
        
        //创建搜索视图
        UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
        searchBar.placeholder = @"搜索";
        if(!_ios7_0_)
        {
            searchBar.tintColor = _searchBarColor_;
        }
        searchBar.delegate = self;
        _tableView.tableHeaderView = searchBar;
        self.searchBar = searchBar;
        [searchBar release];
        
        JBoCustomToolBar *toolBar = [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, tableView.bottom, _width_, toolBarHeight) items:[NSArray arrayWithObject:[JBoCustomToolBarItem toolBarItemWithTitle:@"选择全部" image:nil]]];
        toolBar.delegate = self;
        
        UIButton *btn = [toolBar buttonForIndex:0];
        [btn setTitle:@"全部取消" forState:UIControlStateSelected];
        [btn setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
        
        [self.view addSubview:toolBar];
        self.toolBar = toolBar;
        [toolBar release];
    }
}

#pragma mark- JBoCustomToolBar代理

- (void)toolBar:(JBoCustomToolBar *)toolBar didSelectedAtIndex:(NSInteger)index
{
    UIButton *btn = [toolBar buttonForIndex:index];
    btn.selected = !btn.selected;
    
    if(btn.selected)
    {
        for(JBoCloudAddressBookGroupInfo *groupInfo in self.groupInfos)
        {
            for(JBoCloudAddressBookInfo *info in groupInfo.infos)
            {
                if(info.operation != JBoCloudAddressBookRecordOperationNone && ![self.selectedArray containsObject:info])
                {
                    [self.selectedArray addObject:info];
                }
            }
        }
    }
    else
    {
        [self.selectedArray removeAllObjects];
    }
    
    [_tableView reloadData];
}

#pragma mark-通讯录操作

//获取手机上的通信录信息
- (void)getInfoFromLocalAddressBook:(ABAddressBookRef) addressBook
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        if(self.enableAccess)
        {
            //所有云名片夹的错做设置成默认状态
            for(JBoCloudAddressBookGroupInfo *groupInfo in self.groupInfos)
            {
                for(JBoCloudAddressBookInfo *info in groupInfo.infos)
                {
                    info.operation = JBoCloudAddressBookRecordOperationDefault;
                }
            }
            
            if(_addressBookArray != NULL)
                CFRelease(_addressBookArray);
            
            //获取所有联系人
            _addressBookArray =  ABAddressBookCopyArrayOfAllPeople(addressBook);
            //获取联系人的数量
            CFIndex numberOfContacts = ABAddressBookGetPersonCount(addressBook);
            
            NSLog(@"联系人数量%ld",numberOfContacts);
            
            for(int i = 0;i < numberOfContacts;i++)
            {
                //获取通信录中的一条记录
                NSString *name = nil;
                ABRecordRef recordRef = CFArrayGetValueAtIndex(_addressBookArray, i);
                
                //获取联系人姓名
                if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease]  && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease] == nil)
                {
                    name = [(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease];
                }
                else if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease] == nil && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease])
                {
                    name = [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease];
                }
                else if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease] && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease])
                {
                    name = [NSString stringWithFormat:@"%@%@",[(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease],[(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease]];
                }
                
                if([NSString isEmpty:name])
                {
                    name = [(NSString*)ABRecordCopyCompositeName(recordRef) autorelease];
                }
                
                
                //获取个人信息中的电话号码信息数组
                ABMutableMultiValueRef phoneNumberRef = ABRecordCopyValue(recordRef, kABPersonPhoneProperty);
                
                //从电话号码信息里获取手机号码
                NSInteger phoneCount = 0;
                if(phoneNumberRef != NULL)
                    phoneCount = ABMultiValueGetCount(phoneNumberRef);
                
                NSMutableArray *phoneNums = [[NSMutableArray alloc] initWithCapacity:phoneCount];
                
                for(int i = 0;i < phoneCount;i++)
                {
                    NSString *mobileNumber = [(NSString*)ABMultiValueCopyValueAtIndex(phoneNumberRef, i) autorelease];
                    if(mobileNumber)
                    {
                        NSString *phoneNum = [self phoneNumFromString:mobileNumber];
                        [phoneNums addObject:phoneNum];
                    }
                    else
                    {
                        continue;
                    }
                }

                //遍历数组 获取手机通讯录和云名片夹的区别
                if(name && phoneNums.count > 0)
                {
                    for(JBoCloudAddressBookGroupInfo *groupInfo in self.groupInfos)
                    {
                        for(JBoCloudAddressBookInfo *info in groupInfo.infos)
                        {
                            if(info.operation == JBoCloudAddressBookRecordOperationNone)
                                continue;
                            
                            BOOL existTelePhoneNum = [phoneNums containsObject:info.telePhone];
                            BOOL existPhoneNum = [phoneNums containsObject:info.phoneNum];
                            BOOL existName = [info.name isEqualToString:name];
                            
                            if((existTelePhoneNum || info.telePhone == nil) && existPhoneNum && existName)
                            {
                                info.operation = JBoCloudAddressBookRecordOperationNone;
                                continue;
                            }
                            
                            if(existName)
                            {
                                if(!existPhoneNum && !existTelePhoneNum)
                                {
                                    info.operation = JBoCloudAddressBookRecordOperationAddAllNum;
                                }
                                else if (existPhoneNum && !existTelePhoneNum && info.telePhone != nil)
                                {
                                    info.operation = JBoCloudAddressBookRecordOperationAddTelePhoneNum;
                                }
                                else if(!existPhoneNum && existTelePhoneNum && info.phoneNum != nil)
                                {
                                    info.operation = JBoCloudAddressBookRecordOperationAddPhoneNum;
                                }
                                info.recordIndex = i;
                            }
                            else
                            {
                                info.operation = JBoCloudAddressBookRecordOperationAdd;
                            }
                        }
                    }
                }
                
                if(phoneNumberRef != NULL)
                {
                    CFRelease(phoneNumberRef);
                }
                
                [phoneNums release];
            }
        }
        else
        {
            return;
        }
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            self.appDelegate.dataLoadingView.hidden = YES;
            [self loadInitView];
        });
    });
}

/**修改手机通讯录联系人信息
 *@param 手机通讯录联系人所在下标
 *@param 云名片夹联系人信息
 */
- (void)updateRecordWithInfo:(JBoCloudAddressBookInfo*) info
{
    if(_addressBookArray != NULL)
    {
        NSInteger index = info.recordIndex;
        NSInteger count = CFArrayGetCount(_addressBookArray);
        if(index < count)
        {
            ABRecordRef record = CFArrayGetValueAtIndex(_addressBookArray, index);

            if(![NSString isEmpty:info.remark])
            {
                ABRecordSetValue(record, kABPersonNoteProperty, (CFStringRef)info.remark, NULL);
            }
            
            //创建电话号码值
            ABMutableMultiValueRef multiPhone = NULL;
            
            //创建可变的数组
            ABMultiValueRef phones = ABRecordCopyValue(record, kABPersonPhoneProperty);
            if(phones != NULL)
            {
                multiPhone = ABMultiValueCreateMutableCopy(phones);
                CFRelease(phones);
            }
            if(multiPhone == NULL)
               multiPhone = ABMultiValueCreateMutable(kABMultiStringPropertyType);
            
            switch (info.operation)
            {
                case JBoCloudAddressBookRecordOperationAddAllNum :
                {
                    if(![NSString isEmpty:info.phoneNum])
                    {
                        ABMultiValueAddValueAndLabel(multiPhone, (CFStringRef)info.phoneNum, kABPersonPhoneMobileLabel, NULL);
                    }
                    
                    if(![NSString isEmpty:info.telePhone])
                    {
                        ABMultiValueAddValueAndLabel(multiPhone, (CFStringRef)info.telePhone, kABPersonPhoneMainLabel, NULL);
                    }
                }
                    break;
                case JBoCloudAddressBookRecordOperationAddPhoneNum :
                {
                    if(![NSString isEmpty:info.phoneNum])
                    {
                        ABMultiValueAddValueAndLabel(multiPhone, (CFStringRef)info.phoneNum, kABPersonPhoneMobileLabel, NULL);
                    }
                }
                    break;
                case JBoCloudAddressBookRecordOperationAddTelePhoneNum :
                {
                    if(![NSString isEmpty:info.telePhone])
                    {
                        ABMultiValueAddValueAndLabel(multiPhone, (CFStringRef)info.telePhone, kABPersonPhoneMainLabel, NULL);
                    }
                }
                    break;
                default:
                    break;
            }
            
            if(multiPhone != NULL)
            {
                ABRecordSetValue(record, kABPersonPhoneProperty, multiPhone, NULL);
                CFRelease(multiPhone);
            }
        }
    }
}

/**添加手机联系人
 *@param info 云名片夹联系人信息
 */
- (void)addRecordWithInfo:(JBoCloudAddressBookInfo*) info
{
    if(_addressBook == NULL)
        return;
    
    ABRecordRef record = ABPersonCreate();
    
    if(![NSString isEmpty:info.name])
    {
        ABRecordSetValue(record, kABPersonLastNameProperty, (CFStringRef)info.name, NULL);
    }
    
    ABMutableMultiValueRef multiPhone = ABMultiValueCreateMutable(kABMultiStringPropertyType);
    if(![NSString isEmpty:info.phoneNum])
    {
        ABMultiValueAddValueAndLabel(multiPhone, (CFStringRef)info.phoneNum, kABPersonPhoneMobileLabel, NULL);
    }
    
    if(![NSString isEmpty:info.telePhone])
    {
        ABMultiValueAddValueAndLabel(multiPhone, (CFStringRef)info.telePhone, kABPersonPhoneMainLabel, NULL);
    }
    
    ABRecordSetValue(record, kABPersonPhoneProperty, multiPhone, NULL);
    
    if(multiPhone != NULL)
    {
        CFRelease(multiPhone);
    }
    
    if(record != NULL)
    {
        ABAddressBookAddRecord(_addressBook, record, NULL);
        CFRelease(record);
    }
    
    if(![NSString isEmpty:info.remark])
    {
        ABRecordSetValue(record, kABPersonNoteProperty, (CFStringRef)info.remark, NULL);
    }
    
}

#pragma mark- private method

//把字符串转换成手机号码
- (NSString*)phoneNumFromString:(NSString*) str
{
    NSString *phoneNum = nil;
    if(str)
    {
        phoneNum = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
    }
    return phoneNum;
}

//格式化手机号码
- (NSString*)formatPhoneNum:(NSString*) phoneNum
{
    if([NSString isEmpty:phoneNum])
        return nil;
    
    if(phoneNum.length == 11)
    {
        NSString *str1 = [phoneNum substringWithRange:NSMakeRange(0, 3)];
        NSString *str2 = [phoneNum substringWithRange:NSMakeRange(3, 4)];
        NSString *str3 = [phoneNum substringWithRange:NSMakeRange(7, 4)];
        
        return [NSString stringWithFormat:@"手机:%@-%@-%@", str1, str2, str3];
    }
    else
    {
       return [NSString stringWithFormat:@"手机:%@", phoneNum];
    }
}

//格式化固定电话
- (NSString*)formatTelePhone:(NSString*) telePhone
{
    if([NSString isEmpty:telePhone])
        return nil;
    
    if(telePhone.length == 10)
    {
        NSString *str1 = [telePhone substringWithRange:NSMakeRange(0, 3)];
        NSString *str2 = [telePhone substringWithRange:NSMakeRange(3, telePhone.length - 3)];
        
        return [NSString stringWithFormat:@"座机:%@-%@", str1, str2];
    }
    else
    {
        return [NSString stringWithFormat:@"座机:%@", telePhone];
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    if(!_transparentView)
    {
        _searchResultArray = [[NSMutableArray alloc] init];
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;
        
        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self.view addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [_searchBar setShowsCancelButton:YES animated:YES];
    [_tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
    [_tableView setExtraCellLineHidden];
}


//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        
        [_searchResultArray removeAllObjects];
        
        for(JBoCloudAddressBookGroupInfo *info in self.groupInfos)
        {
            for(JBoCloudAddressBookInfo *bookInfo in info.infos)
            {
                if([self pinyin:pinyin match:bookInfo.name])
                {
                    [_searchResultArray addObject:bookInfo];
                }
                
                if([self chinese:content match:bookInfo.name] && ![_searchResultArray containsObject:bookInfo])
                {
                    [_searchResultArray addObject:bookInfo];
                }
            }
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
        [_tableView reloadData];
        [_tableView setExtraCellLineHidden];
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

- (BOOL)pinyin:(NSString*) pinyin match:(NSString*) str
{
    NSString *name = [ChineseToPinyin pinyinFromChiniseString:str];
    if(name.length < pinyin.length)
    {
        return NO;
    }
    
    NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
    if([pinyin isEqualToString:subStr])
    {
        return YES;
    }
    return NO;
}

- (BOOL)chinese:(NSString*) chinese match:(NSString*) str
{
    NSRange range = [str rangeOfString:chinese];
    if(range.length > 0 && range.location != NSNotFound)
    {
        return YES;
    }
    return NO;
}



#pragma mark- sectionHeader

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
    {
        return 1;
    }
    else
    {
        return _groupInfos.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching)
        return 0;
    else
        return _cloudAddressBookHeaderHeight_;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching)
        return nil;
    
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0

            JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:section];
            
            static NSString *headerIdentifier = @"header";
            JBoCloudAddressBookHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
            
            if(header == nil)
            {
                header = [[[JBoCloudAddressBookHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
                header.headerView.delegate = self;
            }
            
            header.headerView.section = section;
            header.headerView.rightIndicateIcon.selected = info.open;
            header.headerView.nameLabel.text = info.groupName;
            header.headerView.countLabel.text = [NSString stringWithFormat:@"%d", (int)info.infos.count];
            
            return header;
#endif
    }
    else
    {

            JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:section];
            
            JBoCloudAddressBookHeaderView *header = [[[JBoCloudAddressBookHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookHeaderHeight_)] autorelease];
            header.delegate = self;
            
            header.section = section;
            header.rightIndicateIcon.selected = info.open;
            header.nameLabel.text = info.groupName;
            header.countLabel.text = [NSString stringWithFormat:@"%d", (int)info.infos.count];
            
            return header;
    }
}

#pragma mark- header 代理

- (void)headerDidCloseAtSection:(NSInteger)section
{
    JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:section];
    info.open = NO;
    
    NSMutableArray *deleteIndexPaths = [[NSMutableArray alloc] initWithCapacity:info.infos.count];
    
    for(NSInteger i = 0;i < info.infos.count;i ++)
    {
        [deleteIndexPaths addObject:[NSIndexPath indexPathForRow:i inSection:section]];
    }
    
    [_tableView beginUpdates];
    [_tableView deleteRowsAtIndexPaths:deleteIndexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
    [deleteIndexPaths release];
}

- (void)headerDidOpenAtSection:(NSInteger)section
{
    JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:section];
    info.open = YES;
    
    NSMutableArray *insertIndexPaths = [[NSMutableArray alloc] initWithCapacity:info.infos.count];
    
    for(NSInteger i = 0;i < info.infos.count;i ++)
    {
        [insertIndexPaths addObject:[NSIndexPath indexPathForRow:i inSection:section]];
    }
    
    [_tableView beginUpdates];
    [_tableView insertRowsAtIndexPaths:insertIndexPaths withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
    [insertIndexPaths release];
}


#pragma mark-tableview代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return _searchResultArray.count;
    }
    else
    {
        JBoCloudAddressBookGroupInfo *info = [_groupInfos objectAtIndex:section];
        NSInteger count = info.open ? info.infos.count : 0;
        return count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:indexPath.section];
    JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:indexPath];
    
    if(info.Id == _cloudAddressBookWebSubmitInfoGroupId_)
    {
        JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:indexPath];
        if(bookInfo.remarkHeight == 0 && ![NSString isEmpty:bookInfo.remark])
        {
            CGSize size = [JBoImageTextTool getStringSize:[bookInfo remarkMsg] withFont:_cloundAddressBookRemarkFont_ andContraintSize:CGSizeMake(_width_ - 50.0 - _cloudAddressBookSyncInterval_ * 3, _maxFloat_)];
            bookInfo.remarkHeight = size.height + 3.0;
        }
        
        CGFloat height = 20.0;
        
        return _cloudAddressBookSyncInterval_ * 2 + height * 2 + 5.0 + MAX(bookInfo.remarkHeight, height);
    }
    else
    {
        if([NSString isEmpty:bookInfo.telePhone])
        {
            return _cloudAddressBookSyncCellHeight_ - 15.0;
        }
        else
        {
            return _cloudAddressBookSyncCellHeight_;
        }
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"_cellDefault";  //联系人
    
    JBoCloudAddressBookSyncCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoCloudAddressBookSyncCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoCloudAddressBookInfo *bookInfo = [self infoForIndexPath:indexPath];
    
    cell.remarkLabel.text = [bookInfo remarkMsg];
    cell.info = bookInfo;
    cell.nameLabel.text = bookInfo.name;
    cell.headImageView.role = bookInfo.role;
    cell.nameLabel.sex = bookInfo.sex;
    
    cell.exist = bookInfo.operation == JBoCloudAddressBookRecordOperationNone;
    cell.headImageView.sex = bookInfo.sex;
    cell.headImageView.headImageURL = bookInfo.imageURL;
    
    if([self.selectedArray containsObject:bookInfo])
    {
        [cell.checkBox checkBoxStateChange:CheckBoxStyleSeclected];
    }
    else
    {
        [cell.checkBox checkBoxStateChange:CheckBoxStyleDefault];
    }
    
    cell.telLabel.text = [self formatTelePhone:bookInfo.telePhone];
    
    cell.phoneNumLabel.text = [self formatPhoneNum:bookInfo.phoneNum];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //进入好友详细信息视图
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    JBoCloudAddressBookSyncCell *cell = (JBoCloudAddressBookSyncCell*)[tableView cellForRowAtIndexPath:indexPath];
    
    if(!cell.checkBox.hidden)
    {
        [cell.checkBox checkBoxStateChange];
    }
}


#pragma mark- JBoCloudAddressBookSyncCell代理

- (void)cloudAddressBookSyncCell:(JBoCloudAddressBookSyncCell *)cell didChangeSelectedState:(BOOL)selected
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    JBoCloudAddressBookInfo *info = [self infoForIndexPath:indexPath];
    
    if(selected)
    {
        [self.selectedArray addObject:info];
    }
    else
    {
        [self.selectedArray removeObject:info];
    }
}

#pragma mark-加载头像

//获取通讯录数据
- (JBoCloudAddressBookInfo*)infoForIndexPath:(NSIndexPath*) indexPath
{
    if(self.searching)
    {
        JBoCloudAddressBookInfo *bookInfo = [_searchResultArray objectAtIndex:indexPath.row];
        return bookInfo;
    }
    else
    {
        JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:indexPath.section];
        JBoCloudAddressBookInfo *bookInfo = [info.infos objectAtIndex:indexPath.row];
        return bookInfo;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
