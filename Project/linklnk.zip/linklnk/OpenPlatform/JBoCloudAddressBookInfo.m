//
//  JBoCloudAddressBookInfo.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookInfo.h"

@implementation JBoCloudAddressBookInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.recordIndex = -1;
        self.operation = JBoCloudAddressBookRecordOperationDefault;
    }
    return self;
}

- (void)dealloc
{
    [_userId release];
    [_imageURL release];
    [_name release];
    [_cloudURL release];
    
    [_phoneNum release];
    [_telePhone release];
    [_remark release];
    [_time release];
    
    [super dealloc];
}

/**显示的备注信息
 */
- (NSString*)remarkMsg
{
    if(![NSString isEmpty:self.remark])
    {
        return [NSString stringWithFormat:@"备注：%@", self.remark];
    }
    else
    {
        return nil;
    }
}

@end
