//
//  JBoOpenPlatformSubscribeCell.m
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformSubscribeCell.h"
#import "JBoBasic.h"

#define _padding_ 10.0

@implementation JBoOpenPlatformSubscribeCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        CGFloat height = (_openPlatformSubscribeCellHeight_ - _padding_ * 2) / 2.0;
        CGFloat width = _width_ - _padding_ * 2;
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, _padding_, width, height)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont boldSystemFontOfSize:17.0];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat timeWidth = 90.0;
        
        _telLabel = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, _nameLabel.bottom, width - timeWidth, height)];
        _telLabel.backgroundColor = [UIColor clearColor];
        _telLabel.textColor = [UIColor blackColor];
        _telLabel.font = [UIFont boldSystemFontOfSize:17.0];
        [self.contentView addSubview:_telLabel];
        
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_width_ - _padding_ - timeWidth, _nameLabel.bottom, timeWidth, height)];
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.textColor = [UIColor grayColor];
        _timeLabel.textAlign = JBoTextAlignmentRight;
        _timeLabel.font = [UIFont systemFontOfSize:11.0];
        [self.contentView addSubview:_timeLabel];
    }
    return self;
}

- (void)dealloc
{
    [_nameLabel release];
    [_telLabel release];
    [_timeLabel release];
    
    [super dealloc];
}

@end
