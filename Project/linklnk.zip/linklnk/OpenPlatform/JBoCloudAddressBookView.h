//
//  JBoCloundAddressBookView.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**云名片夹
 */
@interface JBoCloudAddressBookView : UIView<UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UIActionSheetDelegate>

//导航栏
@property(nonatomic,assign) UINavigationController *navigationController;

/**通讯录分组信息 数组元素是 JBoCloudAddressBookGroupInfo对象
 */
@property(nonatomic,readonly) NSMutableArray *groupArray;

/**是否正在进行网络请求
 */
@property(nonatomic,assign) BOOL isRequesting;

/**导航栏内容是否为黑色 default is 'YES'
 */
@property(nonatomic,assign) BOOL black;

/**取消网络请求
 */
- (void)cancelHttpRequest;

/**重新加载数据
 */
- (void)reloadData;

/**加载数据
 */
- (void)loadData;

@end
