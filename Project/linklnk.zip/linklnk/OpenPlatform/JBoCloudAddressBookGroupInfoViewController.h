//
//  JBoCloudAddressBookGroupInfoViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoCloudAddressBookGroupInfoViewController;
@class JBoCloudAddressBookGroupInfo;

/** 云名片夹分组信息代理
 */
@protocol JBoCloudAddressBookGroupInfoViewControllerDelegate <NSObject>

@optional
/**分组选择完成
 *@param viewController 信息选择控制器
 *@param info 分组信息
 */
- (void)cloudAddressBookGroupInfoViewController:(JBoCloudAddressBookGroupInfoViewController*) viewController didSelectInfo:(JBoCloudAddressBookGroupInfo*) info;

@end

/** 云名片夹分组信息 主要用户联系人的分组选择
 */
@interface JBoCloudAddressBookGroupInfoViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate,UITextFieldDelegate>

/**云名片夹分组信息 数组元素是 JBoCloudAddressBookGroupInfo对象
 */
@property(nonatomic,retain) NSMutableArray *groupInfos;

/**选中的分组信息 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger selectedIndex;

/**要添加到云名片夹的用户
 */
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;


@property(nonatomic,assign) id<JBoCloudAddressBookGroupInfoViewControllerDelegate> delegate;

@end
