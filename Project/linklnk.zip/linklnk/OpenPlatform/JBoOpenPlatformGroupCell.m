//
//  JBoOpenPlatformGroupCell.m
//  linklnk
//
//  Created by kinghe005 on 14-10-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformGroupCell.h"
#import "JBoBasic.h"
#import "JBoWebToolButton.h"

#define _arrowSize_ 10.0

#pragma mark- sectionHeader

#ifdef __IPHONE_6_0

@implementation JBoopenPlatformGroupHeader

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if(self)
    {
        //背景
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _openPlatformGroupHeaderHeight_)];
        bgView.backgroundColor = [UIColor whiteColor];
        self.backgroundView = bgView;
        [bgView release];
        
        _headerView = [[JBoopenPlatformGroupHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _openPlatformGroupHeaderHeight_)];
        _headerView.sectionHeader = self;
        [self.contentView addSubview:_headerView];
    }
    return self;
}

- (void)dealloc
{
    [_headerView release];
    
    [super dealloc];
}

@end

#endif

@implementation JBoopenPlatformGroupHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //背景
        self.backgroundColor = [UIColor whiteColor];
        
        //添加点击手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
        [self addGestureRecognizer:tap];
        [tap release];
        
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_openPlatformGroupCellInterval_, 0, self.width - _openPlatformGroupCellInterval_ * 3, _openPlatformGroupHeaderHeight_)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont boldSystemFontOfSize:17.0];
        [self addSubview:_nameLabel];
        
//        CGFloat lineHeight = _defaultSeparatorLineSize_;
//        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height - lineHeight, _width_, lineHeight)];
//        lineView.backgroundColor = _defaultSeparatorLineColor_;
//        [self addSubview:lineView];
//        [lineView release];
        
    }
    return self;
}

- (void)dealloc
{
    self.sectionHeader = nil;
    self.delegate = nil;

    [_nameLabel release];
    
    [super dealloc];
}

- (void)handleTap:(UITapGestureRecognizer*) tap
{
    [self touchBegan];
    if([self.delegate respondsToSelector:@selector(sectionHeaderDidSelectAtSection:)])
    {
        [self.delegate sectionHeaderDidSelectAtSection:self.section];
    }
    [self touchEnded];
}

@end

#pragma mark- cell

@implementation JBoOpenPlatformGroupCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        UIImageView *accessoryView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"verify_correct"]];
        self.accessoryView = accessoryView;
        [accessoryView release];
        self.accessoryView.hidden = YES;
        
        self.textLabel.font = [UIFont boldSystemFontOfSize:15.0];
        
        self.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
