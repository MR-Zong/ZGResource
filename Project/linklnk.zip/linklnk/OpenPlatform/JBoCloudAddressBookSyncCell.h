//
//  JBoCloudAddressBookSyncCell.h
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoCheckBox.h"
#import "JBoCloudAddressBookInfo.h"

/**云通讯录同步 cell的高度
 */
#define _cloudAddressBookSyncCellHeight_ 85

/**云通讯录同步内容与边框的间隔
 */
#define _cloudAddressBookSyncInterval_ 10.0

/**云通讯录备足信息字体
 */
#define _cloudAddressBookSyncRemarkFont_ [UIFont systemFontOfSize:14.0]

@class JBoCloudAddressBookSyncCell;

@protocol JBoCloudAddressBookSyncCellDelegate <NSObject>

/**选中checkBox
 */
- (void)cloudAddressBookSyncCell:(JBoCloudAddressBookSyncCell*) cell didChangeSelectedState:(BOOL) selected;

@end

/**云通讯录同步到本地的cell
 */
@interface JBoCloudAddressBookSyncCell : UITableViewCell<JBoCheckBoxDelegate>

/**用户头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**用户名称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**手机号码
 */
@property(nonatomic,readonly) UILabel *phoneNumLabel;

/**固话
 */
@property(nonatomic,readonly) UILabel *telLabel;

/**选择框
 */
@property(nonatomic,readonly) JBoCheckBox *checkBox;

/**备注信息
 */
@property(nonatomic,readonly) UILabel *remarkLabel;

/**云通讯录信息
 */
@property(nonatomic,retain) JBoCloudAddressBookInfo *info;

/**联系人是否已存在
 */
@property(nonatomic,assign) BOOL exist;

@property(nonatomic,assign) id<JBoCloudAddressBookSyncCellDelegate> delegate;

@end
