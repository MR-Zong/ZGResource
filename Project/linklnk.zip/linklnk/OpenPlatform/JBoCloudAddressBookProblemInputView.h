//
//  JBoCloudAddressBookProblemInputView.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**云通讯录验证问题信息输入类型
 */
typedef enum _JBoCloudAddressBookProblemInputStyle
{
    JBoCloudAddressBookProblemInputStyleAdd = 0, //新增验证问题
    JBoCloudAddressBookProblemInputStyleModify = 1, //修改验证问题
    JBoCloudAddressBookProblemInputStyleReply = 2, //回答验证问题
}JBoCloudAddressBookProblemInputStyle;


@class JBoCloudAddressBookProblemInputView;
@class SSTextView;

@protocol JBoCloudAddressBookProblemInputDelegate <NSObject>

@optional

/**验证问题信息输入完成 该方法调用时要调用 dismiss方法
 */
- (void)cloudAddressBookProblemInputViewDidFinish:(JBoCloudAddressBookProblemInputView*) inputView;

/**视图关闭
 */
- (void)cloudAddressBookProblemInputViewDidDismiss:(JBoCloudAddressBookProblemInputView*) inputView;

@end

/**云通讯录验证问题输入视图，这里可以 新增验证问题，修改验证问题，回答验证问题
 */
@interface JBoCloudAddressBookProblemInputView : UIScrollView<UITextViewDelegate, UITableViewDelegate, UITableViewDataSource>

/**云通讯录验证问题信息输入类型
 */
@property(nonatomic,readonly) JBoCloudAddressBookProblemInputStyle style;

/**问题输入框
 */
@property(nonatomic,readonly) SSTextView *problemTextView;

/**答案输入框
 */
@property(nonatomic,readonly) SSTextView *answerTextView;

@property(nonatomic,assign) id<JBoCloudAddressBookProblemInputDelegate> inputDelegate;

/**以问题信息初始化
 *@param infos 验证问题信息 可为空 ，数组元素是JBoCloudAddressBookProblemInfo对象
 *@param style 云通讯录验证问题信息输入类型
 *@param superView 将要在的superView
 */
- (id)initWithFrame:(CGRect) frame infos:(NSArray*) infos style:(JBoCloudAddressBookProblemInputStyle) style;

/**显示视图
 */
- (void)showInView:(UIView*) view;

/**关闭视图
 */
- (void)dismiss;

@end
