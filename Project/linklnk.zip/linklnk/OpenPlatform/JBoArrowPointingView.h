//
//  JBoArrowPointView.h
//  linklnk
//
//  Created by kinghe005 on 14-9-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**箭头指向视图
 */
@interface JBoArrowPointingView : UIView

/**是否选中，YES箭头向下，NO箭头向右 default is 'NO'
 */
@property(nonatomic,assign) BOOL selected;

/**箭头颜色 default is '[UIColor blackColor]'
 */
@property(nonatomic,retain) UIColor *fillColor;

@end
