//
//  JBoOpenPlatformReleaseTextInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-10-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformReleaseTextInfo.h"

@implementation JBoOpenPlatformReleaseTextInfo

- (id)init
{
    self = [super init];
    if(self)
    {
//        JBoOpenPlatformTextStyleInfo *textStyleInfo = [[JBoOpenPlatformTextStyleInfo alloc] init];
//        textStyleInfo.bold = NO;
//        textStyleInfo.textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
//        self.textStyleInfo = textStyleInfo;
//        [textStyleInfo release];
        self.textStyleInfos = [NSMutableArray array];
    }
    return self;
}

- (void)dealloc
{
    [_text release];
    [_textStyleInfos release];
    
    [super dealloc];
}

@end
