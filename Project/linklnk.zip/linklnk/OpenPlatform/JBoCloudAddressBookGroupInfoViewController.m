//
//  JBoCloudAddressBookGroupInfoViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookGroupInfoViewController.h"
#import "JBoHttpRequest.h"
#import "JBoCloudAddressBookOperation.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoCloudAddressBookInfo.h"

@interface JBoCloudAddressBookGroupInfoViewController ()<JBoHttpRequestDelegate>

//信息列表
@property(nonatomic,retain) UITableView *tableView;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

//新的分组信息
@property(nonatomic,retain) JBoCloudAddressBookGroupInfo *info;

@end

@implementation JBoCloudAddressBookGroupInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"选择分组";
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        self.selectedIndex = NSNotFound;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_groupInfos release];
    [_tableView release];
    [_httpRequest release];
    
    [_info release];
    
    [_userDetailInfo release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addCloudAddressBookGroupIdentifier_])
    {
        [self alertNetworkMsg:@"添加新分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_getCloudAddressBookGroupIdentifier_])
    {
        [self alertNetworkMsg:@"获取分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_addCloudAddressBookContactIdentifier_])
    {
        [self alertNetworkMsg:@"添加到云名片夹失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addCloudAddressBookGroupIdentifier_])
    {
        BOOL success = [JBoCloudAddressBookOperation addCloudAddressBookGroupResultFromData:data withInfo:self.info];
        if(success)
        {
            [self.groupInfos addObject:self.info];
            self.selectedIndex = self.groupInfos.count - 1;
            
            if([self.delegate respondsToSelector:@selector(cloudAddressBookGroupInfoViewController:didSelectInfo:)])
            {
                [self.delegate cloudAddressBookGroupInfoViewController:self didSelectInfo:self.info];
            }
            else if(self.userDetailInfo)
            {
                [_tableView reloadData];
                [self addNewContact];
            }
                
        }
        else
        {
            [self alertNetworkMsg:@"添加新分组失败"];
        }
        return;
    }
   
    
    if([identifier isEqualToString:_getCloudAddressBookGroupIdentifier_])
    {
        NSMutableArray *array = [JBoCloudAddressBookOperation getCloudAddressBookGroupFromData:data];
        if(array)
        {
            self.groupInfos = array;
            [self loadInitView];
        }
        else
        {
            [self alertNetworkMsg:@"获取分组失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_addCloudAddressBookContactIdentifier_])
    {
        NSDictionary *dic = [JBoCloudAddressBookOperation addCloudAddressBookContactResultFromData:data];
        
        NSObject *object = [[dic allValues] firstObject];
        if([object isKindOfClass:[JBoCloudAddressBookInfo class]])
        {
            [self alertMsg:@"添加到云名片夹成功"];
            
            JBoCloudAddressBookGroupInfo *groupInfo = [self.groupInfos objectAtIndex:self.selectedIndex];
            
            JBoCloudAddressBookInfo *info = (JBoCloudAddressBookInfo*) object;
            
            //发送添加通知
            [[NSNotificationCenter defaultCenter] postNotificationName:_addCloudAddressBookContactNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:groupInfo, _addCloudAddressBookContactGroupInfo_, info, _addCloudAddressBookContactUserInfo_, nil]];
            
            [self performSelector:@selector(back) withObject:nil afterDelay:0.25];
        }
        else
        {
            NSNumber *number = (NSNumber*)object;
            NSInteger code = [number integerValue];
            
            if(code == _addCloudAddressBookContactInfoExist_)
            {
                [self alertMsg:@"您的云名片夹已存在该用户"];
                return;
            }
            else
            {
                [self alertNetworkMsg:@"添加到云名片夹失败"];
            }
        }
    }
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    if(self.groupInfos)
    {
        JBoCloudAddressBookGroupInfo *groupInfo = [self.groupInfos objectAtIndex:self.selectedIndex];
        NSMutableArray *array = [NSMutableArray arrayWithArray:self.groupInfos];
        for(NSInteger i = 0;i < array.count;i ++)
        {
            JBoCloudAddressBookGroupInfo *info = [array objectAtIndex:i];
            if(info.Id == _cloudAddressBookWebSubmitInfoGroupId_)
            {
                [array removeObject:info];
                break;
            }
        }
        
        self.groupInfos = array;
        
        self.selectedIndex = [self.groupInfos indexOfObject:groupInfo];
        [self loadInitView];
    }
    else
    {
        self.isRequesting = YES;
        [self.httpRequest startDataLoading];
        self.httpRequest.identifier = _getCloudAddressBookGroupIdentifier_;
        [self.httpRequest downloadWithURL:[JBoCloudAddressBookOperation getCloudAddressBookGroup]];
    }
}

- (void)loadInitView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
}

#pragma mark- tableView代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
    {
        return 1;
    }
    else
    {
        return self.groupInfos.count;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        
        UIImage *arrow = [UIImage imageNamed:@"arrow.png"];
        UIImage *tick = [UIImage imageNamed:@"verify_correct"];
        
        UIImageView *imageView = [[UIImageView alloc] initWithImage:tick];
        
        imageView.frame = CGRectMake(0, 0, MAX(arrow.size.width, tick.size.width), MAX(arrow.size.height, tick.size.height));
        imageView.contentMode = UIViewContentModeCenter;
        cell.accessoryView = imageView;
        [imageView release];
    }
    
    UIImageView *imageView = (UIImageView*)cell.accessoryView;
    
    if(indexPath.section == 0)
    {
        imageView.image = [UIImage imageNamed:@"arrow.png"];
        cell.textLabel.text = @"添加到新的分组";
    }
    else
    {
        imageView.image = [UIImage imageNamed:@"verify_correct"];
        
        imageView.hidden = self.selectedIndex != indexPath.row;
        
        JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:indexPath.row];
        cell.textLabel.text = info.groupName;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if(self.isRequesting)
        return;
    
    if(indexPath.section == 0)
    {
        [self showAlertViewWithContent:nil title:@"添加新分组"];
    }
    else
    {
        if(indexPath.row == self.selectedIndex)
            return;
        self.selectedIndex = indexPath.row;
        
        JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:indexPath.row];
        if([self.delegate respondsToSelector:@selector(cloudAddressBookGroupInfoViewController:didSelectInfo:)])
        {
            [self.delegate cloudAddressBookGroupInfoViewController:self didSelectInfo:info];
        }
        else if(self.userDetailInfo)
        {
            //添加新联系人
            [self addNewContact];
            [_tableView reloadData];
        }
    }
}

//添加新联系人
- (void)addNewContact
{
    JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:self.selectedIndex];
    
    self.isRequesting = YES;
    [self.httpRequest startDataLoading];
    self.httpRequest.identifier = _addCloudAddressBookContactIdentifier_;
    [self.httpRequest downloadWithURL:[JBoCloudAddressBookOperation addCloudAddressBookContact] dic:[JBoCloudAddressBookOperation addCloudAddressBookContactParamWithGroupId:info.Id userId:self.userDetailInfo.rosterInfo.username]];
}

//显示alertView
- (void)showAlertViewWithContent:(NSString*) content title:(NSString*) title
{
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:title message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    textField.delegate = self;
    textField.placeholder = [NSString stringWithFormat:@"%d个字以内",_inputFormatCloudAddressBookGroupName_];
    textField.text = content;
    [alerView show];
    [alerView release];
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 1 :
        {
            UITextField *textField = [alertView textFieldAtIndex:0];
            
            if([NSString isEmpty:textField.text])
            {
                [self alertMsg:@"分组名称不能为空"];
                return;
            }
            
            if(textField.text.length > _inputFormatCloudAddressBookGroupName_)
            {
                [self alertMsg:[NSString stringWithFormat:@"分组名称不能超过%d个字", _inputFormatCloudAddressBookGroupName_]];
                return;
            }
            
            self.info = [[[JBoCloudAddressBookGroupInfo alloc] init] autorelease];
            self.info.groupName = textField.text;
            
            self.isRequesting = YES;
            _httpRequest.identifier = _addCloudAddressBookGroupIdentifier_;
            [_httpRequest startDataLoading];
            [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation addCloudAddressBookGroup] dic:[JBoCloudAddressBookOperation addCloudAddressBookGroupParamWithName:self.info.groupName]];
        }
            break;
        default:
            break;
    }
}

#pragma mark- textField代理

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (range.location >= _inputFormatCloudAddressBookGroupName_)
        return NO;
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
