//
//  JBoOpenPlatformGroupInfoViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformInfo;
@class JBoOpenPlatformGroupInfoViewController;
@class JBoOpenPlatformGroupInfo;

/**云名片分组信息代理
 */
@protocol JBoOpenPlatformGroupInfoViewControllerDelegate <NSObject>

/**云名片分组信息选择完成
 */
- (void)openPlatformGroupInfoViewController:(JBoOpenPlatformGroupInfoViewController*) viewController didSelectGroupInfo:(JBoOpenPlatformGroupInfo*) info;

@end

/**云名片分组信息，主要用于云名片信息分组选择
 */
@interface JBoOpenPlatformGroupInfoViewController : JBoViewController<UITextFieldDelegate,UIActionSheetDelegate>

/**云名片录分组信息 数组元素是 JBoOpenPlatformGroupInfo对象
 */
@property(nonatomic,retain) NSMutableArray *groupInfos;

/**云名片信息
 */
@property(nonatomic,retain) JBoOpenPlatformInfo *info;

/**选中的云名片分组信息
 */
@property(nonatomic,retain) JBoOpenPlatformGroupInfo *groupInfo;

@property(nonatomic,assign) id<JBoOpenPlatformGroupInfoViewControllerDelegate> delegate;

@end
