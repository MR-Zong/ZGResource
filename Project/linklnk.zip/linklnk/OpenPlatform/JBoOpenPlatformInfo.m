//
//  JBoOpenPlatformInfo.m
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformInfo.h"
#import "JBoImageTextTool.h"
#import "JBoOpenPlatformCell.h"

//图片选择的最大数量
#define _imageOperationMaxCount_ 32

//图片选择器的最大数量
#define _imageSelectorMaxCount_ 3

@implementation JBoOpenPlatformTextInfo

- (id)init
{
    self = [super init];
    if(self)
    {
//        JBoOpenPlatformTextStyleInfo *styleInfo = [[JBoOpenPlatformTextStyleInfo alloc] init];
//        styleInfo.textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
//        self.styleInfo = styleInfo;
//        [styleInfo release];
        self.textStyleInfos = [NSMutableArray array];
        self.range = NSMakeRange(NSNotFound, 0);
        self.imageHeight = NSNotFound;
    }
    
    return self;
}

/**获取富文本内容
 */
- (NSMutableAttributedString*)attributedSring
{
    if([NSString isEmpty:self.content])
        return nil;
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self.content];
    for(JBoOpenPlatformTextStyleInfo *textStyleInfo in self.textStyleInfos)
    {
        NSDictionary *attributes = [textStyleInfo attributesWithContentLength:attributedString.length isCoreText:YES];
        if(attributes)
        {
            [attributedString addAttributes:attributes range:textStyleInfo.textRange];
        }
    }
    
    return [attributedString autorelease];
}

#pragma mark- class method

/**合并两个文本信息
 *@param one 第一个的图片数量将归0
 */
+ (JBoOpenPlatformTextInfo*)combineInfo:(JBoOpenPlatformTextInfo*) one withOther:(JBoOpenPlatformTextInfo*) other
{
    JBoOpenPlatformTextInfo *newTextInfo = [[JBoOpenPlatformTextInfo alloc] init];
    
    NSMutableAttributedString *attributedString1 = [one attributedSring];
    NSMutableAttributedString *attributedString2 = [other attributedSring];
    
    NSAttributedString *attributedString = nil;
    
    if(attributedString1 != nil && attributedString2 != nil)
    {
       [attributedString1 appendAttributedString:attributedString2];
        attributedString = attributedString1;
    }
    else
    {
        if(attributedString1 != nil)
        {
            attributedString = attributedString1;
        }
        else
        {
            attributedString = attributedString2;
        }
    }
    
    newTextInfo.content = attributedString.string;
    newTextInfo.imageCount = other.imageCount;
    newTextInfo.textStyleInfos = [JBoOpenPlatformTextStyleInfo textStyleInfosFromAttributedString:attributedString];
    
    return [newTextInfo autorelease];
}

- (void)dealloc
{
    [_content release];
    [_textStyleInfos release];
    
    [super dealloc];
}

@end

@implementation JBoOpenPlatformImageInfo

- (void)dealloc
{
    [_imageURL release];
    [_thumbnailURL release];
    [_relateURL release];
    
    [super dealloc];
}

/**获取图片路
 */
+ (NSArray*)getImageURLsFromImageInfos:(NSArray *)imageInfos
{
    NSMutableArray *imageURLs = [NSMutableArray arrayWithCapacity:imageInfos.count];
    
    for(JBoOpenPlatformImageInfo *imageInfo in imageInfos)
    {
        if(![NSString isEmpty:imageInfo.imageURL])
        {
            [imageURLs addObject:imageInfo.imageURL];
        }
    }
    return imageURLs;
    
}

/**获取缩略图路径
 */
+ (NSArray*)getThumbnailURLsFromImageInfos:(NSArray *)imageInfos
{
    NSMutableArray *thumbnailURLs = [NSMutableArray arrayWithCapacity:imageInfos.count];
    for(JBoOpenPlatformImageInfo *imageInfo in imageInfos)
    {
        if(![NSString isEmpty:imageInfo.thumbnailURL])
        {
            [thumbnailURLs addObject:imageInfo.thumbnailURL];
        }
    }
    return thumbnailURLs;
}

@end

@implementation JBoOpenPlatformInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.titleHeight = NSNotFound;
        self.contentHeight = NSNotFound;
        
        self.contentInfos = [NSMutableArray array];
        self.imageInfos = [NSMutableArray array];
        
        self.webStyleInfo = [[[JBoOpenPlatformWebStyleInfo alloc] init] autorelease];
        self.groupInfo = [[[JBoOpenPlatformGroupInfo alloc] init] autorelease];
    }
    return self;
}

- (void)dealloc
{
    [_title release];
    [_contentInfos release];
    
    [_imageInfos release];
    [_time release];

    [_webStyleInfo release];

    
    [_url release];
    
    [_infoURL release];
    [_qrCodeImage release];
    [_qrCodeThumbnail release];
    
    [_addrInfo release];
    
    [_groupInfo release];
    
    [super dealloc];
}

#pragma mark- public method

/**从字典中获取云名片信息
 */
- (void)infoFromDictionary:(NSDictionary*) dict
{
    if(dict == nil)
        return;
    
    self.Id = [[dict valueWithKey:_openPlatformId_] longLongValue];
    self.title = [dict objectWithKey:_openPlatformTitle_];
    //info.imageCountAfterTitle = [[dict valueWithKey:_openPlatformImageCountAfterTitle_] integerValue];
    self.time = [dict objectWithKey:_openPlatformTime_];
    self.type = [[dict valueWithKey:_openPlatformType_] integerValue];
    self.visible = [[dict valueWithKey:_openPlatformVisible_] integerValue];
    self.sortId = [[dict valueWithKey:_openPlatformSortId_] doubleValue];
    self.stick = [[dict valueWithKey:_openPlatformStick_] boolValue];
    self.infoURL = [dict objectWithKey:_openPlatformURL_];
    
    NSString *content = [dict objectWithKey:_openPlatformContent_];
    
    switch (self.type)
    {
        case _openPlatformTypeLink_ :
        {
            self.url = content;
            
            NSString *imageStr = [dict objectWithKey:_openPlatformImages_];
            NSString *widthStr = [dict objectWithKey:_openPlatformWidths_];
            NSString *heightStr = [dict objectWithKey:_openPlatformHeights_];
            if(imageStr)
            {
                JBoOpenPlatformImageInfo *imageInfo = [[JBoOpenPlatformImageInfo alloc] init];
                imageInfo.imageURL = [[JBoImageTextTool getImageURLsFromStr:imageStr] firstObject];
                imageInfo.width = [widthStr intValue];
                imageInfo.height = [heightStr intValue];
                [self.imageInfos addObject:imageInfo];
                [imageInfo release];
            }
        }
            break;
        default:
        {
            if(![NSString isEmpty:content])
            {
                NSArray *contents = [content componentsSeparatedByString:_openPlatformContentSeparator_];
                NSArray *imageCounts = [[dict objectWithKey:_openPlatformImageCountAfterText_] componentsSeparatedByString:_openPlatformSeprator_];
                NSArray *fonts = [[dict objectWithKey:_openPlatformContentFontStyle_] componentsSeparatedByString:_openPlatformSeprator_];
                NSArray *fontSizes = [[dict objectWithKey:_openPlatformContentFontSize_] componentsSeparatedByString:_openPlatformSeprator_];
                NSArray *colors = [[dict objectWithKey:_openPlatformContentTextColor_] componentsSeparatedByString:_openPlatformSeprator_];
                NSArray *ranges = [[dict objectWithKey:_openPlatformContentStyleRange_] componentsSeparatedByString:_openPlatformSeprator_];
                
                for(NSInteger i = 0;i < contents.count;i ++)
                {
                    JBoOpenPlatformTextInfo *textInfo = [[JBoOpenPlatformTextInfo alloc] init];
                    textInfo.content = [contents objectAtIndex:i];
                    
                    if(i < imageCounts.count)
                    {
                        textInfo.imageCount = [[imageCounts objectAtIndex:i] intValue];
                    }
                    
                    
                    if(i < fonts.count && i < colors.count && i < ranges.count && i < fontSizes.count)
                    {
                        NSString *fontStr = [fonts objectAtIndex:i];
                        NSString *colorStr = [colors objectAtIndex:i];
                        NSString *rangeStr = [ranges objectAtIndex:i];
                        NSString *fontSizeStr = [fontSizes objectAtIndex:i];
                        
                        NSArray *fontStrs = [fontStr componentsSeparatedByString:_openPlatformTextStyleSeprator_];
                        NSArray *fontSizeStrs = [fontSizeStr componentsSeparatedByString:_openPlatformTextStyleSeprator_];
                        NSArray *colorStrs = [colorStr componentsSeparatedByString:_openPlatformTextStyleSeprator_];
                        NSArray *rangeStrs = [rangeStr componentsSeparatedByString:_openPlatformTextStyleSeprator_];
                        
                        for(NSInteger j = 0;j < fontStrs.count && j < colorStrs.count && j < rangeStrs.count && j < fontSizeStrs.count;j ++)
                        {
                            JBoOpenPlatformTextStyleInfo *textStyleInfo = [[JBoOpenPlatformTextStyleInfo alloc] init];
                            textStyleInfo.bold = [[fontStrs objectAtIndex:j] boolValue];
                            textStyleInfo.fontSize = [[fontSizeStrs objectAtIndex:j] intValue];
                            
                            UIColor *color = [UIColor colorFromHexadecimal:[colorStrs objectAtIndex:j]];
                            if(color != nil)
                            {
                                textStyleInfo.textColor = color;
                            }
                            
                            NSString *range = [rangeStrs objectAtIndex:j];
                            textStyleInfo.textRange = [JBoOpenPlatformTextStyleInfo rangeFromString:range];
                            
                            [textInfo.textStyleInfos addObject:textStyleInfo];
                            [textStyleInfo release];
                        }
                    }
                    
                    [self.contentInfos addObject:textInfo];
                    [textInfo release];
                }
            }
            
            //图片信息
            NSString *imageStr = [dict objectWithKey:_openPlatformImages_];
            NSString *thumbnailStr = [dict objectWithKey:_openPlatformThumbnails_];
            NSString *widthStr = [dict objectWithKey:_openPlatformWidths_];
            NSString *heightStr = [dict objectWithKey:_openPlatformHeights_];
            NSString *cloudURlStr = [dict objectWithKey:_openPlatformLinks_];
            
            NSArray *images = [JBoImageTextTool getImageURLsFromStr:imageStr];
            NSArray *thumbnails = [JBoImageTextTool getImageURLsFromStr:thumbnailStr];
            NSArray *widths = [widthStr componentsSeparatedByString:_openPlatformSeprator_];
            NSArray *heights = [heightStr componentsSeparatedByString:_openPlatformSeprator_];
            NSArray *cloudURLs = [cloudURlStr componentsSeparatedByString:_openPlatformSeprator_];
            
            if(images.count > 0)
            {
                NSMutableArray *imageInfos = [NSMutableArray arrayWithCapacity:images.count];
                for(NSInteger i = 0;i < images.count && i < thumbnails.count && i < widths.count && i < heights.count && i < cloudURLs.count; i++)
                {
                    JBoOpenPlatformImageInfo *imageInfo = [[JBoOpenPlatformImageInfo alloc] init];
                    imageInfo.imageURL = [images objectAtIndex:i];
                    imageInfo.thumbnailURL = [thumbnails objectAtIndex:i];
                    imageInfo.width = [[widths objectAtIndex:i] intValue];
                    imageInfo.height = [[heights objectAtIndex:i] intValue];
                    
                    NSString *relateURL = [cloudURLs objectAtIndex:i];
                    
                    if(![NSString isEmpty:relateURL] && ![relateURL isEqualToString:_openPlatformLineEmptyValue_])
                    {
                        imageInfo.relateURL = relateURL;
                    }
                    
                    [imageInfos addObject:imageInfo];
                    [imageInfo release];
                }
                self.imageInfos = imageInfos;
            }
            
            if(self.type == _openPlatformTypeMall_)
            {
                self.price = [[dict valueWithKey:_openPlatformPrice_] floatValue];
            }
        }
            break;
    }
    
    self.webStyleInfo.Id = [[dict valueWithKey:_openPlatformWebStyleId_] longLongValue];
    self.webStyleInfo.name = [dict objectWithKey:_openPlatformWebStyleName_];
    
    //地址信息
    NSString *addr = [dict objectWithKey:_openPlatformAddr_];
    if(addr)
    {
        JBoMapInfo *mapInfo = [[JBoMapInfo alloc] init];
        mapInfo.coordinate = CLLocationCoordinate2DMake([[dict valueWithKey:_openPlatformLat_] doubleValue], [[dict valueWithKey:_openPlatformLon_] doubleValue]);
        [mapInfo setAddr:addr];
        self.addrInfo = mapInfo;
        [mapInfo release];
    }
    
    if([dict valueWithKey:_openPlatformGroupSecondaryId_])
    {
        JBoOpenPlatformGroupInfo *groupInfo = [[JBoOpenPlatformGroupInfo alloc] init];
        groupInfo.Id = [[dict valueWithKey:_openPlatformGroupSecondaryId_] longLongValue];
        groupInfo.name = [dict objectWithKey:_openPlatformGroupSecondaryName_];
        
        groupInfo.superId = [[dict valueWithKey:_openPlatformGroupStairId_] longLongValue];
        groupInfo.superName = [dict objectWithKey:_openPlatformGroupStairName_];
        
        self.groupInfo = groupInfo;
        [groupInfo release];
    }
    
    if(self.imageInfos.count > 0 && self.contentInfos.count == 0)
    {
        JBoOpenPlatformTextInfo *textInfo = [[JBoOpenPlatformTextInfo alloc] init];
        textInfo.content = @"";
        textInfo.imageCount = (int)self.imageInfos.count;
        [self.contentInfos addObject:textInfo];
        [textInfo release];
    }
}

/**价格字符串
 */
- (NSString*)priceString
{
    return [NSString stringWithFormat:@"价格：￥%0.2f", _price];
}

/**根据图片下标获取所属文本
 *@param imageIndex 在所有图片中的下标
 *@param index 在所属文本中的图片的下标
 *@return 所属文本下标
 */
- (NSInteger)textIndexFromImageIndex:(NSInteger) imageIndex index:(NSInteger *)index;
{
    NSInteger idex = imageIndex;
    NSInteger position = 0;
        
    for(NSInteger i = 0;i < self.contentInfos.count;i ++)
    {
        JBoOpenPlatformTextInfo *info = [self.contentInfos objectAtIndex:i];
        if(idex < info.imageCount)
        {
            position += i;
            break;
        }
        else
        {
            if(i == self.contentInfos.count - 1)
            {
                position += i;
            }
            else
            {
                idex -= info.imageCount;
            }
        }
    }
    
    if(index != nil)
    {
        *index = idex;
    }
    
    return position;
}

/**通过文本下标获取图片起始位置
 *@param textIndex 文本下标
 *@return 在所有图片中的下标
 */
- (NSInteger)imageIndexFromTextIndex:(NSInteger) textIndex
{
    NSInteger imageIndex = 0;
    for(NSInteger i = 0;i < textIndex && i < self.contentInfos.count;i ++)
    {
        JBoOpenPlatformTextInfo *info = [self.contentInfos objectAtIndex:i];
        imageIndex += info.imageCount;
    }
    return MIN(self.imageInfos.count, imageIndex);
}

/**是否允许添加图片
 *@return 可上传的图片数量
 */
- (NSInteger)canUploadImageCount;
{
    NSInteger count =  _imageOperationMaxCount_ - self.imageInfos.count;
    if(count > 0)
    {
        return MAX(count, _imageOperationMaxCount_);
    }
    else
    {
        return 0;
    }
}

/**是否允许添加文字
 *@return 可上传的添加文字的数量
 */
- (int)canAddTextCount
{
    int count = 0;
    for(JBoOpenPlatformTextInfo *info in self.contentInfos)
    {
        count += info.content.length;
    }
    
    return MAX(_inputFormatOpenplatformTextNum_ - count, 0);
}

/**计算标题高度
 */
- (void)caculateTitleHeight
{
    if([NSString isEmpty:self.title])
    {
        self.titleHeight = 0;
    }
    else
    {
        CGSize size = [JBoImageTextTool getStringSize:self.title withFont:_openPlatformTitleFont_ andContraintSize:CGSizeMake(_openPlatformImageWitdh_, _maxFloat_)];
        size.height += 5.0;
        self.titleHeight = MAX(size.height, _openPlatfromTitleHeight_);
    }
}

/**计算地址高度
 */
- (void)caculateAddrHeight
{
    if(self.addrInfo)
    {
        CGSize addrSize = [JBoImageTextTool getStringSize:[self.addrInfo addr] withFont:_openPlatformAddressFont_ andContraintSize:CGSizeMake(_openPlatformAddressWitdh_, _maxFloat_)];
        self.addrHeight = MAX(ceilf(addrSize.height), _openPlatformAddressMinHeight_);
    }
    else
    {
        self.addrHeight = _openPlatformDateButtonHeight_;
    }
}

/**是否可以添加文字
 */
- (BOOL)canAddTextInfo
{
    BOOL canAddText = NO;
    //判断是否可以添加文字
    if(self.contentInfos.count <= 1)
    {
        if(self.contentInfos.count == 0)
        {
            canAddText = YES;
        }
        else
        {
            JBoOpenPlatformTextInfo *textInfo = [self.contentInfos firstObject];
            if([NSString isEmpty:textInfo.content] && textInfo.content.length <=1)
            {
                canAddText = YES;
            }
        }
    }
    return canAddText;
}

#pragma mark- class method

/**获取文本参数
 *@param textInfos 数组元素是JBoOpenPlatformTextInfo对象
 *@return 上传和修改所需的文本参数 ，文本内容，样式
 */
+ (NSDictionary*)textParamFromTextInfos:(NSArray*) textInfos
{
    NSMutableDictionary *retDic = [NSMutableDictionary dictionaryWithCapacity:6];
    
    NSMutableString *content = [NSMutableString string];
    NSMutableString *imageCount = [NSMutableString string];
    NSMutableString *color = [NSMutableString string];
    NSMutableString *font = [NSMutableString string];
    NSMutableString *fontSize = [NSMutableString string];
    NSMutableString *range = [NSMutableString string];
    
    NSString *separator = _openPlatformContentSeparator_;
    NSString *separator2 = _openPlatformSeprator_;
    
    for(JBoOpenPlatformTextInfo *info in textInfos)
    {
        NSString *text = info.content;
        
        if(text != nil)
        {
            [content appendFormat:@"%@%@", text, separator];
            [imageCount appendFormat:@"%d%@", info.imageCount, separator2];
            [JBoOpenPlatformTextStyleInfo resetWithTextStyleInfos:info.textStyleInfos textLength:text.length];
            [JBoOpenPlatformTextStyleInfo sortTextStyleInfos:info.textStyleInfos];
            
            for(NSInteger i = 0;i < info.textStyleInfos.count;i ++)
            {
                JBoOpenPlatformTextStyleInfo *textStyleInfo = [info.textStyleInfos objectAtIndex:i];
                
                NSString *sep = i == info.textStyleInfos.count - 1 ? separator2 : _openPlatformTextStyleSeprator_;
                
                [color appendFormat:@"%@%@", [textStyleInfo.textColor hexadecimalValue], sep];
                [font appendFormat:@"%d%@", textStyleInfo.bold, sep];
                [fontSize appendFormat:@"%d%@", textStyleInfo.fontSize, sep];
                [range appendFormat:@"%@%@", [textStyleInfo stringRange], sep];
            }
            
            if(info.textStyleInfos.count == 0)
            {
                [color appendFormat:@"000000%@", separator2];
                [font appendFormat:@"0%@", separator2];
                [fontSize appendFormat:@"%d%@", _openPlatformTextFontSize_, separator2];
                [range appendFormat:@"0,0%@", separator2];
            }
        }
    }
    
    
    [color removeLastCharacter];
    [font removeLastCharacter];
    [fontSize removeLastCharacter];
    [range removeLastCharacter];
    
    [content removeLastStringWithString:separator];
    [imageCount removeLastCharacter];
    
    [retDic setObject:color forKey:_openPlatformContentTextColor_];
    [retDic setObject:font forKey:_openPlatformContentFontStyle_];
    [retDic setObject:fontSize forKey:_openPlatformContentFontSize_];
    [retDic setObject:range forKey:_openPlatformContentStyleRange_];
    [retDic setObject:content forKey:_openPlatformContent_];
    [retDic setObject:imageCount forKey:_openPlatformImageCountAfterText_];
    
    return retDic;
}

/**获取图片信息参数
 *@param imageInfos 数组元素是JBoOpenPlatformTextInfo
 *@return 图片关联的链接 高度 宽度 图片路径 缩略图路径
 */
+ (NSDictionary*)imageParamFromImageInfos:(NSArray*) imageInfos
{
    NSMutableDictionary *retDic = [NSMutableDictionary dictionaryWithCapacity:6];
    
    NSMutableString *imageURL = [NSMutableString string];
    NSMutableString *thumbnailURL = [NSMutableString string];
    NSMutableString *relateURL = [NSMutableString string];
    NSMutableString *width = [NSMutableString string];
    NSMutableString *height = [NSMutableString string];

    NSString *separator = _openPlatformSeprator_;
    
    for(JBoOpenPlatformImageInfo *info in imageInfos)
    {
        NSString *relateURLStr = info.relateURL;
        if([NSString isEmpty:relateURLStr])
            relateURLStr = _openPlatformLineEmptyValue_;
        
        if(![NSString isEmpty:info.imageURL])
        {
            [imageURL appendFormat:@"%@%@", info.imageURL, separator];
        }
        
        if(![NSString isEmpty:info.thumbnailURL])
        {
            [thumbnailURL appendFormat:@"%@%@", info.thumbnailURL, separator];
        }
        
        [relateURL appendFormat:@"%@%@", relateURLStr, separator];
        [width appendFormat:@"%d%@", info.width, separator];
        [height appendFormat:@"%d%@",info.height, separator];
    }
    
    [imageURL removeLastCharacter];
    [thumbnailURL removeLastCharacter];
    [relateURL removeLastCharacter];
    [width removeLastCharacter];
    [height removeLastStringWithString:separator];
    
    [retDic setObject:imageURL forKey:_openPlatformImages_];
    [retDic setObject:thumbnailURL forKey:_openPlatformThumbnails_];
    [retDic setObject:relateURL forKey:_openPlatformLinks_];
    [retDic setObject:width forKey:_openPlatformWidths_];
    [retDic setObject:height forKey:_openPlatformHeights_];
    
    return retDic;
}

/**合并没有文本内容但有图片的数据 , 或有文本但没有图片的数据
 *@param textInfos 要合并的文本数据 数组元素是JBoOpenPlatformTextInfo
 */
+ (void)combineTextInfos:(NSMutableArray*) textInfos
{
    if(textInfos.count < 2)
        return;
    NSInteger index = 1;
    while (index < textInfos.count)
    {
        JBoOpenPlatformTextInfo *info = [textInfos objectAtIndex:index];
        JBoOpenPlatformTextInfo *previousInfo = [textInfos objectAtIndex:index - 1];
        
        //没有文本内容
        if(info.content.length < 2 && [NSString isEmpty:info.content])
        {
            previousInfo.imageCount += info.imageCount;
            [textInfos removeObjectAtIndex:index];
            continue;
        }
        
        index ++;
    }
    
    index = 0;
    while (index < textInfos.count - 1)
    {
        JBoOpenPlatformTextInfo *info = [textInfos objectAtIndex:index];
        JBoOpenPlatformTextInfo *nextInfo = [textInfos objectAtIndex:index + 1];
        
        //没有图片
        if(info.imageCount == 0)
        {
            nextInfo.content = [info.content stringByAppendingString:nextInfo.content];
            [textInfos removeObjectAtIndex:index];
            continue;
        }
        
        index ++;
    }
}

@end
