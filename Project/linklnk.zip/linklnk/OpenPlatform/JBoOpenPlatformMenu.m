//
//  JBoOpenPlatformMenu.m
//  linklnk
//
//  Created by kinghe005 on 14-10-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformMenu.h"

@implementation JBoOpenPlatformMenu

/**构造方法
 *@param origin 视图的位置
 *@param size 按钮的大小
 *@param type 云名片操作类型
 *@return 一个根据按钮大小生成的 view
 */
- (id)initWithOrigin:(CGPoint)origin ItemSize:(CGSize)size operationType:(JBoOpenPlatformOperationType)type
{
    CGFloat width = size.width;
    CGFloat height = size.height;
    
    CGFloat rows = 0;
    switch (type)
    {
        case JBoOpenPlatformOperationTypeDefault :
        {
            rows = 2;
        }
            break;
        case JBoOpenPlatformOperationTypeScene :
        {
            rows = 1;
        }
            break;
        default:
            break;
    }
    
    self = [super initWithFrame:CGRectMake(origin.x, origin.y, width * 3, height * rows)];
    if(self)
    {
        _operationType = type;
        self.backgroundColor = [UIColor clearColor];
        
        switch (_operationType)
        {
            case JBoOpenPlatformOperationTypeDefault :
            {
                _stickButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _stickButton.backgroundColor = [UIColor clearColor];
                [_stickButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _stickButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_stickButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                _stickButton.adjustsImageWhenHighlighted = NO;
                
                [_stickButton setTitle:@"置顶" forState:UIControlStateNormal];
                [_stickButton setImage:[UIImage imageNamed:@"stick_icon.png"] forState:UIControlStateNormal];
                [_stickButton setTitle:@"取消置顶" forState:UIControlStateSelected];
                
                [_stickButton setFrame:CGRectMake(0, 0, width, height)];
                [self addSubview:_stickButton];
                
                _visibleButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _visibleButton.backgroundColor = [UIColor clearColor];
                [_visibleButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _visibleButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_visibleButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                _visibleButton.adjustsImageWhenHighlighted = NO;
                
                [_visibleButton setTitle:@"隐藏" forState:UIControlStateNormal];
                [_visibleButton setImage:[UIImage imageNamed:@"private_icon.png"] forState:UIControlStateNormal];
                [_visibleButton setTitle:@"公开" forState:UIControlStateSelected];
                [_visibleButton setImage:[UIImage imageNamed:@"public_icon.png"] forState:UIControlStateSelected];
                
                [_visibleButton setFrame:CGRectMake(_stickButton.right, 0, width, height)];
                [self addSubview:_visibleButton];
                
                _deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _deleteButton.backgroundColor = [UIColor clearColor];
                [_deleteButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _deleteButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_deleteButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                [_deleteButton setImage:[UIImage imageNamed:@"delete_icon.png"] forState:UIControlStateNormal];
                _deleteButton.adjustsImageWhenHighlighted = NO;
                [_deleteButton setTitle:@"删除" forState:UIControlStateNormal];
                [_deleteButton setFrame:CGRectMake(_visibleButton.right, 0, width, height)];
                
                [self addSubview:_deleteButton];
                
                _subscribeButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _subscribeButton.backgroundColor = [UIColor clearColor];
                [_subscribeButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _subscribeButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_subscribeButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                _subscribeButton.adjustsImageWhenHighlighted = NO;
                
                [_subscribeButton setTitle:@"预约的人" forState:UIControlStateNormal];
                [_subscribeButton setImage:[UIImage imageNamed:@"sign_up"] forState:UIControlStateNormal];
                
                [_subscribeButton setFrame:CGRectMake(_stickButton.left, _visibleButton.bottom, width, height)];
                
                [self addSubview:_subscribeButton];
                
                _updateOrderButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _updateOrderButton.backgroundColor = [UIColor clearColor];
                [_updateOrderButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _updateOrderButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_updateOrderButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                _updateOrderButton.adjustsImageWhenHighlighted = NO;
                
                [_updateOrderButton setTitle:@"更新至首位" forState:UIControlStateNormal];
                [_updateOrderButton setImage:[UIImage imageNamed:@"order_icon"] forState:UIControlStateNormal];
                
                [_updateOrderButton setFrame:CGRectMake(_visibleButton.left, _visibleButton.bottom, width, height)];
                
                [self addSubview:_updateOrderButton];
                
                _moveButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _moveButton.backgroundColor = [UIColor clearColor];
                [_moveButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _moveButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_moveButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                _moveButton.adjustsImageWhenHighlighted = NO;
                
                [_moveButton setTitle:@"移动位置" forState:UIControlStateNormal];
                [_moveButton setImage:[UIImage imageNamed:@"moveOrder_icon"] forState:UIControlStateNormal];
                [_moveButton setTitle:@"取消" forState:UIControlStateSelected];
                
                [_moveButton setFrame:CGRectMake(_deleteButton.left, _deleteButton.bottom, width, height)];
                
                [self addSubview:_moveButton];
            }
                break;
            case JBoOpenPlatformOperationTypeScene :
            {
                _selectedButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _selectedButton.backgroundColor = [UIColor clearColor];
                [_selectedButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _selectedButton.titleLabel.font = [UIFont systemFontOfSize:10.0];
                [_selectedButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                _selectedButton.adjustsImageWhenHighlighted = NO;
                
                [_selectedButton setTitle:@"关联" forState:UIControlStateNormal];
                [_selectedButton setImage:[UIImage imageNamed:@"relate_circle_icon.png"] forState:UIControlStateNormal];
                [_selectedButton setTitle:@"取消关联" forState:UIControlStateSelected];
                
                [_selectedButton setFrame:CGRectMake(self.width - width, 0, width, height)];
                
                [self addSubview:_selectedButton];
            }
                break;
            default:
                break;
        }
    }
    
    return self;
}

@end
