//
//  JBoCloudUsersViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-8-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudUsersViewController.h"
#import "JBoAddContactViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoAssociatedUsersView.h"
#import "JBoUserOperation.h"
#import "JBoCloudAddressBookView.h"

//搜索栏高度
#define _searchBarHeight_ 40

@interface JBoCloudUsersViewController ()

//以前选择的seg
@property(nonatomic,assign) NSInteger preSelectedIndex;

//云名片夹
@property(nonatomic,retain) JBoCloudAddressBookView *cloudAddressBookView;

@end

@implementation JBoCloudUsersViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.black = YES;
        self.title = @"云名片夹";
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoCloudUsersViewController dealloc");

    [_cloudAddressBookView release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    self.navigationController.navigationBar.translucent = NO;
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
    
    [self.cloudAddressBookView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

#pragma mark-加载视图

- (void)addContactBarButtonItemAction
{
    JBoAddContactViewController *addContactVC = [[JBoAddContactViewController alloc] init];
    addContactVC.black = self.black;
    [self.navigationController pushViewController:addContactVC animated:YES];
    [addContactVC release];
}

- (void)back
{
    [self.cloudAddressBookView cancelHttpRequest];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //设置返回按钮
    UIImage *image = nil;
    if(self.black)
    {
        image = [UIImage imageNamed:@"newsBact.png"];
        
    }
    else
    {
        image = [UIImage imageNamed:_navigationBarBackItemImage_];
    }
    
    CGFloat width = image.size.width + 8.0;
    
    [JBoNavigatioinBarOperation setLeftItemWithTarget:self action:@selector(back) image:image width:width height:image.size.height];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    //加载视图
    [self loadInitView];
}

//加载视图
- (void)loadInitView
{
    //创建导航条右边的按钮
    [self setRightBarItemWithButtonType:JBoWebToolButtonTypeAdd action:@selector(addContactBarButtonItemAction)];
    
    JBoCloudAddressBookView *cloudAddreessBookView = [[JBoCloudAddressBookView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    cloudAddreessBookView.black = self.black;
    cloudAddreessBookView.navigationController = self.navigationController;
    [self.view addSubview:cloudAddreessBookView];
    self.cloudAddressBookView = cloudAddreessBookView;
    [cloudAddreessBookView release];
    
    [self.cloudAddressBookView loadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
