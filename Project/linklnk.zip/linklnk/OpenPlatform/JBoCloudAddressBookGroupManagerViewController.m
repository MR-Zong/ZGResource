//
//  JBoCloudAddressBookGroupManagerViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookGroupManagerViewController.h"
#import "JBoWebToolButton.h"
#import "JBoCloudAddressBookOperation.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoHttpRequest.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoUserOperation.h"

@interface JBoCloudAddressBookGroupManagerViewController ()<JBoHttpRequestDelegate>

//信息列表
@property(nonatomic,retain) UITableView *tableView;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在请求
@property(nonatomic,assign) BOOL isRequesting;

//选中的cell
@property(nonatomic,retain) NSIndexPath *selectedIndexPath;

//新的分组信息
@property(nonatomic,retain) JBoCloudAddressBookGroupInfo *info;

@end

@implementation JBoCloudAddressBookGroupManagerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
        self.title = @"分组管理";
        
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_infoArray release];
    [_tableView release];
    
    [_httpRequest release];
    [_selectedIndexPath release];
    
    [_info release];
    
    [super dealloc];
}

#pragma mark- http 

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addCloudAddressBookGroupIdentifier_])
    {
        [self alertNetworkMsg:@"添加分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeCloudAddressBookGroupIdentifier_])
    {
        [self alertNetworkMsg:@"删除分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_updateCloudAddressBookGroupIdentifier_])
    {
        [self alertNetworkMsg:@"修改分组名称"];
        return;
    }
    
    self.selectedIndexPath = nil;
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_addCloudAddressBookGroupIdentifier_])
    {
        BOOL success = [JBoCloudAddressBookOperation addCloudAddressBookGroupResultFromData:data withInfo:self.info];
        if(success)
        {
            [self alertMsg:@"添加分组成功"];
            [self.infoArray addObject:self.info];
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.infoArray.count - 1 inSection:0];
            [_tableView beginUpdates];
            [_tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        else
        {
            [self alertNetworkMsg:@"添加分组失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_updateCloudAddressBookGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
            info.groupName = self.info.groupName;
            
            [_tableView beginUpdates];
            [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        else
        {
             [self alertNetworkMsg:@"修改分组名称"];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeCloudAddressBookGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
            
            //把相关数据移动到默认分组
            for(JBoCloudAddressBookGroupInfo *groupInfo in self.infoArray)
            {
                if(groupInfo.Id == _cloudAddressBookGroupDefaultId_)
                {
                    [groupInfo.infos addObjectsFromArray:info.infos];
                    break;
                }
            }
            
            [self.infoArray removeObjectAtIndex:self.selectedIndexPath.row];
            
            [_tableView beginUpdates];
            [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        else
        {
            [self alertNetworkMsg:@"删除分组失败"];
        }
        return;
    }
    
    self.selectedIndexPath = nil;
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 60.0)];
    
    //创建添加按钮
    CGFloat size = 25.0;
    JBoWebToolButton *btn = [[JBoWebToolButton alloc] initWithFrame:CGRectMake(15.0, (header.height - size) / 2.0, size, size) buttonType:JBoWebToolButtonTypeAdd];
    btn.lineColor = [UIColor blackColor];
//    btn.layer.borderWidth = btn.lineWidth;
//    btn.layer.borderColor = btn.lineColor.CGColor;
//    btn.layer.cornerRadius = 3.0;
    btn.layer.masksToBounds = YES;
    [btn addTarget:self action:@selector(addGroup:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:btn];
    [btn release];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundColor:[UIColor clearColor]];
    [button setFrame:CGRectMake(btn.right + 10.0, 0, 130.0, header.height)];
    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    [button setTitleColor:btn.lineColor forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:15.0];
    [button setTitle:@"添加分组" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(addGroup:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:button];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.tableHeaderView = header;
    [header release];
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
}

#pragma mark- private method

- (void)addGroup:(id) sender
{
    [self showAlertViewWithContent:nil title:@"添加分组"];
}

#pragma mark- tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = info.groupName;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    if(info.Id == _cloudAddressBookGroupDefaultId_ || info.Id == _cloudAddressBookWebSubmitInfoGroupId_)
        return;
    
    if(self.isRequesting)
        return;
    self.selectedIndexPath = indexPath;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"删除分组不会删除该分组内的联系人" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"修改分组名称", @"删除", nil];
    actionSheet.destructiveButtonIndex = 1;
    [actionSheet showInView:self.view];
    [actionSheet release];
}

#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0 :
        {
            NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
            JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
            [self showAlertViewWithContent:info.groupName title:title];
        }
            break;
        case 1 :
        {
            self.isRequesting = YES;
            
            JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
            _httpRequest.identifier = _removeCloudAddressBookGroupIdentifier_;
            [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation removeCloudAddressBookGroup] dic:[JBoCloudAddressBookOperation removeCloudAddressBookGroupParamWithId:info.Id]];
        }
            break;
        default:
        {
            self.selectedIndexPath = nil;
        }
            break;
    }
}

//显示alertView
- (void)showAlertViewWithContent:(NSString*) content title:(NSString*) title
{
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:title message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    textField.delegate = self;
    textField.placeholder = [NSString stringWithFormat:@"%d个字以内",_inputFormatCloudAddressBookGroupName_];
    textField.text = content;
    [alerView show];
    [alerView release];
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0 :
        {
            self.selectedIndexPath = nil;
        }
            break;
        case 1 :
        {
            UITextField *textField = [alertView textFieldAtIndex:0];
            
            if([NSString isEmpty:textField.text])
            {
                [self alertMsg:@"分组名称不能为空"];
                return;
            }
            
            if(textField.text.length > _inputFormatCloudAddressBookGroupName_)
            {
                [self alertMsg:[NSString stringWithFormat:@"分组名称不能超过%d个字", _inputFormatCloudAddressBookGroupName_]];
                return;
            }
            
            self.info = [[[JBoCloudAddressBookGroupInfo alloc] init] autorelease];
            self.info.groupName = textField.text;
            self.isRequesting = YES;
            
            if(self.selectedIndexPath != nil)
            {
                //更新分组名
                JBoCloudAddressBookGroupInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
                if(![info.groupName isEqualToString:self.info.groupName])
                {
                    _httpRequest.identifier = _updateCloudAddressBookGroupIdentifier_;
                    [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation updateCloudAddressBookGroup] dic:[JBoCloudAddressBookOperation updateCloudAddressBookGroupParamWithId:info.Id name:self.info.groupName]];
                }
                else
                {
                    self.selectedIndexPath = nil;
                    self.isRequesting= NO;
                    self.info = nil;
                }
            }
            else
            {
                //添加分组名
                _httpRequest.identifier = _addCloudAddressBookGroupIdentifier_;
                [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation addCloudAddressBookGroup] dic:[JBoCloudAddressBookOperation addCloudAddressBookGroupParamWithName:self.info.groupName]];
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark- textField代理

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (range.location >= _inputFormatCloudAddressBookGroupName_)
        return NO;
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
