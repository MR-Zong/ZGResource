//
//  JBoOpenPlatformInfo.h
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoOpenPlatformWebStyleInfo.h"
#import "JBoOpenPlatformTextStyleInfo.h"
#import "JBoMapInfo.h"
#import "JBoOpenPlatformGroupInfo.h"

/**云名片文本信息
 */
@interface JBoOpenPlatformTextInfo : NSObject

/**文本内容
 */
@property(nonatomic,copy) NSString *content;

/**文本高度
 */
@property(nonatomic,assign) NSInteger contentHeight;

/**文本后面的图片数量
 */
@property(nonatomic,assign) int imageCount;

/**图片高度 default is 'NSNotfound'
 */
@property(nonatomic,assign) NSInteger imageHeight;

/**文本样式 数组元素是 JBoOpenPlatformTextStyleInfo对象
 */
@property(nonatomic,retain) NSMutableArray *textStyleInfos;

/**在所有文本中的范围
 */
@property(nonatomic,assign) NSRange range;

/**获取富文本内容
 */
- (NSMutableAttributedString*)attributedSring;

#pragma mark- class method

/**合并两个文本信息
 *@param one 第一个的图片数量将归0
 */
+ (JBoOpenPlatformTextInfo*)combineInfo:(JBoOpenPlatformTextInfo*) one withOther:(JBoOpenPlatformTextInfo*) other;

@end

/**云名片图片信息
 */
@interface JBoOpenPlatformImageInfo : NSObject

/**图片原图路径
 */
@property(nonatomic,copy) NSString *imageURL;

/**图片缩略图路径
 */
@property(nonatomic,copy) NSString *thumbnailURL;

/**图片关联的链接
 */
@property(nonatomic,copy) NSString *relateURL;

/**图片高度
 */
@property(nonatomic,assign) int height;

/**图片宽度
 */
@property(nonatomic,assign) int width;

#pragma mark- class method

/**获取图片路
 */
+ (NSArray*)getImageURLsFromImageInfos:(NSArray*) imageInfos;

/**获取缩略图路径
 */
+ (NSArray*)getThumbnailURLsFromImageInfos:(NSArray*) imageInfos;


@end

/**云名片信息
 */
@interface JBoOpenPlatformInfo : NSObject

/**名片信息Id
 */
@property(nonatomic,assign) long long Id;

/**名片信息标题
 */
@property(nonatomic,copy) NSString *title;

/**标题高度
 */
@property(nonatomic,assign) NSInteger titleHeight;

/**标题后面的图片高度 2.5.5版本后取消
 */
//@property(nonatomic,assign) NSInteger titleImageHeight;

/**标题后面的图片数量 2.5.5版本后取消
 */
//@property(nonatomic,assign) NSInteger imageCountAfterTitle;

/**名片信息内容 数组元素是 JBoOpenPlatformTextInfo 对象
 */
@property(nonatomic,retain) NSMutableArray *contentInfos;

/**内容高度 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger contentHeight;

/**信息排序Id
 */
@property(nonatomic,assign) double sortId;

/**图片集合 数组元素是 JBoOpenPlatformImageInfo 对象
 */
@property(nonatomic,retain) NSMutableArray *imageInfos;

/**信息类型 0 默认
 */
@property(nonatomic,assign) NSInteger type;

/**可见状态 0 公开 1隐藏
 */
@property(nonatomic,assign) NSInteger visible;

/**时间
 */
@property(nonatomic,copy) NSString *time;

/**是否置顶
 */
@property(nonatomic,assign) BOOL stick;

/**云名片样式信息
 */
@property(nonatomic,retain) JBoOpenPlatformWebStyleInfo *webStyleInfo;

/**信息是否展开 default is 'NO'
 */
@property(nonatomic,assign) BOOL expand;

/**分享的链接
 */
@property(nonatomic,copy) NSString *url;

/**云名片链接
 */
@property(nonatomic,copy) NSString *infoURL;

//云名片信息二维码图片 信息内容是云名片链接
@property(nonatomic,retain) UIImage *qrCodeImage;
@property(nonatomic,retain) UIImage *qrCodeThumbnail;

/**地址位置信息
 */
@property(nonatomic,retain) JBoMapInfo *addrInfo;

/**地址信息高度 
 */
@property(nonatomic,assign) NSInteger addrHeight;

/**云名片分组信息
 */
@property(nonatomic,retain) JBoOpenPlatformGroupInfo *groupInfo;

/**商品价格
 */
@property(nonatomic,assign) float price;

#pragma mark- public method

/**从字典中获取云名片信息
 */
- (void)infoFromDictionary:(NSDictionary*) dict;

/**价格字符串
 */
- (NSString*)priceString;

/**根据图片下标获取所属文本
 *@param imageIndex 在所有图片中的下标
 *@param index 在所属文本中的图片的下标
 *@return 所属文本下标
 */
- (NSInteger)textIndexFromImageIndex:(NSInteger) imageIndex index:(NSInteger*) index;

/**通过文本下标获取图片起始位置
 *@param textIndex 文本下标
 *@return 在所有图片中的下标
 */
- (NSInteger)imageIndexFromTextIndex:(NSInteger) textIndex;

/**是否允许添加图片
 *@return 可上传的图片数量
 */
- (NSInteger)canUploadImageCount;

/**是否允许添加文字
 *@return 可上传的添加文字的数量
 */
- (int)canAddTextCount;

/**计算标题高度
 */
- (void)caculateTitleHeight;

/**计算地址高度
 */
- (void)caculateAddrHeight;

/**是否可以添加文字
 */
- (BOOL)canAddTextInfo;

#pragma mark- class method

/**获取文本参数
 *@param textInfos 数组元素是JBoOpenPlatformTextInfo对象
 *@return 上传和修改所需的文本参数 ，文本内容，样式
 */
+ (NSDictionary*)textParamFromTextInfos:(NSArray*) textInfos;

/**获取图片信息参数
 *@param imageInfos 数组元素是JBoOpenPlatformTextInfo
 *@return 图片关联的链接 高度 宽度 图片路径 缩略图路径
 */
+ (NSDictionary*)imageParamFromImageInfos:(NSArray*) imageInfos;

/**合并没有文本内容但有图片的数据, 或有文本但没有图片的数据
 *@param textInfos 要合并的文本数据 数组元素是JBoOpenPlatformTextInfo
 */
+ (void)combineTextInfos:(NSMutableArray*) textInfos;

@end
