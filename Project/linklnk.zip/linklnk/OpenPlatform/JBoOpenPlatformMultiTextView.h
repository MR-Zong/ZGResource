//
//  JBoOpenPlatformMultiTextView.h
//  linklnk
//
//  Created by kinghe005 on 14-9-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoBasic.h"    
#import "JBoMultiImageView.h"

@class JBoImageTextLabel;

//cell未展开时显示图片的数量
#define _openPlatformShowImageCountWhenClose_ 3

#define _openPlatformTextInset_ 5.0
#define _openPlatformTextLineHeight_ 20.0
#define _openPlatformTextWordInset_ 1.0
#define _openPlatformTextFont_ [UIFont systemFontOfSize:_openPlatformTextFontSize_]

#define _openPlatformAddTextButtonHeight_ 30.0

#define _openPlatfromTitleHeight_ 25.0

//每个文本框的间距
#define _openPlatformTextBoxPadding_ 5.0

//文本后面的图数量标记
#define _openPlatformImageCountHeight_ 20.0

#define _openPlatformImageCountAlertMsg_ @"图片,"

@class JBoOpenPlatformMultiTextView;
@class JBoOpenPlatformInfo;

/**云名片文本信息显示视图代理
 */
@protocol JBoOpenPlatformMultiTextViewDelegate <NSObject>

/**长按label
 */
- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView*) multiTextView didLongPressLabelAtIndex:(NSInteger) index;

/**添加文本
 */
- (void)openPlatformMultiTextViewDidAddTextInfo:(JBoOpenPlatformMultiTextView*) multiTextView;

/**点击链接
 */
- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView *)multiTextView didSelectURL:(NSURL*) url;

/**选择图片
 */
- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView*) multiTextView didSelectedImageAtIndex:(NSInteger) index;

/**长按图片
 */
- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView*) multiTextView didLongPressedImageAtIndex:(NSInteger) index;

@end

/**云名片文本及图片信息显示视图
 */
@interface JBoOpenPlatformMultiTextView : UIView

/**云名片信息
 */
@property(nonatomic,retain) JBoOpenPlatformInfo *info;

/**添加文字按钮
 */
@property(nonatomic,readonly) UIButton *addTextInfoButton;

@property(nonatomic,assign) id<JBoOpenPlatformMultiTextViewDelegate> delegate;

/**通过下标获取label
 */
- (JBoImageTextLabel*)labelForIndex:(NSInteger) index;

//加载视图
- (void)reloadData;

/**重新加载图片
*/
- (void)reloadImageAtIndex:(NSInteger) index withURL:(NSString*) URL;

/**设置logo
 */
- (void)setupLogoStyle:(JBoMultiImageViewCellLogoStyle) logoStyle atIndex:(NSInteger) index;

#pragma mark- class method

/**获取图片高度
 */
+ (CGFloat)imageHeightForImageCount:(NSInteger) count;

@end
