//
//  JBoOpenPlatformEditViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-11-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"
#import "JBoHttpRequest.h"

@class JBoOpenPlatformEditViewController;
@class JBoOpenPlatformInfo;
@class JBoTextView;
@class JBoStraightlineProgressView;

//图片选择的最大数量
#define _imageOperationMaxCount_ 32

//边距
#define _margin_ 10.0

//控件间隔
#define _controlInterval_ 20.0

/**云名片信息编辑代理
 */
@protocol JBoOpenPlatformEidtViewControllerDelegate <NSObject>

@optional

/**编辑完成
 *@param info 新的云名片信息
 */
- (void)openPlatformEidtViewController:(JBoOpenPlatformEditViewController*) viewController didFinishWithInfo:(JBoOpenPlatformInfo*) info;

/**云名片信息修改完成
 */
- (void)openPlatformEidtViewControllerDidFinishModify:(JBoOpenPlatformEditViewController *)viewController;

@end

@class JBoOpenPlatformEditViewController;

/**云名片信息编辑基类
 */
@interface JBoOpenPlatformEditViewController : JBoViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,JBoHttpRequestDelegate,UIAlertViewDelegate>

/**文本编辑器
 */
@property(nonatomic,retain) JBoTextView *textView;

/**编辑器frame
 */
@property(nonatomic,assign) CGRect originalTextFrame;

/**图片文件路径 数组元素是 NSString 对象
 */
@property(nonatomic,retain) NSArray *files;

/**缩略图 文件路径 数组元素是 NSString 对象
 */
@property(nonatomic,retain) NSArray *thumbnailFiles;

/**上传图片的文本大小
 */
@property(nonatomic,assign) long long totalSize;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;
@property(nonatomic,assign) BOOL isRequesting;

/**图片信息 数组元素是 UIImage 对象
 */
@property(nonatomic,retain) NSArray *images;

/**缩略图信息 数组元素是 UIImage 对象
 */
@property(nonatomic,retain) NSArray *thumbnails;

/**编辑器附件信息 数组元素是JBoTextAttachment对象
 */
@property(nonatomic,retain) NSMutableArray *attachments;

/**上传进度条
 */
@property(nonatomic,retain) JBoStraightlineProgressView *progressView;

@property(nonatomic,assign) id<JBoOpenPlatformEidtViewControllerDelegate> delegate;

/**退出编辑
 */
- (void)close;

/**获取编辑器中所有图片图片
 *@return 数组元素是 UIImage 对象
 */
- (NSMutableArray*)getImages;

/**格式化 文本 获取分段文本和文本后的图片数量
 *@return 数组元素 是JBoOpenPlatformTextInfo
 */
- (NSArray*)getOpenPlatformTextInfos;

/**获取图片信息
 *@return 数组元素是 JBoOpenPlatformImageInfo对象
 */
- (NSArray*)getOpenPlatformImageInfos;

/**获取文本参数
 *@return 上传和修改所需的文本参数 ，文本内容，样式
 */
- (NSDictionary*)textParam;

/**获取图片参数
 *@return 上传的图片大小集合 
 */
- (NSDictionary*)imageParam;


@end
