//
//  JBoOpenPlatformSubscribeViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformSubscribeViewController.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoHttpRequest.h"
#import "JBoOpenPlatformSubscribeInfo.h"
#import "JBoOpenPlatformSubscribeCell.h"
#import "JBoOpenPlatformOperation.h"
#import "JBoOpenPlatformSubscribeInfo.h"

@interface JBoOpenPlatformSubscribeViewController ()<JBoHttpRequestDelegate>

/**云名片信息
 */
@property(nonatomic,retain)  JBoOpenPlatformInfo *info;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

//列表
@property(nonatomic,retain) UITableView *tableView;

//预约的人的数据 数组元素是 JBoOpenPlatformSubscribeInfo 对象
@property(nonatomic,retain) NSMutableArray *infoArray;

//拨号
@property(nonatomic,retain) UIWebView *callOutWebView;

@end

@implementation JBoOpenPlatformSubscribeViewController

/**构造方法
 *@param info 云名片信息
 *@return 一个初始化的JBoOpenPlatformSubscribeViewController对象
 */
- (id)initWithOpenPlatformInfo:(JBoOpenPlatformInfo *)info
{
    self = [super initWithNibName:nil bundle:nil];
    if(self)
    {
        self.info = info;
        self.title = @"预约的人";
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_info release];
    
    [_httpRequest release];
    [_tableView release];
    [_infoArray release];
    
    [_callOutWebView clean];
    [_callOutWebView release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [self alertNetworkMsg:@"获取预约的人失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    NSMutableArray *infos = [JBoOpenPlatformOperation getOpenPlatFormSubscribeInfoFromData:data];
    self.infoArray = infos;
    [self loadInitView];
}

#pragma mark- 加载视图

- (void)back
{
    self.isRequesting = NO;
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.isRequesting = YES;
    [self.httpRequest downloadWithURL:[JBoOpenPlatformOperation getOpenPlatFormSubscribeInfoWithId:self.info.Id]];
}

- (void)loadInitView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.rowHeight = _openPlatformSubscribeCellHeight_;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
    
    [tableView setExtraCellLineHidden];
    
    [self hasInfo];
}

//是否有预约的人
- (void)hasInfo
{
    if(self.infoArray.count > 0)
    {
       // self.tableView.tableFooterView = nil;
    }
    else
    {
        UILabel *label = [[UILabel alloc] initWithFrame:self.tableView.bounds];
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont boldSystemFontOfSize:20.0];
        label.textColor = [UIColor grayColor];
        label.textAlign = JBoTextAlignmentCenter;
        label.text = @"暂无预约的人";
        self.tableView.tableFooterView = label;
        [label release];
    }
}

#pragma mark- tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoOpenPlatformSubscribeCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoOpenPlatformSubscribeCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoOpenPlatformSubscribeInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    cell.nameLabel.text = info.name;
    cell.telLabel.text = info.tel;
    cell.timeLabel.text = info.time;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    JBoOpenPlatformSubscribeInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    NSURL *phoneURL = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",info.tel]];
    if(!self.callOutWebView)
    {
        self.callOutWebView = [[[UIWebView alloc] init] autorelease];
    }
    [_callOutWebView loadRequest:[NSURLRequest requestWithURL:phoneURL]];
}

@end
