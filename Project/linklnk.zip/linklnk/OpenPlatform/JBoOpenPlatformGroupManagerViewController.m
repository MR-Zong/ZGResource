//
//  JBoOpenPlatformGroupManagerViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformGroupManagerViewController.h"
#import "JBoOpenPlatformGroupInfo.h"
#import "JBoOpenPlatformGroupOperation.h"
#import "JBoHttpRequest.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoUserOperation.h"
#import "JBoCustomInsetLabel.h"
#import "JBoOpenPlatformStairGroupView.h"
#import "JBoPopupMenu.h"

#define _selectSectionTag_ 1000

static NSString *const removeGroup = @"删除";
static NSString *const addSecondaryGroup = @"添加二级分组";
static NSString *const modifyGroupName = @"修改分组名称";

typedef enum _JBoAlertOpeartionType
{
    JBoAlertOpeartionTypeAddGroup = 0, //添加一级分组
    JBoAlertOpeartionTypeAddSecondaryGroup = 1, //添加二级分组
    JBoAlertOpeartionTypeModifyGroup = 2, //修改一级分组
    JBoAlertOpeartionTypeModifySecondaryGroup = 3, //修改二级分组
}JBoAlertOpeartionType;

@interface JBoOpenPlatformGroupManagerViewController ()<JBoHttpRequestDelegate,JBoPopupMenuDelegate,JBoOpenPlatformStairGroupViewDelegate>


//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在请求
@property(nonatomic,assign) BOOL isRequesting;

//选中的一级分组
@property(nonatomic,assign) NSInteger selectedStairIndex;

//选中的二级分组
@property(nonatomic,assign) NSInteger selectedSecondaryIndex;

//新的分组名称
@property(nonatomic,retain) NSString *groupName;

//分组操作类型
@property(nonatomic,assign) JBoAlertOpeartionType alertType;

//一级分组
@property(nonatomic,retain) JBoOpenPlatformStairGroupView *stairGroupView;

//二级分组
@property(nonatomic,retain) JBoPopupMenu *secondaryGroupMenu;

//显示二级菜单的一级分组
@property(nonatomic,assign) NSInteger showSecondaryGroupStairIndex;

@end

@implementation JBoOpenPlatformGroupManagerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"云名片分组管理";
        
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        self.infoArray = [NSMutableArray array];
        
        self.selectedStairIndex = NSNotFound;
        self.selectedSecondaryIndex = NSNotFound;
        self.showSecondaryGroupStairIndex = NSNotFound;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_infoArray release];
    
    [_httpRequest release];
   
    [_groupName release];
    
    [_stairGroupView release];
    [_secondaryGroupMenu release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getOpenPlatformGroupInfoIdentifier_])
    {
        [self alertNetworkMsg:@"获取分组信息失败"];
        return;
    }
    
    if([identifier isEqualToString:_addOpenPlatformGroupIdentifier_])
    {
        [self alertNetworkMsg:@"添加一级分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_addOpenPlatformSecondaryGroupIdentifier_])
    {
        [self alertNetworkMsg:@"添加二级分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformGroupIdentifier_])
    {
        [self alertNetworkMsg:@"删除一级分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformSecondaryGroupIdentifier_])
    {
        [self alertNetworkMsg:@"删除二级分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_modifyOpenPlatformGroupIdentifier_])
    {
        [self alertNetworkMsg:@"修改一级分组名称失败"];
        return;
    }
    
    if([identifier isEqualToString:_modifyOpenPlatformSecondaryGroupIdentifier_])
    {
        [self alertNetworkMsg:@"修改二级分组名称失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_getOpenPlatformGroupInfoIdentifier_])
    {
        NSArray *array = [JBoOpenPlatformGroupOperation getOpenPlatformGroupInfoFromData:data];
        if(array)
        {
            [self.infoArray addObjectsFromArray:array];
            [self loadInitView];
        }
        else
        {
            [self alertNetworkMsg:@"获取分组信息失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_addOpenPlatformGroupIdentifier_])
    {
        NSInteger error = 0;
        JBoOpenPlatformGroupInfo *info = [JBoOpenPlatformGroupOperation additionOpenPlatformGroupInfoFromData:data error:&error];
        if(info)
        {
            info.name = self.groupName;
            self.groupName = nil;
            [self.infoArray addObject:info];
            
            [self.stairGroupView reload];
        }
        else
        {
            if(error == _openPlatformGroupBeyondMaxCountCode_)
            {
                [self alertMsg:@"添加的一级分组已超出数量上限"];
            }
            else
            {
                [self alertNetworkMsg:@"添加一级分组失败"];
            }
        }
        return;
    }
    
    if([identifier isEqualToString:_addOpenPlatformSecondaryGroupIdentifier_])
    {
        NSInteger error = 0;
        JBoOpenPlatformGroupInfo *info = [JBoOpenPlatformGroupOperation additionOpenPlatformGroupInfoFromData:data error:&error];
        if(info)
        {
            JBoOpenPlatformGroupInfo *stairInfo = [self.infoArray objectAtIndex:self.selectedStairIndex];
            
            if(stairInfo.secondaryInfos == nil)
            {
                stairInfo.secondaryInfos = [NSMutableArray arrayWithCapacity:1];
            }
            
            [stairInfo.secondaryInfos addObject:info];
            info.name = self.groupName;
            self.groupName = nil;

            if(self.showSecondaryGroupStairIndex == self.selectedStairIndex)
            {
                [self setSecondaryGroupMenuItemWithInfo:stairInfo];
                [self.secondaryGroupMenu reloadMenuItems];
            }
        }
        else
        {
            if(error == _openPlatformGroupBeyondMaxCountCode_)
            {
                [self alertMsg:@"添加的二级分组已超出数量上限"];
            }
            else
            {
                [self alertNetworkMsg:@"添加二级分组失败"];
            }
        }
        return;
    }
    
    if([identifier isEqualToString:_modifyOpenPlatformGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            info.name = self.groupName;
            self.groupName = nil;
            [self.stairGroupView reload];
            
            if([self.delegate respondsToSelector:@selector(openPlatformGroupManagerViewController:didModifyGroupInfo:)])
            {
                [self.delegate openPlatformGroupManagerViewController:self didModifyGroupInfo:info];
            }
        }
        else
        {
            [self alertNetworkMsg:@"修改一级分组名称失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_modifyOpenPlatformSecondaryGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            JBoOpenPlatformGroupInfo *secondary = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
            secondary.name = self.groupName;
            self.groupName = nil;
            
            if(self.showSecondaryGroupStairIndex == self.selectedStairIndex)
            {
                [self setSecondaryGroupMenuItemWithInfo:info];
                [self.secondaryGroupMenu reloadMenuItems];
            }
            
            if([self.delegate respondsToSelector:@selector(openPlatformGroupManagerViewController:didModifyGroupInfo:)])
            {
                [self.delegate openPlatformGroupManagerViewController:self didModifyGroupInfo:secondary];
            }
        }
        else
        {
            [self alertNetworkMsg:@"修改二级级分组名称失败"];
        }
    }
    
    if([identifier isEqualToString:_removeOpenPlatformGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            
            if(info.secondaryInfos.count > 0)
            {
                if([self.delegate respondsToSelector:@selector(openPlatformGroupManagerViewController:didRemoveGroupInfo:)])
                {
                    [self.delegate openPlatformGroupManagerViewController:self didRemoveGroupInfo:info];
                }
            }
           
            [self.infoArray removeObjectAtIndex:self.selectedStairIndex];
            
            [self.stairGroupView reload];
            
            if(self.selectedStairIndex == self.showSecondaryGroupStairIndex)
            {
                [self.secondaryGroupMenu dismissMenuWithAnimated:YES];
            }
        }
        else
        {
            [self alertNetworkMsg:@"删除一级分组失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformSecondaryGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            JBoOpenPlatformGroupInfo *second = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
            
            if([self.delegate respondsToSelector:@selector(openPlatformGroupManagerViewController:didRemoveGroupInfo:)])
            {
                [self.delegate openPlatformGroupManagerViewController:self didRemoveGroupInfo:second];
            }
            
            [info.secondaryInfos removeObjectAtIndex:self.selectedSecondaryIndex];
            if(self.showSecondaryGroupStairIndex == self.selectedStairIndex)
            {
                [self setSecondaryGroupMenuItemWithInfo:info];
                [self.secondaryGroupMenu reloadMenuItems];
            }
        }
        else
        {
            [self alertNetworkMsg:@"删除二级分组失败"];
        }
        return;
    }
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    if(self.infoArray.count == 0)
    {
        self.isRequesting = YES;
        self.httpRequest.identifier = _getOpenPlatformGroupInfoIdentifier_;
        [self.httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation getOpenPlatformGroupInfo]];
    }
    else
    {
        [self loadInitView];
    }
}

- (void)loadInitView
{
    JBoOpenPlatformStairGroupView *view = [[JBoOpenPlatformStairGroupView alloc] initWithFrame:CGRectMake(0, 0, _width_, _openPlatformStairGroupViewHeight_)];
    view.editable = YES;
    view.maxCount = _openPlatformGroupMaxCount_;
    view.infos = self.infoArray;
    view.delegate = self;
    [self.view addSubview:view];
    self.stairGroupView = view;
    [view release];
    
    JBoCustomInsetLabel *alertLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, (_height_ - _statuBarHeight_ - _navgateBarHeight_ - view.height - 50) / 2.0, _width_, 50.0)];
    alertLabel.insets = UIEdgeInsetsMake(0, 10.0, 0, 10.0);
    alertLabel.numberOfLines = 0;
    alertLabel.backgroundColor = [UIColor clearColor];
    alertLabel.font = [UIFont systemFontOfSize:14.0];
    alertLabel.textColor = [UIColor grayColor];
    alertLabel.text = [NSString stringWithFormat:@"您最多只能添加%d个一级分组,每个一级菜单最多添加%d个二级分组", _openPlatformGroupMaxCount_, _openPlatformSecondaryGroupMaxCount_];
    
    [self.view addSubview:alertLabel];
    
    [alertLabel release];
    
}

#pragma mark- private method

- (void)addGroup
{
    [self showAlertViewWithContent:nil type:JBoAlertOpeartionTypeAddGroup];
}

//设置二级分组按钮信息
- (void)setSecondaryGroupMenuItemWithInfo:(JBoOpenPlatformGroupInfo*) info
{
    NSMutableArray *menuItems = [NSMutableArray arrayWithCapacity:info.secondaryInfos.count];
    
      NSString *maxLengthTitle = nil;
    for(JBoOpenPlatformGroupInfo *secondaryInfo in info.secondaryInfos)
    {
        JBoPopupMenuItem *popupMenuItem = [JBoPopupMenuItem menuItemWithIcon:nil title:secondaryInfo.name];
        popupMenuItem.add = NO;
        [menuItems addObject:popupMenuItem];
        
        if(maxLengthTitle.length < secondaryInfo.name.length)
        {
            maxLengthTitle = secondaryInfo.name;
        }
    }
    
    //添加 添加二级分组按钮
    if(menuItems.count < _openPlatformSecondaryGroupMaxCount_)
    {
        JBoPopupMenuItem *menuItem = [JBoPopupMenuItem menuItemWithIcon:nil title:nil];
        menuItem.add = YES;
        [menuItems addObject:menuItem];
    }
    
    CGFloat width = [self.secondaryGroupMenu getMenuWidthFromTitle:maxLengthTitle];
    width = width < _width_ / _openPlatformGroupMaxCount_ - 10 ? _width_ / _openPlatformGroupMaxCount_ - 10 : width;
    self.secondaryGroupMenu.menuWidth = width;
    
    self.secondaryGroupMenu.menuItems = menuItems;
}

#pragma mark- JBoOpenPlatformStairGroupView 代理

- (void)openPlatformStairGroupView:(JBoOpenPlatformStairGroupView *)view didLongPressGroupAtIndex:(NSInteger)index
{
    self.selectedStairIndex = index;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"删除分组不会删除分组内的云名片信息" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil, nil];
    actionSheet.tag = _selectSectionTag_;
  
    [actionSheet addButtonWithTitle:modifyGroupName];
    actionSheet.destructiveButtonIndex = [actionSheet addButtonWithTitle:removeGroup];
    actionSheet.cancelButtonIndex = [actionSheet addButtonWithTitle:@"取消"];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformStairGroupView:(JBoOpenPlatformStairGroupView *)view didSelectGroupAtIndex:(NSInteger)index
{
    if(self.showSecondaryGroupStairIndex != index)
    {
        [self.secondaryGroupMenu dismissMenuWithAnimated:YES];
        JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:index];
        
        
        self.secondaryGroupMenu = [[[JBoPopupMenu alloc] initWithStyle:JBoPopupMenuStylePlainText] autorelease];
        self.secondaryGroupMenu.tintColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        self.secondaryGroupMenu.menuTitleColor = [UIColor blackColor];
        self.secondaryGroupMenu.separatedLineColor = [UIColor lightGrayColor];
        
        JBoOpenPlatformStairGroupButton *item = [view buttonForIndex:index];
        [self setSecondaryGroupMenuItemWithInfo:info];
        
        self.secondaryGroupMenu.delegate = self;
        
        CGRect relateRect = item.frame;
        relateRect.origin.y = view.frame.origin.y;
        relateRect.size.height = view.frame.size.height;
        
        [self.secondaryGroupMenu showInView:self.view relatedRect:relateRect animated:YES overlay:YES];
        [self.view bringSubviewToFront:view];
        self.showSecondaryGroupStairIndex = index;
    }
    else
    {
        [self.secondaryGroupMenu dismissMenuWithAnimated:YES];
        self.showSecondaryGroupStairIndex = NSNotFound;
    }
}

- (void)openPlatformStairGroupViewDidAddGroup:(JBoOpenPlatformStairGroupView *)view
{
    if(self.isRequesting)
        return;
    [self addGroup];
}


#pragma mark-JBoPopupMenu代理

- (void)popupMenu:(JBoPopupMenu *)menu didSelectedAtIndex:(NSInteger)index
{
//    JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.showSecondaryGroupStairIndex];
//    JBoSendMsgUrlMenuItem *subItem = [mainItem.childItems objectAtIndex:index];
//    
//    JBoWebViewController *web = [[JBoWebViewController alloc] init];
//    web.black = NO;
//    web.URL = [NSURL URLWithString:subItem.url];
//    [web showInViewController:self animated:YES completion:nil];
//    [web release];
}

- (void)popupMenu:(JBoPopupMenu *)menu didAddedAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    self.selectedStairIndex = self.showSecondaryGroupStairIndex;
    self.selectedSecondaryIndex = index;
    
    [self showAlertViewWithContent:nil type:JBoAlertOpeartionTypeAddSecondaryGroup];
}

- (void)popupMenu:(JBoPopupMenu *)menu didLongPressAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    
    self.selectedStairIndex = self.showSecondaryGroupStairIndex;
    self.selectedSecondaryIndex = index;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"删除分组不会删除分组内的云名片信息" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:modifyGroupName, removeGroup, nil];
    actionSheet.destructiveButtonIndex = 1;
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)popupMenuWillDismiss:(JBoPopupMenu *)menu
{
    self.showSecondaryGroupStairIndex = NSNotFound;
}


#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if([title isEqualToString:addSecondaryGroup])
    {
        [self showAlertViewWithContent:nil type:JBoAlertOpeartionTypeAddSecondaryGroup];
    }
    else if([title isEqualToString:modifyGroupName])
    {
        if(actionSheet.tag == _selectSectionTag_)
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            [self showAlertViewWithContent:info.name type:JBoAlertOpeartionTypeModifyGroup];
        }
        else
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            JBoOpenPlatformGroupInfo *secondatyInfo = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
            
            [self showAlertViewWithContent:secondatyInfo.name type:JBoAlertOpeartionTypeModifySecondaryGroup];
        }
    }
    else if([title isEqualToString:removeGroup])
    {
        self.isRequesting = YES;
        if(actionSheet.tag == _selectSectionTag_)
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            _httpRequest.identifier = _removeOpenPlatformGroupIdentifier_;
            [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation removeOpenPlatformGroup] dic:[JBoOpenPlatformGroupOperation removeOpenPlatformGroupParamWithId:info.Id]];
        }
        else
        {
            JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
            JBoOpenPlatformGroupInfo *secondatyInfo = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
            _httpRequest.identifier = _removeOpenPlatformSecondaryGroupIdentifier_;
            [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation removeOpenPlatformSecondaryGroup] dic:[JBoOpenPlatformGroupOperation removeOpenPlatformSecondaryGroupParamWithId:secondatyInfo.Id]];
        }
    }
}

//显示alertView
- (void)showAlertViewWithContent:(NSString*) content type:(JBoAlertOpeartionType) type
{
    NSString *title = nil;
    
    switch (type)
    {
        case JBoAlertOpeartionTypeAddGroup :
            title = @"添加一级分组";
            break;
        case JBoAlertOpeartionTypeAddSecondaryGroup :
            title = @"添加二级分组";
            break;
        case JBoAlertOpeartionTypeModifyGroup :
        case JBoAlertOpeartionTypeModifySecondaryGroup :
            title = @"修改分组名称";
            break;
        default:
            break;
    }
    self.alertType = type;
    
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:title message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    [textField addTarget:self action:@selector(textValueDidChange:) forControlEvents:UIControlEventEditingChanged];
    textField.delegate = self;
    textField.placeholder = [NSString stringWithFormat:@"%d个字以内",_inputFormatOpenPlatformGroupName_];
    textField.text = content;
    [alerView show];
    [alerView release];
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 1 :
        {
            UITextField *textField = [alertView textFieldAtIndex:0];
            
            if([NSString isEmpty:textField.text])
            {
                [self alertMsg:@"分组名称不能为空"];
                return;
            }
            
            if(textField.text.length > _inputFormatOpenPlatformGroupName_)
            {
                [self alertMsg:[NSString stringWithFormat:@"分组名称不能超过%d个字", _inputFormatOpenPlatformGroupName_]];
                return;
            }
            
            self.groupName = textField.text;
            self.isRequesting = YES;
            
            switch (self.alertType)
            {
                case JBoAlertOpeartionTypeAddSecondaryGroup :
                {
                    //添加分组
                    JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
                    _httpRequest.identifier = _addOpenPlatformSecondaryGroupIdentifier_;
                    [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation addOpenPlatformSecondaryGroup] dic:[JBoOpenPlatformGroupOperation addOpenPlatformSecondaryGroupParamWithName:self.groupName groupId:info.Id]];
                }
                    break;
                case JBoAlertOpeartionTypeAddGroup :
                {
                    //添加分组
                    _httpRequest.identifier = _addOpenPlatformGroupIdentifier_;
                    [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation addOpenPlatformGroup] dic:[JBoOpenPlatformGroupOperation addOpenPlatformGroupParamWithName:self.groupName]];
                }
                    break;
                case JBoAlertOpeartionTypeModifyGroup :
                {
                    //更新分组名
                    JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
                    if(![info.name isEqualToString:self.groupName])
                    {
                        _httpRequest.identifier = _modifyOpenPlatformGroupIdentifier_;
                        [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation modifyOpenPlatformGroup] dic:[JBoOpenPlatformGroupOperation modifyOpenPlatformGroupParamWithName:self.groupName Id:info.Id]];
                    }
                    else
                    {
                        self.isRequesting= NO;
                        self.groupName = nil;
                    }
                }
                    break;
                case JBoAlertOpeartionTypeModifySecondaryGroup :
                {
                    //更新分组名
                    JBoOpenPlatformGroupInfo *info = [self.infoArray objectAtIndex:self.selectedStairIndex];
                    JBoOpenPlatformGroupInfo *secondaryInfo = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
                    
                    if(![secondaryInfo.name isEqualToString:self.groupName])
                    {
                        _httpRequest.identifier = _modifyOpenPlatformSecondaryGroupIdentifier_;
                        [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation modifyOpenPlatformSecondaryGroup] dic:[JBoOpenPlatformGroupOperation modifyOpenPlatformSecondaryGroupParamWithName:self.groupName Id:secondaryInfo.Id]];
                    }
                    else
                    {
                        self.isRequesting= NO;
                        self.groupName = nil;
                    }
                }
                    break;
                default:
                    break;
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark- textField代理

- (void)textValueDidChange:(UITextField*)textField
{
    [textField textDidChangeWithLimitedCount:_inputFormatOpenPlatformGroupName_];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return [textField textShouldChangeCharactersInRange:range replacementString:string limitedCount:_inputFormatOpenPlatformGroupName_];
}

@end
