//
//  JBoOpenPlatformTextInfoModifyVieController.m
//  linklnk
//
//  Created by kinghe005 on 14-10-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformInfoModifyVieController.h"
#import "JBoTextView.h"
#import "JBoHttpRequest.h"
#import "JBoOpenPlatformOperation.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoUserOperation.h"
#import "JBoOpenPlatformTextStyleViewController.h"
#import "JBoStraightlineProgressView.h"
#import "JBoFileManager.h"
#import "JBoImageCacheTool.h"

//文本后面的图片数量提示
#define _imageCountAfterTextAlertMsg_ @"文本后面的图片数量"

//标题后面的图片数量提示
#define _imageCountAfterTitleAlertMsg_ @"文本后面的图片数量"

//输入框高度
#define _textViewHeight_ 170.0
#define _textFieldHeight_ 35.0

//每个文本后面跟随的图片最大数量
#define _imageCountAfterTextMaxCount_ 32

#define _padding_ 10.0

@interface JBoOpenPlatformInfoModifyVieController ()

@end

@implementation JBoOpenPlatformInfoModifyVieController

/**构造方法
 *@param info 靓云台信息
 *@param index 要修改的文本信息下标或新信息插入的位置
 *@param imageIndex 图片的下标
 *@param type 编辑类型
 *@return 一个初始化的 JBoOpenPlatformTextInfoModifyVieController
 */
- (id)initWithInfo:(JBoOpenPlatformInfo*) info modifyIndex:(NSInteger) index imageIndex:(int) imageIndex type:(JBoOpenPlatformEditType) type
{
    self = [super initWithNibName:nil bundle:nil];
    if(self)
    {
        _type = type;
        self.black = YES;
        self.httpRequest.identifier = _modifyOpenPlatformTextInfoIdentifier_;
        _info = [info retain];
        _modifyIndex = index;
        _imageIndex = imageIndex;

        switch (_type)
        {
            case JBoOpenPlatformEditTypeModifyText :
            {
                self.title = @"更改云名片信息";
            }
                break;
            default:
                self.title = @"添加云名片信息";
                break;
        }
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_info release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    [super httpRequest:request didFailed:error identifier:identifier];

    switch (_type)
    {
        case JBoOpenPlatformEditTypeModifyText :
        {
            [self alertNetworkMsg:@"更改云名片信息失败"];
        }
            break;
        default:
            [self alertNetworkMsg:@"添加云名片信息失败"];
            break;
    }
    
    return;
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.progressView.progress = 1.0;
    self.isRequesting = NO;
    
    JBoOpenPlatformInfo *info = [JBoOpenPlatformOperation updatedOpenPlatformInfoFromData:data];
    if(info)
    {
        JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
        NSInteger start = [self.info imageIndexFromTextIndex:self.modifyIndex];
        
        NSMutableArray *urls = [NSMutableArray arrayWithCapacity:self.thumbnails.count];
        for(NSInteger i = 0;i < self.thumbnails.count && i + start < info.imageInfos.count;i ++)
        {
            JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:i + start];
            if(![NSString isEmpty:imageInfo.thumbnailURL])
            {
                [urls addObject:imageInfo.thumbnailURL];
            }
        }
        
        [JBoFileManager moveFiles:self.thumbnailFiles withURLs:urls suffix:cache.imageSuffix toPath:cache.normalCachePath];
        
        [JBoFileManager deleteFiles:self.files];
        self.files = nil;
        
        self.progressView.hidden = YES;
        self.isRequesting = NO;
        
        self.info.contentHeight = NSNotFound;
        self.info.imageInfos = info.imageInfos;
        self.info.contentInfos = info.contentInfos;
        
        switch (_type)
        {
            case JBoOpenPlatformEditTypeModifyText :
            {
                [self alertMsg:@"更改云名片信息成功"];
            }
                break;
            default:
                 [self alertMsg:@"添加云名片信息成功"];
                break;
        }
        if([self.delegate respondsToSelector:@selector(openPlatformEidtViewControllerDidFinishModify:)])
        {
            [self.delegate openPlatformEidtViewControllerDidFinishModify:self];
        }
        [self close];
    }
    else
    {
        [self httpRequest:request didFailed:nil identifier:identifier];
    }
}

#pragma mark- 加载视图

- (void)finish
{
    if(self.isRequesting)
        return;
    if([NSString isEmpty:self.textView.text])
    {
        [self alertMsg:@"内容不能为空"];
        return;
    }
    
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    self.isRequesting = YES;
    
    if(!self.progressView)
    {
        JBoStraightlineProgressView *progressView = [[JBoStraightlineProgressView alloc] initWithFrame:CGRectMake(0, 0, _width_, 3.0)];
        [self.view addSubview:progressView];
        self.progressView = progressView;
        [progressView release];
    }
    self.progressView.hidden = NO;
    self.progressView.progress = 0;
    
    [self.httpRequest startDataLoading];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        NSArray *textInfos = [self getOpenPlatformTextInfos];
        NSArray *imageInfos = [self getOpenPlatformImageInfos];
        
        self.httpRequest.startImmediately = NO;
        self.httpRequest.totalBytesSent = self.totalSize;
        self.totalSize = 0;
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            [self.httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOpenPlatformInfo] paraDic:[JBoOpenPlatformOperation updateOpenPlatformInfoParamWithInfo:self.info atIndex:self.modifyIndex newTextInfos:textInfos type:self.type newImageInfos:imageInfos imageIndex:self.imageIndex] files:self.files filesKey:_openPlatformImagesFile_];
            [self.httpRequest addFiles:self.thumbnailFiles forKey:_openPlatformThumbnailsFile_];
            [self.httpRequest startDownload];
            
            self.httpRequest.startImmediately = YES;
        });
    });
}

- (void)back
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    self.isRequesting = NO;
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
   // self.textView.height = _height_ - _statuBarHeight_ - _navgateBarHeight_ - _margin_ * 2;
    
    switch (self.type)
    {
        case JBoOpenPlatformEditTypeModifyText :
        {
            JBoOpenPlatformTextInfo *info = [self.info.contentInfos objectAtIndex:self.modifyIndex];
            NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:info.content attributes:[self.textView defaultAttributes]];
            
            for(JBoOpenPlatformTextStyleInfo *textStyleInfo in info.textStyleInfos)
            {
                NSDictionary *attrs = [textStyleInfo attributesWithContentLength:attributedString.length isCoreText:YES];
                if(attrs)
                {
                    [attributedString addAttributes:attrs range:textStyleInfo.textRange];
                }
            }
            
            self.textView.attributedText = attributedString;
            [attributedString release];
        }
            break;
            
        default:
            break;
    }
   
    self.textView.maxImageCount = _imageOperationMaxCount_ - (int)self.info.imageInfos.count;
    
    self.textView.maxCount = [self.info canAddTextCount] + (int)self.textView.attributedText.length;
    
    if(self.textView.maxImageCount < 0)
    {
        self.textView.maxImageCount = 0;
    }
    
    [self.view addSubview:self.textView];
}

@end
