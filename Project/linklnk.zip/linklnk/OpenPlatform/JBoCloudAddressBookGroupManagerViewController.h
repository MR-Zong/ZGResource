//
//  JBoCloudAddressBookGroupManagerViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**云名片夹分组管理
 */
@interface JBoCloudAddressBookGroupManagerViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,UIAlertViewDelegate,UITextFieldDelegate>

/**信息内容 数组元素是JBoCloudAddressBookGroupInfo对象
 */
@property(nonatomic,retain) NSMutableArray *infoArray;

@end
