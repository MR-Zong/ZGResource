//
//  JBoCloundAddressSyncViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**将云名片夹同步到本地通讯录
 */
@interface JBoCloudAddressBookSyncViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>

/**云名片夹信息 数组元素是 JBoCloudAddressBookGroupInfo对象
 */
@property(nonatomic,retain) NSMutableArray *groupInfos;

@end
