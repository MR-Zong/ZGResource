//
//  JBoLocalAddressBookSyncViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLocalAddressBookSyncViewController.h"
#import "JBoLocalAddressBookOperation.h"
#import "JBoLocalAddressBookSyncCell.h"
#import "JBoLocalAddressBookSyncInfo.h"
#import "ChineseToPinyin.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoCloudAddressBookInfo.h"
#import "JBoAddressBookSectionHeader.h"
#import "JBoLettersSearchBar.h"

@interface JBoLocalAddressBookSyncViewController ()

/**本地通讯录联系人列表
 */
@property(nonatomic,retain) UITableView *tableView;

/**本地通讯录联系人信息 数组元素是JBoAddressBookGroupInfo
 */
@property(nonatomic,retain) NSMutableArray *localAddressBookInfos;

/**搜索栏
 */
@property(nonatomic,retain) UISearchBar *searchBar;

/**正在搜索中
 */
@property(nonatomic,assign) BOOL searching;

/**搜索结果 数组元素是JBoLocalAddressBookSyncInfo
 */
@property(nonatomic,retain) NSMutableArray *searchResultArray;

/**搜索透明视图
 */
@property(nonatomic,retain) UIView *transparentView;

/**本地通讯录操作
 */
@property(nonatomic,retain) JBoLocalAddressBookOperation *addressBookOperation;

/**字母选择
 */
@property(nonatomic,retain) JBoLettersSearchBar *lettersSearchBar;

@end

@implementation JBoLocalAddressBookSyncViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self)
    {
        self.title = @"手机通讯录同步";
        self.searchResultArray = [NSMutableArray array];
        self.addressBookOperation = [[[JBoLocalAddressBookOperation alloc] init] autorelease];
        self.addressBookOperation.personClassString = NSStringFromClass([JBoLocalAddressBookSyncInfo class]);
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_cloundAddresBookInfos release];
    
    [_tableView release];
    [_localAddressBookInfos release];
    
    [_searchBar release];
    
    [_searchResultArray release];
    [_transparentView release];
    [_addressBookOperation release];
    [_lettersSearchBar release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)back
{
    [super back];
}

- (void)finish
{
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.appDelegate.dataLoadingView.hidden = NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        NSArray *personInfos = [self.addressBookOperation getAddressBookPersonInfos];
        
        //对比联系人是否已存在云名片夹中
        if(self.cloundAddresBookInfos.count > 0 && personInfos.count > 0)
        {
            for(JBoCloudAddressBookGroupInfo *groupInfo in self.cloundAddresBookInfos)
            {
                for(JBoCloudAddressBookInfo *bookInfo in groupInfo.infos)
                {
                    for(JBoLocalAddressBookSyncInfo *personInfo in personInfos)
                    {
                        if(personInfo.cloudGroupInfo == nil)
                        {
                            if([personInfo.phoneNums containsObject:bookInfo.phoneNum])
                            {
                                personInfo.cloudGroupInfo = groupInfo;
                            }
                            else if([personInfo.phoneNums containsObject:bookInfo.telePhone])
                            {
                                personInfo.cloudGroupInfo = groupInfo;
                            }
                        }
                    }
                }
            }
        }
        
        self.localAddressBookInfos = [self.addressBookOperation addressBookGroupInfosFromPersonInfos:personInfos];
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            [self loadInitView];
        });
    });
}

- (void)loadInitView
{
    self.appDelegate.dataLoadingView.hidden = YES;
    if(self.localAddressBookInfos.count == 0)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, _width_ - 20.0, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        [label setTextAlign:JBoTextAlignmentCenter];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor blackColor];
        label.numberOfLines = 0;
        
        if([self.addressBookOperation canUseAddressBook])
        {
            label.text = _alerMsgWhenAddressBookIsEmpty_;
        }
        else
        {
            label.text = _alerMagWhenCannotAccessAddressBook_;
        }
        
        [self.view addSubview:label];
        [label release];
    }
    else
    {
        [self setRightBarItemWithTitle:@"同步" action:@selector(finish)];
        
        CGFloat toolBarHeight = 0;
        
        //创建tableview
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_ - toolBarHeight) style:UITableViewStylePlain];
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.separatorColor = [UIColor colorWithRed:160.0 / 255.0 green:160.0 / 255.0 blue:160.0 / 255.0 alpha:1.0];
        [self.view addSubview:tableView];
        self.tableView = tableView;
        [tableView release];
        [tableView setExtraCellLineHidden];
        
        //创建搜索视图
        UISearchBar *searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, 40.0)];
        searchBar.placeholder = @"搜索";
        if(!_ios7_0_)
        {
            searchBar.tintColor = _searchBarColor_;
        }
        searchBar.delegate = self;
        _tableView.tableHeaderView = searchBar;
        self.searchBar = searchBar;
        [searchBar release];
        
        //创建通讯录字母搜索视图
        JBoLettersSearchBar *lettersSearchBar = [[JBoLettersSearchBar alloc] initWithFrame:CGRectMake(_width_ - _letterViewWidth_, 0, _letterViewWidth_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        [lettersSearchBar addTarget:self action:@selector(letterTouchedAction)];
        [self.view addSubview:lettersSearchBar];
        self.lettersSearchBar = lettersSearchBar;
        [lettersSearchBar release];
        
//        JBoCustomToolBar *toolBar = [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, tableView.bottom, _width_, toolBarHeight) items:[NSArray arrayWithObject:[JBoCustomToolBarItem toolBarItemWithTitle:@"选择全部" image:nil]]];
//        toolBar.delegate = self;
//        
//        UIButton *btn = [toolBar buttonForIndex:0];
//        [btn setTitle:@"全部取消" forState:UIControlStateSelected];
//        [btn setTitleColor:[UIColor greenColor] forState:UIControlStateHighlighted];
//        
//        [self.view addSubview:toolBar];
//        self.toolBar = toolBar;
//        [toolBar release];
    }
}

- (void)letterTouchedAction
{
    NSString *letter = self.lettersSearchBar.touchLetter;
    for(NSInteger i = 0;i < self.localAddressBookInfos.count;i ++)
    {
        JBoAddressBookGroupInfo *info  = [self.localAddressBookInfos objectAtIndex:i];
        if([info.title isEqualToString:letter])
        {
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:i];
            [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
            break;
        }
    }
}

#pragma mark-searchBar 代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    self.searching = YES;
    if(!_transparentView)
    {
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + self.searchBar.height : self.searchBar.height;
        
        UIView *transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [transparentView addGestureRecognizer:tap];
        transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self.view addSubview:transparentView];
        self.transparentView = transparentView;
        [transparentView release];
        [tap release];
    }
    _transparentView.hidden = NO;
    
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    [_searchBar setShowsCancelButton:YES animated:YES];
    [self.tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    self.searching = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
    [_tableView setExtraCellLineHidden];
}

//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [_searchResultArray removeAllObjects];
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        
        [_searchResultArray removeAllObjects];
        
        for(JBoAddressBookGroupInfo *groupInfo in self.localAddressBookInfos)
        {
            for(JBoLocalAddressBookSyncInfo *info in groupInfo.personInfos)
            {
                if([self pinyin:pinyin match:info.name])
                {
                    [_searchResultArray addObject:info];
                }
                
                if([self chinese:content match:info.name] && ![_searchResultArray containsObject:info])
                {
                    [_searchResultArray addObject:info];
                }
            }
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
        [_tableView reloadData];
        [_tableView setExtraCellLineHidden];
    }
    else
    {
        _transparentView.hidden = NO;
    }
}

- (BOOL)pinyin:(NSString*) pinyin match:(NSString*) str
{
    NSString *name = [ChineseToPinyin pinyinFromChiniseString:str];
    if(name.length < pinyin.length)
    {
        return NO;
    }
    
    NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
    if([pinyin isEqualToString:subStr])
    {
        return YES;
    }
    return NO;
}

- (BOOL)chinese:(NSString*) chinese match:(NSString*) str
{
    NSRange range = [str rangeOfString:chinese];
    if(range.length > 0 && range.location != NSNotFound)
    {
        return YES;
    }
    return NO;
}

#pragma mark- tableView代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(self.searching)
    {
        return 1;
    }
    else
    {
        return self.localAddressBookInfos.count;
    }
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(self.searching)
        return nil;
    JBoAddressBookGroupInfo *groupInfo = [self.localAddressBookInfos objectAtIndex:section];
    UIView *view = nil;
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"headerIdentifier";
        JBoAddressBookSectionHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[JBoAddressBookSectionHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.headerView.titleLabl.text = groupInfo.title;
        view = header;
#endif
    }
    else
    {
        JBoAddressBookSectionHeaderView *header = [[[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)] autorelease];
        header.titleLabl.text = groupInfo.title;
        view = header;
    }
    
    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(self.searching)
    {
        return 0;
    }
    else
    {
        return _sectionHeaderHeight_;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(self.searching)
    {
        return self.searchResultArray.count;
    }
    else
    {
        JBoAddressBookGroupInfo *groupInfo = [self.localAddressBookInfos objectAtIndex:section];
        return groupInfo.personInfos.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLocalAddressBookSyncInfo *info = [self infoFroIndexPath:indexPath];
    
    CGFloat height = _localAddressBookSyncCellMargin_ * 2 + _localAddressBookSyncCellControlHeight_ * 2;
    if(![NSString isEmpty:info.remark])
    {
        height += _localAddressBookSyncCellControlHeight_;
    }
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoLocalAddressBookSyncCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoLocalAddressBookSyncCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    JBoLocalAddressBookSyncInfo *info = [self infoFroIndexPath:indexPath];
    
    cell.nameLabel.text = info.name;
    cell.phoneNumLabel.text = info.displayPhoneNum;
    cell.remarkLabel.text = info.remark;
    cell.exist = info.cloudGroupInfo != nil;
    
    return cell;
}

#pragma mark- private method

/**获取联系人信息
 */
- (JBoLocalAddressBookSyncInfo*)infoFroIndexPath:(NSIndexPath*) indexPath
{
    if(self.searching)
    {
        return [self.searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        JBoAddressBookGroupInfo *groupInfo = [self.localAddressBookInfos objectAtIndex:indexPath.section];
        return [groupInfo.personInfos objectAtIndex:indexPath.row];
    }
}

@end
