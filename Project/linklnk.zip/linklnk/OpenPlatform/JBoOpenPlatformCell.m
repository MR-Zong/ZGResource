//
//  JBoOpenPlatformCell.m
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformCell.h"
#import "JBoBasic.h"
#import "JBoCustomInsetLabel.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoOpenPlatformMenu.h"

#define _rightPadding_ 5
#define _topPadding_ 10

@interface JBoOpenPlatformCell ()

//菜单出现时的覆盖视图
@property(nonatomic,retain) UIView *overlayView;

//要变色的label
@property(nonatomic,retain) UIView *selectedView;

//选择的label下标
@property(nonatomic,assign) NSInteger selectedIndex;

//删除等功能菜单
@property(nonatomic,retain) JBoOpenPlatformMenu *menu;

@end

@implementation JBoOpenPlatformCell

/**构造方法
 *@param reuseIdentifier 重用标识
 *@param cellStyle cell的类型
 *@param type 云名片操作类型
 *@return 一个初始化的 JBoOpenPlatformCell 对象
 */
- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier cellStyle:(JBoOpenPlatformCellStyle) cellStyle operationType:(JBoOpenPlatformOperationType)type
{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _operationType = type;
        self.contentView.backgroundColor = [UIColor whiteColor];
        
        _qrCodeImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_rightPadding_ + (_openPlatformDateLabelWidth_- _openPlatformQRCodeImageWidth_) / 2.0, _openPlatformDateInnerPadding_, _openPlatformQRCodeImageWidth_, _openPlatformQRCodeImageHeight_)];
        _qrCodeImageView.userInteractionEnabled = YES;
        _qrCodeImageView.backgroundColor = _imageBackgroundColorBeforeDownload_;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(qrCodeDidSelect:)];
        [_qrCodeImageView addGestureRecognizer:tap];
        [tap release];
        [self.contentView addSubview:_qrCodeImageView];
        
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(qrCodeDidLongPress:)];
        [_qrCodeImageView addGestureRecognizer:longPress];
        [longPress release];
        
        _dateView = [[JBoDateView alloc] initWithFrame:CGRectMake(_rightPadding_, _qrCodeImageView.bottom, _openPlatformDateLabelWidth_, _lookAndTellDateViewDefaultHeight_)];
        _dateView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_dateView];
        
        _cellStyle = cellStyle;
        switch (_cellStyle)
        {
            case JBoOpenPlatformCellStyleImageText :
            case JBoOpenPlatformCellStyleMall :
            {
                _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(_dateView.right + _topPadding_, _qrCodeImageView.top, _openPlatformImageWitdh_, _openPlatfromTitleHeight_)];
                _titleLabel.backgroundColor = [UIColor clearColor];
                _titleLabel.userInteractionEnabled = YES;
                
                UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(titleLongPress:)];
                [_titleLabel addGestureRecognizer:longPress];
                [longPress release];
                
                _titleLabel.font = _openPlatformTitleFont_;
                _titleLabel.textColor = [UIColor blackColor];
                _titleLabel.numberOfLines = 0;
                [self addSubview:_titleLabel];
                
                //详情按钮
                CGFloat detailButtonWidth = 48;
                
                UIImage *arrow = [UIImage imageNamed:@"down_Arrow"];
                _topDetailButton = [UIButton buttonWithType:UIButtonTypeCustom];
                
                _topDetailButton.frame = CGRectMake(_titleLabel.right - detailButtonWidth, _titleLabel.bottom, detailButtonWidth, _openPlatformImageCountHeight_);
                [_topDetailButton setTitle:@"详情" forState:UIControlStateNormal];
                [_topDetailButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _topDetailButton.titleLabel.font = [UIFont systemFontOfSize:13.0];
                [_topDetailButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
                [_topDetailButton setImage:arrow forState:UIControlStateNormal];
                [_topDetailButton setImage:[UIImage imageNamed:@"top_Arrow"] forState:UIControlStateSelected];
                [_topDetailButton setTitleEdgeInsets:UIEdgeInsetsMake(0, - arrow.size.width, 0, arrow.size.width)];
                [_topDetailButton setImageEdgeInsets:UIEdgeInsetsMake(0, 27.0, 0, - 27.0)];
                
                [_topDetailButton addTarget:self action:@selector(titleTap:) forControlEvents:UIControlEventTouchUpInside];
                [self addSubview:_topDetailButton];
                
                
                _bottomDetailButton = [UIButton buttonWithType:UIButtonTypeCustom];
                _bottomDetailButton.frame = CGRectMake(_topDetailButton.left, _multiTextView.bottom, _topDetailButton.width, _openPlatformImageCountHeight_);
                [_bottomDetailButton addTarget:self action:@selector(titleTap:) forControlEvents:UIControlEventTouchUpInside];
                [_bottomDetailButton setTitle:@"详情" forState:UIControlStateNormal];
                [_bottomDetailButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _bottomDetailButton.titleLabel.font = [UIFont systemFontOfSize:13.0];
                [_bottomDetailButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
                [_bottomDetailButton setImage:[UIImage imageNamed:@"top_Arrow"] forState:UIControlStateNormal];
                [_bottomDetailButton setTitleEdgeInsets:UIEdgeInsetsMake(0, - arrow.size.width, 0, arrow.size.width)];
                [_bottomDetailButton setImageEdgeInsets:UIEdgeInsetsMake(0, 27.0, 0, - 27.0)];
                [self.contentView addSubview:_bottomDetailButton];
                
                CGFloat y = _titleLabel.bottom;
                if(cellStyle == JBoOpenPlatformCellStyleMall)
                {
                    CGRect frame = _titleLabel.frame;
                    frame.origin.y = y;
                    frame.size.width -= detailButtonWidth;
                    _priceLabel = [[UILabel alloc] initWithFrame:frame];
                    _priceLabel.backgroundColor = [UIColor clearColor];
                    _priceLabel.textColor = [UIColor redColor];
                    _priceLabel.font = [UIFont boldSystemFontOfSize:15.0];
                    [self.contentView addSubview:_priceLabel];
                    y = _priceLabel.bottom;
                }
                
                _multiTextView = [[JBoOpenPlatformMultiTextView alloc] initWithFrame:CGRectMake(_dateView.right + _topPadding_, y, _openPlatformImageWitdh_ + _openPlatformTextInset_ * 2, 0)];
                _multiTextView.delegate = self;
                [self.contentView addSubview:_multiTextView];
                
                CGFloat size = 35.0;
                _checkBox = [[JBoCheckBox alloc] initWithFrame:CGRectMake(_rightPadding_ + (_dateView.width - size) / 2.0, _dateView.bottom + _rightPadding_, size, size) style:CheckBoxStyleDefault selectedImage:nil unselectedImage:nil];
                _checkBox.hidden = YES;
                _checkBox.delegate = self;
                [self.contentView addSubview:_checkBox];
                
                _webStyleButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [_webStyleButton setShowsTouchWhenHighlighted:YES];
                _webStyleButton.backgroundColor = [UIColor clearColor];
                [_webStyleButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _webStyleButton.titleLabel.font = _openPlatformAddressFont_;
                [_webStyleButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                // _webStyleButton.adjustsImageWhenHighlighted = NO;
                [_webStyleButton setFrame:CGRectMake(_multiTextView.left, 0, _multiTextView.width, _openPlatformDateButtonHeight_)];
                
                [_webStyleButton addTarget:self action:@selector(webStyleAction:) forControlEvents:UIControlEventTouchUpInside];
                [self.contentView addSubview:_webStyleButton];
                
                //地址信息
                UIImage *icon = [UIImage imageNamed:@"location_icon"];
                _addrIconImageView = [[UIImageView alloc] initWithImage:icon];
                _addrIconImageView.contentMode = UIViewContentModeCenter;
                _addrIconImageView.frame = CGRectMake(_multiTextView.left, 0, _openPlatformAddressIconWidth_, icon.size.height);
                [self.contentView addSubview:_addrIconImageView];
                
                _addrLabel = [[UILabel alloc] initWithFrame:CGRectMake(_addrIconImageView.right, 0, _openPlatformAddressWitdh_, 0)];
                _addrLabel.backgroundColor = [UIColor clearColor];
                _addrLabel.textColor = [UIColor grayColor];
                _addrLabel.font = _openPlatformAddressFont_;
                _addrLabel.numberOfLines = 0;
                
                _addrLabel.userInteractionEnabled = YES;
                longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(addrLongPress:)];
                [_addrLabel addGestureRecognizer:longPress];
                [longPress release];
                
                [self.contentView addSubview:_addrLabel];
                
                _addrAddButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [_addrAddButton setShowsTouchWhenHighlighted:YES];
                _addrAddButton.backgroundColor = [UIColor clearColor];
                [_addrAddButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
                _addrAddButton.titleLabel.font = [UIFont boldSystemFontOfSize:15.0];
                [_addrAddButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
                // _webStyleButton.adjustsImageWhenHighlighted = NO;
                [_addrAddButton setFrame:CGRectMake(_multiTextView.left, 0, _multiTextView.width, _openPlatformDateButtonHeight_)];
                [_addrAddButton setImage:[UIImage imageNamed:@"location_icon"] forState:UIControlStateNormal];
                [_addrAddButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                [_addrAddButton setTitle:@" 添加地址 十 " forState:UIControlStateNormal];
                [_addrAddButton addTarget:self action:@selector(addrAdd:) forControlEvents:UIControlEventTouchUpInside];
                [self.contentView addSubview:_addrAddButton];
            }
                break;
            case JBoOpenPlatformCellStyleLink :
            {
                _linkView = [[JBoLinkShareView alloc] initWithFrame:CGRectMake(_dateView.right + _topPadding_, _qrCodeImageView.top, _openPlatformImageWitdh_, _openPlatformLinkViewHeight_)];
                [_linkView addTarget:self singleTapAction:@selector(shareURLDidSelected:)];

                [self.contentView addSubview:_linkView];
            }
                break;
            default:
                break;
        }
        
        //分组信息
        _groupButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_groupButton setShowsTouchWhenHighlighted:YES];
        _groupButton.backgroundColor = [UIColor clearColor];
        [_groupButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        _groupButton.titleLabel.font = _openPlatformAddressFont_;
        [_groupButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        // _webStyleButton.adjustsImageWhenHighlighted = NO;
        [_groupButton setFrame:CGRectMake(_dateView.right + _topPadding_, 0, _openPlatformImageWitdh_, _openPlatformDateButtonHeight_)];
        
        [_groupButton addTarget:self action:@selector(groupAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_groupButton];
        
        CGFloat width = _openPlatformImageWitdh_ / 3;
        CGFloat height = _openPlatformDateButtonHeight_;
        
        
        JBoOpenPlatformMenu *menu = [[JBoOpenPlatformMenu alloc] initWithOrigin:CGPointMake(_dateView.right + _topPadding_, 0) ItemSize:CGSizeMake(width, height) operationType:type];

        switch (_operationType)
        {
            case JBoOpenPlatformOperationTypeScene :
            {
                [menu.selectedButton addTarget:self action:@selector(selectOpenPlatformInfo:) forControlEvents:UIControlEventTouchUpInside];
            }
                break;
            case JBoOpenPlatformOperationTypeDefault :
            {
                [menu.deleteButton addTarget:self action:@selector(deleteMsg:) forControlEvents:UIControlEventTouchUpInside];
                [menu.visibleButton addTarget:self action:@selector(setVisible:) forControlEvents:UIControlEventTouchUpInside];
                [menu.stickButton addTarget:self action:@selector(setStick:) forControlEvents:UIControlEventTouchUpInside];
                
                [menu.updateOrderButton addTarget:self action:@selector(updateOrder:) forControlEvents:UIControlEventTouchUpInside];
                [menu.moveButton addTarget:self action:@selector(move:) forControlEvents:UIControlEventTouchUpInside];
                [menu.subscribeButton addTarget:self action:@selector(subscribed:) forControlEvents:UIControlEventTouchUpInside];
            }
                break;
            default:
                break;
        }

        [self.contentView addSubview:menu];
        self.menu = menu;
        [menu release];

    }
    return self;
}

- (void)dealloc
{
    [_info release];
    [_dateView release];
    [_qrCodeImageView release];
    
    [_multiTextView release];
    
    [_overlayView release];
    [_selectedView release];
    
    [_menu release];
    
    [super dealloc];
}

- (void)setIsSelectedInfo:(BOOL)isSelectedInfo
{
    self.menu.selectedButton.selected = isSelectedInfo;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    //重新布局
    switch (self.cellStyle)
    {
        // 图文
        case JBoOpenPlatformCellStyleImageText :
        case JBoOpenPlatformCellStyleMall :
        {
            //标题和详情按钮
            self.titleLabel.height = self.info.titleHeight;
            self.topDetailButton.top = self.titleLabel.bottom;
            _priceLabel.top = self.titleLabel.bottom;
            
            CGFloat y = self.topDetailButton.bottom;
            if(self.cellStyle == JBoOpenPlatformCellStyleMall)
                y =  _priceLabel.bottom;
            
            //内容
            _multiTextView.top = y;

            //样式 分组 详情
            _webStyleButton.top =  _multiTextView.bottom;
            self.groupButton.top = _webStyleButton.bottom;
            self.bottomDetailButton.top = _groupButton.top + 5.0;
            y = self.groupButton.bottom;
            
            //地址信息
            if(self.info.addrInfo)
            {
                _addrIconImageView.hidden = NO;
                _addrLabel.hidden = NO;
                _addrAddButton.hidden = YES;
                _addrIconImageView.top = y;
                _addrLabel.top = _addrIconImageView.top;
                _addrLabel.height = self.info.addrHeight;
                _addrLabel.text = [self.info.addrInfo addr];
                y = _addrLabel.bottom;
                self.addrLabel.hidden = !self.info.expand;
                self.addrIconImageView.hidden = !self.info.expand;
                
            }
            else
            {
                _addrIconImageView.hidden = YES;
                _addrLabel.hidden = YES;
                _addrAddButton.hidden = NO;
                _addrAddButton.top = y;
                y = _addrAddButton.bottom;
                self.addrAddButton.hidden = !self.info.expand;
            }
            
            _webStyleButton.hidden = !self.info.expand;
            _groupButton.hidden = !self.info.expand;
            
            //判断内容是否过长
            if((self.info.contentHeight + self.info.titleHeight + _openPlatformDateInnerPadding_ * 2) > _height_)
            {
                _bottomDetailButton.hidden = !self.info.expand;
            }
            else
            {
                _bottomDetailButton.hidden = YES;
            }
            
            _topDetailButton.selected = self.info.expand;
            
            //操作菜单
            switch (self.operationType)
            {
                case JBoOpenPlatformOperationTypeDefault :
                {
                    self.menu.hidden = !self.info.expand;
                    self.menu.top = y;
                }
                    break;
                case JBoOpenPlatformOperationTypeScene :
                {
                    if(self.info.expand)
                    {
                        self.menu.top = y;
                    }
                    else
                    {
                        self.menu.top = self.multiTextView.bottom + _openPlatformTextBoxPadding_;
                    }
                }
                    break;
                default:
                    break;
            }
            
            [self.contentView bringSubviewToFront:self.bottomDetailButton];
            
        }
            break;
        //分享的链接
        case JBoOpenPlatformCellStyleLink :
        {
            self.groupButton.top = self.linkView.bottom;
            self.menu.top = self.groupButton.bottom;
        }
            break;
        default:
            break;
    }
  
    
    self.menu.visibleButton.selected = self.info.visible == _openPlatformVisibleHide;
    self.menu.stickButton.selected = self.info.stick;
    self.menu.moveButton.hidden = self.info.stick;
    self.menu.updateOrderButton.hidden = self.info.stick;
}

#pragma mark- private method

- (void)deleteMsg:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidDelete:)])
    {
        [self.delegate openPlatformCellDidDelete:self];
    }
}

- (void)setVisible:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellSetupVisible:)])
    {
        [self.delegate openPlatformCellSetupVisible:self];
    }
}

- (void)setStick:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellSetupStick:)])
    {
        [self.delegate openPlatformCellSetupStick:self];
    }
}

- (void)updateOrder:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellUpdateOrder:)])
    {
        [self.delegate openPlatformCellUpdateOrder:self];
    }
}

- (void)move:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidMove:)])
    {
        [self.delegate openPlatformCellDidMove:self];
    }
}

- (void)subscribed:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidSubscribe:)])
    {
        [self.delegate openPlatformCellDidSubscribe:self];
    }
}

- (void)qrCodeDidSelect:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didSelectURL:)])
    {
        [self.delegate openPlatformCell:self didSelectURL:[NSURL URLWithString:self.info.infoURL]];
    }
}

- (void)qrCodeDidLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        if(self.qrCodeImageView.image == nil)
            return;
        if([self.delegate respondsToSelector:@selector(openplatformCellDidSelectQRCodeImage:)])
        {
            [self.delegate openplatformCellDidSelectQRCodeImage:self];
        }
    }
}

- (void)setShowCheckBox:(BOOL)showCheckBox
{
    self.checkBox.hidden = !showCheckBox;
    self.menu.moveButton.selected = showCheckBox;
}


//修改样式
- (void)webStyleAction:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidModifyWebStyle:)])
    {
        [self.delegate openPlatformCellDidModifyWebStyle:self];
    }
}

//点击链接视图
- (void)shareURLDidSelected:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didSelectURL:)])
    {
        if(![NSString isEmpty:self.info.url])
        {
            [self.delegate openPlatformCell:self didSelectURL:[NSURL URLWithString:self.info.url]];
        }
    }
}

//选择云名片信息
- (void)selectOpenPlatformInfo:(UIButton*) button
{
    button.selected = !button.selected;
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didSelect:)])
    {
        [self.delegate openPlatformCell:self didSelect:button.selected];
    }
}

//选择分组
- (void)groupAction:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidSelectGroup:)])
    {
        [self.delegate openPlatformCellDidSelectGroup:self];
    }
}

#pragma mark- 地址

- (void)addrLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        [self showOverlayView];
        self.selectedView = longPress.view;
        self.selectedView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];
        
        
        NSMutableArray *itemArray = [NSMutableArray array];
        
        UIMenuItem *copy = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyAddress:)];
        [itemArray addObject:copy];
        [copy release];
        
        UIMenuItem *modify = [[UIMenuItem alloc] initWithTitle:@"更改" action:@selector(modifyAddress:)];
        [itemArray addObject:modify];
        [modify release];
        
        
        [self becomeFirstResponder];
        
        CGRect rect = CGRectMake(longPress.view.left, self.top + longPress.view.top, longPress.view.width, longPress.view.height);
        UIMenuController *menu = [UIMenuController sharedMenuController];
        [menu setMenuItems:itemArray];
        [menu setTargetRect:rect inView:self.superview];
        [menu setMenuVisible:YES animated:YES];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(menuWillDismiss:) name:UIMenuControllerWillHideMenuNotification object:nil];
    }
}

- (void)addrAdd:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidUpdateAddress:)])
    {
        [self.delegate openPlatformCellDidUpdateAddress:self];
    }
}

- (void)modifyAddress:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidUpdateAddress:)])
    {
        [self.delegate openPlatformCellDidUpdateAddress:self];
    }
}

- (void)copyAddress:(id) sender
{
    NSString *msg = self.addrLabel.text;
    if([NSString isEmpty:msg])
    {
        msg = @" ";
    }
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = msg;
}


#pragma mark- checkBox代理

- (void)checkBoxStyleDidChanged:(JBoCheckBox *)checkBox
{
    if([self.delegate respondsToSelector:@selector(openplatformCellDidSelectedCheckBox:)])
    {
        [self.delegate openplatformCellDidSelectedCheckBox:self];
    }
}

#pragma mark- JBoOpenPlatformMultiTextView代理

- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView *)multiTextView didSelectedImageAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didSelectedImageAtIndex:)])
    {
        [self.delegate openPlatformCell:self didSelectedImageAtIndex:index];
    }
}

- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView *)multiTextView didLongPressedImageAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didLongPressedImageAtIndex:)])
    {
        [self.delegate openPlatformCell:self didLongPressedImageAtIndex:index];
    }
}

- (void)openPlatformMultiTextViewDidAddTextInfo:(JBoOpenPlatformMultiTextView *)multiTextView
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didAddTextInfoAtIndex:)])
    {
        [self.delegate openPlatformCell:self didAddTextInfoAtIndex:NSNotFound];
    }
}

- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView *)multiTextView didSelectURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didSelectURL:)])
    {
        [self.delegate openPlatformCell:self didSelectURL:url];
    }
}

- (void)openPlatformMultiTextView:(JBoOpenPlatformMultiTextView *)multiTextView didLongPressLabelAtIndex:(NSInteger)index
{
    [self showOverlayView];
    
    self.selectedIndex = index;
    JBoImageTextLabel *label = [self.multiTextView labelForIndex:index];
    
    self.selectedView = label;
    self.selectedView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];
    
    NSMutableArray *itemArray = [NSMutableArray array];
    
    UIMenuItem *copy = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyMsg:)];
    [itemArray addObject:copy];
    [copy release];
    
    UIMenuItem *remove = [[UIMenuItem alloc] initWithTitle:@"删除" action:@selector(removeMsg:)];
    [itemArray addObject:remove];
    [remove release];
    
    UIMenuItem *modify = [[UIMenuItem alloc] initWithTitle:@"更改" action:@selector(modifyMsg:)];
    [itemArray addObject:modify];
    [modify release];
    
    if(self.canAddTextInfo)
    {
        UIMenuItem *add = [[UIMenuItem alloc] initWithTitle:@"添加" action:@selector(addMsg:)];
        [itemArray addObject:add];
        [add release];
    }
    
    [self becomeFirstResponder];
    
    CGRect rect = CGRectMake(label.left, self.top + label.top + multiTextView.top, label.width, label.height);
    UIMenuController *menu = [UIMenuController sharedMenuController];
    [menu setMenuItems:itemArray];
    [menu setTargetRect:rect inView:self.superview];
    [menu setMenuVisible:YES animated:YES];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(menuWillDismiss:) name:UIMenuControllerWillHideMenuNotification object:nil];
}

#pragma mark- 菜单

- (void)showOverlayView
{
    if(!self.overlayView)
    {
        self.overlayView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
        self.overlayView.backgroundColor = [UIColor clearColor];
        
        UITapGestureRecognizer *dismissMenuTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissMenu:)];
        [self.overlayView addGestureRecognizer:dismissMenuTap];
        [dismissMenuTap release];
    }
    
    UIView *view = nil;
    
    if([self.delegate isKindOfClass:[UIView class]])
    {
        view = (UIView*)self.delegate;
    }
    else if([self.delegate isKindOfClass:[UIViewController class]])
    {
        view = [(UIViewController*)self.delegate view];
    }
    
    [view addSubview:self.overlayView];
}

- (void)dismissMenu:(UITapGestureRecognizer*) tap
{
    [self resignFirstResponder];
}

- (void)menuWillDismiss:(NSNotification*) notification
{
    [self.overlayView removeFromSuperview];
    self.overlayView = nil;
    self.selectedView.backgroundColor = [UIColor clearColor];
    self.priceLabel.backgroundColor = [UIColor clearColor];
    self.selectedView = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIMenuControllerWillHideMenuNotification object:nil];
}

//复制文本
- (void)copyMsg:(id) sender
{
    if(self.selectedIndex < self.multiTextView.info.contentInfos.count)
    {
        JBoOpenPlatformTextInfo *textInfo = [self.multiTextView.info.contentInfos objectAtIndex:self.selectedIndex];
        NSString *msg = textInfo.content;
        if([NSString isEmpty:msg])
        {
            msg = @" ";
        }
        
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = msg;
    }
}

//删除文本
- (void)removeMsg:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didRemoveTextInfoAtIndex:)])
    {
        [self.delegate openPlatformCell:self didRemoveTextInfoAtIndex:self.selectedIndex];
    }
}

//修改文本
- (void)modifyMsg:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didModifyTextInfoAtIndex:)])
    {
        [self.delegate openPlatformCell:self didModifyTextInfoAtIndex:self.selectedIndex];
    }
}

//添加信息
- (void)addMsg:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCell:didAddTextInfoAtIndex:)])
    {
        [self.delegate openPlatformCell:self didAddTextInfoAtIndex:self.selectedIndex];
    }
}

#pragma mark- title

- (void)titleLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        [self showOverlayView];
        self.selectedView = self.titleLabel;
        self.selectedView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.2];
        
        self.priceLabel.backgroundColor = self.selectedView.backgroundColor;
        
        NSMutableArray *itemArray = [NSMutableArray array];
        
        UIMenuItem *copy = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyTitle:)];
        [itemArray addObject:copy];
        [copy release];
        
        UIMenuItem *modify = [[UIMenuItem alloc] initWithTitle:@"更改" action:@selector(modifyTitle:)];
        [itemArray addObject:modify];
        [modify release];
        
        
        [self becomeFirstResponder];
        
        CGRect rect = CGRectMake(self.selectedView.left, self.top + self.selectedView.top, self.selectedView.width, self.selectedView.height);
        UIMenuController *menu = [UIMenuController sharedMenuController];
        [menu setMenuItems:itemArray];
        [menu setTargetRect:rect inView:self.superview];
        [menu setMenuVisible:YES animated:YES];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(menuWillDismiss:) name:UIMenuControllerWillHideMenuNotification object:nil];
    }
}

//复制标题
- (void)copyTitle:(id) sender
{
    NSString *msg = self.titleLabel.text;
    if([NSString isEmpty:msg])
    {
        msg = @" ";
    }
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = msg;
}

//单击标题
- (void)titleTap:(id) sender
{
    self.info.expand = !self.info.expand;
    self.topDetailButton.selected = !self.topDetailButton.selected;
    if([self.delegate respondsToSelector:@selector(openPlatformCellExpandDidChanged:)])
    {
        [self.delegate openPlatformCellExpandDidChanged:self];
    }
}

//更改标题
- (void)modifyTitle:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformCellDidModifyTitle:)])
    {
        [self.delegate openPlatformCellDidModifyTitle:self];
    }
}

#pragma mark- responder

//让cell成为第一响应者
- (BOOL)canBecomeFirstResponder
{
    return YES;
}

//可以显示的操作方法
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if(action == @selector(copyMsg:) || action == @selector(removeMsg:) || action == @selector(modifyMsg:) || action == @selector(addMsg:) || action == @selector(copyTitle:) || action == @selector(modifyTitle:) || action == @selector(copyAddress:) || action == @selector(modifyAddress:))
    {
        return YES;
    }
    return NO;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
