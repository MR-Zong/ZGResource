//
//  JBoOpenPlatformModifyTitleViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-11-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformModifyTitleViewController.h"
#import "SSTextView.h"
#import "JBoHttpRequest.h"
#import "JBoOpenPlatformOperation.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoUserOperation.h"
#import "JBoImageTextTool.h"
#import "JBoOpenPlatformCell.h"
#import "JBoImageTextLabel.h"
#import <QuartzCore/QuartzCore.h>

#define _padding_ 10.0

@interface JBoOpenPlatformModifyTitleViewController ()<JBoHttpRequestDelegate>

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//正在请求中
@property(nonatomic,assign) BOOL isRequesting;

/**文本内容
 */
@property(nonatomic,retain) SSTextView *textView;

//新的标题
@property(nonatomic,copy) NSString *newsTitle;

/**价格
 */
@property(nonatomic,retain) UITextField *priceTextField;

/**新的价格
 */
@property(nonatomic,assign) float price;

@end

@implementation JBoOpenPlatformModifyTitleViewController

/**构造方法
 *@param info 云名片信息
 *@return 一个初始化的 JBoOpenPlatformModifyTitleViewController
 */
- (id)initWithInfo:(JBoOpenPlatformInfo*) info
{
    self = [super initWithNibName:nil bundle:nil];
    if(self)
    {
        self.black = YES;
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        _info = [info retain];

        self.title = @"更改云名片标题";
    }
    return self;
}

#pragma mark- property

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
        self.textView.editable = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    self.delegate = nil;
    [_textView release];
    [_info release];

    
    [_httpRequest release];
    [_newsTitle release];
    [_priceTextField release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;

    if([identifier isEqualToString:_modifyOpenPlatformTitleIdentifier_])
    {
        [self alertNetworkMsg:@"更改云名片标题失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_modifyOpenPlatformTitleIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [self alertMsg:@"更改云名片标题成功"];
            
            CGSize size = [JBoImageTextTool getStringSize:self.newsTitle withFont:_openPlatformTitleFont_ andContraintSize:CGSizeMake(_openPlatformImageWitdh_, _maxFloat_)];
            size.height += 5.0;
            self.info.titleHeight = MAX(size.height, _openPlatfromTitleHeight_);
            self.info.title = self.newsTitle;
            self.info.price = self.price;
            
            if([self.delegate respondsToSelector:@selector(openPlatformModityTitleController:didFinishWithNewTitle:)])
            {
                [self.delegate openPlatformModityTitleController:self didFinishWithNewTitle:self.newsTitle];
            }
            [self back];
        }
        else
        {
            [self alertNetworkMsg:@"更改云名片标题失败"];
        }
        return;
    }
}

#pragma mark- 加载视图

- (void)finish
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    if([NSString isEmpty:self.textView.text])
    {
        [self alertMsg:[NSString stringWithFormat:@"%@不能为空", self.textView.placeholder]];
        return;
    }
    
    if(self.info.type == _openPlatformTypeMall_)
    {
        if([NSString isEmpty:self.priceTextField.text])
        {
            [self alertMsg:@"价格不能为空"];
            return;
        }
        
        float price = [self.priceTextField.text floatValue];
        if(price == 0)
        {
            [self alertMsg:@"请输入商品价格"];
            return;
        }
        self.price = price;
    }
    
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    
    self.isRequesting = YES;

    self.newsTitle = _textView.text;
    _httpRequest.identifier = _modifyOpenPlatformTitleIdentifier_;
    [_httpRequest downloadWithURL:[JBoOpenPlatformOperation modifyOpenPlatformTitle] dic:[JBoOpenPlatformOperation modifyOpenPlatformTitleParamWithId:self.info.Id title:self.newsTitle imageNumAfterTitle:0 price:self.price]];
}

- (void)back
{
    self.isRequesting = NO;
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    //文本输入框
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
    view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    
    CGFloat buttonWidth = 60.0;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitle:@"完成" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
    [view addSubview:button];
    
    SSTextView *textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2, 60.0)];
    textView.layer.cornerRadius = 6;
    textView.layer.borderWidth = 0.2;
    textView.inputAccessoryView = view;
    textView.layer.borderColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0].CGColor;
    textView.font = [UIFont systemFontOfSize:17];
    textView.textColor = [UIColor blackColor];
    textView.inputAccessoryView = view;
    
    textView.delegate = self;

    textView.font = _openPlatformTitleFont_;
    textView.limitable = YES;
    textView.maxCount = _inputFormatOpenplatformTitle_;
    textView.text = self.info.title;
    textView.placeholder = @"标题";
    textView.placeholderOffset = CGPointMake(2.0, 8.0);
 
    [self.view addSubview:textView];
    self.textView = textView;
    [textView release];
    [view release];
    
    //商品价格
    if(self.info.type == _openPlatformTypeMall_)
    {
        textView.placeholder = @"商品名称";
        
        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(textView.left, textView.bottom + 10.0, textView.width, 40.0)];
        textField.borderStyle = UITextBorderStyleNone;
        textField.layer.cornerRadius = self.textView.layer.cornerRadius;
        textField.layer.masksToBounds = YES;
        textField.placeholder = @"价格(元)";
        textField.backgroundColor = self.textView.backgroundColor;
        textField.font = self.textView.font;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.inputAccessoryView = self.textView.inputAccessoryView;
        
//        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 20.0, textField.height)];
//        label.textColor = textField.textColor;
//        label.font = textField.font;
//        label.textAlign = JBoTextAlignmentCenter;
//        label.text = @"￥";
//        textField.leftView = label;
//        [label release];
        
        textField.keyboardType = UIKeyboardTypeDecimalPad;
        textField.text = [NSString stringWithFormat:@"%0.2f", self.info.price];
        [textField addTarget:self action:@selector(priceDidEndEdit:) forControlEvents:UIControlEventEditingDidEnd];
        //[textField addTarget:self action:@selector(priceDidChange:) forControlEvents:UIControlEventEditingChanged];
        [self.view addSubview:textField];
        self.priceTextField = textField;
        [textField release];
        
        //[self priceDidChange:self.priceTextField];
    }
}

//回收键盘
- (void)inputFinish:(id) sender
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

//商品价格改变
- (void)priceDidChange:(UITextField*) textField
{
   if(textField.text.length > 0)
   {
       textField.leftViewMode = UITextFieldViewModeAlways;
   }
   else
   {
       textField.leftViewMode = UITextFieldViewModeNever;
   }
}

- (void)priceDidEndEdit:(UITextField*) textField
{
    if(textField.text.length > 0)
    {
        float price = [textField.text floatValue];
        
        if(price < _inputFormatOpenPlatformMinPrice_)
        {
            price = _inputFormatOpenPlatformMinPrice_;
            textField.text = [NSString stringWithFormat:@"%0.2f", price];
        }
        else if(price > _inputFormatOpenPlatformMaxPirce_)
        {
            price = _inputFormatOpenPlatformMaxPirce_;
            textField.text = [NSString stringWithFormat:@"%0.2f", price];
        }
    }
}

#pragma mark- textView代理

- (void)textViewDidChange:(UITextView *)textView
{
    SSTextView *sst = (SSTextView*)textView;
    [sst textDidChange];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    SSTextView *sst = (SSTextView*)textView;
    return [sst shouldChangeTextInRange:range replacementText:text];
}

@end
