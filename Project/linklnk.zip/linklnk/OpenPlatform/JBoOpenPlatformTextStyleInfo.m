//
//  JBoOpenPlatformTextStyleInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-10-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformTextStyleInfo.h"
#import "JBoBasic.h"
#import <CoreText/CoreText.h>
#import "JBoTextStorage.h"

//范围包含
typedef enum _JBoRangeContainStyle
{
    JBoRangeContainStyleNone = 0, //没有包含
    JBoRangeContainStyleMiddleInner = 1, //中间包含
    JBoRangeContainStyleOuter = 2, //外部包含
    JBoRangeContainStyleLeftCross = 3, //左边交叉
    JBoRangeContainStyleRightCross = 4, //右边交叉
    JBoRangeContainStyleEqual = 5, //完全相等
    JBoRangeContainStyleLeftInner = 6, //左边包含
    JBoRangeContainStyleRightInner = 7, //右边包含
}JBoRangeContainStyle;

@implementation JBoOpenPlatformTextStyleInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.bold = NO;
        self.fontSize = _JBoOpenPlatformTextStyleFontMiddleSize_;
    }
    return self;
}

- (void)dealloc
{
    [_textColor release];
    [_styleName release];
    [_backgroundColor release];
    
    [super dealloc];
}

/**获取范围的字符串
 */
- (NSString*)stringRange
{
    return [NSString stringWithFormat:@"%d%@%d", (unsigned int)self.textRange.location, _openPlatformTextStyleRangeSeprator_, (unsigned int)self.textRange.length];
}

/**获取样式字典
 *@param length 所属文本的长度
 *@param fontSize 需要显示的字体大小
 *@param flag 显示字体的控件是否是使用coreText的
 */
- (NSDictionary*)attributesWithContentLength:(NSInteger)length isCoreText:(BOOL)flag
{
    
    if(self.textRange.length > 0 && (self.textRange.length + self.textRange.location) <= length)
    {
        if(flag)
        {
            UIFont *font = self.bold ? [UIFont boldSystemFontOfSize:self.fontSize] : [UIFont systemFontOfSize:self.fontSize];
            CTFontRef ctFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:(id)ctFont, (NSString*)kCTFontAttributeName, (id)self.textColor.CGColor, (NSString*)kCTForegroundColorAttributeName, nil];
            
//            if(self.backgroundColor != nil)
//            {
//                [dic setObject:self.backgroundColor forKey:JBoBackgroundColorAttributeName];
//            }
            
            CFRelease(ctFont);
            return dic;
        }
        else
        {
            if(_ios6_0_)
            {
#ifdef __IPHONE_6_0
                NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithObjectsAndKeys:self.bold ? [UIFont boldSystemFontOfSize:self.fontSize] : [UIFont systemFontOfSize:self.fontSize], NSFontAttributeName, self.textColor, NSForegroundColorAttributeName, nil];
                
                if(self.backgroundColor != nil)
                {
                    [dic setObject:self.backgroundColor forKey:NSBackgroundColorAttributeName];
                }
                
                return dic;
#endif
            }
            else
            {
                return nil;
            }
            
        }
    }
    return nil;
}

/**是否是默认值 普通字段，黑色
 */
- (BOOL)isDefaultValue
{
    if(!self.bold && [self.textColor isEqualToColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:1.0]] && self.fontSize == _openPlatformTextFontSize_)
    {
        return YES;
    }
    return NO;
}

#pragma mark- class method

/**把重复的样式设置分离出来
 *@param infos 原有的样式，数组元素是 JBoOpenPlatformTextStyleInfo 对象
 */
+ (void)resetWithTextStyleInfos:(NSMutableArray*) infos textLength:(NSInteger)textLength
{
    textLength = MIN(textLength, _inputFormatOpenplatformTextNum_);
    JBoOpenPlatformTextStyleInfo *additionInfo = nil;
    
    NSInteger i = infos.count - 1;
    while (i >= 0)
    {
        JBoOpenPlatformTextStyleInfo *info = [infos objectAtIndex:i];
        
        if(info.textRange.location >= textLength)
        {
            [infos removeObjectAtIndex:i];
        }
        else
        {
            if(info.textRange.location + info.textRange.length - 1 >= textLength)
            {
                info.textRange = NSMakeRange(info.textRange.location, textLength - info.textRange.location);
            }
            
            additionInfo = info;
            break;
        }
        
        i --;
    }
    
    if(infos.count < 2)
        return;
    
    i = infos.count - 2;
    
    //是否已经有内部包含了
    BOOL innerContain = NO;
    
    
    
    while (i >= 0)
    {
        JBoOpenPlatformTextStyleInfo *info = [infos objectAtIndex:i];
        if(info.textRange.location >= textLength)
        {
            [infos removeObjectAtIndex:i];
            continue;
        }

   
        if(info.textRange.location + info.textRange.length - 1 >= textLength)
        {
            info.textRange = NSMakeRange(info.textRange.location, textLength - info.textRange.location);
        }
        
        if(!innerContain)
        {
            JBoRangeContainStyle style = [[self class] isRange:additionInfo.textRange containOtherRange:info.textRange];
            
            switch (style)
            {
                case JBoRangeContainStyleEqual :
                case JBoRangeContainStyleOuter :
                {
                    [infos removeObjectAtIndex:i];
                }
                    break;
                case JBoRangeContainStyleMiddleInner :
                {
                    innerContain = YES;
                    
                    //插在原信息后面
                    JBoOpenPlatformTextStyleInfo *backInfo = [[JBoOpenPlatformTextStyleInfo alloc] init];
                    backInfo.textColor = info.textColor;
                    backInfo.bold = info.bold;
                    backInfo.fontSize = info.fontSize;
                    backInfo.textRange = NSMakeRange(additionInfo.textRange.location + additionInfo.textRange.length, info.textRange.length + info.textRange.location - additionInfo.textRange.length - additionInfo.textRange.location);
                    [infos insertObject:backInfo atIndex:i + 1];
                    [backInfo release];
                    
                    //插在原信息前面
                    JBoOpenPlatformTextStyleInfo *forwordInfo = [[JBoOpenPlatformTextStyleInfo alloc] init];
                    forwordInfo.textColor = info.textColor;
                    forwordInfo.bold = info.bold;
                    forwordInfo.fontSize = info.fontSize;
                    forwordInfo.textRange = NSMakeRange(info.textRange.location, additionInfo.textRange.location - info.textRange.location);
                    [infos replaceObjectAtIndex:i withObject:forwordInfo];
                    [forwordInfo release];
                }
                    break;
                case JBoRangeContainStyleRightInner :
                {
                    info.textRange = NSMakeRange(info.textRange.location,info.textRange.length - additionInfo.textRange.length);
                }
                    break;
                case JBoRangeContainStyleLeftInner :
                {
                    info.textRange = NSMakeRange(additionInfo.textRange.location + additionInfo.textRange.length, info.textRange.length - additionInfo.textRange.length);
                }
                    break;
                case JBoRangeContainStyleRightCross :
                {
                    info.textRange = NSMakeRange(info.textRange.location, additionInfo.textRange.location - info.textRange.location);
                }
                    break;
                case JBoRangeContainStyleLeftCross :
                {
                    info.textRange = NSMakeRange(additionInfo.textRange.location + additionInfo.textRange.length, info.textRange.length - (additionInfo.textRange.length + additionInfo.textRange.location - info.textRange.location));
                }
                    break;
                default:
                    break;
            }
        }
        
        i --;
    }
    
    //删除默认颜色
    i = 0;
    while (i < infos.count)
    {
        JBoOpenPlatformTextStyleInfo *info = [infos objectAtIndex:i];
        if([info isDefaultValue])
        {
            [infos removeObjectAtIndex:i];
            continue;
        }
        i ++;
    }
}

//一个范围是否包含另一个范围
+ (JBoRangeContainStyle)isRange:(NSRange) range containOtherRange:(NSRange) otherRange
{
    if(range.location == otherRange.location && range.length == otherRange.length)
    {
        return JBoRangeContainStyleEqual;
    }
    
    if(range.location + range.length < otherRange.location || range.location > otherRange.location + otherRange.length)
    {
        return JBoRangeContainStyleNone;
    }
    
    if(range.location >= otherRange.location && range.location + range.length <= otherRange.location + otherRange.length)
    {
        if(range.location == otherRange.location)
            return JBoRangeContainStyleLeftInner;
        
        if(range.location + range.length == otherRange.location + otherRange.length)
            return JBoRangeContainStyleRightInner;
        
        return JBoRangeContainStyleMiddleInner;
    }
    
    if(range.location <= otherRange.location && range.location + range.length >= otherRange.location + otherRange.length)
    {
        return JBoRangeContainStyleOuter;
    }
    
    if(range.location < otherRange.location && range.location + range.length >= otherRange.location)
    {
        return JBoRangeContainStyleLeftCross;
    }
    
    if(range.location < otherRange.location + otherRange.length && otherRange.location < range.location)
    {
        return JBoRangeContainStyleRightCross;
    }
    
    return JBoRangeContainStyleNone;
}

/**从字符串中获取范围
 *@param string 字符串
 *@return NSRange范围
 */
+ (NSRange)rangeFromString:(NSString*) string
{
    NSRange range = NSMakeRange(0, 0);
    NSArray *rangeComponents = [string componentsSeparatedByString:_openPlatformTextStyleRangeSeprator_];
    if(rangeComponents.count > 1)
    {
        range = NSMakeRange([[rangeComponents firstObject] integerValue], [[rangeComponents objectAtIndex:1] integerValue]);
    }
    return range;
}

/**文本改变，样式范围修复
 *@param infos 原有的样式，数组元素是 JBoOpenPlatformTextStyleInfo 对象
 *@param 要改变的范围
 *@param text 新的文本
 */
+ (void)adjustTextStyleInfos:(NSMutableArray*) infos WithRange:(NSRange)range replacedText:(NSString *)text
{
    if(infos.count == 0)
        return;
    
    NSInteger length = text.length;
    if(range.length == text.length)
        return;
    
   // NSLog(@"%d,%d",text.length,range.length);
    
    NSRange newRange = NSMakeRange(range.location, length);
    
    NSInteger i = 0;
    while (i < infos.count) {
        JBoOpenPlatformTextStyleInfo *info = [infos objectAtIndex:i];
        JBoRangeContainStyle style = [[self class] isRange:range containOtherRange:info.textRange];
        
        switch (style)
        {
            case JBoRangeContainStyleLeftInner :
            {
               info.textRange = NSMakeRange(info.textRange.location, info.textRange.length - range.length + length);
            }
                break;
            case JBoRangeContainStyleRightInner :
            {
                info.textRange = NSMakeRange(info.textRange.location, info.textRange.length - range.length + length);
            }
                break;
            case JBoRangeContainStyleLeftCross :
            {
                NSInteger corssLength = range.location + range.length - info.textRange.location;
                info.textRange = NSMakeRange(newRange.length + newRange.location, info.textRange.length - corssLength);
            }
                break;
            case JBoRangeContainStyleRightCross :
            {
                NSInteger corssLength = info.textRange.location + info.textRange.length - range.location;
                info.textRange = NSMakeRange(info.textRange.location, info.textRange.length - corssLength);
            }
                break;
            case JBoRangeContainStyleMiddleInner :
            {
                info.textRange = NSMakeRange(info.textRange.location, info.textRange.length - range.length + length);
            }
                break;
            case JBoRangeContainStyleEqual :
            {
                info.textRange = NSMakeRange(info.textRange.location, length);
            }
                break;
            case JBoRangeContainStyleOuter :
            {
                info.textRange = NSMakeRange(0,0);
            }
                break;
            case JBoRangeContainStyleNone :
            {
                if(range.location < info.textRange.location)
                {
                    info.textRange = NSMakeRange(info.textRange.location + length - range.length, info.textRange.length);
                }
                
            }
                break;
            default:
                break;
        }
        
        if(info.textRange.length <= 0)
        {
            [infos removeObjectAtIndex:i];
        }
        else
        {
            i ++;
        }
    }
}

/**样式排序
 *@param infos 原有的样式，数组元素是 JBoOpenPlatformTextStyleInfo 对象
 */
+ (void)sortTextStyleInfos:(NSMutableArray*) infos
{
    [infos sortUsingComparator:^NSComparisonResult(id obj1,id obj2){
        
        JBoOpenPlatformTextStyleInfo *info1 = (JBoOpenPlatformTextStyleInfo*)obj1;
        JBoOpenPlatformTextStyleInfo *info2 = (JBoOpenPlatformTextStyleInfo*)obj2;
        
        if(info1.textRange.location > info2.textRange.location)
        {
            return NSOrderedDescending;
        }
        
        if(info1.textRange.location < info2.textRange.location)
        {
            return NSOrderedAscending;
        }
        
        return NSOrderedSame;
    }];
}

/**从文本中提取样式
 *@param 样式文本attributedString
 *@return 数组元素是 JBoOpenPlatformTextStyleInfo 对象
 */
+ (NSMutableArray*)textStyleInfosFromAttributedString:(NSAttributedString*) attributedString
{
   // NSLog(@"%@", attributedString);
    
    NSMutableArray *infos = [NSMutableArray array];
    [attributedString enumerateAttributesInRange:NSMakeRange(0, attributedString.length) options:NSAttributedStringEnumerationReverse usingBlock:^(NSDictionary *attrs, NSRange range, BOOL *stop){
        
        CGColorRef cgColor = (CGColorRef)[attrs objectForKey:(NSString*)kCTForegroundColorAttributeName];
        CTFontRef ctfont = (CTFontRef)[attrs objectForKey:(NSString*)kCTFontAttributeName];
        
        if(cgColor != NULL && ctfont != NULL)
        {
            UIFont *font = [UIFont fontWithCTFont:ctfont];
            UIColor *color = [UIColor colorWithCGColor:cgColor];
            
            JBoOpenPlatformTextStyleInfo *info = [[JBoOpenPlatformTextStyleInfo alloc] init];
            info.fontSize = font.pointSize;
            info.textColor = color;
            info.textRange = range;
            info.bold = [font isBoldFont];
            
            if(![info isDefaultValue])
            {
                [infos addObject:info];
            }
            [info release];
        }
    }];
    
    return infos;
}

/**默认文本属性
 */
+ (NSDictionary*)defaultOpenPlatformAttributes
{
    UIFont *font = [UIFont systemFontOfSize:_JBoOpenPlatformTextStyleFontMiddleSize_];
    
    UIColor *textColor = [UIColor blackColor];
    
    //换行模式
    CTParagraphStyleSetting lineBreadMode;
    CTLineBreakMode linkBreak = kCTLineBreakByCharWrapping;
    lineBreadMode.spec = kCTParagraphStyleSpecifierLineBreakMode;
    lineBreadMode.value = &linkBreak;
    lineBreadMode.valueSize = sizeof(CTLineBreakMode);
    
    CTParagraphStyleSetting setting[] = {lineBreadMode};
    CTParagraphStyleRef style = CTParagraphStyleCreate(setting, 1);
    
    CTFontRef ctFont = CTFontCreateWithName((CFStringRef)font.fontName, font.pointSize, NULL);
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:(id)textColor.CGColor, (NSString*)kCTForegroundColorAttributeName, (id)ctFont, (NSString*)kCTFontAttributeName, (id)style, (NSString*)kCTParagraphStyleAttributeName, nil];
    
    CFRelease(ctFont);
    CFRelease(style);
    
    return dic;
}

/**支持的字体颜色
 *@return 数组元素是 UIColor
 */
+ (NSArray*)supportedTextColors
{
    return [NSArray arrayWithObjects:
            [UIColor blackColor],
            [UIColor redColor],
            [UIColor orangeColor],
            [UIColor yellowColor],
            [UIColor greenColor],
            [UIColor cyanColor],
            [UIColor blueColor],
            [UIColor purpleColor], nil];
}

/**支持的字体
 *@return 数组元素是 NSString fontName
 */
+ (NSArray*)supportedFontNames
{
    return [NSArray arrayWithObjects:
            [UIFont systemFontOfSize:1.0].fontName,
            [UIFont boldSystemFontOfSize:1.0].fontName, @"Arial-BoldMT", nil];
}

/**支持的字体大小
 *@return 数组元素是 NSNumber floatValue
 */
+ (NSArray*)supportedFontSizes
{
    return [NSArray arrayWithObjects:
            [NSNumber numberWithFloat:13.0],
            [NSNumber numberWithFloat:16.0],
            [NSNumber numberWithFloat:20.0], nil];
}

@end
