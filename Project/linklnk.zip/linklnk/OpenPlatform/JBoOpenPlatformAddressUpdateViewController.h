//
//  JBoOpenPlatformAddressUpdateViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-10-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformInfo;
@class JBoOpenPlatformAddressUpdateViewController;

/**云名片地址信息更新 代理
 */
@protocol JBoOpenPlatformAddressUpdateViewControllerDelegate <NSObject>

- (void)OpenPlatformAddressUpdateViewControllerDidFinish:(JBoOpenPlatformAddressUpdateViewController*) viewController;

@end

/**云名片地址信息更新
 */
@interface JBoOpenPlatformAddressUpdateViewController : JBoViewController

@property(nonatomic,assign) id<JBoOpenPlatformAddressUpdateViewControllerDelegate> delegate;

/**构造方法
 *@param info 云名片信息
 *@return 一个初始化的 JBoOpenPlatformAddressUpdateViewController 对象
 */
- (id)initWithOpenPlatformInfo:(JBoOpenPlatformInfo*) info;

@end
