//
//  JBoOpenPlatformSubscribeCell.h
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _openPlatformSubscribeCellHeight_ 70

/**云名片预约的人列表
 */
@interface JBoOpenPlatformSubscribeCell : UITableViewCell

/**名称
 */
@property(nonatomic,readonly) UILabel *nameLabel;

/**日期
 */
@property(nonatomic,readonly) UILabel *timeLabel;

/**电话号码
 */
@property(nonatomic,readonly) UILabel *telLabel;

@end
