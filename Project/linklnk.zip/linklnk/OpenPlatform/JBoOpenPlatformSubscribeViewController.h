//
//  JBoOpenPlatformSubscribeViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformInfo;

/**预约的人的信息列表
 */
@interface JBoOpenPlatformSubscribeViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>

/**构造方法
 *@param info 云名片信息
 *@return 一个初始化的JBoOpenPlatformSubscribeViewController对象
 */
- (id)initWithOpenPlatformInfo:(JBoOpenPlatformInfo*) info;

@end
