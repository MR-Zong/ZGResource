//
//  JBoLocalAddressBookSyncCell.h
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _localAddressBookSyncCellMargin_ 10.0
#define _localAddressBookSyncCellControlHeight_ 20.0

/**本地通讯录同步到服务器cell
 */
@interface JBoLocalAddressBookSyncCell : UITableViewCell

/**名称
 */
@property(nonatomic,readonly) UILabel *nameLabel;

/**电话号码
 */
@property(nonatomic,readonly) UILabel *phoneNumLabel;

/**备注信息
 */
@property(nonatomic,readonly) UILabel *remarkLabel;

/**是否已存在
 */
@property(nonatomic,assign) BOOL exist;

@end
