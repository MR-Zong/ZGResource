//
//  JBoOpenPlatformReleaseTextInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-10-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoOpenPlatformTextStyleInfo.h"

/**云名片文本内容
 */
@interface JBoOpenPlatformReleaseTextInfo : NSObject

/**文本信息
 */
@property(nonatomic,copy) NSString *text;

/**图片数量
 */
@property(nonatomic,assign) NSInteger imageCount;

/**文本滚动到的位置
 */
@property(nonatomic,assign) CGPoint textOffset;

/**文本样式 数组元素是 JBoOpenPlatformTextStyleInfo对象
 */
@property(nonatomic,retain) NSMutableArray *textStyleInfos;

@end
