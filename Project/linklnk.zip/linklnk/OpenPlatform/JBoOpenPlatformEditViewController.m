//
//  JBoOpenPlatformEditViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-11-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformEditViewController.h"
#import "JBoTextView.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoOpenPlatformTextStyleViewController.h"
#import "JBoOpenPlatformTextStyleInfo.h"
#import "JBoImageTextTool.h"
#import "JBoTextAttachment.h"
#import "JBoFileManager.h"
#import "JBoStraightlineProgressView.h"
#import "JBoUserOperation.h"
#import "JBoTextStorage.h"
#import "JBoTextParagraphInfo.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoColorPickerViewController.h"
#import "JBoTextViewTextInfo.h"

#define _actionSheetImageOperationTag_ 100

@interface JBoOpenPlatformEditViewController ()
<JBoTextViewDelegate,
JBoOpenPlatformTextStyleViewControllerDelegate,
JBoHttpRequestDelegate,
JBoMutiImagePickerDelegate
>

/**选中的位置
 */
@property(nonatomic,assign) NSRange selectedRange;

/**长按操作的图片
 */
@property(nonatomic,retain) JBoTextAttachment *longPressedTextAttachment;

/**图片所在段落下标
 */
@property(nonatomic,assign) NSInteger paragraphIndex;

@end

@implementation JBoOpenPlatformEditViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self)
    {
        self.attachments = [NSMutableArray array];
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        self.httpRequest.showAccurateProgress = YES;
        self.paragraphIndex = NSNotFound;
        self.totalSize = 0;
    }
    
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
        self.textView.editable = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    self.delegate = nil;
    
    [JBoFileManager deleteFiles:_files];
    [_files release];
    [JBoFileManager deleteFiles:_thumbnailFiles];
    [_thumbnailFiles release];
    
    [_textView release];
    
    [_attachments release];
    [_images release];
    [_thumbnails release];
    
    [_httpRequest release];
    [_progressView release];
    
    [_longPressedTextAttachment release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillChangeFrame:) name:UIKeyboardWillChangeFrameNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.textView.editable = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
 
    self.textView.editable = NO;
    [self.textView endEdit];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.progressView.hidden = YES;
    self.isRequesting = NO;

    [JBoFileManager deleteFiles:self.files];
    self.files = nil;
    
    [JBoFileManager deleteFiles:self.thumbnailFiles];
    self.thumbnailFiles = nil;
}

- (void)httpRequest:(JBoHttpRequest *) request didUpdateProgress:(float)progress identifier:(NSString *)identifier
{
    self.progressView.progress = progress * 0.99;
}

#pragma mark- alertView 

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"确定"])
    {
        [self close];
    }
}

#pragma mark- 加载视图

- (void)back
{
    if(self.textView.attributedText.length == 0)
    {
        [self close];
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"确定结束这次编辑？" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
        [alertView show];
        [alertView release];
    }
}

/**退出
 */
- (void)close
{
    self.textView.textDelegate = nil;
    [self.textView endEdit];
    
    [self.appDelegate closeAlertView];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    //
    JBoTextView *textView = [[JBoTextView alloc] initWithFrame:CGRectMake(_margin_, _margin_, _width_ - _margin_ * 2, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _margin_ * 2)];
    textView.textDelegate = self;
    textView.font = [UIFont systemFontOfSize:_openPlatformTextFontSize_];
    textView.maxImageCount = _imageOperationMaxCount_;
    textView.maxCount = _inputFormatOpenplatformTextNum_;
    textView.supportedTextColors = [JBoOpenPlatformTextStyleInfo supportedTextColors];
    textView.supportedFontSizes = [JBoOpenPlatformTextStyleInfo supportedFontSizes];
    textView.supportedFontNames = [JBoOpenPlatformTextStyleInfo supportedFontNames];
    
    [textView setupDefaultInputAccessoryView];
    
    self.textView = textView;
    [textView release];
    
    self.originalTextFrame = self.textView.frame;
}

#pragma mark- 键盘

/**键盘高度改变
 */
- (void)keyboardWillChangeFrame:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    CGRect frame = [[dic objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    frame = [self.view convertRect:frame fromView:nil];
    
    if(frame.origin.y < self.view.height)
    {
        CGFloat keyboardHeight = frame.size.height;
        CGRect frame = self.originalTextFrame;
        frame.size.height -= keyboardHeight;
        self.textView.frame = frame;
    }
    else
    {
        self.textView.frame = self.originalTextFrame;
    }
}

#pragma mark- public method

/**获取编辑器中所有图片图片
 *@return 数组元素是 UIImage 对象
 */
- (NSMutableArray*)getImages
{
    NSArray *attachments = [self.textView attachments];
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:attachments.count];
    for(JBoTextAttachment *attachment in attachments)
    {
        if(attachment.image)
        {
            NSLog(@"%@", NSStringFromRange(attachment.range));
            [array addObject:attachment.image];
        }
    }
    
    return array;
}

/**格式化 文本 获取分段文本和文本后的图片数量
 *@return 数组元素 是JBoOpenPlatformTextInfo
 */
- (NSArray*)getOpenPlatformTextInfos
{
    NSMutableArray *infos = [NSMutableArray array];
    
    NSArray *textInfos = [self.textView getSeparatedTextInfo];
    for(JBoTextViewTextInfo *info in textInfos)
    {
        JBoOpenPlatformTextInfo *textInfo = [[JBoOpenPlatformTextInfo alloc] init];
        textInfo.imageCount = info.imageCount;
        textInfo.content = info.content;
        textInfo.range = info.range;
        
        //获取文本样式
        textInfo.textStyleInfos = [JBoOpenPlatformTextStyleInfo textStyleInfosFromAttributedString:[self.textView.textStorage attributedSubstringFromRange:textInfo.range]];
        
        [infos addObject:textInfo];
        [textInfo release];
    }
    
    return infos;
}

/**获取图片信息
 *@return 数组元素是 JBoOpenPlatformImageInfo对象
 */
- (NSArray*)getOpenPlatformImageInfos
{
    long long fileSize = 0;
    
    NSArray *images = [self getImages];
    self.images = images;
    
    NSMutableArray *imageInfos = [NSMutableArray arrayWithCapacity:images.count];
    if(images.count > 0)
    {
        self.files = [JBoFileManager writeImageInTemporaryFile:images withCompressedScale:_openPlatformImageCompressedScale_];
        
        NSMutableArray *thumbnails = [NSMutableArray arrayWithCapacity:images.count];
        for(UIImage *image in images)
        {
            UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:[JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_openPlatformThumbnailMaxWidth_, _maxFloat_) type:JBoShrinkImageTypeWidth]];
            [thumbnails addObject:thumbnail];
            
            JBoOpenPlatformImageInfo *imageInfo = [[JBoOpenPlatformImageInfo alloc] init];
            imageInfo.width = image.size.width;
            imageInfo.height = image.size.height;
            [imageInfos addObject:imageInfo];
            [imageInfo release];
        }
        self.thumbnails = thumbnails;
        
        NSFileManager *fileManager = [[[NSFileManager alloc] init] autorelease];
        for(NSString *str in self.files)
        {
            if([fileManager fileExistsAtPath:str])
            {
                fileSize += [[fileManager attributesOfItemAtPath:str error:nil] fileSize];
            }
        }
        
        self.thumbnailFiles = [JBoFileManager writeImageInTemporaryFile:thumbnails withCompressedScale:_openPlatformThumbnailCompressedScale_];
        
        for(NSString *str in self.thumbnailFiles)
        {
            if([fileManager fileExistsAtPath:str])
            {
                fileSize += [[fileManager attributesOfItemAtPath:str error:nil] fileSize];
            }
        }
    }
    
    self.totalSize = fileSize;
    return imageInfos;
}

/**获取文本参数
 *@return 上传和修改所需的文本参数 ，文本内容，样式
 */
- (NSDictionary*)textParam
{
    NSArray *textInfos = [self getOpenPlatformTextInfos];
    return [JBoOpenPlatformInfo textParamFromTextInfos:textInfos];
}

/**获取图片参数
 *@return 上传的图片大小集合
 */
- (NSDictionary*)imageParam
{
    NSMutableString *widths = [NSMutableString string];
    NSMutableString *heights = [NSMutableString string];
    
    NSArray *imageInfos = [self getOpenPlatformImageInfos];
    
    if(imageInfos.count > 0)
    {
        for(JBoOpenPlatformImageInfo *imageInfo in imageInfos)
        {
            [widths appendFormat:@"%d%@", imageInfo.width, _openPlatformSeprator_];
            [heights appendFormat:@"%d%@", imageInfo.height, _openPlatformSeprator_];
        }
        
        [widths removeLastCharacter];
        [heights removeLastCharacter];
    }
    
    return [NSDictionary dictionaryWithObjectsAndKeys:widths, _openPlatformWidths_, heights, _openPlatformHeights_, nil];
}

#pragma mark- textView代理

- (void)customTextViewDidInsertImage:(JBoTextView *)textView
{
    if(self.isRequesting)
        return;
    
    self.longPressedTextAttachment = nil;
    self.paragraphIndex = NSNotFound;
    NSInteger count = textView.maxImageCount - [self attachments].count;
    if(count <= 0)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"您最多只能选择%d张图片", (int)self.textView.maxImageCount] message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    self.selectedRange = textView.selectedRange;
    
    [self showImagePickerActionSheet];
}

- (void)customTextView:(JBoTextView *)textView didInsertAttachemtsInWithTextLength:(NSInteger)length
{
//    if(![self.textView isFirstResponder])
//    {
//        [self.textView becomeFirstResponder];
//    }
    
    self.textView.selectedRange = NSMakeRange(MIN(self.selectedRange.location + length, self.textView.text.length), 0);
    self.selectedRange = NSMakeRange(NSNotFound, 0);
}

- (void)customTextViewDidSelectTextStyle:(JBoTextView *)textView
{
    if(self.isRequesting)
        return;
    self.selectedRange = textView.selectedRange;
    //[[UIApplication sharedApplication].keyWindow endEditing:YES];
    self.textView.editable = NO;
    [self.textView endEdit];
    
    JBoOpenPlatformTextStyleViewController *textStyleVC = [[JBoOpenPlatformTextStyleViewController alloc] init];
    textStyleVC.black = self.black;
    textStyleVC.delegte = self;
    [self.navigationController pushViewController:textStyleVC animated:YES];
    [textStyleVC release];
}

- (void)customTextView:(JBoTextView *)textView willDeleteAttachments:(NSArray *)attachments
{
    [self.attachments removeObjectsInArray:attachments];
    self.longPressedTextAttachment = nil;
    self.paragraphIndex = NSNotFound;
}

- (void)customTextView:(JBoTextView *)textView didPasteAttachemts:(NSArray *)attachments
{
    [self.attachments addObjectsFromArray:attachments];
}

- (NSArray*)customTextViewDidGetAttachments:(JBoTextView *)textView
{
    return self.attachments;
}

- (void)customTextView:(JBoTextView *)textView WillReplaceAttachemt:(JBoTextAttachment *)attachment withAttachemnt:(JBoTextAttachment *)otherAttachment
{
    if(otherAttachment != nil && attachment != nil)
    {
        NSInteger index = [self.attachments indexOfObject:attachment];
        if(index != NSNotFound)
        {
            [self.attachments replaceObjectAtIndex:index withObject:otherAttachment];
        }
    }
    self.longPressedTextAttachment = nil;
    self.paragraphIndex = NSNotFound;
}

- (void)customTextView:(JBoTextView *)textView didLongPressAttachemt:(JBoTextAttachment *)attachment atParagraphIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    self.paragraphIndex = index;
    self.longPressedTextAttachment = attachment;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"图片操作" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"更改图片", @"删除图片", nil];
    actionSheet.tag = _actionSheetImageOperationTag_;
    actionSheet.destructiveButtonIndex = 1;
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)customTextViewDidUndo:(JBoTextView *)textView
{
    [self.attachments removeAllObjects];
    [self.attachments addObjectsFromArray:[textView attachments]];
}

- (void)customTextViewDidRedo:(JBoTextView *)textView
{
    [self.attachments removeAllObjects];
    [self.attachments addObjectsFromArray:[textView attachments]];
}

#pragma mark- JBoOpenPlatformTextStyleViewController 代理

- (void)openPlatformTextStyleDidSelect:(JBoOpenPlatformTextStyleViewController *)viewController
{
    viewController.selectedTextStyleInfo.textRange = self.selectedRange;
    [self.textView addAttributes:[viewController.selectedTextStyleInfo attributesWithContentLength:self.textView.text.length isCoreText:YES] range:self.selectedRange];
    self.selectedRange = NSMakeRange(NSNotFound, 0);
}

#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(actionSheet.tag == _actionSheetImageOperationTag_)
    {
        switch (buttonIndex)
        {
            case 0 :
            {
                [self showImagePickerActionSheet];
            }
                break;
            case 1 :
            {
                [self.textView replaceAttachment:self.longPressedTextAttachment withAttachment:nil paragraphIndex:self.paragraphIndex];
                self.longPressedTextAttachment = nil;
            }
                break;
            default:
            {
                self.longPressedTextAttachment = nil;
                self.paragraphIndex = NSNotFound;
            }
                break;
        }
    }
    else
    {
        switch (buttonIndex)
        {
            case 0:
            {
                [self getCamera];
            }
                break;
            case 1 :
            {
                [self getPhotos];
            }
                break;
            case 2 :
            {
                JBoColorPickerViewController *colorPicker = [[JBoColorPickerViewController alloc] init];
                colorPicker.delegate = self;
                colorPicker.black = self.black;
                colorPicker.type = JBoImageEditorOperationTypeSaveAndUse;
                [colorPicker showInViewController:self animated:YES completion:nil];
                [colorPicker release];
            }
                break;
            default:
                break;
        }
    }
}

//图片选择
- (void)showImagePickerActionSheet
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"图片添加文字请在选中状态点击超图+" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", @"纯色背景文字", nil];
    [actionSheet showInView:self.navigationController.view];
    [actionSheet release];
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机无法拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^(void){
        
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:retImage withSize:size];
        
        JBoTextAttachment *attachment = [self.textView attachmentWithImage:thumbnail];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 if(attachment)
                 {
                     [self operationAttachments:[NSArray arrayWithObject:attachment]];
                 }
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [self.appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

#pragma mark- 相册

//发送图片 打开相册选着图片
- (void)getPhotos
{
    NSInteger count = (self.longPressedTextAttachment != nil && self.paragraphIndex != NSNotFound) ? 1 : self.textView.maxImageCount - self.attachments.count;
    
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)count;
    mutilImagePicker.title = @"相册";
    [mutilImagePicker showInViewController:self animated:YES completion:nil];
    
    [mutilImagePicker release];
}


- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       NSMutableArray *attachments = [NSMutableArray arrayWithCapacity:assetArray.count];
                       if(assetArray.count > 0)
                       {
                           for(ALAsset *asset in assetArray)
                           {
                               UIImage *image = [UIImage imageFromAsset:asset];
                               CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                               
                               UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
                               JBoTextAttachment *attachment = [self.textView attachmentWithImage:thumbnail];
                               if(attachment)
                               {
                                   [attachments addObject:attachment];
                               }
                           }
                       }
                       
                       dispatch_async(dispatch_get_main_queue(), ^(void){
                           [viewController dismissViewControllerAnimated:YES completion:^(void)
                            {
                                [self operationAttachments:attachments];
                                self.appDelegate.dataLoadingView.hidden = YES;
                            }];
                       });
                   });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
        
        JBoTextAttachment *attachment = [self.textView attachmentWithImage:thumbnail];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 if(attachment)
                 {
                     [self operationAttachments:[NSArray arrayWithObject:attachment]];
                 }
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}

#pragma mark- private method

//操作附件
- (void)operationAttachments:(NSArray*) attachments
{
    if(attachments.count == 0)
        return;
    if(self.longPressedTextAttachment != nil && self.paragraphIndex != NSNotFound)
    {
        [self.textView replaceAttachment:self.longPressedTextAttachment withAttachment:[attachments firstObject] paragraphIndex:self.paragraphIndex];
    }
    else
    {
        [self.textView insertAttachments:attachments atIndex:self.selectedRange.location];
        [self.attachments addObjectsFromArray:attachments];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
