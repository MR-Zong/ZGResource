//
//  JBoOpenPlatformAddressUpdateViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-10-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformAddressUpdateViewController.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoOpenPlatformOperation.h"
#import "JBoLocationSelectView.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"

@interface JBoOpenPlatformAddressUpdateViewController ()<JBoHttpRequestDelegate>

//位置
@property(nonatomic,retain) JBoLocationSelectView *locationSelected;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

//云名片信息
@property(nonatomic,retain) JBoOpenPlatformInfo *info;

@end

@implementation JBoOpenPlatformAddressUpdateViewController

/**构造方法
 *@param info 云名片信息
 *@return 一个初始化的 JBoOpenPlatformAddressUpdateViewController 对象
 */
- (id)initWithOpenPlatformInfo:(JBoOpenPlatformInfo*) info
{
    self = [super initWithNibName:nil bundle:nil];
    if(self)
    {
        self.info = info;
        
        if(self.info.addrInfo)
        {
            self.title = @"更改地址";
        }
        else
        {
            self.title = @"添加地址";
        }
        
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
    }
    
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
        self.locationSelected.userInteractionEnabled = !_isRequesting;
    }
}

#pragma mark- 视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.locationSelected viewWillDisappear];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.locationSelected viewWillAppear];
}

#pragma mark- dealloc

- (void)dealloc
{
    self.delegate = nil;
    [_locationSelected release];
    [_httpRequest release];
    [_info release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    [self alertNetworkMsg:[NSString stringWithFormat:@"%@失败", self.title]];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([JBoUserOperation isSuccess:data])
    {
        [self alertMsg:[NSString stringWithFormat:@"%@成功", self.title]];
        
        self.info.addrInfo = [self.locationSelected getAddressInfo];
        [self.info caculateAddrHeight];
        
        if([self.delegate respondsToSelector:@selector(OpenPlatformAddressUpdateViewControllerDidFinish:)])
        {
            [self.delegate OpenPlatformAddressUpdateViewControllerDidFinish:self];
        }
        [self back];
    }
    else
    {
        [self alertNetworkMsg:[NSString stringWithFormat:@"%@失败", self.title]];
    }
}

#pragma mark- 加载视图

- (void)back
{
    self.isRequesting = NO;
    [self.locationSelected viewWillDisappear];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)finish
{
    if([self.locationSelected getAddressInfo] == nil)
    {
        [self alertMsg:@"请选择位置"];
        return;
    }
    
    self.isRequesting = YES;
    [self.httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOpenPlatformAddress] dic:[JBoOpenPlatformOperation updateOpenPlatformAddressParamWithId:self.info.Id addrInfo:[self.locationSelected getAddressInfo]]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    CGFloat padding = 10.0;
    
    //位置
    JBoLocationSelectView *loc = [[JBoLocationSelectView alloc] initWithFrame:CGRectMake(padding, 30.0, _width_ - padding * 2, 0)];
    loc.layer.cornerRadius = 5.0;
    loc.layer.masksToBounds = YES;
    loc.navigationController = self.navigationController;
    loc.black = self.black;
    [self.view addSubview:loc];
    self.locationSelected = loc;
    [loc release];
}

@end
