//
//  JBoCloudAddressBookCell.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookCell.h"
#import "JBoBasic.h"
#import "JBoImageTitleView.h"

#define _arrowSize_ 10.0

#pragma mark- sectionHeader

#ifdef __IPHONE_6_0

@implementation JBoCloudAddressBookHeader

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if(self)
    {
        //背景
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookHeaderHeight_)];
        bgView.backgroundColor = [UIColor whiteColor];
        self.backgroundView = bgView;
        [bgView release];
        
        _headerView = [[JBoCloudAddressBookHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookHeaderHeight_)];
        _headerView.sectionHeader = self;
        [self.contentView addSubview:_headerView];
    }
    return self;
}

- (void)dealloc
{
    [_headerView release];
    
    [super dealloc];
}

@end

#endif

@implementation JBoCloudAddressBookHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //背景
        self.backgroundColor = [UIColor whiteColor];
        
        //添加点击手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
        [self addGestureRecognizer:tap];
        [tap release];
        
        _rightIndicateIcon = [[JBoArrowPointingView alloc] initWithFrame:CGRectMake(_cloudAddessBookInterval_, (_cloudAddressBookHeaderHeight_ - _arrowSize_) / 2.0, _arrowSize_, _arrowSize_)];
        [self addSubview:_rightIndicateIcon];
        
        CGFloat countWidth = 60.0;
        _countLabel = [[UILabel alloc] initWithFrame:CGRectMake(_width_ - _cloudAddessBookInterval_ - countWidth, 0, countWidth, _cloudAddressBookHeaderHeight_)];
        _countLabel.backgroundColor = [UIColor clearColor];
        _countLabel.textAlign = JBoTextAlignmentRight;
        _countLabel.textColor = [UIColor grayColor];
        _countLabel.font = [UIFont systemFontOfSize:13.0];
        [self addSubview:_countLabel];
        
        
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_rightIndicateIcon.right + _cloudAddessBookInterval_, 0, _countLabel.left - _rightIndicateIcon.right - _cloudAddessBookInterval_ * 2, _cloudAddressBookHeaderHeight_)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.textColor = [UIColor blackColor];
        _nameLabel.font = [UIFont boldSystemFontOfSize:15.0];
        [self addSubview:_nameLabel];
        
        CGFloat lineHeight = _defaultSeparatorLineSize_;
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height - lineHeight, _width_, lineHeight)];
        lineView.backgroundColor = _defaultSeparatorLineColor_;
        [self addSubview:lineView];
        [lineView release];
    }
    return self;
}

- (void)dealloc
{
    self.sectionHeader = nil;
    self.delegate = nil;
    
    [_rightIndicateIcon release];
    [_nameLabel release];
    [_countLabel release];
    
    [super dealloc];
}

- (void)handleTap:(UITapGestureRecognizer*) tap
{
    [self touchBegan];
    _rightIndicateIcon.selected = !_rightIndicateIcon.selected;
    if(_rightIndicateIcon.selected)
    {
        if([self.delegate respondsToSelector:@selector(headerDidOpenAtSection:)])
        {
            [self.delegate headerDidOpenAtSection:self.section];
        }
    }
    else
    {
        if([self.delegate respondsToSelector:@selector(headerDidCloseAtSection:)])
        {
            [self.delegate headerDidCloseAtSection:self.section];
        }
    }
    [self touchEnded];
}

@end

@implementation JBoCloudAddressBookFirstHeader

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if(self)
    {
        //背景
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookFirstHeaderHeight_)];
        bgView.backgroundColor = [UIColor whiteColor];
        self.backgroundView = bgView;
        [bgView release];
        
        _headerView = [[JBoCloudAddressBookFirstHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _cloudAddressBookFirstHeaderHeight_)];
        [self.contentView addSubview:_headerView];
    }
    return self;
}

@end

@implementation JBoCloudAddressBookFirstHeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor whiteColor];
        
        CGFloat width = self.width / 4.0;
        CGFloat height = self.height;
        CGFloat y = 0;
        CGFloat x = 0;
        
        UIFont *font = [UIFont systemFontOfSize:14.0];
        UIColor *textColor = [UIColor blackColor];
        
        JBoImageTitleView *btn = [[JBoImageTitleView alloc] initWithFrame:CGRectMake(x, y, width, height) image:[UIImage imageNamed:@"openPlatform_group"] title:@"分组"];
        btn.titleLabel.font = font;
        btn.titleLabel.textColor = textColor;
        [btn addTarget:self action:@selector(groupManager:)];
        [self addSubview:btn];
        [btn release];
        x = btn.right;
        
        btn = [[JBoImageTitleView alloc] initWithFrame:CGRectMake(x, y, width, height) image:[UIImage imageNamed:@"openPlatform_security"] title:@"安全"];
        btn.titleLabel.font = font;
        btn.titleLabel.textColor = textColor;
        [btn addTarget:self action:@selector(problemManager:)];
        [self addSubview:btn];
        [btn release];
        x = btn.right;
        
        btn = [[JBoImageTitleView alloc] initWithFrame:CGRectMake(x, y, width, height) image:[UIImage imageNamed:@"openPlatform_share"] title:@"共享"];
        btn.titleLabel.font = font;
        btn.titleLabel.textColor = textColor;
        [btn addTarget:self action:@selector(share:)];
        [self addSubview:btn];
        [btn release];
        x = btn.right;
        
        btn = [[JBoImageTitleView alloc] initWithFrame:CGRectMake(x, y, width, height) image:[UIImage imageNamed:@"openPlatform_sync"] title:@"同步"];
        btn.titleLabel.font = font;
        btn.titleLabel.textColor = textColor;
        [btn addTarget:self action:@selector(syncToLocalAddressBook:)];
        [self addSubview:btn];
        [btn release];
       // x = btn.right;
        
//        btn = [[JBoImageTitleView alloc] initWithFrame:CGRectMake(x, y, width, height) image:[UIImage imageNamed:@"openPlatform_sync"] title:@"手机"];
//        btn.titleLabel.font = font;
//        btn.titleLabel.textColor = textColor;
//        [btn addTarget:self action:@selector(syncToServer:)];
//        [self addSubview:btn];
//        [btn release];
        
        CGFloat lineHeight = _defaultSeparatorLineSize_;
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height - lineHeight, _width_, lineHeight)];
        lineView.backgroundColor = _defaultSeparatorLineColor_;
        [self addSubview:lineView];
        [lineView release];
    }
    return self;
}

- (void)groupManager:(id) sender
{
    if([self.delegate respondsToSelector:@selector(headerGroupManagerAtSection:)])
    {
        [self.delegate headerGroupManagerAtSection:self.section];
    }
}

- (void)problemManager:(id) sender
{
    if([self.delegate respondsToSelector:@selector(headerProblemManagerAtSection:)])
    {
        [self.delegate headerProblemManagerAtSection:self.section];
    }
}

- (void)share:(id) sender
{
    if([self.delegate respondsToSelector:@selector(headerDidShareCloudAddressBookAtSection:)])
    {
        [self.delegate headerDidShareCloudAddressBookAtSection:self.section];
    }
}

- (void)syncToLocalAddressBook:(id) sender
{
    if([self.delegate respondsToSelector:@selector(headerDidSyncLocalAddressBookAtSection:)])
    {
        [self.delegate headerDidSyncLocalAddressBookAtSection:self.section];
    }
}

- (void)syncToServer:(id) sender
{
    if([self.delegate respondsToSelector:@selector(headerDidSyncToServerAtSection:)])
    {
        [self.delegate headerDidSyncToServerAtSection:self.section];
    }
}

@end

#pragma mark- cell

@implementation JBoCloudAddressBookCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        CGFloat height = _cloudAddressBookCellHeight_ - _cloudAddessBookInterval_ * 2;
        CGFloat width = _cloudAddressBookPhoneIconSize_;
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_cloudAddessBookInterval_, _cloudAddessBookInterval_, height, height)];
        [self.contentView addSubview:_headImageView];
        
        CGFloat contentWith = _width_ - _headImageView.right - _cloudAddessBookInterval_ * 3 - width;
        CGFloat timeWidth = 110.0;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _cloudAddessBookInterval_, _headImageView.top, contentWith - timeWidth, height / 2.0)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        _timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.right, _nameLabel.top, timeWidth, _nameLabel.height)];
        _timeLabel.backgroundColor = [UIColor clearColor];
        _timeLabel.textColor = _dateTextColor_;
        _timeLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _timeLabel.textAlign = JBoTextAlignmentRight;
        [self.contentView addSubview:_timeLabel];
        
        _phoneNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _nameLabel.bottom, contentWith, height / 2.0)];
        _phoneNumLabel.backgroundColor = [UIColor clearColor];
        _phoneNumLabel.textColor = [UIColor blackColor];
        _phoneNumLabel.font = _cloundAddressBookRemarkFont_;
        [self.contentView addSubview:_phoneNumLabel];
        
        _remarkLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _phoneNumLabel.bottom, contentWith, 0)];
        _remarkLabel.backgroundColor = [UIColor clearColor];
        _remarkLabel.font = _cloundAddressBookRemarkFont_;
        _remarkLabel.numberOfLines = 0;
        _remarkLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_remarkLabel];
        
        
        _phoneStateImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_width_ - width - _cloudAddessBookInterval_, (_cloudAddressBookCellHeight_ - width) / 2.0, width, width)];
        [self.contentView addSubview:_phoneStateImageView];
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_timeLabel release];
    [_phoneStateImageView release];
    [_remarkLabel release];
    [_info release];
    
    [super dealloc];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
     CGFloat height = _cloudAddressBookCellHeight_ - _cloudAddessBookInterval_ * 2;
    
    CGRect frame = self.nameLabel.frame;
    
    if([NSString isEmpty:self.info.remark])
    {
        self.remarkLabel.hidden = YES;
    }
    else
    {
        self.remarkLabel.hidden = NO;
    }
    
    if([NSString isEmpty:self.phoneNumLabel.text])
    {
         frame.size.height = height;
    }
    else
    {
         frame.size.height = height / 2.0;
    }
    
    self.nameLabel.frame = frame;
    self.timeLabel.top = self.nameLabel.top;
    self.phoneNumLabel.top = self.nameLabel.bottom;
    self.remarkLabel.top = self.phoneNumLabel.bottom;
    self.remarkLabel.height = self.info.remarkHeight;

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
