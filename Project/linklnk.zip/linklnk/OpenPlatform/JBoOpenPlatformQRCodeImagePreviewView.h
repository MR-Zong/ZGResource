//
//  JBoOpenPlatformQRCodeImagePreviewView.h
//  linklnk
//
//  Created by kinghe005 on 14-10-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JBoOpenPlatformQRCodeImagePreviewView : UIView

/**构造方法
 *@param frame 视图大小
 *@param image 二维码图片
 *@return 一个 初始化的 JBoOpenPlatformQRCodeImagePreviewView 对象
 */
- (id)initWithFrame:(CGRect) frame image:(UIImage*) image;

- (void)showInView:(UIView*) view;

@end
