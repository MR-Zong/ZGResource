//
//  JBoOpenPlatformViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformViewController;
@class JBoOpenPlatformInfo;

/**云名片信息代理
 */
@protocol JBoOpenPlatformViewControllerDelegate <NSObject>

/**选择某条云名片信息
 */
- (void)openPlatformViewController:(JBoOpenPlatformViewController*) viewController didSelectInfo:(JBoOpenPlatformInfo*) info;

@end

/**云名片信息列表
 */
@interface JBoOpenPlatformViewController : JBoViewController<UITableViewDataSource, UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,UIAlertViewDelegate>

@property(nonatomic,assign) id<JBoOpenPlatformViewControllerDelegate> delegate;

//选中的云名片信息
@property(nonatomic,retain) JBoOpenPlatformInfo *selectedInfo;

//云名片操作类型
@property(nonatomic,assign) JBoOpenPlatformOperationType type;

/**云名片上传预输入文本，目前主要用于 寻宝场景关联云名片
 */
@property(nonatomic,retain) NSAttributedString *preAttributedText;

@end
