//
//  JBoOpenPlatformViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-8-15.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformViewController.h"
#import "JBoHttpRequest.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoOpenPlatformCell.h"
#import "JBoImageCacheTool.h"
#import "JBoReuseScrollView.h"
#import "JBoUserTableHeaderView.h"
#import "JBoUserOperation.h"
#import "JBoCircleBgViewController.h"
#import "JBoDatetimeTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageTextTool.h"
#import "JBoFileManager.h"
#import "JBoOpenPlatformOperation.h"
#import "JBoWebViewController.h"

#import "JBoAddContactViewController.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoOpenPlatformInfoModifyVieController.h"
#import "JBoOpenPlatformWebStyleViewController.h"
#import "JBoReuseScrollInfo.h"

#import "JBoOpenPlatformUploadButton.h"
#import "JBoCheckInputText.h"
#import "JBoOpenPlatformSubscribeViewController.h"

#import "JBoQRCodeOperation.h"
#import "JBoOpenPlatformQRCodeImagePreviewView.h"
#import "JBoOpenPlatformAddressUpdateViewController.h"
#import "JBoOpenPlatformGroupManagerViewController.h"
#import "JBoOpenPlatformGroupInfoViewController.h"
#import "JBoOpenPlatformUploadViewController.h"

#import "JBoOpenPlatformModifyTitleViewController.h"
#import "JBoLinklnkIconView.h"
#import "JBoCustomToolBar.h"
#import "JBoPopupMenu.h"

#import "JBoCloudUsersViewController.h"
#import "JBoOrderListViewController.h"
#import "JBoOpenPlatformOrderButton.h"

static NSString *const updateImage = @"更改这张图片";
static NSString *const removeImage = @"删除这张图片";

static NSString *const addImageBefore = @"在已选图片前面添加";
static NSString *const addImageAfter = @"在已选图片后面添加";

static NSString *const camera = @"拍照";
static NSString *const album = @"相册";

static NSString *const removeOpenPlatformInfo = @"删除";

static NSString *const removeOpenPlatformTextInfo = @"删除文本";

static NSString *const updateOrder = @"更新至首位";

static NSString *const moveOrder = @"移动位置";

static NSString *const linkManager = @"链接管理";

static NSString *const openLinkURL = @"打开链接";
static NSString *const addLinkCloundURL = @"添加云名片链接";
static NSString *const addCustomerLink = @"添加自定义链接";

static NSString *const removeLinkCloundURL = @"删除链接";
static NSString *const updateToLinkCloundURL = @"更改为云名片链接";
static NSString *const updateToCumstomerLink = @"更改为自定义链接";

static NSString *const insertTextAfter = @"在已选文本后面添加";
static NSString *const insertTextBefore = @"在已选文本前面添加";

static NSString *const modifyWebStyle = @"修改";
static NSString *const grouping = @"分组";
static NSString *const groupStick = @"置顶";
static NSString *const cancelGroupStick = @"取消置顶";


@interface JBoOpenPlatformViewController ()
<JBoHttpRequestDelegate,
JBoReuseScrollViewDelegate,
JBoUserTableHeaderViewDelegate,
JBoOpenPlatformCellDelegate,
JBoMutiImagePickerDelegate,
JBoCustomToolBarDelegate,
JBoRosterInfoDelegate,
JBoRealNameAuthenViewControllerDelegate,
JBoOpenPlatformWebStyleViewControllerDelegate,
JBoOpenPlatformAddressUpdateViewControllerDelegate,
JBoOpenPlatformGroupManagerViewControllerDelegate,
JBoOpenPlatformGroupInfoViewControllerDelegate,
JBoOpenPlatformEidtViewControllerDelegate,
JBoOpenPlatformModifyTitleViewControllerDelegate,
JBoPopupMenuDelegate>

//顶部工具条
@property(nonatomic,retain) JBoCustomToolBar *toolBar;

//信息筛选
@property(nonatomic,retain) JBoPopupMenu *popupMenu;

//信息筛选下标
@property(nonatomic,assign) NSInteger filterIndex;

//表示图
@property(nonatomic,retain) UITableView *tableView;

//平台信息 数组元素是 JBoOpenPlatformInfo对象
@property(nonatomic,retain) NSMutableArray *infoArray;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在请求
@property(nonatomic,assign) BOOL isRequesting;

//图片浏览
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;

//所有图片路径 数组元素是 JBoReuseScrollInfo对象
@property(nonatomic,retain) NSMutableArray *imageScrollInfos;

//当前登录的用户信息
@property(nonatomic,retain) JBoUserDetailInfo *myInfo;

//是否还有数据
@property(nonatomic,assign) BOOL hasInfo;

//加载更多
@property(nonatomic,retain) JBoBottomLoadingView *bottomLoadingView;

//没有数据时
@property(nonatomic,retain) UILabel *hasNoInfoLabel;

//平台信息图片集合中要操作的图片的下标
@property(nonatomic,assign) NSInteger selectedIndex;

//选中的平台信息下标
@property(nonatomic,assign) NSInteger selectedInfoIndex;

//要操作的文本信息下标
@property(nonatomic,assign) NSInteger selectedTextInfoIndex;

//要上传的图片文件路径 数组元素是NSString 对象
@property(nonatomic,retain) NSArray *files;

//缩略图 文件路径 数组元素是 NSString 对象
@property(nonatomic,retain) NSArray *thumbnailFiles;

//更新的图片
@property(nonatomic,retain) UIImage *updateImage;

//更新的图片缩略图
@property(nonatomic,retain) UIImage *updateThumbnail;

//云名片链接
@property(nonatomic,copy) NSString *URL;

//开始移动位置
@property(nonatomic,assign) BOOL moveOreder;

//需要移动的cell
@property(nonatomic,copy) NSIndexPath *moveIndexPath;

//移动到的cell
@property(nonatomic,copy) NSIndexPath *moveToIndexPath;

//计算内容高度
@property(nonatomic,retain) JBoImageTextLabel *caculateHeight;

/**云名片样式信息 数组元素是 JBoOpenPlatformWebStyleInfo对象
 */
@property(nonatomic,retain) NSMutableArray *webStyleInfoArray;

/**靓咖标记
 */
@property(nonatomic,retain) UIImage *linkIcon;

/**用户头像
 */
@property(nonatomic,retain) UIImage *userHeadImage;

/**导航栏titleView
 */
@property(nonatomic,retain) UISegmentedControl *seg;

@end

@implementation JBoOpenPlatformViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.type = JBoOpenPlatformOperationTypeDefault;
        self.black = YES;
        self.title = @"云名片";
        self.infoArray = [NSMutableArray array];
        self.myInfo = [JBoUserOperation getUserDetailInfo];

        self.hasInfo = YES;
        
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        
        self.caculateHeight = [[[JBoImageTextLabel alloc] init] autorelease];
        self.caculateHeight.font = _openPlatformTextFont_;
        self.caculateHeight.textInset = _openPlatformTextInset_;
        self.caculateHeight.wordInset = _openPlatformTextWordInset_;
        self.caculateHeight.minLineHeight = _openPlatformTextLineHeight_;
        
        self.webStyleInfoArray = [NSMutableArray array];
    
        //链接分享通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(uploadOpenPlatformInfo:) name:_uploadOpenPlatformInfoNotification_ object:nil];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        if(!_isRequesting)
        {
            self.appDelegate.dataLoadingView.hidden = YES;
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            self.tableView.tableFooterView = nil;
        }
    }
}

//设置二维码标记
- (void)setUserHeadImage:(UIImage *)userHeadImage
{
    if(_userHeadImage != userHeadImage)
    {
        [_userHeadImage release];
        _userHeadImage = [userHeadImage retain];
        [self.tableView reloadData];
    }
}

#pragma mark- 通知

//有新信息上传
- (void)uploadOpenPlatformInfo:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoOpenPlatformInfo *info = [dic objectForKey:_uploadOpenPlatformInfoKey_];
    if([info isKindOfClass:[JBoOpenPlatformInfo class]])
    {
        [self newOpenPlatformInfo:info];
    }
}


#pragma mark-视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    self.navigationController.navigationBar.translucent = NO;
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleDefault];
}


#pragma mark- 内存管理

- (void)dealloc
{
    NSLog(@"JBoOpenPlatformViewController dealloc");
    
    self.delegate = nil;
    [_selectedInfo release];
    [_preAttributedText release];
    
    [_toolBar release];
    [_popupMenu release];
    
    [_tableView release];
    [_infoArray release];
    
    [_httpRequest release];
    
    [_imageScrollView release];
    [_imageScrollInfos release];
    
    [_myInfo release];
    
    [_bottomLoadingView release];
    [_hasNoInfoLabel release];

    [JBoFileManager deleteFiles:_files];
    [_files release];
    
    [JBoFileManager deleteFiles:_thumbnailFiles];
    [_thumbnailFiles release];
    
    [_updateImage release];
    [_updateThumbnail release];
    
    [_moveIndexPath release];
    [_moveToIndexPath release];
    
    [_caculateHeight release];
    
    [_webStyleInfoArray release];
    
    [_linkIcon release];
    [_userHeadImage release];
    
    [_seg release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_uploadOpenPlatformInfoNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_removeOneImageAtOpenPlatformIdentifier_])
    {
        [self alertNetworkMsg:@"删除图片失败"];
        return;
    }
    
    if([identifier isEqualToString:_updateOneImageAtOpenPlatformIdentifier_])
    {
        [JBoFileManager deleteFiles:self.files];
        self.files = nil;
        
        [JBoFileManager deleteFiles:self.thumbnailFiles];
        self.thumbnailFiles = nil;

        [self alertNetworkMsg:@"更改图片失败"];
        
        self.updateThumbnail = nil;
        self.updateImage = nil;
    
        return;
    }
    
    if([identifier isEqualToString:_getUserOpenPlatformInfoIdentifier_])
    {
        if(self.tableView)
        {
            [self alertNetworkMsg:@"获取信息失败"];
            [self infoIsNull];
        }
        else
        {
            [self failToLoadDataFromNetworkWithAlertMessage:nil];
        }
        
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformInfoIdentifier_])
    {
        [self alertNetworkMsg:@"删除信息失败"];
        return;
    }
    
    if([identifier isEqualToString:_modifyOpenPlatformInfoVisibleIdentifier_])
    {
        [self alertNetworkMsg:@"修改可见范围失败"];
        return;
    }
    
    if([identifier isEqualToString:_setupOpenPlatformInfoStickIdentifier_])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        if(info.stick)
        {
            [self alertNetworkMsg:@"取消置顶失败"];
        }
        else
        {
            [self alertNetworkMsg:@"置顶失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_updateOpenPlatformInfoOrderIdentifier_])
    {
        [self alertNetworkMsg:@"更新至首位失败"];
        return;
    }
    
    if([identifier isEqualToString:_moveOpenPlatformInfoOrderIdentifier_])
    {
        self.moveIndexPath = nil;
        self.moveToIndexPath = nil;
        self.moveOreder = NO;
        [self.tableView reloadData];
        [self alertNetworkMsg:@"移动位置失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformInfoImageRelatedURLIdentifier_])
    {
        [self alertNetworkMsg:@"删除链接失败"];
        return;
    }
    
    if([identifier isEqualToString:_updateOpenPlatformInfoImageRelatedURLIdentifier_])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        
        JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
        if(![NSString isEmpty:imageInfo.relateURL])
        {
            [self alertNetworkMsg:@"更改链接失败"];
        }
        else
        {
            [self alertNetworkMsg:@"添加链接失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformTextInfoIdentifier_])
    {
        [self alertNetworkMsg:@"删除云名片文本信息失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_removeOneImageAtOpenPlatformIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
            info.contentHeight = NSNotFound;
            
            JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
            
            //删除本地缓存图片
            if(![NSString isEmpty:imageInfo.imageURL])
            {
                [[JBoImageCacheTool sharedInstance] removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.imageURL] thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeDefault];
                [[JBoImageCacheTool sharedInstance] removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.imageURL] thumbnailSize:CGSizeMake(_multiSize_, _multiSize_) cacheType:JBoImageCacheTypeDefault];
            }
            
            if(![NSString isEmpty:imageInfo.thumbnailURL])
            {
                [[JBoImageCacheTool sharedInstance] removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.thumbnailURL] thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeDefault];
                [[JBoImageCacheTool sharedInstance] removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.thumbnailURL] thumbnailSize:CGSizeMake(_multiSize_, _multiSize_) cacheType:JBoImageCacheTypeDefault];
            }
            
            NSInteger textIndex = [info textIndexFromImageIndex:self.selectedIndex index:nil];
            JBoOpenPlatformTextInfo *textInfo = [info.contentInfos objectAtIndex:textIndex];
            textInfo.imageCount --;
            
            //判断文本后面是否没有图片了，没有则合并后面的文本
            if(textInfo.imageCount == 0 && textIndex != info.contentInfos.count - 1)
            {
                JBoOpenPlatformTextInfo *textInfo2 = [info.contentInfos objectAtIndex:textIndex + 1];
                JBoOpenPlatformTextInfo *newTextInfo = [JBoOpenPlatformTextInfo combineInfo:textInfo withOther:textInfo2];
                
                if(newTextInfo.imageCount != 0 || (newTextInfo.content.length > 1 && ![NSString isEmpty:newTextInfo.content]))
                {
                    [info.contentInfos insertObject:newTextInfo atIndex:textIndex];
                }
                
                [info.contentInfos removeObject:textInfo];
                [info.contentInfos removeObject:textInfo2];
            }
            
            if(info.imageInfos.count == 0 && [info canAddTextInfo])
            {
                [info.contentInfos removeAllObjects];
            }
            
            [info.imageInfos removeObjectAtIndex:self.selectedIndex];
            info.contentHeight = NSNotFound;
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
            
            [self.tableView beginUpdates];
            [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
            
            [self alertMsg:@"删除图片成功"];
        }
        else
        {
            [self alertNetworkMsg:@"删除图片失败"];
        }
        
        [self.imageScrollView endRemoveImage];
        
        return;
    }
    
    if([identifier isEqualToString:_updateOneImageAtOpenPlatformIdentifier_])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        
        NSDictionary *updatedDic = [JBoOpenPlatformOperation getUpdaeOneImageFromData:data];
        if(updatedDic != nil)
        {
            info.contentHeight = NSNotFound;
            
            JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
            
            JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
            //删除本地缓存图片
            if(![NSString isEmpty:imageInfo.imageURL])
            {
                [cache removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.imageURL] thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeDefault];
                [cache removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.imageURL] thumbnailSize:CGSizeMake(_multiSize_, _multiSize_) cacheType:JBoImageCacheTypeDefault];
            }
            
            if(![NSString isEmpty:imageInfo.thumbnailURL])
            {
                [cache removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.thumbnailURL] thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeDefault];
                [cache removeCacheImageWithURL:[NSArray arrayWithObject:imageInfo.thumbnailURL] thumbnailSize:CGSizeMake(_multiSize_, _multiSize_) cacheType:JBoImageCacheTypeDefault];
            }
            
            imageInfo.imageURL = [updatedDic objectWithKey:_openPlatformUpdatedImage_];
            imageInfo.thumbnailURL = [updatedDic objectWithKey:_openPlatformUpdateThumbnail_];
            
            [self alertMsg:@"更改图片成功"];
            
            //插入新的图片
            [JBoFileManager moveFiles:self.thumbnailFiles withURLs:[NSArray arrayWithObject:imageInfo.thumbnailURL] suffix:cache.imageSuffix toPath:cache.normalCachePath];
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
            
            [self.tableView beginUpdates];
            [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
            
        }
        else
        {
            [JBoFileManager deleteFiles:self.thumbnailFiles];

            [self alertNetworkMsg:@"更改图片失败"];
        }
        
        [self.imageScrollView endUpdateImage];
        
        [JBoFileManager deleteFiles:self.files];
        self.files = nil;
        self.thumbnailFiles = nil;
        
        self.updateImage = nil;
        self.updateThumbnail = nil;
        
        return;
    }
    
    if([identifier isEqualToString:_getUserOpenPlatformInfoIdentifier_])
    {
        NSArray *array = [JBoOpenPlatformOperation getUserOpenPlatformInfoFromData:data];
        if(array)
        {
            [self.infoArray addObjectsFromArray:array];
            self.hasInfo = array.count >= _openPlatformPageSize_;
        }
        
        
        [self sortInfo];
        
        if(!self.tableView)
        {
            [self loadInitView];
        }
        else
        {
            [self.tableView reloadData];
        }
        
        [self.tableView setExtraCellLineHidden];
        
        [self infoIsNull];
    }
    
    if([identifier isEqualToString:_removeOpenPlatformInfoIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
            
            //删除本地缓存图片
            if(info.imageInfos.count > 0)
            {
                JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
                [cache removeCacheImageWithURL:[JBoOpenPlatformImageInfo getImageURLsFromImageInfos:info.imageInfos] thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeDefault];
            
                [cache removeCacheImageWithURL:[JBoOpenPlatformImageInfo getImageURLsFromImageInfos:info.imageInfos] thumbnailSize:CGSizeMake(_multiSize_, _multiSize_) cacheType:JBoImageCacheTypeDefault];
                
                [cache removeCacheImageWithURL:[JBoOpenPlatformImageInfo getThumbnailURLsFromImageInfos:info.imageInfos] thumbnailSize:CGSizeZero cacheType:JBoImageCacheTypeDefault];
                [cache removeCacheImageWithURL:[JBoOpenPlatformImageInfo getThumbnailURLsFromImageInfos:info.imageInfos] thumbnailSize:CGSizeMake(_multiSize_, _multiSize_) cacheType:JBoImageCacheTypeDefault];
            }
            
            [self.infoArray removeObjectAtIndex:self.selectedInfoIndex];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
            
            [self.tableView beginUpdates];
            [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
            
            NSInteger index = MAX(self.selectedInfoIndex - 1, 0);
            if(index < self.infoArray.count)
            {
                indexPath = [NSIndexPath indexPathForRow:index inSection:0];
                [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
            }
            
            
            [self.tableView setExtraCellLineHidden];
            
            [self alertMsg:@"删除信息成功"];
        }
        else
        {
            [self alertNetworkMsg:@"删除信息失败"];
        }
        [self infoIsNull];
        return;
    }
    
    if([identifier isEqualToString:_modifyOpenPlatformInfoVisibleIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
            if(info.visible == _openPlatformVisibleShow_)
            {
                info.visible = _openPlatformVisibleHide;
            }
            else
            {
                info.visible = _openPlatformVisibleShow_;
            }
            
            if(self.filterIndex != 0)
            {
                [self.infoArray removeObjectAtIndex:self.selectedInfoIndex];
            }

            
            [self.tableView reloadData];
            [self.tableView setExtraCellLineHidden];
        }
        else
        {
            [self alertNetworkMsg:@"修改可见范围失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_setupOpenPlatformInfoStickIdentifier_])
    {
        JBoOpenPlatformInfo *info = [[self.infoArray objectAtIndex:self.selectedInfoIndex] retain];
        
        if([JBoUserOperation isSuccess:data])
        {
            info.stick = !info.stick;
            
            //是否需要重新排序
            BOOL needSort = NO;
            
            if(self.selectedInfoIndex != 0)
            {
                JBoOpenPlatformInfo *stickInfo = [self.infoArray firstObject];
                if(stickInfo.stick)
                {
                    stickInfo.stick = NO;
                  //  stickInfo.contentHeight += _openPlatformDateButtonHeight_;
                    needSort = YES;
                }
            }
            
            [self.infoArray removeObjectAtIndex:self.selectedInfoIndex];
            [self.infoArray insertObject:info atIndex:0];
            
            if(info.stick)
            {
               // info.contentHeight -= _openPlatformDateButtonHeight_;
                [self alertMsg:@"置顶成功"];
            }
            else
            {
                //info.contentHeight += _openPlatformDateButtonHeight_;
                [self alertMsg:@"取消置顶成功"];
                needSort = YES;
            }
            
            //重新排序
            if(needSort)
            {
                [self sortInfo];
            }
            
            [self.tableView reloadData];
        }
        else
        {
            if(info.stick)
            {
                [self alertNetworkMsg:@"取消置顶失败"];
            }
            else
            {
                [self alertNetworkMsg:@"置顶失败"];
            }
        }
        
        [info release];
        return;
    }
    
    if([identifier isEqualToString:_updateOpenPlatformInfoOrderIdentifier_])
    {
        double sortId = [JBoOpenPlatformOperation updateOpenPlatformInfoOrderResultFromData:data];
        if(sortId != 0)
        {
            [self alertMsg:@"更新至首位成功"];
            JBoOpenPlatformInfo *info = [[self.infoArray objectAtIndex:self.selectedInfoIndex] retain];
            info.time = [JBoDatetimeTool getCurrentTime];
            info.sortId = sortId;
            
            NSInteger index = 0;
            
            if(self.infoArray.count > 1)
            {
                JBoOpenPlatformInfo *firstInfo = [self.infoArray firstObject];
                if(firstInfo.stick)
                {
                    index = 1;
                }
                
                [self.infoArray removeObjectAtIndex:self.selectedInfoIndex];
                [self.infoArray insertObject:info atIndex:index];
            }
            
            [self.tableView reloadData];
            
            if(self.infoArray.count > 1)
            {
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
                [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
            }
            
            [info release];
        }
        else
        {
            [self alertNetworkMsg:@"更新至首位失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_moveOpenPlatformInfoOrderIdentifier_])
    {
        double result = [JBoOpenPlatformOperation moveOpenPlatformInfoOrderResultFromData:data];
        if(result != 0)
        {
            [self alertMsg:@"移动位置成功"];
            
            NSIndexPath *moveIndexPath = [self.moveIndexPath copy];
            self.moveIndexPath = nil;
            self.moveOreder = NO;
            [self.tableView reloadData];


            JBoOpenPlatformInfo *moveInfo = [[self.infoArray objectAtIndex:moveIndexPath.row] retain];
            
            //如果要移动的位置在本身位置之前 目标加1
            NSInteger index = self.moveToIndexPath.row;
            if(moveIndexPath.row > self.moveToIndexPath.row)
            {
                index ++;
            }
            NSIndexPath *moveToindexPath = [NSIndexPath indexPathForRow:index inSection:self.moveToIndexPath.section];
            
            [self.infoArray removeObjectAtIndex:moveIndexPath.row];
            
            [self.infoArray insertObject:moveInfo atIndex:moveToindexPath.row];
            
            [moveInfo release];
            
            [self.tableView beginUpdates];
            [self.tableView moveRowAtIndexPath:moveIndexPath toIndexPath:moveToindexPath];
            [self.tableView endUpdates];
            
            [moveIndexPath release];
        }
        else
        {
            self.moveIndexPath = nil;
            self.moveOreder = NO;
            [self.tableView reloadData];
            [self alertNetworkMsg:@"移动位置失败"];
        }
        
        self.moveToIndexPath = nil;
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformInfoImageRelatedURLIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [self alertMsg:@"删除链接成功"];
            
            JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
            JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
            imageInfo.relateURL = nil;
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
            
            [self.tableView beginUpdates];
            [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
        else
        {
            [self alertNetworkMsg:@"删除链接失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_updateOpenPlatformInfoImageRelatedURLIdentifier_])
    {
        NSString *url = [JBoOpenPlatformOperation updateOpenPlatformInfoImageRelatedURLResultFromData:data];
        
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    
        JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
        
        if(url)
        {
            if(![NSString isEmpty:imageInfo.relateURL])
            {
                [self alertMsg:@"更改链接成功"];
            }
            else
            {
                [self alertMsg:@"添加链接成功"];
            }
            
            imageInfo.relateURL = url;
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
            
            [self.tableView beginUpdates];
            [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [self.tableView endUpdates];
        }
        else
        {
            if(![NSString isEmpty:imageInfo.relateURL])
            {
                [self alertNetworkMsg:@"更改链接失败"];
            }
            else
            {
                [self alertNetworkMsg:@"添加链接失败"];
            }
        }
        return;
    }
    
    if([identifier isEqualToString:_removeOpenPlatformTextInfoIdentifier_])
    {
        JBoOpenPlatformInfo *retInfo = [JBoOpenPlatformOperation updatedOpenPlatformInfoFromData:data];
        if(retInfo)
        {
            [self alertMsg:@"删除云名片文本信息成功"];
            JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
            info.contentInfos = retInfo.contentInfos;
            info.contentHeight = NSNotFound;
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
            [_tableView beginUpdates];
            [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        else
        {
            [self alertNetworkMsg:@"删除云名片文本信息失败"];
            return;
        }
    }
}

//排序
- (void)sortInfo
{
    [self.infoArray sortUsingComparator:^(id obj1, id obj2){
        
        JBoOpenPlatformInfo *info1 = (JBoOpenPlatformInfo*)obj1;
        JBoOpenPlatformInfo *info2 = (JBoOpenPlatformInfo*)obj2;
        
        if(info1.stick)
        {
            return (NSComparisonResult)NSOrderedSame;
        }
        
        if(info1.sortId < info2.sortId)
        {
            return (NSComparisonResult)NSOrderedDescending;
        }
        else if(info1.sortId > info2.sortId)
        {
            return (NSComparisonResult)NSOrderedAscending;
        }
        else
        {
            return (NSComparisonResult)NSOrderedSame;
        }
    }];
}

#pragma mark- toolBar代理

- (void)toolBar:(JBoCustomToolBar *)toolBar didSelectedAtIndex:(NSInteger)index
{
    switch (index)
    {
        case 0 :
        {
            if(!self.popupMenu)
            {
                JBoPopupMenu *menu = [[JBoPopupMenu alloc] initWithStyle:JBoPopupMenuStylePlainText];
                menu.delegate = self;
                menu.enableLongPressGesture = NO;
                NSMutableArray *items = [NSMutableArray arrayWithObjects:
                                         [JBoPopupMenuItem menuItemWithIcon:nil title:@"全部"],
                                         [JBoPopupMenuItem menuItemWithIcon:nil title:@"公开"],
                                         [JBoPopupMenuItem menuItemWithIcon:nil title:@"隐藏"],nil];
                menu.menuItems = items;
                menu.tintColor = self.toolBar.backgroundColor;
                menu.menuTitleColor = [UIColor blackColor];
                self.popupMenu = menu;
                [menu release];
            }
            
            self.popupMenu.hidden = NO;
            [self.popupMenu showInView:self.view relatedRect:CGRectMake(0, self.toolBar.top, self.toolBar.width / 2, self.toolBar.height) animated:YES overlay:YES];
            
        }
            break;
        case 1 :
        {
            JBoOpenPlatformGroupManagerViewController *groupManagerVC = [[JBoOpenPlatformGroupManagerViewController alloc] init];
            groupManagerVC.delegate = self;
            groupManagerVC.black = self.black;
            [self.navigationController pushViewController:groupManagerVC animated:YES];
            [groupManagerVC release];
        }
            break;
        default:
            break;
    }
}

#pragma mark- popuMenu代理

- (void)popupMenu:(JBoPopupMenu *)menu didSelectedAtIndex:(NSInteger)index
{
    if(index == self.filterIndex)
        return;
    self.filterIndex = index;
    
    JBoPopupMenuItem *item = [menu.menuItems objectAtIndex:index];
    [self.toolBar setTitle:item.title forIndex:0];
    
    [self.infoArray removeAllObjects];
    [self.tableView reloadData];
    [self.tableView setExtraCellLineHidden];
    [self loadInfo];
    
    [self.popupMenu dismissMenuWithAnimated:YES];
}

- (void)popupMenuDidDismissed:(JBoPopupMenu *)menu
{
    self.popupMenu.hidden = YES;
}

//获取用户平台信息
- (void)loadInfo
{
    if(self.isRequesting)
        return;
    
    NSInteger visible = 0;
    switch (self.filterIndex)
    {
        case 0 :
            visible = NSNotFound;
            break;
        case 1 :
            visible = _openPlatformVisibleShow_;
            break;
        case 2 :
            visible = _openPlatformVisibleHide;
            break;
        default:
            break;
    }
    
    self.isRequesting = YES;
    JBoOpenPlatformInfo *info = [self.infoArray lastObject];
    _httpRequest.identifier = _getUserOpenPlatformInfoIdentifier_;
    
    [_httpRequest downloadWithURL:[JBoOpenPlatformOperation getUserOpenPlatformInfoWithLastId:info.Id rows:_openPlatformPageSize_ visible:visible]];
}

#pragma mark- JBoOpenPlatformEidtViewController 代理

- (void)openPlatformEidtViewController:(JBoOpenPlatformUploadViewController *)viewController didFinishWithInfo:(JBoOpenPlatformInfo *)info
{
    [self newOpenPlatformInfo:info];
}

//有新信息上传
- (void)newOpenPlatformInfo:(JBoOpenPlatformInfo*) info
{
    if(info)
    {
        info.expand = YES;
        NSInteger visible = 0;
        switch (self.filterIndex)
        {
            case 1 :
                visible = _openPlatformVisibleShow_;
                break;
            case 2 :
                visible = _openPlatformVisibleHide;
                break;
            default:
                break;
        }
        
        if(self.filterIndex == 0 || visible == info.visible)
        {
            NSInteger index = 0;
   
            if(self.infoArray.count > 0)
            {
                JBoOpenPlatformInfo *firstInfo = [self.infoArray firstObject];
                if(firstInfo.stick)
                {
                    index = 1;
                }
            }
            
            [self.infoArray insertObject:info atIndex:index];
            [self.tableView reloadData];
            [self.tableView setExtraCellLineHidden];
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
            
            [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
        }
    }
}

#pragma mark- 视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        self.appDelegate.dataLoadingView.hidden = YES;
    }
}


#pragma mark- 加载视图

- (void)back
{
    switch (self.type)
    {
        case JBoOpenPlatformOperationTypeDefault :
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
            break;
        case JBoOpenPlatformOperationTypeScene :
        {
            if([self.delegate respondsToSelector:@selector(openPlatformViewController:didSelectInfo:)])
            {
                [self.delegate openPlatformViewController:self didSelectInfo:self.selectedInfo];
            }
            [self dismissViewControllerAnimated:YES completion:nil];
        }
            break;
        default:
            break;
    }
    
}

//打开链接
- (void)openLink:(UIGestureRecognizer*) gesture
{
    if([gesture isKindOfClass:[UIGestureRecognizer class]])
    {
        if(gesture.state == UIGestureRecognizerStateBegan)
        {
            if(self.myInfo.rosterInfo.role == _rosterRoleNormal_)
            {
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"你未通过实名认证，无法上传图片到云名片" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"去认证", nil];
                [alertView show];
                [alertView release];
                return;
            }
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请输入网址" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"前往", nil];
            alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
            UITextField *textField = [alertView textFieldAtIndex:0];
            textField.keyboardType = UIKeyboardTypeURL;
            [alertView show];
            [alertView release];
        }
    }
}

//上传图片
- (void)uploadImage
{
    if(self.myInfo.rosterInfo.role == _rosterRoleNormal_)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"云名片%@", realNameAuthenTitle] message:realNameAuthenMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", goToRealNameAuthen, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    JBoOpenPlatformUploadViewController *edit = [[JBoOpenPlatformUploadViewController alloc] init];
    edit.black = self.black;
    edit.preAttributedText = self.preAttributedText;
    edit.styleInfoArray = self.webStyleInfoArray;
    edit.delegate = self;
    [edit showInViewController:self animated:YES completion:nil];
    [edit release];
}

//订单管理
- (void)orderManager
{
    JBoOrderListViewController *orderList = [[JBoOrderListViewController alloc] init];
    orderList.black = self.black;
    [self.navigationController pushViewController:orderList animated:YES];
    [orderList release];
}

//分段选择改变
- (void)valueDidChanged:(UISegmentedControl*) seg
{
    switch (seg.selectedSegmentIndex)
    {
        case 0 :
        {
            
        }
            break;
        case 1 :
        {
            self.seg.selectedSegmentIndex = 0;
            JBoCloudUsersViewController *clound = [[JBoCloudUsersViewController alloc] init];
            clound.black = self.black;
            [self.navigationController pushViewController:clound animated:YES];
            [clound release];
        }
            break;
        case 2 :
        {
            self.seg.selectedSegmentIndex = 0;
            [self orderManager];
        }
            break;
        default:
            break;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.backItem = YES;
 
    self.appDelegate.dataLoadingView.hidden = NO;
    [self loadInfo];
}

- (void)reloadDataFromNetwork
{
    self.appDelegate.dataLoadingView.hidden = NO;
    [self loadInfo];
}

//信息是否为空
- (void)infoIsNull
{
    if(_infoArray.count == 0)
    {
        if(!self.hasNoInfoLabel)
        {
            CGFloat height = _height_ - _navgateBarHeight_ - _statuBarHeight_ - _circelBgImageHeight_- self.toolBar.height;
            UILabel *hasNoInfoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
            hasNoInfoLabel.textColor = [UIColor grayColor];
            hasNoInfoLabel.backgroundColor = [UIColor whiteColor];
            [hasNoInfoLabel setTextAlign:JBoTextAlignmentCenter];
            hasNoInfoLabel.text = @"暂无信息";
            self.hasNoInfoLabel = hasNoInfoLabel;
            [hasNoInfoLabel release];
        }
        
        _tableView.tableFooterView = _hasNoInfoLabel;
    }
    else
    {
        _tableView.tableFooterView = nil;
    }
}

- (void)loadInitView
{
    CGFloat width = 200.0;
    CGFloat height = 30.0;
    
    UIColor *tintColor = [UIColor colorWithWhite:0 alpha:0.7];
    NSDictionary *selectedDic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, [UIFont systemFontOfSize:13.0], UITextAttributeFont, nil];
    NSDictionary *norlmalDic = [NSDictionary dictionaryWithObjectsAndKeys:tintColor, UITextAttributeTextColor, [UIFont systemFontOfSize:13.0], UITextAttributeFont, nil];
    
    self.seg = [[[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"云名片", @"云名片夹", @"订单", nil]] autorelease];
    self.seg.frame = CGRectMake(0, 0, width, height);
    self.seg.tintColor = tintColor;
    [self.seg addTarget:self action:@selector(valueDidChanged:) forControlEvents:UIControlEventValueChanged];
    self.seg.selectedSegmentIndex = 0;
    
    [self.seg setTitleTextAttributes:selectedDic forState:UIControlStateSelected];
    [self.seg setTitleTextAttributes:norlmalDic forState:UIControlStateNormal];
    
    self.navigationItem.titleView = self.seg;

    [self valueDidChanged:self.seg];
    
    //顶部工具条
    NSArray *items = [NSArray arrayWithObjects:[JBoCustomToolBarItem toolBarItemWithTitle:@"全部" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"分组管理" image:nil], nil];
    JBoCustomToolBar *toolBar = [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _defaultToolBarHeight_)  items:items];
    toolBar.separatorLine.top = toolBar.height - toolBar.separatorWidth;
    toolBar.delegate = self;
    [self.view addSubview:toolBar];
    self.toolBar = toolBar;
    [toolBar release];
    
    self.filterIndex = 0;
    
    //上传云名片信息按钮
    JBoOpenPlatformUploadButton *uploadButton = [[JBoOpenPlatformUploadButton alloc] initWithFrame:CGRectMake(0, 0, 25, 35)];
    [uploadButton addTapGestureWithTarget:self action:@selector(uploadImage)];
    [uploadButton addLongPressGestureWithTarget:self action:@selector(openLink:)];
    
    [self setRightBarItemWithCustomView:uploadButton];
    
    [uploadButton release];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, self.toolBar.bottom, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - self.toolBar.bottom) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;

    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
    
    
    JBoUserTableHeaderView *tableHeaderView = [[JBoUserTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tableHeaderViewHeight_)];

    tableHeaderView.nameLabel.text = self.myInfo.rosterInfo.name;

    tableHeaderView.nameLabel.sex = self.myInfo.rosterInfo.sex;
    tableHeaderView.bgImageView.userId = [JBoUserOperation getUserId];
    tableHeaderView.delegate = self;
    tableHeaderView.backgroundColor = [UIColor clearColor];
    tableHeaderView.headImageView.role = self.myInfo.rosterInfo.role;
    
    [tableHeaderView addSeparatorLine];
    
    if(self.myInfo.rosterInfo.image)
    {
        tableHeaderView.headImageView.imageView.image = self.myInfo.rosterInfo.image;
    }
    else
        
    {
        tableHeaderView.headImageView.sex = self.myInfo.rosterInfo.sex;
    }
    
    tableHeaderView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = tableHeaderView;
    [tableHeaderView release];
    
    [self.tableView setExtraCellLineHidden];
    
    
    //获取二维码标
    self.linkIcon = [self getLinklnkIcon];

    self.userHeadImage = [self getUserHeadImageIconFromImage:self.myInfo.rosterInfo.image];
}

/**获取靓咖标记
 */
- (UIImage*)getLinklnkIcon
{
    JBoLinklnkIconView *icon = [[JBoLinklnkIconView alloc] initWithFrame:CGRectMake(0, 0, _defaultLinklnkIconSize_, _defaultLinklnkIconSize_)];
    UIImage *image = [JBoImageTextTool getImageFromView:icon];
    [icon release];
    
    return image;
}

/**获取二维码中间头像标记
 */
- (UIImage*)getUserHeadImageIconFromImage:(UIImage*) image
{
    JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getUserDetailInfo];
    
    JBoUserHeadImageView *headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(0, 0, _defaultImageSize_, _defaultImageSize_)];
    headImageView.role = userDetailInfo.rosterInfo.role;
    
    if(image)
    {
        headImageView.imageView.image = image;
    }
    else
    {
        headImageView.sex = userDetailInfo.rosterInfo.sex;
    }
    
    UIImage *ret = [JBoImageTextTool getImageFromView:headImageView];
    [headImageView release];
    
    return ret;
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (alertView.alertViewStyle)
    {
        case UIAlertViewStyleDefault :
        {
            if(buttonIndex == 1)
            {
                JBoRealNameAuthenViewController *realName = [[JBoRealNameAuthenViewController alloc] init];
                realName.delegate = self;
                realName.black = self.black;
                [self.navigationController pushViewController:realName animated:YES];
                [realName release];
            }
        }
            break;
        case UIAlertViewStylePlainTextInput :
        {
            if(buttonIndex == 1)
            {
                NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
                
                if([title isEqualToString:@"前往"])
                {
                    UITextField *textField = [alertView textFieldAtIndex:0];
                    NSString *url = textField.text;;
                    if([JBoCheckInputText isURL:url])
                    {
                        JBoWebViewController *webVC = [[JBoWebViewController alloc] init];
                        webVC.URL = [NSURL URLWithString:[NSString encodeStr:url]];
                        webVC.black = self.black;
                        [webVC showInViewController:self animated:YES completion:nil];
                        [webVC release];
                    }
                    else
                    {
                        [self alertMsg:@"请输入有效地址"];
                    }
                }
                else if([title isEqualToString:@"确定"])
                {
                    UITextField *textField = [alertView textFieldAtIndex:0];
                    NSString *url = textField.text;;
                    if([JBoCheckInputText isURL:url])
                    {
                        NSRange range = [url rangeOfString:_httpHeader_];
                        NSRange ranges = [url rangeOfString:_httpsHeader_];
                        
                        if((range.length == 0 || range.location == NSNotFound) && (ranges.length == 0 || ranges.location == NSNotFound))
                        {
                            url = [NSString stringWithFormat:@"%@%@",_httpHeader_,url];
                        }
                        
                        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
                        JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
                        
                        self.isRequesting = YES;
                        [_httpRequest startDataLoading];
                        _httpRequest.identifier = _updateOpenPlatformInfoImageRelatedURLIdentifier_;
                        [_httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOpenPlatformInfoImageRelatedURL] dic:[JBoOpenPlatformOperation updateOpenPlatformInfoImageRelatedURLParamWithId:info.Id imageURL:imageInfo.imageURL relatedUserId:nil linkURL:url]];
                    }
                    else
                    {
                        [self alertMsg:@"请输入有效链接"];
                    }
                }
            }
        }
            break;
        default:
            break;
    }
  
}

#pragma mark- JBoRealNameAuthenViewController 代理

- (void)realNameAuthenViewController:(JBoRealNameAuthenViewController *)viweController DidModifyName:(NSString *)name
{
    self.myInfo.rosterInfo.name = name;
    
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:self.myInfo];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:_loginDetailUserInfo_];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark-JBoLookAndTellTableHeaderView代理

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView bgImageDidTapped:(UIView *)view
{
    JBoCircleBgViewController *circleBgVC = [[JBoCircleBgViewController alloc] init];
    [self.navigationController pushViewController:circleBgVC animated:YES];
    [circleBgVC release];
}

- (void)tableHeaderView:(JBoUserTableHeaderView *)tableHeaderView headImageDidTapped:(JBoUserHeadImageView *)headImageView
{
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.black = self.black;
    web.needGetOpenPlatformURL = YES;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

#pragma mark- JBoOpenPlatformGroupManagerViewController代理

- (void)openPlatformGroupManagerViewController:(JBoViewController *)viewController didModifyGroupInfo:(JBoOpenPlatformGroupInfo *)info
{
    for(JBoOpenPlatformInfo *openPlatformInfo in self.infoArray)
    {
        if(info.secondaryInfos.count > 0)
        {
            for(JBoOpenPlatformGroupInfo *subInfo in info.secondaryInfos)
            {
                if(subInfo.Id == openPlatformInfo.groupInfo.Id)
                {
                    openPlatformInfo.groupInfo.superId = info.Id;
                    openPlatformInfo.groupInfo.superName = info.name;
                }
            }
        }
        else
        {
            if(openPlatformInfo.groupInfo.Id == info.Id)
            {
                openPlatformInfo.groupInfo.name = info.name;
            }
        }
    }
    [self.tableView reloadData];
}

- (void)openPlatformGroupManagerViewController:(JBoViewController *)viewController didRemoveGroupInfo:(JBoOpenPlatformGroupInfo *)info
{
    for(JBoOpenPlatformInfo *openPlatformInfo in self.infoArray)
    {
        if(info.secondaryInfos.count == 0)
        {
            if(openPlatformInfo.groupInfo.Id == info.Id)
            {
                openPlatformInfo.groupInfo = nil;
            }
        }
        else
        {
            for(JBoOpenPlatformGroupInfo *goupInfo in info.secondaryInfos)
            {
                if(openPlatformInfo.groupInfo.Id == goupInfo.Id)
                {
                    openPlatformInfo.groupInfo = nil;
                }
            }
        }
    }
    [self.tableView reloadData];
}

#pragma mark- tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    //边距和菜单 样式，分组 详情 的高度
    CGFloat iconHeight = _openPlatformDateInnerPadding_ * 2 + _openPlatformDateButtonHeight_ * 4 + _openPlatformImageCountHeight_;
    
    //没有文本信息的数量
    NSInteger noneContent = 0;

        switch (info.type)
        {
            case _openPlatformTypeLink_ :
            {
                if(info.contentHeight == NSNotFound)
                {
                    info.titleHeight = 0;
                    info.contentHeight = _openPlatformLinkViewHeight_;
                }
                iconHeight -= _openPlatformDateButtonHeight_;
                iconHeight -= _openPlatformImageCountHeight_;
            }
                break;
            default:
            {
                if(info.contentHeight == NSNotFound)
                {
                    //计算标题高度和地址高度
                    [info caculateTitleHeight];
                    [info caculateAddrHeight];
                    
                    //计算内容高度
                    NSInteger count = 0;
                    if(info.contentInfos.count > 0)
                    {
                        CGFloat height = 0;
                        for(NSInteger i = 0;i < info.contentInfos.count;i ++)
                        {
                            JBoOpenPlatformTextInfo *textInfo = [info.contentInfos objectAtIndex:i];
                            self.caculateHeight.attributes = textInfo.textStyleInfos;
                            
                            if(textInfo.content.length > 1 || ![NSString isEmpty:textInfo.content])
                            {
                                CGSize size = [JBoImageTextTool getHeightFromAttributedText:[self.caculateHeight getAttributedTextFromString:textInfo.content] contraintWidth:_openPlatformImageWitdh_ - _openPlatformTextInset_ * 2];
                                CGFloat contentHeight = round(size.height) + _openPlatformTextInset_ * 2 + 2.0;
                                
                                textInfo.contentHeight = contentHeight;
                                height += contentHeight;
                            }
                            else
                            {
                                textInfo.contentHeight = 0;
                                noneContent ++;
                            }
                            
                            NSInteger imageCount = MIN((NSInteger)info.imageInfos.count - count, textInfo.imageCount);
                            
                            
                            if(i == info.contentInfos.count - 1)
                            {
                                imageCount = info.imageInfos.count - count;
                            }
                            
                            if(imageCount < 0)
                            {
                                imageCount = 0;
                            }
                            
                            
                            
                            textInfo.imageHeight = [JBoOpenPlatformMultiTextView imageHeightForImageCount:imageCount];
                            count += textInfo.imageCount;
                            height += textInfo.imageHeight;
                            if(textInfo.imageHeight == 0)
                                noneContent ++;
                        }
                        
                        info.contentHeight = height;
                        if([info canAddTextInfo])
                        {
                            info.contentHeight += _openPlatformAddTextButtonHeight_;
                            noneContent --;
                            if(noneContent < 0)
                                noneContent = 0;
                        }
                    }
                    else
                    {
                        info.contentHeight = _openPlatformAddTextButtonHeight_;
                    }
                }
                
                //有文字，添加文字和图片的间距
                if(info.contentHeight != 0)
                {
                    iconHeight += _openPlatformTextImagePadding_;
                }
                
//                if(info.type == _openPlatformTypeMall_)
//                {
//                    iconHeight += _openPlatfromTitleHeight_;
//                }
            }
                break;
        }
    
    //减少一列菜单
    if(self.type == JBoOpenPlatformOperationTypeScene)
    {
        iconHeight -= _openPlatformDateButtonHeight_;
    }
//
    //每段文件之间的间距
    CGFloat textBoxPadding = 0;
    if(info.contentInfos.count > 1)
    {
        textBoxPadding = (info.contentInfos.count - 1) * _openPlatformTextBoxPadding_ * 2;
        textBoxPadding -= noneContent * _openPlatformTextBoxPadding_;
    }
    
    CGFloat height = info.contentHeight + iconHeight + info.titleHeight + textBoxPadding + info.addrHeight;

    if(!info.expand)
    {
        switch (info.type)
        {
            case _openPlatformTypeImageAndText_ :
            {
                NSInteger imageHeight = [JBoOpenPlatformMultiTextView imageHeightForImageCount:MIN(info.imageInfos.count, 3)];
                height = info.titleHeight + imageHeight + _openPlatformDateInnerPadding_ * 2 + _openPlatformImageCountHeight_;
            }
                break;
            case _openPlatformTypeMall_ :
            {
                NSInteger imageHeight = [JBoOpenPlatformMultiTextView imageHeightForImageCount:MIN(info.imageInfos.count, 3)];
                height = info.titleHeight + imageHeight + _openPlatformDateInnerPadding_ * 2 + _openPlatfromTitleHeight_;
            }
                break;
            default:
                break;
        }
        
        //减少一列菜单
        if(self.type == JBoOpenPlatformOperationTypeScene)
        {
            height += _openPlatformDateButtonHeight_ + _openPlatformTextBoxPadding_;
        }
    }
    
    if(height < _openPlatformQRCodeImageHeight_ + _lookAndTellDateViewDefaultHeight_ + _openPlatformDateInnerPadding_ * 2)
    {
        height = _openPlatformQRCodeImageHeight_ + _lookAndTellDateViewDefaultHeight_ + _openPlatformDateInnerPadding_ * 2;
    }
    
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    JBoOpenPlatformCell *cell = nil;
    
    switch (info.type)
    {
        case _openPlatformTypeLink_ :
        {
            static NSString *linkIdentifier = @"link";
            cell = [tableView dequeueReusableCellWithIdentifier:linkIdentifier];
            if(cell == nil)
            {
                cell = [[[JBoOpenPlatformCell alloc] initWithReuseIdentifier:linkIdentifier cellStyle:JBoOpenPlatformCellStyleLink operationType:self.type] autorelease];
                cell.delegate = self;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }
            
            cell.linkView.htmlTitleLabel.text = info.title;
            
            JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos firstObject];
            NSString *url = imageInfo.thumbnailURL;
            
            if([NSString isEmpty:url])
            {
                url = imageInfo.imageURL;
            }

            [cell.linkView.htmlImageView getImageWithURL:url];
        }
            break;
        case _openPlatformTypeMall_ :
        {
            static NSString *mallIdentifier = @"mall";
            
            cell = [tableView dequeueReusableCellWithIdentifier:mallIdentifier];
            if(cell == nil)
            {
                cell = [[[JBoOpenPlatformCell alloc] initWithReuseIdentifier:mallIdentifier cellStyle:JBoOpenPlatformCellStyleMall operationType:self.type] autorelease];
                cell.delegate = self;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }
            
            cell.canAddTextInfo =  [info canAddTextCount] > 0;
            
            cell.titleLabel.text = info.title;
            cell.multiTextView.info = info;
            [cell.multiTextView reloadData];
            
            [cell.webStyleButton setTitle:info.webStyleInfo.name forState:UIControlStateNormal];
            
            cell.priceLabel.text = [info priceString];
        }
            break;
        default:
        {
            static NSString *imageTextIdentifier = @"imageText";
            
            cell = [tableView dequeueReusableCellWithIdentifier:imageTextIdentifier];
            if(cell == nil)
            {
                cell = [[[JBoOpenPlatformCell alloc] initWithReuseIdentifier:imageTextIdentifier cellStyle:JBoOpenPlatformCellStyleImageText operationType:self.type] autorelease];
                cell.delegate = self;
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
            }
            
            cell.canAddTextInfo =  [info canAddTextCount] > 0;
            
            cell.titleLabel.text = info.title;
            cell.multiTextView.info = info;
            [cell.multiTextView reloadData];
            
            [cell.webStyleButton setTitle:info.webStyleInfo.name forState:UIControlStateNormal];
        }
            break;
    }
    
    if([NSString isEmpty:info.groupInfo.name])
    {
        [cell.groupButton setTitle:@"暂无分组" forState:UIControlStateNormal];
    }
    else
    {
        [cell.groupButton setTitle:[info.groupInfo title] forState:UIControlStateNormal];
    }
    
    cell.info = info;
    if(indexPath.row != 0)
    {
        JBoOpenPlatformInfo *listInfo = [self.infoArray objectAtIndex:indexPath.row - 1];
        cell.dateView.sameDay = [JBoDatetimeTool isOnTheSameDay:listInfo.time otherDay:info.time];
    }
    else
    {
        cell.dateView.sameDay = NO;
    }
    cell.dateView.time = info.time;
    
    cell.showCheckBox = self.moveOreder && !info.stick;
    
    if(self.moveIndexPath != nil && self.moveIndexPath.row == indexPath.row)
    {
        [cell.checkBox checkBoxStateChange:CheckBoxStyleSeclected];
    }
    else
    {
        [cell.checkBox checkBoxStateChange:CheckBoxStyleDefault];
    }
    
    cell.qrCodeImageView.image = info.qrCodeThumbnail;
    cell.isSelectedInfo = self.selectedInfo.Id == info.Id;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [NSThread detachNewThreadSelector:@selector(downloadImageForIndexPath:) toTarget:self withObject:indexPath];
}

#pragma mark- JBoOpenPlatformCell代理

- (void)openPlatformCellDidMove:(JBoOpenPlatformCell *)cell
{
    if(self.isRequesting)
        return;
    
    if(self.moveOreder)
    {
        self.moveOreder = NO;
        [self.tableView reloadData];
    }
    else
    {
        self.moveIndexPath = [self.tableView indexPathForCell:cell];
        
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"移动位置将该信息放在所选信息之后" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:moveOrder, nil];
        [actionSheet showInView:self.view];
        [actionSheet release];
    }
}

- (void)openplatformCellDidSelectedCheckBox:(JBoOpenPlatformCell *)cell
{
    if(self.isRequesting)
        return;
    
    if(cell.checkBox.selected)
    {
        self.isRequesting = YES;
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        self.moveToIndexPath = indexPath;
        
        JBoOpenPlatformInfo *moveInfo = [self.infoArray objectAtIndex:self.moveIndexPath.row];
        JBoOpenPlatformInfo *selectedInfo = [self.infoArray objectAtIndex:self.moveToIndexPath.row];
        
        _httpRequest.identifier = _moveOpenPlatformInfoOrderIdentifier_;
        [_httpRequest startDataLoading];
        [_httpRequest downloadWithURL:[JBoOpenPlatformOperation moveOpenPlatformInfoOrder] dic:[JBoOpenPlatformOperation moveOpenPlatformInfoOrderParamWithMoveId:moveInfo.Id frontSortId:selectedInfo.sortId]];
    }
    else
    {
        self.moveIndexPath = nil;
        self.moveOreder = NO;
        [self.tableView reloadData];
    }
}

- (void)openPlatformCellUpdateOrder:(JBoOpenPlatformCell *)cell
{
    if(self.isRequesting)
        return;
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"更新至首位将该信息放在当前页面首位或置顶信息之后，并更新时间" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:updateOrder, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformCellDidDelete:(JBoOpenPlatformCell *)cell
{
    if(self.isRequesting)
        return;
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定要删除该信息？" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:removeOpenPlatformInfo otherButtonTitles:nil, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformCellSetupVisible:(JBoOpenPlatformCell *)cell
{
    if(self.isRequesting)
        return;
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    [self.httpRequest startDataLoading];
    self.isRequesting = YES;
    self.httpRequest.identifier = _modifyOpenPlatformInfoVisibleIdentifier_;
    NSInteger visible = _openPlatformVisibleShow_;
    if(info.visible == _openPlatformVisibleShow_)
        visible = _openPlatformVisibleHide;
    
    [self.httpRequest downloadWithURL:[JBoOpenPlatformOperation modifyOpenPlatformInfo] dic:[JBoOpenPlatformOperation modifyOpenPlatformInfoParamWithVisible:visible withId:info.Id]];
}

- (void)openPlatformCellSetupStick:(JBoOpenPlatformCell *)cell
{
    if(self.isRequesting)
        return;
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    
    NSString *title = nil;
    NSString *buttonTitle = nil;
    if(info.stick)
    {
        buttonTitle = cancelGroupStick;
        title = @"取消置顶后，该云名片信息将放回原来的位置";
    }
    else
    {
        buttonTitle = groupStick;
        title = @"置顶后，该云名片信息将放在所属分组的首位";
    }
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:title delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:buttonTitle, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didLongPressedImageAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    if(!info.expand)
    {
        return;
    }
    
    self.selectedInfoIndex = indexPath.row;
    self.selectedIndex = index;
    
    UIActionSheet *actionSheet = nil;
    
    if([info canUploadImageCount] > 0)
    {
        actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:linkManager, updateImage, addImageBefore, addImageAfter, removeImage, nil];
        actionSheet.destructiveButtonIndex = 4;
    }
    else
    {
        actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:linkManager, updateImage, removeImage, nil];
        actionSheet.destructiveButtonIndex = 2;
    }
    
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didSelectedImageAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    NSInteger currentIndex = 0;
    
    self.imageScrollInfos = [NSMutableArray array];
    
    for(NSInteger i = 0;i < self.infoArray.count;i ++)
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:i];
        if(info.type == _openPlatformTypeLink_)
            continue;
        
        for(NSInteger j = 0; j < info.imageInfos.count;j ++)
        {
            JBoReuseScrollInfo *scrollInfo = [[JBoReuseScrollInfo alloc] init];
            JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:j];
            
            if(j < info.contentInfos.count)
            {
                JBoOpenPlatformTextInfo *textInfo = [info.contentInfos objectAtIndex:j];
                scrollInfo.titleHeight = [JBoReuseScrollInfo getHeightWithContent:textInfo.content];
                scrollInfo.title = textInfo.content;
            }
            
            scrollInfo.url = imageInfo.thumbnailURL;
            
            [self.imageScrollInfos addObject:scrollInfo];
            [scrollInfo release];
        }
        
        if(i < indexPath.row)
        {
            currentIndex += info.imageInfos.count;
        }
    }
    
    currentIndex += index;
    
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = currentIndex;
    [self.imageScrollView reloadData];
    
    [self.imageScrollView showInViewController:self];
}

- (void)openPlatformCellDidAddImage:(JBoOpenPlatformCell *)cell
{
//    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
//    self.selectedInfoIndex = indexPath.row;
//    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
//    
//    [self uploadImageWithInfo:info selectedIndex:0 position:0];
}

- (void)openPlatformCellDidModifyWebStyle:(JBoOpenPlatformCell *)cell
{
    if(self.myInfo.rosterInfo.role != _rosterRoleEnterprise_)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"只有%@才能修改云名片样式", _rosterGodenUser_] delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"修改云名片样式" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:modifyWebStyle, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didRemoveTextInfoAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    self.selectedTextInfoIndex = index;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"确定要删除这段文本？该操作不可逆" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:removeOpenPlatformTextInfo otherButtonTitles:nil, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didModifyTextInfoAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    self.selectedTextInfoIndex = index;
    
    [self modifyInfoWithType:JBoOpenPlatformEditTypeModifyText position:self.selectedTextInfoIndex imageIndex:0];
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didAddTextInfoAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    self.selectedTextInfoIndex = index;
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    
    if(![info canAddTextInfo])
    {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"文本信息添加的位置" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:insertTextBefore, insertTextAfter, nil];
        [actionSheet showInView:self.view];
        [actionSheet release];
    }
    else
    {
        [self modifyInfoWithType:JBoOpenPlatformEditTypeAddBeforeText position:0 imageIndex:0];
    }
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didSelectURL:(NSURL *)url
{
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.black = self.black;
    web.URL = url;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

- (void)openPlatformCellDidModifyTitle:(JBoOpenPlatformCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
   
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    
    JBoOpenPlatformModifyTitleViewController *modifyTitleVC = [[JBoOpenPlatformModifyTitleViewController alloc] initWithInfo:info];
    modifyTitleVC.black = self.black;
    modifyTitleVC.delegate = self;
    [modifyTitleVC showInViewController:self animated:YES completion:nil];
    [modifyTitleVC release];
}

- (void)openPlatformCellExpandDidChanged:(JBoOpenPlatformCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    [self.tableView beginUpdates];
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView endUpdates];
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    if(!info.expand)
    {
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

- (void)openPlatformCellDidSubscribe:(JBoOpenPlatformCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    JBoOpenPlatformSubscribeViewController *sub = [[JBoOpenPlatformSubscribeViewController alloc] initWithOpenPlatformInfo:info];
    sub.black = self.black;
    [self.navigationController pushViewController:sub animated:YES];
    [sub release];
}

- (void)openPlatformCellDidUpdateAddress:(JBoOpenPlatformCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    self.selectedInfoIndex = indexPath.row;
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    JBoOpenPlatformAddressUpdateViewController *addr = [[JBoOpenPlatformAddressUpdateViewController alloc] initWithOpenPlatformInfo:info];
    addr.black = self.black;
    addr.delegate = self;
    [self.navigationController pushViewController:addr animated:YES];
    [addr release];
}

- (void)openPlatformCell:(JBoOpenPlatformCell *)cell didSelect:(BOOL)select
{
    if(select)
    {
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        self.selectedInfoIndex = indexPath.row;
        self.selectedInfo = [self.infoArray objectAtIndex:indexPath.row];
        [self back];
    }
    else
    {
        self.selectedInfo = nil;
    }
}

- (void)openplatformCellDidSelectQRCodeImage:(JBoOpenPlatformCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    
    JBoOpenPlatformQRCodeImagePreviewView *view = [[JBoOpenPlatformQRCodeImagePreviewView alloc] initWithFrame:CGRectMake(0, _height_, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) image:info.qrCodeImage];
    [view showInView:self.view];
    [view release];
}

- (void)openPlatformCellDidSelectGroup:(JBoOpenPlatformCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    self.selectedInfoIndex = indexPath.row;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"把云名片信息移动到某一分组" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:grouping, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

#pragma mark- JBoOpenPlatformInfoModifyVieController

- (void)modifyInfoWithType:(JBoOpenPlatformEditType) type position:(NSInteger) position imageIndex:(NSInteger) imageIndex
{
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    JBoOpenPlatformInfoModifyVieController *modifyVC = [[JBoOpenPlatformInfoModifyVieController alloc] initWithInfo:info modifyIndex:position imageIndex:(int)imageIndex type:type];
    modifyVC.delegate = self;
    [modifyVC showInViewController:self animated:YES completion:nil];
    [modifyVC release];
}

- (void)openPlatformEidtViewControllerDidFinishModify:(JBoOpenPlatformEditViewController *)viewController
{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
//    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
//    info.expand = YES;
    
    [_tableView beginUpdates];
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
   // [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
}

#pragma mark- JBoOpenPlatformModifyTitleViewController 代理

- (void)openPlatformModityTitleController:(JBoOpenPlatformModifyTitleViewController *)viewController didFinishWithNewTitle:(NSString *)title
{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
    
    [_tableView beginUpdates];
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
}

#pragma mark- JBoOpenPlatformAddressUpdateViewController 代理

- (void)OpenPlatformAddressUpdateViewControllerDidFinish:(JBoOpenPlatformAddressUpdateViewController *)viewController
{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
    
    [_tableView beginUpdates];
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
}

#pragma mark- JBoOpenPlatformWebStyleViewController代理

- (void)openPlatformWebStyleViewController:(JBoOpenPlatformWebStyleViewController *)viewController didSelectInfo:(JBoOpenPlatformWebStyleInfo *)info
{
    JBoOpenPlatformInfo *pInfo = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    pInfo.webStyleInfo.Id = info.Id;
    pInfo.webStyleInfo.name = info.name;
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
    [self.tableView beginUpdates];
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
    [self.tableView endUpdates];
}

#pragma mark- reuseScrollView代理

- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.imageScrollInfos.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    JBoReuseScrollInfo *info = [self.imageScrollInfos objectAtIndex:index];
    
    cell.titleLabel.text = info.title;
    cell.titleLabel.frame = CGRectMake(0, _height_ - info.titleHeight, _width_, info.titleHeight);
    scrollView.titleLabel.text = info.title;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    
    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:info.url forIndex:index];
        }
    }
    
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    JBoReuseScrollInfo *info = [self.imageScrollInfos objectAtIndex:index];
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    if(!image)
    {
        [self downloadImageWithUrl:info.url forIndex:index];
    }
}

- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    self.imageScrollInfos = nil;
    [_tableView reloadData];
    [self.tableView setExtraCellLineHidden];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
   
    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.imageScrollView cellForIndex:index];

        cell.imageView.image = image;
        [self.imageScrollView reloadDataAtIndex:index];
    }];
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView didRemovedImageAtIndex:(NSInteger)index
{
    [self infoIndexForImageIndex:index];
    [scrollView beginRemoveImage];
    [self removeImage];
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView didUpdatedImageAtIndex:(NSInteger)index
{
    [self infoIndexForImageIndex:index];
    [self showImagePickActionSheet];
}

//通过下标获取图片所在的平台信息
- (void)infoIndexForImageIndex:(NSInteger) index
{
    NSInteger count = 0;
    for(NSInteger i = 0;i < self.infoArray.count;i ++)
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:i];
        count += info.imageInfos.count;
        if(count > index)
        {
            self.selectedIndex = index - (count - info.imageInfos.count);
            self.selectedInfoIndex = i;
            break;
        }
    }
}

#pragma mark- actionSheet 代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if([title isEqualToString:album])
    {
        [self getPhotos];
    }
    else if([title isEqualToString:camera])
    {
        [self getCamera];
    }
    else if([title isEqualToString:removeOpenPlatformInfo])
    {
        //删除信息
        self.isRequesting = YES;
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        _httpRequest.identifier = _removeOpenPlatformInfoIdentifier_;
        [_httpRequest startDataLoading];
        [_httpRequest downloadWithURL:[JBoOpenPlatformOperation removeOpenPlatformInfo] dic:[JBoOpenPlatformOperation removeOpenPlatformInfoParamWithId:info.Id]];
    }
    else if([title isEqualToString:removeImage])
    {
        [self removeImage];
    }
    else if([title isEqualToString:updateImage])
    {
        [self showImagePickActionSheet];
    }
    else if([title isEqualToString:addImageBefore])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        
        NSInteger imageIndex = 0;
        NSInteger textIndex = [info textIndexFromImageIndex:self.selectedIndex index:&imageIndex];
        
        [self modifyInfoWithType:JBoOpenPlatformEditTypeAddBeforeImage position:textIndex imageIndex:imageIndex] ;
    }
    else if ([title isEqualToString:addImageAfter])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        NSInteger imageIndex = 0;
        NSInteger textIndex = [info textIndexFromImageIndex:self.selectedIndex index:&imageIndex];
        [self modifyInfoWithType:JBoOpenPlatformEditTypeAddAfterImage position:textIndex imageIndex:imageIndex + 1];
    }
    else if([title isEqualToString:updateOrder])
    {
        //更新至首位
        self.isRequesting = YES;
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        _httpRequest.identifier = _updateOpenPlatformInfoOrderIdentifier_;
        [_httpRequest startDataLoading];
        [_httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOpenPlatformInfoOrder] dic:[JBoOpenPlatformOperation updateOpenPlatformInfoOrderParamWithId:info.Id]];
    }
    else if([title isEqualToString:moveOrder])
    {
        self.moveOreder = YES;
        [self.tableView reloadData];
    }
    else if([title isEqualToString:linkManager])
    {
        [self linkCloundURLOperation];
    }
    else if([title isEqualToString:openLinkURL])
    {
        [self openLinkCloundURL];
    }
    else if([title isEqualToString:addLinkCloundURL])
    {
        [self updateLinkCloundURL];
    }
    else if([title isEqualToString:updateToLinkCloundURL])
    {
        [self updateLinkCloundURL];
    }
    else if([title isEqualToString:addCustomerLink])
    {
        [self updateToCustomerLink];
    }
    else if ([title isEqualToString:updateToCumstomerLink])
    {
        [self updateToCustomerLink];
    }
    else if([title isEqualToString:removeLinkCloundURL])
    {
        [self removeLinkCloundURL];
    }
    else if([title isEqualToString:removeOpenPlatformTextInfo])
    {
        self.isRequesting = YES;
        _httpRequest.identifier = _removeOpenPlatformTextInfoIdentifier_;
        [_httpRequest startDataLoading];
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];

        [_httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOpenPlatformInfo] dic:[JBoOpenPlatformOperation updateOpenPlatformInfoParamWithInfo:info atIndex:self.selectedTextInfoIndex newTextInfos:nil type:JBoOpenPlatformEditTypeDeleteText newImageInfos:nil imageIndex:0]];
    }
    else if([title isEqualToString:insertTextBefore])
    {
        [self modifyInfoWithType:JBoOpenPlatformEditTypeAddBeforeText position:self.selectedTextInfoIndex imageIndex:0];
    }
    else if([title isEqualToString:insertTextAfter])
    {
        [self modifyInfoWithType:JBoOpenPlatformEditTypeAddAfterText position:self.selectedTextInfoIndex imageIndex:0];
    }
    else if ([title isEqualToString:modifyWebStyle])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        
        JBoOpenPlatformWebStyleViewController *webStyle = [[JBoOpenPlatformWebStyleViewController alloc] initWithInfo:info.webStyleInfo infoArray:self.webStyleInfoArray operation:JBoOpenPlatformWebStyleOperationModify];
        webStyle.info = info;
        webStyle.black = self.black;
        webStyle.delegate = self;
        [self.navigationController pushViewController:webStyle animated:YES];
        [webStyle release];
    }
    else if([title isEqualToString:grouping])
    {
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        JBoOpenPlatformGroupInfoViewController *groupInfoVC = [[JBoOpenPlatformGroupInfoViewController alloc] init];
        groupInfoVC.black = self.black;
        groupInfoVC.info = info;
        groupInfoVC.delegate = self;
        [self.navigationController pushViewController:groupInfoVC animated:YES];
        [groupInfoVC release];
    }
    else if([title isEqualToString:cancelGroupStick] || [title isEqualToString:groupStick])
    {
        self.isRequesting = YES;
        [self.httpRequest startDataLoading];
        JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
        self.httpRequest.identifier = _setupOpenPlatformInfoStickIdentifier_;
        [self.httpRequest downloadWithURL:[JBoOpenPlatformOperation setupOpenPlatformInfoStick] dic:[JBoOpenPlatformOperation setupOpenPlatformInfoStick:!info.stick withId:info.Id]];
    }
    else
    {
        self.moveIndexPath = nil;
    }
}

#pragma mark- JBoOpenPlatformGroupInfoViewController代理

- (void)openPlatformGroupInfoViewController:(JBoOpenPlatformGroupInfoViewController *)viewController didSelectGroupInfo:(JBoOpenPlatformGroupInfo *)info
{
    [self.tableView beginUpdates];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.selectedInfoIndex inSection:0];
    [self.tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.tableView endUpdates];
}


#pragma mark- 云名片链接

//云名片链接操作

- (void)linkCloundURLOperation
{
    if(self.isRequesting)
        return;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"该图片可以链接实名认证用户的云名片或关联自定义的链接" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil, nil];
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];

    if(![NSString isEmpty:imageInfo.relateURL])
    {
        [actionSheet addButtonWithTitle:openLinkURL];
        [actionSheet addButtonWithTitle:updateToLinkCloundURL];
        [actionSheet addButtonWithTitle:updateToCumstomerLink];
        NSInteger index = [actionSheet addButtonWithTitle:removeLinkCloundURL];
        actionSheet.destructiveButtonIndex = index;
    }
    else
    {
        [actionSheet addButtonWithTitle:addLinkCloundURL];
        [actionSheet addButtonWithTitle:addCustomerLink];
    }
    
    actionSheet.cancelButtonIndex = [actionSheet addButtonWithTitle:@"取消"];
    
    [actionSheet showInView:self.view];
    [actionSheet release];
}

//更新云名片链接
- (void)updateLinkCloundURL
{
    JBoAddContactViewController *add = [[JBoAddContactViewController alloc] init];
    add.black = self.black;
    add.delegate = self;
    add.operationType = JBoRosterOperationTypeLinkCloundURL;
    [add showInViewController:self.navigationController animated:YES completion:nil];
    [add release];
}

//更新成自定义链接
- (void)updateToCustomerLink
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"请输入链接" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    alertView.alertViewStyle = UIAlertViewStylePlainTextInput;
    UITextField *textField = [alertView textFieldAtIndex:0];
    textField.keyboardType = UIKeyboardTypeURL;
    [alertView show];
    [alertView release];
}

//删除云名片链接
- (void)removeLinkCloundURL
{
    self.isRequesting = YES;
    [_httpRequest startDataLoading];
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
    
    _httpRequest.identifier = _removeOpenPlatformInfoImageRelatedURLIdentifier_;
    [_httpRequest downloadWithURL:[JBoOpenPlatformOperation removeOpenPlatformInfoImageRelatedURL] dic:[JBoOpenPlatformOperation removeOpenPlatformInfoImageRelatedURLParamWithId:info.Id relatedURL:imageInfo.imageURL]];
}

//打开链接
- (void)openLinkCloundURL
{
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
    
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.black = self.black;
    web.URL = [NSURL URLWithString:imageInfo.relateURL];
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

#pragma mark- JBoRosterInfo代理

- (void)viewController:(id)viewController didSelectRosterInfo:(JBoRosterInfo *)rosterInfo
{
    [viewController dismissViewControllerAnimated:YES completion:nil];
    
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
    
    self.isRequesting = YES;
    [_httpRequest startDataLoading];
    _httpRequest.identifier = _updateOpenPlatformInfoImageRelatedURLIdentifier_;
    [_httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOpenPlatformInfoImageRelatedURL] dic:[JBoOpenPlatformOperation updateOpenPlatformInfoImageRelatedURLParamWithId:info.Id imageURL:imageInfo.imageURL relatedUserId:rosterInfo.username linkURL:nil]];
}

#pragma mark- 图片的删除和更新

/**更新图片
 *@param image 要上传的图片
 */
- (void)updateWithImage:(UIImage*) image
{
    if(image == nil)
        return;
    [self.imageScrollView beginUpdateImage];
    self.updateImage = image;
    
    self.isRequesting = YES;
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];

    self.files = [JBoFileManager writeImageInTemporaryFile:[NSArray arrayWithObject:image] withCompressedScale:_openPlatformImageCompressedScale_];
    
    UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:[JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_openPlatformThumbnailMaxWidth_, _maxFloat_) type:JBoShrinkImageTypeWidth]];
    self.updateThumbnail = thumbnail;
    
    self.thumbnailFiles = [JBoFileManager writeImageInTemporaryFile:[NSArray arrayWithObject:thumbnail] withCompressedScale:_openPlatformThumbnailCompressedScale_];
    
    JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:self.selectedIndex];
    
    NSDictionary *dic = [JBoOpenPlatformInfo imageParamFromImageInfos:info.imageInfos];
    
    _httpRequest.startImmediately = NO;
    [_httpRequest startDataLoading];
    _httpRequest.identifier = _updateOneImageAtOpenPlatformIdentifier_;
    [_httpRequest downloadWithURL:[JBoOpenPlatformOperation updateOneImageAtOpenPlatform] paraDic:[JBoOpenPlatformOperation updateOneImageAtOpenPlatformParamWithId:info.Id updatedImageURL:imageInfo.imageURL images:[dic objectForKey:_openPlatformImages_] imageSize:image.size] files:self.files filesKey:_openPlatformImagesFile_];
    [_httpRequest addFiles:self.thumbnailFiles forKey:_openPlatformThumbnails_];
    [_httpRequest startDownload];
    _httpRequest.startImmediately = YES;
}

/**删除图片
 */
- (void)removeImage;
{
    self.isRequesting = YES;
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:self.selectedInfoIndex];
    
    [_httpRequest startDataLoading];
    _httpRequest.identifier = _removeOneImageAtOpenPlatformIdentifier_;
    [_httpRequest downloadWithURL:[JBoOpenPlatformOperation removeOneImageAtOpenPlatform] dic:[JBoOpenPlatformOperation removeOneImageAtOpenPlatformParamWithInfo:info atIndex:self.selectedIndex textIndex:[info textIndexFromImageIndex:self.selectedIndex index:nil]]];
}

/**显示图片选择的actionSheet
 */
- (void)showImagePickActionSheet
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"选取图片" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:camera, album, nil];
    if(self.imageScrollView)
    {
        [actionSheet showInView:self.imageScrollView.view];
    }
    else
    {
        [actionSheet showInView:self.view];
    }
    
    [actionSheet release];
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:retImage withSize:size];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self updateWithImage:thumbnail];
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("album", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [self.appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = 1;
    mutilImagePicker.title = @"相册";
    [mutilImagePicker showInViewController:self animated:YES completion:nil];
    
    [mutilImagePicker release];
}

#pragma mark-JBoMutilImagePickerViewController代理

- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       UIImage *thumbnail = nil;
                       if(assetArray.count > 0)
                       {
                           for(ALAsset *asset in assetArray)
                           {
                               // NSLog(@"开始2");
                               UIImage *image = [UIImage imageWithCGImage:[[asset defaultRepresentation] fullScreenImage]];
                               CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                               thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
                           }
                       }
                       
                       dispatch_async(dispatch_get_main_queue(), ^(void){
                           [viewController dismissViewControllerAnimated:YES completion:^(void)
                            {
                                [self updateWithImage:thumbnail];
                                self.appDelegate.dataLoadingView.hidden = YES;
                            }];
                       });
                   });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        
        UIImage *thumbnail = [JBoImageTextTool getThumbnailFromImage:image withSize:size];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self updateWithImage:thumbnail];
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}


#pragma mark- 加载图片

- (void)downloadImageForIndexPath:(NSIndexPath*) indexPath
{
    JBoOpenPlatformInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    if(!info.qrCodeImage && ![NSString isEmpty:info.infoURL] && self.userHeadImage)
    {
        [JBoQRCodeOperation getQRCodeImageFromString:info.infoURL completion:^(UIImage *image, CGFloat padding){
           
            if(image)
            {
                UIImage *qrCodeImage = [JBoOpenPlatformOperation getOpenPlatformQRCodeImageFormImage:image info:info headImage:self.userHeadImage linkIcon:self.linkIcon margin:padding];
                info.qrCodeThumbnail = [JBoImageTextTool getThumbnailFromImage:qrCodeImage withSize:CGSizeMake(_openPlatformQRCodeImageWidth_, _openPlatformQRCodeImageHeight_)];
                info.qrCodeImage = qrCodeImage;
                
                dispatch_async(dispatch_get_main_queue(), ^(void){
                    
                    JBoOpenPlatformCell *cell = (JBoOpenPlatformCell*)[self.tableView cellForRowAtIndexPath:indexPath];
                    [cell.qrCodeImageView setImage:info.qrCodeThumbnail];
                });
            }
        }];
    }
    
    NSInteger count = info.imageInfos.count;
    if(!info.expand)
    {
        count = MIN(_openPlatformShowImageCountWhenClose_, info.imageInfos.count);
    }

    for(NSInteger i = 0;i < count;i ++)
    {
        JBoOpenPlatformImageInfo *imageInfo = [info.imageInfos objectAtIndex:i];
        
        if(![NSString isEmpty:imageInfo.relateURL])
        {
            dispatch_async(dispatch_get_main_queue(), ^(void){
                
                JBoOpenPlatformCell *cell = (JBoOpenPlatformCell*)[self.tableView cellForRowAtIndexPath:indexPath];
                [cell.multiTextView setupLogoStyle:JBoMultiImageViewCellLogoStyleURL atIndex:i];
            });
        }
    }
}


#pragma mark- scrollView代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!self.bottomLoadingView)
        {
            //创建加载更多视图
            self.bottomLoadingView = [[[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)] autorelease];
            self.bottomLoadingView.backgroundColor = [UIColor clearColor];
        }
        if(!self.isRequesting && self.hasInfo)
        {
            self.tableView.tableFooterView = self.bottomLoadingView;
            [self loadInfo];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
