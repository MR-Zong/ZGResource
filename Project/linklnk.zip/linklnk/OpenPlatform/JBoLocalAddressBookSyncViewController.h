//
//  JBoLocalAddressBookSyncViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**本地通讯录同步到服务器
 */
@interface JBoLocalAddressBookSyncViewController : JBoViewController<UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource>

/**云名片夹信息 数组元素是 JBoCloudAddressBookGroupInfo对象
 */
@property(nonatomic,retain) NSArray *cloundAddresBookInfos;

@end
