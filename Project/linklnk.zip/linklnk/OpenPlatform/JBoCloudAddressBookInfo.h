//
//  JBoCloudAddressBookInfo.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

//手机通讯录和云通讯录的异同
typedef enum _JBoCloudAddressBookRecordOperation
{
    JBoCloudAddressBookRecordOperationDefault = -1, //默认状态
    JBoCloudAddressBookRecordOperationNone = 0, //不做任何操作
    JBoCloudAddressBookRecordOperationAdd = 1, //添加新纪录
    JBoCloudAddressBookRecordOperationAddPhoneNum = 2, //添加手机号码
    JBoCloudAddressBookRecordOperationAddTelePhoneNum = 3, //添加固话
    JBoCloudAddressBookRecordOperationAddAllNum = 4 //添加所有号码
}JBoCloudAddressBookRecordOperation;

/**云通讯录联系人信息
 */
@interface JBoCloudAddressBookInfo : NSObject

/**云通讯录信息Id
 */
@property(nonatomic,assign) long long Id;

/**用户 userId
 */
@property(nonatomic,copy) NSString *userId;

/**用户头像
 */
@property(nonatomic,copy) NSString *imageURL;

/**性别
 */
@property(nonatomic,assign) NSInteger sex;

/**用户身份
 */
@property(nonatomic,assign) NSInteger role;

/**认证名称
 */
@property(nonatomic,copy) NSString *name;

/**靓云台链接
 */
@property(nonatomic,copy) NSString *cloudURL;

/**用户手机号码
 */
@property(nonatomic,copy) NSString *phoneNum;

/**手机号码公开状态
 */
@property(nonatomic,assign) BOOL phoneState;

/**用户固话
 */
@property(nonatomic,copy) NSString *telePhone;

/**备注信息
 */
@property(nonatomic,copy) NSString *remark;

/**提交时间
 */
@property(nonatomic,copy) NSString *time;

/**备注信息高度
 */
@property(nonatomic,assign) NSInteger remarkHeight;

/**云通讯录和手机通讯录的区别
 */
@property(nonatomic,assign) JBoCloudAddressBookRecordOperation operation;

/**关联的手机通讯录内容下标 default is '-1'， 没关联的数据
 */
@property(nonatomic,assign) NSInteger recordIndex;

/**显示的备注信息
 */
- (NSString*)remarkMsg;

@end
