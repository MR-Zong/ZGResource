//
//  JBoOpenPlatformStairGroupView.m
//  linklnk
//
//  Created by kinghe005 on 14-10-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformStairGroupView.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoBasic.h"

#define _lineWidth_ 0.5

#define _startTag_ 2000

@implementation JBoOpenPlatformStairGroupButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _lineWidth_, self.bounds.size.height)];
        lineView.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:lineView];
        [lineView release];
        
        _btn = [UIButton buttonWithType:UIButtonTypeCustom];
        _btn.titleLabel.font = [UIFont systemFontOfSize:13.0];
        [_btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _btn.enabled = NO;
        [_btn setFrame:self.bounds];
        [self addSubview:_btn];
        
        _highlightView = [[UIView alloc] initWithFrame:self.bounds];
        _highlightView.backgroundColor = [UIColor colorWithWhite:0.5 alpha:0.4];
        _highlightView.userInteractionEnabled = NO;
        _highlightView.hidden = YES;
        [self addSubview:_highlightView];
    }
    return self;
}

- (void)dealloc
{
    [_highlightView release];
    
    [super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    _highlightView.alpha = 1.0;
    _highlightView.hidden = NO;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [UIView animateWithDuration:0.25 animations:^(void){
        _highlightView.alpha = 0;
    }completion:^(BOOL finish){
        _highlightView.hidden = YES;
    }];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [UIView animateWithDuration:0.25 animations:^(void){
        _highlightView.alpha = 0;
    }completion:^(BOOL finish){
        _highlightView.hidden = YES;
    }];
}

@end

@implementation JBoOpenPlatformStairGroupView


- (id)initWithFrame:(CGRect) frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor colorWithRed:243.0 / 255.0 green:245.0 / 255.0 blue:240.0 / 255.0 alpha:1.0];
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.bounds.size.height - _lineWidth_, self.bounds.size.width, _lineWidth_)];
        lineView.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:lineView];
        [lineView release];
        
        self.maxCount = 3;
        self.editable = YES;
    }
    
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    [_infos release];
    [super dealloc];
}

- (void)setInfos:(NSArray *)infos
{
    if(_infos != infos)
    {
        [_infos release];
        _infos = [infos retain];
        [self reload];
    }
}

#pragma mark- public method

/**重新加载信息
 */
- (void)reload
{
    for(UIView *view in self.subviews)
    {
        if([view isKindOfClass:[JBoOpenPlatformStairGroupButton class]])
        {
            [view removeFromSuperview];
        }
    }
    
    NSInteger count = 0;
    if(self.editable)
    {
        count = MIN(self.maxCount, _infos.count + 1);
    }
    else
    {
        count = _infos.count;
    }
    
    CGFloat width = self.width / count;
    
    for(NSInteger i = 0;i < count;i ++)
    {
        JBoOpenPlatformStairGroupButton *btn = [[JBoOpenPlatformStairGroupButton alloc] initWithFrame:CGRectMake(i * width, 0, width, self.height)];
        if(i == _infos.count)
        {
            [btn.btn setImage:[UIImage imageNamed:@"add_btn"] forState:UIControlStateNormal];
        }
        else
        {
            JBoOpenPlatformGroupInfo *info = [_infos objectAtIndex:i];
            [btn.btn setTitle:info.name forState:UIControlStateNormal];
            UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(handleLongPress:)];
            [btn addGestureRecognizer:longPress];
            [longPress release];
        }
        
        btn.tag = _startTag_ + i;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
        [btn addGestureRecognizer:tap];
        [tap release];
        
        [self addSubview:btn];
        [btn release];
    }
    
    if(!self.editable && self.infos.count == 0)
    {
        UILabel *label = [[UILabel alloc] initWithFrame:self.bounds];
        label.backgroundColor = [UIColor clearColor];
        label.textAlign = JBoTextAlignmentCenter;
        label.textColor = [UIColor blackColor];
        label.text = @"暂无分组信息";
        [self addSubview:label];
        [label release];
    }
}

/**通过下标获取button
 */
- (JBoOpenPlatformStairGroupButton*)buttonForIndex:(NSInteger) index
{
    return (JBoOpenPlatformStairGroupButton*)[self viewWithTag:_startTag_ + index];
}

#pragma mark- private method

//点击
- (void)handleTap:(UITapGestureRecognizer*) tap
{
    NSInteger index = tap.view.tag - _startTag_;
    if(index < _infos.count)
    {
        if([self.delegate respondsToSelector:@selector(openPlatformStairGroupView:didSelectGroupAtIndex:)])
        {
            [self.delegate openPlatformStairGroupView:self didSelectGroupAtIndex:index];
        }
    }
    else
    {
        if([self.delegate respondsToSelector:@selector(openPlatformStairGroupViewDidAddGroup:)])
        {
            [self.delegate openPlatformStairGroupViewDidAddGroup:self];
        }
    }
}

- (void)handleLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        NSInteger index = longPress.view.tag - _startTag_;
        if([self.delegate respondsToSelector:@selector(openPlatformStairGroupView:didLongPressGroupAtIndex:)])
        {
            [self.delegate openPlatformStairGroupView:self didLongPressGroupAtIndex:index];
        }
    }
}

@end
