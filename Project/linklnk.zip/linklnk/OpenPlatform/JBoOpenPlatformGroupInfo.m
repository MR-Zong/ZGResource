//
//  JBoOpenPlatformGroupInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformGroupInfo.h"

@implementation JBoOpenPlatformGroupInfo

- (void)dealloc
{
    [_name release];
    [_superName release];
    [_secondaryInfos release];
    [_url release];
    
    [super dealloc];
}

/**要显示的标题
 */
- (NSString*)title
{
    if(![NSString isEmpty:self.superName])
    {
        return [NSString stringWithFormat:@"%@/%@", self.superName, self.name];
    }
    else
    {
        return self.name;
    }
}

@end
