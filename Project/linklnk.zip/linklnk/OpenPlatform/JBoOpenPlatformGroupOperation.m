//
//  JBoOpenPlatformGroupOperation.m
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformGroupOperation.h"
#import "JBoBasic.h"
#import "JBoUserOperation.h"
#import "JSONKit.h"
#import "JBoOpenPlatformGroupInfo.h"
#import "JBoOpenPlatformInfo.h"

@implementation JBoOpenPlatformGroupOperation

/**添加云名片一级分组 url
 *@return post请求url
 */
+ (NSString*)addOpenPlatformGroup
{
    return _addOpenPlatformGroup_;
}

/**添加云名片一级分组参数
 *@param name 分组名称
 *@return post请求参数
 */
+ (NSDictionary*)addOpenPlatformGroupParamWithName:(NSString*) name
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    [dic setObject:name forKey:_openPlatformGroupName_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    return dic;
}

/**从返回的数据获取新添加的云名片分组信息
 *@param data 返回的数据
 *@param error 错误码
 *@return 云名片一级分组信息
 */
+ (JBoOpenPlatformGroupInfo*)additionOpenPlatformGroupInfoFromData:(NSData*) data error:(NSInteger *)error
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        
        JBoOpenPlatformGroupInfo *info = [[JBoOpenPlatformGroupInfo alloc] init];
        info.Id = [[dict valueWithKey:_openPlatformGroupId_] longLongValue];
        info.name = [dict objectWithKey:_openPlatformGroupName_];
        
        return [info autorelease];
    }
    
    *error = [code integerValue];
    
    return nil;
}

/**添加云名片二级级分组 url
 *@return post请求url
 */
+ (NSString*)addOpenPlatformSecondaryGroup
{
    return _addOpenPlatformSecondaryGroup_;
}

/**添加云名片二级级分组参数
 *@param name 分组名称
 *@param groupId 一级分组Id
 *@return post请求参数
 */
+ (NSDictionary*)addOpenPlatformSecondaryGroupParamWithName:(NSString*) name groupId:(long long) groupId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    [dic setObject:name forKey:_openPlatformGroupName_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:[NSNumber numberWithLongLong:groupId] forKey:_openPlatformStairGroupId_];
    
    return dic;
}

/**从返回的数据获取新添加的云名片二级分组信息
 *@param data 返回的数据
 *@param error 错误码
 *@return 云名片二级级分组信息
 */
+ (JBoOpenPlatformGroupInfo*)additionOpenPlatformSecondaryGroupInfoFromData:(NSData*) data error:(NSInteger *)error
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        
        JBoOpenPlatformGroupInfo *info = [[JBoOpenPlatformGroupInfo alloc] init];
        info.Id = [[dict valueWithKey:_openPlatformGroupId_] longLongValue];
        info.name = [dict objectWithKey:_openPlatformGroupName_];
        info.url = [dict objectWithKey:_openPlatformGroupURL_];
        
        return [info autorelease];
    }
    
    *error = [code integerValue];
    
    return nil;
}

/**删除云名片一级分组 url
 *@return post请求url
 */
+ (NSString*)removeOpenPlatformGroup
{
    return _removeOpenPlatformGroup_;
}

/**删除云名片一级分组参数
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)removeOpenPlatformGroupParamWithId:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformGroupId_];
    
    return dic;
}

/**删除云名片二级级分组 url
 *@return post请求url
 */
+ (NSString*)removeOpenPlatformSecondaryGroup
{
    return _removeOpenPlatformSecondaryGroup_;
}

/**删除云名片二级级分组参数
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)removeOpenPlatformSecondaryGroupParamWithId:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformGroupId_];
    
    return dic;
}


/**修改云名片一级分组名称 url
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformGroup
{
    return _modifyOpenPlatformGroup_;
}

/**修改云名片一级分组名称 参数
 *@param name 新的分组名称
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)modifyOpenPlatformGroupParamWithName:(NSString*) name Id:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:name forKey:_openPlatformGroupName_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformGroupId_];
    
    return dic;
}

/**修改云名片二级分组名称 url
 *@return post请求url
 */
+ (NSString*)modifyOpenPlatformSecondaryGroup
{
    return _modifyOpenPlatformSecondaryGroup_;
}

/**修改云名片二级分组名称 参数
 *@param name 新的分组名称
 *@param Id 分组Id
 *@return post请求参数
 */
+ (NSDictionary*)modifyOpenPlatformSecondaryGroupParamWithName:(NSString*) name Id:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:name forKey:_openPlatformGroupName_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_openPlatformGroupId_];
    
    return dic;
}

/**获取云名片分组信息
 *@return get请求url
 */
+ (NSString*)getOpenPlatformGroupInfo
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getOpenPlatformGroupInfo_, _rosterUserId_, [JBoUserOperation getUserId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**从返回的数据获取云名片分组信息
 *@param data 返回的数据
 *@return 数组元素是 JBoOpenPlatformGroupInfo对象
 */
+ (NSMutableArray*)getOpenPlatformGroupInfoFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoOpenPlatformGroupInfo *info = [[JBoOpenPlatformGroupInfo alloc] init];
            info.Id = [[dict valueWithKey:_openPlatformGroupId_] longLongValue];
            info.name = [dict objectWithKey:_openPlatformGroupName_];
            
            NSArray *secondaryArray = [dict arrayForKey:_openPlatformSecondaryGroupInfo_];
            
            NSMutableArray *secondaryInfos = [NSMutableArray arrayWithCapacity:secondaryArray.count];
            info.secondaryInfos = secondaryInfos;
            
            for(NSDictionary *sdic in secondaryArray)
            {
                JBoOpenPlatformGroupInfo *secondaryInfo = [[JBoOpenPlatformGroupInfo alloc] init];
                secondaryInfo.Id = [[sdic objectWithKey:_openPlatformGroupId_] longLongValue];
                secondaryInfo.superId = info.Id;
                
                secondaryInfo.name = [sdic objectWithKey:_openPlatformGroupName_];
                secondaryInfo.url = [sdic objectWithKey:_openPlatformGroupURL_];
                [info.secondaryInfos addObject:secondaryInfo];
                [secondaryInfo release];
            }
            
            [infoArray addObject:info];
            [info release];
        }

        return infoArray;
    }
    
    return nil;
}

/**移动云名片到另一个分组 参数
 *@return  post请求url
 */
+ (NSString*)moveOpenPlatformToGroup
{
    return _moveOpenPlatformToGroup_;
}

/**移动云名片到另一个分组 参数
 *@param info 云名片信息
 *@param groupInfo 云名片分组信息
 *@return post请求参数
 */
+ (NSDictionary*)moveOpenPlatformToGroupParamWithInfo:(JBoOpenPlatformInfo*) info groupInfo:(JBoOpenPlatformGroupInfo*) groupInfo
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:info.Id] forKey:_moveOpenPlatformId_];
    [dic setObject:[NSNumber numberWithLongLong:groupInfo.Id] forKey:_openPlatformGroupId_];
    
    return dic;
}

@end
