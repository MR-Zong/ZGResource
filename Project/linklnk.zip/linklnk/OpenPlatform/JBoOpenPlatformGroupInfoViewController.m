//
//  JBoOpenPlatformGroupInfoViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformGroupInfoViewController.h"
#import "JBoOpenPlatformGroupInfo.h"
#import "JBoHttpRequest.h"
#import "JBoOpenPlatformGroupOperation.h"
#import "JBoUserOperation.h"
#import "JBoOpenPlatformInfo.h"
#import "JBoOpenPlatformGroupCell.h"
#import "JBoWebToolButton.h"
#import "JBoOpenPlatformStairGroupView.h"
#import "JBoPopupMenu.h"
#import "JBoCustomInsetLabel.h"

//
//static NSString *const removeGroup = @"删除";
//static NSString *const addSecondaryGroup = @"添加二级分组";
//static NSString *const modifyGroupName = @"修改分组名称";

@interface JBoOpenPlatformGroupInfoViewController ()<JBoHttpRequestDelegate,JBoOpenPlatformStairGroupViewDelegate,JBoPopupMenuDelegate>


//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在网络请求
@property(nonatomic,assign) BOOL isRequesting;

//一级分组
@property(nonatomic,retain) JBoOpenPlatformStairGroupView *stairGroupView;

//二级分组
@property(nonatomic,retain) JBoPopupMenu *secondaryGroupMenu;

//显示二级菜单的一级分组
@property(nonatomic,assign) NSInteger showSecondaryGroupStairIndex;

//选中的二级分组
@property(nonatomic,assign) NSInteger selectedSecondaryIndex;

@end

@implementation JBoOpenPlatformGroupInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"云名片分组";
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        self.showSecondaryGroupStairIndex = NSNotFound;
        self.selectedSecondaryIndex = NSNotFound;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_groupInfos release];
    [_info release];
    [_groupInfo release];
    
    [_stairGroupView release];
    [_secondaryGroupMenu release];
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addOpenPlatformGroupIdentifier_])
    {
        [self alertNetworkMsg:@"添加新分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_getOpenPlatformGroupInfoIdentifier_])
    {
        [self alertNetworkMsg:@"获取分组失败"];
        return;
    }
    
    if([identifier isEqualToString:_moveOpenPlatformToGroupIdentifier_])
    {
        [self alertNetworkMsg:@"分组失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addOpenPlatformGroupIdentifier_])
    {
        NSInteger error = 0;
        JBoOpenPlatformGroupInfo *info = [JBoOpenPlatformGroupOperation additionOpenPlatformGroupInfoFromData:data error:&error];
        if(info)
        {
            [self.groupInfos addObject:info];
        }
        else
        {
            [self alertNetworkMsg:@"添加新分组失败"];
        }
        return;
    }
    
    
    if([identifier isEqualToString:_getOpenPlatformGroupInfoIdentifier_])
    {
        NSMutableArray *array = [JBoOpenPlatformGroupOperation getOpenPlatformGroupInfoFromData:data];
        if(array)
        {
            self.groupInfos = array;
            [self loadInitView];
        }
        else
        {
            [self alertNetworkMsg:@"获取分组失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_moveOpenPlatformToGroupIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            JBoOpenPlatformGroupInfo *info = [self.groupInfos objectAtIndex:self.showSecondaryGroupStairIndex];
            JBoOpenPlatformGroupInfo *secondaryInfo = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
            self.info.groupInfo = secondaryInfo;
            self.info.groupInfo.superName = info.name;
            self.info.groupInfo.superId = info.Id;
            
            if([self.delegate respondsToSelector:@selector(openPlatformGroupInfoViewController:didSelectGroupInfo:)])
            {
                [self.delegate openPlatformGroupInfoViewController:self didSelectGroupInfo:secondaryInfo];
            }
            
            [self back];
        }
    }
}

#pragma mark- 加载视图

//添加一级分组
- (void)addGroup
{
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    
    if(self.groupInfos)
    {
        [self loadInitView];
    }
    else
    {
        self.isRequesting = YES;
        [self.httpRequest startDataLoading];
        self.httpRequest.identifier = _getOpenPlatformGroupInfoIdentifier_;
        [self.httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation getOpenPlatformGroupInfo]];
    }
}

- (void)loadInitView
{
    if(self.info.groupInfo != nil)
    {
        self.groupInfo = self.info.groupInfo;
    }
    
    JBoOpenPlatformStairGroupView *view = [[JBoOpenPlatformStairGroupView alloc] initWithFrame:CGRectMake(0, 0, _width_, _openPlatformStairGroupViewHeight_)];
    view.editable = NO;
    view.maxCount = _openPlatformGroupMaxCount_;
    view.infos = self.groupInfos;
    view.delegate = self;
    [self.view addSubview:view];
    self.stairGroupView = view;
    [view release];
    
    JBoCustomInsetLabel *alertLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, (_height_ - _statuBarHeight_ - _navgateBarHeight_ - view.height - 50) / 2.0, _width_, 50.0)];
    alertLabel.insets = UIEdgeInsetsMake(0, 10.0, 0, 10.0);
    alertLabel.numberOfLines = 0;
    alertLabel.backgroundColor = [UIColor clearColor];
    alertLabel.font = [UIFont systemFontOfSize:14.0];
    alertLabel.textColor = [UIColor grayColor];
    alertLabel.textAlign = JBoTextAlignmentCenter;
    alertLabel.text = @"把云名片信息分组，便于查看";
    
    [self.view addSubview:alertLabel];
    
    [alertLabel release];
}

#pragma mark- JBoOpenPlatformStairGroupView 代理

- (void)openPlatformStairGroupView:(JBoOpenPlatformStairGroupView *)view didLongPressGroupAtIndex:(NSInteger)index
{
//    self.selectedStairIndex = index;
//    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"删除分组不会删除分组内的云名片信息" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil, nil];
//    actionSheet.tag = _selectSectionTag_;
//    
//    [actionSheet addButtonWithTitle:modifyGroupName];
//    actionSheet.destructiveButtonIndex = [actionSheet addButtonWithTitle:removeGroup];
//    actionSheet.cancelButtonIndex = [actionSheet addButtonWithTitle:@"取消"];
//    [actionSheet showInView:self.view];
//    [actionSheet release];
}

- (void)openPlatformStairGroupView:(JBoOpenPlatformStairGroupView *)view didSelectGroupAtIndex:(NSInteger)index
{
    if(self.showSecondaryGroupStairIndex != index)
    {
        [self.secondaryGroupMenu dismissMenuWithAnimated:YES];
        JBoOpenPlatformGroupInfo *info = [self.groupInfos objectAtIndex:index];
        
        
        self.secondaryGroupMenu = [[[JBoPopupMenu alloc] initWithStyle:JBoPopupMenuStylePlainText] autorelease];
        self.secondaryGroupMenu.tintColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        self.secondaryGroupMenu.menuTitleColor = [UIColor blackColor];
        self.secondaryGroupMenu.separatedLineColor = [UIColor lightGrayColor];
        
        JBoOpenPlatformStairGroupButton *item = [view buttonForIndex:index];
        [self setSecondaryGroupMenuItemWithInfo:info];
        
        self.secondaryGroupMenu.delegate = self;
        
        CGRect relateRect = item.frame;
        relateRect.origin.y = view.frame.origin.y;
        relateRect.size.height = view.frame.size.height;
        
        [self.secondaryGroupMenu showInView:self.view relatedRect:relateRect animated:YES overlay:YES];
        [self.view bringSubviewToFront:view];
        self.showSecondaryGroupStairIndex = index;
    }
    else
    {
        [self.secondaryGroupMenu dismissMenuWithAnimated:YES];
        self.showSecondaryGroupStairIndex = NSNotFound;
    }
}

- (void)openPlatformStairGroupViewDidAddGroup:(JBoOpenPlatformStairGroupView *)view
{
//    if(self.isRequesting)
//        return;
//    [self addGroup];
}

#pragma mark-JBoPopupMenu代理

- (void)popupMenu:(JBoPopupMenu *)menu didSelectedAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    
    self.selectedSecondaryIndex = index;
    
    if(self.info)
    {
        [self moveToGroup];
    }
    else
    {
        JBoOpenPlatformGroupInfo *info = [self.groupInfos objectAtIndex:self.showSecondaryGroupStairIndex];
        JBoOpenPlatformGroupInfo *secondaryInfo = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];
        
        secondaryInfo.superName = info.name;
        secondaryInfo.superId = info.Id;
        
        if([self.delegate respondsToSelector:@selector(openPlatformGroupInfoViewController:didSelectGroupInfo:)])
        {
            [self.delegate openPlatformGroupInfoViewController:self didSelectGroupInfo:secondaryInfo];
        }
        [self back];
    }
}

- (void)popupMenu:(JBoPopupMenu *)menu didAddedAtIndex:(NSInteger)index
{
//    if(self.isRequesting)
//        return;
//    self.selectedStairIndex = self.showSecondaryGroupStairIndex;
//    self.selectedSecondaryIndex = index;
//    
//    [self showAlertViewWithContent:nil type:JBoAlertOpeartionTypeAddSecondaryGroup];
}

- (void)popupMenu:(JBoPopupMenu *)menu didLongPressAtIndex:(NSInteger)index
{
//    if(self.isRequesting)
//        return;
//    
//    self.selectedStairIndex = self.showSecondaryGroupStairIndex;
//    self.selectedSecondaryIndex = index;
//    
//    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"删除分组不会删除分组内的云名片信息" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:modifyGroupName, removeGroup, nil];
//    actionSheet.destructiveButtonIndex = 1;
//    [actionSheet showInView:self.view];
//    [actionSheet release];
}

- (void)popupMenuWillDismiss:(JBoPopupMenu *)menu
{
    self.showSecondaryGroupStairIndex = NSNotFound;
}

#pragma mark- private method

//移动云名片到某一个分组
- (void)moveToGroup
{
    JBoOpenPlatformGroupInfo *info = [self.groupInfos objectAtIndex:self.showSecondaryGroupStairIndex];
    JBoOpenPlatformGroupInfo *secondaryInfo = [info.secondaryInfos objectAtIndex:self.selectedSecondaryIndex];

    self.isRequesting = YES;
    self.httpRequest.identifier = _moveOpenPlatformToGroupIdentifier_;
    [self.httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation moveOpenPlatformToGroup] dic:[JBoOpenPlatformGroupOperation moveOpenPlatformToGroupParamWithInfo:self.info groupInfo:secondaryInfo]];
}

//设置二级分组按钮信息
- (void)setSecondaryGroupMenuItemWithInfo:(JBoOpenPlatformGroupInfo*) info
{
    NSMutableArray *menuItems = [NSMutableArray arrayWithCapacity:info.secondaryInfos.count];
    
    NSString *maxLengthTitle = nil;
    for(JBoOpenPlatformGroupInfo *secondaryInfo in info.secondaryInfos)
    {
        JBoPopupMenuItem *popupMenuItem = [JBoPopupMenuItem menuItemWithIcon:nil title:secondaryInfo.name];
        popupMenuItem.add = NO;
        [menuItems addObject:popupMenuItem];
        
        if(maxLengthTitle.length < secondaryInfo.name.length)
        {
            maxLengthTitle = secondaryInfo.name;
        }
    }
    
    //添加 添加二级分组按钮
//    if(menuItems.count < _openPlatformSecondaryGroupMaxCount_)
//    {
//        JBoPopupMenuItem *menuItem = [JBoPopupMenuItem menuItemWithIcon:nil title:nil];
//        menuItem.add = YES;
//        [menuItems addObject:menuItem];
//    }
    
    CGFloat width = [self.secondaryGroupMenu getMenuWidthFromTitle:maxLengthTitle];
    width = width < _width_ / _openPlatformGroupMaxCount_ - 10 ? _width_ / _openPlatformGroupMaxCount_ - 10 : width;
    self.secondaryGroupMenu.menuWidth = width;
    
    self.secondaryGroupMenu.menuItems = menuItems;
}

//显示alertView
- (void)showAlertViewWithContent:(NSString*) content title:(NSString*) title
{
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:title message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    [textField addTarget:self action:@selector(textValueDidChange:) forControlEvents:UIControlEventEditingChanged];
    textField.delegate = self;
    textField.placeholder = [NSString stringWithFormat:@"%d个字以内",_inputFormatOpenPlatformGroupName_];
    textField.text = content;
    [alerView show];
    [alerView release];
}

#pragma mark- alertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 1 :
        {
            UITextField *textField = [alertView textFieldAtIndex:0];
            
            if([NSString isEmpty:textField.text])
            {
                [self alertMsg:@"分组名称不能为空"];
                return;
            }
            
            if(textField.text.length > _inputFormatOpenPlatformGroupName_)
            {
                [self alertMsg:[NSString stringWithFormat:@"分组名称不能超过%d个字", _inputFormatOpenPlatformGroupName_]];
                return;
            }
            
            self.isRequesting = YES;
            _httpRequest.identifier = _addOpenPlatformGroupIdentifier_;
            [_httpRequest downloadWithURL:[JBoOpenPlatformGroupOperation addOpenPlatformGroup] dic:[JBoOpenPlatformGroupOperation addOpenPlatformGroupParamWithName:textField.text]];
        }
            break;
        default:
            break;
    }
}

#pragma mark- textField代理

- (void)textValueDidChange:(UITextField*)textField
{
    [textField textDidChangeWithLimitedCount:_inputFormatOpenPlatformGroupName_];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    return [textField textShouldChangeCharactersInRange:range replacementString:string limitedCount:_inputFormatOpenPlatformGroupName_];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
