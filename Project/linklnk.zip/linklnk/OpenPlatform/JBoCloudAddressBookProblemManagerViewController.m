//
//  JBoCloudAddressBookProblemManagerViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookProblemManagerViewController.h"
#import "JBoCloudAddressBookProblemInfo.h"
#import "JBoHttpRequest.h"
#import "JBoCloudAddressBookOperation.h"
#import "JBoCloudAddressBookProblemManagerViewController.h"
#import "JBoCloudAddressBookProblemInputView.h"
#import "SSTextView.h"
#import "JBoCustomInsetLabel.h"
#import "JBoUserOperation.h"

//验证问题最大数量
#define _cloudAddressBookProbleMaxCount_ 3

@interface JBoCloudAddressBookProblemManagerViewController ()<JBoHttpRequestDelegate,JBoCloudAddressBookProblemInputDelegate>

//信息列表
@property(nonatomic,retain) UITableView *tableView;

//信息数据 数组元素是 JBoCloudAddressBookProblemInfo对象
@property(nonatomic,retain) NSMutableArray *infoArray;

//网络请求
@property(nonatomic,retain) JBoHttpRequest *httpRequest;

//是否正在请求
@property(nonatomic,assign) BOOL isRequesting;

//选中的cell
@property(nonatomic,retain) NSIndexPath *selectedIndexPath;

//更新的信息
@property(nonatomic,retain) JBoCloudAddressBookProblemInfo *updatedInfo;

//信息输入框
@property(nonatomic,retain) JBoCloudAddressBookProblemInputView *inputView;

@end

@implementation JBoCloudAddressBookProblemManagerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"验证问题管理";
        self.httpRequest = [[[JBoHttpRequest alloc] initWithDelegate:self] autorelease];
        self.infoArray = [NSMutableArray array];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark- dealloc

- (void)dealloc
{
    [_infoArray release];
    [_tableView release];
    
    [_httpRequest release];
    [_selectedIndexPath release];
    
    [_updatedInfo release];
    [_inputView release];
    
    [super dealloc];
}

#pragma mark- http

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addCloudAddressBookProblemIdentifier_])
    {
        [self alertNetworkMsg:@"添加验证问题失败"];
        return;
    }
    
    if([identifier isEqualToString:_updateCloudAddressBookProblemIdentifier_])
    {
        [self alertNetworkMsg:@"更新验证问题失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeCloudAddressBookProblemIdentifier_])
    {
        [self alertNetworkMsg:@"删除验证问题失败"];
        return;
    }
    
    if([identifier isEqualToString:_getCloudAddressBookProblemIdentifier_])
    {
        [self alertNetworkMsg:@"获取验证问题失败"];
        return;
    }
    
    self.selectedIndexPath = nil;
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addCloudAddressBookProblemIdentifier_])
    {
        long long Id = [JBoCloudAddressBookOperation addCloudAddressBookProblemResultFromData:data];
        if(Id != 0)
        {
            [self alertMsg:@"添加验证问题成功"];
            self.updatedInfo.Id = Id;
            
            [self.infoArray addObject:self.updatedInfo];
            
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.infoArray.count - 1 inSection:0];
            
            [_tableView beginUpdates];
            [_tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        else
        {
            [self alertNetworkMsg:@"添加验证问题失败"];
        }
        
        [self enableAdd];
        
        return;
    }
    
    if([identifier isEqualToString:_updateCloudAddressBookProblemIdentifier_])
    {
         if([JBoUserOperation isSuccess:data])
         {
             [self alertMsg:@"更新验证问题成功"];
             
             JBoCloudAddressBookProblemInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
             
             info.problem = self.updatedInfo.problem;
             info.answer = self.updatedInfo.answer;
             
             [_tableView beginUpdates];
             [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
             [_tableView endUpdates];
         }
         else
         {
            [self alertNetworkMsg:@"更新验证问题失败"];
         }
        self.selectedIndexPath = nil;
        return;
    }
    
    if([identifier isEqualToString:_removeCloudAddressBookProblemIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            [self alertMsg:@"删除验证问题失败"];
            
            [self.infoArray removeObjectAtIndex:self.selectedIndexPath.row];
            
            [_tableView beginUpdates];
            [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        else
        {
            [self alertNetworkMsg:@"删除验证问题失败"];
        }
        
        [self enableAdd];
        self.selectedIndexPath = nil;
        return;
    }
    
    if([identifier isEqualToString:_getCloudAddressBookProblemIdentifier_])
    {
        NSArray *array = [JBoCloudAddressBookOperation getCloudAddressBookProblemFromData:data];
        if(array)
        {
            [self.infoArray addObjectsFromArray:array];
            [self loadInitView];
        }
        else
        {
            [self alertNetworkMsg:@"获取验证问题失败"];
        }
        return;
    }
}


#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
  
    self.backItem = YES;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    self.isRequesting = YES;
    [_httpRequest startDataLoading];
    _httpRequest.identifier = _getCloudAddressBookProblemIdentifier_;
    [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation getCloudAddressBookProblemWithUserId:[JBoUserOperation getUserId]]];
}

//添加验证问题
- (void)addProblem
{
    if(self.isRequesting)
        return;
    
    [self showInputViewWithStyle:JBoCloudAddressBookProblemInputStyleAdd];
}

- (void)loadInitView
{
    //添加按钮
    [self setRightBarItemWithButtonType:JBoWebToolButtonTypeAdd action:@selector(addProblem)];
    
    JBoCustomInsetLabel *alertLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, 0, _width_, 60.0)];
    alertLabel.insets = UIEdgeInsetsMake(0, 10.0, 0, 10.0);
    alertLabel.numberOfLines = 0;
    alertLabel.backgroundColor = [UIColor clearColor];
    alertLabel.font = [UIFont systemFontOfSize:14.0];
    alertLabel.textColor = [UIColor grayColor];
   // alertLabel.textAlign = JBoTextAlignmentCenter;
    alertLabel.text = [NSString stringWithFormat:@"其他用户添加您为云名片夹联系人时，需要输入验证问题的答案，您最多只能添加%d个验证问题", _cloudAddressBookProbleMaxCount_];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    
    tableView.tableHeaderView = alertLabel;
    [alertLabel release];
    
    self.tableView = tableView;
    [tableView release];
}

//是否允许继续添加
- (void)enableAdd
{
    self.navigationItem.rightBarButtonItem.enabled = _infoArray.count < _cloudAddressBookProbleMaxCount_;
}

#pragma mark- tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    [self enableAdd];
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoCloudAddressBookProblemInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = info.problem;
    cell.detailTextLabel.text = info.answer;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if(self.isRequesting)
        return;
    self.selectedIndexPath = indexPath;
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"修改验证问题", @"删除", nil];
    actionSheet.destructiveButtonIndex = 1;
    [actionSheet showInView:self.view];
    [actionSheet release];
}

#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0 :
        {
            [self showInputViewWithStyle:JBoCloudAddressBookProblemInputStyleModify];
        }
            break;
        case 1 :
        {
            self.isRequesting = YES;
            
            JBoCloudAddressBookProblemInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
            
            _httpRequest.identifier = _removeCloudAddressBookProblemIdentifier_;
            [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation removeCloudAddressBookProblem] dic:[JBoCloudAddressBookOperation removeCloudAddressBookProblemParamWithId:info.Id]];
        }
            break;
        default:
        {
            self.selectedIndexPath = nil;
        }
            break;
    }
}

#pragma mark- private method

- (void)showInputViewWithStyle:(JBoCloudAddressBookProblemInputStyle) style
{
    if(self.inputView)
    {
        [self.inputView dismiss];
        return;
    }
    
    CGRect frame = self.view.bounds;
    frame.origin.y = _height_;
    
    JBoCloudAddressBookProblemInputView *inputView = [[JBoCloudAddressBookProblemInputView alloc] initWithFrame:frame infos:nil style:style];
    
    if(style == JBoCloudAddressBookProblemInputStyleModify)
    {
        JBoCloudAddressBookProblemInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
        inputView.problemTextView.text = info.problem;
        inputView.answerTextView.text = info.answer;
    }
    inputView.inputDelegate = self;
    [inputView showInView:self.view];
    self.inputView = inputView;
    [inputView release];
    
    self.title = @"添加验证问题";
}

#pragma mark- JBoCloudAddressBookProblemInputView代理

- (void)cloudAddressBookProblemInputViewDidFinish:(JBoCloudAddressBookProblemInputView *)inputView
{
    NSString *problem = inputView.problemTextView.text;
    NSString *answer = inputView.answerTextView.text;
    
    switch (inputView.style)
    {
        case JBoCloudAddressBookProblemInputStyleModify :
        {
            JBoCloudAddressBookProblemInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
            if(![info.problem isEqualToString:problem] || ![info.answer isEqualToString:answer])
            {
                JBoCloudAddressBookProblemInfo *problemInfo = [[JBoCloudAddressBookProblemInfo alloc] init];
                problemInfo.problem = problem;
                problemInfo.answer = answer;
                self.updatedInfo = problemInfo;
                [problemInfo release];
                
                self.isRequesting = YES;
                _httpRequest.identifier = _updateCloudAddressBookProblemIdentifier_;
                [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation updateCloudAddressBookProblem] dic:[JBoCloudAddressBookOperation updateCloudAddressBookProblemParamWithId:info.Id problem:problem answer:answer]];
            }
            
        }
            break;
        case JBoCloudAddressBookProblemInputStyleAdd :
        {
            JBoCloudAddressBookProblemInfo *problemInfo = [[JBoCloudAddressBookProblemInfo alloc] init];
            problemInfo.problem = problem;
            problemInfo.answer = answer;
            self.updatedInfo = problemInfo;
            [problemInfo release];
            
            self.isRequesting = YES;
            _httpRequest.identifier = _addCloudAddressBookProblemIdentifier_;
            [_httpRequest downloadWithURL:[JBoCloudAddressBookOperation addCloudAddressBookProblem] dic:[JBoCloudAddressBookOperation addCloudAddressBookProblemParam:problem answer:answer]];
        }
            break;
        default:
            break;
    }
    

    [inputView dismiss];
}

- (void)cloudAddressBookProblemInputViewDidDismiss:(JBoCloudAddressBookProblemInputView *)inputView
{
    self.inputView = nil;
    self.title = @"验证问题管理";
//    UIBarButtonItem *item = self.navigationItem.rightBarButtonItem;
//    [UIView animateWithDuration:0.25 animations:^(void){
//        
//        item.customView.transform = CGAffineTransformIdentity;
//    }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
