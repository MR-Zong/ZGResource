//
//  JBoCloudAddressBookProblemInfo.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookProblemInfo.h"

@implementation JBoCloudAddressBookProblemInfo

- (void)dealloc
{
    [_problem release];
    [_answer release];
    
    [super dealloc];
}

@end
