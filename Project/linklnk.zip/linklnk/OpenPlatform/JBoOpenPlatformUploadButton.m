//
//  JBoOpenPlatformUploadButton.m
//  linklnk
//
//  Created by kinghe005 on 14-10-13.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformUploadButton.h"

@implementation JBoOpenPlatformUploadButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        
        UIImage *image = [UIImage imageNamed:@"openPlatform_upload"];
        frame.size = image.size;
        self.frame = frame;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setImage:image forState:UIControlStateNormal];
        [button setFrame:self.bounds];
        [button setAdjustsImageWhenDisabled:NO];
        button.userInteractionEnabled = NO;
        button.enabled = NO;
        [self addSubview:button];
    }
    
    return self;
}

#pragma mark- public method

/**添加单击手势
 */
- (void)addTapGestureWithTarget:(id) target action:(SEL) action
{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:target action:action];
    [self addGestureRecognizer:tap];
    [tap release];
}

/**添加长按手势
 */
- (void)addLongPressGestureWithTarget:(id) target action:(SEL) action
{
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:target action:action];
    [self addGestureRecognizer:longPress];
    [longPress release];
}

@end
