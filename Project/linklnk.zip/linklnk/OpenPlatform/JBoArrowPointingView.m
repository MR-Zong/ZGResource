//
//  JBoArrowPointView.m
//  linklnk
//
//  Created by kinghe005 on 14-9-20.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoArrowPointingView.h"

@implementation JBoArrowPointingView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.fillColor = [UIColor blackColor];
    }
    return self;
}

- (void)dealloc
{
    [_fillColor release];
    [super dealloc];
}

- (void)setFillColor:(UIColor *)fillColor
{
    if(_fillColor != fillColor)
    {
        [_fillColor release];
        _fillColor = [fillColor retain];
        [self setNeedsDisplay];
    }
}

- (void)setSelected:(BOOL)selected
{
    if(_selected != selected)
    {
        _selected = selected;
        
        CGAffineTransform transform = CGAffineTransformIdentity;
        if(_selected)
        {
            transform = CGAffineTransformMakeRotation(M_PI_2);
        }
        
        [UIView animateWithDuration:0.25 animations:^(void){
            
            self.transform = transform;
        }];
    }
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    //设置线条颜色和宽度
    CGContextSetFillColorWithColor(context, self.fillColor.CGColor);
    CGContextSetLineWidth(context, 1.0);
    CGContextSetLineCap(context, kCGLineCapRound);
    CGContextSetLineJoin(context, kCGLineJoinRound);
    
    //画三角箭头
    CGPoint point = CGPointMake(rect.size.width, rect.size.height / 2.0);
    CGContextMoveToPoint(context, point.x, point.y);
    CGContextAddLineToPoint(context, 0, 0);
    CGContextAddLineToPoint(context, 0, rect.size.height);
    CGContextAddLineToPoint(context, point.x, point.y);
    
    //填充颜色
    CGContextClosePath(context);
    CGContextDrawPath(context, kCGPathEOFill);
}

@end
