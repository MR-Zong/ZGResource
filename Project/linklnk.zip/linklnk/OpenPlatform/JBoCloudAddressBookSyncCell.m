//
//  JBoCloudAddressBookSyncCell.m
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookSyncCell.h"
#import "JBoBasic.h"

@interface JBoCloudAddressBookSyncCell ()

//提示信息
@property(nonatomic,retain) UILabel *alertLabel;

@end

@implementation JBoCloudAddressBookSyncCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        CGFloat height = 50.0;
        
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_cloudAddressBookSyncInterval_, _cloudAddressBookSyncInterval_, height, height)];
        [self.contentView addSubview:_headImageView];
        
        CGFloat width = _width_ - _headImageView.right - _cloudAddressBookSyncInterval_ * 2;
        CGFloat size = 25.0; //checkBox大小
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.right + _cloudAddressBookSyncInterval_, _headImageView.top, width - size - _cloudAddressBookSyncInterval_, 25.0)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        height = (_cloudAddressBookSyncCellHeight_ - _cloudAddressBookSyncInterval_ * 2 - _nameLabel.height) / 2.0;
        
        _phoneNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _nameLabel.bottom, width, height)];
        _phoneNumLabel.backgroundColor = [UIColor clearColor];
        _phoneNumLabel.textColor = [UIColor grayColor];
        _phoneNumLabel.font = [UIFont systemFontOfSize:15.0];
        [self.contentView addSubview:_phoneNumLabel];
        
        _telLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _phoneNumLabel.bottom, width, height)];
        _telLabel.backgroundColor = [UIColor clearColor];
        _telLabel.textColor = [UIColor grayColor];
        _telLabel.font = [UIFont systemFontOfSize:15.0];
        [self.contentView addSubview:_telLabel];
        
        _remarkLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.left, _phoneNumLabel.bottom, width, 0)];
        _remarkLabel.backgroundColor = [UIColor clearColor];
        _remarkLabel.font = _cloudAddressBookSyncRemarkFont_;
        _remarkLabel.numberOfLines = 0;
        _remarkLabel.textColor = [UIColor grayColor];
        [self.contentView addSubview:_remarkLabel];
        
       
        _checkBox = [[JBoCheckBox alloc] initWithFrame:CGRectMake(_nameLabel.right + _cloudAddressBookSyncInterval_, _nameLabel.top, size, size) style:CheckBoxStyleDefault selectedImage:nil unselectedImage:nil];
        _checkBox.delegate = self;
        [self.contentView addSubview:_checkBox];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(_checkBox.left - _cloudAddressBookSyncInterval_ / 2.0, _checkBox.top, size + _cloudAddressBookSyncInterval_, _nameLabel.height)];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor grayColor];
        label.font = [UIFont systemFontOfSize:10.0];
        label.text = @"已同步";
        [self.contentView addSubview:label];
        self.alertLabel = label;
        [label release];
        
        self.alertLabel.hidden = YES;
        self.exist = NO;
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_phoneNumLabel release];

    [_checkBox release];
    [_alertLabel release];
    
    [super dealloc];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    if([NSString isEmpty:self.info.remark])
    {
        self.remarkLabel.hidden = YES;
        self.telLabel.hidden = NO;
    }
    else
    {
        self.remarkLabel.hidden = NO;
        self.telLabel.hidden = YES;
    }

    self.remarkLabel.height = self.info.remarkHeight;
}

- (void)setExist:(BOOL)exist
{
    if(_exist != exist)
    {
        _exist = exist;
        _checkBox.hidden = _exist;
        self.alertLabel.hidden = !_exist;
    }
}

- (void)checkBoxStyleDidChanged:(JBoCheckBox *)checkBox
{
    if([self.delegate respondsToSelector:@selector(cloudAddressBookSyncCell:didChangeSelectedState:)])
    {
        [self.delegate cloudAddressBookSyncCell:self didChangeSelectedState:checkBox.selected];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
