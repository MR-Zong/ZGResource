//
//  JBoOpenPlatformMultiTextView.m
//  linklnk
//
//  Created by kinghe005 on 14-9-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformMultiTextView.h"
#import "JBoImageTextLabel.h"
#import "JBoBasic.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoCustomInsetLabel.h"
#import "JBoOpenPlatformInfo.h"

//文本信息的tag
#define _startTag_ 300

//
#define _imageStartTag_ 3000

@interface JBoOpenPlatformMultiTextView ()<JBoImageTextLabelDelegate,JBoMultiImageViewDelegate>

/**字体
 */
@property(nonatomic,retain) UIFont *font;

@end

@implementation JBoOpenPlatformMultiTextView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.font = _openPlatformTextFont_;
        self.backgroundColor = [UIColor clearColor];
        
    }
    return self;
}

- (void)dealloc
{
    [_info release];
    [_font release];
    
    [super dealloc];
}

#pragma mark- public method

/**通过下标获取label
 */
- (JBoImageTextLabel*)labelForIndex:(NSInteger) index
{
    if(index < self.info.contentInfos.count)
    {
        JBoImageTextLabel *label = (JBoImageTextLabel*)[self viewWithTag:index + _startTag_];
        return label;
    }
    
    return nil;
}

//加载视图
- (void)reloadData
{
    for(UIView *view in self.subviews)
    {
        if([view isKindOfClass:[JBoImageTextLabel class]] || [view isKindOfClass:[JBoMultiImageView class]])
        {
            [view removeFromSuperview];
        }
    }
    
    CGFloat y = 0;
    
    if(self.info.expand && self.info.contentInfos.count > 0)
    {
        self.layer.cornerRadius = 2.0;
        self.layer.borderColor = _navigationBarBackgroundDefaultColor_.CGColor;
        self.layer.borderWidth = 1.0;
    }
    else
    {
        self.layer.cornerRadius = 0;
        self.layer.borderColor = [UIColor clearColor].CGColor;
        self.layer.borderWidth = 0;
    }
    
    //内容收缩，只显示3张图片
    if(!self.info.expand)
    {
        NSRange range = NSMakeRange(0, MIN(_openPlatformShowImageCountWhenClose_, self.info.imageInfos.count));
        JBoMultiImageView *multiImageView = [self multiImageViewWithIndex:0 y:y array:[self imageURLArrayForRange:range]];
        [self addSubview:multiImageView];
        y = multiImageView.bottom + _openPlatformTextBoxPadding_;
        self.height = y;
        return;
    }
    
    BOOL canAddText = [self.info canAddTextInfo];
    
    
    if(canAddText)
    {
        if(!self.addTextInfoButton)
        {
            _addTextInfoButton = [UIButton buttonWithType:UIButtonTypeCustom];
            [_addTextInfoButton addTarget:self action:@selector(addTextInfo:) forControlEvents:UIControlEventTouchUpInside];
            [_addTextInfoButton setTitle:@"十 添加文字" forState:UIControlStateNormal];
            [_addTextInfoButton setShowsTouchWhenHighlighted:YES];
            [_addTextInfoButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
            _addTextInfoButton.titleLabel.font = [UIFont boldSystemFontOfSize:15.0];
            [_addTextInfoButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [_addTextInfoButton setTitleColor:[UIColor grayColor] forState:UIControlStateDisabled];
            [_addTextInfoButton setFrame:CGRectMake(0, 0, 100.0, _openPlatformAddTextButtonHeight_)];
            [self addSubview:_addTextInfoButton];
        }
        self.addTextInfoButton.hidden = NO;
        y = self.addTextInfoButton.bottom;
    }
    else
    {
        self.addTextInfoButton.hidden = YES;
    }
    
    //文本后面的图片数量起始
    NSInteger beginCount = 0;
    
    for(NSInteger i = 0;i < self.info.contentInfos.count;i ++)
    {
        JBoOpenPlatformTextInfo *info = [self.info.contentInfos objectAtIndex:i];
        
        if(info.content.length > 1 || ![NSString isEmpty:info.content])
        {
            JBoImageTextLabel *label = [self imageTextLabelWithFrame:CGRectMake(0, y, self.width, info.contentHeight)];
            label.tag = _startTag_ + i;
            label.attributes = info.textStyleInfos;
            label.text = info.content;
            [self addSubview:label];
        }
        
        y += info.contentHeight + _openPlatformTextBoxPadding_;
        
        NSInteger len = info.imageCount;
        
        if(beginCount + len > self.info.imageInfos.count || i == self.info.contentInfos.count - 1)
        {
            len = self.info.imageInfos.count - beginCount;
            if(len < 0)
            {
                len = 0;
            }
        }
        
        JBoMultiImageView *multiImageView = [self multiImageViewWithIndex:i y:y array:[self imageURLArrayForRange:NSMakeRange(beginCount, len)]];
        [self addSubview:multiImageView];
        
        y += multiImageView.height + _openPlatformTextBoxPadding_;
        if(multiImageView.height == 0)
            y -= _openPlatformTextBoxPadding_;
        
        beginCount += len;
    }
    
    self.height = y;
}

/**重新加载图片
 */
- (void)reloadImageAtIndex:(NSInteger)index withURL:(NSString *)URL
{
    //计算
    NSInteger idex = index;
    NSInteger position = 0;
    
    if(self.info.expand)
    {
        position = [self.info textIndexFromImageIndex:index index:&idex];
    }
    
 //   NSLog(@"position %d, index = %d , idex = %d", position, index, idex);
    
    JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:_imageStartTag_ + position];
    [multiImageView reloadCellAtIndex:idex withURL:URL];
}

/**设置logo
 */
- (void)setupLogoStyle:(JBoMultiImageViewCellLogoStyle)logoStyle atIndex:(NSInteger)index
{
    NSInteger idex = index;
    NSInteger position = 0;
    
    if(self.info.expand)
    {
        position = [self.info textIndexFromImageIndex:index index:&idex];
    }
    
    JBoMultiImageView *multiImageView = (JBoMultiImageView*)[self viewWithTag:_imageStartTag_ + position];
    [multiImageView setupCellLogoStyle:logoStyle atIndex:idex];
}

#pragma mark- private method

//文本信息长按
- (void)longPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        if([self.delegate respondsToSelector:@selector(openPlatformMultiTextView:didLongPressLabelAtIndex:)])
        {
            NSInteger index = longPress.view.tag - _startTag_;
            [self.delegate openPlatformMultiTextView:self didLongPressLabelAtIndex:index];
        }
    }
}

//添加文本信息
- (void)addTextInfo:(id) sender
{
    if([self.delegate respondsToSelector:@selector(openPlatformMultiTextViewDidAddTextInfo:)])
    {
        [self.delegate openPlatformMultiTextViewDidAddTextInfo:self];
    }
}

/**创建label
 */
- (JBoImageTextLabel*)imageTextLabelWithFrame:(CGRect) frame
{
    JBoImageTextLabel *label = [[JBoImageTextLabel alloc] initWithFrame:frame];
    
    label.userInteractionEnabled = YES;
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    [label addGestureRecognizer:longPress];
    [longPress release];
    
    label.delegate = self;
    label.backgroundColor = [UIColor clearColor];
    
    label.textInset = _openPlatformTextInset_;
    label.textColor = [UIColor blackColor];
    label.wordInset = _openPlatformTextWordInset_;
    label.minLineHeight = _openPlatformTextLineHeight_;
    label.font = self.font;
    
    return [label autorelease];
}

/**创建multiImageView
 */
- (JBoMultiImageView*)multiImageViewWithIndex:(NSInteger) index y:(CGFloat) y array:(NSArray*) array;
{
    CGFloat height = [JBoMultiImageView getThumbnailHeightWithCount:array.count];
    
    JBoMultiImageView *multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectMake(_openPlatformTextInset_, y, self.width, height)];
    multiImageView.clipsToBounds = YES;
    multiImageView.delegate = self;
    multiImageView.row = index;
    multiImageView.enableLongPressGesture = self.info.expand;
    multiImageView.tag = _imageStartTag_ + index;
    multiImageView.images = array;
    multiImageView.onlythumbnail = YES;
    
    return [multiImageView autorelease];
}

//通过图片集合的行数 获取图片路径
- (NSArray*)imageURLArrayForRange:(NSRange) range
{
    NSArray *imageInfos = nil;
    if(!self.info.expand)
    {
        NSInteger len = MIN(_openPlatformShowImageCountWhenClose_, self.info.imageInfos.count);
        
        imageInfos = [self.info.imageInfos objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, len)]];
    }
    else
    {
        if(range.location + range.length <= self.info.imageInfos.count)
        {
            imageInfos = [self.info.imageInfos objectsAtIndexes:[NSIndexSet indexSetWithIndexesInRange:range]];
        }
    }
    
    if(imageInfos)
    {
        return [JBoOpenPlatformImageInfo getThumbnailURLsFromImageInfos:imageInfos];
    }
    
    return nil;
}


#pragma mark- JBoImageTextLabel 代理

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(openPlatformMultiTextView:didSelectURL:)])
    {
        [self.delegate openPlatformMultiTextView:self didSelectURL:url];
    }
}

#pragma mark- multiImageView 代理

- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(openPlatformMultiTextView:didSelectedImageAtIndex:)])
    {
        NSInteger idex = multiImageView.row;
        NSInteger count = 0;
        for(NSInteger i = 0;i < idex && i < self.info.contentInfos.count;i ++)
        {
            JBoOpenPlatformTextInfo *info = [self.info.contentInfos objectAtIndex:i];
            count += info.imageCount;
        }
        
        [self.delegate openPlatformMultiTextView:self didSelectedImageAtIndex:count + index];
    }
}

- (void)multiImageView:(JBoMultiImageView *)multiImageView didLongPressedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(openPlatformMultiTextView:didLongPressedImageAtIndex:)])
    {
        NSInteger idex = multiImageView.row;
        NSInteger count = 0;
        for(NSInteger i = 0;i < idex && i < self.info.contentInfos.count;i ++)
        {
            JBoOpenPlatformTextInfo *info = [self.info.contentInfos objectAtIndex:i];
            count += info.imageCount;
        }
        
        [self.delegate openPlatformMultiTextView:self didLongPressedImageAtIndex:count + index];
    }
}

#pragma mark- class method

/**获取图片高度
 */
+ (CGFloat)imageHeightForImageCount:(NSInteger)count
{
    return [JBoMultiImageView getThumbnailHeightWithCount:count];
}

@end
