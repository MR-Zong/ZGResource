//
//  JBoOpenPlatformGroupManagerViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformGroupManagerViewController;
@class JBoOpenPlatformGroupInfo;

/**云名片分组管理 代理
 */
@protocol JBoOpenPlatformGroupManagerViewControllerDelegate <NSObject>

/**删除分组
 *@param info 要删除的分组信息
 */
- (void)openPlatformGroupManagerViewController:(JBoViewController*) viewController didRemoveGroupInfo:(JBoOpenPlatformGroupInfo*) info;

/**修改分组
 *@param info 要修改的分组信息
 */
- (void)openPlatformGroupManagerViewController:(JBoViewController*) viewController didModifyGroupInfo:(JBoOpenPlatformGroupInfo*) info;

@end

/**云名片分组管理
 */
@interface JBoOpenPlatformGroupManagerViewController : JBoViewController<UIActionSheetDelegate,UIAlertViewDelegate,UITextFieldDelegate>

@property(nonatomic,assign) id<JBoOpenPlatformGroupManagerViewControllerDelegate> delegate;

/**分组信息内容 数组元素是JBoOpenPlatformGroupInfo对象
 */
@property(nonatomic,retain) NSMutableArray *infoArray;

@end
