//
//  JBoOpenPlatformMenu.h
//  linklnk
//
//  Created by kinghe005 on 14-10-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoBasic.h"

/**云名片信息菜单
 */
@interface JBoOpenPlatformMenu : UIView

/**删除按钮
 */
@property(nonatomic,readonly) UIButton *deleteButton;

/**公开隐藏按钮
 */
@property(nonatomic,readonly) UIButton *visibleButton;

/**置顶按钮
 */
@property(nonatomic,readonly) UIButton *stickButton;

/**更新顺序按钮
 */
@property(nonatomic,readonly) UIButton *updateOrderButton;

/**移动按钮
 */
@property(nonatomic,readonly) UIButton *moveButton;

/**预约的人
 */
@property(nonatomic,readonly) UIButton *subscribeButton;

/**云名片信息选择按钮
 */
@property(nonatomic,readonly) UIButton *selectedButton;

/**云名片操作类型
 */
@property(nonatomic,readonly) JBoOpenPlatformOperationType operationType;

/**构造方法
 *@param origin 视图的位置
 *@param size 按钮的大小
 *@param type 云名片操作类型
 *@return 一个根据按钮大小生成的 view
 */
- (id)initWithOrigin:(CGPoint) origin ItemSize:(CGSize) size operationType:(JBoOpenPlatformOperationType) type;

@end
