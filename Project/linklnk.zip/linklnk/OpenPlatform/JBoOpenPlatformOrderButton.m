//
//  JBoOpenPlatformOrderButton.m
//  linklnk
//
//  Created by kinghe005 on 15-3-5.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformOrderButton.h"
#import "JBoNumberBadge.h"

@interface JBoOpenPlatformOrderButton ()

//红点
@property(nonatomic,retain) JBoNumberBadge *badge;

@end

@implementation JBoOpenPlatformOrderButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        UIImage *image = [UIImage imageNamed:@"order_manager"];
        frame.size = image.size;
        self.frame = frame;
        
        _button = [UIButton buttonWithType:UIButtonTypeCustom];
        [_button setImage:image forState:UIControlStateNormal];
        [_button setFrame:self.bounds];
        [_button setShowsTouchWhenHighlighted:YES];
        [self addSubview:_button];
    }
    
    return self;
}

- (void)dealloc
{
    [_badge release];
    
    [super dealloc];
}

- (void)setRedPoint:(BOOL)redPoint
{
    if(_redPoint != redPoint)
    {
        _redPoint = redPoint;
        
        if(!self.badge)
        {
            CGFloat size = 10.0;
            JBoNumberBadge *badge = [[JBoNumberBadge alloc] initWithFrame:CGRectMake(self.width - size, 0, size, size)];
            badge.point = YES;
            badge.userInteractionEnabled = NO;
            [self addSubview:badge];
            self.badge = badge;
            [badge release];
        }
        
        self.badge.hidden = !_redPoint;
    }
}

@end
