//
//  JBoCloudAddressBookSharedViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-9-4.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookSharedViewController.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoCustomInsetLabel.h"

@interface JBoCloudAddressBookSharedViewController ()<UIActionSheetDelegate>

//信息列表
@property(nonatomic,retain) UITableView *tableView;

//选中的cell
@property(nonatomic,retain) NSIndexPath *selectedIndexPath;

@end

@implementation JBoCloudAddressBookSharedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.title = @"云名片夹共享";
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_groupInfos release];
    [_tableView release];
    [_selectedIndexPath release];
    [_url release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.backItem = YES;
    self.view.backgroundColor = _mainBackgroundColor_;
    [self loadInitView];
}

- (void)loadInitView
{
    JBoCustomInsetLabel *alertLabel = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, 0, _width_, 60.0)];
    alertLabel.insets = UIEdgeInsetsMake(0, 10.0, 0, 10.0);
    alertLabel.numberOfLines = 0;
    alertLabel.backgroundColor = [UIColor clearColor];
    alertLabel.font = [UIFont systemFontOfSize:14.0];
    alertLabel.textColor = [UIColor grayColor];
   // alertLabel.textAlign = JBoTextAlignmentCenter;
    alertLabel.text = @"您可以共享云名片夹，也可以共享云名片夹中的某个分组";
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    
    tableView.tableHeaderView = alertLabel;
    [alertLabel release];
    
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
}

#pragma mark- tableView代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(section == 0)
    {
        return 1;
    }
    else
    {
        return self.groupInfos.count;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        
        UIImage *arrow = [UIImage imageNamed:@"arrow.png"];
        
        UIImageView *imageView = [[UIImageView alloc] initWithImage:arrow];
        imageView.contentMode = UIViewContentModeCenter;
        cell.accessoryView = imageView;
        [imageView release];
    }

    if(indexPath.section == 0)
    {
        cell.textLabel.text = @"全部";
    }
    else
    {
        JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:indexPath.row];
        cell.textLabel.text = info.groupName;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    self.selectedIndexPath = indexPath;
    
    NSString *title = nil;
    if(indexPath.section != 0)
    {
        JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:indexPath.row];
        title = [NSString stringWithFormat:@"复制%@通讯录", info.groupName];
    }
    else
    {
        title = @"复制全部通讯录";
    }
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:[NSString stringWithFormat:@"复制通讯录后，可通过%@、短信、微信、QQ、Line、易信、来往等粘贴发送通讯录给好友，好友查看该通讯录时根据您的云名片夹安全设置可能需要正确回答问题", self.appDelegate.appName]  delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:title, nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}

#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0:
        {
            NSString *content = nil;
            if(self.selectedIndexPath.section == 0)
                content = self.url;
            else
            {
                JBoCloudAddressBookGroupInfo *info = [self.groupInfos objectAtIndex:self.selectedIndexPath.row];
                content = info.url;
            }
            
            if(content)
            {
                UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
                pasteboard.string = content;
            }
            
            [self alertMsg:@"已复制到剪切板"];
        }
            break;
            
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
