//
//  JBoOpenPlatformModifyTitleViewController.h
//  linklnk
//
//  Created by kinghe005 on 14-11-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOpenPlatformInfo;
@class JBoOpenPlatformModifyTitleViewController;

@protocol JBoOpenPlatformModifyTitleViewControllerDelegate <NSObject>

/**修改完成
 */
- (void)openPlatformModityTitleController:(JBoOpenPlatformModifyTitleViewController*) viewController didFinishWithNewTitle:(NSString*) title;

@end

/**修改云名片标题
 */
@interface JBoOpenPlatformModifyTitleViewController : JBoViewController<UITextViewDelegate>

/**要修改的靓云台信息
 */
@property(nonatomic,readonly,retain) JBoOpenPlatformInfo *info;

@property(nonatomic,assign) id<JBoOpenPlatformModifyTitleViewControllerDelegate> delegate;

/**构造方法
 *@param info 云名片信息
 *@return 一个初始化的 JBoOpenPlatformModifyTitleViewController
 */
- (id)initWithInfo:(JBoOpenPlatformInfo*) info;

@end
