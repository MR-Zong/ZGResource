//
//  JBoOpenPlatformGroupCell.h
//  linklnk
//
//  Created by kinghe005 on 14-10-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoArrowPointingView.h"
#import "JBoHighlightView.h"

@class JBoWebToolButton;

/**云名片 sectionHeader的高度
 */
#define _openPlatformGroupHeaderHeight_ 40.0

/**云名片 cell的高度
 */
#define _openPlatformGroupCellHeight_ 45

/**云名片内容与边框的间隔
 */
#define _openPlatformGroupCellInterval_ 10.0

#pragma mark- serctionHeader

@protocol JBoopenPlatformGroupHeaderDelegate <NSObject>

/**添加次级分组
 *@param section 分组所在位置
 */
- (void)sectionHeaderDidSelectAtSection:(NSInteger) section;


@end

#ifdef __IPHONE_6_0

@class JBoopenPlatformGroupHeaderView;

/**云名片内的分组内容 ,ios 6.0以上才能用 tableSectionHeader
 */
@interface JBoopenPlatformGroupHeader : UITableViewHeaderFooterView
/**内容
 */
@property(nonatomic,readonly) JBoopenPlatformGroupHeaderView *headerView;

@end

#endif

/**云名片内的一级分组内容 ,ios 6.0以下用 tableSectionHeader
 */
@interface JBoopenPlatformGroupHeaderView : JBoHighlightView

/**所在section
 */
@property(nonatomic,assign) NSInteger section;

/**分组名称
 */
@property(nonatomic,readonly) UILabel *nameLabel;

/**添加按钮
 */
//@property(nonatomic,readonly) JBoWebToolButton *addButton;

/**关联的 sectionHeader ios6以下为 nil
 */
@property(nonatomic,assign) UIView *sectionHeader;

@property(nonatomic,assign) id<JBoopenPlatformGroupHeaderDelegate> delegate;

@end


#pragma mark- cell

/**云名片分组信息cell
 */
@interface JBoOpenPlatformGroupCell : UITableViewCell

@end
