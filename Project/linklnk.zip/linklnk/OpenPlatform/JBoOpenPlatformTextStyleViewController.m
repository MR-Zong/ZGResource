//
//  JBoOpenPlatformTextStyleViewController.m
//  linklnk
//
//  Created by kinghe005 on 14-10-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoOpenPlatformTextStyleViewController.h"
#import "JBoOpenPlatformTextStyleInfo.h"

/**样式类目信息
 */
@interface JBoOpenPlatformTextStyleCategoryInfo : NSObject

/**名称
 */
@property(nonatomic,copy) NSString *name;

/**所属样式信息 数组元素是 JBoOpenPlatformTextStyleInfo 对象
 */
@property(nonatomic,retain) NSArray *styleInfos;


@end

@implementation JBoOpenPlatformTextStyleCategoryInfo

- (void)dealloc
{
    [_name release];
    [_styleInfos release];
    
    [super dealloc];
}

@end

@interface JBoOpenPlatformTextStyleViewController ()

/**样式信息 数组元素是 JBoOpenPlatformTextStyleCategoryInfo 对象
 */
@property(nonatomic,retain) NSMutableArray *infoArray;

//列表
@property(nonatomic,retain) UITableView *tableView;

@end

@implementation JBoOpenPlatformTextStyleViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self)
    {
        self.title = @"样式";
    }
    
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    self.delegte = nil;
   // [_textStyleInfo release];
    [_infoArray release];
    [_tableView release];
    [_selectedTextStyleInfo release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)finish
{
    if([self.delegte respondsToSelector:@selector(openPlatformTextStyleDidSelect:)])
    {
//        self.textStyleInfo.textColor = self.selectedTextStyleInfo.textColor;
//        self.textStyleInfo.bold = self.selectedTextStyleInfo.bold;
        [self.delegte openPlatformTextStyleDidSelect:self];
    }
    [self back];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //初始化文本样式
    _selectedTextStyleInfo = [[JBoOpenPlatformTextStyleInfo alloc] init];
    _selectedTextStyleInfo.textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.backItem = YES;
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
    self.infoArray = [NSMutableArray arrayWithCapacity:2];
    
    //字体样式
    JBoOpenPlatformTextStyleCategoryInfo *info = [[[JBoOpenPlatformTextStyleCategoryInfo alloc] init] autorelease];
    info.name = @"字体";
    [self.infoArray addObject:info];
    
    NSMutableArray *infos1 = [NSMutableArray arrayWithCapacity:2];
    info.styleInfos = infos1;
    
    JBoOpenPlatformTextStyleInfo *styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.bold = NO;
    styleInfo.styleName = @"普通";
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.bold = YES;
    styleInfo.styleName = @"黑体";
    [infos1 addObject:styleInfo];
    
    //字体大小
    info = [[[JBoOpenPlatformTextStyleCategoryInfo alloc] init] autorelease];
    info.name = @"字体大小";
    [self.infoArray addObject:info];
    
    infos1 = [NSMutableArray arrayWithCapacity:3];
    info.styleInfos = infos1;
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.bold = NO;
    styleInfo.styleName = @"小";
    styleInfo.fontSize = 13;
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.bold = YES;
    styleInfo.styleName = @"中";
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.bold = YES;
    styleInfo.styleName = @"大";
    styleInfo.fontSize = 20;
    [infos1 addObject:styleInfo];
    
    //字体颜色
    info = [[[JBoOpenPlatformTextStyleCategoryInfo alloc] init] autorelease];
    info.name = @"字体颜色";
    [self.infoArray addObject:info];
    
    infos1 = [NSMutableArray arrayWithCapacity:7];
    info.styleInfos = infos1;
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"黑色";
    styleInfo.textColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"红色";
    styleInfo.textColor = [UIColor redColor];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"橙色";
    styleInfo.textColor = [UIColor orangeColor];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"黄色";
    styleInfo.textColor = [UIColor yellowColor];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"绿色";
    styleInfo.textColor = [UIColor greenColor];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"青色";
    styleInfo.textColor = [UIColor cyanColor];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"蓝色";
    styleInfo.textColor = [UIColor blueColor];
    [infos1 addObject:styleInfo];
    
    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
    styleInfo.styleName = @"紫色";
    styleInfo.textColor = [UIColor purpleColor];
    [infos1 addObject:styleInfo];
    
    //背景颜色
//    info = [[[JBoOpenPlatformTextStyleCategoryInfo alloc] init] autorelease];
//    info.name = @"背景颜色";
//    [self.infoArray addObject:info];
//    
//    infos1 = [NSMutableArray arrayWithCapacity:7];
//    info.styleInfos = infos1;
    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"无";
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"黑色";
//    styleInfo.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:1.0];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"红色";
//    styleInfo.backgroundColor = [UIColor redColor];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"橙色";
//    styleInfo.backgroundColor = [UIColor orangeColor];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"黄色";
//    styleInfo.backgroundColor = [UIColor yellowColor];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"绿色";
//    styleInfo.backgroundColor = [UIColor greenColor];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"青色";
//    styleInfo.backgroundColor = [UIColor cyanColor];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"蓝色";
//    styleInfo.backgroundColor = [UIColor blueColor];
//    [infos1 addObject:styleInfo];
//    
//    styleInfo = [[[JBoOpenPlatformTextStyleInfo alloc] init] autorelease];
//    styleInfo.styleName = @"紫色";
//    styleInfo.backgroundColor = [UIColor purpleColor];
//    [infos1 addObject:styleInfo];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStyleGrouped];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    [tableView release];
}

#pragma mark- tableView代理

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.infoArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    JBoOpenPlatformTextStyleCategoryInfo *info = [self.infoArray objectAtIndex:section];
    return info.styleInfos.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40.0;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    JBoOpenPlatformTextStyleCategoryInfo *info = [self.infoArray objectAtIndex:section];
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"header";
        UITableViewHeaderFooterView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        
        if(header == nil)
        {
            header = [[[UITableViewHeaderFooterView alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        
        header.textLabel.text = info.name;
        
        return header;
#endif
    }
    else
    {
        UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, 40.0)] autorelease];
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont boldSystemFontOfSize:15.0];
        label.textColor = [UIColor blackColor];
        label.text = info.name;
        
        return label;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"verify_correct"]];
        cell.accessoryView = imageView;
        [imageView release];
        
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoOpenPlatformTextStyleCategoryInfo *category = [self.infoArray objectAtIndex:indexPath.section];
    JBoOpenPlatformTextStyleInfo *info = [category.styleInfos objectAtIndex:indexPath.row];
    
    cell.textLabel.text = info.styleName;
    
    switch (indexPath.section)
    {
        case 0 :
        {
            cell.accessoryView.hidden = info.bold != self.selectedTextStyleInfo.bold;
        }
            break;
        case 1 :
        {
            cell.accessoryView.hidden = info.fontSize != self.selectedTextStyleInfo.fontSize;
        }
            break;
        case 2 :
        {
            cell.accessoryView.hidden = ![info.textColor isEqualToColor:self.selectedTextStyleInfo.textColor];
        }
            break;
        case 3 :
        {
            cell.accessoryView.hidden = !(info.backgroundColor == nil && self.selectedTextStyleInfo.backgroundColor == nil) || ![self.selectedTextStyleInfo.backgroundColor isEqualToColor:info.backgroundColor];
        }
            break;
        default:
            break;
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if(cell.accessoryView.hidden == YES)
    {
        JBoOpenPlatformTextStyleCategoryInfo *category = [self.infoArray objectAtIndex:indexPath.section];
        JBoOpenPlatformTextStyleInfo *info = [category.styleInfos objectAtIndex:indexPath.row];
        
        switch (indexPath.section)
        {
            case 0 :
            {
                self.selectedTextStyleInfo.bold = info.bold;
            }
                break;
            case 1 :
            {
                self.selectedTextStyleInfo.fontSize = info.fontSize;
            }
                break;
            case 2 :
            {
                self.selectedTextStyleInfo.textColor = info.textColor;
            }
                break;
            case 3 :
            {
                if([self.selectedTextStyleInfo.backgroundColor isEqualToColor:self.selectedTextStyleInfo.textColor])
                {
                    [self alertMessage:@"背景颜色不能和字体颜色一样"];
                }
                else
                {
                    self.selectedTextStyleInfo.backgroundColor = info.backgroundColor;
                }
            }
                break;
            default:
                break;
        }
        
        [tableView reloadData];
    }
}

@end
