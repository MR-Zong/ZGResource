//
//  JBoCloudAddressBookOperation.m
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCloudAddressBookOperation.h"
#import "JBoUserOperation.h"
#import "JBoBasic.h"
#import "JBoCloudAddressBookInfo.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoCloudAddressBookProblemInfo.h"
#import "JSONKit.h"

@implementation JBoCloudAddressBookOperation

#pragma mark- 分组

/**添加云通讯录分组 url
 */
+ (NSString*)addCloudAddressBookGroup
{
    return _addCloudAddressBookGroupInfo_;
}

/**添加云通讯录分组 参数
 *@param name 分组名称
 *@return post参数
 */
+ (NSDictionary*)addCloudAddressBookGroupParamWithName:(NSString*) name
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:name forKey:_cloudAddressBookGroupName_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    return dic;
}

/**获取添加云通讯录分组结果
 *@param 返回数据
 *@param info 新分组信息，将新的填充分组信息
 *@return 返回是否成功
 */
+ (BOOL)addCloudAddressBookGroupResultFromData:(NSData*) data withInfo:(JBoCloudAddressBookGroupInfo *)info
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    //NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        long long Id = [[dict valueWithKey:_cloudAddressBookGroupId_] longLongValue];
        NSString *url = [dict objectWithKey:_cloudAddressBookGroupURL_];
        
        info.url = url;
        info.Id = Id;
        
        return Id;
    }
    
    return NO;
}

/**删除云通讯录分组 url
 */
+ (NSString*)removeCloudAddressBookGroup
{
    return _removeCloudAddressBookGroupInfo_;
}

/**删除云通讯录分组 参数
 *@param Id 分组Id
 *@return post参数
 */
+ (NSDictionary*)removeCloudAddressBookGroupParamWithId:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_cloudAddressBookGroupId_];
    
    return dic;
}

/**更新云通讯录分组 url
 */
+ (NSString*)updateCloudAddressBookGroup
{
    return _updateCloudAddressBookGroupInfo_;
}

/**更新云通讯录分组 参数
 *@param Id 分组Id
 *@param name 分组新名称
 *@return post参数
 */
+ (NSDictionary*)updateCloudAddressBookGroupParamWithId:(long long) Id name:(NSString*) name
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:name forKey:_cloudAddressBookGroupName_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_cloudAddressBookGroupId_];
    
    return dic;
}

/**获取用户的所有云通讯录分组
 *@return get请求url
 */
+ (NSString*)getCloudAddressBookGroup
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getCloudAddressBookGroupInfo_, _rosterUserId_, [JBoUserOperation getUserId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    return url;
}

/**从返回数据中获取用户的云通讯录分组信息
 *@param data 返回数据
 *@return 数组元素是 JBoCloudAddressBookGroupInfo对象
 */
+ (NSMutableArray*)getCloudAddressBookGroupFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        for(NSDictionary *dict in dataArray)
        {
            JBoCloudAddressBookGroupInfo *info = [[JBoCloudAddressBookGroupInfo alloc] init];
            
            info.Id = [[dict valueWithKey:_cloudAddressBookGroupId_] longLongValue];
            info.groupName = [dict objectWithKey:_cloudAddressBookGroupName_];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return infoArray;
    }
    
    return nil;
}

#pragma mark- 验证问题

/**添加云通讯录验证问题 url
 */
+ (NSString*)addCloudAddressBookProblem
{
    return _addCloudAddressBookProblemInfo_;
}

/**添加云通讯录验证问题 参数
 *@param problem 问题
 *@param answer 答案
 */
+ (NSDictionary*)addCloudAddressBookProblemParam:(NSString *)problem answer:(NSString *)answer
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:problem forKey:_cloudAddressBookProblemName_];
    [dic setObject:answer forKey:_cloudAddressBookProblemAnswer_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    return dic;
}

/**获取添加云通讯录分组结果
 *@param 返回数据
 *@return 成功返回问题Id 否则返回0
 */
+ (long long)addCloudAddressBookProblemResultFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        long long Id = [[dict valueWithKey:_cloudAddressBookProblemId_] longLongValue];
        
        return Id;
    }
    
    return 0;
}

/**删除云通讯录验证问题 url
 */
+ (NSString*)removeCloudAddressBookProblem
{
    return _removeCloudAddressBookProblemInfo_;
}

/**删除云通讯录验证问题 参数
 *@param Id 问题Id
 *@return post参数
 */
+ (NSDictionary*)removeCloudAddressBookProblemParamWithId:(long long) Id
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_cloudAddressBookProblemId_];
    
    return dic;
}

/**更新云通讯录验证问题 url
 */
+ (NSString*)updateCloudAddressBookProblem
{
    return _updateCloudAddressBookProblemInfo_;
}

/**更新云通讯录验证问题 参数
 *@param Id 问题Id
 *@param problem 新问题
 *@param answer 新答案
 *@return post参数
 */
+ (NSDictionary*)updateCloudAddressBookProblemParamWithId:(long long) Id problem:(NSString*) problem answer:(NSString*) answer
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithDouble:Id] forKey:_cloudAddressBookProblemId_];
    [dic setObject:problem forKey:_cloudAddressBookProblemName_];
    [dic setObject:answer forKey:_cloudAddressBookProblemAnswer_];
    
    return dic;
}

/**获取某个用户的云通讯录验证问题
 *@param userId 验证问题的用户的userid
 *@return get请求url
 */
+ (NSString*)getCloudAddressBookProblemWithUserId:(NSString*) userId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getCloudAddressBookProblemInfo_, _getCloudAddressBookProblemUserId_, userId];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    return url;
}

/**从返回数据中获取用户的云通讯录验证问题信息
 *param data 返回数据
 *@return 数组元素是 JBoCloundAddressBookProblemInfo对象
 */
+ (NSMutableArray*)getCloudAddressBookProblemFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    //NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        NSMutableArray *infoArray = [NSMutableArray arrayWithCapacity:dataArray.count];
        for(NSDictionary *dict in dataArray)
        {
            JBoCloudAddressBookProblemInfo *info = [[JBoCloudAddressBookProblemInfo alloc] init];
            
            info.Id = [[dict valueWithKey:_cloudAddressBookProblemId_] longLongValue];
            info.problem = [dict objectWithKey:_cloudAddressBookProblemName_];
            info.answer = [dict objectWithKey:_cloudAddressBookProblemAnswer_];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return infoArray;
    }
    
    return nil;
}

#pragma mark- 云通讯录信息

/**添加云通讯录联系人 url
 */
+ (NSString*)addCloudAddressBookContact
{
    return _addCloudAddressBookContactInfo_;
}

/**添加云通讯录联系人 参数
 *@param groudId 添加到的分组Id
 *@param userId 新增的用户
 *@return post参数
 */
+ (NSDictionary*)addCloudAddressBookContactParamWithGroupId:(long long) groudId userId:(NSString*) userId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:groudId] forKey:_cloudAddressBookGroupId_];
    [dic setObject:userId forKey:_cloudAddressBookContactAddUserId_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    return dic;
}

/**获取添加云通讯录联系人结果
 *@param 返回数据
 *@return key为result 成功value 为 新联系人的信息，否则value为 失败错误码
 */
+ (NSDictionary*)addCloudAddressBookContactResultFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    //NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        
        JBoCloudAddressBookInfo *info = [[JBoCloudAddressBookInfo alloc] init];
        
        info.Id = [[dict valueWithKey:_cloudAddressBookContactId_] longLongValue];
        info.name = [dict objectWithKey:_cloudAddressBookContactName_];
        info.cloudURL = [dict objectWithKey:_cloudAddressBookContactLinkURL_];
        
        info.imageURL = [dict objectWithKey:_rosterImageURL_];
        info.role = [[dict objectWithKey:_rosterRole_] integerValue];
        info.sex = [[dict objectWithKey:_rosterSex_] integerValue];
        info.userId = [dict objectWithKey:_rosterUserId_];
        info.phoneNum = [dict objectWithKey:_rosterPhoneNum_];
        info.telePhone = [dict objectWithKey:_rosterEnterpriseTelephone_];
        
        NSDictionary *result = [NSDictionary dictionaryWithObject:info forKey:@"result"];
        [info release];
        
        return result;
    }
    else
    {
        return [NSDictionary dictionaryWithObject:code forKey:@"result"];
    }

}

/**删除云通讯录联系人 url
 */
+ (NSString*)removeCloudAddressBookContact
{
    return _removeCloudAddressBookContactInfo_;
}

/**删除云通讯录联系人 参数
 *@param Id 联系人的Id
 *@param groupId 分组Id
 *@return post参数
 */
+ (NSDictionary*)removeCloudAddressBookContactParamWithId:(long long) Id groupId:(long long)groupId
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_cloudAddressBookContactId_];
    [dic setObject:[NSNumber numberWithLongLong:groupId] forKey:_cloudAddressBookGroupId_];
    
    return dic;
}

/**获取用户的云通讯录联系人信息
 *@return get请求url
 */
+ (NSString*)getCloudAddressBookContactInfo
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getCloudAddressBookContactInfo_, _rosterUserId_, [JBoUserOperation getUserId]];
    
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**从返回数据中获取用户的云通讯录联系人信息
 *@param data 返回的数据
 *@param groupInfos 空的数组，将填充 JBoCloudAddressBookGroupInfo对象
 *@return 云通讯录链接
 */
+ (NSString*)getCloudAddressBookContactInfoFromData:(NSData *)data withArray:(NSMutableArray *)groupInfos
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSString *url = [dic objectWithKey:_cloudAddressBookURL_];
        
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoCloudAddressBookGroupInfo *groupInfo = [[JBoCloudAddressBookGroupInfo alloc] init];
            
            groupInfo.Id = [[dict valueWithKey:_cloudAddressBookGroupId_] longLongValue];
            groupInfo.groupName = [dict valueWithKey:_cloudAddressBookGroupName_];
            groupInfo.url = [dict objectWithKey:_cloudAddressBookGroupURL_];
            
            NSArray *normalInfos = [dict arrayForKey:_cloudAddressBookContactMembers_];
         
            for(NSDictionary *dicts in normalInfos)
            {
                JBoCloudAddressBookInfo *info = [[JBoCloudAddressBookInfo alloc] init];
                
                info.Id = [[dicts valueWithKey:_cloudAddressBookContactId_] longLongValue];
                info.name = [dicts objectWithKey:_cloudAddressBookContactName_];
                info.cloudURL = [dicts objectWithKey:_cloudAddressBookContactLinkURL_];
                
                info.imageURL = [dicts objectWithKey:_rosterImageURL_];
                info.role = [[dicts objectWithKey:_rosterRole_] integerValue];
                info.sex = [[dicts objectWithKey:_rosterSex_] integerValue];
                info.userId = [dicts objectWithKey:_rosterUserId_];
                info.phoneNum = [dicts objectWithKey:_rosterPhoneNum_];
                info.telePhone = [dicts objectWithKey:_rosterEnterpriseTelephone_];
                info.phoneState = [[dicts valueWithKey:_rosterPhoneState_] boolValue];
                
                [groupInfo.infos addObject:info];
                [info release];
            }
            
            NSArray *webInfos = [dict arrayForKey:_cloudAddressBookGroupWebSubmitInfo_];
            for(NSDictionary *dicts in webInfos)
            {
                JBoCloudAddressBookInfo *info = [[JBoCloudAddressBookInfo alloc] init];
                
                info.Id = [[dicts valueWithKey:_cloudAddressBookWebSubmitInfoId_] longLongValue];
                info.name = [dicts objectWithKey:_cloudAddressBookWebSubmitInfoName_];
                info.phoneNum = [dicts objectWithKey:_cloudAddressBookWebSubmitInfoPhone_];
                info.remark = [dicts objectWithKey:_cloudAddressBookWebSubmitInfoRemarkMsg_];
                info.time = [dicts objectWithKey:_cloudAddressBookWebSubmitInfoTime_];
                
                if(![NSString isEmpty:info.phoneNum])
                {
                    info.phoneState = YES;
                }
                
                [groupInfo.infos addObject:info];
                [info release];
            }
            
            [groupInfos addObject:groupInfo];
            [groupInfo release];
            
        }
        
        return url;
    }
    
    return nil;
}

/**移动云通讯录联系人到某一分组 url
 */
+ (NSString*)moveCloudAddressBookContact
{
    return _moveCloudAddressBookContactInfo_;
}

/**移动云通讯录联系人到某一分组 参数
 *@param Id 联系人Id
 *@param groupId 分组Id
 *@return post参数
 */
+ (NSDictionary*)moveCloudAddressBookContactParamWithId:(long long) Id groupId:(long long) groupId groupName:(NSString *)groupName
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:groupId] forKey:_cloudAddressBookContactMoveGroupId_];
    [dic setObject:[NSNumber numberWithLongLong:Id] forKey:_cloudAddressBookContactId_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    
    if(groupName)
    {
        [dic setObject:groupName forKey:_cloudAddressBookGroupName_];
    }
    
    return dic;
}

/**获取移动云通讯录联系人到某一分组结果
 *@param 返回数据
 *@return 成功返回分组Id(当是添加到新分组时） 或0 否则返回-1
 */
+ (long long)moveCloudAddressBookContactProblemResultFromData:(NSData*) data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
   // NSLog(@"%@",dic);
    
    if([code intValue] == _codeSuccess_)
    {
        NSDictionary *dict = [dic dictionaryForKey:_data_];
        long long Id = [[dict valueWithKey:_cloudAddressBookGroupId_] longLongValue];
        
        return Id;
    }
    
    return -1;
}

@end
