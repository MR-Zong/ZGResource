//
//  JBoOpenPlatformGroupInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-10-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

//分组和次级分组的最大数量
#define _openPlatformGroupMaxCount_ 3
#define _openPlatformSecondaryGroupMaxCount_ 4

/**云名片分组信息
 */
@interface JBoOpenPlatformGroupInfo : NSObject

/**分组Id
 */
@property(nonatomic,assign) long long Id;

/**分组名称
 */
@property(nonatomic,copy) NSString *name;

/**所属的上一级分组Id
 */
@property(nonatomic,assign) long long superId;

/**所属上一级的分组名称
 */
@property(nonatomic,copy) NSString *superName;


/**分组链接，可打开该分组的所有云名片信息
 */
@property(nonatomic,copy) NSString *url;

/**次级分组信息 数组元素是 JBoOpenPlatformGroupInfo 对象
 */
@property(nonatomic,retain) NSMutableArray *secondaryInfos;

/**要显示的标题
 */
- (NSString*)title;

@end
