//
//  JBoCloudAddressBookProblemManagerViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-9-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**云名片夹安全验证问题管理
 */
@interface JBoCloudAddressBookProblemManagerViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate>

@end
