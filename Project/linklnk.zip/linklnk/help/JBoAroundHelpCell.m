//
//  JBoAroundHelpCell.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAroundHelpCell.h"
#import "JBoBasic.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoImageTextTool.h"

#define _labelHeight_ 30
#define _nameLabelWidth_ 100

#define _headSize_ 35.0

@interface JBoAroundHelpCell ()<JBoImageTextLabelDelegate>


@end

@implementation JBoAroundHelpCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentView.backgroundColor = [UIColor clearColor];
        
        UIImage *bgImage = [UIImage imageNamed:@"helpCellBg"];
        _bgImageView = [[UIImageView alloc] initWithImage:bgImage];
        _bgImageView.frame = CGRectMake(0, 0, _width_, _aroundHelpHeight_);
        [self.contentView addSubview:_bgImageView];
        
        _bgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _aroundHelpHeight_)];
        [self.contentView addSubview:_bgView];
        
        
        CGFloat width = _width_ - _aroundHelpCellInteval_ * 3 - _headSize_;
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_aroundHelpCellInteval_, _aroundHelpCellInteval_, _headSize_, _headSize_)];
        _headImageView.userInteractionEnabled = YES;
        _headImageView.layer.cornerRadius = 17.0;
        [_bgView addSubview:_headImageView];
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _aroundHelpCellInteval_, _aroundHelpCellInteval_, width * 2 / 3, _aroundHelpControlHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:15.0];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.textColor = [UIColor whiteColor];
        [_bgView addSubview:_nameLabel];
        
        //        _matchIdLabel = [[UILabel alloc] initWithFrame:CGRectMake(_width_ - _aroundHelpCellInteval_ - width * 2 / 3, _nameLabel.frame.origin.y, width * 2 / 3, _aroundHelpControlHeight_)];
        //        _matchIdLabel.backgroundColor = [UIColor clearColor];
        //        _matchIdLabel.textColor = [UIColor grayColor];
        //        _matchIdLabel.textAlignment = NSTextAlignmentRight;
        //        _matchIdLabel.font = [UIFont systemFontOfSize:14.0];
        //        [self.contentView addSubview:_matchIdLabel];
        
        _locationLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x + _nameLabel.frame.size.width, _nameLabel.frame.origin.y, width / 3, _aroundHelpControlHeight_)];
        _locationLabel.backgroundColor = [UIColor clearColor];
        [_locationLabel setTextAlign:JBoTextAlignmentRight];
        _locationLabel.textColor = [UIColor whiteColor];
        _locationLabel.font = [UIFont systemFontOfSize:14.0];
        [_bgView addSubview:_locationLabel];
        
//        JBoDashLineView *dashLineView = [[JBoDashLineView alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _locationLabel.frame.origin.y + _locationLabel.frame.size.height, width, 0.5)];
//        [self.contentView addSubview:dashLineView];
//        [dashLineView release];
        
        CGFloat buttonHeight = 40.0;
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _locationLabel.frame.origin.y + _locationLabel.frame.size.height, width, _aroundHelpHeight_ - _locationLabel.frame.origin.y - _locationLabel.frame.size.height - _aroundHelpCellInteval_ - buttonHeight)];
        _contentLabel.textColor = [UIColor whiteColor];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.horizontalAlignmentCenter = YES;
        _contentLabel.verticalAlignmentCenter = YES;
        _contentLabel.delegate = self;
        [_bgView addSubview:_contentLabel];
        
        
        UIImage *image = [UIImage imageNamed:@"helpComment_icon"];
        
        _commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_commentButton setFrame:CGRectMake(_width_ - image.size.width - _aroundHelpCellInteval_ * 3, _contentLabel.bottom, image.size.width, buttonHeight)];
        _commentButton.backgroundColor = [UIColor clearColor];
        [_commentButton setImage:image forState:UIControlStateNormal];
        [_commentButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_commentButton addTarget:self action:@selector(comment:) forControlEvents:UIControlEventTouchUpInside];
        [_bgView addSubview:_commentButton];
        
        image = [UIImage imageNamed:@"helpPraise_icon"];
        CGFloat buttonWidth = image.size.width + 80.0;
        _praiseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _praiseButton.backgroundColor = [UIColor clearColor];
        [_praiseButton setFrame:CGRectMake(_aroundHelpCellInteval_ * 3, _contentLabel.bottom, buttonWidth, buttonHeight)];
        
        [_praiseButton.titleLabel setFont:[UIFont systemFontOfSize:12.0]];
        [_praiseButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        [_praiseButton setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];
        [_praiseButton setImage:image forState:UIControlStateNormal];
        [_praiseButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_praiseButton addTarget:self action:@selector(praise:) forControlEvents:UIControlEventTouchUpInside];
        [_bgView addSubview:_praiseButton];
    }
    return self;
}

- (void)setPraiseCount:(long long)praiseCount
{
    _praiseCount = praiseCount;
    [_praiseButton setTitle:[NSString stringWithFormat:@"%lld",_praiseCount] forState:UIControlStateNormal];
}

- (void)comment:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(aroundHelpCellDidComment:)])
    {
        [self.delegate aroundHelpCellDidComment:self];
    }
}

- (void)praise:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(aroundHelpCellDidPraise:)])
    {
        [self.delegate aroundHelpCellDidPraise:self];
    }
}

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(aroundHelpCell:didSelectedURL:)])
    {
        [self.delegate aroundHelpCell:self didSelectedURL:url];
    }
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_locationLabel release];
    [_contentLabel release];
    
    [_bgView release];
    [_bgImageView release];
    
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
