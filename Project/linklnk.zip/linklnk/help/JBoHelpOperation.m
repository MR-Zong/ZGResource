//
//  JBoHelpOperation.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoHelpOperation.h"
#import "JBoAppDelegate.h"
#import "JBoHelpInfo.h"
#import "JBoAroundHelpInfo.h"
#import "JBoHelpCommentDataObject.h"
#import "JBoUserOperation.h"
#import "JSONKit.h"
#import "NSDictionary+customDic.h"
#import "JBoImageTextTool.h"


@implementation JBoHelpOperation

#pragma mark- 获取匿名

/**根据地理位置获取匿名信息
 *@param pageNum 页码
 *@param rows 每页数量
 *@param coordinate 地理位置经纬度
 *@param radius 范围，米
 *@param lastHelpId 每页最后一条信息的id，第一页不传
 *@return get请求
 */
+ (NSString*)getAroundHelpInfoWithPageNum:(int)pageNum rows:(int)rows currentCoornidate:(CLLocationCoordinate2D)coordinate radius:(int)radius lastHelpId:(long long)lastHelpId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%d&%@=%d&%@=%f&%@=%f&%@=%d&%@=%@&%@=%lld",_getAroundHelpInfo_, _pageNum_, pageNum, _rows_, rows, _helpLatitude_, coordinate.latitude, _helpLongitude_, coordinate.longitude, _helpRadius_, radius, _userId_, [JBoUserOperation getUserId], _helpID_, lastHelpId];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    return url;
}

/**从返回的数据获取周围匿名信息
 *@param data 返回的数据
 *@param coordinate 获取匿名时的地理位置经纬度 用于计算距离
 *@return 数组元素是 JBoAroundHelpInfo
 */
+ (NSMutableArray*)getAroundHelpInfoFromData:(NSData *)data withCurrentCoordinate:(CLLocationCoordinate2D)coordinate
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSMutableArray *infoArray = [[NSMutableArray alloc] init];
        NSArray *dataArray = [dic arrayForKey:_data_];
        
        for(NSDictionary *dataDic in dataArray)
        {
            JBoAroundHelpInfo *helpInfo = [[JBoAroundHelpInfo alloc] init];
            
            helpInfo.helpID = [[dataDic valueWithKey:_helpID_] longLongValue];
            helpInfo.helpMsg = [dataDic objectWithKey:_helpMessage_];
            helpInfo.helpDate = [dataDic objectWithKey:_helpDate_];
            
            helpInfo.praiseCount = [[dataDic valueWithKey:_secretPrasieCount_] longLongValue];
            helpInfo.praise = [[dataDic valueWithKey:_secretIsPraise_] boolValue];
            
            helpInfo.coordinate = CLLocationCoordinate2DMake([[dataDic valueWithKey:_helpLatitude_] doubleValue], [[dataDic valueWithKey:_helpLongitude_] doubleValue]);
            
            helpInfo.distance = [JBoImageTextTool getDistanceBetweenCoordinate:coordinate andOtherCoordinate:helpInfo.coordinate];
            
            helpInfo.userID = [dataDic objectWithKey:_rosterUserId_];
            
            NSString *images = [dataDic objectWithKey:_helpImages_];
            helpInfo.imageURLArray = [JBoImageTextTool getImageURLsFromStr:images];
            
            NSArray *commentArray = [dataDic objectWithKey:_helpComment_];
            NSMutableArray *commentInfoArray = [[NSMutableArray alloc] init];
            
            for(NSDictionary *commentDic in commentArray)
            {
                JBoHelpCommentInfo *info = [[JBoHelpCommentInfo alloc] init];
                
                info.commentID = [[commentDic valueWithKey:_helpCommentID_] longLongValue];
                info.commentDate = [commentDic objectWithKey:_helpCommentDate_];
                info.commentMsg = [commentDic objectWithKey:_helpCommentMsg_];
                info.replyCount = 0;
                info.userID = [commentDic objectWithKey:_helpCommentUser_];
                
                info.parentCommentID = [[commentDic valueWithKey:_helpCommentParentId_] longLongValue];
                
                [commentInfoArray addObject:info];
                //                if([info.parentCommentID isEqualToString:_helpParentCommentIDDefaultValue_])
                //                {
                //                    [commentInfoArray addObject:comment];
                //                }
                //                else
                //                {
                //                    for(JBoHelpCommentDataObject *dataObject in commentInfoArray)
                //                    {
                //                        if([JBoHelpOperation addCommentInfo:comment inDataObject:dataObject])
                //                        {
                //                            break;
                //                        }
                //                    }
                //                }
                [info release];
            }
            
            helpInfo.commentInfoArray = commentInfoArray;
            helpInfo.commentCount = commentInfoArray.count;
            
            [commentInfoArray release];
            [infoArray addObject:helpInfo];
            [helpInfo release];
        }
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}


/**获取用户发布的附近匿名信息
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求 url
 */
+ (NSString*)getUserHelpInfoWithPageNum:(int)pageNum rows:(int)rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getUserHelpInfo_, _userId_, [JBoUserOperation getUserId], _pageNum_, pageNum, _rows_, rows];
    url = [JBoUserOperation md5Url:url withUserId:NO];
    
    return url;
}

/**从返回的数据获取用户发布附近匿名信息
 *@param data 返回的数据
 *@return 数组元素是 JBoHelpInfo
 */
+ (NSMutableArray*)getUserHelpInfoFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [[NSMutableArray alloc] init];
        for(NSDictionary *dataDic in dataArray)
        {
            JBoHelpInfo *helpInfo = [[JBoHelpInfo alloc] init];
            
            helpInfo.helpID = [[dataDic valueWithKey:_helpID_] longLongValue];
            helpInfo.helpMsg = [dataDic objectWithKey:_helpMessage_];
            helpInfo.helpDate = [dataDic objectWithKey:_helpDate_];
            
            helpInfo.praiseCount = [[dataDic valueWithKey:_secretPrasieCount_] longLongValue];
            helpInfo.praise = [[dataDic valueWithKey:_secretIsPraise_] boolValue];
            
            NSString *images = [dataDic objectWithKey:_helpImages_];
            helpInfo.imageURLArray = [JBoImageTextTool getImageURLsFromStr:images];
            
            NSArray *commentArray = [dataDic objectWithKey:_helpComment_];
            NSMutableArray *commentInfoArray = [[NSMutableArray alloc] init];
            
            for(NSDictionary *commentDic in commentArray)
            {
                JBoHelpCommentInfo *info = [[JBoHelpCommentInfo alloc] init];
                
                info.commentID = [[commentDic valueWithKey:_helpCommentID_] longLongValue];
                info.commentDate = [commentDic objectWithKey:_helpCommentDate_];
                info.commentMsg = [commentDic objectWithKey:_helpCommentMsg_];
                info.replyCount = 0;
                info.userID = [commentDic objectWithKey:_helpCommentUser_];
                
                info.parentCommentID = [[commentDic valueWithKey:_helpCommentParentId_] longLongValue];
                
               // JBoHelpCommentDataObject *comment = [[JBoHelpCommentDataObject alloc] initWithHelpInfo:info
                //                                                                            childArray:nil];
                [commentInfoArray addObject:info];
//                if([info.parentCommentID isEqualToString:_helpParentCommentIDDefaultValue_])
//                {
//                    [commentInfoArray addObject:comment];
//                }
//                else
//                {
//                    for(JBoHelpCommentDataObject *dataObject in commentInfoArray)
//                    {
//                        if([JBoHelpOperation addCommentInfo:comment inDataObject:dataObject])
//                        {
//                            break;
//                        }
//                    }
//                }
                [info release];
              //  [comment release];
            }
            
            helpInfo.commentInfoArray = commentInfoArray;
            helpInfo.commentCount = commentInfoArray.count;
            
            [infoArray addObject:helpInfo];
            
            [commentInfoArray release];
            [helpInfo release];
        }
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}

+ (BOOL)addCommentInfo:(JBoHelpCommentDataObject*) commentInfo inDataObject:(JBoHelpCommentDataObject*) dataObject
{
    if(commentInfo.parentCommentInfo.parentCommentID == dataObject.parentCommentInfo.commentID)
    {
        if(!dataObject.childArray)
        {
            dataObject.childArray = [[[NSMutableArray alloc] init] autorelease];
        }
        [dataObject.childArray addObject:commentInfo];
        dataObject.parentCommentInfo.replyCount ++;
        return YES;
    }
    else
    {
        for(JBoHelpCommentDataObject *data in dataObject.childArray)
        {
            [JBoHelpOperation addCommentInfo:commentInfo inDataObject:data];
        }
    }
    return NO;
}

#pragma mark- 发布附近匿名

/**发布附近匿名 URL
 *@return post请求 url
 */
+ (NSString*)getReleaseHelpInfoURL
{
    return _releaseHelpInfo_;
}

/**发布附近匿名 参数
 *@param msg 内容
 *@param lat 经度
 *@param lon 纬度
 *@param addr 地址
 *@return post 请求参数
 */
+ (NSDictionary*)getReleaseHelpInfoPostDataWihtMsg:(NSString *)msg latitude:(double)lat logitude:(double)lon address:(NSString *)addr
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:msg forKey:_helpMessage_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_rosterUserId_];
    [dic setObject:[NSNumber numberWithDouble:lat] forKey:_helpLatitude_];
    [dic setObject:[NSNumber numberWithDouble:lon] forKey:_helpLongitude_];
    [dic setObject:addr forKey:_helpAddress_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    return [dic autorelease];
}

+ (NSString*)isReleaseHelpInfoSuccessFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic objectForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic objectForKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        return @"1";
    }
    else
    {
        return nil;
    }
}

#pragma mark- 附近匿名操作

/**删除匿名
 *@param helpId 匿名信息Id
 *@return get请求url
 */
+ (NSString*)removeHelpInfoWithHelpId:(long long)helpId
{
    NSString *url = [NSString stringWithFormat:_removeUserHelpInfo_, [NSString stringWithFormat:@"%lld",helpId]];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    return url;
}

/**评论匿名 url
 *@return post请求url
 */
+ (NSString*)getReleaseHelpCommentURL
{
    return _releaseHelpComment_;
}

/**评论匿名 参数
 *@param msg 评论内容
 *@param parentId 回复的评论信息id，如果不是回复某个评论，传0
 *@param helpId 评论的匿名的id
 *@return post请求参数
 */
+ (NSDictionary*)getReleaseHelpCommentPostDataWithMsg:(NSString *)msg parentId:(NSString *)parentId helpId:(long long)helpId
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    [dic setObject:[NSNumber numberWithLongLong:helpId] forKey:_helpID_];
    [dic setObject:msg forKey:_helpCommentMsg_];
    [dic setObject:parentId forKey:_helpCommentParentId_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_helpCommentUser_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    return [dic autorelease];
}

/**是否评论成功
 *@data 返回的数据
 */
+ (NSString*)isReleaseHelpCommentSuccessFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        return @"1";
    }
    else
    {
        return nil;
    }
}

/**点赞附近匿名 url
 *@return post请求 url
 */
+ (NSString*)getPraiseSecretURL
{
    return _praiseSecret_;
}

/**点赞附近匿名 参数
 *@param info 要点赞的匿名信息
 *@return post请求 参数
 */
+ (NSDictionary*)getPraiseSecretParaWithInfo:(JBoHelpInfo*) info
{
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    [dic setObject:[NSNumber numberWithLongLong:info.helpID] forKey:_helpID_];
    [dic setObject:[JBoUserOperation getUserId] forKey:_praiseSecretUser_];
    
    return dic;
}

@end
