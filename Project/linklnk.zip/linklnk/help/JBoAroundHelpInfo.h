//
//  JBoAroundHelpInfo.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "JBoUserDetailInfo.h"
#import "JBoHelpInfo.h"

/**附近匿名信息
 */
@interface JBoAroundHelpInfo : JBoHelpInfo

/**用户Id
 */
@property(nonatomic,copy) NSString *userID;

/**用户性别
 */
@property(nonatomic,assign) NSInteger sex;

@property(nonatomic,assign) CLLocationCoordinate2D coordinate;
@property(nonatomic,copy) NSString *distance;


@end