//
//  JBoAroundHelpCell.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoImageTextLabel.h"

#define _aroundHelpHeight_ 320
#define _aroundHelpCellInteval_ 10
#define _aroundHelpControlHeight_ 20
#define _aroundHelpPresenceMaxHeight_ 40

@class JBoAroundHelpCell;

@protocol JBoAroundHelpCellDelegate <NSObject>

/**评论
 */
- (void)aroundHelpCellDidComment:(JBoAroundHelpCell*) cell;
/**点赞
 */
- (void)aroundHelpCellDidPraise:(JBoAroundHelpCell *)cell;
/**选中链接
 */
- (void)aroundHelpCell:(JBoAroundHelpCell*) cell didSelectedURL:(NSURL*) url;

@end

@interface JBoAroundHelpCell : UITableViewCell

/**头像 只显示默认男或女头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
/** 内容 居中显示 白色字体
 */
@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;
/** 内容高度
 */
@property(nonatomic,assign) NSInteger contentHeight;

@property(nonatomic,readonly)JBoUserNameLabel *nameLabel;

/** 和当前位置距离
 */
@property(nonatomic,readonly)UILabel *locationLabel;
/** 背景图片
 */
@property(nonatomic,readonly) UIImageView *bgImageView;
/** 背景颜色
 */
@property(nonatomic,readonly) UIView *bgView;
/**评论按钮
 */
@property(nonatomic,readonly) UIButton *commentButton;
/** 点赞按钮
 */
@property(nonatomic,readonly) UIButton *praiseButton;
/** 设置点赞的数量
 */
@property(nonatomic,assign) long long praiseCount;

@property(nonatomic,assign) id<JBoAroundHelpCellDelegate> delegate;

@end
