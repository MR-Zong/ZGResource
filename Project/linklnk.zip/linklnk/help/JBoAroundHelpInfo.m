//
//  JBoAroundHelpInfo.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAroundHelpInfo.h"

@implementation JBoAroundHelpInfo

- (void)dealloc
{
    
    [_userID release];
    [_distance release];

    
    [super dealloc];
}

@end
