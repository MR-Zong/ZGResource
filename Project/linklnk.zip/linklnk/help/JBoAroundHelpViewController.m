//
//  JBoAroundHelpViewController.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAroundHelpViewController.h"
#import "JBoHelpOperation.h"
#import "JBoAroundHelpInfo.h"
#import "JBoAroundHelpCell.h"
#import "JBoAppDelegate.h"
#import "UITableView+extraCellLine.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "EGORefreshTableHeaderView.h"
#import "JBoBottomLoadingView.h"
#import "JBoHelpDetailViewController.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoUserTableHeaderView.h"
#import "JBoCircleBgViewController.h"
#import "JBoMyHelpInfoViewController.h"
#import "BMapKit.h"
#import "JBoImageTextTool.h"
#import "JBoReleaseHelpMsgViewController.h"
#import "JBoOfflineCacheOperation.h"
#import "JBoWebViewController.h"
#import "JBoRoundView.h"
#import "JBoHelpCommentDataObject.h"
#import "BMKGeoCodeSearch+Utilities.h"

#define _latestLatitude_ @"secretlat"
#define _latestLongitude_ @"secretlon"

@interface JBoAroundHelpViewController ()<JBoHttpRequestDelegate,EGORefreshTableHeaderDelegate,BMKLocationServiceDelegate,JBoUserTableHeaderViewDelegate,JBoMyHelpInfoViewControllerDelegate,JBoAroundHelpCellDelegate,BMKGeoCodeSearchDelegate>
{
    JBoHttpRequest *_httpRequest;
    //个人信息加载进程
    NSMutableDictionary *_downloadProgressDic;
    //个人信息 value是  JBoUserDetailInfo对象 key是 userId
    NSMutableDictionary *_userDetailInfoDic;
    
    //下拉刷新
    EGORefreshTableHeaderView *_refreshView;
    BOOL _isLoading;
    
    JBoBottomLoadingView *_bottomLoadingView;
    BOOL _hasInfo;
    
    //离线缓存
    JBoOfflineCacheOperation *_offlineCacheOperation;
}

//定位
@property(nonatomic,retain) BMKLocationService *locationManager;
//地理反编码
@property(nonatomic,retain) BMKGeoCodeSearch *addrSearch;

@property(nonatomic,assign) int pageIndex;
@property(nonatomic,assign) BOOL isRequesting;

//当前坐标
@property(nonatomic,assign) CLLocationCoordinate2D currentCoordinate;

//每一行背景颜色 数组成员是 UIColor
@property(nonatomic,retain) NSArray *bgColorArray;

/**请求队列
 */
@property(nonatomic,retain) ASINetworkQueue *httpQueue;

/**有新匿名
 */
@property(nonatomic,retain) UIView *newsSecretView;

//查看当前位置的匿名
@property(nonatomic,assign) BOOL seeCurloc;

//当前登录的用户信息
@property(nonatomic,retain) JBoUserDetailInfo *info;

//定位请求
@property(nonatomic,retain) CLLocationManager *sysLocationManager;

@end

@implementation JBoAroundHelpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = [NSString stringWithFormat:@"附近%@", _helpName_];
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        _infoArray = [[NSMutableArray alloc] init];
        
        //个人信息加载进程
        _downloadProgressDic = [[NSMutableDictionary alloc] init];
        //
        _userDetailInfoDic = [[NSMutableDictionary alloc] init];
        
        self.isRequesting = NO;
        _hasInfo = YES;
        _isLoading = NO;
        self.pageIndex = 1;
        
        self.bgColorArray = [NSArray arrayWithObjects:[UIColor colorWithRed:62.0 / 255.0 green:215.0 / 255.0 blue:21.0 / 255.0 alpha:0.5], [UIColor colorWithRed:175.0 / 255.0 green:93.0 / 255.0 blue:161.0 / 255.0 alpha:0.5], [UIColor colorWithRed:55.0 / 255.0 green:46.0 / 255.0 blue:43.0 / 255.0 alpha:0.5], [UIColor colorWithRed:0.0 green:117.0 / 255.0 blue:169.0 / 255.0 alpha:0.5], nil];
        
        //发布邦信息通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(releaseHelpAction:) name:_releaseHelpMsgNotification_ object:nil];
        
        //新匿名通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newsSecret:) name:_newsSecretNotification_ object:nil];
        
        _offlineCacheOperation = [[JBoOfflineCacheOperation alloc] init];
        
        self.httpQueue = [ASINetworkQueue queue];
        self.httpQueue.delegate = self;
        self.httpQueue.shouldCancelAllRequestsOnFailure = NO;
        [self.httpQueue setQueueDidFinishSelector:@selector(queueDidFinish:)];
        
        self.info = [JBoUserOperation getUserDetailInfo];
        self.currentCoordinate = CLLocationCoordinate2DMake(self.info.defalutAddrLat, self.info.defaultAddrLon);
    }
    
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    _isRequesting = isRequesting;
    if(!_isRequesting)
    {
        if(!_isLoading)
        {
            self.appDelegate.dataLoadingView.hidden = !_isRequesting;
        }
        _tableView.tableFooterView = nil;
    }
}

#pragma mark- 通知

- (void)releaseHelpAction:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    JBoAroundHelpInfo *info = [dic objectForKey:_helpMessage_];
    
    [_infoArray insertObject:info atIndex:0];
    [_tableView reloadData];
    
    //保存
    [_offlineCacheOperation insertMySecret:info];
    [_offlineCacheOperation insertSecret:info isSelf:NO];
}

- (void)newsSecret:(NSNotification*) notification
{
    if(!_isLoading)
    {
        [self setNewsSecretHidden:NO];
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    NSLog(@"JBoAroundHelpViewController dealloc");
    
    [_tableView release];
    [_infoArray release];
    
    [_httpRequest release];
    [_downloadProgressDic release];
    [_userDetailInfoDic release];
    
    [_refreshView release];
    [_bottomLoadingView release];
    
    [_locationManager release];
    [_addrSearch release];
    
    [_bgColorArray release];
    [_offlineCacheOperation release];
    
    [_httpQueue reset];
    [_httpQueue release];
    
    [_newsSecretView release];
    
    [_info release];
    [_sysLocationManager release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_releaseHelpMsgNotification_ object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_newsSecretNotification_ object:nil];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    _locationManager.delegate = self;
    _addrSearch.delegate = self;
    
    [self.appDelegate setStatusBarStyle:JBoStatusBarStyleTranslucent];
    [_tableView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [_locationManager stopUserLocationService];
    _locationManager.delegate = nil;
    _addrSearch.delegate = nil;
    
    if(self.isRequesting)
    {
        [self.appDelegate closeAlertView];
    }
    
}

#pragma mark-htppRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if(_isLoading)
    {
        [self tableViewDataSourceDidFinishLoading:NO];
    }
    else
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"获取信息失败"];
        self.pageIndex --;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    NSArray *array = [JBoHelpOperation getAroundHelpInfoFromData:data withCurrentCoordinate:self.currentCoordinate];
    if(array.count > 0)
    {
        if(_isLoading)
        {
            [_infoArray removeAllObjects];
            [self removeSecretAndComment];
        }
        [_infoArray addObjectsFromArray:array];
        
        [self saveSecretWithArray:array];
        
        if(_isLoading)
        {
            [self tableViewDataSourceDidFinishLoading:YES];
        }
        
        [_tableView reloadData];
        
        if(_infoArray.count > array.count)
        {
            [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:_infoArray.count - array.count inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        }
    }
    else
    {
        if(_isLoading)
        {
            [self tableViewDataSourceDidFinishLoading:NO];
        }
    }
    if(!_tableView)
    {
        [self loadInitView];
    }
    
    _hasInfo = array.count == _helpPageSize_;
    if(_infoArray.count == 0)
    {
        [JBoUserOperation alertMsg:[NSString stringWithFormat:@"暂时没有附近%@", _helpName_]];
    }
}

- (void)queueDidFinish:(ASINetworkQueue*) queue
{
    
}

#pragma mark- 匿名离线缓存

- (void)saveSecretWithArray:(NSArray*) secretArray
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        for(JBoAroundHelpInfo *info in secretArray)
        {
            [_offlineCacheOperation removeSecretWithId:info.helpID isSelf:NO];
            [_offlineCacheOperation insertSecret:info isSelf:NO];
            
            [_offlineCacheOperation deleteSecretCommentWithHelpId:info.helpID];
            
            for(JBoHelpCommentInfo *commentInfo in info.commentInfoArray)
            {
                [_offlineCacheOperation insertIntoSecretCommentWithId:info.helpID commentInfo:commentInfo];
            }
        }
    });
}

- (void)getSecret
{
    self.appDelegate.dataLoadingView.hidden = NO;
   
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        [_offlineCacheOperation getAroundSecretWithArray:_infoArray currentCoordinate:CLLocationCoordinate2DMake(self.currentCoordinate.latitude, self.currentCoordinate.longitude)];
        dispatch_async(dispatch_get_main_queue(), ^(void){

            self.pageIndex = (int)_infoArray.count / _helpPageSize_;
            self.appDelegate.dataLoadingView.hidden = YES;
            if(!_tableView)
            {
                [self loadInitView];
            }
            else
            {
                [_tableView reloadData];
            }
            
            
            if(_infoArray.count == 0)
            {
                _hasInfo = NO;
                [_refreshView beginRefresh];
            }
            else
            {
                 [self setNewsSecretHidden:!self.hasNewsSecret];
            }
        });
    });
}

- (void)removeSecretAndComment
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        [_offlineCacheOperation removeAllSecret];
        [_offlineCacheOperation removeAllComment];
    });
}

#pragma mark-加载视图

- (void)back
{
    [_httpQueue reset];
    [_downloadProgressDic removeAllObjects];
    [self canPerformAction:@selector(loadInfo:) withSender:self];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
	[JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    
    [self getSecret];
    
}

- (void)releaseAction:(id)sender
{
    JBoReleaseHelpMsgViewController *releaseHelpMsg = [[JBoReleaseHelpMsgViewController alloc] init];
    [self.navigationController pushViewController:releaseHelpMsg animated:YES];
    [releaseHelpMsg release];
}

- (void)loadInitView
{
    UIImage *releaseImage = [UIImage imageNamed:@"helpRelease"];
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(releaseAction:) title:nil backgroundImage:releaseImage textColor:nil];
    
    JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getUserDetailInfo];
    
    JBoUserTableHeaderView *tableHeaderView = [[JBoUserTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tableHeaderViewHeight_)];
    [tableHeaderView addLeftButton];
    [tableHeaderView.leftButton setTitle:@"看当前位置" forState:UIControlStateNormal];
    [tableHeaderView.leftButton setImage:[UIImage imageNamed:@"conditions_map"] forState:UIControlStateNormal];
    
    if(userDetailInfo.rosterInfo.image)
    {
        tableHeaderView.headImageView.imageView.image = userDetailInfo.rosterInfo.image;
    }
    else
    {
        tableHeaderView.headImageView.sex = userDetailInfo.rosterInfo.sex;
    }
    tableHeaderView.headImageView.role = userDetailInfo.rosterInfo.role;
    tableHeaderView.bgImageView.userId = userDetailInfo.rosterInfo.username;
    tableHeaderView.nameLabel.text = userDetailInfo.rosterInfo.name;
    tableHeaderView.nameLabel.textColor = [UIColor blackColor];
   // tableHeaderView.nameLabel.sex = userDetailInfo.rosterInfo.sex;
    tableHeaderView.delegate = self;
    
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.rowHeight = _aroundHelpHeight_;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.tableHeaderView = tableHeaderView;
    [tableHeaderView release];
    [self.view addSubview:_tableView];
    [_tableView setExtraCellLineHidden];
    
    //下拉刷新
    _refreshView = [[EGORefreshTableHeaderView alloc] initWithFrame:_tableView.frame];
    _refreshView.delegate = self;
    _refreshView.scrollView = _tableView;
    [self.view insertSubview:_refreshView belowSubview:_tableView];
}

- (void)loadInfo:(BOOL) hidden
{
    self.isRequesting = YES;
    
    long long lastHelpId = 0;
    if(_infoArray.count > 0 && !_isLoading)
    {
        JBoAroundHelpInfo *info = [_infoArray lastObject];
        lastHelpId = info.helpID;
    }
    
    self.appDelegate.dataLoadingView.hidden = hidden;
    [_httpRequest downloadWithURL:[JBoHelpOperation getAroundHelpInfoWithPageNum:_isLoading ? 1 : self.pageIndex rows:_helpPageSize_ currentCoornidate:self.currentCoordinate radius:_helpRadiusDefaultValue_ lastHelpId:lastHelpId]];
}

- (void)setNewsSecretHidden:(BOOL) hidden
{
    NSLog(@"%d", self.hasNewsSecret);
    if(!self.newsSecretView)
    {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(refreshSecret:)];
        [view addGestureRecognizer:tap];
        [tap release];
        view.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:view];
        self.newsSecretView = view;
        [view release];
        
        
        CGFloat pointSize = 5.0;
        CGFloat width = (_width_ - view.height - pointSize) / 2.0;
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, view.height)];
        label.font = [UIFont boldSystemFontOfSize:14.0];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor blackColor];
        label.text = @"有新匿名";
        [label setTextAlign:JBoTextAlignmentRight];
        [view addSubview:label];
        [label release];
        
        JBoRoundView *point = [[JBoRoundView alloc] initWithFrame:CGRectMake(label.right, 7.0, pointSize, pointSize)];
        point.bgColor = [UIColor redColor];
        [view addSubview:point];
        [point release];
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(point.right + 5.0, 0, 68.0, view.height)];
        label.font = [UIFont boldSystemFontOfSize:14.0];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor blackColor];
        label.text = @"点击刷新";
        [label setTextAlign:JBoTextAlignmentLeft];
        [view addSubview:label];
        [label release];
        
        UIImage *image = [UIImage imageNamed:@"arrow"];
        UIImageView *arrowImageView = [[UIImageView alloc] initWithFrame:CGRectMake(label.right, (view.height - image.size.height) / 2.0, image.size.width, image.size.height)];
        arrowImageView.image = image;
        [view addSubview:arrowImageView];
        [arrowImageView release];
    }
    
    self.newsSecretView.hidden = hidden;
    if(hidden)
    {
        _tableView.frame = CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_);
    }
    else
    {
        _tableView.frame = CGRectMake(0, self.newsSecretView.bottom, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_);
    }
}

- (void)refreshSecret:(UITapGestureRecognizer*) tap
{
    self.isRequesting = NO;
    _isLoading = NO;
    _hasInfo = NO;
    [self setNewsSecretHidden:YES];
    [_refreshView beginRefresh];
}

#pragma mark-JBoUserTableHeaderView代理
- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView headImageDidTapped:(JBoUserHeadImageView *)headImageView
{
    JBoMyHelpInfoViewController *myHelpVC = [[JBoMyHelpInfoViewController alloc] init];
    myHelpVC.delegate = self;
    myHelpVC.offlineCacheOperation = _offlineCacheOperation;
    [self.navigationController pushViewController:myHelpVC animated:YES];
    [myHelpVC release];
}

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView bgImageDidTapped:(UIView *)view
{
    JBoCircleBgViewController *circleBgVC = [[JBoCircleBgViewController alloc] init];
    circleBgVC.black = NO;
    [self.navigationController pushViewController:circleBgVC animated:YES];
    [circleBgVC release];
}

- (void)tableHeaderViewDidSelectLeftButton:(JBoUserTableHeaderView *)tableHeaderView
{
    if(self.isRequesting)
        return;
    self.seeCurloc = YES;
    [_refreshView beginRefresh];
}

#pragma mark- JBoMyHelpInfoViewController代理

- (void)myHelpInfoViewController:(JBoMyHelpInfoViewController *)viewController didDeletedInfo:(long long)infoId
{
    for(NSInteger i = 0; i < _infoArray.count; i ++)
    {
        JBoAroundHelpInfo *info = [_infoArray objectAtIndex:i];
        if(info.helpID == infoId)
        {
            [_offlineCacheOperation removeSecretWithId:info.helpID isSelf:YES];
            [_offlineCacheOperation removeSecretWithId:info.helpID isSelf:NO];
            [_infoArray removeObject:info];
            break;
        }
    }
    [_tableView reloadData];
}

#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(_infoArray.count == 0)
    {
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    else
    {
        tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoAroundHelpCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoAroundHelpCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    JBoUserDetailInfo *userDetailInfo = [_userDetailInfoDic objectForKey:info.userID];
   
    NSInteger colorIndex = indexPath.row % self.bgColorArray.count;
    
    cell.bgView.backgroundColor = [self.bgColorArray objectAtIndex:colorIndex];
    
    
//    if(userDetailInfo.rosterInfo.image)
//    {
//        cell.headImageView.image = userDetailInfo.rosterInfo.image;
//    }
//    else
//    {
        cell.headImageView.sex = userDetailInfo.rosterInfo.sex;
  //  }
    //cell.headImageView.role = userDetailInfo.rosterInfo.role;
    cell.headImageView.imageView.image = nil;
    if(!userDetailInfo)
    {
        if(!tableView.dragging && !tableView.decelerating)
        {
            [self donloadUserInfoForInfo:info];
        }
    }
    else
    {
        if(info.sex != userDetailInfo.rosterInfo.sex)
        {
            info.sex = userDetailInfo.rosterInfo.sex;
            [_offlineCacheOperation updateSecret:info];
        }
    }
//    else
//    {
//        cell.nameLabel.sex = userDetailInfo.rosterInfo.sex;
//    }
    
   // cell.nameLabel.text = userDetailInfo.rosterInfo.name;
    cell.locationLabel.text = info.distance;
    cell.contentLabel.text = info.helpMsg;
    cell.praiseCount = info.praiseCount;
    
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canPerformAction:(SEL)action forRowAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender
{
    if(action == @selector(copy:))
        return YES;
    return NO;
}

- (BOOL)tableView:(UITableView *)tableView shouldShowMenuForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView performAction:(SEL)action forRowAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender
{
    if(action == @selector(copy:))
    {
        JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
        pasteboard.string = info.helpMsg;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    JBoUserDetailInfo *userDetailInfo = [_userDetailInfoDic objectForKey:info.userID];
    if(!userDetailInfo)
    {
        userDetailInfo = [[[JBoUserDetailInfo alloc] init] autorelease];
        userDetailInfo.rosterInfo.username = info.userID;
    }
    
    JBoHelpDetailViewController *helpDetailVC = [[JBoHelpDetailViewController alloc] init];
    helpDetailVC.offlineCache = _offlineCacheOperation;
    helpDetailVC.aroundHelpInfo = info;
    helpDetailVC.userDetailInfo = userDetailInfo;
    [self.navigationController pushViewController:helpDetailVC animated:YES];
    [helpDetailVC release];
}

- (void)donloadUserInfoForInfo:(JBoAroundHelpInfo*) info
{
    JBoAsyncDownloadUserInfoOperation *asyncDownload = [_downloadProgressDic objectForKey:info.userID];
    if(!asyncDownload)
    {
        asyncDownload = [[JBoAsyncDownloadUserInfoOperation alloc] init];
        __block JBoAsyncDownloadUserInfoOperation *blockAsyncDownload = asyncDownload;
        
        asyncDownload.completionHandler = ^(void)
        {
            if(blockAsyncDownload.userDetailInfo)
            {
                if(blockAsyncDownload.userDetailInfo.rosterInfo.image)
                {
                    blockAsyncDownload.userDetailInfo.rosterInfo.image = [JBoImageTextTool getThumbnailFromImage:blockAsyncDownload.userDetailInfo.rosterInfo.image withSize:CGSizeMake(_aroundHelpHeight_ - _aroundHelpCellInteval_ * 2, _aroundHelpHeight_ - _aroundHelpCellInteval_ * 2)];
                }
                [_userDetailInfoDic setObject:blockAsyncDownload.userDetailInfo forKey:info.userID];
                [_tableView reloadData];
            }
            [_downloadProgressDic removeObjectForKey:info.userID];
        };
        [_downloadProgressDic setObject:asyncDownload forKey:info.userID];
        [asyncDownload downloadWithUserId:info.userID];
        [asyncDownload release];
    }
}

#pragma mark- aroundCell代理

- (void)aroundHelpCellDidComment:(JBoAroundHelpCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    
    JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    JBoUserDetailInfo *userDetailInfo = [_userDetailInfoDic objectForKey:info.userID];
    
    if(!userDetailInfo)
    {
        userDetailInfo = [[[JBoUserDetailInfo alloc] init] autorelease];
        userDetailInfo.rosterInfo.username = info.userID;
    }
    
    JBoHelpDetailViewController *helpDetailVC = [[JBoHelpDetailViewController alloc] init];
    helpDetailVC.showComment = YES;
    helpDetailVC.offlineCache = _offlineCacheOperation;
    helpDetailVC.aroundHelpInfo = info;
    helpDetailVC.userDetailInfo = userDetailInfo;
    [self.navigationController pushViewController:helpDetailVC animated:YES];
    [helpDetailVC release];
}

- (void)aroundHelpCellDidPraise:(JBoAroundHelpCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    
    JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    if(!info.praise)
    {
        [self alertMsg:@"您已赞过"];
        return;
    }
    
    info.praise = NO;
    info.praiseCount ++;
    
    [_offlineCacheOperation updateSecret:info];
    
    [_tableView beginUpdates];
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:[JBoHelpOperation getPraiseSecretURL]]];
    
    NSDictionary *dic = [JBoHelpOperation getPraiseSecretParaWithInfo:info];
    [dic enumerateKeysAndObjectsUsingBlock:^(id key, id vaule, BOOL *stop)
     {
         [request setPostValue:vaule forKey:key];
     }];
    
    [self.httpQueue addOperation:request];
    [self.httpQueue go];
}

- (void)aroundHelpCell:(JBoAroundHelpCell *)cell didSelectedURL:(NSURL *)url
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    
    JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    JBoUserDetailInfo *userDetailInfo = [_userDetailInfoDic objectForKey:info.userID];
    
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    if(![userDetailInfo.rosterInfo.username isEqualToString:[JBoUserOperation getUserId]])
    {
        web.userId = userDetailInfo.rosterInfo.username;
    }
    web.URL = url;
    web.black = self.black;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

#pragma mark-加载头像
- (void)downloadImageForInfo:(JBoAroundHelpInfo*) info
{
    //先判断该头像是否正在下载
    JBoAsyncDownloadImageOperation *asyncDownloadOperation = [_downloadProgressDic objectForKey:info.userID];
    
    if(!asyncDownloadOperation)
    {
        //创建一个queue来获取头像
        JBoAsyncDownloadImageOperation *asyncDownloadOperation = [[JBoAsyncDownloadImageOperation alloc] init];
        
        __block JBoAsyncDownloadImageOperation *blockAsyncDownloadOperation = asyncDownloadOperation;
        
        [asyncDownloadOperation setCompletionHandler:^(){
            
            UIImage *image = [[UIImage alloc] initWithData:blockAsyncDownloadOperation.data];
            if(image)
            {
                [_userDetailInfoDic setObject:image forKey:info.userID];
            }
            else
            {
               // [_userDetailInfoDic setObject:_appDelegate.defaultImage forKey:info.userID];
            }
            [image release];
            
            [self performSelectorOnMainThread:@selector(updataHeaderImage) withObject:nil waitUntilDone:NO];
            
            [_downloadProgressDic removeObjectForKey:info.userID];
        }];
        
        [_downloadProgressDic setObject:asyncDownloadOperation forKey:info.userID];
       // [asyncDownloadOperation downloadWithURL:info.imageURL];
        [asyncDownloadOperation release];
    }
}

- (void)updataHeaderImage
{
    [_tableView reloadData];
}


//加载可见的cell的好友头像
- (void)loadImageForOnScreenRows
{
    if(_infoArray.count > 0)
    {
        NSArray *indexPathArray = [_tableView indexPathsForVisibleRows];
        for(NSIndexPath *indexPath in indexPathArray)
        {
            JBoAroundHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
   
            JBoUserDetailInfo *userDetialInfo = [_userDetailInfoDic objectForKey:info.userID];
            if(!userDetialInfo)
            {
                [self donloadUserInfoForInfo:info];
            }
        }
    }
}

#pragma mark-scrollView代理  在用户停止拖动和拖动停止减速时加载头像

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    //NSLog(@"addressBook scrollViewDidEndDragging");
    [_refreshView egoRefreshScrollViewDidEndDragging:scrollView];
    if(!decelerate)
    {
        [self loadImageForOnScreenRows];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    // NSLog(@"addressBook scrollViewDidEndDecelerating");
    [self loadImageForOnScreenRows];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
   //  NSLog(@"addressBook scrollViewDidScroll");
    
    if(self.isRequesting || !_hasInfo)
        return;
    
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!_bottomLoadingView)
        {
            //创建加载更多视图
            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
        }

        self.isRequesting = YES;
        self.pageIndex ++;
        
        _tableView.tableFooterView = _bottomLoadingView;
        [self performSelector:@selector(loadInfo:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.5];
    }
    
    [_refreshView egoRefreshScrollViewDidScroll:scrollView];
}

#pragma mark-下拉刷新
- (void)reloadTableViewDataSource
{
    self.isRequesting = NO;
    [self setNewsSecretHidden:YES];
    _isLoading = YES;
    
    if((self.currentCoordinate.longitude == 0 && self.currentCoordinate.latitude == 0) || self.seeCurloc)
    {
        self.seeCurloc = NO;
        [self location];
    }
    else
    {
        [self loadInfo:YES];
    }
}

//数据加载完成
- (void)tableViewDataSourceDidFinishLoading:(BOOL) success
{
    self.pageIndex = 1;
    self.appDelegate.dataLoadingView.hidden = YES;
    if(success)
    {
        _refreshView.finishText = @"刷新成功";
    }
    else
    {
        _refreshView.finishText = [NSString stringWithFormat:@"刷新失败"];
    }
    _isLoading = NO;
    [_refreshView egoRefreshScrollViewDataSourceDidFinishedLoading:_tableView];
}

//下拉刷新
- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    [self reloadTableViewDataSource];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return _isLoading;
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

#pragma mark-定位
- (void)location
{
    if(_ios8_0_)
    {
        #ifdef __IPHONE_8_0
        if([CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined)
        {
            self.sysLocationManager = [[[CLLocationManager alloc] init] autorelease];

            [self.sysLocationManager requestAlwaysAuthorization];
        }
        #endif
    }
    
    BOOL canloc = NO;
    
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways;
#endif
    }
    else
    {
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized;
    }
    
    if(canloc)
    {
        if(!_locationManager)
        {
            _locationManager = [[BMKLocationService alloc] init];
            _locationManager.delegate = self;
        }
        
        if(!_isLoading)
        {
            self.appDelegate.dataLoadingView.hidden = NO;
        }
        
        [_locationManager startUserLocationService];

    }
    else
    {
        [JBoUserOperation cannotUserLocationService];
        [self tableViewDataSourceDidFinishLoading:NO];
    }
}

#pragma mark- BMKLocationService delegate

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
     if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {
        self.currentCoordinate = userLocation.location.coordinate;
        NSLog(@"%f,%f",self.currentCoordinate.latitude, self.currentCoordinate.longitude);
        [_locationManager stopUserLocationService];
        
        [self loadInfo:_isLoading];
        
        if([NSString isEmpty:self.info.defaultAddr])
        {
            [self reserveCoordinate];
        }
    }
}

- (void)didFailToLocateUserWithError:(NSError *)error
{
    [_locationManager stopUserLocationService];
    [self failToLocation];
}

//地理反编码
- (void)reserveCoordinate
{
    if(!_addrSearch)
    {
        self.addrSearch = [BMKGeoCodeSearch sharedInstance];
    }
    
    self.addrSearch.delegate = self;
    
    BMKReverseGeoCodeOption *option = [[[BMKReverseGeoCodeOption alloc] init] autorelease];
    option.reverseGeoPoint = self.currentCoordinate;
    
    if(![_addrSearch reverseGeoCode:option])
    {
        self.addrSearch.delegate = nil;
        self.addrSearch = nil;
    }
}

#pragma mark- BMKGeoCodeSearch delegate

- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    self.addrSearch.delegate = nil;
    self.addrSearch = nil;
    if(error != BMK_SEARCH_NO_ERROR)
    {
        return;
    }
    
    NSString *strAddr = result.address;
    if(strAddr == nil)
        return;
    
    BMKPoiInfo *info = [result.poiList firstObject];
    NSString *poiAddr = info.name;
    
    NSString *str = [self.info strAddr:strAddr andPoiAddr:poiAddr];
    self.info.defaultAddr = str;
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         str, _rosterDefaultAddr_,
                         [NSNumber numberWithDouble:self.currentCoordinate.latitude], _rosterDefaultLat_,
                         [NSNumber numberWithDouble:self.currentCoordinate.longitude], _rosterDefaultLon_, nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:_saveDefaultAddrNotification_ object:self userInfo:dic];
}

- (void)failToLocation
{
    self.appDelegate.dataLoadingView.hidden = YES;
   // [JBoUserOperation alertMsg:@"无法定位您当前的位置"];
    [JBoUserOperation openSystemSettingsAlertViewWithDelegate:self];
}

#pragma mark- UIAlertView delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    
    if([title isEqualToString:_alertButtonTitleWhenCannotLocate_])
    {
        [JBoUserOperation openSystemSettings];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [_downloadProgressDic removeAllObjects];
}

@end
