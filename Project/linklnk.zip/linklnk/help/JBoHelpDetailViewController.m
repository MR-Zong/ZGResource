//
//  JBoHelpDetailViewController.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoHelpDetailViewController.h"
#import "JBoUserHeadImageView.h"
#import "JBoAppDelegate.h"
#import "JBoHelpOperation.h"
#import "JBoImageTextTool.h"
#import "JBoHelpCommentCell.h"
#import "JBoHelpCommentDataObject.h"
#import "JBoSubmitInputContentView.h"
#import "JBoDatetimeTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoSendMsgViewController.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoComplaintViewController.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoNavigationViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoImageTextLabel.h"
#import "JBoWebViewController.h"
#import "JBoAroundHelpInfo.h"

#import "JBoMultiImageView.h"
#import "JBoImageCacheTool.h"
#import "JBoReuseScrollView.h"
#import "JBoOfflineCacheOperation.h"

#define _padding_ 20
#define _headImageSize_ 35.0
#define _controlInterval_ 5
#define _controlHeight_ 25

@interface JBoHelpDetailViewController ()<UITableViewDelegate,UITableViewDataSource,JBoHttpRequestDelegate,JBoSubmitInputContentViewDelegate,JBoHelpCommentCellDelegate,UIAlertViewDelegate,JBoImageTextLabelDelegate,JBoMultiImageViewDelegate,JBoReuseScrollViewDelegate>
{
    JBoHttpRequest *_httpRequest;
    
    //树状评论
    UITableView *_tableView;
    
    //评论
    JBoSubmitInputContentView *_submitCommentView;
    
    //加载图片
    NSMutableDictionary *_downloadProgressDic;
    NSMutableDictionary *_headImageDic;
    
    JBoBottomLoadingView *_bottomLoadingView;
    BOOL _hasInfo;
}

//正在评论的内容 回复的评论ID 是否正在请求
@property(nonatomic,copy) NSString *submitComment;
@property(nonatomic,copy) NSString *parentCommentID;
@property(nonatomic,assign) BOOL isRequesting;

@property(nonatomic,assign) NSInteger parentIndex;
@property(nonatomic,assign) NSInteger childIndex;

@property(nonatomic,retain) JBoHelpCommentCell *currentCell;
@property(nonatomic,retain) JBoHelpCommentDataObject *loadingItem;
@property(nonatomic,retain) JBoHelpCommentDataObject *expandItem;

@property(nonatomic,retain) NSMutableArray *commentInfoArray;
/**当前登录的用户信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *myUserDetailInfo;

//计算评论字大小
@property(nonatomic,retain) JBoImageTextLabel *imageText;

//点赞按钮
@property(nonatomic,assign) UIButton *praiseButton;

//图片
@property(nonatomic,retain) JBoMultiImageView *multiImageView;

//查看大图
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;

@end

@implementation JBoHelpDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.imageText = [[[JBoImageTextLabel alloc] initWithFrame:CGRectZero] autorelease];
        self.imageText.font = _helpCommentFont_;
        self.imageText.minLineHeight = _helpCommentMinLineHeight_;
        self.imageText.textInset = _helpCommentTextInset_;
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.isRequesting = NO;
        _hasInfo = YES;
        
        _downloadProgressDic = [[NSMutableDictionary alloc] init];
        _headImageDic = [[NSMutableDictionary alloc] init];
        
        self.myUserDetailInfo = [JBoUserOperation getUserDetailInfo];
        [_headImageDic setObject:self.myUserDetailInfo forKey:self.myUserDetailInfo.rosterInfo.username];
        
        self.parentIndex = 0;
        self.childIndex = 0;
        self.isSelf = NO;
  
        self.title = @"详情";
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        if(!_isRequesting)
        {
            self.appDelegate.dataLoadingView.hidden = YES;
        }
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    NSLog(@"JBoHelpDetailViewController dealloc");
    [_tableheaderView release];
    [_commentInfoArray release];
    
    [_aroundHelpInfo release];
    [_userDetailInfo release];
    [_offlineCache release];
    
    [_tableView release];
    [_httpRequest release];
    [_submitCommentView release];
    
    [_submitComment release];
    [_parentCommentID release];
    
    [_downloadProgressDic release];
    [_headImageDic release];
    
    [_imageText release];
    [_currentCell release];
    [_loadingItem release];
    [_expandItem release];
    
    [_myUserDetailInfo release];
    [_multiImageView release];
    
    [_imageScrollView release];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if((self.commentInfoArray.count == 0 && self.isSelf) || self.showComment)
    {
        self.showComment = NO;
        [self comment];
    }
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_releaseHelpCommentIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"评论失败"];
        return;
    }
    
    if([identifier isEqualToString:_praiseSecretIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"点赞失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_releaseHelpCommentIdentifier_])
    {
        self.navigationItem.rightBarButtonItem.enabled = YES;
        NSString *commentId = [JBoHelpOperation isReleaseHelpCommentSuccessFromData:data];
        if(commentId)
        {
            //获取用户个人信息
            JBoHelpCommentInfo *info = [[JBoHelpCommentInfo alloc] init];
            
            info.commentID = [commentId longLongValue];
            info.commentDate = [JBoDatetimeTool getCurrentTime];
            info.commentMsg = self.submitComment;
            
            info.userID = self.myUserDetailInfo.rosterInfo.username;
            info.userName = self.myUserDetailInfo.rosterInfo.name;
            info.sex = self.myUserDetailInfo.rosterInfo.sex;
            
            //info.replyCount = 2;
            
            
           // JBoHelpCommentDataObject *comment = [[JBoHelpCommentDataObject alloc] initWithHelpInfo:info childArray:nil];
            
//            if(self.currentCell)
//            {
//                JBoHelpCommentDataObject *tmpComment = self.currentCell.helpCommentData;
//                tmpComment.parentCommentInfo.replyCount ++;
//                if(tmpComment.childArray == nil)
//                {
//                    NSMutableArray *childArray = [[NSMutableArray alloc] init];
//                    tmpComment.childArray = childArray;
//                    [childArray release];
//                }
//                [tmpComment.childArray addObject:comment];
//                self.expandItem = self.currentCell.helpCommentData;
//                self.currentCell = nil;
//            }
//            else
//            {
//                [_commentInfoArray addObject:comment];
//            }
            [_commentInfoArray addObject:info];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
               
                [self.offlineCache insertIntoSecretCommentWithId:self.aroundHelpInfo.helpID commentInfo:info];
                [self.offlineCache updateSecret:self.aroundHelpInfo];
            });
            
            self.aroundHelpInfo.commentCount = self.aroundHelpInfo.commentInfoArray.count;
           
            [info release];
           // [comment release];
            
            [_tableView reloadData];
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"评论失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_praiseSecretIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            self.aroundHelpInfo.praise = NO;
            self.aroundHelpInfo.praiseCount ++;
            
            [self.praiseButton setTitle:[NSString stringWithFormat:@"%lld", self.aroundHelpInfo.praiseCount] forState:UIControlStateNormal];
        }
        else
        {
            [JBoUserOperation alertMsg:@"您已赞过"];
        }
        return;
    }
}

- (void)contentLongPress:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        [self becomeFirstResponder];
        UIMenuController *menu = [UIMenuController sharedMenuController];
        [menu setTargetRect:longPress.view.frame inView:self.view];
        [menu setMenuVisible:YES animated:YES];
    }
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if(action == @selector(copy:))
    {
        return YES;
    }
    return NO;
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

- (void)copy:(id)sender
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = self.aroundHelpInfo.helpMsg;
}


#pragma mark-JBoSubmitCommentView代理
- (void)submitDidFinished:(NSString *)comment
{
    self.title = @"详情";
    if(![NSString isEmpty:comment])
    {
        self.navigationItem.rightBarButtonItem.enabled = NO;
        _httpRequest.identifier = _releaseHelpCommentIdentifier_;
        self.isRequesting = YES;
        self.submitComment = comment;
        [_httpRequest downloadWithURL:[JBoHelpOperation getReleaseHelpCommentURL] dic:[JBoHelpOperation getReleaseHelpCommentPostDataWithMsg:comment parentId:self.parentCommentID helpId:self.aroundHelpInfo.helpID]];
    }
    else
    {
        [JBoUserOperation alertMsg:@"评论内容不能为空"];
    }
}

- (void)submitViewWillDismiss:(JBoSubmitInputContentView *)view
{
    self.title = @"详情";
}

#pragma mark-加载视图

- (void)back
{
    [_downloadProgressDic removeAllObjects];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)comment
{
    self.title = @"评论";
    self.parentCommentID = _helpParentCommentIDDefaultValue_;
    
    if(!_submitCommentView)
    {
        _submitCommentView = [[JBoSubmitInputContentView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) maxCommentCount:_inputFormatNewsComment_];
        _submitCommentView.delegate = self;
        [self.view addSubview:_submitCommentView];
    }
    
    [_submitCommentView beginComment];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
	[self setBackItem:YES];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.commentInfoArray = self.aroundHelpInfo.commentInfoArray;
    
    if(self.commentInfoArray.count == 0)
    {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
            NSArray *array = [self.offlineCache getSecretCommentWithId:self.aroundHelpInfo.helpID];
            [self.commentInfoArray addObjectsFromArray:array];
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
                
                [_tableView reloadData];
            });
        });
    }
    
    if(!self.userDetailInfo)
    {
        JBoAsyncDownloadUserInfoOperation *asyncDownload = [[JBoAsyncDownloadUserInfoOperation alloc] init];
        __block JBoAsyncDownloadUserInfoOperation *blockAsyncDownload = asyncDownload;
        
        asyncDownload.completionHandler = ^(void)
        {
            self.userDetailInfo = blockAsyncDownload.userDetailInfo;
            [self loadInitView];
            [blockAsyncDownload release];
        };
        [asyncDownload downloadWithUserId:self.aroundHelpInfo.userID];
    }
    else
    {
        [self loadInitView];
    }
}


- (void)updateImage:(NSArray*) array
{
    UIImage *image = [array objectAtIndex:0];
    JBoUserHeadImageView *imageView = [array objectAtIndex:1];
    imageView.imageView.image = image;
}

- (void)loadInitView
{
    [self setRightBarItemWithIcon:[UIImage imageNamed:@"helpComment_icon"] action:@selector(comment)];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor clearColor];
    _tableView.tableFooterView = view;
    [view release];
    
    if(!self.isSelf)
    {
        _tableheaderView = [[UIView alloc] initWithFrame:CGRectZero];
        _tableheaderView.backgroundColor = [UIColor whiteColor];
        
        //发布人信息
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouched:)];
        JBoUserHeadImageView *headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_padding_, _controlInterval_ * 2, _headImageSize_, _headImageSize_)];
        headImageView.layer.cornerRadius = 17.0;
        headImageView.userInteractionEnabled = YES;
        [headImageView addGestureRecognizer:tap];
        [tap release];
        headImageView.sex = self.userDetailInfo.rosterInfo.sex;
        headImageView.imageView.image = nil;
        [_tableheaderView addSubview:headImageView];
        [headImageView release];
        
        //位置
        UILabel *distanceLabel = [[UILabel alloc] initWithFrame:CGRectMake(headImageView.frame.origin.x + headImageView.frame.size.width + _controlInterval_, headImageView.frame.origin.y + (headImageView.frame.size.height - _controlHeight_) / 2, _width_ - _headImageSize_ - _controlInterval_ - _padding_ * 2, _controlHeight_)];
        distanceLabel.textColor = [UIColor grayColor];
        distanceLabel.text = self.aroundHelpInfo.distance;
        [_tableheaderView addSubview:distanceLabel];
        [distanceLabel release];
        
        //内容
        JBoImageTextLabel *contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectZero];
        CGSize size = [JBoImageTextTool getHeightFromAttributedText:[contentLabel getAttributedTextFromString:self.aroundHelpInfo.helpMsg] contraintWidth:_width_ - _padding_ * 2];
        contentLabel.frame = CGRectMake(headImageView.frame.origin.x, headImageView.bottom + _controlInterval_, _width_ - _padding_ * 2, size.height + 10.0);
        contentLabel.textColor = [UIColor blackColor];
        contentLabel.backgroundColor = [UIColor clearColor];
        //contentLabel.horizontalAlignmentCenter = YES;
       // contentLabel.verticalAlignmentCenter = YES;
        contentLabel.delegate = self;
        contentLabel.text = self.aroundHelpInfo.helpMsg;
        contentLabel.userInteractionEnabled = YES;
        UILongPressGestureRecognizer *longpress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(contentLongPress:)];
        [contentLabel addGestureRecognizer:longpress];
        [longpress release];
        [_tableheaderView addSubview:contentLabel];
        [contentLabel release];
        
        CGFloat y = contentLabel.bottom;
        if(self.aroundHelpInfo.imageURLArray.count > 0)
        {
            JBoMultiImageView *multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectMake(contentLabel.left, y + 10.0, _multiSize_ * _imagesPerRows_ + _multiImageInterval_ * (_imagesPerRows_ - 1), [JBoMultiImageView getThumbnailHeightWithCount:self.aroundHelpInfo.imageURLArray.count])];
            multiImageView.images = self.aroundHelpInfo.imageURLArray;
            multiImageView.onlythumbnail = YES;
            multiImageView.delegate = self;
            [_tableheaderView addSubview:multiImageView];
            self.multiImageView = multiImageView;
            [multiImageView release];
            y = multiImageView.bottom;
            
        }
        
        CGFloat buttonWidth = 70.0;
        CGFloat buttonHeight = 40.0;
        CGFloat padding = 20.0;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [button setTitle:@"投诉" forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:15.0];
        [button setImage:[UIImage imageNamed:@"complaint_icon.png"] forState:UIControlStateNormal];
        [button setFrame:CGRectMake(_width_ - buttonWidth - padding, y + 10.0, buttonWidth, buttonHeight)];
        [button addTarget:self action:@selector(complaint:) forControlEvents:UIControlEventTouchUpInside];
        [_tableheaderView addSubview:button];
        
        button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [button setTitle:[NSString stringWithFormat:@"%lld", self.aroundHelpInfo.praiseCount] forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:12.0];
        [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentRight];
        [button setImage:[UIImage imageNamed:@"helpPraise_btn"] forState:UIControlStateNormal];
        [button setFrame:CGRectMake(_width_ - buttonWidth - padding - 170.0, y + 10.0, 150.0, buttonHeight)];
        [button addTarget:self action:@selector(praise:) forControlEvents:UIControlEventTouchUpInside];
        [_tableheaderView addSubview:button];
        self.praiseButton = button;
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, button.bottom + 1.0, _width_, 0.5)];
        lineView.backgroundColor = [UIColor colorWithWhite:0.8 alpha:1.0];
        [_tableheaderView addSubview:lineView];
        [lineView release];
        
        _tableheaderView.frame = CGRectMake(0, 0, _width_, button.bottom + _padding_);
        _tableView.tableHeaderView = _tableheaderView;
    }
}

#pragma mark- JBoImageTextLabel代理

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    if(![self.userDetailInfo.rosterInfo.username isEqualToString:self.myUserDetailInfo.rosterInfo.username])
    {
        web.userId = self.userDetailInfo.rosterInfo.username;
    }
    web.black = self.black;
    web.URL = url;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

#pragma mark- multiImage代理

- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = index;
    [self.imageScrollView reloadData];
    
    [self.imageScrollView showInViewController:self];
}

#pragma mark-reuseScrollView代理

- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.aroundHelpInfo.imageURLArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    NSString *url = [self.aroundHelpInfo.imageURLArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:url thumbnailSize:CGSizeZero];

    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:url forIndex:index];
        }
    }

    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    NSString *url = [self.aroundHelpInfo.imageURLArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:url thumbnailSize:CGSizeZero];
    if(!image)
    {
        [self downloadImageWithUrl:url forIndex:index];
    }
}


- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    [_tableView reloadData];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.imageScrollView cellForIndex:index];
        
        cell.imageView.image = image;
        [self.imageScrollView reloadDataAtIndex:index];
    }];
}


#pragma mark- private method

- (void)praise:(UIButton*) button
{
    if(self.isRequesting)
        return;
    
    if(!self.aroundHelpInfo.praise)
    {
        [self alertMsg:@"您已赞过"];
        return;
    }
    
    self.isRequesting = YES;
    _httpRequest.identifier = _praiseSecretIdentifier_;
    [_httpRequest downloadWithURL:[JBoHelpOperation getPraiseSecretURL] dic:[JBoHelpOperation getPraiseSecretParaWithInfo:self.aroundHelpInfo]];
}

- (void)complaint:(UIButton*) button
{
    JBoComplaintViewController *complaintVC = [[JBoComplaintViewController alloc] init];
    complaintVC.userId = self.userDetailInfo.rosterInfo.username;
    
    JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:complaintVC];
    nav.black = NO;
    [self.appDelegate.window.rootViewController presentViewController:nav animated:YES completion:nil];
    [complaintVC release];
    [nav release];
}

- (void)headImageDidTouched:(UITapGestureRecognizer*) tap
{
    if([self.userDetailInfo.rosterInfo.username isEqualToString:[JBoUserOperation getUserId]])
        return;
    JBoPublickUserInfoViewController *publicVC = [[JBoPublickUserInfoViewController alloc] init];
    publicVC.sendMsgType = JBoSendMsgSecret;
    publicVC.userDetailInfo = self.userDetailInfo;
    [self.navigationController pushViewController:publicVC animated:YES];
    [publicVC release];
}

- (void)sendMsgAction:(UIButton*) buttom
{
    JBoSendMsgViewController *sendMsgVC = [[JBoSendMsgViewController alloc] init];
    sendMsgVC.rosterInfo = self.userDetailInfo.rosterInfo;
    [self.navigationController pushViewController:sendMsgVC animated:YES];
    [sendMsgVC release];
}

- (void)exchangeAction:(UIButton*) button
{
    if([JBoUserOperation isSelfWithJid:self.userDetailInfo.rosterInfo.jid])
    {
        [JBoUserOperation alertMsg:@"该用户已是您的好友"];
        return;
    }
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"请求信息" message:@"" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    textField.placeholder = [NSString stringWithFormat:@"%d字以内",_inputFormatStatus_];
    [alerView show];
    [alerView release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        UITextField *textField = [alertView textFieldAtIndex:0];
        if(textField.text.length > _inputFormatStatus_)
        {
            [JBoUserOperation alertMsg:[NSString stringWithFormat:@"验证信息不能超过%d字",_inputFormatStatus_]];
        }
        else
        {
            if([JBoUserOperation sendApplyInfoWithStatus:textField.text jid:self.userDetailInfo.rosterInfo.jid type:JBoAddBuddyTypeSecret])
            {
                self.isRequesting = YES;
            }
        }
    }
}

#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _commentInfoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoHelpCommentInfo *info = [_commentInfoArray objectAtIndex:indexPath.row];

    if(info.contentHeight == NSNotFound)
    {
        CGSize size = [JBoImageTextTool getHeightFromAttributedText:[self.imageText getAttributedTextFromString:info.commentMsg] contraintWidth:_width_ - _helpCommentImageSize_ - _helpCommentContentInterval_ * 3 - _helpCommentTextInset_ * 2] ;
        info.contentHeight = size.height + 10.0;
    }
    
    CGFloat height = info.contentHeight + _helpCommentContentInterval_ + _helpCommentContentHeight_ + _helpCommentTextInset_ * 2;
    
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    JBoHelpCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoHelpCommentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoHelpCommentInfo *info = [_commentInfoArray objectAtIndex:indexPath.row];
    
   // cell.nameLabel.text = info.userName;
    cell.contentHeight = info.contentHeight;
    cell.contentLabel.text = info.commentMsg;
    
    JBoUserDetailInfo *userDetailInfo = [_headImageDic objectForKey:info.userID];
    
//    if(userDetailInfo.rosterInfo.image)
//    {
//        cell.headImageView.image = userDetailInfo.rosterInfo.image;
//    }
//    else
//    {
        cell.headImageView.sex = userDetailInfo.rosterInfo.sex;
    cell.headImageView.headImageURL = nil;
//    }
    
    if(!userDetailInfo)
    {
        if(!tableView.dragging && !tableView.decelerating)
        {
            [self donloadUserInfoForInfo:info];
        }
    }
//    else
//    {
//        cell.nameLabel.sex = userDetailInfo.rosterInfo.sex;
//    }
    
    //cell.headImageView.role = userDetailInfo.rosterInfo.role;
    cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.commentDate];
   // cell.nameLabel.text = userDetailInfo.rosterInfo.name;
   
    return cell;
}



#pragma mark-JBoHelpCommentCell代理

- (void)helpCommentCellDidTouchHeadImage:(JBoHelpCommentCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    if(indexPath.row >= _commentInfoArray.count)
        return;
    JBoHelpCommentInfo *info = [_commentInfoArray objectAtIndex:indexPath.row];
    
    if([info.userID isEqualToString:[JBoUserOperation getUserId]])
        return;
    
    JBoPublickUserInfoViewController *publicVC = [[JBoPublickUserInfoViewController alloc] init];
    publicVC.sendMsgType = JBoSendMsgSecret;
    
    JBoUserDetailInfo *detailInfo = [_headImageDic objectForKey:info.userID];
    if(detailInfo)
    {
        publicVC.userDetailInfo = detailInfo;
    }
    else
    {
        publicVC.userId = info.userID;
    }
    
    [self.navigationController pushViewController:publicVC animated:YES];
    [publicVC release];
//    JBoRosterInfo *rosterInfo = [_appDelegate.rosterAndUsernameDic objectForKey:info.userID];
//    if(rosterInfo)
//    {
//        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
//        detail.rosterInfo = rosterInfo;
//        [self.navigationController pushViewController:detail animated:YES];
//        [detail release];
//    }
//    else
//    {
//        JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
//        userInfo.userId = info.userID;
//        [self.navigationController pushViewController:userInfo animated:YES];
//        [userInfo release];
//    }
}


- (void)donloadUserInfoForInfo:(JBoHelpCommentInfo*) info
{
  //  NSLog(@"下载%@", info.userID);
    JBoAsyncDownloadUserInfoOperation *asyncDownload = [_downloadProgressDic objectForKey:info.userID];
    if(!asyncDownload)
    {
        asyncDownload = [[JBoAsyncDownloadUserInfoOperation alloc] init];
        __block JBoAsyncDownloadUserInfoOperation *blockAsyncDownload = asyncDownload;
        
        asyncDownload.completionHandler = ^(void)
        {
            if(blockAsyncDownload.userDetailInfo)
            {
                if(blockAsyncDownload.userDetailInfo.rosterInfo.image)
                {
                    blockAsyncDownload.userDetailInfo.rosterInfo.image = [JBoImageTextTool getThumbnailFromImage:blockAsyncDownload.userDetailInfo.rosterInfo.image withSize:CGSizeMake(_helpCommentImageSize_, _helpCommentImageSize_)];
                }
                [_headImageDic setObject:blockAsyncDownload.userDetailInfo forKey:info.userID];
                [_tableView reloadData];
               // NSLog(@"%@",blockAsyncDownload.userDetailInfo);
            }
            [_downloadProgressDic removeObjectForKey:info.userID];
        };
        [_downloadProgressDic setObject:asyncDownload forKey:info.userID];
        [asyncDownload downloadWithUserId:info.userID];
        [asyncDownload release];
    }
}

#pragma mark-加载头像
- (void)downloadImageForInfo:(JBoHelpCommentInfo*) info
{
    //先判断该头像是否正在下载
    JBoAsyncDownloadImageOperation *asyncDownloadOperation = [_downloadProgressDic objectForKey:info.userID];
    
    if(!asyncDownloadOperation)
    {
        //创建一个queue来获取头像
        JBoAsyncDownloadImageOperation *asyncDownloadOperation = [[JBoAsyncDownloadImageOperation alloc] init];
        
        __block JBoAsyncDownloadImageOperation *blockAsyncDownloadOperation = asyncDownloadOperation;
        
        [asyncDownloadOperation setCompletionHandler:^(){
            
            UIImage *image = [[UIImage alloc] initWithData:blockAsyncDownloadOperation.data];
            if(image)
            {
                
                [_headImageDic setObject:image forKey:info.userID];
            }
            else
            {
                //[_headImageDic setObject:_appDelegate.defaultImage forKey:info.userID];
            }
            [image release];
            
            [self performSelectorOnMainThread:@selector(updataHeaderImage) withObject:nil waitUntilDone:NO];
            
            [_downloadProgressDic removeObjectForKey:info.userID];
        }];
        
        [_downloadProgressDic setObject:asyncDownloadOperation forKey:info.userID];
        [asyncDownloadOperation downloadWithURL:info.imageURL];
        [asyncDownloadOperation release];
    }
}

- (void)updataHeaderImage
{
    [_tableView reloadData];
}


//加载可见的cell的好友头像
- (void)loadImageForOnScreenRows
{
    if(_commentInfoArray.count > 0)
    {
        NSArray *indexPaths = [_tableView indexPathsForVisibleRows];
        for(NSIndexPath *indexPath in indexPaths)
        {
            JBoHelpCommentInfo *info = [_commentInfoArray objectAtIndex:indexPath.row];
            
            JBoUserDetailInfo *detailInfo = [_headImageDic objectForKey:info.userID];
            if(!detailInfo)
            {
                [self donloadUserInfoForInfo:info];
            }
        }
    }
}

#pragma mark-scrollView代理  在用户停止拖动和拖动停止减速时加载头像

//- (void)scrollViewDidScroll:(UIScrollView *)scrollView
//{
//    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
//    {
//        if(!_bottomLoadingView)
//        {
//            //创建加载更多视图
//            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
//        }
//        NSLog(@"--");
//        if(!self.isRequesting && _hasInfo)
//        {
//            self.parentIndex ++;
//            _treeView.treeFooterView = _bottomLoadingView;
//            //[self loadCommentInfo:YES pageIndex:self.parentIndex parentID:self.parentCommentID];
//        }
//    }
//    
//}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    //NSLog(@"addressBook scrollViewDidEndDragging");
    if(!decelerate)
    {
        [self loadImageForOnScreenRows];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    // NSLog(@"addressBook scrollViewDidEndDecelerating");
    [self loadImageForOnScreenRows];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [_downloadProgressDic removeAllObjects];
}

@end
