//
//  JBoHelpCommentDataObject.h
//  连客
//
//  Created by kinghe005 on 14-1-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface JBoHelpCommentInfo : NSObject

//id 日期 信息
@property(nonatomic,assign) long long parentCommentID;
@property(nonatomic,assign) long long commentID;
@property(nonatomic,copy) NSString *commentDate;
@property(nonatomic,copy) NSString *commentMsg;

@property(nonatomic,assign) NSInteger contentHeight;

//回复数量
@property(nonatomic,assign) NSInteger replyCount;

//用户id 昵称 性别
@property(nonatomic,copy) NSString *userID;
@property(nonatomic,copy) NSString *userName;
@property(nonatomic,assign) NSInteger sex;
@property(nonatomic,copy) NSString *imageURL;


@end

@interface JBoHelpCommentDataObject : NSObject

@property(nonatomic,retain) JBoHelpCommentInfo *parentCommentInfo;
@property(nonatomic,retain) NSMutableArray *childArray;

@property(nonatomic,assign) BOOL loading;

- (id)initWithHelpInfo:(JBoHelpCommentInfo*) commentInfo childArray:(NSMutableArray*) childArray;

@end
