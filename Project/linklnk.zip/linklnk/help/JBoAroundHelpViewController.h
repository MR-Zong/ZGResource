//
//  JBoAroundHelpViewController.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**附近匿名
 */
@interface JBoAroundHelpViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIAlertViewDelegate>
{
    UITableView *_tableView;
    
    //附近匿名信息，数组元素是 JBoAroundHelpInfo对象
    NSMutableArray *_infoArray;
}

/**是否有新匿名 default is 'NO'
 */
@property(nonatomic,assign) BOOL hasNewsSecret;

@end
