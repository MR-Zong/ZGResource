//
//  JBoReleaseHelpMsgViewController.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoReleaseHelpMsgViewController.h"
#import "JBoAppDelegate.h"
#import <CoreLocation/CoreLocation.h>
#import "BMapKit.h"
#import "SSTextView.h"
#import "JBoIconTextView.h"
#import "JBoHelpOperation.h"
#import "JBoHelpInfo.h"
#import "JBoDatetimeTool.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoMapViewController.h"
#import "JBoImageTextTool.h"
#import "JBoUserPrivacyViewController.h"
#import "JBoAroundHelpInfo.h"
#import "JBoSceneMakingOperation.h"
#import "JBoImageOperationView.h"
#import "JBoImageOperationPreviewedViewController.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoFileManager.h"
#import "JBoImageCacheTool.h"
#import "JBoImageTextLabel.h"
#import "BMKGeoCodeSearch+Utilities.h"
#import "JBoStraightlineProgressView.h"

#define _controlInterval_ 5
#define _controlHeight_ 30
#define _padding_ 20

@interface JBoReleaseHelpMsgViewController ()<BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate,UITextViewDelegate,JBoHttpRequestDelegate,UIGestureRecognizerDelegate,JBoMapViewControllerDelegate,JBoImageOperationViewDelegate,JBoImageOperationPreviewedViewControllerDelegate,JBoMutiImagePickerDelegate>
{
    //定位
    BMKLocationService *_locationManager;
    
    JBoHttpRequest *_httpRequest;
}

//地理反编码
@property(nonatomic,retain) BMKGeoCodeSearch *addrSearch;

//地址信息
@property(nonatomic,retain) JBoMapInfo *addrInfo;

@property(nonatomic,assign) BOOL isRequesting;
//是否定位
@property(nonatomic,assign) BOOL isLocation;
@property(nonatomic,assign) BOOL locating;

//上传图片
@property(nonatomic,retain) NSMutableArray *imageArray;
@property(nonatomic,retain) JBoImageOperationView *imageOperationView;

//滚动视图
@property(nonatomic,retain) UIScrollView *scrollView;
@property(nonatomic,assign) CGFloat orgHeight;

//上传的文件
@property(nonatomic,retain) NSArray *files;

//位置地址
@property(nonatomic,retain) UIView *locationView;

//当前登录的用户信息
@property(nonatomic,retain) JBoUserDetailInfo *info;

//请求定位
@property(nonatomic,retain) CLLocationManager *sysLocationManager;

//上传进度
@property(nonatomic,retain) JBoStraightlineProgressView *progressView;

@end

@implementation JBoReleaseHelpMsgViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.addrInfo = [[[JBoMapInfo alloc] init] autorelease];
        self.title = [NSString stringWithFormat:@"发布%@", _helpName_];
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.showAccurateProgress = YES;
        _httpRequest.delegate = self;
        
        self.isRequesting = NO;
        
        self.info = [JBoUserOperation getUserDetailInfo];
        
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _contentTextView.editable = !_isRequesting;
        self.navigationItem.rightBarButtonItem.enabled = !_isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}



#pragma mark-内存管理
- (void)dealloc
{
    NSLog(@"JBoReleaseHelpMsgViewController dealloc");
    [_contentTextView release];
    [_actView release];
    [_addressLabel release];
    
    [_locationManager release];
    [_addrSearch release];
    [_httpRequest release];
    
    [_addrInfo release];
    
    [_imageOperationView release];
    [_imageArray release];
    
    [_scrollView release];
    
    [JBoFileManager deleteFiles:_files];
    [_files release];
    
    [_locationView release];
    [_info release];
    [_sysLocationManager release];
    
    [_progressView release];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    _locationManager.delegate = self;
    _addrSearch.delegate = self;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if(!self.isLocation)
    {
        [self currentLocationAction:_defaultLocationButton];
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.locating = NO;
    [_actView stopAnimating];
    
    [_locationManager stopUserLocationService];
    _locationManager.delegate = nil;
    _addrSearch.delegate = nil;
    
    [_locationManager release];
    _locationManager = nil;
    [self.appDelegate closeAlertView];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.progressView.hidden = YES;
    self.isRequesting = NO;
    if([identifier isEqualToString:_releaseHelpInfoIdentifier_])
    {
        [JBoFileManager deleteFiles:_files];
        [JBoUserOperation alertmsgWithBadNetwork:@"发布失败"];
        return;
    }
    
    if([identifier isEqualToString:_getUserHelpInfoIdentifier_])
    {
        [JBoFileManager deleteFiles:_files];
        [JBoUserOperation alertmsgWithBadNetwork:@"发布失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_releaseHelpInfoIdentifier_])
    {
        BOOL success = [JBoUserOperation isSuccess:data];
        
        if(success)
        {
            [_httpRequest startDataLoading];
            _httpRequest.identifier = _getUserHelpInfoIdentifier_;
            self.isRequesting = YES;
            [_httpRequest downloadWithURL:[JBoHelpOperation getUserHelpInfoWithPageNum:1 rows:1]];
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"发布失败"];
        }
        return;
    }
    
    if([identifier isEqualToString:_getUserHelpInfoIdentifier_])
    {
        NSArray *array = [JBoHelpOperation getUserHelpInfoFromData:data];
        if(array.count > 0)
        {
            self.progressView.progress = 1.0;
            JBoHelpInfo *helpInfo = [array firstObject];
            
            JBoAroundHelpInfo *info = [[[JBoAroundHelpInfo alloc] init] autorelease];
            info.praise = YES;
            info.helpID = helpInfo.helpID;
            info.helpDate = helpInfo.helpDate;
            info.helpMsg = helpInfo.helpMsg;
            info.imageURLArray = helpInfo.imageURLArray;
            info.userID = [JBoUserOperation getUserId];
            info.commentInfoArray = [NSMutableArray array];
            info.distance = [NSString stringWithFormat:@"1米"];
            info.coordinate = self.addrInfo.coordinate;
            
            JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
            [JBoFileManager moveFiles:self.files withURLs:info.imageURLArray suffix:cache.imageSuffix toPath:cache.normalCachePath];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:_releaseHelpMsgNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:info forKey:_helpMessage_]];
            
            
            
            [JBoUserOperation alertMsg:@"发布成功"];
            [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
        }
        else
        {
            self.progressView.hidden = YES;
            [JBoUserOperation alertmsgWithBadNetwork:@"发布失败"];
        }
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didUpdateProgress:(float)progress identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_releaseHelpInfoIdentifier_])
    {
        if(!self.progressView)
        {
            CGFloat height = 3.0;
            JBoStraightlineProgressView *view = [[JBoStraightlineProgressView alloc] initWithFrame:CGRectMake(0, 0, _width_, height)];
            [self.view addSubview:view];
            self.progressView = view;
            [view release];
        }
        [self.view bringSubviewToFront:self.progressView];
        self.progressView.hidden = NO;
        self.progressView.progress = progress * 0.95;
    }
}

#pragma mark-加载视图

- (void)finishAction
{
    if([NSString isEmpty:_contentTextView.text])
    {
        [JBoUserOperation alertMsg:@"内容不能为空"];
        return;
    }
    
    if(!self.isLocation)
    {
        [JBoUserOperation alertMsg:@"正在定位,请稍后..."];
        return;
    }
    
    if(self.addrInfo == nil)
    {
        [JBoUserOperation alertMsg:@"还没定位,无法提交"];
        return;
    }
    
    self.progressView.progress = 0;
    _httpRequest.identifier = _releaseHelpInfoIdentifier_;
    [_httpRequest startDataLoading];
    
    self.files = [JBoFileManager writeImageInTemporaryFile:self.imageArray withCompressedScale:_helpImageCompressedScale_];
    
    NSDictionary *dic = [JBoHelpOperation getReleaseHelpInfoPostDataWihtMsg:_contentTextView.text latitude:self.addrInfo.coordinate.latitude logitude:self.addrInfo.coordinate.longitude address:[JBoSceneMakingOperation getUploadAddrFromMapInfo:self.addrInfo]];
    
    long long fileSize = _contentTextView.text.length * 2;
    for(NSString *str in self.files)
    {
        if([[NSFileManager defaultManager] fileExistsAtPath:str])
        {
            fileSize += [[[NSFileManager defaultManager] attributesOfItemAtPath:str error:nil] fileSize];
        }
    }
    _httpRequest.totalBytesSent = fileSize;
   
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoHelpOperation getReleaseHelpInfoURL] paraDic:dic files:self.files filesKey:_helpImagesFile_];
}

- (void)reconverKeyboard:(UITapGestureRecognizer*) tap
{
    [_contentTextView resignFirstResponder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_- _navgateBarHeight_)];
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.backgroundColor = self.view.backgroundColor;
    [self.view addSubview:scrollView];
    self.scrollView = scrollView;
    [scrollView release];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyboard:)];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
    [tap release];
    
    [self setBackItem:YES];
    [self setRightBarItemWithTitle:@"完成" action:@selector(finishAction)];
    
    //内容
    _contentTextView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _controlInterval_ * 2, _width_ - _padding_ * 2, _controlHeight_ * 5)];
    _contentTextView.placeholder = [NSString stringWithFormat:@"附近%@是匿名圈，你发布的信息在一定距离内任何人可见，任何人都可以评论（但无法查看彼此的呢称、头像等个人详细资料），加好友请求会标注“%@”，可以举报投诉或加入黑名单", _helpName_, _addBuddyTypeSectet_];
    _contentTextView.layer.cornerRadius = 6;
    _contentTextView.layer.borderWidth = 0.2;
    _contentTextView.layer.borderColor = [UIColor grayColor].CGColor;
    _contentTextView.font = [UIFont systemFontOfSize:17];
    _contentTextView.delegate = self;
    _contentTextView.limitable = YES;
    _contentTextView.maxCount = _inputFormatHelpNum_;
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
    view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
    
    CGFloat buttonWidth = 60.0;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button setTitle:@"完成" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
    [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
    [view addSubview:button];
    
    _contentTextView.inputAccessoryView = view;
    [view release];
    
    [self.scrollView addSubview:_contentTextView];
  
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, _contentTextView.bottom + 10.0, _width_ - _padding_ * 2, 30.0)];
    label.text = @"上传图片";
    label.font = [UIFont systemFontOfSize:15.0];
    label.textColor = [UIColor grayColor];
    label.backgroundColor = [UIColor clearColor];
    [self.scrollView addSubview:label];
    [label release];
    
    self.imageArray = [NSMutableArray array];
    JBoImageOperationView *imageOperationView = [[JBoImageOperationView alloc] initWithFrame:CGRectMake(_padding_, label.bottom + 10.0, _width_ - _padding_ * 2, _imageOperationDefaultCellSize_) srcArray:self.imageArray imageSize:_imageOperationDefaultCellSize_];
    imageOperationView.backgroundColor = [UIColor whiteColor];
    imageOperationView.delegate = self;
    imageOperationView.maxCount = 9;
    [self.scrollView addSubview:imageOperationView];
    self.imageOperationView = imageOperationView;
    [imageOperationView release];
    
    //位置地
    
    UIView *locationView = [[UIView alloc] initWithFrame:CGRectMake(_padding_, self.imageOperationView.bottom + 20.0, _width_ - _padding_ * 2, 0)];
    locationView.layer.cornerRadius = 5.0;
    locationView.layer.masksToBounds = YES;
    locationView.backgroundColor = [UIColor whiteColor];
    [self.scrollView addSubview:locationView];
    self.locationView = locationView;
    [locationView release];
    
    UIFont *font = [UIFont systemFontOfSize:15.0];
    //位置
    buttonWidth = 85.0;
    CGFloat buttonHeight = 30.0;
    UIButton *locButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [locButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [locButton setTitle:@"位置" forState:UIControlStateNormal];
    [locButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
    locButton.titleLabel.font = font;
    [locButton setImage:[UIImage imageNamed:@"conditions_map"] forState:UIControlStateNormal];
    [locButton setFrame:CGRectMake(10.0 / 2.0, (40.0 - buttonHeight) / 2.0, buttonWidth, buttonHeight)];
    [locationView addSubview:locButton];
    
    //当前位置
    _defaultLocationButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_defaultLocationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_defaultLocationButton setTitle:@"默认位置" forState:UIControlStateNormal];
    _defaultLocationButton.titleLabel.font = font;
    [_defaultLocationButton setImage:[UIImage imageNamed:@"sceneNormal_gray"] forState:UIControlStateNormal];
    [_defaultLocationButton setImage:[UIImage imageNamed:@"sceneSelected"] forState:UIControlStateSelected];
    [_defaultLocationButton setFrame:CGRectMake(locButton.right + 5.0, locButton.top, buttonWidth, buttonHeight)];
    [_defaultLocationButton addTarget:self action:@selector(currentLocationAction:) forControlEvents:UIControlEventTouchUpInside];
    [locationView addSubview:_defaultLocationButton];
    
    
    //其他位置
    _locationButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_locationButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_locationButton setTitle:@"直接定位" forState:UIControlStateNormal];
    _locationButton.titleLabel.font = font;
    [_locationButton setImage:[UIImage imageNamed:@"sceneNormal_gray"] forState:UIControlStateNormal];
    [_locationButton setImage:[UIImage imageNamed:@"sceneSelected"] forState:UIControlStateSelected];
    [_locationButton setFrame:CGRectMake(self.locationView.width - buttonWidth, locButton.top, buttonWidth, buttonHeight)];
    [_locationButton addTarget:self action:@selector(otherLocationAction:) forControlEvents:UIControlEventTouchUpInside];
    [locationView addSubview:_locationButton];
    
    //分割线
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 40.0, locationView.width, 0.5)];
    line.backgroundColor = [UIColor colorWithWhite:0.8 alpha:1.0];
    [locationView addSubview:line];
    [line release];
    
    //位置地址
    _addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_, line.bottom, self.locationView.width - _controlInterval_ * 2, 50.0)];
    _addressLabel.textColor = [UIColor grayColor];
    _addressLabel.backgroundColor = [UIColor clearColor];
    _addressLabel.numberOfLines = 0;
    _addressLabel.font = [UIFont systemFontOfSize:14.0];
    _addressLabel.hidden = YES;
    [self.locationView addSubview:_addressLabel];
    
    _addressLabel.hidden = YES;
    if(!_actView)
    {
        CGFloat size = 30;
        _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _actView.hidesWhenStopped = YES;
        _actView.frame = CGRectMake((locationView.width - size) / 2.0, _addressLabel.top + (_addressLabel.height - size) / 2.0, size, size);
        [self.locationView addSubview:_actView];
    }
    self.locationView.height = _addressLabel.bottom;
    
    //使用条款
    UIView *protocalView = [JBoUserOperation getProtocolViewWithFrame:CGRectMake(0, self.locationView.bottom + _padding_ * 2, _width_, 0) target:self action:@selector(serverProtocolAction:)];
    [self.scrollView addSubview:protocalView];

    self.scrollView.contentSize = CGSizeMake(_width_, protocalView.bottom + _controlHeight_);
    self.orgHeight = self.scrollView.height;

}

- (void)inputFinish:(UIButton*) button
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (void)serverProtocolAction:(UIButton*) button
{
    JBoUserPrivacyViewController *userPrivacy = [[JBoUserPrivacyViewController alloc] init];
    [self.navigationController pushViewController:userPrivacy animated:YES];
    [userPrivacy release];
}

#pragma mark-textView代理

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    self.scrollView.height = self.orgHeight - 216.0;
    self.scrollView.contentOffset = CGPointMake(0, textView.frame.origin.y - _padding_);
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.scrollView.height = self.orgHeight;
    CGFloat y = textView.frame.origin.y - 216;
    self.scrollView.contentOffset = CGPointMake(0, y < 0 ? 0 : y);
}

- (void)textViewDidChange:(UITextView *)textView
{
    SSTextView *sst = (SSTextView*)textView;
    [sst textDidChange];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    SSTextView *sst = (SSTextView*)textView;
    return [sst shouldChangeTextInRange:range replacementText:text];
}

#pragma mark-gesture代理
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if([touch.view isKindOfClass:[UIButton class]])
        return NO;
    return YES;
}

#pragma mark- JBoMapViewController代理

- (void)mapViewController:(JBoMapViewController *)mapView didLocatedWithInfo:(NSDictionary *)userInfo
{
    self.addrInfo = [userInfo objectForKey:_locationInfo_];
    _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.addrInfo];

    self.isLocation = YES;
    [self setCurLocation:NO];
}

#pragma mark-位置

- (void)setCurLocation:(BOOL) cur
{
    _defaultLocationButton.selected = cur;
    _locationButton.selected = !cur;
}
//位置
- (void)currentLocationAction:(UIButton*) button
{
    if(![NSString isEmpty:self.info.defaultAddr])
    {
        self.addrInfo.coordinate = CLLocationCoordinate2DMake(self.info.defalutAddrLat, self.info.defaultAddrLon);
        NSDictionary *dic = [self.info strAddrAndPoiAddr];
        self.addrInfo.strAddr = [dic objectForKey:mapStrAddrKey];
        self.addrInfo.poiAddr = [dic objectForKey:mapPoiAddrKey];
        self.isLocation = YES;
        _addressLabel.hidden = NO;
        _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.addrInfo];
        [self setCurLocation:YES];
    }
    else
    {
        _addressLabel.hidden = YES;
        
        [_actView startAnimating];
        [self location];
    }
}

- (void)otherLocationAction:(UIButton*) button
{
    JBoMapViewController *mapVC = [[JBoMapViewController alloc] init];
    mapVC.delegate = self;
    mapVC.isSender = YES;
    mapVC.black = self.black;

    if(self.addrInfo)
    {
        mapVC.coordinate = self.addrInfo.coordinate;
        mapVC.detailAddr = self.addrInfo.strAddr;
        mapVC.poiInfo = self.addrInfo.poiAddr;
    }

    [self.navigationController pushViewController:mapVC animated:YES];
    [mapVC release];
}

- (void)finishLocation:(BOOL) success
{
    NSLog(@"定位完成");
    [_actView stopAnimating];
    _addressLabel.hidden = NO;
    if(success)
    {
        self.isLocation = YES;
        _addressLabel.text = [JBoImageTextTool getDetailAddrFromMapInfo:self.addrInfo];
        [self setCurLocation:YES];
        
        //保存默认位置
        if([NSString isEmpty:self.info.defaultAddr])
        {
            if(_addressLabel.text == nil)
                return;
            
            self.info.defaultAddr = _addressLabel.text;
            self.info.defalutAddrLat = self.addrInfo.coordinate.latitude;
            self.info.defaultAddrLon = self.addrInfo.coordinate.longitude;
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 _addressLabel.text, _rosterDefaultAddr_,
                                 [NSNumber numberWithDouble:self.addrInfo.coordinate.latitude], _rosterDefaultLat_,
                                 [NSNumber numberWithDouble:self.addrInfo.coordinate.longitude], _rosterDefaultLon_, nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:_saveDefaultAddrNotification_ object:self userInfo:dic];
        }
    }
    else
    {
        self.isLocation = NO;
        _addressLabel.text = @"无法确定您当前的位置";
        
        [JBoUserOperation openSystemSettingsAlertViewWithDelegate:self];
    }
    self.locating = NO;
}

#pragma mark- UIAlertView delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:_alertButtonTitleWhenCannotLocate_])
    {
        [JBoUserOperation openSystemSettings];
    }
}

- (void)layoutAddress
{
    CGSize size = [JBoImageTextTool getStringSize:_addressLabel.text withFont:_addressLabel.font andContraintSize:CGSizeMake(_addressLabel.width, _height_)];
    _addressLabel.height = size.height + 3.0;
}

#pragma mark- BMKGeoCodeSearch delegate

//BMKSearchDelegate
- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    if(error != BMK_SEARCH_NO_ERROR)
    {
        NSLog(@"获取地址信息出错%d",error);
        [self finishLocation:NO];
        return;
    }
    
    self.addrInfo.strAddr = result.address;
    BMKPoiInfo *info = [result.poiList firstObject];
    self.addrInfo.poiAddr = info.name;
    
    self.isLocation = YES;
    [self finishLocation:YES];
}

#pragma mark-定位
- (void)location
{
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        if([CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined)
        {
            self.sysLocationManager = [[[CLLocationManager alloc] init] autorelease];
            
            [self.sysLocationManager requestAlwaysAuthorization];
        }
#endif
    }
    
    BOOL canloc = NO;
    
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedAlways;
#endif
    }
    else
    {
        canloc = [CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorized;
    }
    
    if(canloc)
    {
        if(!_locationManager)
        {
            _locationManager = [[BMKLocationService alloc] init];
            _locationManager.delegate = self;
        }
        
        [_locationManager startUserLocationService];
        self.locating = YES;
    }
    else
    {
        [JBoUserOperation cannotUserLocationService];
        [self finishLocation:NO];
    }
}

#pragma mark- BMKLocationService delegate

- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    if(userLocation != nil && (userLocation.location.coordinate.latitude != 0 && userLocation.location.coordinate.longitude != 0))
    {
        self.addrInfo.coordinate = userLocation.location.coordinate;
        
        if(!_addrSearch)
        {
            self.addrSearch = [BMKGeoCodeSearch sharedInstance];
        }
        
        self.addrSearch.delegate = self;
        BMKReverseGeoCodeOption *option = [[[BMKReverseGeoCodeOption alloc] init] autorelease];
        option.reverseGeoPoint = self.addrInfo.coordinate;
        
        if([_addrSearch reverseGeoCode:option])
        {
            NSLog(@"地理反编码");
        }
        [_locationManager stopUserLocationService];
    }
}

- (void)didFailToLocateUserWithError:(NSError *)error
{
    [_locationManager stopUserLocationService];
    [self finishLocation:NO];
}

#pragma mark-JBoImageOperationView代理

- (void)imageOperationViewDidAddedCell:(JBoImageOperationView *)selectedView
{
    if(self.isRequesting)
        return;
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
    [actionSheet showInView:self.navigationController.view];
    [actionSheet release];
}

- (void)imageOperationView:(JBoImageOperationView *)selctedView didSelectImageAtIndex:(NSInteger)index
{
    JBoImageOperationPreviewedViewController *previewVC = [[JBoImageOperationPreviewedViewController alloc] init];
    previewVC.srcArray = selctedView.srcArray;
    previewVC.currentIndex = index;
    previewVC.delegate = self;
    [self.navigationController pushViewController:previewVC animated:YES];
    [previewVC release];
}

- (void)imageOperationViewDidReloadData:(JBoImageOperationView *)selctedView
{
    self.appDelegate.dataLoadingView.hidden = YES;
}

#pragma mark-JBoImageOperationPreviewedViewController代理
- (void)imageOperationPreviewedViewController:(JBoImageOperationPreviewedViewController *)viewController didRemoveImageAtIndex:(NSInteger)index
{
    [self.imageOperationView removeImageAtIndex:index];
}

#pragma makr-actionsheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [self getCamera];
    }
    else if(buttonIndex == 1)
    {
        [self getPhotos];
    }
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        [self.imageOperationView.srcArray addObject:[JBoImageTextTool getThumbnailFromImage:retImage withSize:size]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("album", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [self.appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)self.imageOperationView.maxCount - (int)self.imageOperationView.srcArray.count;;
    mutilImagePicker.title = @"相册";
    [mutilImagePicker showInViewController:self animated:YES completion:nil];
    [mutilImagePicker release];
}

#pragma mark-JBoMutilImagePickerViewController代理
- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
                   {
                       if(assetArray.count > 0)
                       {
                           for(ALAsset *asset in assetArray)
                           {
                               // NSLog(@"开始2");
                               UIImage *image = [UIImage imageFromAsset:asset];
                               CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                               
                               [self.imageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
                           }
                       }
                       
                       dispatch_async(dispatch_get_main_queue(), ^(void){
                           [viewController dismissViewControllerAnimated:YES completion:^(void)
                            {
                                [self.imageOperationView updateContent];
                                self.appDelegate.dataLoadingView.hidden = YES;
                            }];
                       });
                   });
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        
        [self.imageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 self.appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
