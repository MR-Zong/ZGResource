//
//  JBoReleaseHelpMsgViewController.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

#define _releaseHelpMsgNotification_ @"releaseHelpMsgNotification"

@class SSTextView;
@class JBoIconTextView;
@class JBoImageTextLabel;

/**附近匿名发布
 */
@interface JBoReleaseHelpMsgViewController : JBoViewController<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIActionSheetDelegate,UIAlertViewDelegate>
{
    //位置详情地址
    UILabel *_addressLabel;
    
    UIActivityIndicatorView *_actView;
    SSTextView *_contentTextView;
    
    //获取位置
    UIButton *_defaultLocationButton;
    UIButton *_locationButton;
}
@end
