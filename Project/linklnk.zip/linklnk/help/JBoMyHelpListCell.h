//
//  JBoMyHelpListCell.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoImageTextLabel.h"
#import "JBoIconTextView.h"
#import "JBoMultiImageView.h"

#define _controlHeight_ 23
#define _myHelpPadding_ 5
#define _myHelpButtonHeight_ 35.0
#define _myHelpContentTextInset_ 5.0
#define _myHelpBackgroundViewPadding_ 20.0
#define _helpTableHeaderHeight_ 40.0
#define _myHelpContentFont_ [UIFont systemFontOfSize:15.0]

@class JBoMyHelpListCell;

@protocol JBoMyHelpListCellDelegate <NSObject>

@optional

/**评论
 */
- (void)myHelpListCellDidCommented:(JBoMyHelpListCell*) cell;
/**选择链接
 */
- (void)myHelpListCell:(JBoMyHelpListCell *)cell didSelectURL:(NSURL*) url;
/**选择图片
 */
- (void)myHelpListCell:(JBoMyHelpListCell *)cell didImageAtIndex:(NSInteger) index;

@end

/**我发布的附近匿名信息 列表
 */
@interface JBoMyHelpListCell : UITableViewCell

/**评论按钮 显示评论数量
 */
@property(nonatomic,readonly) UIButton *commentButton;

/**评论数量
 */
@property(nonatomic,assign) long long commentCount;

/**点赞按钮 无法点赞，只显示赞的数量
 */
@property(nonatomic,readonly) UIButton *praiseButton;

/**赞的数量
 */
@property(nonatomic,assign) long long praiseCount;

/**发布日期
 */
@property(nonatomic,readonly) UILabel *dateLabel;

//内容
@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;

/**内容高度
 */
@property(nonatomic,assign) NSInteger contentHeight;

/**图片
 */
@property(nonatomic,readonly) JBoMultiImageView *multiImageView;

/**图片高度
 */
@property(nonatomic,assign) NSInteger imageHeight;

@property(nonatomic,assign) id<JBoMyHelpListCellDelegate> delegate;

@end
