//
//  JBoHelpCommentDataObject.m
//  连客
//
//  Created by kinghe005 on 14-1-3.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoHelpCommentDataObject.h"

@implementation JBoHelpCommentInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.contentHeight = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_commentDate release];
    [_commentMsg release];
    
    [_userID release];
    [_userName release];
    [_imageURL release];
    
    [super dealloc];
}

@end

@implementation JBoHelpCommentDataObject

- (id)initWithHelpInfo:(JBoHelpCommentInfo *)commentInfo childArray:(NSMutableArray *)childArray
{
    self = [super init];
    if(self)
    {
        self.parentCommentInfo = commentInfo;
        self.childArray = childArray;
        self.loading = NO;
    }
    return self;
}

- (void)dealloc
{
    [_parentCommentInfo release];
    [_childArray release];
    
    [super dealloc];
}

@end
