//
//  JBoHelpInfo.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**附近匿名信息
 */
@interface JBoHelpInfo : NSObject

/**附近匿名Id
 */
@property(nonatomic,assign) long long helpID;

/**内容
 */
@property(nonatomic,copy) NSString *helpMsg;

/**赞的数量
 */
@property(nonatomic,assign) long long praiseCount;

/**是否已赞 0 已赞，1没赞 default is 'YES'
 */
@property(nonatomic,assign) BOOL praise;

/**发布日期
 */
@property(nonatomic,copy) NSString *helpDate;

/**内容高度 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger contentHeight;

/**评论 数组成员是 JBoCommentInfo对象
 */
@property(nonatomic,retain) NSMutableArray *commentInfoArray;
@property(nonatomic,assign) NSInteger commentCount;

/**图片路径 default is 'nil'
 */
@property(nonatomic,retain) NSArray *imageURLArray;

/**图片高度 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger imageHeight;

@end
