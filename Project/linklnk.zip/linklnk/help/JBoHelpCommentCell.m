//
//  JBoHelpCommentCell.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoHelpCommentCell.h"
#import "JBoBasic.h"
#import "JBoImageTextTool.h"
#import <QuartzCore/QuartzCore.h>

@implementation JBoHelpCommentLoadingCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, _helpCommentLoadingCellHeight_)];
        [self.contentView addSubview:_bottomLoadingView];
    }
    
    return self;
}

- (void)dealloc
{
    [_bottomLoadingView release];
    [super dealloc];
}

@end


@interface JBoHelpCommentCell ()



@end

@implementation JBoHelpCommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.contentView.backgroundColor = [UIColor whiteColor];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouch:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_helpCommentContentInterval_, _helpCommentContentInterval_, _helpCommentImageSize_, _helpCommentImageSize_)];
        _headImageView.layer.cornerRadius = 17.0;
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [tap release];
        [self.contentView addSubview:_headImageView];
        
        CGFloat width = _width_ - _headImageView.frame.origin.x - _headImageView.frame.size.width - _helpCommentContentInterval_ * 2;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _helpCommentContentInterval_, _headImageView.frame.origin.y, width / 2, _helpCommentContentHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(_nameLabel.right, _nameLabel.frame.origin.y, width / 2, _helpCommentContentHeight_)];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        _dateLabel.backgroundColor = [UIColor clearColor];
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        [self.contentView addSubview:_dateLabel];
  
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _helpCommentContentHeight_ + _helpCommentTextInset_, width , _helpCommentContentHeight_)];
        _contentLabel.recognizeURL = NO;
        _contentLabel.minLineHeight = _helpCommentContentHeight_;
        _contentLabel.font = _helpCommentFont_;
        _contentLabel.textInset = _helpCommentTextInset_;
        _contentLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_contentLabel];
    }
    return self;
}

- (void)dealloc
{
    [_contentLabel release];
    [_nameLabel release];
    [_dateLabel release];
    
    [_replyIconTextView release];
    [_headImageView release];
    
    [_helpCommentData release];
    
    [super dealloc];
}

- (void)headImageDidTouch:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(helpCommentCellDidTouchHeadImage:)])
    {
        [self.delegate helpCommentCellDidTouchHeadImage:self];
    }
}

- (void)replyAction:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(helpCommentCellDidTouchReply:)])
    {
        [self.delegate helpCommentCellDidTouchReply:self];
    }
}

- (void)setDevLevel:(NSInteger)devLevel
{
    if(_devLevel != devLevel)
    {
        _devLevel = devLevel;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    NSInteger tmp = _devLevel;
    tmp = tmp > _indentationCount_ ? _indentationCount_ : tmp;
    CGFloat padding = tmp * _indentationWidth_;
    

    _headImageView.frame = CGRectMake(padding + _helpCommentContentInterval_, _headImageView.frame.origin.y, _headImageView.frame.size.width, _headImageView.frame.size.height);
    
    CGFloat width = _width_ - _headImageView.frame.origin.x - _headImageView.frame.size.width - _helpCommentContentInterval_ * 2;
    
    _nameLabel.frame = CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _helpCommentContentInterval_, _nameLabel.frame.origin.y, width / 2, _nameLabel.frame.size.height);
    _dateLabel.frame = CGRectMake(_nameLabel.frame.origin.x + _nameLabel.frame.size.width, _nameLabel.frame.origin.y, width / 2, _dateLabel.frame.size.height);
    _contentLabel.frame = CGRectMake(_nameLabel.frame.origin.x, _contentLabel.frame.origin.y, width, self.contentHeight);
    _replyIconTextView.frame = CGRectMake(_width_ - _replyIconTextView.frame.size.width, _contentLabel.frame.origin.y + _contentLabel.frame.size.height, _replyIconTextView.frame.size.width, _replyIconTextView.frame.size.height);
    //NSLog(@"%@",_dateLabel);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
