//
//  JBoSubmitCommentView.m
//  连客
//
//  Created by kinghe005 on 13-12-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSubmitInputContentView.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoKeyboardButton.h"
#import "JBoBasic.h"

#define _blackBgViewHeight_ 50
#define _padding_ 20

@interface JBoSubmitInputContentView ()<UITextViewDelegate>


@property(nonatomic,assign) BOOL keyboardHidden;

@end

@implementation JBoSubmitInputContentView

/**构造方法
 *@param frame 视图位置大小
 *@param maxCount 文本最大输入字数
 *@return 一个视图
 */
- (id)initWithFrame:(CGRect)frame maxCommentCount:(NSInteger)maxCount
{
    return [self initWithFrame:frame maxCommentCount:maxCount style:JBoSubmitInputLimitStyleCannotInput];
}

/**构造方法
 *@param frame 视图位置大小
 *@param maxCount 文本最大输入字数
 *@param style 文本输入字数限制类型
 *@return 一个视图
 */
- (id)initWithFrame:(CGRect)frame maxCommentCount:(NSInteger)maxCount style:(JBoSubmitInputLimitStyle) style
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _style = style;
        _maxCount = maxCount;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardAppearance:) name:UIKeyboardWillShowNotification object:nil];
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameChanged:) name:UIKeyboardDidChangeFrameNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDisappearrance:) name:UIKeyboardWillHideNotification object:nil];
        
        _blackBgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, _blackBgViewHeight_)];
        _blackBgView.userInteractionEnabled = YES;
        _blackBgView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.4];
        _blackBgView.hidden = YES;
        [self addSubview:_blackBgView];
        
        _whiteBgView = [[UIView alloc] initWithFrame:CGRectMake(0, _blackBgView.frame.origin.y + _blackBgView.frame.size.height, self.frame.size.width, self.frame.size.height - _blackBgViewHeight_)];
        _whiteBgView.userInteractionEnabled = YES;
        _whiteBgView.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        [self addSubview:_whiteBgView];
        
        _newsCommentTextView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, self.frame.size.width - _padding_ * 2, 80 * _height_ / 480)];
        _newsCommentTextView.layer.cornerRadius = 6;
        _newsCommentTextView.layer.borderWidth = 0.2;
        _newsCommentTextView.layer.borderColor = [UIColor grayColor].CGColor;
        _newsCommentTextView.font = [UIFont systemFontOfSize:17];
        _newsCommentTextView.delegate = self;
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
        view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        
        CGFloat buttonWidth = 60.0;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [button setTitle:@"完成" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(finishAction:) forControlEvents:UIControlEventTouchUpInside];
        [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
        [view addSubview:button];
        
        _newsCommentTextView.inputAccessoryView = view;
        [view release];
        NSLog(@"%@",_newsCommentTextView);
        
        //_newsCommentTextView.returnKeyType = UIReturnKeyDone;
        
        switch (style)
        {
            case JBoSubmitInputLimitStyleCannotInput :
            {
                _newsCommentTextView.maxCount = maxCount;
                _newsCommentTextView.limitable = YES;
            }
                break;
            case JBoSubmitInputLimitStyleRedRemind :
            {
                if(_ios6_0_)
                {
                    _newsCommentTextView.placeholder = [NSString stringWithFormat:@"每段限%d字,超出部分以红色显示", (int)self.maxCount];
                }
                else
                {
                    _newsCommentTextView.placeholder = [NSString stringWithFormat:@"每段限%d字", (int)self.maxCount];
                }
            }
                break;
            default:
                break;
        }
        
        [_whiteBgView addSubview:_newsCommentTextView];
        
        //回收键盘
        _reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyboard:)];
        [_blackBgView addGestureRecognizer:_reconverGesture];
        
        self.keyboardHidden = YES;
    }
    return self;
}

- (void)dealloc
{
   
    [_newsCommentTextView release];
    
    [_reconverGesture release];
    [_blackBgView release];
    [_whiteBgView release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidChangeFrameNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    
    [super dealloc];
}

- (void)beginComment
{
    if(self.keyboardHidden)
    {
        [_newsCommentTextView becomeFirstResponder];
    }
    else
    {
        [_newsCommentTextView resignFirstResponder];
    }
}


//textView代理

- (void)textViewDidChange:(UITextView *)textView
{
    switch (self.style)
    {
        case JBoSubmitInputLimitStyleCannotInput :
        {
            SSTextView *sst = (SSTextView*)textView;
            int length = (int)(sst.maxCount - textView.text.length);
            sst.numLabel.text = [NSString stringWithFormat:@"%d",length < 0 ? 0 : length];
        }
            break;
        case JBoSubmitInputLimitStyleRedRemind :
        {
            NSString *text = textView.text;
            
            if(text.length > self.maxCount)
            {
                if(_ios6_0_)
                {
#ifdef __IPHONE_6_0
                    SSTextView *sst = (SSTextView*)textView;
                    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithString:text];
                    [attributedText addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(self.maxCount, text.length - self.maxCount)];
                    [attributedText addAttribute:NSFontAttributeName value:textView.font range:NSMakeRange(0, text.length)];
                    sst.attributedText = attributedText;
                    [attributedText release];
#endif
                }
                else
                {
                    textView.text = [text substringToIndex:self.maxCount];
                }
            }
        }
            break;
        default:
            break;
    }
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
//    if([text isEqualToString:@"\n"])
//    {
//        [self finishAction:nil];
//        return NO;
//    }
    
    switch (self.style)
    {
        case JBoSubmitInputLimitStyleCannotInput :
        {
            NSString *new = [textView.text stringByReplacingCharactersInRange:range withString:text];
            NSInteger res = _newsCommentTextView.maxCount - new.length;
            
            _newsCommentTextView.numLabel.text = [NSString stringWithFormat:@"%d",(int)(res < 0 ? 0 : res)];
            
            if(res > 0)
            {
                return YES;
            }
            else
            {
                NSString *str = [textView.text stringByAppendingString:text];
                NSInteger index = _newsCommentTextView.maxCount >= str.length ? str.length : _newsCommentTextView.maxCount;
                
                NSString *subStr = [str substringToIndex:index];
                textView.text = subStr;
                
                return NO;
            }
        }
            break;
        case JBoSubmitInputLimitStyleRedRemind :
        {
            return YES;
        }
            break;
        default:
        {
            return YES;
        }
            break;
    }
}



//完成
- (void)finishAction:(id)sender
{
    [_newsCommentTextView resignFirstResponder];
    
    NSString *text = _newsCommentTextView.text;
    
    if(text.length > self.maxCount)
    {
        text = [text substringToIndex:self.maxCount];
    }
    
    if([self.delegate respondsToSelector:@selector(submitDidFinished:)])
    {
        [self.delegate submitDidFinished:text];
    }
    _newsCommentTextView.text = @"";
}

//回收键盘
- (void)reconverKeyboard:(UITapGestureRecognizer*) tap
{
    [_newsCommentTextView resignFirstResponder];
}

- (void)getkeyboardHeightFromNotification:(NSNotification*) notification
{
    //获取键盘高度
    NSDictionary *dic = [notification userInfo];
//    NSValue *keyboardValue = [dic objectForKey:UIKeyboardFrameEndUserInfoKey];
//    CGRect keyboardRect = [keyboardValue CGRectValue];
    
    CGFloat height = self.keyboardHidden ? _height_ : 0;
    
    if(self.keyboardHidden)
    {
        if([self.delegate respondsToSelector:@selector(submitViewWillDismiss:)])
        {
            [self.delegate respondsToSelector:@selector(submitViewWillDismiss:)];
        }
    }
    
    NSNumber *animateDurationNumber = [dic objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    CGFloat animateDuration = [animateDurationNumber floatValue];
    
    [UIView animateWithDuration:animateDuration animations:^(void)
    {
        self.frame = CGRectMake(self.frame.origin.x, height, self.frame.size.width, self.frame.size.height);
    }completion:^(BOOL finish)
    {
        if(finish)
        {
            _blackBgView.hidden = self.keyboardHidden;
        }
    }];
}

- (void)keyboardAppearance:(NSNotification*) notification
{
    self.keyboardHidden = NO;
    _reconverGesture.enabled = YES;
    [self getkeyboardHeightFromNotification:notification];
}

//- (void)keyboardFrameChanged:(NSNotification*) notification
//{
//   // [self getkeyboardHeightFromNotification:notification];
//}

- (void)keyboardDisappearrance:(NSNotification*) notification
{
    self.keyboardHidden = YES;
    _reconverGesture.enabled = NO;
    [self getkeyboardHeightFromNotification:notification];
}

@end
