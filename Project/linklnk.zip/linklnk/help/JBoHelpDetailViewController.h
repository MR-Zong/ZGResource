//
//  JBoHelpDetailViewController.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoAroundHelpInfo;
@class JBoOfflineCacheOperation;

@interface JBoHelpDetailViewController : JBoViewController<UIScrollViewDelegate>
{
    UIView *_tableheaderView;
}

/**附近匿名信息
 */
@property(nonatomic,retain) JBoAroundHelpInfo *aroundHelpInfo;
/**发布这条匿名的用户信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

/**是否是从我的匿名中打开的
 */
@property(nonatomic,assign) BOOL isSelf;

/**是否显示评论
 */
@property(nonatomic,assign) BOOL showComment;
/**离线缓存
 */
@property(nonatomic,retain) JBoOfflineCacheOperation *offlineCache;

@end
