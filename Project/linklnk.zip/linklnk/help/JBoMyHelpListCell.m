//
//  JBoMyHelpListCell.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMyHelpListCell.h"
#import "JBoImageTextTool.h"
#import "JBoBasic.h"


@interface JBoMyHelpListCell ()<JBoImageTextLabelDelegate,JBoMultiImageViewDelegate>

@property(nonatomic,retain) UIView *bgView;

@end

@implementation JBoMyHelpListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        self.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        self.contentView.backgroundColor = self.backgroundColor;
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(_myHelpBackgroundViewPadding_, 0, _width_ - _myHelpBackgroundViewPadding_ * 2, _controlHeight_)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        [self.contentView addSubview:_dateLabel];
        
        //白色圆角背景
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(_myHelpBackgroundViewPadding_, _dateLabel.bottom, _dateLabel.width, _controlHeight_)];
        bgView.backgroundColor = [UIColor whiteColor];
        bgView.layer.cornerRadius = 5.0;
        bgView.layer.shadowColor = [UIColor blackColor].CGColor;
        bgView.layer.shadowOffset = CGSizeMake(1, 1);
        bgView.layer.shadowRadius = 2.0;
        bgView.layer.masksToBounds = YES;
        [self.contentView addSubview:bgView];
        self.bgView = bgView;
        [bgView release];
        
        
        
        CGFloat buttonWidth = 80.0;
        CGFloat buttonHeight = _myHelpButtonHeight_;
        
        _contentLabel = [[JBoImageTextLabel alloc] initWithFrame:CGRectMake(0, 0, bgView.width, bgView.height)];
        _contentLabel.textColor = [UIColor blackColor];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.delegate = self;
        _contentLabel.font = _myHelpContentFont_;
        _contentLabel.textInset = _myHelpContentTextInset_;
        [_bgView addSubview:_contentLabel];
        
        _multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectMake(5.0, _contentLabel.bottom + 10.0, _multiSize_ * _imagesPerRows_ + _multiImageInterval_ * (_imagesPerRows_ - 1), _controlHeight_)];
        _multiImageView.delegate = self;
       // _multiImageView.onlythumbnail = YES;
        [bgView addSubview:_multiImageView];
        
        _commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_commentButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        _commentButton.titleLabel.font = [UIFont systemFontOfSize:13.0];
        [_commentButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [_commentButton setImage:[UIImage imageNamed:@"helpComment_btn"] forState:UIControlStateNormal];
        [_commentButton setFrame:CGRectMake(bgView.width - buttonWidth, _multiImageView.bottom, buttonWidth, buttonHeight)];
        [_commentButton addTarget:self action:@selector(commentAction:) forControlEvents:UIControlEventTouchUpInside];
        [bgView addSubview:_commentButton];
        
        _praiseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_praiseButton setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];
        _praiseButton.titleLabel.font = [UIFont systemFontOfSize:13.0];
        _praiseButton.adjustsImageWhenDisabled = NO;
        [_praiseButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [_praiseButton setImage:[UIImage imageNamed:@"helpPraise_btn"] forState:UIControlStateNormal];
        [_praiseButton setFrame:CGRectMake(_commentButton.left - buttonWidth - _myHelpPadding_, _commentButton.top, buttonWidth, buttonHeight)];
        [_praiseButton addTarget:self action:@selector(commentAction:) forControlEvents:UIControlEventTouchUpInside];
        [bgView addSubview:_praiseButton];
        
    }
    return self;
}

- (void)setPraiseCount:(long long)praiseCount
{
    _praiseCount = praiseCount;
    [self.praiseButton setTitle:[NSString stringWithFormat:@"%lld",_praiseCount] forState:UIControlStateNormal];
}

- (void)setCommentCount:(long long)commentCount
{
    _commentCount = commentCount;
    [self.commentButton setTitle:[NSString stringWithFormat:@"%lld",_commentCount] forState:UIControlStateNormal];
}

- (void)dealloc
{
    [_bgView release];
    
    [_contentLabel release];
    [_dateLabel release];
    [_multiImageView release];
    
    [super dealloc];
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    self.contentLabel.height = self.contentHeight;
    self.multiImageView.frame =  CGRectMake(5.0, self.contentLabel.bottom + _myHelpPadding_, self.multiImageView.width, self.imageHeight);

    self.bgView.height = self.multiImageView.bottom + _commentButton.height;
    
    self.commentButton.top = self.multiImageView.bottom + _myHelpPadding_;
    self.praiseButton.top = self.commentButton.top;
}


- (void)commentAction:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(myHelpListCellDidCommented:)])
    {
        [self.delegate myHelpListCellDidCommented:self];
    }
}

- (void)imageTextLabel:(JBoImageTextLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(myHelpListCell:didSelectURL:)])
    {
        [self.delegate myHelpListCell:self didSelectURL:url];
    }
}

- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(myHelpListCell:didImageAtIndex:)])
    {
        [self.delegate myHelpListCell:self didImageAtIndex:index];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
