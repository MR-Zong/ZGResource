//
//  JBoHelpInfo.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoHelpInfo.h"

@implementation JBoHelpInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.contentHeight = NSNotFound;
        self.imageHeight = NSNotFound;
        self.commentInfoArray = [NSMutableArray array];
        self.praise = YES;
    }
    return self;
}

- (void)dealloc
{
    [_helpMsg release];
    [_commentInfoArray release];
    [_imageURLArray release];
    
    [super dealloc];
}

@end
