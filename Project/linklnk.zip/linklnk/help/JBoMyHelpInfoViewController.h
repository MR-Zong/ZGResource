//
//  JBoMyHelpInfoViewController.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoOfflineCacheOperation;
@class JBoMyHelpInfoViewController;

@protocol JBoMyHelpInfoViewControllerDelegate <NSObject>

/**删除匿名信息
 *@param infoId 匿名信息Id
 */
- (void)myHelpInfoViewController:(JBoMyHelpInfoViewController*) viewController didDeletedInfo:(long long) infoId;

@end

/**我发布的匿名信息
 */
@interface JBoMyHelpInfoViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
{
    UITableView *_tableView;
    
    /**匿名信息，数组元素是 JBoHelpInfo
     */
    NSMutableArray *_infoArray;
}

/**离线缓存
 */
@property(nonatomic,retain) JBoOfflineCacheOperation *offlineCacheOperation;
@property(nonatomic,assign) id<JBoMyHelpInfoViewControllerDelegate> delegate;


@end
