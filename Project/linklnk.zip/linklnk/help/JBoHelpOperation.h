//
//  JBoHelpOperation.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

#define _getUserHelpInfoIdentifier_ @"getUserHelpInfoIdentifier"
#define _removeUserHelpInfoIdentifier_ @"removeUserHelpInfoIdentifier"
#define _releaseHelpInfoIdentifier_ @"releaseHelpInfoIdentifier"

#define _releaseHelpCommentIdentifier_ @"releaseHelpCommentIdentifier"

#define _praiseSecretIdentifier_ @"praiseSecretIdentifier"

@class XMPPIQ;
@class JBoHelpInfo;

/**附近匿名网络操作
 */
@interface JBoHelpOperation : NSObject

#pragma mark- 获取匿名

/**根据地理位置获取匿名信息
 *@param pageNum 页码
 *@param rows 每页数量
 *@param coordinate 地理位置经纬度
 *@param radius 范围，米
 *@param lastHelpId 每页最后一条信息的id，第一页不传
 *@return get请求
 */
+ (NSString*)getAroundHelpInfoWithPageNum:(int) pageNum rows:(int) rows currentCoornidate:(CLLocationCoordinate2D) coordinate radius:(int) radius lastHelpId:(long long) lastHelpId;

/**从返回的数据获取周围匿名信息
 *@param data 返回的数据
 *@param coordinate 获取匿名时的地理位置经纬度 用于计算距离
 *@return 数组元素是 JBoAroundHelpInfo
 */
+ (NSMutableArray*)getAroundHelpInfoFromData:(NSData*) data withCurrentCoordinate:(CLLocationCoordinate2D) coordinate;

/**获取用户发布的附近匿名信息
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求 url
 */
+ (NSString*)getUserHelpInfoWithPageNum:(int) pageNum rows:(int) rows;

/**从返回的数据获取用户发布附近匿名信息
 *@param data 返回的数据
 *@return 数组元素是 JBoHelpInfo
 */
+ (NSMutableArray*)getUserHelpInfoFromData:(NSData*) data;

#pragma mark- 发布附近匿名

/**发布附近匿名 URL
 *@return post请求 url
 */
+ (NSString*)getReleaseHelpInfoURL;

/**发布附近匿名 参数
 *@param msg 内容
 *@param lat 经度
 *@param lon 纬度
 *@param addr 地址
 *@return post 请求参数
 */
+ (NSDictionary*)getReleaseHelpInfoPostDataWihtMsg:(NSString*) msg latitude:(double) lat logitude:(double) lon address:(NSString*) addr;

/**发布附近匿名是否成功
 *@param data 返回的数据
 */
+ (NSString*)isReleaseHelpInfoSuccessFromData:(NSData*) data;

#pragma mark- 附近匿名操作

/**删除匿名
 *@param helpId 匿名信息Id
 *@return get请求url
 */
+ (NSString*)removeHelpInfoWithHelpId:(long long) helpId;

/**评论匿名 url
 *@return post请求url
 */
+ (NSString*)getReleaseHelpCommentURL;

/**评论匿名 参数
 *@param msg 评论内容
 *@param parentId 回复的评论信息id，如果不是回复某个评论，传0
 *@param helpId 评论的匿名的id
 *@return post请求参数
 */
+ (NSDictionary*)getReleaseHelpCommentPostDataWithMsg:(NSString*) msg parentId:(NSString*) parentId helpId:(long long) helpId;

/**是否评论成功
 *@data 返回的数据
 */
+ (NSString*)isReleaseHelpCommentSuccessFromData:(NSData*) data;

/**点赞附近匿名 url
 *@return post请求 url
 */
+ (NSString*)getPraiseSecretURL;

/**点赞附近匿名 参数
 *@param info 要点赞的匿名信息
 *@return post请求 参数
 */
+ (NSDictionary*)getPraiseSecretParaWithInfo:(JBoHelpInfo*) info;

@end
