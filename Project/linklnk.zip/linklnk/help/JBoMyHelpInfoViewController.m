//
//  JBoMyHelpInfoViewController.m
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoMyHelpInfoViewController.h"
#import "JBoAppDelegate.h"
#import "JBoReleaseHelpMsgViewController.h"
#import "JBoHelpInfo.h"
#import "JBoHelpOperation.h"
#import "JBoBottomLoadingView.h"
#import "JBoImageTextTool.h"
#import "JBoMyHelpListCell.h"
#import "UITableView+extraCellLine.h"
#import "JBoAroundHelpViewController.h"
#import "JBoHelpDetailViewController.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoCircleBgViewController.h"
#import "JBoUserTableHeaderView.h"
#import "JBoUserOperation.h"
#import "JBoOfflineCacheOperation.h"
#import "JBoWebViewController.h"
#import "JBoImageCacheTool.h"
#import "JBoReuseScrollView.h"
#import "JBoReuseScrollInfo.h"

@interface JBoMyHelpInfoViewController ()<UIActionSheetDelegate, JBoMyHelpListCellDelegate, JBoHttpRequestDelegate,JBoUserTableHeaderViewDelegate,JBoReuseScrollViewDelegate>
{
    JBoBottomLoadingView *_bottomLoadingView;
    
    BOOL _hasInfo;
    
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,assign) BOOL isRequesting;

@property(nonatomic,assign) int pageIndex;

@property(nonatomic,assign) NSInteger currentIndex;

//计算内容高度
@property(nonatomic,retain) JBoImageTextLabel *caculateHeight;

//查看大图
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;
@property(nonatomic,retain) NSMutableArray *imageArray;

@end

@implementation JBoMyHelpInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = [NSString stringWithFormat:@"我的%@", _helpName_];
        
        _infoArray = [[NSMutableArray alloc] init];
        
        _hasInfo = YES;
        self.isRequesting = NO;
        
        self.pageIndex = 1;
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.caculateHeight = [[[JBoImageTextLabel alloc] init] autorelease];
        self.caculateHeight.textInset = _myHelpContentTextInset_;
        self.caculateHeight.font = _myHelpContentFont_;

    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        if(!_isRequesting)
        {
            self.appDelegate.dataLoadingView.hidden = !_isRequesting;
            _tableView.tableFooterView = nil;
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
        }
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoMyHelpInfoViewController dealloc");
    [_tableView release];
    [_infoArray release];
    
    [_offlineCacheOperation release];
    
    [_httpRequest release];
    
    
    [_caculateHeight release];
    
    [_imageScrollView release];
    [_imageArray release];

    [super dealloc];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_removeUserHelpInfoIdentifier_])
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"删除失败"];
        return;
    }
    
    if([identifier isEqualToString:_getUserHelpInfoIdentifier_])
    {
        if(_infoArray.count != 0)
        {
            [JBoUserOperation alertmsgWithBadNetwork:[NSString stringWithFormat:@"获取我的%@失败", _helpName_]];
        }
        else
        {
            [self getSecret];
        }
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([identifier isEqualToString:_getUserHelpInfoIdentifier_])
    {
        NSArray *array = [JBoHelpOperation getUserHelpInfoFromData:data];
        
        [self saveSecretWithArray:array];
        [_infoArray addObjectsFromArray:array];
        if(array.count < _helpPageSize_)
            _hasInfo = NO;
        if(!_tableView)
        {
            [self loadInitView];
        }
        [_tableView reloadData];
        
        return;
    }
    
    if([identifier isEqualToString:_removeUserHelpInfoIdentifier_])
    {
        BOOL success = [JBoUserOperation isSuccess:data];
        if(success)
        {
            if(self.currentIndex < _infoArray.count)
            {
                if([self.delegate respondsToSelector:@selector(myHelpInfoViewController:didDeletedInfo:)])
                {
                    JBoHelpInfo *info = [_infoArray objectAtIndex:self.currentIndex];
                    [self.delegate myHelpInfoViewController:self didDeletedInfo:info.helpID];
                }
                
                [_infoArray removeObjectAtIndex:self.currentIndex];
                [_tableView beginUpdates];
                [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:self.currentIndex inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
                [_tableView endUpdates];
            }
        }
        else
        {
            [JBoUserOperation alertmsgWithBadNetwork:@"删除失败"];
        }
        return;
    }
}

#pragma mark- 视图消失出西安

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if(!_tableView)
    {
        if(self.appDelegate.previousWorkStatus != NotReachable)
        {
            [self loadInfo:NO];
        }
        else
        {
            [self getSecret];
        }
    }
    else
    {
        if(self.currentIndex < _infoArray.count)
        {
            JBoHelpInfo *info = [_infoArray objectAtIndex:self.currentIndex];
            info.commentCount = info.commentInfoArray.count;
            [_tableView reloadData];
        }
    }
}

#pragma mark- 数据库操作

- (void)getSecret
{
    self.appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        [_offlineCacheOperation getMySecretWithArray:_infoArray];
        dispatch_async(dispatch_get_main_queue(), ^(void){
            self.appDelegate.dataLoadingView.hidden = YES;
            [_tableView reloadData];
        });
    });
}

- (void)saveSecretWithArray:(NSArray*) secretArray
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        for(JBoAroundHelpInfo *info in secretArray)
        {
            [_offlineCacheOperation removeSecretWithId:info.helpID isSelf:YES];
            [_offlineCacheOperation insertMySecret:info];
        }
    });
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setBackItem:YES];
}

- (void)loadInitView
{
    JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getUserDetailInfo];
   
    
    JBoUserTableHeaderView *tableHeaderView = [[JBoUserTableHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _tableHeaderViewHeight_)];
    
    if(userDetailInfo.rosterInfo.image)
    {
        tableHeaderView.headImageView.imageView.image = userDetailInfo.rosterInfo.image;
    }
    else
    {
        tableHeaderView.headImageView.sex = userDetailInfo.rosterInfo.sex;
    }
    
    tableHeaderView.headImageView.role = userDetailInfo.rosterInfo.role;
    tableHeaderView.bgImageView.userId = userDetailInfo.rosterInfo.username;
    tableHeaderView.nameLabel.text = userDetailInfo.rosterInfo.name;
    tableHeaderView.delegate = self;
    tableHeaderView.nameLabel.sex = userDetailInfo.rosterInfo.sex;
    tableHeaderView.backgroundColor = [UIColor clearColor];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.tableHeaderView = tableHeaderView;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [tableHeaderView release];
    _tableView.backgroundColor = [UIColor colorWithRed:238.0 / 255.0 green:238.0 / 255.0 blue:238.0 / 255.0 alpha:1.0];
    [self.view addSubview:_tableView];
    
    [_tableView setExtraCellLineHidden];
}

- (void)loadInfo:(BOOL) hidden
{
    if(self.isRequesting)
        return;
    _httpRequest.identifier = _getUserHelpInfoIdentifier_;
    self.isRequesting = YES;
    self.appDelegate.dataLoadingView.hidden = hidden;
    [_httpRequest downloadWithURL:[JBoHelpOperation getUserHelpInfoWithPageNum:self.pageIndex rows:_helpPageSize_]];
}

- (void)tableHeaderView:(JBoUserTableHeaderView*)tableHeaderView bgImageDidTapped:(UIView *)view
{
    JBoCircleBgViewController *circleBgVC = [[JBoCircleBgViewController alloc] init];
    circleBgVC.black = self.black;
    [self.navigationController pushViewController:circleBgVC animated:YES];
    [circleBgVC release];
}

#pragma mark-JBoMyHelpTableHeaderView代理

- (void)rightViewDidTouched
{
    JBoAroundHelpViewController *aroundHelpVC = [[JBoAroundHelpViewController alloc] init];
    [self.navigationController pushViewController:aroundHelpVC animated:YES];
    [aroundHelpVC release];
}

#pragma mark-tableView代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
    if(info.contentHeight == NSNotFound)
    {
        CGSize size = [JBoImageTextTool getHeightFromAttributedText:[self.caculateHeight getAttributedTextFromString:info.helpMsg] contraintWidth:(_width_ - _myHelpBackgroundViewPadding_ * 2 - _myHelpContentTextInset_ * 2)];
        info.contentHeight = size.height + 5.0 + _myHelpContentTextInset_ * 2;
        
        info.imageHeight = [JBoMultiImageView getHeightWithCount:info.imageURLArray.count];
    }
    
    
    CGFloat height = info.contentHeight + _controlHeight_ * 2 + _myHelpButtonHeight_ + info.imageHeight + _myHelpPadding_ * 2;
    
    return height;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoMyHelpListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoMyHelpListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoHelpInfo *info = [_infoArray objectAtIndex:indexPath.row];
  
    cell.contentHeight = info.contentHeight;
    cell.dateLabel.text = info.helpDate;
    cell.contentLabel.text = info.helpMsg;
    
    cell.commentCount = info.commentCount;
    
    cell.praiseCount = info.praiseCount;
    
    cell.imageHeight = info.imageHeight;
    
    cell.multiImageView.images = info.imageURLArray;
 
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.isRequesting)
        return;
    self.currentIndex = indexPath.row;
    
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"要删除这条信息？" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"删除", nil];
    actionSheet.destructiveButtonIndex = 0;
    [actionSheet showInView:self.view];
    [actionSheet release];
}

#pragma mark-JBoMyHelpListCell代理

- (void)myHelpListCellDidCommented:(JBoMyHelpListCell *)cell
{
    self.currentIndex = [_tableView indexPathForCell:cell].row;
    JBoHelpInfo *info = [_infoArray objectAtIndex:self.currentIndex];

    JBoHelpDetailViewController *helpDetailVC = [[JBoHelpDetailViewController alloc] init];
    helpDetailVC.isSelf = YES;
    helpDetailVC.offlineCache = _offlineCacheOperation;
    JBoAroundHelpInfo *helpInfo = [[JBoAroundHelpInfo alloc] init];
    helpInfo.helpID = info.helpID;
    helpInfo.helpMsg = info.helpMsg;
    helpInfo.helpDate = info.helpDate;
    helpInfo.commentInfoArray = info.commentInfoArray;
    
    helpDetailVC.aroundHelpInfo = helpInfo;
    [helpInfo release];
    [self.navigationController pushViewController:helpDetailVC animated:YES];
    [helpDetailVC release];
}

- (void)myHelpListCell:(JBoMyHelpListCell *)cell didSelectURL:(NSURL *)url
{
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.black = self.black;
    web.URL = url;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

- (void)myHelpListCell:(JBoMyHelpListCell *)cell didImageAtIndex:(NSInteger)index
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    NSInteger currentIndex = 0;
    
    NSMutableArray *urlArray = [[NSMutableArray alloc] init];
    for(NSInteger i = 0;i < _infoArray.count;i ++)
    {
        JBoHelpInfo *info = [_infoArray objectAtIndex:i];
        
        CGFloat titleHeight = [JBoReuseScrollInfo getHeightWithContent:info.helpMsg];
        
        for(NSString *url in info.imageURLArray)
        {
            JBoReuseScrollInfo *bigInfo = [[JBoReuseScrollInfo alloc] init];
            bigInfo.msgId = info.helpID;
            bigInfo.title = info.helpMsg;
            bigInfo.titleHeight = titleHeight;
            bigInfo.url = url;
            
            [urlArray addObject:bigInfo];
            [bigInfo release];
        }
        
        if(i < indexPath.row)
        {
            currentIndex += info.imageURLArray.count;
        }
        
        if(i == indexPath.row)
        {
            currentIndex += index;
        }
    }
    
    self.imageArray = urlArray;
    [urlArray release];
    
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = currentIndex;
    [self.imageScrollView reloadData];
    
    [self.imageScrollView showInViewController:self];
}

#pragma mark-reuseScrollView代理

- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.imageArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    JBoReuseScrollInfo *info = [self.imageArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    
    cell.titleLabel.text = info.title;
    cell.titleLabel.frame = CGRectMake(0, _height_ - info.titleHeight, _width_, info.titleHeight);
    scrollView.titleLabel.text = info.title;
    
    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:info.url forIndex:index];
        }
    }
    
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    JBoReuseScrollInfo *info = [self.imageArray objectAtIndex:index];
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:info.url thumbnailSize:CGSizeZero];
    if(!image)
    {
        [self downloadImageWithUrl:info.url forIndex:index];
    }
}

- (BOOL)resuseScrollView:(JBoReuseScrollView *)scrollView isSameTitleAtIndex:(NSInteger)index withOtherIndex:(NSInteger)otherIndex
{
    if(otherIndex < 0 || otherIndex >= self.imageArray.count || index < 0 || index >= self.imageArray.count)
    {
        return YES;
    }
    
    JBoReuseScrollInfo *info = [self.imageArray objectAtIndex:index];
    JBoReuseScrollInfo *otherInfo = [self.imageArray objectAtIndex:otherIndex];
    
    return info.msgId == otherInfo.msgId;
}

- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    self.imageArray = nil;
    [_tableView reloadData];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;
    
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.imageScrollView cellForIndex:index];
    
        cell.imageView.image = image;
        [self.imageScrollView reloadDataAtIndex:index];
    }];
}


#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    JBoHelpInfo *info = [_infoArray objectAtIndex:self.currentIndex];
    switch (buttonIndex)
    {
        case 0 :
        {
            _httpRequest.identifier = _removeUserHelpInfoIdentifier_;
            [_httpRequest startNetwork];
            if([_httpRequest downloadWithURL:[JBoHelpOperation removeHelpInfoWithHelpId:info.helpID]])
            {
                self.isRequesting = YES;
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark- scrollView代理


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!_bottomLoadingView)
        {
            //创建加载更多视图
            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
        }
        if(!self.isRequesting && _hasInfo)
        {
            self.pageIndex ++;
            _tableView.tableFooterView = _bottomLoadingView;
            [self loadInfo:YES];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

@end
