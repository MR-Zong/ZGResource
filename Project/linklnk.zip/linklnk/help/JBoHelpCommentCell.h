//
//  JBoHelpCommentCell.h
//  连客
//
//  Created by kinghe005 on 14-1-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserHeadImageView.h"
#import "JBoIconTextView.h"
#import "JBoHelpCommentDataObject.h"
#import "JBoBottomLoadingView.h"
#import "JBoUserNameLabel.h"
#import "JBoImageTextLabel.h"

#define _helpCommentContentHeight_ 20
#define _helpCommentContentInterval_ 10
#define _helpCommentImageSize_ 35.0
#define _indentationCount_ 2
#define _indentationWidth_ 10
#define _helpCommentLoadingCellHeight_ 50

#define _helpCommentMinLineHeight_ 18.0
#define _helpCommentFont_ [UIFont systemFontOfSize:13.0]
#define _helpCommentTextInset_ 2.0

@interface JBoHelpCommentLoadingCell : UITableViewCell

@property(nonatomic,readonly) JBoBottomLoadingView *bottomLoadingView;

@end

@class JBoHelpCommentCell;

@protocol JBoHelpCommentCellDelegate <NSObject>

@optional

- (void)helpCommentCellDidTouchReply:(JBoHelpCommentCell*) cell;
- (void)helpCommentCellDidTouchHeadImage:(JBoHelpCommentCell*) cell;

@end

@interface JBoHelpCommentCell : UITableViewCell


@property(nonatomic,readonly) JBoImageTextLabel *contentLabel;
@property(nonatomic,assign) CGFloat contentHeight;

@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;
@property(nonatomic,readonly) UILabel *dateLabel;

@property(nonatomic,readonly) JBoIconTextView *replyIconTextView;

//cell深度
@property(nonatomic,assign) NSInteger devLevel;

@property(nonatomic,assign) id<JBoHelpCommentCellDelegate> delegate;


@property(nonatomic,retain) JBoHelpCommentDataObject *helpCommentData;

@end
