//
//  JBoSubmitCommentView.h
//  连客
//
//  Created by kinghe005 on 13-12-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SSTextView.h"

@class JBoSubmitInputContentView;

//输入文本限制类型
typedef enum _JBoSubmitInputLimitStyle
{
    JBoSubmitInputLimitStyleCannotInput = 0, //当字数足够时无法输入
    JBoSubmitInputLimitStyleRedRemind = 1 //多出部分红色显示，只支持ios6.0以上
}JBoSubmitInputLimitStyle;

@protocol JBoSubmitInputContentViewDelegate <NSObject>

/**信息输入完成
 */
- (void)submitDidFinished:(NSString*) content;

/**取消输入信息
 */
- (void)submitViewWillDismiss:(JBoSubmitInputContentView*) view;

@end



@interface JBoSubmitInputContentView : UIView
{
    //回收键盘
    UITapGestureRecognizer *_reconverGesture;

    UIView *_blackBgView;
    UIView *_whiteBgView;
}

@property(nonatomic,assign) id<JBoSubmitInputContentViewDelegate> delegate;
@property(nonatomic,readonly) SSTextView *newsCommentTextView;

/**文本限制类型 default is 'JBoSubmitInputLimitStyleCannotInput'
 */
@property(nonatomic,readonly) JBoSubmitInputLimitStyle style;

/**文本最大字数
 */
@property(nonatomic,readonly) NSInteger maxCount;

/**构造方法
 *@param frame 视图位置大小
 *@param maxCount 文本最大输入字数
 *@return 一个视图
 */
- (id)initWithFrame:(CGRect)frame maxCommentCount:(NSInteger) maxCount;

/**构造方法
 *@param frame 视图位置大小
 *@param maxCount 文本最大输入字数
 *@param style 文本输入字数限制类型
 *@return 一个视图
 */
- (id)initWithFrame:(CGRect)frame maxCommentCount:(NSInteger)maxCount style:(JBoSubmitInputLimitStyle) style;

/**开始输入文字 视图显示
 */
- (void)beginComment;

@end
