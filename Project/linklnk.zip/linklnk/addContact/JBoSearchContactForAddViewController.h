//
//  KingHeSearchContactForAddViewController.h
//  微喂
//
//  Created by kinghe005 on 13-9-14.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLookAndTellViewController.h"
#import "JBoUserDetailInfo.h"
#import "JBoRosterInfoDelegate.h"

#define _removeBlacklistNotification_ @"removeBlacklistNotification"
#define _agreeAddContactNotification_ @"agreeAddContactNotification"

/**操作类型 ,不同的操作类型 底部工具条的功能不同
 */
typedef NS_ENUM(NSInteger, JBoUserOperationType)
{
    JBoUserOperationTypeAddContact = 1,//添加好友
    JBoUserOperationTypeRemoveBlacklist = 2, //移出黑名单
    JBoUserOperationTypeLocalAddress = 4 //可添加到本地通讯录
};

@class JBoUserHeadImageView;

/**搜索用户的详情信息,可添加好友
 */
@interface JBoSearchContactForAddViewController : JBoLookAndTellViewController<UIAlertViewDelegate,UITableViewDataSource,UITableViewDelegate>

/**要查看的用户信息
 */
@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;

/**要查看的用户的 userId
 */
@property(nonatomic,copy) NSString *userId;

/**要查看的用户的账号
 */
@property(nonatomic,copy) NSString *email;

/**操作类型
 */
@property(nonatomic,assign) JBoUserOperationType operationType;

/**是否是扫描二维码出来的
 */
@property(nonatomic,assign) BOOL scanning;

/**对用户信息的操作类型
 */
@property(nonatomic,assign) JBoRosterOperationType type;

/** JBoRosterInfoDelegate 类型的代理
 */
@property(nonatomic,assign) id delegate;

@end
