//
//  JBoLocalAddressBookCell.h
//  连你
//
//  Created by kinghe005 on 14-1-23.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _localAddressBookCellHeight_ 60

/**本地通讯录信息类型
 */
typedef NS_ENUM(NSInteger, JBoLocalAddressBookType)
{
    JBoLocalAddressBookTypeExist = 0, //已注册
    JBoLocalAddressBookTypeNo = 1, //不存在
    JBoLocalAddressBookTypeContact //已是好友
};

/**本地通讯录信息
 */
@interface JBoLocalAddressBookInfo : NSObject

/**名称
 */
@property(nonatomic,copy) NSString *name;

/**手机号
 */
@property(nonatomic,copy) NSString *phoneNum;

/**本地通讯录信息类型
 */
@property(nonatomic,assign) JBoLocalAddressBookType type;

@end

/**本地通讯录列表cell
 */
@interface JBoLocalAddressBookCell : UITableViewCell

/**名称
 */
@property(nonatomic,readonly) UILabel *nameLabel;

/**手机号
 */
@property(nonatomic,readonly) UILabel *phoneNumLabel;

/**类型
 */
@property(nonatomic,readonly) UILabel *typeLabel;

/**箭头
 */
@property(nonatomic,readonly) UIImageView *arrowImageView;

@end
