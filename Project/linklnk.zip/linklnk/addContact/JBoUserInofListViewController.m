//
//  JBoUserInofListViewController.m
//  连你
//
//  Created by kinghe005 on 14-2-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoUserInofListViewController.h"
#import "JBoUserInfoListCell.h"
#import "JBoUserOperation.h"
#import "JBoUserDetailInfo.h"
#import "JBoSearchContactForAddViewController.h"


@interface JBoUserInofListViewController ()


@end

@implementation JBoUserInofListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"搜昵称";
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_infoArray release];
    
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [super initialization];
    self.tableView.rowHeight = _UserInfoListCellHeight_;
    [self.tableView setExtraCellLineHidden];
    
    self.backItem = YES;
}


#pragma mark- tableVUITableViewiew delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoUserInfoListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoUserInfoListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    JBoUserDetailInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    cell.nameLabel.text = info.rosterInfo.name;
    cell.nameLabel.sex = info.rosterInfo.sex;
    cell.headImageView.role = info.rosterInfo.role;
    
    [cell setPresence:info.rosterInfo.presence];
    cell.headImageView.sex = info.rosterInfo.sex;
    cell.headImageView.headImageURL = info.rosterInfo.imageURL;
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    JBoUserDetailInfo *info = [_infoArray objectAtIndex:indexPath.row];
    JBoSearchContactForAddViewController *searchVC = [[JBoSearchContactForAddViewController alloc] init];
    searchVC.black = self.black;
    searchVC.userDetailInfo = info;
    [self.navigationController pushViewController:searchVC animated:YES];
    [searchVC release];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
