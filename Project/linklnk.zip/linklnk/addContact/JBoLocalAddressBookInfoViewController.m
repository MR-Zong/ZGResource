//
//  KingHeLocalAddressBookInfoViewController.m
//  微喂
//
//  Created by kinghe005 on 13-8-23.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoLocalAddressBookInfoViewController.h"
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>
#import <QuartzCore/QuartzCore.h>
#import "JBoLettersSearchBar.h"
#import "ChineseToPinyin.h"
#import "JBoCheckInputText.h"
#import "JBoLocalAddresBookSearchViewController.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoRosterCell.h"
#import "JBoLocalAddressBookCell.h"

#define _sectionHeaderHeight_ 20
#define _searchBarHeight_ 40
#define _contactName_ @"name"
#define _contactPhoneNum_ @"phone"

@interface JBoLocalAddressBookInfoViewController ()<JBoHttpRequestDelegate>
{
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) NSArray *existArray;

@end

@implementation JBoLocalAddressBookInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"手机通讯录";
        _isAbleToAccess = NO;
        _isDidSearch = NO;
        
        _keywordArray = [[NSMutableArray alloc] init];
        _infoDic = [[NSMutableDictionary alloc] init];
        _searchResultArray = [[NSMutableArray alloc] init];
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.isNeedToCallOut = NO;
    }
    return self;
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoLocalAddressBookInfoViewController");
    [_tableView release];
    [_lettersView release];
    [_searchBar release];
    
    [_infoDic release];
    [_keywordArray release];
    [_searchResultArray release];
    
    [_callOutWebView release];
    [_httpRequest release];
    [_existArray release];
    [_transparentView release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [_searchBar resignFirstResponder];
}


#pragma mark-htppRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    self.existArray = [JBoUserOperation getLocalAddressBookVerifyFromData:data];
    if(self.existArray)
    {
        for(NSString *str in _keywordArray)
        {
            NSArray *array = [_infoDic objectForKey:str];
            for(JBoLocalAddressBookInfo *info in array)
            {
                if([self.existArray containsObject:info.phoneNum] && info.type != JBoLocalAddressBookTypeContact)
                {
                    info.type = JBoLocalAddressBookTypeExist;
                }
                else
                {
                    info.type = JBoLocalAddressBookTypeNo;
                }
            }
        }
        
        [_tableView reloadData];
    }
}

#pragma mark-加载视图


- (void)closeAddressBookAction:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if(self.isNeedToCallOut)
    {
        [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(closeAddressBookAction:) title:@"取消" backgroundImage:nil textColor:[UIColor whiteColor]];
        [JBoNavigatioinBarOperation setDefaultNavigationBar:self.navigationController.navigationBar];
    }
    else
    {
        //自己定义返回按钮
        self.backItem = YES;
    }
    
    ABAddressBookRef addressBook = nil;
    
    //判断当前设备系统的版本 IOS6以后的通讯录要授权才能操作
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        if(ABAddressBookGetAuthorizationStatus() != kABAuthorizationStatusAuthorized)
        {
            addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
            //等待同意后向下执行
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            NSLog(@"请求访问通讯录");
            ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error)
                                                     {
                                                         dispatch_semaphore_signal(sema);
                                                         _isAbleToAccess = granted;
                                                         [self getInfoFromLocalAddressBook:addressBook];
                                                         NSLog(@"请求访问通讯录 - %d",granted);
                                                     });
            
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
            dispatch_release(sema);
        }
        else
        {
            addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
            _isAbleToAccess = YES;
            [self getInfoFromLocalAddressBook:addressBook];
            CFRelease(addressBook);
        }
#endif
    }
    else
    {
        addressBook = ABAddressBookCreate();
        _isAbleToAccess = YES;
        [self getInfoFromLocalAddressBook:addressBook];
        CFRelease(addressBook);
    }
    
    if(_isAbleToAccess)
    {
        if(!_keywordArray.count)
        {
            self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 0, _width_ - 20.0, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
            [label setTextAlign:JBoTextAlignmentCenter];
            label.backgroundColor = [UIColor clearColor];
            label.text = _alerMsgWhenAddressBookIsEmpty_;
            [self.view addSubview:label];
            [label release];
            return;
        }
        [self loadInitView];
    }
    else
    {
        self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10.0, 0, _width_ - 20.0, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
        [label setTextAlign:JBoTextAlignmentCenter];
        label.backgroundColor = [UIColor clearColor];
        label.numberOfLines = 0;
        label.text = _alerMagWhenCannotAccessAddressBook_;
        [self.view addSubview:label];
        [label release];
    }
    
    if(!self.isNeedToCallOut)
    {
        if(_isAbleToAccess && _keywordArray.count > 0)
        {
            NSMutableArray *phoneArray = [[NSMutableArray alloc] init];
            for(NSString *str in _keywordArray)
            {
                NSArray *array = [_infoDic objectForKey:str];
                for(JBoLocalAddressBookInfo *info in array)
                {
                    [phoneArray addObject:[NSString stringWithFormat:@"'%@'",info.phoneNum]];
                }
            }
            
            if([_httpRequest downloadWithURL:[JBoUserOperation getLocalAddressBookVerifyURL] dic:[JBoUserOperation getLocalAddressBookVerifyPostData:phoneArray]])
            {
                self.isRequesting = YES;
            }
            [phoneArray release];
        }
    }
    else
    {
        [self loadInitView];
    }
}


//加载视图
- (void)loadInitView
{
    //修改导航条背景颜色
    
    //创建tableview
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _statuBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
    
    //创建搜索视图
    _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, _width_, _searchBarHeight_)];
    _searchBar.placeholder = @"搜索";
    if(!_ios7_0_)
    {
        _searchBar.tintColor = _searchBarColor_;
    }
    _searchBar.delegate = self;
    _tableView.tableHeaderView = _searchBar;
    
    //创建通讯录字母搜索视图
    _lettersView = [[JBoLettersSearchBar alloc] initWithFrame:CGRectMake(_width_ - _letterViewWidth_, 0, _letterViewWidth_, _height_ - _statuBarHeight_ - _navgateBarHeight_)];
    [_lettersView addTarget:self action:@selector(letterTouchedAction)];
    [self.view addSubview:_lettersView];;
}

#pragma mark-通讯录操作
//获取手机上的通信录信息
- (void)getInfoFromLocalAddressBook:(ABAddressBookRef) addressBook
{
    NSLog(@"获取通讯录信息 - %d",_isAbleToAccess);
    if(_isAbleToAccess)
    {
        //程序内部通讯录信息，用来过滤信息
        NSArray *filterPhoneNumberArray = [self.appDelegate.rosterAndUsernameDic allKeys];
        //获取所有联系人
        CFArrayRef allContactsArrayRef =  ABAddressBookCopyArrayOfAllPeople(addressBook);
        //获取联系人的数量
        CFIndex numberOfContacts = ABAddressBookGetPersonCount(addressBook);
        
        NSLog(@"联系人数量%ld",numberOfContacts);
        
        for(int i = 0;i < numberOfContacts;i++)
        {
            //获取通信录中的一条记录
            NSString *name = nil;
            ABRecordRef recordRef = CFArrayGetValueAtIndex(allContactsArrayRef, i);
            
            //获取联系人姓名
            if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease]  && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease] == nil)
            {
                name = [(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease];
            }
            else if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease] == nil && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease])
            {
                name = [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease];
            }
            else if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease] && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease])
            {
                name = [NSString stringWithFormat:@"%@%@",[(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease],[(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease]];
            }
            
            if([NSString isEmpty:name])
            {
                name = [(NSString*)ABRecordCopyCompositeName(recordRef) autorelease];
            }
            
            if(!name)
                name = @"无名字";
            
            //从电话号码信息里获取手机号码
            NSMutableArray *infoArray = [[NSMutableArray alloc] init];
         
            //获取个人信息中的电话号码信息数组
            ABMutableMultiValueRef phoneNumberRef = ABRecordCopyValue(recordRef, kABPersonPhoneProperty);
            
            if(phoneNumberRef != nil && ABMultiValueGetCount(phoneNumberRef) > 0)
            {
                for(int i = 0;i < ABMultiValueGetCount(phoneNumberRef);i++)
                {
                    NSString *mobileNumber = [(NSString*)ABMultiValueCopyValueAtIndex(phoneNumberRef, i) autorelease];
                    if(mobileNumber)
                    {
                        NSString *phoneNum = [self phoneNumFromString:mobileNumber];
                        if([JBoCheckInputText isMobileNumber:phoneNum])
                        {
                            JBoLocalAddressBookInfo *info = [[JBoLocalAddressBookInfo alloc] init];
                            
                            info.name = name;
                            info.phoneNum = phoneNum;
                            if([filterPhoneNumberArray containsObject:phoneNum])
                            {
                                info.type = JBoLocalAddressBookTypeContact;
                            }
                            
                            [infoArray addObject:info];
                            [info release];
                        }
                    }
                    else
                    {
                        continue;
                    }
                    //NSLog(@"_$!<Main>!$_%@",mobileNumber);
                }
            }
            
            if(phoneNumberRef != NULL)
            {
                CFRelease(phoneNumberRef);
            }
            
            if(infoArray.count == 0)
            {
                [infoArray release];
                continue;
            }
            
            NSString *keyword = [NSString stringWithFormat:@"%c",[ChineseToPinyin sortSectionTitle:name]];
            if(![_keywordArray containsObject:keyword])
            {
                [_keywordArray addObject:keyword];
                [_infoDic setObject:infoArray forKey:keyword];
            }
            else
            {
                NSMutableArray *phoneArray = [_infoDic objectForKey:keyword];
                
                if(phoneArray == nil)
                {
                    phoneArray = [NSMutableArray array];
                    [_infoDic setObject:phoneArray forKey:keyword];
                }
   
                [phoneArray addObjectsFromArray:infoArray];
                
            }
            
            [infoArray release];
        }
        CFRelease(allContactsArrayRef);
    }
    else
    {
        NSLog(@"通讯录不能访问");
        return;
    }
    
    //给通讯录关键字排序
    for(int i = 0;i < _keywordArray.count;i++)
    {
        for(int j = i + 1;j < _keywordArray.count;j++)
        {
            if([[_keywordArray objectAtIndex:i] characterAtIndex:0] > [[_keywordArray objectAtIndex:j] characterAtIndex:0])
            {
                 NSString *temp = [_keywordArray objectAtIndex:i];
                [_keywordArray replaceObjectAtIndex:i withObject:[_keywordArray objectAtIndex:j]];
                [_keywordArray replaceObjectAtIndex:j withObject:temp];
            }
        }
    }
    if(_keywordArray.count > 0)
    {
        if([[_keywordArray objectAtIndex:0] isEqualToString:@"#"])
        {
            [_keywordArray removeObjectAtIndex:0];
            [_keywordArray addObject:@"#"];
        }
    }
    
}

#pragma mark-私有方法

//把字符串转换成手机号码
- (NSString*)phoneNumFromString:(NSString*) str
{
    NSString *phoneNum = nil;
    if(str)
    {
        phoneNum = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
    }
    return phoneNum;
}


//字母选择
- (void)letterTouchedAction
{
    NSString *letter = _lettersView.touchLetter;
    if([_keywordArray containsObject:letter])
    {
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:[_keywordArray indexOfObject:letter]];
        [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

#pragma mark-searchBar代理

#ifdef __IPHONE_7_0
//搜索时用
- (UIBarPosition)positionForBar:(id<UIBarPositioning>)bar
{
    return UIBarPositionTopAttached;
}
#endif

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    _isDidSearch = YES;
    if(!_transparentView)
    {
        CGFloat y = _ios7_0_ ? _statuBarHeight_ + _searchBarHeight_ : _searchBarHeight_;

        _transparentView = [[UIView alloc] initWithFrame:CGRectMake(0, y, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(searchBarCancelButtonClicked:)];
        [_transparentView addGestureRecognizer:tap];
        _transparentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
        [self.view addSubview:_transparentView];
        [tap release];
    }
    _transparentView.hidden = NO;
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    _lettersView.hidden = YES;
    [_searchBar setShowsCancelButton:YES animated:YES];
    [_tableView reloadData];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    _isDidSearch = NO;
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    _transparentView.hidden = YES;
    _lettersView.hidden = NO;
    [_searchBar setShowsCancelButton:NO animated:YES];
    [_tableView reloadData];
}

//取消搜索方法
- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    _searchBar.text = @"";
    [_searchBar resignFirstResponder];
}

//搜索方法
- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    NSString *content = _searchBar.text;
    if(content.length <= 0)
    {
        return;
    }
    else
    {
        NSString *pinyin = [ChineseToPinyin pinyinFromChiniseString:content];
        char c = [ChineseToPinyin sortSectionTitle:content];
        if(c > 'a' && c < 'z')
            c = c - 32;
        
        NSArray *array = [_infoDic objectForKey:[NSString stringWithFormat:@"%c",c]];
        
        if(array)
        {
            [_searchResultArray removeAllObjects];
            
            for(JBoLocalAddressBookInfo *rosterInfo in array)
            {
                NSString *name = [ChineseToPinyin pinyinFromChiniseString:rosterInfo.name];
                NSLog(@"%@",name);
                if(name.length < pinyin.length)
                {
                    continue;
                }
                
                NSString *subStr = [name substringWithRange:NSMakeRange(0, pinyin.length)];
                NSLog(@"sub = %@",subStr);
                if([pinyin isEqualToString:subStr])
                {
                    [_searchResultArray addObject:rosterInfo];
                }
            }
        }
        
        
        for(NSString *str in _keywordArray)
        {
            NSArray *infos = [_infoDic objectForKey:str];
            
            for(JBoLocalAddressBookInfo *info in infos)
            {
                NSRange range = [info.name rangeOfString:content];
                
                if(range.length > 0 && (![_searchResultArray containsObject:info]))
                {
                    [_searchResultArray addObject:info];
                }
            }
        }
    }
    
    if(_searchResultArray.count > 0)
    {
        _transparentView.hidden = YES;
    }
    else
    {
        _transparentView.hidden = NO;
    }

    [_tableView reloadData];
}

#pragma mark-tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if(_isDidSearch)
    {
        return 1;
    }
    else
    {
        return _keywordArray.count;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(_isDidSearch)
    {
        return _searchResultArray.count;
    }
    else
    {
        return [[_infoDic objectForKey:[_keywordArray objectAtIndex:section]] count];
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentify = @"_cellDefault";
    
    JBoLocalAddressBookCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentify];
    if(cell == nil)
    {
        cell = [[[JBoLocalAddressBookCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentify] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
    
    JBoLocalAddressBookInfo *info = nil;
    
    if(_isDidSearch)
    {
        info = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        info = [[_infoDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }
    cell.nameLabel.text = info.name;
    cell.phoneNumLabel.text = info.phoneNum;
    if(!self.isNeedToCallOut)
    {
        switch (info.type)
        {
            case JBoLocalAddressBookTypeContact :
                cell.typeLabel.text = @"已是好友";
                break;
            case JBoLocalAddressBookTypeExist :
                cell.typeLabel.text = @"添加好友";
                break;
            case JBoLocalAddressBookTypeNo :
                cell.typeLabel.text = @"邀请";
                break;
        }
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSString *title = [_keywordArray objectAtIndex:section];
    UIView *view = nil;
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        static NSString *headerIdentifier = @"headerIdentifier";
       JBoAddressBookSectionHeader *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:headerIdentifier];
        if(header == nil)
        {
            header = [[[JBoAddressBookSectionHeader alloc] initWithReuseIdentifier:headerIdentifier] autorelease];
        }
        header.headerView.titleLabl.text = title;
        view = header;
#endif
    }
    else
    {
        JBoAddressBookSectionHeaderView *header = [[[JBoAddressBookSectionHeaderView alloc] initWithFrame:CGRectMake(0, 0, _width_, _sectionHeaderHeight_)] autorelease];
        header.titleLabl.text = title;
        view = header;
    }

    return view;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(_isDidSearch)
    {
        return 0;
    }
    else
    {
        return _sectionHeaderHeight_;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    JBoLocalAddressBookInfo *info = nil;
    
    if(_isDidSearch)
    {
        info = [_searchResultArray objectAtIndex:indexPath.row];
    }
    else
    {
        info = [[_infoDic objectForKey:[_keywordArray objectAtIndex:indexPath.section]] objectAtIndex:indexPath.row];
    }

    if(self.isNeedToCallOut)
    {
        NSURL *phoneURL = [NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",info.phoneNum]];
     
        if(!_callOutWebView)
        {
            _callOutWebView = [[UIWebView alloc] init];
        }
        [_callOutWebView loadRequest:[NSURLRequest requestWithURL:phoneURL]];
    }
    else
    {
        if(info.type == JBoLocalAddressBookTypeContact)
            return;
        JBoLocalAddresBookSearchViewController *localSearchVC = [[JBoLocalAddresBookSearchViewController alloc] init];
        localSearchVC.title = info.name;
        localSearchVC.black = self.black;
        localSearchVC.userDetailInfo.rosterInfo.username = info.phoneNum;
        localSearchVC.userDetailInfo.rosterInfo.name = info.name;
        localSearchVC.isExist = NO;//info.type != JBoLocalAddressBookTypeNo;
        [self.navigationController pushViewController:localSearchVC animated:YES];
        [localSearchVC release];
    }
    
    [_searchBar resignFirstResponder];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
