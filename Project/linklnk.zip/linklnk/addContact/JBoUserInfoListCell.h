//
//  JBoUserInfoListCell.h
//  连你
//
//  Created by kinghe005 on 14-2-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"

#define _UserInfoListCellHeight_ 80
#define _UserInfoListCellInteval_ 10

/**个人信息列表cell
 */
@interface JBoUserInfoListCell : UITableViewCell
{
    //心情和背景
    UILabel *_presenceLabel;
}


//头像和名称 性别
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;


//心情
- (void)setPresence:(NSString*) presence;

@end
