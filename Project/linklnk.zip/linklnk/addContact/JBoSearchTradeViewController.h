//
//  JBoSearchTradeViewController.h
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoTableViewController.h"

/**搜行业
 */
@interface JBoSearchTradeViewController : JBoTableViewController<UITableViewDelegate,UITableViewDataSource>


@end
