//
//  JBoSearchNameViewController.m
//  连你
//
//  Created by kinghe005 on 14-2-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSearchNameViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoUserInofListViewController.h"
#import "JBoImageTextTool.h"
#import <QuartzCore/QuartzCore.h>


#define _controlInteval_ 10    //控件之间的间隔

@interface JBoSearchNameViewController ()<JBoHttpRequestDelegate,UIAlertViewDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

//是否正在请求
@property(nonatomic,assign) BOOL isRequesting;

//搜索结果，数组元素是 JBoUserDetailInfo
@property(nonatomic,retain) NSMutableArray *infoArray;

//正在搜索的昵称
@property(nonatomic,copy) NSString *searchName;

//搜索结果类型
@property(nonatomic,assign) NSInteger type;

@end

@implementation JBoSearchNameViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"搜昵称";
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.isRequesting = NO;
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc {
    
    [_nameTextField release];
    [_httpRequest release];
    
    [_searchName release];
    [_infoArray release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
     [_nameTextField becomeFirstResponder];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    self.searchName = nil;
    [JBoUserOperation alertmsgWithBadNetwork:@"搜索失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [self.infoArray removeAllObjects];
    self.type = [JBoUserOperation getSearchNameResultFromData:data infoArray:self.infoArray];
    
    if(self.infoArray.count > 0)
    {
        if(self.type)
        {
            [self seeResult];
        }
        else
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"无法找到相符合的用户,是否需要推荐朋友" delegate:self cancelButtonTitle:nil otherButtonTitles:@"不了", @"好", nil];
            [alertView show];
            [alertView release];
        }
    }
    else
    {
        self.searchName = nil;
        [JBoUserOperation alertMsg:@"无法找到相符合的用户"];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        [self seeResult];
    }
}

#pragma mark-加载视图


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //自定义返回按钮
    self.backItem = YES;
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    //手机号
    CGFloat x = 35.0;
    _nameTextField = [[UITextField alloc] initWithFrame:CGRectMake(x, _controlInteval_ * 3, _width_ - x * 2, 35)];
    _nameTextField.backgroundColor = [UIColor whiteColor];
    _nameTextField.layer.cornerRadius = 5.0;
    _nameTextField.layer.masksToBounds = YES;
    _nameTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _nameTextField.borderStyle = UITextBorderStyleNone;
    _nameTextField.placeholder = @"请输入昵称";
    [_nameTextField setLeftViewWithImageName:@"name_icon" padding:8.0];
    [self.view addSubview:_nameTextField];
    
    //搜索
    UIImage *searchImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"long_btn_@2x" ofType:_imageType_]];
    
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [searchButton setTitle:@"搜索" forState:UIControlStateNormal];
    searchButton.titleLabel.font = [UIFont systemFontOfSize:20.0];
    [searchButton setFrame:CGRectMake((_width_ - searchImage.size.width) / 2, _nameTextField.bottom + _controlInteval_, searchImage.size.width, searchImage.size.height)];
    [searchButton setBackgroundImage:searchImage forState:UIControlStateNormal];
    [searchButton addTarget:self action:@selector(searchtButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:searchButton];
    [searchImage release];
}

//搜索
- (void)searchtButtonAction:(id)sender
{
    if(self.isRequesting)
        return;
    
    if([self.searchName isEqualToString:_nameTextField.text] && self.infoArray.count > 0)
    {
       
        [self seeResult];
        return;
    }
    
    self.searchName = _nameTextField.text;
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoUserOperation getSearchNameURL] dic:[JBoUserOperation getSearchNameParamWithName:_nameTextField.text]];
}

- (void)seeResult
{
    JBoUserInofListViewController *listVC = [[JBoUserInofListViewController alloc] init];
    listVC.black = self.black;
    listVC.infoArray = self.infoArray;
    [self.navigationController pushViewController:listVC animated:YES];
    [listVC release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
