//
//  KingHeLocalAddressBookInfoViewController.h
//  微喂
//
//  Created by kinghe005 on 13-8-23.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoLettersSearchBar;

/**本地通讯录列表
 */
@interface JBoLocalAddressBookInfoViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate>
{
    
    UITableView *_tableView;
    //关键字母
    NSMutableArray *_keywordArray;
    NSMutableDictionary *_infoDic;
    
    //搜索栏
    UISearchBar *_searchBar;
    //是否正在搜索
    BOOL _isDidSearch;
    //搜索结果
    NSMutableArray *_searchResultArray;
    //字母搜索栏
    JBoLettersSearchBar *_lettersView;
    
    //是否能够访问通讯录
    BOOL _isAbleToAccess;
    //拨号
    UIWebView *_callOutWebView;
    //黑色半透明视图
    UIView *_transparentView;
}

@property(nonatomic,assign) BOOL isNeedToCallOut;

@end
