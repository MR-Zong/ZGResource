//
//  KingHeSearchContactViewController.h
//  微喂
//
//  Created by kinghe005 on 13-9-13.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

@class JBoAlertView;

/**搜账号
 */
@interface JBoSearchContactViewController : JBoViewController
{
    //账号输入框
    UITextField *_emailTextField;
}

@end
