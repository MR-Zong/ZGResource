//
//  JBoCustomToolBar.h
//  连你
//
//  Created by kinghe005 on 14-3-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

//工具条默认高度
#define _defaultToolBarHeight_ 35.0

/**自定义工具条按钮信息
 */
@interface JBoCustomToolBarItem : NSObject

/**按钮信息
 */
@property(nonatomic,copy) NSString *title;

/**按钮图标
 */
@property(nonatomic,copy) UIImage *image;

+ (JBoCustomToolBarItem*) toolBarItemWithTitle:(NSString*) title image:(UIImage*) image;

@end

@class JBoCustomToolBar;

/**自定义工具条代理
 */
@protocol JBoCustomToolBarDelegate <NSObject>

@optional

/**点击某个按钮
 *@param 按钮下标
 */
- (void)toolBar:(JBoCustomToolBar*) toolBar didSelectedAtIndex:(NSInteger) index;

@end

/**自定义工具条
 */
@interface JBoCustomToolBar : UIView

/**初始化一个 toolBar
 @param items 数组成员是 JBoCustomToolBarItem对象
 */
- (id)initWithFrame:(CGRect)frame items:(NSArray*) items;

@property(nonatomic,retain) NSMutableArray *barImtes;

/**标题字体 default is 'nil'
 */
@property(nonatomic,retain) UIFont *titleFont;

/**标题颜色 default is [UIColor blackColor]
 */
@property(nonatomic,retain) UIColor *titleColor;

/**标题选中颜色 default is 'nil'
 */
@property(nonatomic,retain) UIColor *titleSelectedColor;

/**分割线颜色 default is [UIColor lightGrayColor]
 */
@property(nonatomic,retain) UIColor *separatorColor;

/**分割线宽度 default is '0.5'
 */
@property(nonatomic,assign) CGFloat separatorWidth;

/**选中的按钮下标 default is 'NSNotfound'
 */
@property(nonatomic,assign) NSInteger selectedIndex;

/**分割线
 */
@property(nonatomic,retain) UIView *separatorLine;

@property(nonatomic,assign) id<JBoCustomToolBarDelegate> delegate;

/**重新加载按钮信息
 */
- (void)reloadItems;

/**通过下标获取按钮
 */
- (UIButton*)buttonForIndex:(NSInteger) index;

/**通过下标设置按钮的标题
 */
- (void)setTitle:(NSString*) title forIndex:(NSInteger) index;

/**通过下标设置按钮的标题颜色
 */
- (void)setTitleColor:(UIColor *)titleColor forIndex:(NSInteger) index;

/**通过下标设置按钮的图标
 */
- (void)setImage:(UIImage*) image forIndex:(NSInteger) index;

/**通过下标设置按钮的背景图片
 */
- (void)setBackgroundImage:(UIImage*) image forIndex:(NSInteger) index;

/**删除按钮
 */
- (void)removeItemAtIndex:(NSInteger) index;

/**通过下标获取按钮的标题
 *@param 按钮下标
 */
- (NSString*)buttonTitleForIndex:(NSInteger) index;

@end
