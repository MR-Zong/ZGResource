//
//  KingHeAddContactViewController.m
//  微喂
//
//  Created by kinghe005 on 13-8-22.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoAddContactViewController.h"
#import "JBoLocalAddressBookInfoViewController.h"
#import "JBoSearchContactViewController.h"
#import "JBoBasic.h"
#import "JBoSearchNameViewController.h"
#import "JBoSearchTradeViewController.h"
#import "JBoRosterListViewController.h"
#import "JBoCustomInsetLabel.h"

@interface JBoAddContactViewController ()

@end

@implementation JBoAddContactViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
       
        self.operationType = JBoRosterOperationTypeDefault;
    }
    return self;
}

- (void)dealloc {
    
    self.delegate = nil;
    [_textArray release];
    
    [super dealloc];
}

#pragma mark-加载视图

- (void)cancel
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    JBoCustomInsetLabel *header = nil;
    switch (self.operationType)
    {
        case JBoRosterOperationTypeLinkCloundURL :
        {
             self.title = @"添加云名片链接";
             _textArray = [[NSArray alloc] initWithObjects:@"搜昵称", @"搜账号", @"搜行业", @"通讯录", nil];
            self.black = YES;
            [self setRightBarItemWithTitle:@"取消" action:@selector(cancel)];
            header = [[[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(0, 0, _width_, 40.0)] autorelease];
            header.insets = UIEdgeInsetsMake(0, 15.0, 0, 15.0);
            header.backgroundColor = [UIColor clearColor];
            header.textColor = [UIColor grayColor];
            header.font = [UIFont systemFontOfSize:13.0];
            header.text = @"只能添加实名认证的用户的云名片链接";
        }
            break;
        default:
        {
            _textArray = [[NSArray alloc] initWithObjects:@"搜昵称", @"搜账号", @"搜行业",@"从手机的通讯录上添加",nil];
            self.title = @"添加联系人";
            self.backItem = YES;
        }
            break;
    }
    
    [super initialization];
    self.tableView.tableHeaderView = header;
}


#pragma mark-tableView代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _textArray.count;
}


- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentity = @"_cellDefault";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentity];
    if(cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentity] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        UIImage *image = [UIImage imageNamed:@"arrow.png"];
        UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
        cell.accessoryView = imageView;
        [imageView release];
    }
    
    cell.textLabel.text = [_textArray objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row)
    {
        case 0 :
        {
            JBoSearchNameViewController *searchNameVC = [[JBoSearchNameViewController alloc] init];
            searchNameVC.black = self.black;
            [self.navigationController pushViewController:searchNameVC animated:YES];
            [searchNameVC release];
            
            break;
        }
        case 1 :
        {
            JBoSearchContactViewController *searchContactVC = [[JBoSearchContactViewController alloc] init];
            searchContactVC.black = self.black;
            [self.navigationController pushViewController:searchContactVC animated:YES];
            [searchContactVC release];
            break;
        }
            case 2 :
        {
            JBoSearchTradeViewController *searchTrade = [[JBoSearchTradeViewController alloc] init];
            searchTrade.black = self.black;
            [self.navigationController pushViewController:searchTrade animated:YES];
            [searchTrade release];
        }
            break;
            case 3 :
        {
            switch (self.operationType)
            {
                case JBoRosterOperationTypeLinkCloundURL :
                {
                    JBoRosterListViewController *rosterList = [[JBoRosterListViewController alloc] init];
                    rosterList.black = self.black;
                    rosterList.delegate = self.delegate;
                    rosterList.rosterOprationType = self.operationType;
                    [self.navigationController pushViewController:rosterList animated:YES];
                    [rosterList release];
                }
                    break;
                default:
                {
                    JBoLocalAddressBookInfoViewController *localAddressBookInfoVC = [[JBoLocalAddressBookInfoViewController alloc] init];
                    localAddressBookInfoVC.black = self.black;
                    [self.navigationController pushViewController:localAddressBookInfoVC animated:YES];
                    [localAddressBookInfoVC release];
                }
                    break;
            }
            
            break;
        }
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
