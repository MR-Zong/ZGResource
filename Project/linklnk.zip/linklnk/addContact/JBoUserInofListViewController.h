//
//  JBoUserInofListViewController.h
//  连你
//
//  Created by kinghe005 on 14-2-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoTableViewController.h"

/**用户信息列表，用户显示搜昵称等多个搜索结果
 */
@interface JBoUserInofListViewController : JBoTableViewController

/**用户信息，数组元素是 JBoUserDetailInfo
 */
@property(nonatomic,retain) NSArray *infoArray;

@end
