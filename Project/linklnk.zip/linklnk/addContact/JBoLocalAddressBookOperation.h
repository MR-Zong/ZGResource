//
//  JBoLocalAddressBookOperation.h
//  连你
//
//  Created by kinghe005 on 14-4-1.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>



/**本地通讯录操作
 */
@interface JBoLocalAddressBookOperation : NSObject

/**是否能够使用本地通讯录
 */
@property(nonatomic,readonly) BOOL canUseAddressBook;

// 添加联系人（联系人名称、号码、号码备注标签）
//+ (BOOL)addContactName:(NSString*)name phoneNum:(NSString*)num withLabel:(NSString*)label;

/**联系人信息实体类 必须是 JBoAddressBookPersonInfo 或其子类，默认 JBoAddressBookPersonInfo
 */
@property(nonatomic,copy) NSString *personClassString;

/**获取本地通讯录
 */
- (ABAddressBookRef)getAddressBook;

/**从本地通讯录中获取联系人信息 没分组
 *@return 联系人信息，数组元素是 JBoAddressBookPersonInfo 对象
 */
- (NSMutableArray*)getAddressBookPersonInfos;

/**从本地通讯录中获取联系人信息 按首字母分组
 *@return 联系人分组信息，数组元素是 JBoAddressBookGroupInfo 对象
 */
- (NSMutableArray*)getAddressBookGroupInfos;

/**把联系人按首字母分组
 *@param personInfos 联系人信息 数组元素是 JBoAddressBookPersonInfo 对象
 *@return 联系人分组信息，数组元素是 JBoAddressBookGroupInfo 对象
 */
- (NSMutableArray*)addressBookGroupInfosFromPersonInfos:(NSArray*) personInfos;

@end
