//
//  JBoLocalAddressBookCell.m
//  连你
//
//  Created by kinghe005 on 14-1-23.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLocalAddressBookCell.h"
#import "JBoBasic.h"

#define _controlInterval_ 5
#define _controlHeight_ 25
#define _typeLabelWidth_ 60
#define _letterWidht_ 30

@implementation JBoLocalAddressBookInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.type = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_name release];
    [_phoneNum release];
    
    [super dealloc];
}

@end

@implementation JBoLocalAddressBookCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        CGFloat width = _width_ - _typeLabelWidth_ - _controlInterval_ * 2 - _letterWidht_;
        _nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_, _controlInterval_, width, _controlHeight_)];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:16.0];
        [self.contentView addSubview:_nameLabel];
        
        _phoneNumLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_, _controlInterval_ + _controlHeight_, width, _controlHeight_)];
        _phoneNumLabel.font = [UIFont systemFontOfSize:15.0];
        [self.contentView addSubview:_phoneNumLabel];
        
        _typeLabel = [[UILabel alloc] initWithFrame:CGRectMake(_width_ - _letterWidht_ - _typeLabelWidth_, (_localAddressBookCellHeight_ - _controlHeight_) / 2, _typeLabelWidth_, _controlHeight_)];
        _typeLabel.textColor = [UIColor grayColor];
        _typeLabel.font = [UIFont systemFontOfSize:14.0];
        [_typeLabel setTextAlign:JBoTextAlignmentRight];
        
        [self.contentView addSubview:_typeLabel];
    }
    return self;
}

- (void)dealloc
{
    [_typeLabel release];
    [_arrowImageView release];
    [_phoneNumLabel release];
    [_nameLabel release];
    
    [super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
