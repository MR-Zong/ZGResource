//
//  JBoSearchNameViewController.h
//  连你
//
//  Created by kinghe005 on 14-2-26.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"
#import "JBoRosterInfoDelegate.h"

/**搜昵称
 */
@interface JBoSearchNameViewController : JBoViewController
{
    //昵称输入框
    UITextField *_nameTextField;
}

@end
