//
//  JBoAddressBookPersonInfo.h
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**本地通讯录分组信息
 */
@interface JBoAddressBookGroupInfo : NSObject

/**分组标题
 */
@property(nonatomic,copy) NSString *title;

/**分组信息 数组元素是 JBoAddressBookPersonInfo
 */
@property(nonatomic,retain) NSMutableArray *personInfos;

@end

/**本地通讯录联系人信息
 */
@interface JBoAddressBookPersonInfo : NSObject

/**联系人名称
 */
@property(nonatomic,copy) NSString *name;

/**联系人电话号码 数组元素是 NSString对象
 */
@property(nonatomic,retain) NSMutableArray *phoneNums;

/**联系人备注信息
 */
@property(nonatomic,copy) NSString *remark;

@end
