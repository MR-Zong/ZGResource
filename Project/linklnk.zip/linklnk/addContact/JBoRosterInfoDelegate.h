//
//  JBoRosteInfoDelegate.h
//  靓咖
//
//  Created by kinghe005 on 14-9-2.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

//对用户信息操作的类型
typedef enum _JBoRosterOperationType
{
    JBoRosterOperationTypeDefault = 0, //默认操作
    JBoRosterOperationTypeLogoDownload,//logo下载
    JBoRosterOperationTypeSharelink, //分享连接
    JBoRosterOperationTypeLinkCloundURL, //靓云台链接选择
}JBoRosterOperationType;

@class JBoRosterInfo;
@class UIViewController;

/**用户信息选择代理
 */
@protocol JBoRosterInfoDelegate <NSObject>

@optional

/**选择用户信息
 *@param viewController 选择的用户信息所在的viewController 可以为空
 *@param rosterInfo 选择的用户信息
 */
- (void)viewController:(UIViewController*) viewController didSelectRosterInfo:(JBoRosterInfo*) rosterInfo;

@end
