//
//  JBoLocalAddresBookSearchViewController.m
//  连客
//
//  Created by kinghe005 on 13-11-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoLocalAddresBookSearchViewController.h"
#import "GTMBase64.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoUserOperation.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoUserInfoCell.h"
#import "JBoImageTextTool.h"
#import "JBoImageBrowerViewController.h"
#import <MessageUI/MessageUI.h>
#import "JBoAsyncDownloadImageOperation.h"

#undef _controlInterval_
#undef _controlHeight_

#define _controlInterval_ 10
#define _controlHeight_ 30
#define _padding_ 30
#define _cellHeight_ 40


@interface JBoLocalAddresBookSearchViewController ()<UIAlertViewDelegate,XMPPStreamDelegate,JBoHttpRequestDelegate,MFMessageComposeViewControllerDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,assign) BOOL isRequesting;

@property(nonatomic,assign) CGFloat contentWordHeight;
@property(nonatomic,assign) CGFloat contentWidth;
@property(nonatomic,retain) UIFont *contentFont;

@end

@implementation JBoLocalAddresBookSearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        self.userDetailInfo = [[[JBoUserDetailInfo alloc] init] autorelease];
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.contentFont = [UIFont systemFontOfSize:17];
        self.contentWordHeight = [JBoImageTextTool getFontSize:self.contentFont withString:@"我"].height;
        self.contentWidth = _width_ - _padding_ * 2 - _userInfoTitleWidth_ - _userInfoCellcontrolInterval_ * 2;
        
        self.isRequesting = NO;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    NSLog(@"JBoLocalAddresBookSearchViewController dealloc");
    [_userDetailInfo release];
    [_headImageView release];
    [_tableView release];
    [_contactInfoArray release];
    
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [_appDelegate.xmpp.xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_appDelegate.xmpp.xmppStream removeDelegate:self];
    [_appDelegate closeAlertView];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"请重试"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getSearchUserIdResultFromData:data];
    if(userDetailInfo)
    {
        self.userDetailInfo = userDetailInfo;
        [self loadInitView];
    }
}

#pragma mark-xmppStream代理
- (void)xmppStream:(XMPPStream *)sender didFailToSendPresence:(XMPPPresence *)presence error:(NSError *)error
{
    NSLog(@"add contact fail to send presence");
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"请重试"];
}

- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    NSString *type = [presence attributeStringValueForName:_xmppType_];
    if([type isEqualToString:_xmppError_])
    {
        self.isRequesting = NO;
        [JBoUserOperation alertmsgWithBadNetwork:@"请重试"];
        return;
    }
    
    NSString *success = [[presence elementForName:_xmppSuccess_] stringValue];
    if(success)
    {
        self.isRequesting = NO;
        _appDelegate.alertView.message = @"已向对方发送请求，请耐心等候";
        [_appDelegate.alertView viewDesalt:_second_];
    }
}

#pragma mark-加载视图


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //自定义返回按钮
    self.backItem = YES;
    
     self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    if(self.isExist)
    {
        
    }
    else
    {
        [self loadNotExist];
    }
}

//加载视图
- (void)loadNotExist
{
    //头像
    _headImageView = [[JBoUserHeadImageView alloc] initWithFrame: CGRectMake((_width_ - _defaultImageSize_) / 2, _controlInterval_ * 3, _defaultImageSize_, _defaultImageSize_)];
    _headImageView.imageView.image = _appDelegate.boyImage;
    [self.view addSubview:_headImageView];
  
    //昵称
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, _headImageView.frame.origin.y + _headImageView.frame.size.height + _controlInterval_, _width_, _controlHeight_)];
    nameLabel.backgroundColor = [UIColor clearColor];
    [nameLabel setTextAlign:JBoTextAlignmentCenter];
    nameLabel.text = self.userDetailInfo.rosterInfo.name;
    [self.view addSubview:nameLabel];
    [nameLabel release];
    
    //手机号
    UILabel *phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, nameLabel.frame.origin.y + nameLabel.frame.size.height + _controlInterval_, _width_, _controlHeight_)];
    phoneLabel.backgroundColor = [UIColor clearColor];
    [phoneLabel setTextAlign:JBoTextAlignmentCenter];
    phoneLabel.text = [NSString stringWithFormat:@"手机号:%@", self.userDetailInfo.rosterInfo.username];
    [self.view addSubview:phoneLabel];
    [phoneLabel release];
    
    NSString *appName = self.appDelegate.appName;
    
    //提示
    UILabel *noteLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, phoneLabel.frame.origin.y + phoneLabel.frame.size.height + _controlInterval_, _width_, _controlHeight_)];
    noteLabel.backgroundColor = [UIColor clearColor];
    [noteLabel setTextAlign:JBoTextAlignmentCenter];
    noteLabel.text = [NSString stringWithFormat:@"%@ 还没开通%@", appName, self.userDetailInfo.rosterInfo.name];
    [self.view addSubview:noteLabel];
    [noteLabel release];
    
    //搜索
    CGFloat buttonY = _isExist ? phoneLabel.frame.origin.y + phoneLabel.frame.size.height + _controlInterval_: noteLabel.frame.origin.y + noteLabel.frame.size.height + _controlInterval_;
    
    UIImage *addImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"long_btn_@2x" ofType:_imageType_]];
    UIButton *addButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [addButton setTitle:@"发送邀请" forState:UIControlStateNormal];
    [addButton setBackgroundImage:addImage forState:UIControlStateNormal];
    [addButton addTarget:self action:@selector(sendInvitationAction:) forControlEvents:UIControlEventTouchUpInside];
    [addButton setFrame:CGRectMake((_width_ - addImage.size.width) / 2, buttonY, addImage.size.width, addImage.size.height)];
    [self.view addSubview:addButton];
    [addImage release];
}

#pragma mark-加载存在的视图

- (void)updateHeadImage
{
    if(self.userDetailInfo.rosterInfo.image)
    {
        _headImageView.imageView.image = self.userDetailInfo.rosterInfo.image;
    }
    else
    {
        _headImageView.sex = self.userDetailInfo.rosterInfo.sex;
    }
}

- (void)loadInitView
{
    //头像
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageBecomeBig:)];
    _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake((_width_ - _defaultImageSize_) / 2, 20, _defaultImageSize_, _defaultImageSize_)];
    _headImageView.sex = self.userDetailInfo.rosterInfo.sex;
    if(self.userDetailInfo.rosterInfo.image)
    {
        _headImageView.imageView.image = self.userDetailInfo.rosterInfo.image;
    }
    else
    {
        _headImageView.sex = self.userDetailInfo.rosterInfo.sex;
        
        if([NSString isEmpty:self.userDetailInfo.rosterInfo.imageURL])
        {
            JBoAsyncDownloadImageOperation *asyncDownload = [[JBoAsyncDownloadImageOperation alloc] init];
            __block JBoAsyncDownloadImageOperation *blockAsyncDownload = asyncDownload;
            
            asyncDownload.completionHandler = ^(void)
            {
                UIImage *headImage = [[UIImage alloc] initWithData:blockAsyncDownload.data];
                self.userDetailInfo.rosterInfo.image = headImage;
                [headImage release];
                [self performSelectorOnMainThread:@selector(updateHeadImage) withObject:nil waitUntilDone:NO];
                [blockAsyncDownload release];
            };
            [asyncDownload downloadWithURL:self.userDetailInfo.rosterInfo.imageURL];
        }
    }
    
    _headImageView.userInteractionEnabled = YES;
    [_headImageView addGestureRecognizer:tap];
    [tap release];
    [self.view addSubview:_headImageView];
    
    //昵称
    JBoUserNameLabel *nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_padding_, _headImageView.frame.size.height + _headImageView.frame.origin.y + _controlInterval_, _width_ - _padding_ * 2, _controlHeight_)];
    nameLabel.text = self.userDetailInfo.rosterInfo.name;
    nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
    nameLabel.textColor = [UIColor whiteColor];
    nameLabel.sex = self.userDetailInfo.rosterInfo.sex;
    [nameLabel setTextAlign:JBoTextAlignmentCenter];
    nameLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:nameLabel];
    [nameLabel release];
    
    
    _contactInfoArray = [[self.userDetailInfo getPublicInfo] retain];
    
    CGFloat tableViewHeight = 0;
    for(NSDictionary *dic in _contactInfoArray)
    {
        NSString *content = [[dic allValues] objectAtIndex:0];
        CGSize size = [JBoImageTextTool getStringSize:content withFont:self.contentFont andContraintSize:CGSizeMake(self.contentWidth, 200)];
        
        NSInteger lines = size.height / self.contentWordHeight;
        tableViewHeight += lines * _userInfoCellcontrolHeight_ + _userInfoCellcontrolInterval_ * 2;
    }
    
    //联系人信息
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(_padding_, nameLabel.frame.origin.y + nameLabel.frame.size.height + _controlInterval_, _width_ - _padding_ * 2, tableViewHeight - 2.0) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.scrollEnabled = NO;
    _tableView.layer.cornerRadius = 5.0;
    _tableView.layer.masksToBounds = YES;
    _tableView.separatorColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0];
    [self.view addSubview:_tableView];
    
    //创建临时会话按钮
    //搜索
    UIImage *addImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"long_btn_@2x" ofType:_imageType_]];
    
    UIButton *addButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [addButton setTitle:@"添加好友" forState:UIControlStateNormal];
    [addButton setFrame:CGRectMake((_width_ - addImage.size.width) / 2, _tableView.frame.origin.y + _tableView.frame.size.height + _controlInterval_, addImage.size.width, addImage.size.height)];
    [addButton setBackgroundImage:addImage forState:UIControlStateNormal];
    [addButton addTarget:self action:@selector(addButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:addButton];
    [addImage release];
}

//添加好友
- (void)addButtonAction:(UIButton*) button
{
    if(self.isRequesting)
        return;
    
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"请求信息" message:@"" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    textField.placeholder = [NSString stringWithFormat:@"%d字以内",_inputFormatStatus_];
    [alerView show];
    [alerView release];
}

#pragma mark-UIAlertView代理
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        UITextField *textField = [alertView textFieldAtIndex:0];
        if(textField.text.length > _inputFormatStatus_)
        {
            _appDelegate.alertView.message = [NSString stringWithFormat:@"验证信息不能超过%d字",_inputFormatStatus_];
            [_appDelegate.alertView viewDesalt:_second_];
        }
        else
        {
            if([JBoUserOperation sendApplyInfoWithStatus:textField.text jid:self.userDetailInfo.rosterInfo.jid type:JBoAddBuddyTypeDefault])
            {
                self.isRequesting = YES;
            }
        }
    }
}

//发送短信邀请
- (void)sendInvitationAction:(UIButton*) button
{
    if(![MFMessageComposeViewController canSendText])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"该设备不支持发送短信" message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
    }
    else
    {
        NSString *appName = self.appDelegate.appName;
        MFMessageComposeViewController *msgVC = [[MFMessageComposeViewController alloc] init];
        msgVC.messageComposeDelegate = self;
        NSMutableString *url = [[NSMutableString alloc] initWithString:@"https://itunes.apple.com/us/app/lian-ni/id827390903?mt=8&uo=4"];
        
        msgVC.body = [NSString stringWithFormat:@"%@：一种极致简单快连的生活方式。全球首个和全球最大的场景社交生活精准对接平台。闺蜜最近总有帅哥请吃饭、请唱K，进出豪车接送，一起外出旅行，原来是用了“%@”APP。下载地址:%@", appName, url, appName];
        msgVC.recipients = [NSArray arrayWithObject:self.userDetailInfo.rosterInfo.username];
        [_appDelegate.window.rootViewController presentViewController:msgVC animated:YES completion:nil];
        [msgVC release];
        [url release];
    }
}

- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    switch (result)
    {
        case MessageComposeResultCancelled :
        {
        }
            break;
        case MessageComposeResultFailed :
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"发送短信失败,请检查该设备是否具有发送短信功能" message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
            [alertView release];
        }
            break;
        case MessageComposeResultSent :
        {
            _appDelegate.alertView.message = @"发送成功";
            [_appDelegate.alertView viewDesalt:_second_];
        }
            break;
    }
    [controller dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark-查看头像大图
- (void)imageBecomeBig:(id)sender
{
    UITapGestureRecognizer *tap = (UITapGestureRecognizer*)sender;
    UIImageView *imageView = (UIImageView*)tap.view;
    
    JBoImageBrowerViewController *detailImageView = [[JBoImageBrowerViewController alloc] init];
    detailImageView.srcArray = [NSArray arrayWithObject:imageView.image];
    [detailImageView createImageCell];
    [detailImageView showInViewController:self];
    [detailImageView release];
}

#pragma mark-tableView 代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _contactInfoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dic = [_contactInfoArray objectAtIndex:indexPath.row];
    NSString *content = [[dic allValues] objectAtIndex:0];
    CGSize size = [JBoImageTextTool getStringSize:content withFont:self.contentFont andContraintSize:CGSizeMake(self.contentWidth, 200)];
    
    NSInteger lines = size.height / self.contentWordHeight;
    
    return lines * _userInfoCellcontrolHeight_ + _userInfoCellcontrolInterval_ * 2;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cellDefault";
    JBoUserInfoCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoUserInfoCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier width:_width_ - _padding_ * 2] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    NSDictionary *dic = [_contactInfoArray objectAtIndex:indexPath.row];
    
    cell.titleLabel.text = [[dic allKeys] objectAtIndex:0];
    cell.contentLabel.text = [[dic allValues] objectAtIndex:0];
    
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
