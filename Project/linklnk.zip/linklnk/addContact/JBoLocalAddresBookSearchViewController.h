//
//  JBoLocalAddresBookSearchViewController.h
//  连客
//
//  Created by kinghe005 on 13-11-25.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoViewController.h"
#import "JBoUserDetailInfo.h"

@class JBoUserHeadImageView;

/**本地通讯录用户详情
 */
@interface JBoLocalAddresBookSearchViewController : JBoViewController<UITableViewDelegate,UITableViewDataSource>
{
    //个人信息
    NSArray *_contactInfoArray;
    UITableView *_tableView;
    
    //头像
    JBoUserHeadImageView *_headImageView;
}

@property(nonatomic,retain) JBoUserDetailInfo *userDetailInfo;
@property(nonatomic,assign) BOOL isExist;

@end
