//
//  JBoLocalAddressBookOperation.m
//  连你
//
//  Created by kinghe005 on 14-4-1.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLocalAddressBookOperation.h"
#import "JBoBasic.h"
#import "JBoAddressBookPersonInfo.h"
#import "ChineseToPinyin.h"

@interface JBoLocalAddressBookOperation ()
{
    ABAddressBookRef _addressBook;
}
@end

@implementation JBoLocalAddressBookOperation

- (id)init
{
    self = [super init];
    if(self)
    {
        self.personClassString = NSStringFromClass([JBoAddressBookPersonInfo class]);
        [self addressBookCreate];
    }
    return self;
}

- (void)dealloc
{
    [_personClassString release];
    if(_addressBook != NULL)
        CFRelease(_addressBook);
    
    [super dealloc];
}

// 添加联系人（联系人名称、号码、号码备注标签）
+ (BOOL)addContactName:(NSString*)name phoneNum:(NSString*)num withLabel:(NSString*)label
{
    // 创建一条空的联系人
    ABRecordRef record = ABPersonCreate();
    CFErrorRef error;
    // 设置联系人的名字
    
    ABRecordSetValue(record, kABPersonFirstNameProperty, (CFTypeRef)name, &error);
    // 添加联系人电话号码以及该号码对应的标签名
    ABMutableMultiValueRef multi = ABMultiValueCreateMutable(kABPersonPhoneProperty);
    ABMultiValueAddValueAndLabel(multi, (CFTypeRef)num, (CFTypeRef)label, NULL);
    ABRecordSetValue(record, kABPersonPhoneProperty, multi, &error);
    CFRelease(multi);
    
    ABAddressBookRef addressBook = nil;
    // 如果为iOS6以上系统，需要等待用户确认是否允许访问通讯录。
#ifdef __IPHONE_6_0
    if(ABAddressBookGetAuthorizationStatus() != kABAuthorizationStatusAuthorized)
    {
        addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
        //等待同意后向下执行
        dispatch_semaphore_t sema = dispatch_semaphore_create(0);
        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error)
                                                 {
                                                     dispatch_semaphore_signal(sema);
                                                 });
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        dispatch_release(sema);
    }
    else
    {
        addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
    }
#else
    addressBook = ABAddressBookCreate();
#endif
    // 将新建联系人记录添加如通讯录中
    BOOL success = ABAddressBookAddRecord(addressBook, record, &error);
    if (!success)
    {
        CFRelease(record);
        if(addressBook != nil)
        {
            CFRelease(addressBook);
        }
        return NO;
    }else
    {
    // 如果添加记录成功，保存更新到通讯录数据库中
        success = ABAddressBookSave(addressBook, &error);
        CFRelease(record);
        
        if(addressBook != nil)
        {
            CFRelease(addressBook);
        }
        
        return success ? YES : NO;
    }  
}

//创建本地通讯录
- (void)addressBookCreate
{
    // 如果为iOS6以上系统，需要等待用户确认是否允许访问通讯录。
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        if(ABAddressBookGetAuthorizationStatus() != kABAuthorizationStatusAuthorized)
        {
            _addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
            //等待同意后向下执行
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            ABAddressBookRequestAccessWithCompletion(_addressBook, ^(bool granted, CFErrorRef error)
                                                     {
                                                         dispatch_semaphore_signal(sema);
                                                     });
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
            dispatch_release(sema);
        }
        else
        {
            _addressBook = ABAddressBookCreateWithOptions(NULL, NULL);
        }
#endif
    }
    else
    {
        _addressBook = ABAddressBookCreate();
    }
}

- (BOOL)canUseAddressBook
{
    return ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized;
}

//获取本地通讯录
- (ABAddressBookRef)getAddressBook
{
    return _addressBook;
}

/**从本地通讯录中获取联系人信息
 *@param addressBook 本地通讯录
 *@return 联系人信息，数组元素是 JBoAddressBookPersonInfo 对象
 */
- (NSMutableArray*)getAddressBookPersonInfos
{
    if(_addressBook == NULL)
        return nil;
    Class personClass = NSClassFromString(self.personClassString);
    //获取所有联系人
    CFArrayRef addressBookArray =  ABAddressBookCopyArrayOfAllPeople(_addressBook);
    //获取联系人的数量
    CFIndex numberOfContacts = ABAddressBookGetPersonCount(_addressBook);
    
    NSMutableArray *infos = [NSMutableArray arrayWithCapacity:numberOfContacts];
    
    for(int i = 0;i < numberOfContacts;i++)
    {
        //获取通信录中的一条记录
        NSString *name = nil;
        ABRecordRef recordRef = CFArrayGetValueAtIndex(addressBookArray, i);
        
        //获取联系人姓名
        if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease]  && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease] == nil)
        {
            name = [(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease];
        }
        else if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease] == nil && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease])
        {
            name = [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease];
        }
        else if([(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease] && [(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease])
        {
            name = [NSString stringWithFormat:@"%@%@",[(NSString*)ABRecordCopyValue(recordRef, kABPersonLastNameProperty) autorelease],[(NSString*)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty) autorelease]];
        }
        
        if([NSString isEmpty:name])
        {
            name = [(NSString*)ABRecordCopyCompositeName(recordRef) autorelease];
        }
        
        if([NSString isEmpty:name])
            continue;
        
        //获取个人信息中的电话号码信息数组
        ABMutableMultiValueRef phoneNumberRef = ABRecordCopyValue(recordRef, kABPersonPhoneProperty);
        
        if(phoneNumberRef == NULL)
            continue;
        
        //从电话号码信息里获取手机号码
        NSInteger phoneCount = 0;
        if(phoneNumberRef != NULL)
            phoneCount = ABMultiValueGetCount(phoneNumberRef);
        
        NSMutableArray *phoneNums = [NSMutableArray arrayWithCapacity:phoneCount];
        
        for(int i = 0;i < phoneCount;i++)
        {
            NSString *mobileNumber = [(NSString*)ABMultiValueCopyValueAtIndex(phoneNumberRef, i) autorelease];
            if(mobileNumber)
            {
                NSString *phoneNum = [JBoLocalAddressBookOperation phoneNumFromString:mobileNumber];
                [phoneNums addObject:phoneNum];
            }
            else
            {
                continue;
            }
        }
        
        CFRelease(phoneNumberRef);
        
        if(name && phoneNums.count > 0)
        {
            JBoAddressBookPersonInfo *info = [[personClass alloc] init];
            info.name = name;
            info.phoneNums = phoneNums;
            info.remark = [(NSString*)ABRecordCopyValue(recordRef, kABPersonNoteProperty) autorelease];
            
            [infos addObject:info];
            [info release];
        }
    }
    
    CFRelease(addressBookArray);
    
    return infos;
}

/**从本地通讯录中获取联系人信息 按首字母分组
 *@return 联系人信息，数组元素是 JBoAddressBookGroupInfo 对象
 */
- (NSMutableArray*)getAddressBookGroupInfos
{
    NSArray *personInfos = [self getAddressBookPersonInfos];
  
    return [self addressBookGroupInfosFromPersonInfos:personInfos];
}

/**把联系人按首字母分组
 *@param personInfos 联系人信息 数组元素是 JBoAddressBookPersonInfo 对象
 *@return 联系人分组信息，数组元素是 JBoAddressBookGroupInfo 对象
 */
- (NSMutableArray*)addressBookGroupInfosFromPersonInfos:(NSArray*) personInfos
{
    if(personInfos == 0)
        return [NSMutableArray array];
    
    NSMutableArray *groupInfos = [NSMutableArray array];
    NSMutableDictionary *personDic = [NSMutableDictionary dictionary];
    
    //获取首字母分组
    for(JBoAddressBookPersonInfo *person in personInfos)
    {
        NSString *name = [person.name stringByReplacingOccurrencesOfString:@" " withString:@""];
        char c = [ChineseToPinyin sortSectionTitle:name];
        if(c <'A' || c > 'Z')
            c = '#';
        
        NSString *key = [NSString stringWithFormat:@"%c",c];
        
        NSMutableArray *infos = [personDic objectForKey:key];
        if(!infos)
        {
            infos = [NSMutableArray array];
            [personDic setObject:infos forKey:key];
        }
        
        [infos addObject:person];
    }
    
    //排序首字母
    NSArray *keys = [[personDic allKeys] sortedArrayUsingComparator:^(id obj1, id obj2){
        
        char c1 = [(NSString*)obj1 firstCharacter];
        char c2 = [(NSString*)obj2 firstCharacter];
        
        if(c1 == '#')
            return NSOrderedDescending;
        
        if(c2 == '#')
            return NSOrderedAscending;
        
        if(c1 > c2)
        {
            return NSOrderedDescending;
        }
        else if(c1 < c2)
        {
            return NSOrderedAscending;
        }
        else
        {
            return NSOrderedSame;
        }
    }];
    
    //获取分组信息
    for(NSString *key in keys)
    {
        JBoAddressBookGroupInfo *group = [[JBoAddressBookGroupInfo alloc] init];
        group.personInfos = [personDic objectForKey:key];
        group.title = key;
        [groupInfos addObject:group];
        [group release];
    }
    
    return groupInfos;
}

#pragma mark- class method

//把字符串转换成手机号码
+ (NSString*)phoneNumFromString:(NSString*) str
{
    NSString *phoneNum = nil;
    if(str)
    {
        phoneNum = [str stringByReplacingOccurrencesOfString:@"-" withString:@""];
    }
    return phoneNum;
}

@end
