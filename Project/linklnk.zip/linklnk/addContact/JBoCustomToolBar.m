//
//  JBoCustomToolBar.m
//  连你
//
//  Created by kinghe005 on 14-3-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoCustomToolBar.h"
#import "NSString+customString.h"
#import "JBoBasic.h"

#define _buttonStartTag_ 1000
#define _lineWidth_ 0.5

#pragma mark-barItem

@implementation JBoCustomToolBarItem

+ (JBoCustomToolBarItem*) toolBarItemWithTitle:(NSString *)title image:(UIImage *)image
{
    JBoCustomToolBarItem *barItem = [[JBoCustomToolBarItem alloc] init];
    barItem.title = title;
    barItem.image = image;
    return [barItem autorelease];
}

- (void)dealloc
{
    [_title release];
    [_image release];
    
    [super dealloc];
}

@end


@implementation JBoCustomToolBar

- (id)initWithFrame:(CGRect)frame items:(NSArray *)items
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.barImtes = [NSMutableArray arrayWithArray:items];
        [self initilazation];
        [self reloadItems];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if(self)
    {
        [self initilazation];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        [self initilazation];
    }
    return self;
}

- (void)initilazation
{
    self.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    self.titleColor = [UIColor blackColor];
    self.separatorColor = [UIColor lightGrayColor];
    self.separatorWidth = _lineWidth_;
    _selectedIndex = NSNotFound;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_titleColor release];
    [_titleSelectedColor release];
    [_barImtes release];
    [_separatorColor release];
    [_titleFont release];
    
    [_separatorLine release];
    
    [super dealloc];
}

#pragma mark- property

- (void)setTitleFont:(UIFont *)titleFont
{
    if(_titleFont != titleFont)
    {
        [_titleFont release];
        _titleFont = [titleFont retain];
        for(NSInteger i = 0;i < self.barImtes.count;i ++)
        {
            UIButton *button = [self buttonForIndex:i];
            button.titleLabel.font = titleFont;
        }
    }
}

- (void)setTitleSelectedColor:(UIColor *)titleSelectedColor
{
    if(_titleSelectedColor != titleSelectedColor)
    {
        [_titleSelectedColor release];
        _titleSelectedColor = [titleSelectedColor retain];
        for(NSInteger i = 0;i < self.barImtes.count;i ++)
        {
            UIButton *button = [self buttonForIndex:i];
            [button setTitleColor:_titleSelectedColor forState:UIControlStateSelected];
        }
    }
}

- (void)setSelectedIndex:(NSInteger)selectedIndex
{
    if(_selectedIndex != selectedIndex)
    {
        UIButton *button = [self buttonForIndex:_selectedIndex];
        button.selected = NO;
        
        _selectedIndex = selectedIndex;
        button = [self buttonForIndex:_selectedIndex];
        button.selected = YES;
    }
}

#pragma mark- public method

- (UIButton*)buttonForIndex:(NSInteger) index
{
    NSInteger tag = index + _buttonStartTag_;
    UIButton *button = (UIButton*)[self viewWithTag:tag];
    return button;
}

/**通过下标设置按钮的标题
 */
- (void)setTitle:(NSString *)title forIndex:(NSInteger)index
{
    if(index < self.barImtes.count)
    {
        JBoCustomToolBarItem *barItem = [self.barImtes objectAtIndex:index];
        barItem.title = title;
        
        UIButton *button = [self buttonForIndex:index];
        [button setTitle:title forState:UIControlStateNormal];
    }
}

/**通过下标设置按钮的标题颜色
 */
- (void)setTitleColor:(UIColor *)titleColor forIndex:(NSInteger)index
{
    UIButton *button = [self buttonForIndex:index];
    [button setTitleColor:titleColor forState:UIControlStateNormal];
}

/**通过下标设置按钮的图标
 */
- (void)setImage:(UIImage *)image forIndex:(NSInteger)index
{
    UIButton *button = [self buttonForIndex:index];
    [button setImage:image forState:UIControlStateNormal];
}

/**通过下标设置按钮的背景图片
 */
- (void)setBackgroundImage:(UIImage *)image forIndex:(NSInteger)index
{
    UIButton *button = [self buttonForIndex:index];
    [button setBackgroundImage:image forState:UIControlStateNormal];
}

/**删除按钮
 */
- (void)removeItemAtIndex:(NSInteger) index;
{
    if(index < self.barImtes.count)
    {
        [self.barImtes removeObjectAtIndex:index];
        [self reloadItems];
    }
}

/**通过下标获取按钮的标题
 *@param 按钮下标
 */
- (NSString*)buttonTitleForIndex:(NSInteger) index
{
    if(index < self.barImtes.count)
    {
        JBoCustomToolBarItem *barItem = [self.barImtes objectAtIndex:index];
        return barItem.title;
    }
    
    return nil;
}

/**重新加载按钮信息
 */
- (void)reloadItems
{
    for(UIView *view in self.subviews)
    {
        if(![view isEqual:self.separatorLine])
        {
            [view removeFromSuperview];
        }
    }
    
    CGFloat buttonWidth = (self.bounds.size.width - self.separatorWidth * (self.barImtes.count - 1)) / self.barImtes.count;
    
    if(!self.separatorLine)
    {
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, self.separatorWidth)];
        lineView.backgroundColor = self.separatorColor;
        [self addSubview:lineView];
        self.separatorLine = lineView;
        [lineView release];
    }
    
    
    for(NSInteger i = 0;i < self.barImtes.count;i ++)
    {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.tag = _buttonStartTag_ + i;
        
        JBoCustomToolBarItem *barItem = [self.barImtes objectAtIndex:i];
        
        [button setTitleColor:self.titleColor forState:UIControlStateNormal];
        [button setTitle:barItem.title forState:UIControlStateNormal];
        if(self.titleFont)
        {
           button.titleLabel.font = self.titleFont;
        }
        [button setImage:barItem.image forState:UIControlStateNormal];
        button.frame = CGRectMake(buttonWidth * i, 0, buttonWidth, self.bounds.size.height);
        [button addTarget:self action:@selector(buttonDidSelected:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:button];
        
        
        if(i + 1 != self.barImtes.count)
        {
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(buttonWidth * (i + 1), 0, self.separatorWidth, self.bounds.size.height)];
            lineView.backgroundColor = self.separatorColor;
            [self addSubview:lineView];
            [lineView release];
        }
    }
    
    [self bringSubviewToFront:self.separatorLine];
}

//点击某个按钮
- (void)buttonDidSelected:(UIButton*) button
{
    NSInteger index = button.tag - _buttonStartTag_;
    self.selectedIndex = index;
    if([self.delegate respondsToSelector:@selector(toolBar:didSelectedAtIndex:)])
    {
        [self.delegate toolBar:self didSelectedAtIndex:index];
    }
}

@end
