//
//  KingHeSearchContactForAddViewController.m
//  微喂
//
//  Created by kinghe005 on 13-9-14.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSearchContactForAddViewController.h"
#import "GTMBase64.h"
#import "JBoInputFormat.h"
#import "JBoUserOperation.h"
#import "JBoImageTextTool.h"
#import "JBoUserHeadImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoUserLookAndTellCell.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoHttpRequest.h"
#import "JBoCustomToolBar.h"
#import "JBoImageCacheTool.h"
#import <AddressBookUI/AddressBookUI.h>
#import <AddressBook/AddressBook.h>
#import "JBoNavigationViewController.h"
#import "JBoApplyContactInfo.h"
#import "JBoDatetimeTool.h"
#import "JBoUserInfoTableHeaderView.h"
#import "JBoBottomLoadingView.h"
#import "JBoLookAndTellOperation.h"
#import "JBoAddContactViewController.h"
#import "JBoCloudAddressBookOperation.h"
#import "JBoCloudAddressBookGroupInfoViewController.h"
#import "JBoCloudAddressBookProblemInputView.h"
#import "JBoCloudAddressBookGroupInfo.h"
#import "JBoUserInfoViewController.h"
#import "JBoActionSheet.h"
#import "JBoSetupPrivacyViewController.h"
#import "JBoComplaintViewController.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoAppointmentAddViewController.h"
#import "JBoSceneMakingInfo.h"
#import "JBoAppointmentInfo.h"
#import "JBoAppointmentOperation.h"
#import "JBoAttentionOperation.h"

#undef _controlInterval_
#undef _controlHeight_

#define _controlInterval_ 10
#define _controlHeight_ 30
#define _padding_ 20
#define _cellHeight_ 40

//获取个人信息tag
#define _getUserInfoTag_ 2

//获取预约次数
#define _appointmentTag_ 1

//获取关注状态tag
#define _getAttenttionTag_ 3

//获取用户云名片夹验证问题 tag
#define _getCloudAddressBookProblemTag_ 4

static NSString *const addFriend = @"加为好友";
static NSString *const addCloudAddressBook = @"加入云名片夹";
static NSString *const saveTolocalAddressBook = @"保存";
static NSString *const addCloudURL = @"添加云名片链接";
static NSString *const attention = @"关注";
static NSString *const cancelAttention = @"取消关注";


@interface JBoSearchContactForAddViewController ()<XMPPStreamDelegate,JBoUserLookAndTellCellDelegate,JBoHttpRequestDelegate,JBoCustomToolBarDelegate,ABUnknownPersonViewControllerDelegate,JBoUserInfoTableHeaderViewDelegate,JBoCloudAddressBookGroupInfoViewControllerDelegate,JBoCloudAddressBookProblemInputDelegate,JBoActionSheetDelegate>

{
    //加载数据
    JBoBottomLoadingView *_bottomLoadingView;
}

//底部菜单栏
@property(nonatomic,retain) JBoCustomToolBar *toolBar;

//添加好友验证信息
@property(nonatomic,copy) NSString *statusInfo;

//表头
@property(nonatomic,retain) JBoUserInfoTableHeaderView *tableHeaderView;

//网络请求队列
@property(nonatomic,retain) ASINetworkQueue *queue;

//请求队列是否请求成功
@property(nonatomic,assign) BOOL queueSuccess;

//云名片夹验证问题
@property(nonatomic,retain) NSArray *cloudAddressBookProblemInfos;

//是否已通过问题验证
@property(nonatomic,assign) BOOL passValidation;

//更多功能 标题和按钮
@property(nonatomic,retain) NSArray *moreTitleArray;
@property(nonatomic,retain) NSArray *moreImageArray;

//预约次数
@property(nonatomic,retain) JBoAppointmentListInfo *appointmentInfo;

@end

@implementation JBoSearchContactForAddViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"个人资料";
        
        self.isRequesting = NO;
        [self.appDelegate.xmpp.xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        self.operationType = JBoUserOperationTypeAddContact;
        self.hasInfo = NO;
        
        self.type = JBoRosterOperationTypeDefault;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    [super setIsRequesting:isRequesting];
  //  self.appDelegate.dataLoadingView.hidden = !self.isRequesting;
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:self.isRequesting];
}

#pragma mark-内存管理
- (void)dealloc
{
    NSLog(@"JBoSearchContactForAddViewController dealloc");
    self.delegate = nil;
    
    [_userId release];
    [_email release];
    [_userDetailInfo release];
    
    [_bottomLoadingView release];
   
    [_toolBar release];
    [_statusInfo release];
    
    [_tableHeaderView release];
    
    [_queue reset];
    [_queue release];
    
    [_cloudAddressBookProblemInfos release];
    
    [_moreImageArray release];
    [_moreTitleArray release];
    
    [super dealloc];
}

#pragma mark-视图消失出现
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate.xmpp.xmppStream removeDelegate:self];
}

#pragma mark-xmppstream代理

- (void)xmppStream:(XMPPStream *)sender didFailToSendPresence:(XMPPPresence *)presence error:(NSError *)error
{
    NSLog(@"add contact fail to send presence");
    self.isRequesting = NO;
    [self alertNetworkMsg:@"请重试"];
}

- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    NSLog(@"JBoSearchContactForAddViewController contact receive presence");
    
    NSString *type = [presence attributeStringValueForName:_xmppType_];
    
    if([type isEqualToString:_xmppError_])
    {
        self.isRequesting = NO;
        NSXMLElement *errorElement = [presence elementForName:_xmppError_];
        NSString *code = [errorElement attributeStringValueForName:_xmppErrorCode_];
        
        NSString *alertMsg = nil;
        if([code isEqualToString:_xmpp406Error_])
        {
            alertMsg = @"该用户已是您的好友了";
        }
        else
        {
            alertMsg = [NSString stringWithFormat:@"%@请重试",_alertMsgWhenBadNetwork_];
        }
        
        [self alertMsg:alertMsg];
        
        return;
    }
    
    NSString *success = [[presence elementForName:_xmppSuccess_] stringValue];
    if(success)
    {
        self.isRequesting = NO;
        
        NSString *alertMsg = nil;

        alertMsg = @"已向对方发送请求，请耐心等候";
        JBoApplyContactInfo *info = [[JBoApplyContactInfo alloc] init];
        info.userId = self.userDetailInfo.rosterInfo.username;
        info.name = self.userDetailInfo.rosterInfo.name;
        info.sex = self.userDetailInfo.rosterInfo.sex;
        info.role = self.userDetailInfo.rosterInfo.role;
        info.headImageURL = self.userDetailInfo.rosterInfo.imageURL;
        info.time = [JBoDatetimeTool getCurrentTime];
        info.presence = self.userDetailInfo.rosterInfo.presence;
        info.jid = self.userDetailInfo.rosterInfo.jid;
        info.statusInfo = self.statusInfo;
        
        
        [[NSNotificationCenter defaultCenter] postNotificationName:_applyContactNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:info forKey:_applyContactID_]];
        [info release];
        
        [self alertMsg:alertMsg];
    }
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addToBlackListIdentifier_])
    {
        [self alertNetworkMsg:@"添加至黑名单失败"];
        return;
    }
    
    
    if([identifier isEqualToString:_removeBlackListIdentifier_])
    {
        [self alertNetworkMsg:@"移出黑名单失败"];
        return;
    }
    
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        self.isRequesting = NO;
        [self alertNetworkMsg:@"获取日志失败"];
         [self.tableView setExtraCellLineHidden];
        return;
    }
    
    self.isRequesting = NO;
    
    if([identifier isEqualToString:_addAttentionIdentifier_])
    {
        [self alertNetworkMsg:@"关注失败"];
        return;
    }
    
    if([identifier isEqualToString:_cancelAttentionIdentifier_])
    {
        [self alertNetworkMsg:@"取消关注失败"];
        return;
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    
    if([identifier isEqualToString:_addToBlackListIdentifier_])
    {
        self.isRequesting = NO;
        if([JBoUserOperation getAddBlackListFromData:data])
        {
            //通知通讯录更新
            NSNumber *number = [NSNumber numberWithInteger:JBoContactMoreOperationTypeAddBlacklist];
            
            NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:number, _addressBookUpdateType_, self.userDetailInfo.rosterInfo, _addressBookUpdateRosterInfo_, nil];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:_addressBookUpdateNotification_ object:self userInfo:dic];
            
            [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
        }
        return;
    }
    
    if([identifier isEqualToString:_removeBlackListIdentifier_])
    {
        self.isRequesting = NO;
        BOOL success = NO;
        JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getRemoveBlackListFromData:data removeSuccess:&success];
        if(success)
        {
            if(userDetailInfo)
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:_addressBookUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithBool:YES], _addressBookUpdateIsFriend_, userDetailInfo.rosterInfo, _addressBookUpdateRosterInfo_, [NSNumber numberWithInteger:JBoContactMoreOperationTypeRemoveBlacklist], _addressBookUpdateType_, nil]];
            }
        }
        
        [self alertMsg:@"移出黑名单成功"];
        [self.appDelegate.blackListArray removeObject:self.userDetailInfo.rosterInfo.username];
        
        return;
    }
    
    if([identifier isEqualToString:_getUserLookAndTellIdentifier_])
    {
        self.isRequesting = NO;
        BOOL needScroll = self.infoArray.count == 0;
        NSMutableArray *infoArray = [JBoLookAndTellOperation getUserLookAndTellInfoFromData:data multiInfo:self.multisInfoDic offlineCache:nil];
        self.hasInfo = infoArray.count != 0;
        if(infoArray != nil)
        {
            [self.infoArray addObjectsFromArray:infoArray];
        }
        else
        {
            self.hasInfo = NO;
        }
        
        if(!self.tableView)
        {
            [self loadInitView];
        }
        else
        {
            [self.tableView reloadData];
        }
        
        [_tableHeaderView lookAndTellDidLoad:self.infoArray.count != 0];
        if(needScroll && self.infoArray.count > 0)
        {
            [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:YES];
        }
        [self.tableView setExtraCellLineHidden];
        
        return;
    }
    
    self.isRequesting = NO;
    if([identifier isEqualToString:_addAttentionIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            self.userDetailInfo.attention = YES;
            [self.toolBar setTitle:@"取消关注" forIndex:self.toolBar.barImtes.count - 1];
            [self alertMsg:@"关注成功"];
            [[NSNotificationCenter defaultCenter] postNotificationName:_addAttentionNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:self.userDetailInfo forKey:_attentionUserInfo_]];
        }
        return;
    }
    
    if([identifier isEqualToString:_cancelAttentionIdentifier_])
    {
        if([JBoUserOperation isSuccess:data])
        {
            self.userDetailInfo.attention = NO;
            [self.toolBar setTitle:@"关注" forIndex:self.toolBar.barImtes.count - 1];
            [self alertMsg:@"已取消关注"];
            [[NSNotificationCenter defaultCenter] postNotificationName:_cancelAttentionNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:self.userDetailInfo forKey:_attentionUserInfo_]];
        }
        return;
    }
}

//获取用户验证问题等信息
- (void)getUserInfo
{
    
    self.queueSuccess = YES;
    self.queue = [ASINetworkQueue queue];
    [self.queue setDelegate:self];
    [self.queue setQueueDidFinishSelector:@selector(queueDidFinish:)];
    [self.queue setRequestDidFinishSelector:@selector(requestDidFinish:)];
    [self.queue setRequestDidFailSelector:@selector(requestDidFail:)];
    
    NSString *userId = self.userDetailInfo.rosterInfo.username;
    
    //获取云名片夹验证问题
    ASIHTTPRequest *reqeust = [JBoHttpRequest requestWithURL:[JBoCloudAddressBookOperation getCloudAddressBookProblemWithUserId:userId] tag:_getCloudAddressBookProblemTag_];
    [self.queue addOperation:reqeust];
    
    //获取预约次数
    reqeust = [JBoHttpRequest requestWithURL:[JBoAppointmentOperation getUserAppointCountWithId:userId] tag:_appointmentTag_];
    [self.queue addOperation:reqeust];
    
    //获取用户的关注状态
    if(!self.userDetailInfo.attention)
    {
        reqeust = [JBoHttpRequest requestWithURL:[JBoAttentionOperation getAttentionStatus:userId] tag:_getAttenttionTag_];
        [self.queue addOperation:reqeust];
    }
    
    [self.queue go];
}

//对列请求完成
- (void)queueDidFinish:(ASINetworkQueue*) queue
{
    self.isRequesting = NO;
    if(self.queueSuccess)
    {
        self.userDetailInfo.appointmentCount = self.appointmentInfo.appointmentCount;
        self.userDetailInfo.notKeepAppointmentCount = self.appointmentInfo.notKeepAppointmentCount;
        self.userDetailInfo.beLateAppointmentCount = self.appointmentInfo.beLateAppointmentCount;
        self.appointmentInfo = nil;
        
        [self loadInitView];
    }
    else
    {
        [self alertNetworkMsg:@"获取个人资料失败"];
    }
    [self.queue reset];
    self.queue = nil;
}

//某个请求完成
- (void)requestDidFinish:(ASIHTTPRequest*) request
{
    NSData *data = [[NSData alloc] initWithContentsOfFile:request.downloadDestinationPath];
    switch (request.tag)
    {
        case _getCloudAddressBookProblemTag_ :
        {
            self.cloudAddressBookProblemInfos = [JBoCloudAddressBookOperation getCloudAddressBookProblemFromData:data];
        }
            break;
        case _appointmentTag_ :
        {
            self.appointmentInfo = [JBoAppointmentOperation getUserAppointCountFromData:data];
        }
            break;
        default:
            break;
    }
    
    [data release];
    
    //删除临时文件
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
}

//某个队列请求失败
- (void)requestDidFail:(ASIHTTPRequest*) request
{
    if(request.downloadDestinationPath)
    {
        [[NSFileManager defaultManager] removeItemAtPath:request.downloadDestinationPath error:nil];
    }
    self.queueSuccess = NO;
}

#pragma mark-功能更多按钮的方法

- (void)moreBarButtonItemAction
{
    //创建自定义actionSheet

    NSString *blackListTitle = [self.appDelegate.blackListArray containsObject:self.userDetailInfo.rosterInfo.username] ? @"移出黑名单" : @"添加至黑名单";
        //更多功能
    self.moreTitleArray = [[[NSArray alloc] initWithObjects:addCloudAddressBook, @"设置隐私", blackListTitle, @"投诉", nil] autorelease];
    
    UIImage *addImage = [UIImage imageNamed:@"addToCloud.png"];
    UIImage *setupPrivacyImage = [UIImage imageNamed:@"setupPrivacy.png"];
    UIImage *blackListImage = [UIImage imageNamed:@"backList.png"];
    UIImage *complaintImage = [UIImage imageNamed:@"complaint.png"];
        
    self.moreImageArray = [[[NSArray alloc] initWithObjects:addImage, setupPrivacyImage, blackListImage, complaintImage, nil] autorelease];

    self.sharing = NO;
    JBoActionSheet *myActionSheet = [[JBoActionSheet alloc] initWithItems:_moreImageArray.count delegate:self];
    [myActionSheet show];
    [myActionSheet release];
}

#pragma mark-JBoActionSheet代理

- (CGFloat)actionSheet:(JBoActionSheet *)actionSheet heightForRowAtIndex:(NSInteger)index
{
    if(self.sharing)
    {
        return [JBoActionSheet defaultCellHeight];
    }
    else
    {
        return 90.0;
    }
}

- (JBoCustomActionSheetCell*)cellForActionSheet:(JBoActionSheet *)actionSheet index:(NSInteger)index
{
    if(self.sharing)
    {
        return [super cellForActionSheet:actionSheet index:index];
    }
    else
    {
        JBoCustomActionSheetCell *cell = [[JBoCustomActionSheetCell alloc] initWithImage:[_moreImageArray objectAtIndex:index] title:[_moreTitleArray objectAtIndex:index]];
        cell.textLabel.textColor = [UIColor blackColor];
        cell.index = index;
        return [cell autorelease];
    }
}

//功能更多关联方法
- (void)actionSheet:(JBoActionSheet *)actionSheet didSelectedIndex:(NSInteger)index
{
    if(self.sharing)
    {
        [super actionSheet:actionSheet didSelectedIndex:index];
        return;
    }
    switch (index)
    {
        case 1 :
        {
            JBoSetupPrivacyViewController *setupPrivacyVC = [[JBoSetupPrivacyViewController alloc] init];
            setupPrivacyVC.userDetailInfo = self.userDetailInfo;
            [self.navigationController pushViewController:setupPrivacyVC animated:YES];
            [setupPrivacyVC release];
        }
            break;
        case 0 :
        {
            [self addToCloudAddressBook];
        }
            break;
        case 2 :
        {
            NSString *message = nil;
            NSString *title = nil;
            
            if([self.appDelegate.blackListArray containsObject:self.userDetailInfo.rosterInfo.username])
            {
                title = @"移出黑名单";
                message = [NSString stringWithFormat:@"确定要把 %@ 移出黑名单？", self.userDetailInfo.rosterInfo.name];
            }
            else
            {
                title = @"加入黑名单";
                message = [NSString stringWithFormat:@"确定要把 %@ 加入黑名单？", self.userDetailInfo.rosterInfo.name];
            }
            
            UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:title message:message delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", @"取消", nil];
            alerView.delegate = self;
            [alerView show];
            [alerView release];
            break;
        }
        case 3 :
        {
            JBoComplaintViewController *complaintVC = [[JBoComplaintViewController alloc] init];
            complaintVC.userId = self.userDetailInfo.rosterInfo.username;
            JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:complaintVC];
            [self.appDelegate.window.rootViewController presentViewController:nav animated:YES completion:nil];
            [nav release];
            [complaintVC release];
        }
            break;
    }
    
    [actionSheet disMiss];
}


#pragma mark-加载视图

- (void)back
{
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(loadUserLookAndTellInfo) object:nil];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.backItem = YES;
    
    //获取用户信息操作类型
    JBoAddContactViewController *addVC = nil;
    for(UIViewController *viewController in self.navigationController.viewControllers)
    {
        if([viewController isKindOfClass:[JBoAddContactViewController class]])
        {
            addVC = (JBoAddContactViewController*)viewController;
            break;
        }
    }
    
    if(addVC != nil)
    {
        self.type = addVC.operationType;
        self.delegate = addVC.delegate;
    }

    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];

    if(self.userId || self.email)
    {
       // self.isRequesting = YES;
        JBoAsyncDownloadUserInfoOperation *asyncDownload = [[JBoAsyncDownloadUserInfoOperation alloc] init];
        __block JBoAsyncDownloadUserInfoOperation *blockAsyncDownload = asyncDownload;
        
        blockAsyncDownload.completionHandler = ^(void)
        {
            self.userDetailInfo = blockAsyncDownload.userDetailInfo;
            if(self.userDetailInfo)
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:_userInfoUpdateNotification_ object:self userInfo:[NSDictionary dictionaryWithObject:self.userDetailInfo.rosterInfo forKey:_userInfoUpdateKey_]];
                [self getUserInfo];
            }
            else
            {
                [self alertNetworkMsg:@"获取个人资料失败"];
            }
            
            [blockAsyncDownload release];
        };
        
        if([NSString isEmpty:self.email])
        {
            [asyncDownload downloadWithUserId:self.userId];
        }
        else
        {
            [asyncDownload downloadWithEmail:self.email];
        }
    }
    else
    {
        self.isRequesting = YES;
        [self getUserInfo];
    }
}

#pragma mark-

- (void)userInfoTableHeaderViewNeedSeeLookAndTell:(JBoUserInfoTableHeaderView *)header
{
    if(self.isRequesting)
    {
        return;
    }
    
    if(!_bottomLoadingView)
    {
        //创建加载更多视图
        _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
        _bottomLoadingView.backgroundColor = [UIColor clearColor];
    }
    
    self.tableView.tableFooterView = _bottomLoadingView;
    CGFloat y = _tableHeaderView.height + _bottomLoadingView.height - self.tableView.height;
    
    [self.tableView setContentOffset:CGPointMake(0, y) animated:YES];
    [self performSelector:@selector(loadUserLookAndTellInfo) withObject:nil afterDelay:0.25];
}

- (void)loadUserLookAndTellInfo
{
    if(self.isRequesting)
        return;
    self.httpRequest.identifier = _getUserLookAndTellIdentifier_;
    self.isRequesting = YES;
    [self.httpRequest downloadWithURL:[JBoLookAndTellOperation getUserLookAndTellInfoWithUserId:self.userDetailInfo.rosterInfo.username pageNum:self.pageIndex rows:_lookAndTellPageSize_ visible:_lookAndTellVisiblePublic_]];
}

- (void)loadInitView
{
    if(self.tableView)
        return;
    
    JBoUserDetailInfo *myInfo = [JBoUserOperation getUserDetailInfo];
    
    if(![myInfo.rosterInfo.username isEqualToString:self.userDetailInfo.rosterInfo.username] && ![self.userDetailInfo.rosterInfo.username isEqualToString:_linklnkUserId_])
    {
        //创建功能更多按钮
        if(self.black)
        {
            [self setRightBarItemWithIcon:[UIImage imageNamed:@"moreSetupBlack.png"] action:@selector(moreBarButtonItemAction)];
        }
        else
        {
            [self setRightBarItemWithIcon:[UIImage imageNamed:@"moreSetup.png"] action:@selector(moreBarButtonItemAction)];
        }
    }
    
    self.isRequesting = NO;
    self.appDelegate.dataLoadingView.hidden = YES;
    
    //联系人信息
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.separatorColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0];
    [self.view addSubview:tableView];
    
    [tableView setExtraCellLineHidden];
    self.tableView = tableView;
    [tableView release];
    
    JBoUserRelation relation = JBoUserRelationStranger;
    if(self.scanning)
        relation = JBoUserRelationQRCodeCard;
    
    JBoUserInfoTableHeaderView *tableHeaderView = [[JBoUserInfoTableHeaderView alloc] initWithUserDetailInfo:self.userDetailInfo relation:relation];
    tableHeaderView.black = self.black;
    tableHeaderView.delegate = self;
    tableHeaderView.navigationController = self.navigationController;
    self.tableView.tableHeaderView = tableHeaderView;
    self.tableHeaderView = tableHeaderView;
    [tableHeaderView release];
  
    if(![JBoUserOperation isSelfWithJid:self.userDetailInfo.rosterInfo.jid] || self.type == JBoRosterOperationTypeLinkCloundURL)
    {
        NSMutableArray *items = [NSMutableArray array];
        
        if(self.type != JBoRosterOperationTypeLinkCloundURL)
        {
            if(![JBoUserOperation isMyFriend:self.userDetailInfo.rosterInfo.username])
            {
                [items addObject:[JBoCustomToolBarItem toolBarItemWithTitle:addFriend image:nil]];
                [items addObject:[JBoCustomToolBarItem toolBarItemWithTitle:makeAppointment image:nil]];
            }
            
            switch (self.operationType)
            {
                case JBoUserOperationTypeLocalAddress :
                    [items addObject:[JBoCustomToolBarItem toolBarItemWithTitle:saveTolocalAddressBook image:nil]];
                    break;
                    
                default:
                    break;
            }
           // [items addObject:[JBoCustomToolBarItem toolBarItemWithTitle:addCloudAddressBook image:nil]];
        }
        else
        {
            [items addObject:[JBoCustomToolBarItem toolBarItemWithTitle:addCloudURL image:nil]];
        }
        
        if(items.count != 0)
        {
            if(items.count >= 2)
            {
                [items addObject:[JBoCustomToolBarItem toolBarItemWithTitle:attention image:nil]];
            }
            
            JBoCustomToolBar *toolBar= [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, _height_ - _statuBarHeight_ - _navgateBarHeight_ - _defaultToolBarHeight_, _width_, _defaultToolBarHeight_) items:items];
            toolBar.delegate = self;
            toolBar.titleFont = [UIFont boldSystemFontOfSize:14.0];
            [self.view addSubview:toolBar];
            [toolBar release];
            
            self.toolBar = toolBar;
            if(self.userDetailInfo.attention)
            {
                [self.toolBar setTitle:cancelAttention forIndex:items.count - 1];
            }
            
            self.tableView.frame = CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_ - self.toolBar.height);
        }
        
        //如果用户不是实名认证的用户
        if(self.type == JBoRosterOperationTypeLinkCloundURL && self.userDetailInfo.rosterInfo.role == _rosterRoleNormal_)
        {
            UIButton *button = [self.toolBar buttonForIndex:0];
            [button setTitleColor:[UIColor grayColor] forState:UIControlStateDisabled];
            button.enabled = NO;
        }
    }
}

#pragma mark-JBoCustomToolBar代理

- (void)toolBar:(JBoCustomToolBar *)toolBar didSelectedAtIndex:(NSInteger)index
{
    if(self.isRequesting)
        return;
    
    NSString *title = [toolBar buttonTitleForIndex:index];
    
    if([title isEqualToString:addFriend])
    {
        [self addButtonAction];
    }
    else if([title isEqualToString:saveTolocalAddressBook])
    {
        [self saveToLocalAddress];
    }
    else if([title isEqualToString:addCloudURL])
    {
        if([self.delegate respondsToSelector:@selector(viewController:didSelectRosterInfo:)])
        {
            [self.delegate viewController:self didSelectRosterInfo:self.userDetailInfo.rosterInfo];
        }
    }
    else if([title isEqualToString:addCloudAddressBook])
    {
        [self addToCloudAddressBook];
    }
    else if([title isEqualToString:makeAppointment])
    {
        [self makeAnAppointment];
    }
    else if([title isEqualToString:attention])
    {
        [self attentionAction];
    }
    else if([title isEqualToString:cancelAttention])
    {
        [self attentionAction];
    }
}

//加关注
- (void)attentionAction
{
    if(self.isRequesting)
        return;
    
    if(!self.userDetailInfo.attention)
    {
        self.httpRequest.identifier = _addAttentionIdentifier_;
        self.isRequesting = YES;
        [self.httpRequest downloadWithURL:[JBoAttentionOperation AddAttentionUser:self.userDetailInfo.rosterInfo.username]];
    }
    else
    {
        self.httpRequest.identifier = _cancelAttentionIdentifier_;
        self.isRequesting = YES;
        [self.httpRequest downloadWithURL:[JBoAttentionOperation cancelAttentionUser:self.userDetailInfo.rosterInfo.username]];
    }
}

//请求添加好友
- (void)addButtonAction
{
    if([JBoUserOperation isSelfWithJid:self.userDetailInfo.rosterInfo.jid])
    {
        [JBoUserOperation alertMsg:@"该用户已是您的好友"];
        return;
    }
    
    
    UIAlertView *alerView = [[UIAlertView alloc] initWithTitle:@"请求信息" message:@"" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"取消", @"确定", nil];
    alerView.alertViewStyle = UIAlertViewStylePlainTextInput;
    alerView.delegate = self;
    UITextField *textField = [alerView textFieldAtIndex:0];
    textField.placeholder = [NSString stringWithFormat:@"%d字以内",_inputFormatStatus_];
    [alerView show];
    [alerView release];
}

//预约
- (void)makeAnAppointment
{
    JBoUserDetailInfo *userDetailInfo = [JBoUserDetailInfo userDetailInfoFromUserDetaults];
    if(userDetailInfo.rosterInfo.role == 0)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[NSString stringWithFormat:@"预约%@", realNameAuthenTitle] message:realNameAuthenMessage delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", goToRealNameAuthen, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    JBoSceneMakingInfo *info = [[[JBoSceneMakingInfo alloc] init] autorelease];
    info.userDetailInfo = self.userDetailInfo;
    
    JBoAppointmentAddViewController *add = [[JBoAppointmentAddViewController alloc] initWithInfo:info mapInfo:nil target:JBoAppointmentTargetToStranger];
    [self.navigationController pushViewController:add animated:YES];
    [add release];
}

//移出黑名单
- (void)removeBlacklist:(UIButton*) button
{
    
}

//保存到手机通讯录
- (void)saveToLocalAddress
{
    ABUnknownPersonViewController *unknownPersonVC = [[ABUnknownPersonViewController alloc] init];
    unknownPersonVC.unknownPersonViewDelegate = self;
    
    ABRecordRef person = ABPersonCreate();
    [self getPerson:person];
    unknownPersonVC.displayedPerson = person;
    CFRelease(person);
    
    unknownPersonVC.allowsAddingToAddressBook = YES;
    unknownPersonVC.allowsActions = YES;

    [self.navigationController pushViewController:unknownPersonVC animated:YES];
   
    [unknownPersonVC release];
}


#pragma mark-ABUnknownPersonViewController代理

- (BOOL)unknownPersonViewController:(ABUnknownPersonViewController *)personViewController shouldPerformDefaultActionForPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
    return NO;
}

- (void)unknownPersonViewController:(ABUnknownPersonViewController *)unknownCardViewController didResolveToPerson:(ABRecordRef)person
{
    [unknownCardViewController.navigationController popViewControllerAnimated:YES];
}

- (void)getPerson:(ABRecordRef) person
{
   
    NSString *name = self.userDetailInfo.rosterInfo.name;
    if(![NSString isEmpty:name])
    {
        ABRecordSetValue(person, kABPersonLastNameProperty, (CFStringRef) name, NULL);
    }
    
    NSString *email = self.userDetailInfo.email;
    if(![NSString isEmpty:email])
    {
        ABMultiValueRef value = ABMultiValueCreateMutable(kABMultiStringPropertyType);
        BOOL add = ABMultiValueAddValueAndLabel(value, (CFStringRef) email, kABWorkLabel, NULL);
        if(add)
        {
            ABRecordSetValue(person, kABPersonEmailProperty, value, NULL);
        }
        
        CFRelease(value);
    }
    
    ABMultiValueRef phoneValue = ABMultiValueCreateMutable(kABMultiStringPropertyType);
    
    NSString *phone = self.userDetailInfo.phoneNum;
    if(![NSString isEmpty:phone] && self.userDetailInfo.phoneState)
    {
        ABMultiValueAddValueAndLabel(phoneValue, (CFStringRef) phone, kABPersonPhoneMobileLabel, NULL);
    }
    
    NSString *tel = self.userDetailInfo.rosterInfo.enterpriseTelePhone;
    if(![NSString isEmpty:tel])
    {
        ABMultiValueAddValueAndLabel(phoneValue, (CFStringRef) tel, kABPersonPhoneMainLabel, NULL);
    }
    
    ABRecordSetValue(person, kABPersonPhoneProperty, phoneValue, NULL);
    CFRelease(phoneValue);
    
    NSString *address = [NSString isEmpty:self.userDetailInfo.rosterInfo.enterpriseAddr] ? self.userDetailInfo.area : self.userDetailInfo.rosterInfo.enterpriseAddr;
    if(![NSString isEmpty:address])
    {
        ABMultiValueRef value = ABMultiValueCreateMutable(kABMultiStringPropertyType);
        NSDictionary *values = [NSDictionary dictionaryWithObject:address forKey:(NSString*)kABPersonAddressCountryKey];
        
        BOOL add = ABMultiValueAddValueAndLabel(value, (CFDictionaryRef) values, kABHomeLabel, NULL);
        if(add)
        {
            ABRecordSetValue(person, kABPersonAddressProperty, value, NULL);
        }
        
        CFRelease(value);
    }
    
    
    NSString *organizer = self.userDetailInfo.rosterInfo.enterpriseName;
    if(![NSString isEmpty:organizer])
    {
        ABRecordSetValue(person, kABPersonOrganizationProperty, (CFStringRef)organizer, NULL);
    }
    
    NSString *title = self.userDetailInfo.vocation;
    if(![NSString isEmpty:title])
    {
        ABRecordSetValue(person, kABPersonJobTitleProperty, (CFStringRef)title, NULL);
    }
    
//    NSString *url = [_userInfo objectForKey:urlChinese];
//    if(![NSString isEmpty:url])
//    {
//        ABMultiValueRef value = ABMultiValueCreateMutable(kABMultiStringPropertyType);
//        BOOL add = ABMultiValueAddValueAndLabel(value, (CFStringRef) url, kABPersonHomePageLabel, NULL);
//        if(add)
//        {
//            ABRecordSetValue(person, kABPersonURLProperty, value, NULL);
//        }
//        CFRelease(value);
//    }
    
    NSString *note = self.userDetailInfo.rosterInfo.presence;
    if(![NSString isEmpty:note])
    {
        ABRecordSetValue(person, kABPersonNoteProperty, (CFStringRef)note, NULL);
    }
    
}

#pragma mark- 云名片夹

//添加到云名片夹
- (void)addToCloudAddressBook
{
    JBoUserDetailInfo *info = [JBoUserOperation getUserDetailInfo];
    if([NSString isEmpty:info.phoneNum] && [NSString isEmpty:info.rosterInfo.enterpriseTelePhone])
    {
        UIAlertView *aletView = [[UIAlertView alloc] initWithTitle:@"请先填写手机号码或座机号码" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:@"取消", @"去填写", nil];
        [aletView show];
        [aletView release];
        return;
    }
    
    if([self.userDetailInfo.rosterInfo.username isEqualToString:info.rosterInfo.username])
    {
        [self alertMsg:@"您的云名片夹已存在该用户"];
        return;
    }
    
    if(self.cloudAddressBookProblemInfos.count > 0 && !self.passValidation)
    {
        CGRect frame = self.view.bounds;
        frame.origin.y = 0;
        
        JBoCloudAddressBookProblemInputView *inputView = [[JBoCloudAddressBookProblemInputView alloc] initWithFrame:frame infos:self.cloudAddressBookProblemInfos style:JBoCloudAddressBookProblemInputStyleReply];
        inputView.inputDelegate = self;
        [inputView showInView:self.view];
        [inputView release];
    }
    else
    {
        [self selectCloudAddressBookGroup];
    }
}

//选择云名片夹分组
- (void)selectCloudAddressBookGroup
{
    JBoCloudAddressBookGroupInfoViewController *group = [[JBoCloudAddressBookGroupInfoViewController alloc] init];
    group.black = self.black;
    group.userDetailInfo = self.userDetailInfo;
    [self.navigationController pushViewController:group animated:YES];
    [group release];
}


#pragma mark- JBoCloudAddressBookProblemInputView 代理

- (void)cloudAddressBookProblemInputViewDidDismiss:(JBoCloudAddressBookProblemInputView *)inputView
{
    
}

- (void)cloudAddressBookProblemInputViewDidFinish:(JBoCloudAddressBookProblemInputView *)inputView
{
    self.passValidation = YES;
    [self selectCloudAddressBookGroup];
    [inputView dismiss];
}


#pragma mark-UIAlertView代理

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    
    if([title isEqualToString:@"取消"])
    {
        return;
    }
    
    if([title isEqualToString:@"去填写"])
    {
        JBoUserInfoViewController *userInfo = [[JBoUserInfoViewController alloc] init];
        userInfo.black = self.black;
        [self.navigationController pushViewController:userInfo animated:YES];
        [userInfo release];
        return;
    }
    
    
    if(alertView.alertViewStyle == UIAlertViewStylePlainTextInput)
    {
        if(buttonIndex == 1)
        {
            
            UITextField *textField = [alertView textFieldAtIndex:0];
            
            if(self.userDetailInfo.status && [NSString isEmpty:textField.text])
            {
                [self alertMsg:@"请求信息不能为空"];
                return;
            }
            
            if(textField.text.length > _inputFormatStatus_)
            {
                [self alertMsg:[NSString stringWithFormat:@"请求信息不能超过%d字",_inputFormatStatus_]];
            }
            else
            {
                self.isRequesting = YES;
                self.statusInfo = textField.text;
                if(![JBoUserOperation sendApplyInfoWithStatus:textField.text jid:self.userDetailInfo.rosterInfo.jid type:JBoAddBuddyTypeDefault])
                {
                    self.isRequesting = NO;
                }
            }
        }
    }
    else
    {
        if(self.isRequesting)
            return;
        if(buttonIndex == 0)
        {
            self.isRequesting = YES;
            if([self.appDelegate.blackListArray containsObject:self.userDetailInfo.rosterInfo.username])
            {
                self.httpRequest.identifier = _removeBlackListIdentifier_;
                [self.httpRequest downloadWithURL:[JBoUserOperation getRemoveBlackListURl:self.userDetailInfo.rosterInfo.username]];
            }
            else
            {
                self.httpRequest.identifier = _addToBlackListIdentifier_;
                [self.httpRequest downloadWithURL:[JBoUserOperation getAddBlackListURL:self.userDetailInfo.rosterInfo.username]];
            }
        }
    }
    
    if ([title isEqualToString:goToRealNameAuthen])
    {
        JBoRealNameAuthenViewController *realName = [[JBoRealNameAuthenViewController alloc] init];
        realName.black = self.black;
        [self.navigationController pushViewController:realName animated:YES];
        [realName release];
    }
}

#pragma mark-tableView 代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    return [self userLookAndTellHeightForIndexPath:indexPath style:info.operationInfo.style];
}


- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *mutliIdentifier = @"mutil";
    static NSString *shareLinkIdentifier = @"share";
    static NSString *shortMovieIdentifier = @"shortMovie";
    
    NSString *cellIdentifier = nil;
    JBoLookAndTellCellStyle style;
    
    JBoLookAndTellListInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cellIdentifier = shareLinkIdentifier;
            style = JBoLookAndTellCellStyleLinkShare;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cellIdentifier = shortMovieIdentifier;
            style = JBoLookAndTellCellStyleShortMovie;
        }
            break;
        default:
        {
            cellIdentifier = mutliIdentifier;
            style = JBoLookAndTellCellStyleDefault;
        }
            break;
    }
    
    JBoUserLookAndTellCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil)
    {
        cell = [[[JBoUserLookAndTellCell alloc] initWithCellStyle:style reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
        cell.statusImageLabel.hidden = YES;
        cell.msgOperationView.canComplaint = NO;
    }
    
    switch (info.type)
    {
        case _lookAndTellTypeShareLink_ :
        {
            cell.linkView.shareView.htmlTitleLabel.text = info.urlTitle;
            cell.linkView.shareURL = info.url;
            cell.linkView.srcArray = info.multiInfo;
        }
            break;
        case _lookAndTellTypeShortMovie_ :
        {
            cell.shareShortMovieView.srcArray = info.multiInfo;
        }
            break;
        default:
        {
            cell.multiImageTextView.hasMoreText = info.hasMoreText;
            cell.multiImageTextView.srcArray = info.multiInfo;
        }
            break;
    }
    
    cell.msgOperationView.index = indexPath.row;
    cell.msgOperationView.info = info;
    cell.msgOperationView.style = info.operationInfo.style;
    
    if(indexPath.row != 0)
    {
        JBoLookAndTellListInfo *listInfo = [self.infoArray objectAtIndex:indexPath.row - 1];
        cell.dateView.sameDay = [JBoDatetimeTool isOnTheSameDay:listInfo.date otherDay:info.date];
    }
    else
    {
        cell.dateView.sameDay = NO;
    }
    cell.dateView.time = info.date;
    
    return cell;
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(!self.hasInfo || self.isRequesting)
        return;
    if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
    {
        if(!_bottomLoadingView)
        {
            //创建加载更多视图
            _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            _bottomLoadingView.backgroundColor = [UIColor clearColor];
        }
 
        self.pageIndex ++;
        self.tableView.tableFooterView = _bottomLoadingView;
        [self loadUserLookAndTellInfo];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
