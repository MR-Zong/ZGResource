//
//  JBoAddressBookPersonInfo.m
//  linklnk
//
//  Created by kinghe005 on 14-11-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoAddressBookPersonInfo.h"

@implementation JBoAddressBookGroupInfo

- (void)dealloc
{
    [_title release];
    [_personInfos release];
    
    [super dealloc];
}

@end

@implementation JBoAddressBookPersonInfo

- (void)dealloc
{
    [_name release];
    [_phoneNums release];
    [_remark release];
    
    [super dealloc];
}

@end

