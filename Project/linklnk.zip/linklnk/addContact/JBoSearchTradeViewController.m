//
//  JBoSearchTradeViewController.m
//  连你
//
//  Created by kinghe005 on 14-1-16.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoSearchTradeViewController.h"
#import "JBoAuthListCell.h"
#import "JBoUserInfoSelectedViewController.h"
#import "JBoRosterCell.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoSearchContactForAddViewController.h"


@interface JBoSearchTradeViewController ()<JBoHttpRequestDelegate>
{
    //网络请求
    JBoHttpRequest *_httpRequest;
}

/**搜索结果，数组元素是 JBoRosterInfo
 */
@property(nonatomic,retain) NSMutableArray *infoArray;

/**选择的行业信息
 */
@property(nonatomic,retain) NSDictionary *vocationDic;

//是否正在搜索
@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoSearchTradeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"搜行业";
        
        _infoArray = [[NSMutableArray alloc] init];
        
        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.isRequesting = NO;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(vocationDidSelected:) name:_userDetailInfoDidSelectedNofitication_ object:nil];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
    }
}

#pragma mark- 通知

//选择某个行业
- (void)vocationDidSelected:(NSNotification*) notification
{
    NSDictionary *dic = [notification userInfo];
    self.vocationDic = [[dic allValues] objectAtIndex:0];
    //_vocationLabel.text = [[self.vocationDic allValues] objectAtIndex:0];
    [self.tableView reloadData];
    if([_httpRequest downloadWithURL:[JBoUserOperation getTradeSearchURL:[[self.vocationDic allKeys] objectAtIndex:0]]])
    {
        self.isRequesting = YES;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_infoArray release];

    [_vocationDic release];
    
    [_httpRequest release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:_userDetailInfoDidSelectedNofitication_ object:self];
    
    [super dealloc];
}

#pragma mark- 视图消失出现


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [self.appDelegate closeAlertView];
    }
}

#pragma mark- JBoHttpRequest delegate

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"搜索失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    NSMutableArray *array = [JBoUserOperation getTradeSearchFromData:data];
    if(array)
    {
        self.infoArray = array;
        [self.tableView reloadData];
    }
    
    if(self.infoArray.count == 0)
    {
        [JBoUserOperation alertMsg:@"暂时搜不到该行业的用户"];
    }
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.backItem = YES;
    
    [super initialization];
    [self.tableView setExtraCellLineHidden];
}


#pragma mark-tableview代理

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count + 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0)
    {
        return 40;
    }
    else
    {
        return _authCellHeight_;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row == 0)
    {
        static NSString *cellIdentifier = @"cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if(cell == nil)
        {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier] autorelease];
            UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"arrow@2x" ofType:_imageType_]];
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
            UIImageView *imageView = [[UIImageView alloc] initWithImage:image];
            cell.accessoryView = imageView;
            [imageView release];
            [image release];
        }
        cell.textLabel.text = @"行业";
        
        if(self.vocationDic != nil)
        {
            cell.detailTextLabel.text = [[self.vocationDic allValues] firstObject];
        }
        
        return cell;
    }
    else
    {
        static NSString *cellIdentifier = @"_cellDefault";  //联系人
        
        JBoRosterCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if(cell == nil)
        {
            cell = [[[JBoRosterCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
            cell.selectionStyle = UITableViewCellSelectionStyleGray;
        }
        
        JBoRosterInfo *rosterInfo = [_infoArray objectAtIndex:indexPath.row - 1];
        
        cell.nameLabel.text = rosterInfo.name;
        cell.nameLabel.sex = rosterInfo.sex;
        cell.headImageView.role = rosterInfo.role;
        [cell setPresence:rosterInfo.presence];
        
        cell.headImageView.sex = rosterInfo.sex;
        cell.headImageView.headImageURL = rosterInfo.imageURL;

        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if(indexPath.row == 0)
    {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        
        JBoUserInfoSelectedViewController *userInfoSelected = [[JBoUserInfoSelectedViewController alloc] init];
        userInfoSelected.userInfoType = JBoUserInfoTypeTrade;
        userInfoSelected.black = self.black;
        userInfoSelected.title = @"行业";
        [self.navigationController pushViewController:userInfoSelected animated:YES];
        [userInfoSelected release];
    }
    else
    {
        JBoRosterInfo *rosterInfo = [_infoArray objectAtIndex:indexPath.row - 1];
        JBoSearchContactForAddViewController *userInfoVC = [[JBoSearchContactForAddViewController alloc] init];
        userInfoVC.black = self.black;
        userInfoVC.userId = rosterInfo.username;
        [self.navigationController pushViewController:userInfoVC animated:YES];
        [userInfoVC release];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
