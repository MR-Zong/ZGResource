//
//  KingHeSearchContactViewController.m
//  微喂
//
//  Created by kinghe005 on 13-9-13.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoSearchContactViewController.h"
#import "JBoAlertView.h"
#import <QuartzCore/QuartzCore.h>
#import "JBoCheckInputText.h"
#import "JBoSearchContactForAddViewController.h"
#import "JBoUserOperation.h"
#import "JBoHttpRequest.h"
#import "JBoCheckInputText.h"


#define _controlInteval_ 10    //控件之间的间隔

@interface JBoSearchContactViewController ()<JBoHttpRequestDelegate>
{
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,assign) BOOL isRequesting;

@end

@implementation JBoSearchContactViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"搜账号";

        _httpRequest = [[JBoHttpRequest alloc] init];
        _httpRequest.delegate = self;
        
        self.isRequesting = NO;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        self.appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc {
  
    [_emailTextField release];
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-视图出现消失

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [_emailTextField becomeFirstResponder];
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.appDelegate closeAlertView];
}

#pragma mark-httpRequest代理
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"搜索失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    JBoUserDetailInfo *userDetailInfo = [JBoUserOperation getSearchEmailResultFromData:data];
    if(userDetailInfo != nil)
    {
        JBoSearchContactForAddViewController *searchContactForAddVC = [[JBoSearchContactForAddViewController alloc] init];
        searchContactForAddVC.userDetailInfo = userDetailInfo;
        searchContactForAddVC.black = self.black;
        [self.navigationController pushViewController:searchContactForAddVC animated:YES];
        [searchContactForAddVC release];
    }
    else
    {
        [JBoUserOperation alertMsg:@"账号不存在"];
    }
}

#pragma mark-加载视图

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //自定义返回按钮
    self.backItem = YES;
    
    self.view.backgroundColor = [UIColor colorWithRed:_mainColorValue_ green:_mainColorValue_ blue:_mainColorValue_ alpha:1.0];
    
    //手机号
    CGFloat x = 35.0;
    _emailTextField = [[UITextField alloc] initWithFrame:CGRectMake(x, _controlInteval_ * 3, _width_ - x * 2, 35.0)];
    _emailTextField.backgroundColor = [UIColor whiteColor];
    _emailTextField.layer.masksToBounds = YES;
    _emailTextField.layer.cornerRadius = 5.0;
    _emailTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _emailTextField.borderStyle = UITextBorderStyleNone;
    _emailTextField.placeholder = @"请输入账号";
    [_emailTextField setLeftViewWithImageName:@"account_icon" padding:8.0];
    [self.view addSubview:_emailTextField];

    
    //搜索
    UIImage *searchImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"long_btn_@2x" ofType:_imageType_]];
    
    UIButton *searchButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [searchButton setTitle:@"搜索" forState:UIControlStateNormal];
    searchButton.titleLabel.font = [UIFont systemFontOfSize:20.0];
    [searchButton setFrame:CGRectMake((_width_ - searchImage.size.width) / 2, _emailTextField.bottom + _controlInteval_, searchImage.size.width, searchImage.size.height)];
    [searchButton setBackgroundImage:searchImage forState:UIControlStateNormal];
    [searchButton addTarget:self action:@selector(searchtButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:searchButton];
    [searchImage release];
}

//搜索
- (void)searchtButtonAction:(id)sender
{
    if(self.isRequesting)
        return;
    if(![JBoCheckInputText isLinklnkId:_emailTextField.text])
    {
        [JBoUserOperation alertMsg:@"账号不合法"];
        return;
    }
    
    if([_httpRequest downloadWithURL:[JBoUserOperation getSearchEmail:[JBoUserOperation getEmailFromStr:_emailTextField.text]]])
    {
        self.isRequesting = YES;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
