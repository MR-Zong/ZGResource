//
//  KingHeAddContactViewController.h
//  微喂
//
//  Created by kinghe005 on 13-8-22.
//  Copyright (c) 2013年 kinghe. All rights reserved.
//

#import "JBoTableViewController.h"
#import "JBoRosterInfoDelegate.h"

/**好友、云名片夹用户添加 选项通道
 */
@interface JBoAddContactViewController : JBoTableViewController
{
    //tableView 数据源
    NSArray *_textArray;
}

/**对用户信息的操作类型
 */
@property(nonatomic,assign) JBoRosterOperationType operationType;

/** JBoRosterInfoDelegate 类型的代理
 */
@property(nonatomic,assign) id delegate;

@end
