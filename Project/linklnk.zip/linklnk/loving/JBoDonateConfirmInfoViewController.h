//
//  JBoDonateConfirmInfoViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**爱心捐物确认收货信息浏览
 */
@interface JBoDonateConfirmInfoViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>

/**捐物信息的Id
 */
@property(nonatomic,copy) NSString *Id;

/**导航栏标题是否为黑色
 */
@property(nonatomic,assign) BOOL black;

@end
