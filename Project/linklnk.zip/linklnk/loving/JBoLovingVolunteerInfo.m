//
//  JBoLovingVolunteerInfo.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingVolunteerInfo.h"

@implementation JBoLovingVolunteerInfo

- (void)dealloc
{
    [_date release];
    [super dealloc];
}

@end
