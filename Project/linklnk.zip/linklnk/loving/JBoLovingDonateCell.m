//
//  JBoLovingDonateCell.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingDonateCell.h"
#import "JBoBasic.h"

@implementation JBoLovingDonateCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouched:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_rightPadding_, _topPadding_, _headImageSize_, _headImageSize_)];
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [self.contentView addSubview:_headImageView];
        [tap release];
        
        _confirmButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_confirmButton setFrame:CGRectMake(_headImageView.frame.origin.x, _headImageView.frame.origin.y + _headImageView.frame.size.height + _controlInterval_, _headImageSize_, 35)];
        _confirmButton.titleLabel.font = [UIFont systemFontOfSize:12.0];
        [_confirmButton setTitle:@"确认收到" forState:UIControlStateNormal];
        [_confirmButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        [_confirmButton addTarget:self action:@selector(confirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_confirmButton];
        
        CGFloat width = _width_ - _headImageView.frame.origin.x - _headImageView.frame.size.width - _rightPadding_ * 2 - _controlInterval_;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _controlInterval_, _headImageView.frame.origin.y, width / 5 * 3, 30)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat x = _nameLabel.frame.origin.x - _nameLabel.frame.size.width;
        
        _dateLabel = [[JBoAttributedLabel alloc] initWithFrame:CGRectMake(x, _nameLabel.frame.origin.y, _width_ - x - _rightPadding_, _nameLabel.frame.size.height)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        [self.contentView addSubview:_dateLabel];
        

        _multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.origin.y + _nameLabel.frame.size.height + _controlInterval_, _multiSize_ * _imagesPerRows_ + _controlInterval_ * (_imagesPerRows_ - 1), _controlHeight_)];
        _multiImageView.delegate = self;
        [self.contentView addSubview:_multiImageView];
        
        _countLabel = [[UILabel alloc] initWithFrame:CGRectMake(_multiImageView.frame.origin.x, 0, _multiImageView.frame.size.width, 25)];
        _countLabel.backgroundColor = [UIColor clearColor];
        _countLabel.font = [UIFont systemFontOfSize:14.0];
        _countLabel.textColor = [UIColor grayColor];
        [self.contentView addSubview:_countLabel];
    }
    return self;
}

- (void)dealloc
{
    [_headImageView release];
    [_nameLabel release];
    [_dateLabel release];
    [_multiImageView release];
    [_countLabel release];
    
    [super dealloc];
}

- (void)headImageDidTouched:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(lovingDonateDidSelectedHeadImage:)])
    {
        [self.delegate lovingDonateDidSelectedHeadImage:self];
    }
}

- (void)confirmAction:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(lovingDonateCellDidConfirmed:)])
    {
        [self.delegate lovingDonateCellDidConfirmed:self];
    }
}

#pragma mark-JBoMultiImageView代理
- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(lovingDonateCell:didSelectedImageAtIndex:)])
    {
        [self.delegate lovingDonateCell:self didSelectedImageAtIndex:index];
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
 
    _multiImageView.frame = CGRectMake(_multiImageView.frame.origin.x, _multiImageView.frame.origin.y, _multiImageView.frame.size.width, [JBoMultiImageView getHeightWithCount:_multiImageView.images.count]);
    _countLabel.frame = CGRectMake(_countLabel.frame.origin.x, _multiImageView.frame.origin.y + _multiImageView.frame.size.height + _controlInterval_, _countLabel.frame.size.width, _countLabel.frame.size.height);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
