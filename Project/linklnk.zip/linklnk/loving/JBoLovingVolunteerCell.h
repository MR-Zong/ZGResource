//
//  JBoLovingVolunteerCell.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoAttributedLabel.h"

#define _lovingVolunteerCellHeight_ 60.0
#define _lovingVolunteerCellInterval_ 10.0

/**志愿者信息的cell
 */
@interface JBoLovingVolunteerCell : UITableViewCell

/**头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**参加志愿者的日期
 */
@property(nonatomic,readonly) JBoAttributedLabel *dateLabel;

@end
