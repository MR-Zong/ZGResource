//
//  JBoLovingDonateListViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingDonateListViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoLookAndTellOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoLovingDonateInfo.h"
#import "JBoLovingDonateCell.h"
#import "JBoLovingOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoImageTextTool.h"
#import "JBoConfirmLovingDonateViewController.h"
#import "JBoDonateConfirmInfoViewController.h"
#import "UITableView+extraCellLine.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoContactDetailInfotViewController.h"
#import "JBoReuseScrollView.h"

@interface JBoLovingDonateListViewController ()<JBoHttpRequestDelegate,UITableViewDataSource,UITableViewDelegate,JBoLovingDonateCellDelegate,JBoReuseScrollViewDelegate,JBoConfirmLovingDonateViewControllerDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
    
    JBoBottomLoadingView *_bottomLoadingView;
}

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) UITableView *tableView;
@property(nonatomic,retain) NSMutableArray *infoArray;

@property(nonatomic,assign) int pageIndex;
@property(nonatomic,assign) int pageSize;
@property(nonatomic,assign) BOOL hasInfo;

@property(nonatomic,retain) NSMutableArray *imageURLArray;
@property(nonatomic,retain) JBoReuseScrollView *imageScrollView;

@property(nonatomic,retain) NSIndexPath *selectedIndexPath;

@end

@implementation JBoLovingDonateListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"捐物";
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
        
        self.hasInfo = YES;
        self.pageIndex = 1;
        self.pageSize = 10;

        self.black = YES;
    }
    return self;
}


- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequesting];
        if(!_isRequesting)
        {
            _appDelegate.dataLoadingView.hidden = YES;
            self.tableView.tableFooterView = nil;
        }
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_groupId release];
    [_httpRequest release];
    [_tableView release];
    [_infoArray release];
    [_bottomLoadingView release];

    [_imageURLArray release];
    [_imageScrollView release];
    [_selectedIndexPath release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取数据失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    NSMutableArray *array = [JBoLovingOperation getLovingDonateFromData:data];
    if(array.count > 0)
    {
        self.hasInfo = array.count == self.pageSize;
        [self.infoArray addObjectsFromArray:array];
        
        if(!_tableView)
        {
            [self loadInitView];
        }
        else
        {
            [_tableView reloadData];
        }
    }
    else
    {
        if(self.infoArray.count == 0)
        {
            [JBoUserOperation alertMsg:@"暂时没有爱心捐物"];
        }
    }
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.view.backgroundColor = [UIColor whiteColor];
    
    if(self.black)
    {
        [JBoNavigatioinBarOperation setBlackBackItemWithTarget:self action:@selector(back)];
    }
    else
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    }
    
    
    [self loadInfo:NO];
}

- (void)loadInitView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    [tableView setExtraCellLineHidden];
    
    self.tableView = tableView;
    [tableView release];
}

- (void)loadInfo:(BOOL) hidden
{
    if(self.isRequesting)
        return;
    
    self.isRequesting = YES;
    _appDelegate.dataLoadingView.hidden = hidden;
    [_httpRequest downloadWithURL:[JBoLovingOperation getLovingDonateWithGroupId:self.groupId pageNum:self.pageIndex rows:self.pageSize]];
}

#pragma mark-tableView代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLovingDonateInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    CGFloat height = _headImageSize_ + _topPadding_ * 2 + [JBoMultiImageView getHeightWithCount:info.imageURLArray.count];
    
    return height;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _infoArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoLovingDonateCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoLovingDonateCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    JBoLovingDonateInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    cell.headImageView.sex = info.sex;
    cell.headImageView.headImageURL = info.headImageURL;

    if(info.alreadConfirm)
    {
        if(self.isSelf)
        {
            [cell.confirmButton setTitle:@"已签收" forState:UIControlStateNormal];
        }
        else
        {
            [cell.confirmButton setTitle:@"已签收" forState:UIControlStateNormal];
        }
    }
    else
    {
        if(self.isSelf)
        {
            [cell.confirmButton setTitle:@"签收" forState:UIControlStateNormal];
        }
        else
        {
            [cell.confirmButton setTitle:@"未签收" forState:UIControlStateNormal];
        }
    }
    
    cell.nameLabel.sex = info.sex;
    cell.nameLabel.text = info.name;
    cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.date];
    cell.countLabel.text = [NSString stringWithFormat:@"共%d件", info.count];
    
    cell.multiImageView.images = info.imageURLArray;

    return cell;
}

#pragma mark-JBoLovingDonateCell代理

- (void)lovingDonateCellDidConfirmed:(JBoLovingDonateCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    self.selectedIndexPath = indexPath;
    JBoLovingDonateInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    if(info.alreadConfirm)
    {
        JBoDonateConfirmInfoViewController *confirmInfo = [[JBoDonateConfirmInfoViewController alloc] init];
        confirmInfo.black = self.black;
        confirmInfo.Id = info.ID;
        [self.navigationController pushViewController:confirmInfo animated:YES];
        [confirmInfo release];
    }
    else if(self.isSelf)
    {
        JBoConfirmLovingDonateViewController *confirm = [[JBoConfirmLovingDonateViewController alloc] init];
        confirm.info = info;
        confirm.delegate = self;
        confirm.black = self.black;
        confirm.groupId = self.groupId;
        [self.navigationController pushViewController:confirm animated:YES];
        [confirm release];
    }
}

- (void)lovingDonateCell:(JBoLovingDonateCell *)cell didSelectedImageAtIndex:(NSInteger)index
{
    
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    NSInteger currentIndex = 0;
    
    NSMutableArray *urlArray = [[NSMutableArray alloc] init];
    for(NSInteger i = 0;i < _infoArray.count;i ++)
    {
        JBoLovingDonateInfo *info = [_infoArray objectAtIndex:i];
        [urlArray addObjectsFromArray:info.imageURLArray];
        
        if(i < indexPath.row)
        {
            currentIndex += info.imageURLArray.count;
        }
        
        if(i == indexPath.row)
        {
            currentIndex += index;
        }
    }
    
    self.imageURLArray = urlArray;
    [urlArray release];
    
    self.imageScrollView = [[[JBoReuseScrollView alloc] init] autorelease];
    self.imageScrollView.delegate = self;
    self.imageScrollView.currentIndex = currentIndex;
    [self.imageScrollView reloadData];
    
    
    [self.imageScrollView showInViewController:self];
}

- (void)lovingDonateDidSelectedHeadImage:(JBoLovingDonateCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoLovingDonateInfo *info = [_infoArray objectAtIndex:indexPath.row];
    
    JBoRosterInfo *rosterInfo = [_appDelegate.rosterAndUsernameDic objectForKey:info.userId];
    if(rosterInfo)
    {
        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
        detail.rosterInfo = rosterInfo;
        detail.black = self.black;
        [self.navigationController pushViewController:detail animated:YES];
        [detail release];
    }
    else
    {
        JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
        userInfo.userId = info.userId;
        userInfo.black = self.black;
        [self.navigationController pushViewController:userInfo animated:YES];
        [userInfo release];
    }
}

#pragma mark- JBoConfirmLovingDonateViewController代理

- (void)confirmLovingDonateViewControllerDidConfirmed:(JBoConfirmLovingDonateViewController *)viewController
{
    JBoLovingDonateInfo *info = [self.infoArray objectAtIndex:self.selectedIndexPath.row];
    info.alreadConfirm = YES;
    
    [_tableView beginUpdates];
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [_tableView endUpdates];
    
    self.selectedIndexPath = nil;
    [viewController back];
}


#pragma mark-reuseScrollView代理
- (NSInteger)numberOfRowsAtScrollView:(JBoReuseScrollView *)scrollView
{
    return self.imageURLArray.count;
}

- (JBoReuseScrollViewCell*)resuseScrollView:(JBoReuseScrollView *)scrollView cellForIndex:(NSInteger)index
{
    JBoReuseScrollViewCell *cell = [scrollView dequeueRecycledCell];
    if(cell == nil)
    {
        // NSLog(@"reuse cell");
        cell = [[[JBoReuseScrollViewCell alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
    }
    
    NSString *url = [self.imageURLArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:url thumbnailSize:CGSizeZero];
    
    if(image)
    {
        cell.loading = NO;
        cell.imageView.image = image;
    }
    else
    {
        cell.loading = YES;
        cell.imageView.image = nil;
        if(!scrollView.dragging && !scrollView.decelerating)
        {
            [self downloadImageWithUrl:url forIndex:index];
        }
    }
    //NSLog(@"reuse cell");
    return cell;
}

- (void)resuseScrollView:(JBoReuseScrollView *)scrollView cellCanDownloadAtIndex:(NSInteger)index
{
    NSString *url = [self.imageURLArray objectAtIndex:index];
    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    
    UIImage *image = [cache imageForURL:url thumbnailSize:CGSizeZero];
    if(!image)
    {
        [self downloadImageWithUrl:url forIndex:index];
    }
}


- (void)resuseScrollViewDidClosed:(JBoReuseScrollView *)scrollView
{
    self.imageScrollView = nil;
    self.imageURLArray = nil;
    [_tableView reloadData];
}

- (void)downloadImageWithUrl:(NSString*) url forIndex:(NSInteger) index
{
    if([NSString isEmpty:url])
        return;

    JBoImageCacheTool *cache = [JBoImageCacheTool sharedInstance];
    [cache getImageWithURL:url thumbnailSize:CGSizeZero useCache:YES completion:^(UIImage *image){
        
        JBoReuseScrollViewCell *cell = [self.imageScrollView cellForIndex:index];

        cell.imageView.image = image;
        [self.imageScrollView reloadDataAtIndex:index];
    }];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // NSLog(@"addressBook scrollViewDidScroll");
    if(!self.isRequesting && self.hasInfo)
    {
        if(scrollView.contentOffset.y > scrollView.contentSize.height - scrollView.frame.size.height + 40)
        {
            if(!_bottomLoadingView)
            {
                //创建加载更多视图
                _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            }
           
            self.pageIndex ++;
            _tableView.tableFooterView = _bottomLoadingView;
            [self loadInfo:YES];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
