//
//  JBoConfirmLovingDonateViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoConfirmLovingDonateViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoImageOperationView.h"
#import "JBoImageOperationPreviewedViewController.h"
#import "JBoFileManager.h"
#import "JBoLookAndTellOperation.h"
#import "JBoUserOperation.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageTextTool.h"
#import "JBoNavigationViewController.h"
#import "JBoLovingOperation.h"
#import "SSTextView.h"

#define _padding_ 10
#define _imageSize_ 100


@interface JBoConfirmLovingDonateViewController ()<UITextViewDelegate,JBoMutiImagePickerDelegate,JBoImageOperationViewDelegate,JBoHttpRequestDelegate,JBoImageOperationPreviewedViewControllerDelegate,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate>

{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,retain) JBoImageOperationView *imageOperationView;
@property(nonatomic,retain) NSMutableArray *imageArray;
@property(nonatomic,retain) NSArray *filesArray;
@property(nonatomic,assign) BOOL isRequesting;

//数量
@property(nonatomic,retain) SSTextView *textView;

@end

@implementation JBoConfirmLovingDonateViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"确认签收";
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        self.black = YES;
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理

- (void)dealloc
{
    [_info release];
    [_groupId release];
    
    [_httpRequest release];
    [_imageOperationView release];
    [_imageArray release];
    
    [_textView release];
    
    [JBoFileManager deleteFiles:_filesArray];
    [_filesArray release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    [JBoFileManager deleteFiles:self.filesArray];
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"上传失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    [JBoFileManager deleteFiles:self.filesArray];
    self.isRequesting = NO;
    if([JBoUserOperation isSuccess:data])
    {
        [JBoUserOperation alertMsg:@"上传成功"];
        if([self.delegate respondsToSelector:@selector(confirmLovingDonateViewControllerDidConfirmed:)])
        {
            [self.delegate confirmLovingDonateViewControllerDidConfirmed:self];
        }
        else
        {
            [self back];
        }
    }
    else
    {
        [JBoUserOperation alertmsgWithBadNetwork:@"上传失败"];
    }
}

#pragma mark-加载视图

- (void)back
{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)send
{
    if([NSString isEmpty:self.textView.text])
    {
        [JBoUserOperation alertMsg:@"请输入数量"];
        return;
    }
    if(self.imageArray.count == 0)
    {
        [JBoUserOperation alertMsg:@"请上传图片"];
        return;
    }
    
    self.isRequesting = YES;
    dispatch_block_t block = ^(void)
    {
        self.filesArray = [JBoFileManager writeImageInTemporaryFile:self.imageArray withCompressedScale:_lookAndTellImageCompressedScale_];
        dispatch_async(dispatch_get_main_queue(), ^(void)
                       {
                           [_httpRequest downloadWithURL:[JBoLovingOperation confirmLovingDonate] paraDic:[JBoLovingOperation confirmLovingDonateWithGroupId:self.groupId donaterUserId:self.info.userId replyContent:_textView.text count:self.info.count donateInfoId:self.info.ID] files:self.filesArray filesKey:_lovingDonateImagesFile_];
                       });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("files", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

- (void)reconverKeyborad:(UITapGestureRecognizer*) tap
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = _mainBackgroundColor_;
    self.navigationController.navigationBar.translucent = NO;
    
    if(self.black)
    {
        //返回
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back) image:[UIImage imageNamed:@"newsBact.png"]];
        [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(send) title:@"完成" backgroundImage:nil textColor:[UIColor blackColor]];
    }
    else
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
        [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(send) title:@"完成" backgroundImage:nil textColor:[UIColor whiteColor]];
    }
   
    
    //回收键盘
    UITapGestureRecognizer *reconverGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(reconverKeyborad:)];
    [self.view addGestureRecognizer:reconverGesture];
    [reconverGesture release];
    
    _textView = [[SSTextView alloc] initWithFrame:CGRectMake(_padding_, _padding_, _width_ - _padding_ * 2 , 112.5)];
    _textView.delegate = self;
    _textView.returnKeyType = UIReturnKeyDone;
    _textView.placeholder = @"感言";
    _textView.layer.cornerRadius = 6;
    _textView.layer.borderWidth = 0.2;
    _textView.layer.borderColor = [UIColor colorWithRed:210.0 / 255.0 green:210.0 / 255.0 blue:210.0 / 255.0 alpha:1.0].CGColor;
    _textView.font = [UIFont systemFontOfSize:17];
    [self.view addSubview:_textView];
    
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(_padding_, _textView.frame.size.height + _textView.frame.origin.y +  _padding_, _width_ - _padding_ * 2, 30)];
    label.text = @"上传图片";
    label.textColor = [UIColor grayColor];
    label.backgroundColor = [UIColor clearColor];
    [self.view addSubview:label];
    [label release];
    
    self.imageArray = [[[NSMutableArray alloc] init] autorelease];
    
    JBoImageOperationView *imageOperationView = [[JBoImageOperationView alloc] initWithFrame:CGRectMake(_padding_, label.frame.origin.y + label.frame.size.height + _padding_, _width_ - _padding_ * 2, _imageOperationDefaultCellSize_) srcArray:self.imageArray imageSize:_imageOperationDefaultCellSize_];
    imageOperationView.backgroundColor = [UIColor whiteColor];
    imageOperationView.delegate = self;
    imageOperationView.maxCount = 9;
    [self.view addSubview:imageOperationView];
    self.imageOperationView = imageOperationView;
    [imageOperationView release];
}

#pragma mark-textView代理
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}

#pragma mark-JBoImageOperationView代理
- (void)imageOperationViewDidAddedCell:(JBoImageOperationView *)selectedView
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
    [actionSheet showInView:self.navigationController.view];
    [actionSheet release];
}

- (void)imageOperationView:(JBoImageOperationView *)selctedView didSelectImageAtIndex:(NSInteger)index
{
    JBoImageOperationPreviewedViewController *previewVC = [[JBoImageOperationPreviewedViewController alloc] init];
    previewVC.srcArray = selctedView.srcArray;
    previewVC.currentIndex = index;
    previewVC.delegate = self;
    [self.navigationController pushViewController:previewVC animated:YES];
    [previewVC release];
}

- (void)imageOperationViewDidReloadData:(JBoImageOperationView *)selctedView
{
    _appDelegate.dataLoadingView.hidden = YES;
}

#pragma mark-JBoImageOperationPreviewedViewController代理
- (void)imageOperationPreviewedViewController:(JBoImageOperationPreviewedViewController *)viewController didRemoveImageAtIndex:(NSInteger)index
{
    [self.imageOperationView removeImageAtIndex:index];
}

#pragma makr-actionsheet代理
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 0)
    {
        [self getCamera];
    }
    else if(buttonIndex == 1)
    {
        [self getPhotos];
    }
}

#pragma mark-照相
//拍照
- (void)getCamera
{
    //如果该手机不支持拍照，则返回
    NSLog(@"拍照");
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"" message:@"您的手机不能拍照" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alertView show];
        [alertView release];
        return;
    }
    
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.delegate = self;
    
    [self.navigationController presentViewController:imagePicker animated:YES completion:^(void)
     {
         [self hiddTopView:YES];
     }];
    [imagePicker release];
}

//UIImagePickerController代理
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        //图片选取
        UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
        
        UIImage *retImage = image;
        if(image.imageOrientation != UIImageOrientationUp)
        {
            UIGraphicsBeginImageContext(image.size);
            [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
            retImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        CGSize size = [JBoImageTextTool shrinkImage:retImage WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidthAndHeight];
        [self.imageOperationView.srcArray addObject:[JBoImageTextTool getThumbnailFromImage:retImage withSize:size]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [self hiddTopView:NO];
            [picker dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("album", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

//图片选取取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self hiddTopView:NO];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

- (void)hiddTopView:(BOOL) hidden
{
    [_appDelegate hiddenStatusBar:hidden];
    [self.navigationController setNavigationBarHidden:hidden];
}

//发送图片 打开相册选着图片
- (void)getPhotos
{
    JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
    mutilImagePicker.delegate = self;
    mutilImagePicker.imageCount = (int)self.imageOperationView.maxCount - (int)self.imageOperationView.srcArray.count;;
    mutilImagePicker.title = @"相册";
    JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:mutilImagePicker];
    [self presentViewController:nav animated:YES completion:nil];
    
    [mutilImagePicker release];
    [nav release];
}

#pragma mark-JBoMutilImagePickerViewController代理

- (void)imagePicker:(UIViewController *)viewController assetsDidSelected:(NSArray *)assetArray
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_block_t block = ^(void)
    {
        if(assetArray.count > 0)
        {
            for(ALAsset *asset in assetArray)
            {
                UIImage *image = [UIImage imageFromAsset:asset];
                CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
                [self.imageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
            }
        }
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    };
    
    dispatch_queue_t queue = dispatch_queue_create("album", NULL);
    dispatch_async(queue, block);
    dispatch_release(queue);
}

- (void)imagePicker:(UIViewController *)viewController imageDidSelected:(UIImage *)image
{
    _appDelegate.dataLoadingView.hidden = NO;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        
        CGSize size = [JBoImageTextTool shrinkImage:image WithSize:CGSizeMake(_width_, _height_) type:JBoShrinkImageTypeWidth];
        [self.imageArray addObject:[JBoImageTextTool getThumbnailFromImage:image withSize:size]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            [viewController dismissViewControllerAnimated:YES completion:^(void)
             {
                 [self.imageOperationView updateContent];
                 _appDelegate.dataLoadingView.hidden = YES;
             }];
        });
    });
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
