//
//  JBolovingConfirmInfo.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoUserParentInfo.h"

/**超友圈活动捐赠确认信息
 */
@interface JBolovingConfirmInfo : JBoUserParentInfo

/**确认时间
 */
@property(nonatomic,copy) NSString *date;

/**确认输入的信息
 */
@property(nonatomic,copy) NSString *content;

/**确认输入的信息内容高度 default is 'NSNotFound'
 */
@property(nonatomic,assign) NSInteger contenHeight;

/**物品图片,数组元素是图片路径,NSString对象
 */
@property(nonatomic,retain) NSMutableArray *imageURLArray;

@end
