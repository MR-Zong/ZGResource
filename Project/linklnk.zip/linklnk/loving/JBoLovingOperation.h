//
//  JBoLovingDonateOperation.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBolovingConfirmInfo.h"

/**超友圈爱心活动网络操作
 */
@interface JBoLovingOperation : NSObject

/**参加爱心志愿者 url
 *@return post请求url
 */
+ (NSString*)addLovingVolunteer;

/**参加爱心志愿者参数
 *@param date 参加日期
 *@param groupId 爱心活动的源groupId
 *@return post请求参数
 */
+ (NSDictionary*)addLovingVolunteerWithDate:(NSString*) date groupId:(NSString*) groupId;

/**爱心捐物 url
 *@return post请求url
 */
+ (NSString*)addLovingDonate;

/**爱心捐物 参数
 *@param groupId 爱心活动的源groupId
 *@param count 爱心捐物的数量
 *@return post请求参数
 */
+ (NSDictionary*)addLovingDonateWithGroupId:(NSString*) groupId count:(NSInteger) count;

/**获取爱心志愿者
 *@param groupId 爱心活动的源groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get 请求url
 */
+ (NSString*)getLovingVolunteerWithGroupId:(NSString*) groupId pageNum:(int) pageNum rows:(int) rows;

/**从返回的数据获取爱心志愿者信息
 *@return 数组元素是 JBoLovingVolunteerInfo 对象
 */
+ (NSMutableArray*)getLovingVolunteerFromData:(NSData*) data;

/**获取爱心志愿者总数
 *@param groupId 爱心活动的源groupId
 *@return get请求url
 */
+ (NSString*)getLovingVolunteerCountWithGroupId:(NSString*) groupId;

/**从返回的数据获取爱心志愿者总数
 *@param data 返回的数据
 *@return 爱心志愿者总数
 */
+ (NSInteger)getLovingVolunteerCountFromData:(NSData*) data;

/**获取爱心捐物用户信息
 *@param groupId 爱心活动的源groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getLovingDonateWithGroupId:(NSString*) groupId pageNum:(int) pageNum rows:(int) rows;

/**从返回的数据获取爱心捐物用户信息
 *@param data 返回的数据
 *@return 数组元素是 JBoLovingDonateInfo 对象
 */
+ (NSMutableArray*)getLovingDonateFromData:(NSData*) data;

/**获取爱心志捐物用户总数
 *@param groupId 爱心活动的源groupId
 *@return get请求url
 */
+ (NSString*)getLovingDonateCountWithGroupId:(NSString*) groupId;

/**从返回的数据获取爱心志捐物用户总数
 *@param data 返回的数据
 *@return 爱心志捐物用户总数
 */
+ (NSInteger)getLovingDonateCountFromData:(NSData*) data;

/**确认收货 url
 *@return post请求url
 */
+ (NSString*)confirmLovingDonate;

/**确认收货 参数
 *@param groupId 爱心活动的源groupId
 *@param donateUserId 捐物的用户
 *@param content 回复留言
 *@param count 物品数量
 *@param donateInfoId 捐物信息的Id
 *@return post请求参数
 */
+ (NSDictionary*)confirmLovingDonateWithGroupId:(NSString*) groupId donaterUserId:(NSString*) donateUserId replyContent:(NSString*) content count:(NSInteger) count donateInfoId:(NSString*) donateInfoId;

/**获取确认收货信息
 *@param Id 捐物信息的Id
 *@return get请求url
 */
+ (NSString*)getLovingConfirmInfoWithId:(NSString*) Id;

/**从返回的数据获取确认收货信息
 *@param data返回的数据
 *@return 确认收货信息
 */
+ (JBolovingConfirmInfo*)getLovingConfirmInfoFromData:(NSData*) data;

@end
