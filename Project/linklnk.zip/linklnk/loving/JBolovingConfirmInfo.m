//
//  JBolovingConfirmInfo.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBolovingConfirmInfo.h"

@implementation JBolovingConfirmInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.contenHeight = NSNotFound;
    }
    return self;
}

- (void)dealloc
{
    [_date release];
    [_content release];
    [_imageURLArray release];
    
    [super dealloc];
}

@end
