//
//  JBoLovingVolunteerInfo.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoUserParentInfo.h"

/**超友圈活动志愿者信息
 */
@interface JBoLovingVolunteerInfo : JBoUserParentInfo

/**参加志愿者的时间
 */
@property(nonatomic,copy) NSString *date;

@end
