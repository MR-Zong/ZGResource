//
//  JBoDonateConfirmInfoViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoDonateConfirmInfoViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoLookAndTellOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoLovingDonateInfo.h"
#import "JBoLovingDonateCell.h"
#import "JBoLovingOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoAsyncDownloadImageOperation.h"
#import "JBoImageTextTool.h"
#import "UITableView+extraCellLine.h"
#import "JBoLovingConfirmCell.h"

@interface JBoDonateConfirmInfoViewController ()<JBoHttpRequestDelegate,JBoLovingConfirmCellDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,retain) UITableView *tableView;
@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) JBolovingConfirmInfo *info;

@end

@implementation JBoDonateConfirmInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    [_Id release];
    
    [_httpRequest release];
    [_info release];
    
    [_tableView release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"获取信息失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    self.info = [JBoLovingOperation getLovingConfirmInfoFromData:data];
    
    if(!_tableView)
    {
        [self loadInitView];
    }
}

#pragma mark-加载视图

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.view.backgroundColor = [UIColor whiteColor];
    if(self.black)
    {
        //返回
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back) image:[UIImage imageNamed:@"newsBact.png"]];
    }
    else
    {
        [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    }
    
    [self loadInfo:NO];
}

- (void)loadInfo:(BOOL)hidden
{
    if(self.isRequesting)
        return;
    self.isRequesting = YES;
    _appDelegate.dataLoadingView.hidden = hidden;
    
    [_httpRequest downloadWithURL:[JBoLovingOperation getLovingConfirmInfoWithId:self.Id]];
}

- (void)loadInitView
{
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    [tableView setExtraCellLineHidden];
    
    self.tableView = tableView;
    [tableView release];
}

#pragma mark-tableView代理

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(self.info.contenHeight == NSNotFound)
    {
        CGFloat contentHeight = [JBoImageTextTool getStringSize:self.info.content withFont:[UIFont systemFontOfSize:17.0] andContraintSize:CGSizeMake(_multiSize_ * _imagesPerRows_ + _controlInterval_ * (_imagesPerRows_ - 1), _height_)].height;
        self.info.contenHeight = contentHeight + 10.0;
    }
    
    CGFloat height = _headImageSize_ + _topPadding_ * 2 + self.info.contenHeight + [JBoMultiImageView getHeightWithCount:self.info.imageURLArray.count];
    
    return height;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoLovingConfirmCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoLovingConfirmCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.delegate = self;
    }
    
    cell.nameLabel.text = self.info.name;
    cell.nameLabel.sex = self.info.sex;
 
    cell.headImageView.sex = self.info.sex;
    cell.headImageView.headImageURL = self.info.headImageURL;
    
    cell.contentHeight = self.info.contenHeight;
    cell.contentLabel.text = self.info.content;
    cell.dateLabel.text = [JBoDatetimeTool datetimeTool:self.info.date];
    cell.multiImageView.images = self.info.imageURLArray;
    
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
