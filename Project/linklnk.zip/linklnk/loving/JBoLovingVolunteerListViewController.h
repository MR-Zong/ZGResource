//
//  JBoVolunteerListViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**爱心活动志愿者信息列表
 */
@interface JBoLovingVolunteerListViewController : UIViewController

/**爱心活动的groupId
*/
@property(nonatomic,copy) NSString *groupId;

/**导航栏标题是否为黑色
 */
@property(nonatomic,assign) BOOL black;

@end
