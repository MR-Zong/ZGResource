//
//  JBoVolunteerViewController.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingVolunteerViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoUserOperation.h"
#import "JBoLookAndTellOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoLovingOperation.h"

@interface JBoLovingVolunteerViewController ()<JBoHttpRequestDelegate>
{
    JBoAppDelegate *_appDelegate;
    JBoHttpRequest *_httpRequest;
}

@property(nonatomic,assign) BOOL isRequesting;
@property(nonatomic,retain) UIDatePicker *datePicker;
@property(nonatomic,retain) UILabel *timeLabel;

@end

@implementation JBoLovingVolunteerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"志愿者";
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
    }
    return self;
}

- (void)setIsRequesting:(BOOL)isRequesting
{
    if(_isRequesting != isRequesting)
    {
        _isRequesting = isRequesting;
        _appDelegate.dataLoadingView.hidden = !_isRequesting;
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    [_groupId release];
    [_datePicker release];
    [_timeLabel release];
    [_httpRequest release];
    
    [super dealloc];
}

#pragma mark-视图消失出现

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequesting)
    {
        [_appDelegate closeAlertView];
    }
}

#pragma mark-httpRequest代理

- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    [JBoUserOperation alertmsgWithBadNetwork:@"上传失败"];
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    self.isRequesting = NO;
    if([JBoUserOperation isSuccess:data])
    {
        [JBoUserOperation alertMsg:@"上传成功"];
        if([self.delegate respondsToSelector:@selector(lovingVolunteerViewControllerDidFinished:)])
        {
            [self.delegate lovingVolunteerViewControllerDidFinished:self];
        }
        else
        {
            [self performSelector:@selector(back) withObject:nil afterDelay:0.3];
        }
    }
}

#pragma mark-加载视图

- (void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)send
{
    if(self.isRequesting)
        return;
    self.isRequesting = YES;
    [_httpRequest downloadWithURL:[JBoLovingOperation addLovingVolunteer] dic:[JBoLovingOperation addLovingVolunteerWithDate:self.timeLabel.text groupId:self.groupId]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
    self.navigationController.navigationBar.translucent = NO;
    self.view.backgroundColor = _mainBackgroundColor_;
    
    //返回
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back) image:[UIImage imageNamed:@"newsBact.png"]];
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(send) title:@"完成" backgroundImage:nil textColor:[UIColor blackColor]];
    
    UILabel *timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, _width_, 40 )];
    timeLabel.backgroundColor = [UIColor clearColor];

    [timeLabel setTextAlign:JBoTextAlignmentCenter];
    [self.view addSubview:timeLabel];
    self.timeLabel = timeLabel;
    [timeLabel release];
    
    UIDatePicker *datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, self.timeLabel.frame.origin.y + self.timeLabel.frame.size.height + 20, 0, 0)];
    datePicker.datePickerMode = UIDatePickerModeDateAndTime;
    datePicker.date = [NSDate date];
   // datePicker.locale = [NSLocale localeWithLocaleIdentifier:@"zh-Hans"];
    datePicker.timeZone = [NSTimeZone timeZoneWithName:@"Asia/BeiJing"];
    [self.view addSubview:datePicker];
    self.datePicker = datePicker;
    [datePicker addTarget:self action:@selector(dateDidChanged:) forControlEvents:UIControlEventValueChanged];
    [datePicker release];
    
    [self dateDidChanged:datePicker];
}

- (void)dateDidChanged:(UIDatePicker*) datePicker
{
    NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithName:@"Asia/BeiJing"]];
    self.timeLabel.text = [dateFormatter stringFromDate:datePicker.date];
    //NSLog(@"%@",[dateFormatter stringFromDate:datePicker.date]);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
