//
//  JBoLovingDonateOperation.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingOperation.h"
#import "JBoBasic.h"
#import "JBoUserOperation.h"
#import "JBoLovingDonateInfo.h"
#import "JBoLovingVolunteerInfo.h"
#import "JSONKit.h"
#import "NSDictionary+customDic.h"
#import "JBoImageTextTool.h"

@implementation JBoLovingOperation

#pragma mark-新增

/**参加爱心志愿者 url
 *@return post请求url
 */
+ (NSString*)addLovingVolunteer
{
    return _addLovingVolunteer_;
}

/**参加爱心志愿者参数
 *@param date 参加日期
 *@param groupId 爱心活动的源groupId
 *@return post请求参数
 */
+ (NSDictionary*)addLovingVolunteerWithDate:(NSString *)date groupId:(NSString *)groupId
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:6];
    [dic setObject:[JBoUserOperation getUserId] forKey:_lovingUserId_];
    [dic setObject:date forKey:_lovingVolunteerDate_];
    [dic setObject:groupId forKey:_lookAndTellGroupId_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    NSLog(@"%@",dic);
    
    return [dic autorelease];
}

/**爱心捐物 url
 *@return post请求url
 */
+ (NSString*)addLovingDonate
{
    return _addLovingDonate_;
}

/**爱心捐物 参数
 *@param groupId 爱心活动的源groupId
 *@param count 爱心捐物的数量
 *@return post请求参数
 */
+ (NSDictionary*)addLovingDonateWithGroupId:(NSString *)groupId count:(NSInteger)count
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:6];
    [dic setObject:[JBoUserOperation getUserId] forKey:_lovingUserId_];
    [dic setObject:[NSNumber numberWithInteger:count] forKey:_lovingDonateCount_];
    [dic setObject:groupId forKey:_lookAndTellGroupId_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    NSLog(@"%@",dic);
    
    return [dic autorelease];
}

/**获取爱心志愿者
 *@param groupId 爱心活动的源groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get 请求url
 */
+ (NSString*)getLovingVolunteerWithGroupId:(NSString*) groupId pageNum:(int)pageNum rows:(int)rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getLovingVolunteer_, _lovingId_, groupId, _pageNum_, pageNum, _rows_, rows];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取爱心志愿者信息
 *@return 数组元素是 JBoLovingVolunteerInfo 对象
 */
+ (NSMutableArray*)getLovingVolunteerFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infos = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoLovingVolunteerInfo *info = [[JBoLovingVolunteerInfo alloc] init];
            
            info.userId = [dict objectWithKey:_rosterUserId_];
            info.name = [dict objectWithKey:_rosterName_];
            info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
            info.headImageURL = [dict objectWithKey:_rosterImageURL_];
            info.role = [[dict valueWithKey:_rosterRole_] integerValue];
            
            info.date = [dict objectWithKey:_lovingVolunteerDate_];
            
            [infos addObject:info];
            [info release];
        }
        
        return [infos autorelease];;
    }
    else
    {
        return nil;
    }
}

/**获取爱心志愿者总数
 *@param groupId 爱心活动的源groupId
 *@return get请求url
 */
+ (NSString*)getLovingVolunteerCountWithGroupId:(NSString*) groupId;
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getLovingVolunteerCount_, _lovingId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
   // NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取爱心志愿者总数
 *@param data 返回的数据
 *@return 爱心志愿者总数
 */
+ (NSInteger)getLovingVolunteerCountFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
   // NSLog(@"%@", [[dic objectForKey:_result_] objectForKey:_msg_]);
  //  NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSInteger count = [[dic objectWithKey:_data_] integerValue];
        return count;
    }
    else
    {
        return 0;
    }
}

/**获取爱心捐物用户信息
 *@param groupId 爱心活动的源groupId
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*)getLovingDonateWithGroupId:(NSString*) groupId pageNum:(int) pageNum rows:(int) rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getLovingDonate_, _lovingId_, groupId, _pageNum_, pageNum, _rows_, rows];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取爱心捐物用户信息
 *@param data 返回的数据
 *@return 数组元素是 JBoLovingDonateInfo 对象
 */
+ (NSMutableArray*)getLovingDonateFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];

    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infos = [[NSMutableArray alloc] initWithCapacity:dataArray.count];
        
        for(NSDictionary *dict in dataArray)
        {
            JBoLovingDonateInfo *info = [[JBoLovingDonateInfo alloc] init];
            
            info.userId = [dict objectWithKey:_rosterUserId_];
            info.name = [dict objectWithKey:_rosterName_];
            info.role = [[dict valueWithKey:_rosterRole_] integerValue];
            info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
            info.headImageURL = [dict objectWithKey:_rosterImageURL_];
            info.ID = [dict objectWithKey:_lovingInfoId_];
            info.alreadConfirm = [[dict valueWithKey:_donateConfirmState_] boolValue];
            
            NSString *imageURL = [dict objectWithKey:_lovingDonatePhoto_];
            info.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
            info.count = [[dict valueWithKey:_lovingDonateCount_] intValue];
            
            [infos addObject:info];
            [info release];
        }
        
        return [infos autorelease];
    }
    else
    {
        return nil;
    }
}

/**获取爱心志捐物用户总数
 *@param groupId 爱心活动的源groupId
 *@return get请求url
 */
+ (NSString*)getLovingDonateCountWithGroupId:(NSString*) groupId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getLovingDonateCount_, _lovingId_, groupId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
   // NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取爱心志捐物用户总数
 *@param data 返回的数据
 *@return 爱心志捐物用户总数
 */
+ (NSInteger)getLovingDonateCountFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
//    NSLog(@"--%@", [[dic objectForKey:_result_] objectForKey:_msg_]);
   // NSLog(@"donate%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSInteger count = [[dic valueWithKey:_data_] integerValue];
        return count;
    }
    else
    {
        return 0;
    }
}


#pragma mark-确认收货

/**确认收货 url
 *@return post请求url
 */
+ (NSString*)confirmLovingDonate
{
    return _confirmDonate_;
}

/**确认收货 参数
 *@param groupId 爱心活动的源groupId
 *@param donateUserId 捐物的用户
 *@param content 回复留言
 *@param count 物品数量
 *@param donateInfoId 捐物信息的Id
 *@return post请求参数
 */
+ (NSDictionary*)confirmLovingDonateWithGroupId:(NSString *)groupId donaterUserId:(NSString *)donateUserId replyContent:(NSString *)content count:(NSInteger)count donateInfoId:(NSString *)donateInfoId
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithCapacity:9];
    
    [dic setObject:[JBoUserOperation getUserId] forKey:_confirmDonateUserId_];
    [dic setObject:groupId forKey:_lovingId_];
    
    [dic setObject:donateUserId forKey:_donaterUserId_];
    [dic setObject:content forKey:_lovingReplyContent_];
    [dic setObject:[NSNumber numberWithInteger:count] forKey:_lovingDonateCount_];
    [dic setObject:donateInfoId forKey:_lovingInfoId_];
    
    [dic addEntriesFromDictionary:[JBoUserOperation getSecurityAuthentication]];
    
    NSLog(@"%@",dic);
    
    return [dic autorelease];
}

/**获取确认收货信息
 *@param Id 捐物信息的Id
 *@return get请求url
 */
+ (NSString*)getLovingConfirmInfoWithId:(NSString *)Id
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _getLovingConfrim_, _lovingConfirmSourceId_, Id];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    return url;
}

/**从返回的数据获取确认收货信息
 *@param data返回的数据
 *@return 确认收货信息
 */
+ (JBolovingConfirmInfo*)getLovingConfirmInfoFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    
    NSLog(@"%@",dic);
    
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code intValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        if(dataArray.count == 0)
            return nil;
        NSDictionary *dict = [dataArray firstObject];
        
        JBolovingConfirmInfo *info = [[JBolovingConfirmInfo alloc] init];
        
        info.content = [dict objectWithKey:_lovingReplyContent_];
        NSString *imageURL = [dict objectWithKey:_lovingDonatePhoto_];
        info.imageURLArray = [JBoImageTextTool getImageURLsFromStr:imageURL];
        
        info.userId = [dict objectWithKey:_rosterUserId_];
        info.name = [dict objectWithKey:_rosterName_];
        info.sex = [[dict valueWithKey:_rosterSex_] integerValue];
        info.role = [[dict valueWithKey:_rosterRole_] integerValue];
        info.headImageURL = [dict objectWithKey:_rosterImageURL_];
        
        info.date = [dict objectWithKey:_lovingConfirmDate_];
        
        return [info autorelease];
    }
    else
    {
        return nil;
    }
}

@end
