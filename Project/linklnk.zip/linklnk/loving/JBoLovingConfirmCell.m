//
//  JBoLovingConfirmCell.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingConfirmCell.h"
#import "JBoBasic.h"

@implementation JBoLovingConfirmCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageDidTouched:)];
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_rightPadding_, _topPadding_, _headImageSize_, _headImageSize_)];
        _headImageView.userInteractionEnabled = YES;
        [_headImageView addGestureRecognizer:tap];
        [self.contentView addSubview:_headImageView];
        [tap release];
        
        CGFloat width = _width_ - _headImageView.frame.origin.x - _headImageView.frame.size.width - _rightPadding_ * 2 - _controlInterval_;
        
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _controlInterval_, _headImageView.frame.origin.y, width / 5 * 3, 30)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        _nameLabel.font = [UIFont fontWithName:_userNameFontName_ size:_userNameFontSize_];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat x = _nameLabel.frame.origin.x - _nameLabel.frame.size.width;
        
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, _nameLabel.frame.origin.y, _width_ - x - _rightPadding_, _nameLabel.frame.size.height)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;
        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        
        [self.contentView addSubview:_dateLabel];
        
        
        _contentLabel = [[JBoChatMsgLabel alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.origin.y + _nameLabel.frame.size.height, _multiSize_ * _imagesPerRows_ + _controlInterval_ * (_imagesPerRows_ - 1), _controlHeight_)];
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.delegate = self;
        _contentLabel.contentFont = [UIFont systemFontOfSize:17.0];
        [self.contentView addSubview:_contentLabel];
        
        _multiImageView = [[JBoMultiImageView alloc] initWithFrame:CGRectZero];
        _multiImageView.delegate = self;
        [self.contentView addSubview:_multiImageView];
    }
    return self;
}

- (void)dealloc
{
    [_multiImageView release];
    [_contentLabel release];
    
    [_headImageView release];
    [_nameLabel release];
    [_dateLabel release];
    
    [super dealloc];
}

- (void)headImageDidTouched:(UITapGestureRecognizer*) tap
{
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    _contentLabel.frame = CGRectMake(_contentLabel.frame.origin.x, _contentLabel.frame.origin.y, _contentLabel.frame.size.width, self.contentHeight);
    
    _multiImageView.frame = CGRectMake(_contentLabel.frame.origin.x, _contentLabel.bottom + _controlInterval_, _contentLabel.width, [JBoMultiImageView getHeightWithCount:_multiImageView.images.count]);
    
    CGFloat y = _multiImageView.frame.size.height + _multiImageView.frame.origin.y;
    _dateLabel.frame = CGRectMake(_dateLabel.frame.origin.x, y, _dateLabel.frame.size.width, _dateLabel.frame.size.height);
}



#pragma mark-JBoChatMsgLabel代理

- (void)chatMsgLabel:(JBoChatMsgLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(lovingConfrimCell:didSelectedURL:)])
    {
        [self.delegate lovingConfrimCell:self didSelectedURL:url];
    }
}

#pragma mark-JBoMultiImageView代理

- (void)multiImageView:(JBoMultiImageView *)multiImageView didSelectedAtIndex:(NSInteger)index
{
    if([self.delegate respondsToSelector:@selector(lovingConfrimCell:didSelectedImageAtIndex:)])
    {
        [self.delegate lovingConfrimCell:self didSelectedImageAtIndex:index];
    }
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
