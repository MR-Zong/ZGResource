//
//  JBoLovingDonateListViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

/**捐赠信息列表
 */
@interface JBoLovingDonateListViewController : UIViewController

/**爱心活动的groupId
 */
@property(nonatomic,copy) NSString *groupId;

/**是否是查看自己发布的活动
 */
@property(nonatomic,assign) BOOL isSelf;

/**导航栏标题是否为黑色
 */
@property(nonatomic,assign) BOOL black;

@end
