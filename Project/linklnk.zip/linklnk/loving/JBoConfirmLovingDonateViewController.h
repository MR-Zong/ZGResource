//
//  JBoConfirmLovingDonateViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoLovingDonateInfo.h"

@class JBoConfirmLovingDonateViewController;

/**爱心捐物确认收货代理
 */
@protocol JBoConfirmLovingDonateViewControllerDelegate <NSObject>

/**确认收货
 */
- (void)confirmLovingDonateViewControllerDidConfirmed:(JBoConfirmLovingDonateViewController*) viewController;

@end

/**爱心捐物确认收货
 */
@interface JBoConfirmLovingDonateViewController : UIViewController

/**捐物信息
 */
@property(nonatomic,retain) JBoLovingDonateInfo *info;

/**爱心活动的groupId
 */
@property(nonatomic,copy) NSString *groupId;

/**导航栏标题是否为黑色
 */
@property(nonatomic,assign) BOOL black;
@property(nonatomic,assign) id<JBoConfirmLovingDonateViewControllerDelegate> delegate;

//返回
- (void)back;

@end
