//
//  JBoLovingDonateCell.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoMultiImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoAttributedLabel.h"

#define _controlInterval_ 5
#define _controlHeight_ 21
#define _headImageSize_ 50
#define _lookAndTellCellNormalHeight_ 60
#define _tableHeaderViewHeight_ 130
#define _rightPadding_ 22
#define _topPadding_ 20

@class JBoLovingDonateCell;

/**捐物信息cell的代理
 */
@protocol JBoLovingDonateCellDelegate <NSObject>

@optional

/**点击图片预览大图
 *@param index 图片的下标
 */
- (void)lovingDonateCell:(JBoLovingDonateCell*) cell didSelectedImageAtIndex:(NSInteger) index;

/*确认收货
 */
- (void)lovingDonateCellDidConfirmed:(JBoLovingDonateCell *)cell;

/**点击头像
 */
- (void)lovingDonateDidSelectedHeadImage:(JBoLovingDonateCell*) cell;

@end

/**捐物信息cell
 */
@interface JBoLovingDonateCell : UITableViewCell<JBoMultiImageViewDelegate>

/**头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**捐物图片
 */
@property(nonatomic,readonly) JBoMultiImageView *multiImageView;

/**确认收货按钮
 */
@property(nonatomic,readonly) UIButton *confirmButton;

/**捐物的日期
 */
@property(nonatomic,readonly) JBoAttributedLabel *dateLabel;

/**捐物的数量
 */
@property(nonatomic,readonly) UILabel *countLabel;

@property(nonatomic,assign) id<JBoLovingDonateCellDelegate> delegate;

@end
