//
//  JBoLovingDonateInfo.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoUserParentInfo.h"

/**超友圈爱心活动捐赠信息
 */
@interface JBoLovingDonateInfo : JBoUserParentInfo

/**信息Id
 */
@property(nonatomic,copy) NSString *ID;

/**捐赠时间
 */
@property(nonatomic,copy) NSString *date;

/**捐赠数量
 */
@property(nonatomic,assign) int count;

/**捐赠的物品预览图 数组元素是图片路径，NSString对象
 */
@property(nonatomic,retain) NSMutableArray *imageURLArray;

/**是否已经确认收货
 */
@property(nonatomic,assign) BOOL alreadConfirm;

@end
