//
//  JBoLovingDonateViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoLovingDonateViewController;

/**爱心活动捐赠物品代理
 */
@protocol JBoLovingDonateViewControllerDelegate <NSObject>

@optional

/**捐赠信息完成
 */
- (void)lovingDonateViewControllerDidFinish:(JBoLovingDonateViewController*) viewController;

@end

/**爱心活动捐赠物品
 */
@interface JBoLovingDonateViewController : UIViewController

/**爱心活动的groupid
 */
@property(nonatomic,copy) NSString *groupId;
@property(nonatomic,assign) id<JBoLovingDonateViewControllerDelegate> delegate;

//返回
- (void)back;

@end
