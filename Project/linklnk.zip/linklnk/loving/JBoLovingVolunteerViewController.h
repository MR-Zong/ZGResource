//
//  JBoVolunteerViewController.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoLovingVolunteerViewController;

/**参加爱心志愿者代理
 */
@protocol JBoLovingVolunteerViewControllerDelegate <NSObject>

@optional

/**爱心志愿者信息完成
 */
- (void)lovingVolunteerViewControllerDidFinished:(JBoLovingVolunteerViewController*) viewController;

@end

/**参加爱心志愿者
 */
@interface JBoLovingVolunteerViewController : UIViewController

/**爱心活动的groupId
 */
@property(nonatomic,copy) NSString *groupId;
@property(nonatomic,assign) id<JBoLovingVolunteerViewControllerDelegate> delegate;

//返回
- (void)back;

@end
