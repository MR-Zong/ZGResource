//
//  JBoLovingConfirmCell.h
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoMultiImageView.h"
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"
#import "JBoChatMsgLabel.h"

#define _controlInterval_ 5
#define _controlHeight_ 21
#define _headImageSize_ 50
#define _lookAndTellCellNormalHeight_ 60
#define _tableHeaderViewHeight_ 130
#define _rightPadding_ 22
#define _topPadding_ 20

@class JBoLovingConfirmCell;

/**捐物确认收货信息的cell
 */
@protocol JBoLovingConfirmCellDelegate <NSObject>

@optional

/**点击图片预览大图
 *@param index 图片的下标
 */
- (void)lovingConfrimCell:(JBoLovingConfirmCell*) cell didSelectedImageAtIndex:(NSInteger) index;

/**点击链接
 *@param url 点击的链接
 */
- (void)lovingConfrimCell:(JBoLovingConfirmCell *)cell didSelectedURL:(NSURL*) url;

@end

@interface JBoLovingConfirmCell : UITableViewCell<JBoMultiImageViewDelegate,JBoChatMsgLabelDelegate>

/**图片集合
 */
@property(nonatomic,readonly) JBoMultiImageView *multiImageView;

/**确认信息
 */
@property(nonatomic,readonly) JBoChatMsgLabel *contentLabel;

/**确认信息高度
 */
@property(nonatomic,assign) NSInteger contentHeight;

//用户头像 昵称 说说日期
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;
@property(nonatomic,readonly) UILabel *dateLabel;



@property(nonatomic,assign) id<JBoLovingConfirmCellDelegate> delegate;

@end
