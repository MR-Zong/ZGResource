//
//  JBoLovingDonateInfo.m
//  连你
//
//  Created by kinghe005 on 14-4-7.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLovingDonateInfo.h"

@implementation JBoLovingDonateInfo

- (void)dealloc
{
    [_ID release];
    [_date release];
    [_imageURLArray release];
    
    [super dealloc];
}

@end
