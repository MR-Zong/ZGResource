//
//  main.m
//  连客
//
//  Created by kinghe005 on 13-10-30.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JBoAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([JBoAppDelegate class]));
    }
}
