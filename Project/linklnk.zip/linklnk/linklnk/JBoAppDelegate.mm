//
//  JBoAppDelegate.m
//  简宝
//
//  Created by kinghe005 on 13-10-30.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoAppDelegate.h"
#import "JBoLoginViewController.h"
#import "JBoInstantMsgInfoOperation.h"
#import "JBoImageCacheTool.h"
#import "JBoRealNameAuthenViewController.h"
#import "JBoNavigationViewController.h"
#import "JBoSystemOperation.h"
#import "JBoUserOperation.h"
#import "SSKeychain.h"
#import <MediaPlayer/MediaPlayer.h>
#import "HTTPServer.h"
#import "JBoMovieCacheTool.h"
#import "JBoSystemOperation.h"
#import <LocalAuthentication/LocalAuthentication.h>
#import "JBoTouchIdOperation.h"

#include <sys/sysctl.h>
#include <mach/mach.h>

//网络连接状态监测的地址
#define _reachHostName_ @"www.baidu.com"

//存放uuid的钥匙串
static NSString *keychainService = @"com.linklnk.KingHe";
static NSString *keychainUUIDKey = @"uuid";

@interface JBoAppDelegate ()<JBoGesturePasswdControllerDelegate>

/**http本地服务，目前用于视频播放
 */
@property(nonatomic,retain) HTTPServer *httpServer;

/**手势密码控制器
 */
@property(nonatomic,retain) JBoGesturePasswdController *gesturePasswdController;

/**百度地图引擎
 */
@property(nonatomic,retain) BMKMapManager *mapManager;

//设备唯一标识符
@property(nonatomic,copy) NSString *uuid;


@end

@implementation JBoAppDelegate

- (void)dealloc
{
    [_window release];
    [_xmpp release];
    [_md5Passwd release];
    [_version release];
    
    [_blackListArray release];
    
    [_boyImage release];
    [_girlImage release];
    [_lastDate release];
    
    [_reachability release];
   
    [_rosterAndUsernameDic release];
    [_alertView release];
    [_dataLoadingView release];
    
    [_httpServer release];
    [_gesturePasswdController release];
    
    [_mapManager release];
    [_uuid release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kReachabilityChangedNotification object:nil];
    
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    if(_ios6_0_)
    {
#ifdef __IPHONE_6_0
        self.interfaceOrientationMask = UIInterfaceOrientationMaskPortrait;
#endif
    }
    
    //获取当前版本号
    NSDictionary *localDic = [[NSBundle mainBundle] infoDictionary];
    NSString *version = [localDic objectForKey:@"CFBundleShortVersionString"];
    self.version = [version stringByReplacingOccurrencesOfString:@"." withString:@""];
    
    
    [JBoSystemOperation registerRemoteNotification];
    self.window = [[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds] autorelease];
    
    _xmpp = [[JBoXMPP alloc] init];
    
    //创建网络连接状态监测类
    _reachability = [[Reachability reachabilityWithHostName:_reachHostName_] retain];
    
    //注册网络状态改变的观察者
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(netWorkStatusChange:) name:kReachabilityChangedNotification object:nil];
    [_reachability startNotifier];
    
    
    BMKMapManager *mapManager = [[BMKMapManager alloc] init];
    self.mapManager = mapManager;
    BOOL ret = [mapManager start:_mapKey_ generalDelegate:self];
    
    if(!ret)
        NSLog(@"地图启动失败");
    [mapManager release];
    
    //活动指示器
    JBoDataLoadingView *dataLoadingView = [[JBoDataLoadingView alloc] initWithHeight:140];
    dataLoadingView.hidden = YES;
    [self.window addSubview:dataLoadingView];
    self.dataLoadingView = dataLoadingView;
    [dataLoadingView release];
    
    //消息提示框
    JBoAlertView *alertView = [[JBoAlertView alloc] initWithMessage:@" " height:140];
    alertView.hidden = YES;
    [self.window addSubview:alertView];
    self.alertView = alertView;
    [alertView release];
    
    //性别 男女  默认头像
    self.boyImage = [UIImage imageNamed:@"default_boy_image"];
    
    self.girlImage = [UIImage imageNamed:@"default_girl_image"];
    
    
    //判断是否已经登录过了
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    BOOL alreadLogin = [defaults boolForKey:_alreadLogin_];
    NSString *email = [defaults objectForKey:_loginEmail_];
    NSString *passwd = nil;
    if(email)
    {
        passwd = [defaults objectForKey:email];
    }
    
    if(alreadLogin && ![NSString isEmpty:passwd])
    {
        NSLog(@"已登录");
        
        self.md5Passwd = [[MD5 md5:passwd] lowercaseString];
        self.rosterAndUsernameDic = [NSMutableDictionary dictionary];
        [JBoUserOperation goToMainViewWithLogin:NO];
        [self.window makeKeyAndVisible];
    }
    else
    {
        JBoLoginViewController *loginVC = [[JBoLoginViewController alloc] init];
        self.window.rootViewController = loginVC;
        [loginVC release];
        [self.window makeKeyAndVisible];
    }
   
 
    [self.window bringSubviewToFront:self.dataLoadingView];
    [self.window bringSubviewToFront:self.alertView];
    if(self.gesturePasswdController)
    {
        [self.window bringSubviewToFront:self.gesturePasswdController.passwdContainer];
    }
    [self startHttpServer];
    
    //开始耳机检测
    [JBoSystemOperation beginHeadSetListener];
 
    return YES;
}

#ifdef __IPHONE_6_0
- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return self.interfaceOrientationMask;
    //return UIInterfaceOrientationMaskPortrait;
}
#endif

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    //[[UIApplication sharedApplication].keyWindow endEditing:YES];
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    self.lastDate = [NSDate date];
    [self stopHttpServer];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [self startHttpServer];
    
    NSDate *currentDate = [NSDate date];
  //  NSTimeInterval timeInterval = [currentDate timeIntervalSinceDate:self.lastDate];
    
    //网络状态
   // NSLog(@"连接状态 %d", [self.xmpp.xmppStream isConnected]);
    //[self.xmpp ping];
    
//    if(timeInterval >= _aliveTimeInterval_)
//    {
        if([self.xmpp.xmppStream isDisconnected])
        {
            [self.xmpp connect];
        }
        else
        {
            [self.xmpp ping];
        }
   // }
    self.lastDate = currentDate;
    
    if(self.xmpp.loginOut)
        return;
    
    if(_ios8_0_)
    {
#ifdef __IPHONE_8_0
        if([JBoTouchIdOperation needTouchIdDeblock])
        {
            LAContext *context = [[[LAContext alloc] init] autorelease];
            context.localizedFallbackTitle = @"";
            
            NSError *error = nil;
            if(![context canEvaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error])
            {
                NSLog(@"%@",error);
               
            }
            else
            {
                [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics localizedReason:@"您有3次指纹解锁机会，取消则重新登录" reply:^(BOOL success, NSError *error){
                    
                    if(success)
                    {
                        NSLog(@"验证成功");
                    }
                    else
                    {
                        NSLog(@"%@",error);
                        
                        if(error.code == LAErrorUserCancel)
                        {
                            dispatch_async(dispatch_get_main_queue(), ^(void){
                                
                                [self backToLogin];
                            });
                        }
                        else if(error.code == LAErrorAuthenticationFailed)
                        {
                            //失败超过3次
                            dispatch_async(dispatch_get_main_queue(), ^(void){
                                
                                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"失败次数过多，请重新登录" message:@"" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
                                [alertView show];
                                [alertView release];
                                
                                [self backToLogin];
                            });
                        }
                    }
                }];
            }
        }
        else
        {
            [self authenGesturePassword];
        }
#endif
    }
    else
    {
        [self authenGesturePassword];
    }
}

//返回登录界面
- (void)backToLogin
{
    NSString *email = [[NSUserDefaults standardUserDefaults] objectForKey:_loginEmail_];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:email];
    
    [[NSUserDefaults standardUserDefaults] synchronize];
    [JBoUserOperation loginOutNeedSendMsg:YES];
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application
{
    //清除http缓存
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
     // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    application.applicationIconBadgeNumber = 0;
    if([JBoSystemOperation isHeadphone])
    {
        [[NSUserDefaults standardUserDefaults] setInteger:JBoAudioPlayModeHook forKey:_audioPlayMode_];
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setInteger:JBoAudioPlayModeSpeaker forKey:_audioPlayMode_];
    }
    [JBoSystemOperation setupAudio];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    JBoInstantMsgInfoOperation *_instantInfoOperation = [[JBoInstantMsgInfoOperation alloc] init];
    [_instantInfoOperation exitAction];
    [_instantInfoOperation release];
    
    [JBoImageCacheTool clearCacheImageCompletion:nil];
}

#pragma mark- remoteNotification

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString *pushToken = [[[[deviceToken description]
                             stringByReplacingOccurrencesOfString:@"<" withString:@""]
                            stringByReplacingOccurrencesOfString:@">" withString:@""]
                           stringByReplacingOccurrencesOfString:@" " withString:@""];
    if(![NSString isEmpty:pushToken])
    {
        [[NSUserDefaults standardUserDefaults] setObject:pushToken forKey:_deviceToken_];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    NSLog(@"token = %@",pushToken);
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"注册推送失败 %@",error);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"didReceiveRemoteNotification %@",userInfo);
}

#if __IPHONE_8_0

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
     [application registerForRemoteNotifications];
}

#endif

//- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
//{
//    NSLog(@"didReceiveRemoteNotification completionHandler,%@",userInfo);
//}

#pragma mark-

/**app名称
 */
- (NSString*)appName
{
    return _linklnkAppName_;
}

//获取设备唯一标识符
- (NSString*)getUUID
{
    if(!self.uuid)
    {
        NSError *error = nil;
        NSString *uuid = [SSKeychain passwordForService:keychainService account:keychainUUIDKey error:&error];
        if(error)
        {
            // NSLog(@"获取设备标识符失败%@",error);
        }
        
        if([NSString isEmpty:uuid])
        {
            uuid = [SSKeychain getUUID];
            [SSKeychain setPassword:uuid forService:keychainService account:keychainUUIDKey error:&error];
            if(error)
            {
                /// NSLog(@"保存设备标识符失败%@",error);
            }
        }
        self.uuid = uuid;
    }
    
    return self.uuid;
}

- (void)closeAlertView
{
    self.alertView.hidden = YES;
    self.dataLoadingView.hidden = YES;
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}


#pragma mark- tabBar

/**获取tabBarController 如果没有则返回nil
 */
- (JBoCustomTabBarController*)tabBarController
{
    JBoCustomTabBarController *customTabBarVC = (JBoCustomTabBarController*)self.window.rootViewController;
    if([customTabBarVC isKindOfClass:[JBoCustomTabBarController class]])
    {
        return customTabBarVC;
    }
    else
    {
        return nil;
    }
}

//隐藏选项卡
- (void)hiddenCustomTabBar:(BOOL) hidden
{
    [self hiddenCustomTabBar:hidden animated:NO];
}

/**设置选项卡 tabBar的隐藏状态 可选是否动画
 *@param flag 是否动画
 */
- (void)hiddenCustomTabBar:(BOOL)hidden animated:(BOOL) flag
{
    JBoCustomTabBarController *customTabBarVC = (JBoCustomTabBarController*)self.window.rootViewController;
    if([customTabBarVC isKindOfClass:[JBoCustomTabBarController class]])
    {
        CGFloat y = hidden ? _height_ : _height_ - _tabBarHeight_;
        
        if(!hidden)
        {
            customTabBarVC.customTabBar.hidden = NO;
        }
        
        if(flag)
        {
            [UIView animateWithDuration:0.25 animations:^(void){
                
                customTabBarVC.customTabBar.top = y;
            }completion:^(BOOL finish){
                customTabBarVC.customTabBar.hidden = hidden;
            }];
        }
        else
        {
            customTabBarVC.customTabBar.hidden = hidden;
            customTabBarVC.customTabBar.top = y;
        }
    }
}

#pragma mark- statusBar

//状态栏操作
- (void)hiddenStatusBar:(BOOL)hidden
{
    JBoCustomTabBarController *customTabBarVC = (JBoCustomTabBarController*)self.window.rootViewController;
    if([customTabBarVC isKindOfClass:[JBoCustomTabBarController class]])
    {
        [customTabBarVC setStatusBarHidden:hidden];
    }
    
}

/**设置状态栏的风格 style
 */
- (void)setStatusBarStyle:(JBoStatusBarStyle)style
{
    JBoCustomTabBarController *customTabBarVC = (JBoCustomTabBarController*)self.window.rootViewController;
    if([customTabBarVC isKindOfClass:[JBoCustomTabBarController class]])
    {
        [customTabBarVC setStatusBarStyle:style];
    }
}

/**获取当前状态栏的风格 style
 */
- (JBoStatusBarStyle)statusBarStyle
{
    JBoCustomTabBarController *customTabBarVC = (JBoCustomTabBarController*)self.window.rootViewController;
    if([customTabBarVC isKindOfClass:[JBoCustomTabBarController class]])
    {
        return customTabBarVC.customStatusStyle;
    }
    return JBoStatusBarStyleDefault;
}

#pragma mark- realName auth

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex == 1)
    {
        //实名认证
        JBoRealNameAuthenViewController *realName = [[JBoRealNameAuthenViewController alloc] init];
        realName.black = YES;
        realName.present = YES;
        JBoNavigationViewController *nav = [[JBoNavigationViewController alloc] initWithRootViewController:realName];
        nav.navigationBar.translucent = NO;
        [self.window.rootViewController presentViewController:nav animated:YES completion:nil];
        [nav release];
        [realName release];
    }
}

#pragma mark-百度地图启动代理

- (void)onGetPermissionState:(int)iError
{
    if(iError)
    {
        NSLog(@"地图加载错误：%d",iError);
    }
}

- (void)onGetNetworkState:(int)iError
{
    if(iError)
    {
        NSLog(@"地图网络错误:%d",iError);
    }
}

#pragma mark- network changed

//网络状态改变触发方法
- (void)netWorkStatusChange:(NSNotification*)notification
{
    NSLog(@"网络状态改变了");
    
    NetworkStatus status = [_reachability currentReachabilityStatus];

    _previousWorkStatus = status;
    if([self.xmpp.xmppStream isDisconnected])
    {
        [self.xmpp connect];
    }
    else
    {
        [self.xmpp ping];
    }
}

#pragma mark- local server

/**开始本地http服务 目前用于视频播放
 */
- (void)startHttpServer
{
    if([self.httpServer isRunning])
        return;
    
    if(!self.httpServer)
    {
        //本地服务
        HTTPServer *server = [[HTTPServer alloc] init];
        
        // [server setPort:12345];
        //服务类型为http
        [server setType:@"_http._tcp."];
        
        //NSString *cache = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
        [server setDocumentRoot:NSTemporaryDirectory()];
        self.httpServer = server;
        [server release];
    }
    
    NSError *error = nil;
    [self.httpServer start:&error];
    
    if(error)
    {
        NSLog(@"启动http服务失败%@",error);
    }
    NSLog(@"httpServer running %d",[self.httpServer isRunning]);
}

/**获取http服务的端口
 */
- (UInt16)httpServerPort
{
    UInt16 port = [self.httpServer listeningPort];
    return port;
}

/**获取本地http请求的前缀
 */
- (NSString*)httpPrefiex
{
    return [NSString stringWithFormat:@"http://127.0.0.1:%d/",[self httpServerPort]];
}

/**本地http服务的文件夹
 */
- (NSString*)webRootDocument
{
    return [self.httpServer documentRoot];
}

/**停止本地http服务
 */
- (void)stopHttpServer
{
    [self.httpServer stop];
}

#pragma mark- gesturePassword

//手势密码验证
- (void)authenGesturePassword
{
    NSString *passwd = [JBoGesturePasswdController getGesturePasswd];
    if(passwd)
    {
        [self showGesturePasswdWithType:JBoGesturePasswdControllerOperationTypeValidate];
    }
}

- (void)showGesturePasswdWithType:(JBoGesturePasswdControllerOperationType)type
{
    if([self.window.rootViewController isKindOfClass:[JBoCustomTabBarController class]])
    {
        if(!self.gesturePasswdController)
        {
            self.gesturePasswdController = [[[JBoGesturePasswdController alloc] init] autorelease];
            self.gesturePasswdController.delegate = self;
            self.gesturePasswdController.type = type;
            [self.gesturePasswdController show];
            _gesturePaaswdShow = YES;
        }
    }
}

- (void)gesturePassWdControllerDidFinish:(JBoGesturePasswdController *)controller
{
    _gesturePaaswdShow = NO;
    self.gesturePasswdController = nil;
}


@end
