//
//  JBoAppDelegate.h
//  简宝
//
//  Created by kinghe005 on 13-10-30.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMapKit.h"
#import "Reachability.h"
#import "JBoBasic.h"
#import "JBoDataLoadingView.h"
#import "JBoXMPP.h"
#import "JBoRosterInfo.h"
#import "JBoAlertView.h"
#import "FMDatabase.h"
#import "JBoCustomTabBarController.h"
#import "JBoGesturePasswdController.h"
#import "MD5.h"

@interface JBoAppDelegate : UIResponder <UIApplicationDelegate,BMKGeneralDelegate,UIAlertViewDelegate>

/**默认男头像
 */
@property(nonatomic,retain) UIImage *boyImage;
/**默认女头像
 */
@property(nonatomic,retain) UIImage *girlImage;

/**屏幕支持的旋转 default is UIInterfaceOrientationMaskPortrait 竖屏
 */
@property(nonatomic,assign) NSInteger interfaceOrientationMask;

@property (retain, nonatomic) UIWindow *window;

/**xmpp协议控制类
 */
@property (nonatomic, readonly) JBoXMPP *xmpp;

/**黑名单列表 元素是NSString 对象 用户userID
 */
@property (nonatomic,retain) NSMutableArray *blackListArray;

/**进入后台的时间
 */
@property (nonatomic, retain) NSDate *lastDate;

/**检测网络连接状态
 */
@property (nonatomic, readonly) Reachability *reachability;

/**最后的网络状态
 */
@property (nonatomic, readonly) NetworkStatus previousWorkStatus;

/**加载指示器
 */
@property (nonatomic,retain) JBoDataLoadingView *dataLoadingView;

/**消息提示框
 */
@property (nonatomic,retain) JBoAlertView *alertView;

/**好友信息 key 是用户ID value 是一个 JBoRosterInfo对象
 */
@property (nonatomic,retain) NSMutableDictionary *rosterAndUsernameDic;

/**是否正在输入手势密码
 */
@property (nonatomic,readonly) BOOL gesturePaaswdShow;

/**MD5加密的用户登录密码
 */
@property (nonatomic,copy) NSString *md5Passwd;

/**当前app版本号格式为 233
 */
@property (nonatomic,copy) NSString *version;

/**app名称
 */
@property (nonatomic,readonly) NSString *appName;

/**关闭消息提示框JBoAlertView 加载指示器JBoDataLoadingView 状态栏网络活动指示器
 */
- (void)closeAlertView;

#pragma mark- tabbar

/**获取tabBarController 如果没有则返回nil
 */
- (JBoCustomTabBarController*)tabBarController;

/**设置选项卡 tabBar的隐藏状态
 */
- (void)hiddenCustomTabBar:(BOOL) hidden;

/**设置选项卡 tabBar的隐藏状态 可选是否动画
 *@param flag 是否动画
 */
- (void)hiddenCustomTabBar:(BOOL)hidden animated:(BOOL) flag;

#pragma mark- statusBar

/**设置状态栏 statusBar的隐藏状态
 */
- (void)hiddenStatusBar:(BOOL) hidden;

/**设置状态栏的风格 style 
 */
- (void)setStatusBarStyle:(JBoStatusBarStyle) style;

/**获取当前状态栏的风格 style
 */
- (JBoStatusBarStyle)statusBarStyle;

#pragma mark- local httpServer

/**开始本地http服务 目前用于视频播放
 */
- (void)startHttpServer;

/**获取http服务的端口
 */
- (UInt16)httpServerPort;

/**获取本地http请求的前缀
 */
- (NSString*)httpPrefiex;

/**本地http服务的文件夹
 */
- (NSString*)webRootDocument;

/**停止本地http服务
 */
- (void)stopHttpServer;

/**获取设备唯一标识符
 */
- (NSString*)getUUID;

/**设置或者输入手势密码
 */
- (void)showGesturePasswdWithType:(JBoGesturePasswdControllerOperationType) type;

@end
