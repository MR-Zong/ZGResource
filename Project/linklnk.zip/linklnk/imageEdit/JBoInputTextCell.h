//
//  JBoInputTextCell.h
//  靓咖
//
//  Created by kinghe005 on 14-8-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditBaseCell.h"
#import "JBoCustomInsetLabel.h"

/**靓图秀秀文本输入框内容视图
 */
@interface JBoInputTextContentView : UIView

/**文本内容
 */
@property(nonatomic,readonly) JBoCustomInsetLabel *textLabel;
/**背景图片
 */
@property(nonatomic,readonly) UIImageView *imageView;
/**是否存在文本
 */
@property(nonatomic,assign) BOOL hasText;


@end

@class JBoInputTextCell;

@protocol JBoInputTextCellDelegate <JBoImageEditBaseCellDelegate>

/**cell开始输入文本
 */
- (void)cellDidBeganInputText:(JBoInputTextCell *) cell;

@end

/**靓图秀秀文本输入框
 */
@interface JBoInputTextCell : JBoImageEditBaseCell

@property(nonatomic,assign) id<JBoInputTextCellDelegate> delegate;

/**文本输入内容视图
 */
@property(nonatomic,retain) JBoInputTextContentView *inputTextContentView;

@end
