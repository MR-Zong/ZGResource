//
//  JBoBrushScrollView.h
//  连你
//
//  Created by kinghe005 on 14-1-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoDrawDreamBorderView.h"

@interface JBoBrushCell : UIView

@property(nonatomic,readonly) UIView *borderView;
@property(nonatomic,readonly) UIView *innerView;

@property(nonatomic,retain) UIColor *borderColor;
@property(nonatomic,retain) UIColor *selectedBorderColor;
@property(nonatomic,assign) CGFloat borderWidth;

@property(nonatomic,assign) BOOL selected;
@property(nonatomic,assign) NSInteger index;

@end

@class JBoBrushScrollView;

@protocol JBoBrushScrollViewDelegate <NSObject>

@optional
- (void)brushScrollView:(JBoBrushScrollView*) brush didSelectedColorAtIndex:(NSInteger) index;
- (void)brushScrollView:(JBoBrushScrollView*) brush lineWidthDidChanged:(CGFloat) lineWidth;
- (void)brushScrollView:(JBoBrushScrollView *)brush DidUndone:(UIButton*) button;

@end

@interface JBoBrushScrollView : UIView
{
    UIScrollView *_scrollView;
    UIImageView *_eraserImageView;
    
    UILabel *_lineWidhtLabel;
    UISlider *_lineWidhtSlider;
}

@property(nonatomic,readonly) UIButton *undoButton;
@property(nonatomic,readonly) NSMutableArray *colorArray;
@property(nonatomic,retain) UIColor *selectedColor;
@property(nonatomic,assign) CGFloat lineWidth;

@property(nonatomic,assign) id<JBoBrushScrollViewDelegate> delegate;

@property(nonatomic,assign) CGBlendMode blendMode;

- (void)selectedColorAtIndex:(NSInteger) index;
- (void)selectedLineWidth:(CGFloat) width;

@end
