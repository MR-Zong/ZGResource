//
//  JBoColorPickerViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-8-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"
#import "JBoImageEditorViewController.h"

/**颜色选择
 */
@interface JBoColorPickerViewController : JBoViewController

/**编辑器的操作类型 default is 'JBoImageEditorOperationTypeSave'
 */
@property(nonatomic,assign) JBoImageEditorOperationType type;

//图片选择代理
@property(nonatomic,assign) id delegate;

@end
