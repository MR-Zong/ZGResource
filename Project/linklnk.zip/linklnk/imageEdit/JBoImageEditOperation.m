//
//  JBoImageEditOperation.m
//  连你
//
//  Created by kinghe005 on 14-3-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditOperation.h"
#import "JBoImageEditWartermarkInfo.h"

@implementation JBoImageEditOperation

/**添加水印相机按钮
 *@param srcArray 水印数组 数组元素是 JBoImageEditWartermarkInfo
 */
+ (void)addCameraCell:(NSMutableArray*) srcArray
{
    UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"imageAdded@2x" ofType:@"png"]];
    
    JBoImageEditWartermarkInfo *info = [[JBoImageEditWartermarkInfo alloc] init];
    info.thumbnail = image;
    [srcArray insertObject:info atIndex:0];
    
    [image release];
    [info release];
}

@end
