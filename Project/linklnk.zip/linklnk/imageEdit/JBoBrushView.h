//
//  JBoBrushView.h
//  连你
//
//  Created by kinghe005 on 14-1-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoBrushDelegate.h"

@class JBoBrushView;

@protocol JBoBrushViewDelegate <NSObject>

@optional
- (void)brushViewDidSingleTap:(JBoBrushView*) brushView;
- (void)brushViewDidDraw:(JBoBrushView*) brushView;

@end

@interface JBoBrushView : UIView

//画笔
@property(nonatomic,assign) BOOL brushing;
@property(nonatomic,retain) UIColor *selectedColor;
@property(nonatomic,assign) CGFloat lineWidth;
@property(nonatomic,assign) CGBlendMode blendMode;

//画图代理
@property(nonatomic,retain) id<JBoBrushTool> brushTool;
@property(nonatomic,retain) NSMutableArray *pathArray;

@property(nonatomic,retain) UIImage *image;

@property(nonatomic,assign) id<JBoBrushViewDelegate> delegate;

- (void)undo;
- (BOOL)canUndo;

@end
