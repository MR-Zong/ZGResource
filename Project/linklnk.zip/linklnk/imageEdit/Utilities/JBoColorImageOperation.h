//
//  JBoColorImageOperation.h
//  靓咖
//
//  Created by kinghe005 on 14-5-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum _JBoComponentIndex
{
	JBoComponentIndexHue = 0,
	JBoComponentIndexSaturation = 1,
	JBoComponentIndexBrightness = 2,
} JBoComponentIndex;

float pin( float minValue, float value, float maxValue );

//生成一张多颜色的图片
CGImageRef createHSVBarContentImage(JBoComponentIndex barComponentIndex, float hsv[3]);

