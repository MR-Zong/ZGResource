//
//  UIImage+Utilities.m
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "UIImage+Utilities.h"

@implementation UIImage (Utilities)

//图片初始化
+ (UIImage*)bundleImageWithName:(NSString *)name
{
    UIImage *image = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:name ofType:@"png"]];
    return [image autorelease];
}

//重绘图片
- (UIImage*)resize:(CGSize) size
{
    CGFloat width = size.width;
    CGFloat height = size.height;
    
    CGImageRef imageRef = self.CGImage;
    CGColorSpaceRef colorSpaceRef = CGImageGetColorSpace(imageRef);
    
    CGContextRef context = CGBitmapContextCreate(NULL, width, height, 8, 0, colorSpaceRef, kCGImageAlphaPremultipliedFirst | kCGBitmapByteOrder32Little);
    if(context == NULL)
    {
        NSLog(@"CGBitmapContextCreate fail");
        return nil;
    }
    
    //重新设置重绘图片的宽和高
    if(self.imageOrientation == UIImageOrientationLeft || self.imageOrientation == UIImageOrientationRight)
    {
        width = size.height;
        height = size.width;
    }
    
    //旋转坐标系和坐标原点
    if(self.imageOrientation != UIImageOrientationUp || self.imageOrientation != UIImageOrientationUpMirrored)
    {
        if(self.imageOrientation == UIImageOrientationLeft || self.imageOrientation == UIImageOrientationLeftMirrored)
        {
            CGContextRotateCTM(context, M_PI_2);
            CGContextTranslateCTM(context, 0, - height);
        }
        else if(self.imageOrientation == UIImageOrientationRight || self.imageOrientation == UIImageOrientationRightMirrored)
        {
            CGContextRotateCTM(context, - M_PI_2);
            CGContextTranslateCTM(context, - width, 0);
        }
        else if(self.imageOrientation == UIImageOrientationDown || self.imageOrientation == UIImageOrientationDownMirrored)
        {
            CGContextTranslateCTM(context, width, height);
            CGContextRotateCTM(context, - M_PI);
        }
    }
    
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), imageRef);
    CGImageRef retImage = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    
    if(retImage != NULL)
    {
        UIImage *image = [UIImage imageWithCGImage:retImage];
        NSLog(@"%f,%f",image.size.width, image.size.height);
        CGImageRelease(retImage);
        return image;
    }
    else
    {
        NSLog(@"CGBitmapContextCreateImage fail");
        return nil;
    }
}

//通过指定大小获取图片的最大值
- (CGSize)shrinkWithContraintSize:(CGSize) size
{
    CGSize retSize = CGSizeZero;
    CGFloat width = self.size.width;
    CGFloat height = self.size.height;
    
    if(width == height)
    {
        CGFloat min = MIN(size.width, size.height);
        width = width > min ? min : width;
        height = width;
    }
    else
    {
        CGFloat heightScale = height / size.height;
        CGFloat widthScale = width / size.width;
        
        if(height >= size.height && width >= size.width)
        {
            if(heightScale > widthScale)
            {
                height = height / heightScale;
                width = width / heightScale;
            }
            else
            {
                height = height / widthScale;
                width = width / widthScale;
            }
        }
        else
        {
            if(height >= size.height && width <= size.width)
            {
                height = height / heightScale;
                width = width / heightScale;
            }
            else if(height <= size.height && width >= size.width)
            {
                height = height / widthScale;
                width = width / widthScale;
            }
        }
    }
    
    retSize = CGSizeMake(width, height);
    return retSize;
}

//等比例缩小图片
- (UIImage*)resizeWithContraintSize:(CGSize) size;
{
    CGSize resize = [self shrinkWithContraintSize:size];
    return [self resize:resize];
}

//截取图片
- (UIImage*)subImageWithRect:(CGRect)rect
{
    CGPoint origin = CGPointMake(-rect.origin.x, -rect.origin.y);
    
    UIImage *img = nil;
    
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(floorf(rect.size.width), floorf(rect.size.height)), NO, 0.0f);
    [self drawAtPoint:origin];
    img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}

//重绘图片
- (UIImage*)redraw
{
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(floorf(self.size.width), floorf(self.size.height)), NO, 0.0f);
    [self drawAtPoint:CGPointZero];
    UIImage *retImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return retImage;
}


//等比例缩小的缩略图
- (UIImage*)aspectFitThumbnailWithSize:(CGSize) size
{
    CGSize retSize = [self shrinkWithContraintSize:size];
    return [self resize:retSize];
}

//居中截取的缩略图
- (UIImage*)aspectFillThumbnailWithSize:(CGSize)size
{
    CGFloat width = size.width;
    CGFloat height = size.height;
    
    CGFloat orgWidth = self.size.width;
    CGFloat orgHeight = self.size.height;
    
    
    CGImageRef imageRef = self.CGImage;
    CGColorSpaceRef colorSpaceRef = CGImageGetColorSpace(imageRef);
    
    CGContextRef context = CGBitmapContextCreate(NULL, width, height, 8, 0, colorSpaceRef, kCGImageAlphaPremultipliedFirst | kCGBitmapByteOrder32Little);
    if(context == NULL)
    {
        NSLog(@"CGBitmapContextCreate fail");
        return nil;
    }
    
    //重新设置重绘图片的宽和高
    if(self.imageOrientation == UIImageOrientationLeft || self.imageOrientation == UIImageOrientationRight)
    {
        width = size.height;
        height = size.width;
        orgWidth = self.size.height;
        orgHeight = self.size.width;
    }
    
    //计算比例
    CGFloat scale = MAX(width / orgWidth, height / orgHeight);

    orgHeight = orgHeight * scale;
    orgWidth = orgWidth * scale;
    
    CGFloat x = fabs((orgWidth - width) / 2);
    CGFloat y = fabs((orgHeight - height) / 2);
    
    //旋转坐标系和坐标原点
    if(self.imageOrientation != UIImageOrientationUp || self.imageOrientation != UIImageOrientationUpMirrored)
    {
        if(self.imageOrientation == UIImageOrientationLeft || self.imageOrientation == UIImageOrientationLeftMirrored)
        {
            CGContextRotateCTM(context, M_PI_2);
            CGContextTranslateCTM(context, 0, - height);
        }
        else if(self.imageOrientation == UIImageOrientationRight || self.imageOrientation == UIImageOrientationRightMirrored)
        {
            CGContextRotateCTM(context, - M_PI_2);
            CGContextTranslateCTM(context, - width, 0);
        }
        else if(self.imageOrientation == UIImageOrientationDown || self.imageOrientation == UIImageOrientationDownMirrored)
        {
            CGContextRotateCTM(context, - M_PI);
            CGContextTranslateCTM(context, width, height);
        }
    }
    
    CGContextDrawImage(context, CGRectMake(-x, -y, orgWidth, orgHeight), imageRef);
    CGImageRef retImage = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    
    if(retImage != NULL)
    {
        UIImage *image = [UIImage imageWithCGImage:retImage];
        CGImageRelease(retImage);
        return image;
    }
    else
    {
        NSLog(@"CGBitmapContextCreateImage fail");
        return nil;
    }
}

//圆形图片
- (UIImage*)circleImageWithBorderColor:(UIColor *)color borderWidth:(CGFloat)borderWidth innerPadding:(CGFloat)padding
{
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(floorf(self.size.width + borderWidth), floorf(self.size.height + borderWidth)), NO, 0.0f);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //获取半径和圆心
    CGFloat radius = self.size.width > self.size.height ? self.size.height / 2.0 : self.size.width / 2.0;
//    if(color)
//    {
//        radius -= (borderWidth + padding);
//    }
    CGPoint center = CGPointMake(self.size.width / 2.0, self.size.height / 2.0);;
    
    //切割画板
    CGContextSetLineWidth(context, padding);
    CGContextSetStrokeColorWithColor(context, [UIColor clearColor].CGColor);
    CGContextAddArc(context, center.x, center.y, radius, 0.0, 2.0 * M_PI, YES);
    CGContextClip(context);
    
    //绘图
    [self drawAtPoint:CGPointMake(0, 0)];
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    if(color != nil)
    {
        return [self addCircleBorderWithBorderColor:color borderWidth:borderWidth innerPadding:padding image:image];
    }
    else
    {
        return image;
    }
}

//添加圆形边框
- (UIImage*)addCircleBorderWithBorderColor:(UIColor *)color borderWidth:(CGFloat)borderWidth innerPadding:(CGFloat)padding image:(UIImage *)image
{
    CGSize size = CGSizeMake(image.size.width + borderWidth * 2, image.size.height + borderWidth * 2);
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(floorf(size.width), floorf(size.height)), NO, 0.0f);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    NSLog(@"%f,%f",size.height, size.width);
     //画圆
    CGContextSetLineWidth(context, borderWidth);
    CGContextSetStrokeColorWithColor(context, color.CGColor);
    CGContextStrokeEllipseInRect(context, CGRectMake(borderWidth, borderWidth, image.size.width, image.size.height));
    
    //绘图
    [image drawAtPoint:CGPointMake(borderWidth + borderWidth / 2.0, borderWidth + borderWidth / 2.0)];
    
    UIImage *retImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return retImage;
}

//把UIImage轉成bitmap
- (unsigned char *)createRGBABitmap
{
    CGContextRef context = NULL;
    CGColorSpaceRef colorSpace;
    unsigned char *bitmap;
    size_t bitmapSize;
    size_t bytesPerRow;
    
    CGImageRef image = self.CGImage;
    
    size_t width = CGImageGetWidth(image);
    size_t height = CGImageGetHeight(image);
    
    bytesPerRow   = (width * 4);
    bitmapSize     = (bytesPerRow * height);
    
    bitmap = malloc( bitmapSize );
    if (bitmap == NULL)
    {
        return NULL;
    }
    
    colorSpace = CGColorSpaceCreateDeviceRGB();
    if (colorSpace == NULL)
    {
        free(bitmap);
        return NULL;
    }
    
    CGBitmapInfo kBGRxBitmapInfo = kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst;
    context = CGBitmapContextCreate (bitmap,
                                     width,
                                     height,
                                     8,
                                     bytesPerRow,
                                     colorSpace,
                                     kBGRxBitmapInfo);
    
    CGColorSpaceRelease( colorSpace );
    
    if (context == NULL)
    {
        free (bitmap);
        return NULL;
    }
    
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), image);
    CGContextRelease(context);
    
    return bitmap;
}

//拷贝
- (UIImage*)deepCopy
{
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(floorf(self.size.width), floorf(self.size.height)), NO, 0.0f);
    
    [self drawAtPoint:CGPointMake(0, 0)];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    return image;
}

#pragma mark- class method

/**从图片资源中获取图片数据
 */
+ (UIImage*)imageFromAsset:(ALAsset*) asset
{
    if(asset == nil)
        return nil;
    
    ALAssetRepresentation *representation = [asset defaultRepresentation];
    
    //获取正确的图片方向
    UIImageOrientation orientation = UIImageOrientationUp;
    NSNumber *number = [asset valueForProperty:@"ALAssetPropertyOrientation"];
    
    if(number != nil)
    {
        orientation = [number intValue];
    }
    
    UIImage *image = [UIImage imageWithCGImage:[representation fullResolutionImage] scale:representation.scale orientation:orientation];
    
    return image;
}

@end
