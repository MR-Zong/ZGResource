//
//  JBoImageEditMenuItemView.m
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditMenuItemView.h"

@implementation JBoImageEditMenuItemView

- (id)initWithFrame:(CGRect)frame icon:(UIImage *)icon title:(NSString *)title
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        CGFloat padding = 5;
        CGFloat size = frame.size.width - padding * 2;
        CGFloat titleHeight = frame.size.height - size - padding;
        
        _iconImageView = [[UIImageView alloc] initWithImage:icon];
        _iconImageView.backgroundColor = [UIColor clearColor];
        _iconImageView.layer.borderColor = [UIColor whiteColor].CGColor;
        _iconImageView.layer.borderWidth = 1.0;
        _iconImageView.frame = CGRectMake(padding, padding, size, size);
        [self addSubview:_iconImageView];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, frame.size.height - titleHeight, frame.size.width, titleHeight)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.font = [UIFont systemFontOfSize:10.0];
        [_titleLabel setTextAlign:JBoTextAlignmentCenter];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.text = title;
        [self addSubview:_titleLabel];

    }
    return self;
}

- (void)dealloc
{
    [_iconImageView release];
    [_titleLabel release];
    [_selectedView release];
    
    [super dealloc];
}

- (void)setSelected:(BOOL)selected
{
    if(_selected != selected)
    {
        _selected = selected;
        if(!self.selectedView)
        {
            _selectedView = [[UIView alloc] initWithFrame:self.bounds];
            _selectedView.backgroundColor = _selectedBackgroundColor_;
            [self addSubview:_selectedView];
        }
        _selectedView.hidden = !_selected;
    }
}

@end
