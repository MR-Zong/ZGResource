//
//  UIImage+Utilities.h
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface UIImage (Utilities)

//图片初始化
+ (UIImage*)bundleImageWithName:(NSString*) name;

//依据大小重绘图片
- (UIImage*)resize:(CGSize) size;

//通过指定大小获取图片的最大值
- (CGSize)shrinkWithContraintSize:(CGSize) size;

//等比例缩小图片
- (UIImage*)resizeWithContraintSize:(CGSize) size;

//截取图片
- (UIImage*)subImageWithRect:(CGRect) rect;

//重绘图片
- (UIImage*)redraw;

//等比例缩小的缩略图
- (UIImage*)aspectFitThumbnailWithSize:(CGSize) size;

//居中截取的缩略图
- (UIImage*)aspectFillThumbnailWithSize:(CGSize) size;

//圆形图片
- (UIImage*)circleImageWithBorderColor:(UIColor*) color borderWidth:(CGFloat) borderWidth innerPadding:(CGFloat) padding;

//把UIImage轉成bitmap 需要调用free(),避免内存泄露;
- (unsigned char *)createRGBABitmap;

//拷贝
- (UIImage*)deepCopy;

#pragma mark- class method

/**从图片资源中获取图片数据
 */
+ (UIImage*)imageFromAsset:(ALAsset*) asset;

@end
