//
//  UIView+Utilities.h
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Utilities)
/**
 frame.origin.y
*/
@property (nonatomic) CGFloat top;
/**
 frame.origin.y + frame.size.height
 */
@property (nonatomic) CGFloat bottom;
/**
 frame.origin.x + frame.size.width
 */
@property (nonatomic) CGFloat right;
/**
 frame.origin.x
 */
@property (nonatomic) CGFloat left;
/**
 frame.size.width
 */
@property (nonatomic) CGFloat width;
/**
 frame.size.height
 */
@property (nonatomic) CGFloat height;

@end
