//
//  JBoImageEditMenuItemView.h
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

#define _imageEditItemIconDefuaultSize_ 50.0
#define _selectedBackgroundColor_ [[UIColor cyanColor] colorWithAlphaComponent:0.5]

@interface JBoImageEditMenuItemView : UIView

@property(nonatomic,readonly) UIImageView *iconImageView;
@property(nonatomic,readonly) UILabel *titleLabel;
@property(nonatomic,readonly) UIView *selectedView;

@property(nonatomic,assign) BOOL selected;

- (id)initWithFrame:(CGRect)frame icon:(UIImage*) icon title:(NSString*) title;

@end
