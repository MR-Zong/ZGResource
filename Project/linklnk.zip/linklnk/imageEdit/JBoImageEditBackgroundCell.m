//
//  JBoImageEditBackgroundCell.m
//  靓咖
//
//  Created by kinghe005 on 14-8-23.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditBackgroundCell.h"

@interface JBoImageEditBackgroundCell ()

@end

@implementation JBoImageEditBackgroundCell

- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat)padding
{
    self = [super initWithFrame:frame contentPadding:padding];
    if (self)
    {
        [self setupDefaultAttributes];
        
    }
    return self;
}

#pragma mark- super method

- (void)setupDefaultAttributes
{
    [super setupDefaultAttributes];

    //内容
    UIView *contentView = [[UIView alloc] initWithFrame:CGRectInset(self.bounds, self.contentPadding, self.contentPadding)];
    contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    contentView.userInteractionEnabled = YES;
    [self addSubview:contentView];
    self.contentView = contentView;
    [contentView release];
    
    [self setupSubviewsPosition];
}


- (void)selectedTap:(id)sender
{
    self.selected = !self.selected;
    if([self.delegate respondsToSelector:@selector(cellDidSelected:)])
    {
        [self.delegate cellDidSelected:self];
    }
}

@end
