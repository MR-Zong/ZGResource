//
//  JBoDrawDreamBorderView.h
//  连你
//
//  Created by kinghe005 on 14-1-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _cellInteractiveBorderSize_ 2.0

@interface JBoDrawDreamBorderView : UIView

@property(nonatomic,assign) CGFloat borderWidth;
@property(nonatomic,retain) UIColor *borderColor;

@end
