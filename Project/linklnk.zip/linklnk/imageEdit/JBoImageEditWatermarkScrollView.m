//
//  JBoDrawDreamSceneScrollView.m
//  连客
//
//  Created by kinghe005 on 13-12-28.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoImageEditWatermarkScrollView.h"
#import "JBoImageTextTool.h"
#import "JBoImageEditWartermarkInfo.h"
#import "JBoBasic.h"
#import "JBoImageEditOperation.h"
#import <QuartzCore/QuartzCore.h>

#define _sectionBgColor_ [UIColor colorWithWhite:0.7 alpha:0.5]

@implementation JBoImageEditWatermarkCell

- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier width:(CGFloat)width
{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    if(self)
    {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        _singleImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_JBoImageEditWatermarkCellMargin_, _JBoImageEditWatermarkCellMargin_, _JBoImageEditWatermarkCellSize_, _JBoImageEditWatermarkCellSize_)];
        [self.contentView addSubview:_singleImageView];
    }
    return self;
}

- (void)dealloc
{
    [_singleImageView release];
    [super dealloc];
}


@end

@implementation JBoImageEditWatermarkScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        //横向滚动的水印列表
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero];
        [_tableView.layer setAnchorPoint:CGPointMake(0.0, 0.0)];
        _tableView.transform = CGAffineTransformMakeRotation(M_PI / -2);
        _tableView.frame = CGRectMake(0, self.frame.size.height, self.frame.size.width, self.frame.size.height);
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.showsHorizontalScrollIndicator = NO;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.rowHeight = _JBoImageEditWatermarkCellSize_ + _JBoImageEditWatermarkCellMargin_ * 2;
        [self addSubview:_tableView];
        
        //加载指示器
        _actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _actView.hidesWhenStopped = YES;
        _actView.frame = CGRectMake((self.frame.size.width - 40) / 2, (self.frame.size.height - 40) / 2, 40, 40);
        [self addSubview:_actView];
        
    }
    return self;
}

- (void)setLoading:(BOOL)loading
{
    if(_loading != loading)
    {
        _loading = loading;
        
        if(_loading)
        {
            [_actView startAnimating];
        }
        else
        {
            [_actView stopAnimating];
        }
    }
}

- (void)dealloc
{
    self.delegate = nil;
    [_srcArray release];
    
    [_tableView release];
    [_actView release];
    
    [super dealloc];
}

/**加载完成
 */
- (void)loadingDidFinished
{
    self.loading = NO;
    [_tableView reloadData];
}

- (void)setSrcArray:(NSMutableArray *)srcArray
{
    if(_srcArray != srcArray)
    {
        [_srcArray release];
        _srcArray = [srcArray retain];
    
        [_tableView reloadData];
    }
}

#pragma mark- UITableView delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.srcArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoImageEditWatermarkCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoImageEditWatermarkCell alloc] initWithReuseIdentifier:cellIdentifier width:_JBoImageEditWatermarkCellSize_ + _JBoImageEditWatermarkCellMargin_ * 2] autorelease];
        cell.singleImageView.transform = CGAffineTransformMakeRotation(M_PI / 2);
    }
    
    JBoImageEditWartermarkInfo *info = [self.srcArray objectAtIndex:indexPath.row];
    cell.singleImageView.image = info.thumbnail;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if([self.delegate respondsToSelector:@selector(imageEditWatermarkScrollView:didSelectedImage:)])
    {
        JBoImageEditWartermarkInfo *info = [self.srcArray objectAtIndex:indexPath.row];
        [self.delegate imageEditWatermarkScrollView:self didSelectedImage:info.image];
    }
}

@end
