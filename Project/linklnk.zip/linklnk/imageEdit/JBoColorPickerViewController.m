//
//  JBoColorPickerViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-8-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoColorPickerViewController.h"
#import "JBoSaturationBrightnessPickerView.h"
#import "JBoHuePickerView.h"
#import "JBoImageTextTool.h"
#import "JBoRGBAInputView.h"

@interface JBoColorPickerViewController ()<JBoSaturationBrightnessPickerViewDelegate,JBoHuePickerViewDelegate,JBoRGBAInputViewDelegate>

//当前选择的背景颜色显示视图
@property(nonatomic,retain) UIView *colorView;

//饱和度亮度选择
@property(nonatomic,retain) JBoSaturationBrightnessPickerView *SBPickerView;

//色彩选择
@property(nonatomic,retain) JBoHuePickerView *huePickerView;

//颜色rgb显示和输入视图
@property(nonatomic,retain) JBoRGBAInputView *inputView;

@end

@implementation JBoColorPickerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.title = @"选择背景颜色";
        self.type = JBoImageEditorOperationTypeSave;
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_colorView release];
    [_SBPickerView release];
    [_huePickerView release];
    
    self.delegate = nil;
    [_inputView release];
    
    [super dealloc];
}

#pragma mark- 加载视图

- (void)finish
{
    [self setRequest:YES];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
       
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)];
        view.backgroundColor = self.colorView.backgroundColor;
        UIImage *image = [JBoImageTextTool getImageFromView:view];
        [view release];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){

            [self setRequest:NO];
            JBoImageEditorViewController *editor = [[JBoImageEditorViewController alloc] initWithImage:image type:self.type];
            editor.delegate = self.delegate;
            [self.navigationController pushViewController:editor animated:YES];
            [editor release];
        });
    });
}

- (void)setRequest:(BOOL) flag
{
    self.navigationItem.leftBarButtonItem.enabled = !flag;
    self.appDelegate.dataLoadingView.hidden = !flag;
}

- (void)back
{
    UIViewController *vc = [self.navigationController.viewControllers firstObject];
    if([vc isKindOfClass:[self class]])
    {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.backItem = YES;
    [self setRightBarItemWithTitle:@"完成" action:@selector(finish)];
    
    //首选颜色
    UIColor *color = _navigationBarBackgroundDefaultColor_;
    
    self.view.backgroundColor = [UIColor clearColor];
    CGFloat padding = 10.0;
    
    
    //当前选择的背景颜色显示视图
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(padding, padding, _width_ - padding * 2, 45.0)];
    view.backgroundColor = color;
    [self.view addSubview:view];
    self.colorView = view;
    [view release];
    
    //饱和度亮度选择
    JBoSaturationBrightnessPickerView *sbView = [[JBoSaturationBrightnessPickerView alloc] initWithFrame:CGRectMake(self.colorView.left, self.colorView.bottom + padding, self.colorView.width, _height_ - _statuBarHeight_ - _navgateBarHeight_ - self.colorView.bottom - padding * 2 - self.colorView.height * 2)];
    sbView.delegate = self;
    sbView.color = color;
    [self.view addSubview:sbView];
    self.SBPickerView = sbView;
    [sbView release];
    
    //色彩选择
    JBoHuePickerView *hueView = [[JBoHuePickerView alloc] initWithFrame:CGRectMake(self.colorView.left, self.SBPickerView.bottom + padding, self.colorView.width, self.colorView.height)];
    hueView.delegate = self;
    hueView.color = color;
    [self.view addSubview:hueView];
    self.huePickerView = hueView;
    [hueView release];
    
    JBoRGBAInputView *inputView = [[JBoRGBAInputView alloc] initWithFrame:CGRectMake(padding, 0, _RGBAInputViewDefaultWidth_, 0)];
    inputView.delegate = self;
    inputView.currentColor = color;
    [self.view addSubview:inputView];
    self.inputView = inputView;
    [inputView release];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- JBoSaturationBrightnessPickerView代理

- (void)saturationBrightnessPickerView:(JBoSaturationBrightnessPickerView *)pickerView didSelectColor:(UIColor *)color
{
    self.colorView.backgroundColor = color;
    self.inputView.currentColor = color;
}

#pragma mark- JBoHuePickerView代理

- (void)huePickerView:(JBoHuePickerView *)pickerView didSelectHue:(CGFloat)hue
{
    self.SBPickerView.hue = hue;
    self.colorView.backgroundColor = self.SBPickerView.color;
    self.inputView.currentColor = self.SBPickerView.color;
}

#pragma mark- JBoRGBAInputView代理

- (void)RGBAInputView:(JBoRGBAInputView *)inputView colorDidChanged:(UIColor *)color
{
    self.SBPickerView.color = color;
    self.huePickerView.color = color;
    self.colorView.backgroundColor = color;
}

@end
