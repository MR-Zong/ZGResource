//
//  JBoImageEditCellInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditWartermarkInfo.h"

@implementation JBoImageEditWartermarkInfo

- (void)dealloc
{
    [_image release];
    [_thumbnail release];
    
    [super dealloc];
}

@end
