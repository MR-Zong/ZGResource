//
//  JBoImageEditorViewController.h
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**图片裁剪完成 的操作方法
 */
typedef NS_ENUM(NSInteger, JBoImageEditorOperationType)
{
    JBoImageEditorOperationTypeSave = 0, //保存到相册
    JBoImageEditorOperationTypeUse = 1, //直接使用
    JBoImageEditorOperationTypeSaveAndUse = 2 //保存并使用
};

#define _menuHeight_ 80.0

@interface JBoImageEditorViewController : JBoViewController

//图片比例
@property(nonatomic,assign) CGFloat scale;

/**原始的图片
 */
@property(nonatomic,retain) UIImage *editImage;
@property(nonatomic,readonly) UIImageView *editImageView;
@property(nonatomic,readonly) UIScrollView *scrollView;

@property(nonatomic,assign) CGFloat memuOringinalY;
@property(nonatomic,readonly) UIScrollView *menuScrollView;

@property(nonatomic,assign) JBoImageEditorOperationType type;
@property(nonatomic,assign) id delegate;

/**是否只有图片裁剪 default is 'NO'
 */
@property(nonatomic,assign) BOOL onlyCropImage;

- (id)initWithImage:(UIImage*) image type:(JBoImageEditorOperationType) type;

@end
