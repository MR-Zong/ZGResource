//
//  JBoBrushDelegate.h
//  连你
//
//  Created by kinghe005 on 14-3-17.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol JBoBrushTool <NSObject>

@property (nonatomic, retain) UIColor *lineColor;
@property (nonatomic, assign) CGFloat lineWidth;
@property (nonatomic, assign) CGBlendMode blendMode;

- (void)setInitialPoint:(CGPoint)firstPoint;
- (void)moveFromPoint:(CGPoint)startPoint toPoint:(CGPoint)endPoint;

- (void)draw;

@end


@interface JBoBrushPenTool : UIBezierPath<JBoBrushTool>
{
    CGMutablePathRef path;
}

- (CGRect)addPathPreviousPreviousPoint:(CGPoint)p2Point withPreviousPoint:(CGPoint)p1Point withCurrentPoint:(CGPoint)cpoint;

@end


@interface JBoBrushLineTool : NSObject<JBoBrushTool>

@end