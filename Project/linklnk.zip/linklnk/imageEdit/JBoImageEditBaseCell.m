//
//  JBoImageEditBaseCell.m
//  靓咖
//
//  Created by kinghe005 on 14-8-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditBaseCell.h"


#pragma mark- control

@implementation JBoDrawImageCellControl

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _iconImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        _iconImageView.userInteractionEnabled = YES;
        [self addSubview:_iconImageView];
    }
    return self;
}

- (void)dealloc
{
    [_iconImageView release];
    [super dealloc];
}

@end

#pragma mark- cell

@interface JBoImageEditBaseCell ()
//旋转正弦
@property (nonatomic, assign) float deltaAngle;

//当前触摸点
@property (nonatomic, assign) CGPoint touchStart;

//捏合手势最后的缩放比例
@property (nonatomic, assign) CGFloat lastPinchScale;

//是否拖动
@property (nonatomic, assign) BOOL dragging;

//缩放第一个触摸点
@property (nonatomic, assign) CGPoint zoomStart;

//缩放第一次触发视图的大小
@property (nonatomic, assign) CGRect zoomStartBounds;

//缩放第一次触发视图中心
@property (nonatomic, assign) CGPoint zoomStartCenter;

//当前旋转到的角度
@property (nonatomic, assign) float curAngle;

@end

@implementation JBoImageEditBaseCell

- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame contentPadding:_cellGlobalInset_];
}

- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat)padding
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.contentPadding = padding;
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_contentView release];
    [_rotateControl release];
    
    [_toLeftAndBottomControl release];
    [_toRightAndTopControl release];
    [_closeControl release];
    
    [_borderView release];
    
    [super dealloc];
}

#pragma mark- public method

//初始化参数
- (void)setupDefaultAttributes
{
    _borderView = [[JBoDrawDreamBorderView alloc] initWithFrame:CGRectZero];
    [_borderView setHidden:YES];
    [self addSubview:_borderView];
    
    self.preventsPositionOutsideSuperview = YES;
    self.preventsLayoutWhileResizing = YES;
    self.preventsResizing = NO;
    
    //关闭
    self.closeControl = [[[JBoDrawImageCellControl alloc]initWithFrame:CGRectZero] autorelease];
    self.closeControl.backgroundColor = [UIColor clearColor];
    self.closeControl.autoresizingMask = UIViewAutoresizingNone;
    self.closeControl.iconImageView.image = [UIImage imageNamed:@"draw_delete_btn.png"];
    self.closeControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    self.closeControl.userInteractionEnabled = YES;
    UITapGestureRecognizer *closeTap = [[UITapGestureRecognizer alloc]
                                         initWithTarget:self
                                         action:@selector(close:)];
    [self.closeControl addGestureRecognizer:closeTap];
    [self addSubview:self.closeControl];
    [closeTap release];
    
    //旋转
    self.rotateControl = [[[JBoDrawImageCellControl alloc]initWithFrame:CGRectZero] autorelease];
    self.rotateControl.backgroundColor = [UIColor clearColor];
    self.rotateControl.autoresizingMask = UIViewAutoresizingNone;
    self.rotateControl.userInteractionEnabled = YES;
    self.rotateControl.iconImageView.image = [UIImage imageNamed:@"draw_rotate_btn"];
    self.rotateControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    
    UIPanGestureRecognizer *panResizeGesture = [[UIPanGestureRecognizer alloc]
                                                initWithTarget:self
                                                action:@selector(resizeTranslate:)];
    [self.rotateControl addGestureRecognizer:panResizeGesture];
    [panResizeGesture release];
    [self addSubview:self.rotateControl];
    
    self.toRightAndTopControl = [self controlWithTag:1];
    self.toLeftAndBottomControl = [self controlWithTag:2];
    
    
    self.deltaAngle = atan2(self.frame.origin.y + self.frame.size.height - self.center.y,
                            self.frame.origin.x + self.frame.size.width - self.center.x);
    
    
    //添加单击手势
    UITapGestureRecognizer *selectedTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectedTap:)];
    selectedTap.delegate = self;
    [self addGestureRecognizer:selectedTap];
    [selectedTap release];
    
    //捏合手势
    UIPinchGestureRecognizer *pinchGesture = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchHandle:)];
    [self addGestureRecognizer:pinchGesture];
    [pinchGesture release];

    
    self.autoresizesSubviews = YES;
    
    self.editable = YES;
    
    [self setupSubviewsPosition];
    
    [self layoutSubviewsAfterResize];
    
    self.maxWidth = _borderView.bounds.size.width * 3 + self.contentPadding * 2;
    self.maxHeight = _borderView.bounds.size.height * 3 + self.contentPadding * 2;
    self.minWidth = _borderView.bounds.size.width / 2.0 + self.contentPadding * 2;
    self.minHeight = _borderView.bounds.size.height / 2.0 + self.contentPadding * 2;
}

/**视图缩放 子类重写该方法时必须调用 [super layoutSubviewsAfterResize];
 */
- (void)layoutSubviewsAfterResize
{
    _borderView.frame = CGRectInset(self.bounds, self.contentPadding, self.contentPadding);
    [_borderView setNeedsDisplay];
    self.rotateControl.frame = CGRectMake(self.borderView.right - _cellControlSize_ / 2.0,
                                            self.borderView.bottom - _cellControlSize_ / 2.0,
                                            _cellControlSize_,
                                            _cellControlSize_);
    self.closeControl.frame = CGRectMake(self.borderView.left - _cellControlSize_ / 2.0, self.borderView.top - _cellControlSize_ / 2.0, _cellControlSize_, _cellControlSize_);
    self.toLeftAndBottomControl.frame = CGRectMake(self.borderView.right - _cellControlSize_ / 2.0, self.borderView.top - _cellControlSize_ / 2.0, _cellControlSize_, _cellControlSize_);
    self.toRightAndTopControl.frame = CGRectMake(self.borderView.left - _cellControlSize_ / 2.0, self.borderView.bottom - _cellControlSize_ / 2.0, _cellControlSize_, _cellControlSize_);
    _contentView.frame = CGRectInset(self.bounds, self.contentPadding, self.contentPadding);
}

/**调整 子视图在图层中的位置，把控制器放在前面
 */
- (void)setupSubviewsPosition
{
    [self bringSubviewToFront:_borderView];
    [self bringSubviewToFront:self.rotateControl];
    [self bringSubviewToFront:self.toLeftAndBottomControl];
    [self bringSubviewToFront:self.toRightAndTopControl];
    [self bringSubviewToFront:self.closeControl];
}

//点击视图
- (void)selectedTap:(id) sender
{
    
}

//关闭
- (void)close:(id) sender
{
    if([self.delegate respondsToSelector:@selector(cellDidClose:)])
    {
        [self.delegate cellDidClose:self];
    }
}

/**隐藏编辑层 子类重写该方法时必须调用 [super hideEditingHandles];
 */
- (void)hideEditingHandles
{
    self.rotateControl.hidden = YES;
    self.toLeftAndBottomControl.hidden = YES;
    self.toRightAndTopControl.hidden = YES;
    self.borderView.hidden = YES;
    self.closeControl.hidden = YES;
}

/**显示编辑层 子类重写该方法时必须调用 [super showEditingHandles];
 */
- (void)showEditingHandles
{
    self.rotateControl.hidden = NO;
    self.toLeftAndBottomControl.hidden = NO;
    self.toRightAndTopControl.hidden = NO;
    self.borderView.hidden = NO;
    self.closeControl.hidden = NO;
}

/**设定编辑控制器位置
 */
- (void)setControl:(JBoDrawImageCellControl*) control position:(JBoImageEditControlPosition) position;
{
    CGRect frame = control.frame;
    switch (position)
    {
        case JBoImageEditControlPositionLeftTop :
        {
            frame.origin.x = 0;
            frame.origin.y = 0;
        }
            break;
        case JBoImageEditControlPositionRightTop :
        {
            frame.origin.x = self.width - frame.size.width;
            frame.origin.y = 0;
        }
            break;
        case JBoImageEditControlPositionCenter :
        {
            frame.origin.x = (self.width - frame.size.width) / 2.0;
            frame.origin.y = (self.height - frame.size.height) / 2.0;
        }
            break;
        case JBoImageEditControlPositionLeftBottom :
        {
            frame.origin.x = 0;
            frame.origin.y = self.height - frame.size.height;
        }
            break;
        case JBoImageEditControlPositionRightBottom :
        {
            frame.origin.x = self.width - frame.size.width;
            frame.origin.y = self.height - frame.size.height;
        }
            break;
        default:
            break;
    }
    control.frame = frame;
}

#pragma mark- property

- (void)setSelected:(BOOL)selected
{
    if(_selected != selected)
    {
        _selected = selected;
        if(_selected)
        {
            [self showEditingHandles];
            
        }
        else
        {
            [self hideEditingHandles];
        }
    }
}

#pragma mark-gesture代理
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if([touch.view isKindOfClass:[JBoDrawImageCellControl class]])
    {
        return NO;
    }
    return YES;
}

#pragma mark- pan滑动

- (void)resizeTranslate:(UIPanGestureRecognizer *)recognizer
{
    if(!self.editable)
        return;
    self.selected = YES;
    
    
    if([recognizer state] == UIGestureRecognizerStateBegan)
    {
        self.zoomStart = [recognizer locationInView:self];
    }
    else if ([recognizer state] == UIGestureRecognizerStateChanged)
    {
        //旋转
        float ang = atan2([recognizer locationInView:self.superview].y - self.center.y,
                          [recognizer locationInView:self.superview].x - self.center.x);
        float angleDiff = self.deltaAngle - ang;
        self.curAngle = ang;
        
        if (NO == self.preventsResizing)
        {
            self.transform = CGAffineTransformMakeRotation(- angleDiff);
        }
        
        
        //缩放
        if(self.enableSingleHandResize)
        {
            if (self.bounds.size.width < self.minWidth || self.bounds.size.height < self.minHeight)
            {
                self.bounds = CGRectMake(self.bounds.origin.x,
                                         self.bounds.origin.y,
                                         self.minWidth,
                                         self.minHeight);
            }
            else
            {
                CGPoint point = [recognizer locationInView:self];
                float wChange = 0.0, hChange = 0.0;
                
                wChange = (point.x - self.zoomStart.x);
                hChange = (point.y - self.zoomStart.y);
                
                if (ABS(wChange) > 20.0f || ABS(hChange) > 20.0f)
                {
                    self.zoomStart = [recognizer locationInView:self];
                    return;
                }
                
                if (YES == self.preventsLayoutWhileResizing)
                {
                    if (wChange < 0.0f && hChange < 0.0f)
                    {
                        float change = MIN(wChange, hChange);
                        wChange = change;
                        hChange = change;
                    }
                    if (wChange < 0.0f)
                    {
                        hChange = wChange;
                    } else if (hChange < 0.0f)
                    {
                        wChange = hChange;
                    } else
                    {
                        float change = MAX(wChange, hChange);
                        wChange = change;
                        hChange = change;
                    }
                }
                
                if(self.bounds.size.width != self.bounds.size.height)
                {
                    CGFloat scale = self.bounds.size.width / self.bounds.size.height;
                    hChange = wChange / scale;
                }
                
                CGRect bounds = CGRectMake(self.bounds.origin.x, self.bounds.origin.y,
                                           self.bounds.size.width + (wChange),
                                           self.bounds.size.height + (hChange));
                bounds.size.width = bounds.size.width > self.maxWidth ? self.maxWidth : bounds.size.width;
                bounds.size.height = bounds.size.height > self.maxHeight ? self.maxHeight : bounds.size.height;
                
                self.bounds = bounds;
                self.zoomStart = [recognizer locationInView:self];
            }
        }
        
        [self layoutSubviewsAfterResize];
    }
    else if ([recognizer state] == UIGestureRecognizerStateEnded)
    {
        if([self.delegate respondsToSelector:@selector(cellDidEndEditing:)])
        {
            [self.delegate cellDidEndEditing:self];
        }
    }
}

//捏合手势
- (void)pinchHandle:(UIPinchGestureRecognizer*) pinch
{
    if(pinch.state == UIGestureRecognizerStateBegan)
    {
        self.lastPinchScale = 1.0;
        return;
    }
    
    CGFloat scale = 1.0 - (self.lastPinchScale - pinch.scale);
    
   
    CGRect bounds = self.bounds;
    bounds.size.width = bounds.size.width * scale;
    bounds.size.height = bounds.size.height * scale;
    self.bounds = bounds;
    [self layoutSubviewsAfterResize];
    self.lastPinchScale = pinch.scale;
}

//视图frame发生改变 layoutSubviews
- (void)setFrame:(CGRect)newFrame
{
    [super setFrame:newFrame];
    
    [self layoutSubviewsAfterResize];
}


#pragma mark- touchs

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    
    UITouch *touch = [touches anyObject];
    
    self.touchStart = [touch locationInView:self.superview];

    self.dragging = [touch.view isEqual:self.contentView] || [touch.view isEqual:self.borderView];
    
    if(self.dragging)
    {
        if([_delegate respondsToSelector:@selector(cellDidBeginEditing:)])
        {
            [_delegate cellDidBeginEditing:self];
        }
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesEnded:touches withEvent:event];
    if(!self.editable || !self.dragging)
        return;
    UITouch *touch = [touches anyObject];
    
    if(touch.tapCount == 2)
    {
        if([self.delegate respondsToSelector:@selector(cellDidDoubleTapped:)])
        {
            [self.delegate cellDidDoubleTapped:self];
        }
        return;
    }

    if([_delegate respondsToSelector:@selector(cellDidEndEditing:)])
    {
        [_delegate cellDidEndEditing:self];
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesCancelled:touches withEvent:event];

    if(!self.editable || !self.dragging)
        return;
    UITouch *touch = [touches anyObject];
    
    if(touch.tapCount == 2)
    {
        if([self.delegate respondsToSelector:@selector(cellDidDoubleTapped:)])
        {
            [self.delegate cellDidDoubleTapped:self];
        }
        return;
    }

    if([self.delegate respondsToSelector:@selector(cellDidCancelEditing:)])
    {
        [self.delegate cellDidCancelEditing:self];
    }
}


- (void)translateUsingTouchLocation:(CGPoint)touchPoint
{
    CGPoint newCenter = CGPointMake(self.center.x + touchPoint.x - self.touchStart.x,
                                    self.center.y + touchPoint.y - self.touchStart.y);
    
    if (self.preventsPositionOutsideSuperview) {
        // Ensure the translation won't cause the view to move offscreen.
        CGFloat midPointX = CGRectGetMidX(self.bounds);
        if (newCenter.x > self.superview.bounds.size.width - midPointX) {
            newCenter.x = self.superview.bounds.size.width - midPointX;
        }
        if (newCenter.x < midPointX) {
            newCenter.x = midPointX;
        }
        CGFloat midPointY = CGRectGetMidY(self.bounds);
        if (newCenter.y > self.superview.bounds.size.height - midPointY) {
            newCenter.y = self.superview.bounds.size.height - midPointY;
        }
        if (newCenter.y < midPointY) {
            newCenter.y = midPointY;
        }
    }
    self.center = newCenter;
    if([self.delegate respondsToSelector:@selector(cellDidMoved:)])
    {
        [self.delegate cellDidMoved:self];
    }
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesMoved:touches withEvent:event];

    if(!self.editable || !self.dragging)
        return;
    CGPoint touch = [[touches anyObject] locationInView:self.superview];
    [self translateUsingTouchLocation:touch];
    self.touchStart = touch;
}

#pragma mark- 缩放

- (void)panHandle:(UIPanGestureRecognizer*) pan
{
    CGPoint point = [pan locationInView:self.superview];
    
    
    if(pan.state == UIGestureRecognizerStateBegan)
    {
        switch (pan.view.tag)
        {
            case 1 : //左上角
            {
                point = CGPointMake(point.x - self.contentPadding, point.y + self.contentPadding);
            }
                break;
            case 2 : //右上角
            {
                point = CGPointMake(point.x + self.contentPadding, point.y - self.contentPadding);
            }
                break;
            default:
                break;
        }
        
        self.zoomStart = point;
        self.zoomStartBounds = self.bounds;
        self.zoomStartCenter = self.center;
    }
    else if (pan.state == UIGestureRecognizerStateChanged)
    {
        const CGFloat W = self.superview.width;
        const CGFloat H = self.superview.height;
        CGFloat minX = self.bounds.size.width / 2.0;
        CGFloat minY = self.bounds.size.height / 2.0;
        CGFloat maxX = W - self.bounds.size.width / 2.0;
        CGFloat maxY = H - self.bounds.size.height / 2.0;
        
        CGRect bounds = self.bounds;
        
        CGPoint center = CGPointZero;
        
        CGFloat minSize = 10.0 + self.contentPadding * 2;
        
        NSInteger tag = pan.view.tag;
        
        //旋转，控制按钮位置改变
//        if(self.curAngle != 0)
//        {
//            if(fabsf(self.curAngle) > 2.0)
//            {
//                if(tag == 1)
//                {
//                    tag = 2;
//                }
//                else
//                {
//                    tag = 1;
//                }
//            }
//        }
        
        switch (tag)
        {
            case 1 : // 左下角
            {
                point = CGPointMake(point.x - self.contentPadding, point.y + self.contentPadding);
                
                bounds.size.width = MAX(self.zoomStartBounds.size.width + self.zoomStart.x - point.x, minSize);
                bounds.size.width = MIN(bounds.size.width, self.zoomStartCenter.x + self.zoomStartBounds.size.width / 2.0);

                bounds.size.height = MAX(self.zoomStartBounds.size.height + point.y - self.zoomStart.y, minSize);
                bounds.size.height = MIN(bounds.size.height, self.superview.height - self.zoomStartCenter.y + self.zoomStartBounds.size.height / 2.0);
                
                break;
            }
            case 2 : // 右上角
            {
                point = CGPointMake(point.x + self.contentPadding, point.y - self.contentPadding);
                
                bounds.size.width = MAX(self.zoomStartBounds.size.width + point.x - self.zoomStart.x, minSize);
                bounds.size.width = MIN(bounds.size.width, self.superview.width - self.zoomStartCenter.x + self.zoomStartBounds.size.width / 2.0);
                
                bounds.size.height = MAX(self.zoomStartBounds.size.height + self.zoomStart.y - point.y, minSize);
                bounds.size.height = MIN(bounds.size.height, self.zoomStartCenter.y + self.zoomStartBounds.size.height / 2.0);
                
                break;
            }
            default:
                break;
        }
        
       
        center.x = MIN(self.zoomStartCenter.x + (point.x - self.zoomStart.x) / 2.0, maxX);
        center.x = MAX(center.x, minX);
        center.y = MIN(self.zoomStartCenter.y + (point.y - self.zoomStart.y) / 2.0 , maxY);
        center.y = MAX(center.y, minY);
        
        self.bounds = bounds;
        self.center = center;
        
        [self layoutSubviewsAfterResize];
    }
    else if(pan.state == UIGestureRecognizerStateEnded)
    {
        
    }
}

#pragma mark- private method

//创建缩放控制器
- (JBoDrawImageCellControl*)controlWithTag:(NSInteger) tag
{
    NSString *imageName = nil;
    switch (tag)
    {
        case 1 :
        {
            imageName = @"draw_right_top_zoom_btn";
        }
            break;
        case 2 :
        {
            imageName = @"draw_left_bottom_zoom_btn";
        }
            break;
        default:
            break;
    }
    
    JBoDrawImageCellControl *control = [[[JBoDrawImageCellControl alloc]initWithFrame:CGRectZero] autorelease];
    control.tag = tag;
    control.backgroundColor = [UIColor clearColor];
    control.autoresizingMask = UIViewAutoresizingNone;
    control.iconImageView.image = [UIImage imageNamed:imageName];
    control.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    control.userInteractionEnabled = YES;
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(panHandle:)];
    [control addGestureRecognizer:pan];
    [self addSubview:control];
    [pan release];
    
    return control;
}

@end
