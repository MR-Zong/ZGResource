//
//  JBoImageEditRectangleCell.h
//  linklnk
//
//  Created by kinghe005 on 15/4/17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoImageEditBaseCell.h"

/**图片编辑矩形框
 */
@interface JBoImageEditRectangleCell : JBoImageEditBaseCell

/**矩形框颜色 default is 'redColor'
 */
@property(nonatomic,retain) UIColor *rectangleColor;

@end
