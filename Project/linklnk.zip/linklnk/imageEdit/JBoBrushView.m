//
//  JBoBrushView.m
//  连你
//
//  Created by kinghe005 on 14-1-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoBrushView.h"
#import "JBoDrawImageCell.h"
#import "JBoAppDelegate.h"

#define _lineColor_ @"lineColor"
#define _line_ @"line"
#define _eraser_ @"eraser"
#define _lineWidth_ @"lineWidth"

#define _imageScale_ 2.0

@interface JBoBrushView ()<UIGestureRecognizerDelegate>

@property(nonatomic,assign) CGPoint previousPoint1;
@property(nonatomic,assign) CGPoint previousPoint2;
@property(nonatomic,assign) CGPoint currentPoint;

@end

@implementation JBoBrushView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.brushing = NO;
        self.blendMode = kCGBlendModeNormal;
        self.selectedColor = [UIColor redColor];
        
//        _snapshotImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
//        _snapshotImageView.userInteractionEnabled = YES;
//        [self addSubview:_snapshotImageView];
//        
//        _contentView = [[JBoBrushContentView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
//        _contentView.backgroundColor = [UIColor clearColor];
//        _contentView.delegate = self;
//        [self addSubview:_contentView];
        
//        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
//        pan.delegate = self;
//        [self addGestureRecognizer:pan];
//        [pan release];
        
        self.pathArray = [[[NSMutableArray alloc] init] autorelease];
    }
    return self;
}

- (void)dealloc
{

    [_selectedColor release];
    [_image release];
    [_brushTool release];
    [_pathArray release];
    
    [super dealloc];
}

- (void)setBrushing:(BOOL)brushing
{
    _brushing = brushing;
    self.userInteractionEnabled = _brushing;
}

- (void)undo
{
    if([self canUndo])
    {
        [self.pathArray removeLastObject];
        [self updataImage:YES];
        [self setNeedsDisplay];
    }
}

- (BOOL)canUndo
{
    return self.pathArray.count > 0;
}

//- (void)drawRect:(CGRect)rect
//{
//    //NSLog(@"%d",self.lineArray.count);
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    for(int i = 0;i < self.lineArray.count;i++)
//    {
//        
//        NSMutableDictionary *dic = [self.lineArray objectAtIndex:i];
//        NSMutableArray *pointArray = [dic objectForKey:_line_];
//        UIColor *color = [dic objectForKey:_lineColor_];
//        CGFloat lineWidth = [[dic objectForKey:_lineWidth_] floatValue];
//        
//        if([dic objectForKey:_eraser_])
//        {
//            CGContextSetBlendMode(context, kCGBlendModeClear);
//        }
//        else
//        {
//            CGContextSetBlendMode(context, kCGBlendModeNormal);
//        }
//        
//        CGContextSetStrokeColorWithColor(context,color.CGColor);
//        CGContextSetLineWidth(context,lineWidth);
//        CGContextSetLineCap(context, kCGLineCapRound);
//        CGContextSetLineJoin(context, kCGLineJoinRound);//设置线条拐角处圆滑
//        
//        
//        for(int j = 0;j < pointArray.count - 1;j ++)
//        {
//            NSValue *value = [pointArray objectAtIndex:j];
//            CGPoint point = [value CGPointValue];
//            NSValue *nextValue = [pointArray objectAtIndex:j + 1];
//            CGPoint nextPoint = [nextValue CGPointValue];
//            
//            CGContextMoveToPoint(context,point.x,point.y);
//            CGContextAddLineToPoint(context,nextPoint.x,nextPoint.y);
//        }
//        
//        CGContextStrokePath(context);
//    }
//    //[self.lineArray removeAllObjects];
//    CGContextSaveGState(context);
//    // CGContextRestoreGState(context);
//}

//- (void)panAction:(UIPanGestureRecognizer*) pan
//{
//    if(!self.selectedColor)
//        return;
//
//    if(pan.state == UIGestureRecognizerStateBegan)
//    {
//        // NSLog(@"--");
//        CGPoint point = [pan locationInView:self];
//        self.lastPoint = point;
//
//    }
//    else if(pan.state == UIGestureRecognizerStateChanged)
//    {
//       // NSLog(@"--");
//        CGPoint currentPoint = [pan locationInView:self];
//        [self draw:currentPoint];
//        self.lastPoint = currentPoint;
//    }
//}


#pragma mark-gesture代理
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
   // NSLog(@"%@",touch.view);
    if([touch.view isKindOfClass:[JBoDrawImageCell class]] || [touch.view isKindOfClass:[JBoDrawImageCellControl class]])
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

#pragma mark-重写touches

- (void)touchesBegan:(NSSet*)touches withEvent:(UIEvent*)event
{
//    if(!_selectedColor)
//        return;
    // NSLog(@"touche begin");
    UITouch *touch = [touches anyObject];
   // CGPoint point = [touch locationInView:self];
    
//    point.x = point.x / _imageScale_;
//    point.y = point.y / _imageScale_;
 //   self.lastPoint = point;
    
    self.brushTool = [[[JBoBrushPenTool alloc] init] autorelease];
    self.brushTool.lineWidth = self.lineWidth;
    self.brushTool.lineColor = self.selectedColor;
    self.brushTool.blendMode = self.blendMode;
    [self.pathArray addObject:self.brushTool];
    
    self.previousPoint1 = [touch previousLocationInView:self];
    self.currentPoint = [touch locationInView:self];
    
    [self.brushTool setInitialPoint:self.currentPoint];
}

- (void)touchesMoved:(NSSet*)touches withEvent:(UIEvent*)event
{
//    if(!_selectedColor)
//        return;
    UITouch *touch = [touches anyObject];
    
    self.previousPoint2 = self.previousPoint1;
    self.previousPoint1 = [touch previousLocationInView:self];
    self.currentPoint = [touch locationInView:self];
    
    if ([self.brushTool isKindOfClass:[JBoBrushPenTool class]]) {
        CGRect bounds = [(JBoBrushPenTool*)self.brushTool addPathPreviousPreviousPoint:self.previousPoint2 withPreviousPoint:self.previousPoint1 withCurrentPoint:self.currentPoint];
        
        CGRect drawBox = bounds;
        drawBox.origin.x -= self.lineWidth * 2.0;
        drawBox.origin.y -= self.lineWidth * 2.0;
        drawBox.size.width += self.lineWidth * 4.0;
        drawBox.size.height += self.lineWidth * 4.0;
        
        [self setNeedsDisplayInRect:drawBox];
    }
    else {
        [self.brushTool moveFromPoint:self.previousPoint1 toPoint:self.currentPoint];
        [self setNeedsDisplay];
    }
    
//    CGPoint currentPoint = [touch locationInView:self];
    
//    currentPoint.x = currentPoint.x / _imageScale_;
//    currentPoint.y = currentPoint.y / _imageScale_;
//    [self draw:currentPoint];
//    
//    _lastPoint = currentPoint;
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self touchesEnded:touches withEvent:event];
//    [self updataImage:NO];
//    self.brushTool = nil;
}

- (void)draw:(CGPoint) point
{
//    CGMutablePathRef subPath = CGPathCreateMutable();
//    CGPathMoveToPoint(subPath, NULL, _lastPoint.x, _lastPoint.y);
//    CGPathAddQuadCurveToPoint(subPath, NULL, _lastPoint.x, _lastPoint.y, point.x, point.y);
//    CGPathAddPath(path, NULL, subPath);
//    CGPathRelease(subPath);
//    [self setNeedsDisplay];
}

//- (void)draw
//{
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextAddPath(context, path);
//    CGContextSetLineCap(context, kCGLineCapRound);
//    CGContextSetLineWidth(context, self.lineWidth);
//    CGContextSetStrokeColorWithColor(context, self.selectedColor.CGColor);
//    CGContextSetBlendMode(context, self.blendMode);
//    CGContextStrokePath(context);
//}

- (void)drawRect:(CGRect)rect
{
    [self.image drawInRect:self.bounds];
    [self.brushTool draw];
}

- (void)updataImage:(BOOL) redraw
{
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0.0);
   // CGContextRef context = UIGraphicsGetCurrentContext();
    
    if(redraw)
    {
        self.image = nil;
        for(id<JBoBrushTool> tool in self.pathArray)
        {
            [tool draw];
        }
    }
    else
    {
        [self.image drawAtPoint:CGPointZero];
        [self.brushTool draw];
    }
    
    
    //NSLog(@"11");
//	[self.image drawInRect:CGRectMake(0, 0, _width_ / _imageScale_, _height_ / _imageScale_)];
//	CGContextSetLineCap(context, kCGLineCapRound);
//    // CGContextSetShouldAntialias(context, true);
//    
//    CGFloat scale = self.frame.size.width / _width_;
//    
//    CGFloat width = _lineWidth / scale / _imageScale_;
//    // NSLog(@"%f",width);
//    
//	CGContextSetLineWidth(context, width);
//    CGContextSetBlendMode(UIGraphicsGetCurrentContext(), _blendMode);
//	CGContextSetStrokeColorWithColor(context,_selectedColor.CGColor);
//	CGContextMoveToPoint(context, _lastPoint.x / scale, _lastPoint.y / scale);
//	CGContextAddLineToPoint(context, point.x / scale, point.y / scale);
//	CGContextStrokePath(context);
	self.image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
}

//
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
   // [self touchesMoved:touches withEvent:event];
    [self updataImage:NO];
    self.brushTool = nil;
    
//    UITouch *touch = [touches anyObject];
//    if(touch.tapCount == 2 || touch.tapCount == 1)
//    {
//        if([self.delegate respondsToSelector:@selector(brushViewDidSingleTap:)])
//        {
//            [self.delegate brushViewDidSingleTap:self];
//        }
//    }
//    else
//    {
        if([self.delegate respondsToSelector:@selector(brushViewDidDraw:)])
        {
            [self.delegate brushViewDidDraw:self];
        }
  //  }
}

//- (void)setSelectedColor:(UIColor *)selectedColor
//{
//    self.contentView.selectedColor = selectedColor;
//}
//
//- (void)setLineWidth:(CGFloat)lineWidth
//{
//    self.contentView.lineWidth = lineWidth;
//}
//
//- (void)setEraser:(BOOL)eraser
//{
//    self.contentView.eraser = eraser;
//}
//
//#pragma mark-JBoBrushContentView代理
//- (void)brushContentViewDidEndedBrush:(JBoBrushContentView *)content
//{
//    UIImage *snapshot = [self getSnapshot];
//    if(self.snapshotImageView.image != nil)
//    {
//        snapshot = [self mergeImage:snapshot otherImage:self.snapshotImageView.image size:self.contentView.frame.size];
//    }
//    self.snapshotImageView.image = snapshot;
//    [content.lineArray removeAllObjects];
//}
//
//- (UIImage*)getSnapshot
//{
//    UIGraphicsBeginImageContext(self.contentView.frame.size);
//    [[self.contentView layer] renderInContext:UIGraphicsGetCurrentContext()];
//    
//    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
//    
//    UIGraphicsEndImageContext();
//    return screenshot;
//}
//
//- (UIImage*)mergeImage:(UIImage*) image otherImage:(UIImage*) otherImage size:(CGSize) size;
//{
//    
//    CGRect rect1 = CGRectMake(0, 0, size.width, size.height);
//    CGRect rect2 = CGRectMake(0, 0, size.width, size.height);
//    
//    UIGraphicsBeginImageContext(size);
//    
//    [image drawInRect:rect1];
//    [otherImage drawInRect:rect2];
//    
//    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
//    
//    UIGraphicsEndImageContext();
//    
//    return resultingImage;
//}


@end
