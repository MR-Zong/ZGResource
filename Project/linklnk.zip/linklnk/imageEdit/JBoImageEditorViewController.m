//
//  JBoImageEditorViewController.m
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditorViewController.h"
#import "JBoAppDelegate.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoImageEditMenuItemView.h"
#import "JBoImageEditToolBase.h"
#import "JBoImageFilterTool.h"
#import "JBoImageBrushTool.h"
#import "JBoImageCropTool.h"
#import "JBoImageWatemarkTool.h"
#import "JBoImageTextInputTool.h"
#import "JBoImageToneCurveTool.h"
#import "JBoImageGraphTool.h"
#import "JBoUserOperation.h"
#import "JBoMutiImagePickerDelegate.h"

#define _itemStartTag_ 100

@interface JBoImageEditorViewController ()<UIScrollViewDelegate,JBoImageEditToolDelegate,UIActionSheetDelegate>

//导航条标题视图
@property(nonatomic,retain) UIView *titleView;
//撤销
@property(nonatomic,assign) UIButton *undoButton;
@property(nonatomic,retain) NSMutableArray *undoImageArray;

//恢复
@property(nonatomic,assign) UIButton *resumeButton;
@property(nonatomic,retain) NSMutableArray *resumeImageArray;

//当前编辑工具
@property(nonatomic,retain) JBoImageEditToolBase *currentTool;
@property(nonatomic,assign) UIImageOrientation nextOrientation;

@end

@implementation JBoImageEditorViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        
    }
    return self;
}

- (id)initWithImage:(UIImage *)image type:(JBoImageEditorOperationType)type
{
    self = [super init];
    if(self)
    {
        self.title = @"编辑";
        self.onlyCropImage = NO;
        self.undoImageArray = [NSMutableArray array];
        self.resumeImageArray = [NSMutableArray array];
        
        self.type = type;
        self.editImage = image;
        self.nextOrientation = UIImageOrientationRight;
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    _delegate = nil;
    [_editImageView release];
    [_editImage release];
    
    [_scrollView release];
    [_menuScrollView release];
    
    [_titleView release];
    [_undoImageArray release];
    [_resumeImageArray release];
    
    _currentTool.delegate = nil;
    [_currentTool release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES];
    [self.appDelegate hiddenStatusBar:YES];
    [self.navigationController setNavigationBarHidden:NO];
    [self setNavigationTranslute:YES];

    [JBoNavigatioinBarOperation setNavigationBar:self.navigationController.navigationBar backgroundImage:nil titleTextAttribute:nil barColor:[UIColor blackColor]];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.appDelegate hiddenStatusBar:NO];
    [self.navigationController setNavigationBarHidden:YES];
    [self.navigationController setNavigationBarHidden:NO];
    [self setNavigationTranslute:NO];
    [JBoNavigatioinBarOperation setWhiteNavigationBar:self.navigationController.navigationBar];
}

- (void)setNavigationTranslute:(BOOL) translute
{
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
      //  self.navigationController.navigationBar.translucent = translute;
    }
#endif
    
}

#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0 :
            [self userDirectly];
            break;
        case 1 :
            [self finish];
            break;
        default:
            break;
    }
}


#pragma mark- 加载视图

- (void)back
{
//    for(UIViewController *VC in self.navigationController.viewControllers)
//    {
//        if([VC isKindOfClass:[JBoMutilImagePickerViewController class]])
//        {
//            [self.navigationController popToViewController:VC animated:YES];
//        }
//    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)finish
{
    self.appDelegate.dataLoadingView.hidden = NO;
    self.navigationItem.rightBarButtonItem.enabled = NO;
    
    UIImage *image = [self.editImageView.image deepCopy];
    UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishedSaveWithError:contextInfo:), nil);
}

- (void)useImmediately
{
    switch (self.type)
    {
        case JBoImageEditorOperationTypeUse :
        {
            [self userDirectly];
        }
            break;
        case JBoImageEditorOperationTypeSaveAndUse :
        {
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"直接使用", @"保存并使用", nil];
            [actionSheet showInView:self.view];
            [actionSheet release];
        }
            break;
        default:
            break;
    }
}

//直接使用
- (void)userDirectly
{
    if([self.delegate respondsToSelector:@selector(imagePicker:imageDidSelected:)])
    {
        self.navigationItem.rightBarButtonItem.enabled = NO;
        self.navigationItem.leftBarButtonItem.enabled = NO;
        [self.delegate imagePicker:self imageDidSelected:self.editImageView.image];
    }
}

- (void)image:(UIImage*) image didFinishedSaveWithError:(NSError*) error contextInfo:(void*) contextInfo
{
    self.navigationItem.rightBarButtonItem.enabled = YES;
    self.appDelegate.dataLoadingView.hidden = YES;
    
    if(!error)
    {
        [JBoUserOperation alertMsg:@"已保存到相册"];
        if(self.type == JBoImageEditorOperationTypeSaveAndUse)
        {
            [self userDirectly];
        }
    }
    else
    {
        [JBoUserOperation alertMsg:@"保存到相册失败"];
    }
}

- (void)generalBarButtonItem
{
    [JBoNavigatioinBarOperation setBackItemWithTarget:self action:@selector(back)];
    switch (self.type)
    {
        case JBoImageEditorOperationTypeSave :
             [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(finish) title:@"保存" backgroundImage:nil textColor:[UIColor whiteColor]];
            break;
        case JBoImageEditorOperationTypeUse :
        case JBoImageEditorOperationTypeSaveAndUse :
             [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(useImmediately) title:@"使用" backgroundImage:nil textColor:[UIColor whiteColor]];
            break;
        default:
             [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(finish) title:@"保存" backgroundImage:nil textColor:[UIColor whiteColor]];
            break;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.memuOringinalY = _height_ - _navgateBarHeight_ - _menuHeight_;
    
#ifdef __IPHONE_7_0
    if(_ios7_0_)
    {
        self.automaticallyAdjustsScrollViewInsets = NO;
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
#else
    if(!_ios7_0_)
    {
       // self.wantsFullScreenLayout = YES;
    }
#endif
	
    self.view.backgroundColor = [UIColor blackColor];
    
    
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _navgateBarHeight_ - _menuHeight_ - 1.0)];
    _scrollView.minimumZoomScale = 1.0;
    _scrollView.maximumZoomScale = 5.0;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.backgroundColor = [UIColor clearColor];
    _scrollView.delegate = self;
    [self.view addSubview:_scrollView];

  //  NSLog(@"%f,%f",self.editImage.size.width, self.editImage.size.height);
    
    _editImageView = [[UIImageView alloc] initWithImage:self.editImage];
    _editImageView.userInteractionEnabled = YES;
    _editImageView.backgroundColor = [UIColor clearColor];
    [self.scrollView addSubview:_editImageView];
    [self resetImageFrame];
    
    if(!self.onlyCropImage)
    {
        [self generalBarButtonItem];
        [self createTitleView];
        [self createEditMenu];
    }
}

- (void)resetImageFrame
{
    CGSize size = [self.editImageView.image shrinkWithContraintSize:self.scrollView.frame.size];

    self.editImageView.frame = CGRectMake((self.scrollView.frame.size.width - size.width) / 2, (self.scrollView.frame.size.height - size.height) / 2, size.width, size.height);
    self.scale = self.editImageView.image.size.width / size.width;
}

#pragma mark- 撤销和恢复

- (void)createTitleView
{
    if(!self.titleView)
    {
        CGFloat buttonWidth = 30.0;
        CGFloat buttonInterval = 50.0;
        CGFloat buttonHeight = 30.0;
        
        UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, buttonWidth * 2 + buttonInterval, buttonHeight)];
        titleView.backgroundColor = [UIColor clearColor];
        
        //撤销
        UIButton *undoButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [undoButton setFrame:CGRectMake(0, 0, buttonWidth, buttonHeight)];
        [undoButton setImage:[UIImage imageNamed:@"imageEditor_undo"] forState:UIControlStateNormal];
        [undoButton setImage:[UIImage imageNamed:@"imageEditor_undo_disable"] forState:UIControlStateDisabled];
        [undoButton addTarget:self action:@selector(undo:) forControlEvents:UIControlEventTouchUpInside];
        [undoButton setShowsTouchWhenHighlighted:YES];
        self.undoButton = undoButton;
        [titleView addSubview:undoButton];
        
        //恢复
        UIButton *resumeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [resumeButton setFrame:CGRectMake(buttonWidth + buttonInterval, 0, buttonWidth, buttonHeight)];
        [resumeButton setImage:[UIImage imageNamed:@"imageEditor_resume"] forState:UIControlStateNormal];
        [resumeButton setImage:[UIImage imageNamed:@"imageEditor_resume_disable"] forState:UIControlStateDisabled];
        [resumeButton addTarget:self action:@selector(resume:) forControlEvents:UIControlEventTouchUpInside];
        [resumeButton setShowsTouchWhenHighlighted:YES];
        self.resumeButton = resumeButton;
        [titleView addSubview:resumeButton];
        
        self.titleView = titleView;
        [titleView release];
    }
    
    self.navigationItem.titleView = self.titleView;
    [self canUndo];
    [self canResume];
}

- (void)canUndo
{
    self.undoButton.enabled = self.undoImageArray.count > 0;
}

- (void)canResume
{
    self.resumeButton.enabled = self.resumeImageArray.count > 0;
}

- (void)undo:(UIButton*) button
{
    UIImage *image = [self.undoImageArray lastObject];
    [self.resumeImageArray addObject:self.editImageView.image];
    self.editImageView.image = image;
    [self.undoImageArray removeLastObject];
    [self canUndo];
    [self canResume];
    [self resetImageFrame];
}

- (void)resume:(UIButton*) button
{
    UIImage *image = [self.resumeImageArray lastObject];
    [self.undoImageArray addObject:self.editImageView.image];
    self.editImageView.image = image;
    [self.resumeImageArray removeLastObject];
    [self canResume];
    [self canUndo];
    [self resetImageFrame];
}

#pragma mark- 编辑菜单

- (void)createEditMenu
{
    if(!self.menuScrollView)
    {
        _menuScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _height_ - _navgateBarHeight_ - _menuHeight_, _width_, _menuHeight_)];
        _menuScrollView.backgroundColor = [UIColor colorWithWhite:0 alpha:1.0];
        _menuScrollView.showsHorizontalScrollIndicator = NO;
        _menuScrollView.showsVerticalScrollIndicator = NO;
        [self.view addSubview:_menuScrollView];
        self.memuOringinalY = _menuScrollView.frame.origin.y;
        
        NSArray *icons = [JBoImageEditToolBase imageEditToolIcons];
        NSArray *titles = [JBoImageEditToolBase imageEditToolTitles];
        
        CGFloat height = 60.0;
        CGFloat width = _width_ / titles.count;
        CGFloat iconSize = 30.0;
        CGFloat padding = (width - iconSize) / 2.0;
        
        for(NSInteger i = 0;i < icons.count;i ++)
        {
            JBoImageEditMenuItemView *item = [[JBoImageEditMenuItemView alloc] initWithFrame:CGRectMake(width * i, _menuHeight_ - height, width, height) icon:[UIImage imageNamed:[icons objectAtIndex:i]] title:[titles objectAtIndex:i]];
            item.iconImageView.layer.borderWidth = 0.0;
            item.iconImageView.frame = CGRectMake(padding, padding, iconSize, iconSize);
            item.titleLabel.frame = CGRectMake(0, padding + iconSize, width, height - iconSize - padding);
            item.titleLabel.textColor = [UIColor whiteColor];
            item.tag = _itemStartTag_ + i;
            
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(menuItemDidSelected:)];
            [item addGestureRecognizer:tap];
            [tap release];
            
            [self.menuScrollView addSubview:item];
            [item release];
        }
        self.menuScrollView.contentSize = CGSizeMake(width * icons.count, self.menuScrollView.bounds.size.height);
    }
}

- (void)menuItemDidSelected:(UITapGestureRecognizer*) tap
{
    if(self.currentTool)
        return;
    
    NSInteger index = tap.view.tag - _itemStartTag_;
    
    switch (index) {
        case 0 :
        {
            JBoImageToneCurveTool *toneCurveTool = [[JBoImageToneCurveTool alloc] initWithImageEditor:self];
            toneCurveTool.delegate = self;
            [toneCurveTool beginEdit];
            self.currentTool = toneCurveTool;
            [toneCurveTool release];
        }
            break;
        case 1 :
        {
            JBoImageFilterTool *filterTool = [[JBoImageFilterTool alloc] initWithImageEditor:self];
            filterTool.delegate = self;
            [filterTool beginEdit];
            self.currentTool = filterTool;
            [filterTool release];
        }
            break;
        case 2 :
        {
            UIImage *image = [UIImage imageWithCGImage:self.editImageView.image.CGImage scale:1.0 orientation:self.nextOrientation];
            self.editImageView.image = image;
            
            if(self.nextOrientation == UIImageOrientationRight)
            {
                self.nextOrientation = UIImageOrientationDown;
            }
            else if(self.nextOrientation == UIImageOrientationDown)
            {
                self.nextOrientation = UIImageOrientationLeft;
            }
            else if(self.nextOrientation == UIImageOrientationLeft)
            {
                self.nextOrientation = UIImageOrientationUp;
            }
            else
            {
                self.nextOrientation = UIImageOrientationRight;
            }
            [self resetImageFrame];
        }
            break;
        case 3 :
        {
            JBoImageCropTool *cropTool = [[JBoImageCropTool alloc] initWithImageEditor:self];
            cropTool.delegate = self;
            [cropTool beginEdit];
            self.currentTool = cropTool;
            [cropTool release];
        }
            break;
        case 4 :
        {
            JBoImageBrushTool *brushTool = [[JBoImageBrushTool alloc] initWithImageEditor:self];
            brushTool.delegate = self;
            [brushTool beginEdit];
            self.currentTool = brushTool;
            [brushTool release];
        }
            break;
        case 5 :
        {
            JBoImageWatemarkTool *watermarkTool = [[JBoImageWatemarkTool alloc] initWithImageEditor:self];
            watermarkTool.delegate = self;
            [watermarkTool beginEdit];
            self.currentTool = watermarkTool;
            [watermarkTool release];
        }
            break;
        case 6 :
        {
            JBoImageTextInputTool *textInputTool = [[JBoImageTextInputTool alloc] initWithImageEditor:self];
            textInputTool.delegate = self;
            [textInputTool beginEdit];
            self.currentTool = textInputTool;
            [textInputTool release];
        }
            break;
        case 7 :
        {
            JBoImageGraphTool *graphTool = [[JBoImageGraphTool alloc] initWithImageEditor:self];
            graphTool.delegate = self;
            [graphTool beginEdit];
            self.currentTool = graphTool;
            [graphTool release];
        }
            break;
        default:
            break;
    }
    
    if(index != 2)
    {
        self.navigationItem.titleView = nil;
        self.navigationItem.title = [[JBoImageEditToolBase imageEditToolTitles] objectAtIndex:index];
        [self editBarButtonItem];
        [self beginEdit];
    }
}

#pragma mark- JBoImageEditorTool 

- (void)imageEditTool:(JBoImageEditToolBase*)tool editType:(JBoImageEditType)type didFinishEditWithImage:(UIImage *)image
{
    self.navigationItem.leftBarButtonItem.enabled = YES;
    self.editImageView.image = image;
    [self.undoImageArray addObject:tool.originalImage];
    [self canUndo];
    [self canResume];
    self.appDelegate.dataLoadingView.hidden = YES;
    [self.currentTool close];
    [self generalBarButtonItem];
    [self endEdit];
    [self resetImageFrame];
}

- (void)editBarButtonItem
{
    [JBoNavigatioinBarOperation setLeftItemWithTarget:self action:@selector(editCancel) title:@"取消" backgroundImage:nil textColor:[UIColor whiteColor]];
    [JBoNavigatioinBarOperation setRightItemWithTarget:self action:@selector(editFinish) title:@"完成" backgroundImage:nil textColor:[UIColor whiteColor]];
}

- (void)editCancel
{
    self.editImageView.image = self.currentTool.originalImage;
    [self.currentTool close];
    [self generalBarButtonItem];
    [self endEdit];
}

- (void)editFinish
{
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.appDelegate.dataLoadingView.hidden = NO;
    [self.currentTool endEdit];
}

- (void)beginEdit
{
    [UIView animateWithDuration:0.25 animations:^(void){
       
        self.menuScrollView.frame = CGRectMake(self.menuScrollView.frame.origin.x, _height_, self.menuScrollView.frame.size.width, self.menuScrollView.frame.size.height);
    }];
}

- (void)endEdit
{
    self.currentTool = nil;
    self.navigationItem.titleView = self.titleView;
    [UIView animateWithDuration:0.25 animations:^(void){
       self.menuScrollView.frame = CGRectMake(self.menuScrollView.frame.origin.x, self.memuOringinalY, self.menuScrollView.frame.size.width, self.menuScrollView.frame.size.height);
    }];
}

#pragma mark- scrollView代理

- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _editImageView;
}

- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    [self resizeWhenZoom];
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale
{
    [self resizeWhenZoom];
}

- (void)resizeWhenZoom
{
    CGFloat x = self.scrollView.bounds.size.width * 0.5;
    CGFloat ox = _editImageView.frame.size.width * 0.5;
    CGFloat y = self.scrollView.bounds.size.height * 0.5;
    CGFloat oy = _editImageView.frame.size.height * 0.5;
    
    x = ox > x ? ox : x;
    y = oy > y ? oy : y;
    
    _editImageView.center = CGPointMake(x, y);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
