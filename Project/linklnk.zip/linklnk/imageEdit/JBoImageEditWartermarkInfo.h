//
//  JBoImageEditCellInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-10.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**图片编辑的水印图片信息
 */
@interface JBoImageEditWartermarkInfo : NSObject

/**原图
 */
@property(nonatomic,retain) UIImage *image;

/**缩略图
 */
@property(nonatomic,retain) UIImage *thumbnail;

@end
