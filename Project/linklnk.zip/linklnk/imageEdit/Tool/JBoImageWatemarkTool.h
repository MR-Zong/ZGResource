//
//  JBoImageWatemarkTool.h
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditToolBase.h"

/**图片拼图编辑工具
 */
@interface JBoImageWatemarkTool : JBoImageEditToolBase<UIActionSheetDelegate>

@end
