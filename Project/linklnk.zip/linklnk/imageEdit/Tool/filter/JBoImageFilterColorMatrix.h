//
//  JBoImageFilterColorMatrix.h
//  linklnk
//
//  Created by kinghe005 on 15-3-19.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**颜色矩阵滤镜
 */
@interface JBoImageFilterColorMatrix : NSObject

/**滤镜名称
 *@retrun 数组元素是 NSString
 */
+ (NSArray*)filterNames;

/**通过滤镜名称下标获取颜色矩阵
 *@param index 滤镜名称下标
 *@return 颜色矩阵
 */
+ (const float*) colorMartrixForIndex:(NSInteger) index;

/**通过颜色矩阵获取滤镜图片
 *@param inImage 原图
 *@param colorMatrix 颜色矩阵
 *@return 结果图片
 */
+ (UIImage*)imageWithImage:(UIImage*)inImage withColorMatrix:(const float*) colorMatrix;

@end
