//
//  JBoImageFilterColorMatrix.m
//  linklnk
//
//  Created by kinghe005 on 15-3-19.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoImageFilterColorMatrix.h"

#pragma mark- 颜色矩阵

//LOMO
const float colormatrix_lomo[] = {
    1.7f,  0.1f, 0.1f, 0, -73.1f,
    0,  1.7f, 0.1f, 0, -73.1f,
    0,  0.1f, 1.6f, 0, -73.1f,
    0,  0, 0, 1.0f, 0 };

//黑白
const float colormatrix_heibai[] = {
    0.8f,  1.6f, 0.2f, 0, -163.9f,
    0.8f,  1.6f, 0.2f, 0, -163.9f,
    0.8f,  1.6f, 0.2f, 0, -163.9f,
    0,  0, 0, 1.0f, 0 };
//复古
const float colormatrix_huajiu[] = {
    0.2f,0.5f, 0.1f, 0, 40.8f,
    0.2f, 0.5f, 0.1f, 0, 40.8f,
    0.2f,0.5f, 0.1f, 0, 40.8f,
    0, 0, 0, 1, 0 };

//哥特
const float colormatrix_gete[] = {
    1.9f,-0.3f, -0.2f, 0,-87.0f,
    -0.2f, 1.7f, -0.1f, 0, -87.0f,
    -0.1f,-0.6f, 2.0f, 0, -87.0f,
    0, 0, 0, 1.0f, 0 };

//锐化
const float colormatrix_ruise[] = {
    4.8f,-1.0f, -0.1f, 0,-388.4f,
    -0.5f,4.4f, -0.1f, 0,-388.4f,
    -0.5f,-1.0f, 5.2f, 0,-388.4f,
    0, 0, 0, 1.0f, 0 };


//淡雅
const float colormatrix_danya[] = {
    0.6f,0.3f, 0.1f, 0,73.3f,
    0.2f,0.7f, 0.1f, 0,73.3f,
    0.2f,0.3f, 0.4f, 0,73.3f,
    0, 0, 0, 1.0f, 0 };

//酒红
const float colormatrix_jiuhong[] = {
    1.2f,0.0f, 0.0f, 0.0f,0.0f,
    0.0f,0.9f, 0.0f, 0.0f,0.0f,
    0.0f,0.0f, 0.8f, 0.0f,0.0f,
    0, 0, 0, 1.0f, 0 };

//清宁
const float colormatrix_qingning[] = {
    0.9f, 0, 0, 0, 0,
    0, 1.1f,0, 0, 0,
    0, 0, 0.9f, 0, 0,
    0, 0, 0, 1.0f, 0 };

//浪漫
const float colormatrix_langman[] = {
    0.9f, 0, 0, 0, 63.0f,
    0, 0.9f,0, 0, 63.0f,
    0, 0, 0.9f, 0, 63.0f,
    0, 0, 0, 1.0f, 0 };

//光晕
const float colormatrix_guangyun[] = {
    0.9f, 0, 0,  0, 64.9f,
    0, 0.9f,0,  0, 64.9f,
    0, 0, 0.9f,  0, 64.9f,
    0, 0, 0, 1.0f, 0 };

//蓝调
const float colormatrix_landiao[] = {
    2.1f, -1.4f, 0.6f, 0.0f, -31.0f,
    -0.3f, 2.0f, -0.3f, 0.0f, -31.0f,
    -1.1f, -0.2f, 2.6f, 0.0f, -31.0f,
    0.0f, 0.0f, 0.0f, 1.0f, 0.0f
};

//梦幻
const float colormatrix_menghuan[] = {
    0.8f, 0.3f, 0.1f, 0.0f, 46.5f,
    0.1f, 0.9f, 0.0f, 0.0f, 46.5f,
    0.1f, 0.3f, 0.7f, 0.0f, 46.5f,
    0.0f, 0.0f, 0.0f, 1.0f, 0.0f
};

//夜色
const float colormatrix_yese[] = {
    1.0f, 0.0f, 0.0f, 0.0f, -66.6f,
    0.0f, 1.1f, 0.0f, 0.0f, -66.6f,
    0.0f, 0.0f, 1.0f, 0.0f, -66.6f,
    0.0f, 0.0f, 0.0f, 1.0f, 0.0f
};

@implementation JBoImageFilterColorMatrix

/**滤镜名称
 *@retrun 数组元素是 NSString
 */
+ (NSArray*)filterNames
{
    return [NSArray arrayWithObjects:@"原图",@"LOMO",@"黑白",@"复古",@"哥特",@"锐色",@"淡雅",@"酒红",@"青柠",@"浪漫",@"光晕",@"蓝调",@"梦幻",@"夜色", nil];
}

/**通过滤镜名称下标获取颜色矩阵
 *@param index 滤镜名称下标
 *@return 颜色矩阵
 */
+ (const float*) colorMartrixForIndex:(NSInteger) index
{
    switch (index)
    {
        case 1 :
            return colormatrix_lomo;
            break;
        case 2 :
            return colormatrix_heibai;
            break;
        case 3 :
            return colormatrix_huajiu;
            break;
        case 4 :
            return colormatrix_gete;
            break;
        case 5 :
            return colormatrix_ruise;
            break;
        case 6 :
            return colormatrix_danya;
            break;
        case 7 :
            return colormatrix_jiuhong;
            break;
        case 8 :
            return colormatrix_qingning;
            break;
        case 9 :
            return colormatrix_langman;
            break;
        case 10 :
            return colormatrix_guangyun;
            break;
        case 11 :
            return colormatrix_landiao;
            break;
        case 12 :
            return colormatrix_menghuan;
            break;
        case 13 :
            return colormatrix_yese;
            break;
        default:
            return NULL;
            break;
    }
}

//修改RGB的值
static void changeRGBA(int *red,int *green,int *blue,int *alpha, const float* f)
{
    int redV = *red;
    int greenV = *green;
    int blueV = *blue;
    int alphaV = *alpha;
    
    *red = f[0] * redV + f[1] * greenV + f[2] * blueV + f[3] * alphaV + f[4];
    *green = f[0 + 5] * redV + f[1 + 5] * greenV + f[2 + 5] * blueV + f[3 + 5] * alphaV + f[4 + 5];
    *blue = f[0 + 5 * 2] * redV + f[1 + 5 * 2] * greenV + f[2 + 5 * 2] * blueV + f[3 + 5 * 2] * alphaV + f[4 + 5 * 2];
    *alpha = f[0 + 5 * 3] * redV + f[1 + 5 * 3] * greenV + f[2 + 5 * 3] * blueV + f[3 + 5 * 3] * alphaV + f[4 + 5 * 3];
    
    if (*red > 255)
    {
        *red = 255;
    }
    if(*red < 0)
    {
        *red = 0;
    }
    if(*green > 255)
    {
        *green = 255;
    }
    if(*green < 0)
    {
        *green = 0;
    }
    if(*blue > 255)
    {
        *blue = 255;
    }
    if(*blue < 0)
    {
        *blue = 0;
    }
    if(*alpha > 255)
    {
        *alpha = 255;
    }
    if(*alpha < 0)
    {
        *alpha = 0;
    }
}

/**通过颜色矩阵获取滤镜图片
 *@param inImage 原图
 *@param colorMatrix 颜色矩阵
 *@return 结果图片
 */
+ (UIImage*)imageWithImage:(UIImage*)inImage withColorMatrix:(const float*) colorMatrix
{
    if(colorMatrix == NULL)
        return inImage;
    
    //获取图片RGB数据
    CGContextRef context = NULL;
    CGColorSpaceRef colorSpace;
    
    unsigned char *imgPixel;
    size_t bitmapSize;
    size_t bytesPerRow;
    
    CGImageRef image = inImage.CGImage;
    
    size_t width = CGImageGetWidth(image);
    size_t height = CGImageGetHeight(image);
    
    bytesPerRow   = (width * 4);
    bitmapSize     = (bytesPerRow * height);
    
    imgPixel = malloc( bitmapSize );
    if (imgPixel == NULL)
    {
        return inImage;
    }
    
    colorSpace = CGColorSpaceCreateDeviceRGB();
    if (colorSpace == NULL)
    {
        free(imgPixel);
        return inImage;
    }
    
    CGBitmapInfo kBGRxBitmapInfo = kCGBitmapByteOrderDefault | kCGImageAlphaPremultipliedLast;
    context = CGBitmapContextCreate (imgPixel,
                                     width,
                                     height,
                                     8,
                                     bytesPerRow,
                                     colorSpace,
                                     kBGRxBitmapInfo);
    
    CGColorSpaceRelease( colorSpace );
    
    if (context == NULL)
    {
        free (imgPixel);
        return inImage;
    }
    
    CGContextDrawImage(context, CGRectMake(0, 0, width, height), image);
    CGContextRelease(context);
    
    if(imgPixel == NULL)
        return inImage;
    
    int wOff = 0;
    int pixOff = 0;
    
    for(size_t y = 0;y < height;y ++)//双层循环按照长宽的像素个数迭代每个像素点
    {
        pixOff = wOff;
        
        for (size_t x = 0; x < width; x ++)
        {
            int red = (unsigned char)imgPixel[pixOff];
            int green = (unsigned char)imgPixel[pixOff+1];
            int blue = (unsigned char)imgPixel[pixOff+2];
            int alpha = (unsigned char)imgPixel[pixOff+3];
            changeRGBA(&red, &green, &blue, &alpha, colorMatrix);
            
            //回写数据
            imgPixel[pixOff] = red;
            imgPixel[pixOff + 1] = green;
            imgPixel[pixOff + 2] = blue;
            imgPixel[pixOff + 3] = alpha;
            
            
            pixOff += 4; //将数组的索引指向下四个元素
        }
        
        wOff += width * 4;
    }
    
    NSInteger dataLength = width * height * 4;
    
    //下面的代码创建要输出的图像的相关参数
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, imgPixel, dataLength, dataProviderReleaseData);
    
    size_t bitsPerComponent = 8;
    size_t bitsPerPixel = 32;
    bytesPerRow = 4 * width;
    CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
    CGBitmapInfo bitmapInfo = kCGBitmapByteOrderDefault;
    CGColorRenderingIntent renderingIntent = kCGRenderingIntentDefault;
    
    
    CGImageRef imageRef = CGImageCreate(width, height, bitsPerComponent, bitsPerPixel, bytesPerRow,colorSpaceRef, bitmapInfo, provider, NULL, NO, renderingIntent);//创建要输出的图像
    
    UIImage *myImage = [UIImage imageWithCGImage:imageRef];
    
    CFRelease(imageRef);
    CGColorSpaceRelease(colorSpaceRef);
    CGDataProviderRelease(provider);
    
    
    return myImage;
}

/**CGDataProviderRef 内存释放回调 data必须在此地释放，否则会出现图片像素出错
 */
void dataProviderReleaseData(void *info, const void *data,
                             size_t size)
{
    free((void*)data);
}

@end
