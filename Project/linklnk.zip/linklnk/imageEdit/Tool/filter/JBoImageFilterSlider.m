//
//  JBoImageFilterSlider.m
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterSlider.h"
#import <QuartzCore/QuartzCore.h>

@implementation JBoImageFilterSlider

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.userInteractionEnabled = YES;
        self.layer.cornerRadius = 5.0;
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
        self.layer.masksToBounds = YES;
        
        _slider = [[UISlider alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        [self addSubview:_slider];
        
    }
    return self;
}

- (void)dealloc
{
    [_slider release];
    [super dealloc];
}

- (void)setDirection:(JBoImageFilterSliderDirection)direction
{
    _direction = direction;
    switch (_direction)
    {
        case JBoImageFilterSliderDirectionNormal :
        {
            
        }
            break;
        case JBoImageFilterSliderDirectionVertical :
        {
            self.transform = CGAffineTransformMakeRotation(-M_PI_2);
        }
            break;
        default:
            break;
    }
}

- (void)addTarget:(id)target action:(SEL)action forControlEvents:(UIControlEvents)controlEvents
{
    [_slider addTarget:target action:action forControlEvents:controlEvents];
}

@end
