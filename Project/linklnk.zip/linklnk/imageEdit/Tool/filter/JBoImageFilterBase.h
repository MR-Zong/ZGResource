//
//  JBoImageFilterBase.h
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoImageFilterSlider.h"
#import "UIView+Utilities.h"
#import "JBoImageEditorViewController.h"

@interface JBoImageFilterBase : NSObject

@property(nonatomic,assign) UIView *superView;
@property(nonatomic,assign) UIImageView *imageView;
@property(nonatomic,retain) UIImage *originalImage;
@property(nonatomic,retain) UIImage *rootThumbnail;

@property(nonatomic,retain) CIContext *context;
@property(nonatomic,retain) CIFilter *filter;

- (id)initWithSuperView:(UIView*) superView imageView:(UIImageView*) imageView orignalImage:(UIImage*) originalImage rootThumbnail:(UIImage*) thumbnail;

- (UIImage*)getFilterImageFromImage:(UIImage*) image;

- (void)close;

- (void)valueDidChange;

@end
