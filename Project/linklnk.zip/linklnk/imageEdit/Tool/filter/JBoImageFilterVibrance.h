//
//  JBoImageFilterVibrance.h
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterBase.h"

@interface JBoImageFilterVibrance : JBoImageFilterBase

@end
