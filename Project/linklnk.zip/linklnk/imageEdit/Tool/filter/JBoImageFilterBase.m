//
//  JBoImageFilterBase.m
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterBase.h"

@implementation JBoImageFilterBase

- (id)initWithSuperView:(UIView *)superView imageView:(UIImageView *)imageView orignalImage:(UIImage *)originalImage rootThumbnail:(UIImage *)thumbnail
{
    self = [super init];
    if(self)
    {
        self.superView = superView;
        self.imageView = imageView;
        self.originalImage = originalImage;
        self.rootThumbnail = thumbnail;
        
        self.context = [CIContext contextWithOptions:nil];
    }
    
    return self;
}

- (void)dealloc
{
    [_originalImage release];
    [_rootThumbnail release];
    
    [super dealloc];
}

- (UIImage*)getFilterImageFromImage:(UIImage *)image
{
    return image;
}

- (void)close
{
    self.superView = nil;
    self.imageView = nil;
}

- (void)valueDidChange
{
    static BOOL progress = NO;
    if(progress)
        return;
    progress = YES;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        UIImage *image = [self getFilterImageFromImage:self.rootThumbnail];
        dispatch_async(dispatch_get_main_queue(), ^(void){
            self.imageView.image = image;
            progress = NO;
        });
    });
}

@end
