//
//  JBoImageFilterVibrance.m
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterVibrance.h"

static NSString *const inputAmountKey = @"inputAmount";

@interface JBoImageFilterVibrance ()

@property(nonatomic,retain) JBoImageFilterSlider *vibranceSlider;

@end

@implementation JBoImageFilterVibrance

#pragma mark- 内存管理

- (void)dealloc
{
    [_vibranceSlider release];
    [super dealloc];
}

#pragma mark- super method

- (id)initWithSuperView:(UIView *)superView imageView:(UIImageView *)imageView orignalImage:(UIImage *)originalImage rootThumbnail:(UIImage *)thumbnail
{
    self = [super initWithSuperView:superView imageView:imageView orignalImage:originalImage rootThumbnail:thumbnail];
    if(self)
    {
        self.filter = [CIFilter filterWithName:@"CIVibrance"];
        
        //亮度
        NSDictionary *inputHighlightDic = [self.filter.attributes objectForKey:inputAmountKey];
        CGFloat min = [[inputHighlightDic objectForKey:kCIAttributeSliderMin] floatValue];
        CGFloat max = [[inputHighlightDic objectForKey:kCIAttributeSliderMax] floatValue];
        
        
        JBoImageFilterSlider *vibranceSlider = [[JBoImageFilterSlider alloc] initWithFrame:CGRectMake((superView.width - _imageFilterSliderDefaultWidth_) / 2, (superView.height - _imageFilterSliderDefaultHeight_ - _imageFilterSliderDefaultPadding_ - _menuHeight_), _imageFilterSliderDefaultWidth_, _imageFilterSliderDefaultHeight_)];
        [vibranceSlider addTarget:self action:@selector(vibranceAdjust:) forControlEvents:UIControlEventValueChanged];
        vibranceSlider.slider.minimumValue = min;
        vibranceSlider.slider.maximumValue = max;
        vibranceSlider.slider.value = min;//(min + max) / 2.0;
        [superView addSubview:vibranceSlider];
        self.vibranceSlider = vibranceSlider;
        [vibranceSlider release];
        
        
        [self valueDidChange];
    }
    return self;
}

- (void)close
{
    [self.vibranceSlider removeFromSuperview];
    [super close];
}

- (UIImage*)getFilterImageFromImage:(UIImage *)image
{
    CIImage *inputImage = [CIImage imageWithCGImage:image.CGImage];
    
    self.filter = [CIFilter filterWithName:@"CIVibrance"];
    [self.filter setValue:inputImage forKey:kCIInputImageKey];
    [self.filter setValue:[NSNumber numberWithFloat:self.vibranceSlider.slider.value] forKey:inputAmountKey];
    
    CIImage *outputImage = [self.filter outputImage];
    
    CGRect cropRect = [outputImage extent];
    if(cropRect.size.width >= NSNotFound || cropRect.size.height >= NSNotFound)
    {
        cropRect = CGRectMake(0, 0, image.size.width, image.size.height);
    }
    
    CGImageRef imageRef = [self.context createCGImage:outputImage fromRect:cropRect];
    
    UIImage *retImage = [UIImage imageWithCGImage:imageRef];
    
    CGImageRelease(imageRef);
    
    return retImage;
}

#pragma mark- private method

- (void)vibranceAdjust:(UISlider*) slider
{
    [self valueDidChange];
}

@end
