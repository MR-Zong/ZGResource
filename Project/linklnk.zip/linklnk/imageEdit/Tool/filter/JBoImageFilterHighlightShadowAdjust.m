//
//  JBoImageFilterHighlightShadowAdjust.m
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterHighlightShadowAdjust.h"

static NSString *const inputHighlightKey = @"inputHighlightAmount";
static NSString *const inputShadowKey = @"inputShadowAmount";

@interface JBoImageFilterHighlightShadowAdjust ()

@property(nonatomic,retain) JBoImageFilterSlider *highlightSlider;
@property(nonatomic,retain) JBoImageFilterSlider *shadowSlider;

@end

@implementation JBoImageFilterHighlightShadowAdjust

#pragma mark- 内存管理

- (void)dealloc
{
    [_highlightSlider release];
    [_shadowSlider release];
    
    [super dealloc];
}

#pragma mark- super method

- (id)initWithSuperView:(UIView *)superView imageView:(UIImageView *)imageView orignalImage:(UIImage *)originalImage rootThumbnail:(UIImage *)thumbnail
{
    self = [super initWithSuperView:superView imageView:imageView orignalImage:originalImage rootThumbnail:thumbnail];
    if(self)
    {
            self.filter = [CIFilter filterWithName:@"CIHighlightShadowAdjust"];
            
            //亮度
            NSDictionary *inputHighlightDic = [self.filter.attributes objectForKey:inputHighlightKey];
            CGFloat min = [[inputHighlightDic objectForKey:kCIAttributeSliderMin] floatValue];
            CGFloat max = [[inputHighlightDic objectForKey:kCIAttributeSliderMax] floatValue];
        
        
            JBoImageFilterSlider *highlightSlider = [[JBoImageFilterSlider alloc] initWithFrame:CGRectMake((superView.width - _imageFilterSliderDefaultWidth_) / 2, (superView.height - _imageFilterSliderDefaultHeight_ - _imageFilterSliderDefaultPadding_ - _menuHeight_), _imageFilterSliderDefaultWidth_, _imageFilterSliderDefaultHeight_)];
            [highlightSlider addTarget:self action:@selector(highlightAdjust:) forControlEvents:UIControlEventValueChanged];
            highlightSlider.slider.minimumValue = min;
            highlightSlider.slider.maximumValue = max;
        highlightSlider.slider.value = min;//(min + max) / 2.0;
            [superView addSubview:highlightSlider];
            self.highlightSlider = highlightSlider;
            [highlightSlider release];
            
            //阴影
            NSDictionary *shadowDic = [self.filter.attributes objectForKey:inputShadowKey];
            min = [[shadowDic objectForKey:kCIAttributeSliderMin] floatValue];
            max = [[shadowDic objectForKey:kCIAttributeSliderMax] floatValue];
            
            JBoImageFilterSlider *shadowSlider = [[JBoImageFilterSlider alloc] initWithFrame:CGRectMake(0, 0, _imageFilterSliderDefaultWidth_, _imageFilterSliderDefaultHeight_)];
            shadowSlider.center = CGPointMake(superView.width - _imageFilterSliderDefaultPadding_ / 2.0 - _imageFilterSliderDefaultHeight_ / 2.0, _imageFilterSliderDefaultPadding_ + _imageFilterSliderDefaultWidth_ / 2.0);
            shadowSlider.direction = JBoImageFilterSliderDirectionVertical;
            [shadowSlider addTarget:self action:@selector(shadowAdjust:) forControlEvents:UIControlEventValueChanged];
            shadowSlider.slider.minimumValue = min;
            shadowSlider.slider.maximumValue = max;
        shadowSlider.slider.value = min;//(min + max) / 2.0;
            [superView addSubview:shadowSlider];
            self.shadowSlider = shadowSlider;
            [shadowSlider release];
        
        [self valueDidChange];
    }
    return self;
}

- (void)close
{
    [self.shadowSlider removeFromSuperview];
    [self.highlightSlider removeFromSuperview];
     [super close];
}

- (UIImage*)getFilterImageFromImage:(UIImage *)image
{
    CIImage *inputImage = [CIImage imageWithCGImage:image.CGImage];
    
    self.filter = [CIFilter filterWithName:@"CIHighlightShadowAdjust"];
    [self.filter setValue:inputImage forKey:kCIInputImageKey];
    [self.filter setValue:[NSNumber numberWithFloat:self.highlightSlider.slider.value] forKey:inputHighlightKey];
    [self.filter setValue:[NSNumber numberWithFloat:self.shadowSlider.slider.value] forKey:inputShadowKey];
    
    CIImage *outputImage = [self.filter outputImage];
    
    CGRect cropRect = [outputImage extent];
    if(cropRect.size.width >= NSNotFound || cropRect.size.height >= NSNotFound)
    {
        cropRect = CGRectMake(0, 0, image.size.width, image.size.height);
    }
    
    CGImageRef imageRef = [self.context createCGImage:outputImage fromRect:cropRect];
    
    UIImage *retImage = [UIImage imageWithCGImage:imageRef];
    
    CGImageRelease(imageRef);
    
    return retImage;
}

#pragma mark- private method

- (void)highlightAdjust:(UISlider*) slider
{
    [self valueDidChange];
}

- (void)shadowAdjust:(UISlider*) slider
{
    [self valueDidChange];
}


@end
