//
//  JBoImageFilterSlider.h
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum _JBoImageFilterSliderDirection
{
    JBoImageFilterSliderDirectionNormal = 0,
    JBoImageFilterSliderDirectionVertical = 1 //垂直
}JBoImageFilterSliderDirection;

@interface JBoImageFilterSlider : UIView

#define _imageFilterSliderDefaultWidth_ 260.0
#define _imageFilterSliderDefaultHeight_ 30.0
#define _imageFilterSliderDefaultPadding_ 20.0

@property(nonatomic,readonly) UISlider *slider;
@property(nonatomic,assign) JBoImageFilterSliderDirection direction;


- (void)addTarget:(id) target action:(SEL)action forControlEvents:(UIControlEvents)controlEvents;

@end
