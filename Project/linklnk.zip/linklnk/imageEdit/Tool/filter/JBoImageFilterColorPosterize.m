//
//  JBoImageFilterColorPosterize.m
//  靓咖
//
//  Created by kinghe005 on 14-5-31.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterColorPosterize.h"

static NSString *const inputLevelsKey = @"inputLevels";

@interface JBoImageFilterColorPosterize ()

@property(nonatomic,retain) JBoImageFilterSlider *levelsSlider;

@end

@implementation JBoImageFilterColorPosterize

#pragma mark- 内存管理

- (void)dealloc
{
    [_levelsSlider release];
    [super dealloc];
}

#pragma mark- super method

- (id)initWithSuperView:(UIView *)superView imageView:(UIImageView *)imageView orignalImage:(UIImage *)originalImage rootThumbnail:(UIImage *)thumbnail
{
    self = [super initWithSuperView:superView imageView:imageView orignalImage:originalImage rootThumbnail:thumbnail];
    if(self)
    {
        self.filter = [CIFilter filterWithName:@"CIColorPosterize"];
        
        //亮度
        NSDictionary *inputLevelsDic = [self.filter.attributes objectForKey:inputLevelsKey];
        CGFloat min = [[inputLevelsDic objectForKey:kCIAttributeSliderMin] floatValue];
        CGFloat max = [[inputLevelsDic objectForKey:kCIAttributeSliderMax] floatValue];
        
        JBoImageFilterSlider *levelsSlider = [[JBoImageFilterSlider alloc] initWithFrame:CGRectMake((superView.width - _imageFilterSliderDefaultWidth_) / 2, (superView.height - _imageFilterSliderDefaultHeight_ - _imageFilterSliderDefaultPadding_ - _menuHeight_), _imageFilterSliderDefaultWidth_, _imageFilterSliderDefaultHeight_)];
        [levelsSlider addTarget:self action:@selector(vibranceAdjust:) forControlEvents:UIControlEventValueChanged];
        levelsSlider.slider.minimumValue = min;
        levelsSlider.slider.maximumValue = max;
        levelsSlider.slider.value = min;//(min + max) / 2.0;
        [superView addSubview:levelsSlider];
        self.levelsSlider = levelsSlider;
        [levelsSlider release];
        
        
        [self valueDidChange];
    }
    return self;
}

- (void)close
{
    [self.levelsSlider removeFromSuperview];
    [super close];
}

- (UIImage*)getFilterImageFromImage:(UIImage *)image
{
    CIImage *inputImage = [CIImage imageWithCGImage:image.CGImage];
    
    self.filter = [CIFilter filterWithName:@"CIColorPosterize"];
    [self.filter setValue:inputImage forKey:kCIInputImageKey];
    [self.filter setValue:[NSNumber numberWithFloat:self.levelsSlider.slider.value] forKey:inputLevelsKey];
    
    CIImage *outputImage = [self.filter outputImage];
    
    CGRect cropRect = [outputImage extent];
    if(cropRect.size.width >= NSNotFound || cropRect.size.height >= NSNotFound)
    {
        cropRect = CGRectMake(0, 0, image.size.width, image.size.height);
    }
    
    CGImageRef imageRef = [self.context createCGImage:outputImage fromRect:cropRect];
    
    UIImage *retImage = [UIImage imageWithCGImage:imageRef];
    
    CGImageRelease(imageRef);
    
    return retImage;
}

#pragma mark- private method

- (void)vibranceAdjust:(UISlider*) slider
{
    [self valueDidChange];
}

@end
