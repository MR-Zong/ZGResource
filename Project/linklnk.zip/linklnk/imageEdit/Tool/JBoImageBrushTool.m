//
//  JBoImageBrushTool.m
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageBrushTool.h"
#import "JBoBrushScrollView.h"
#import "JBoBrushView.h"

@interface JBoImageBrushTool ()<JBoBrushScrollViewDelegate,JBoBrushViewDelegate>

@property(nonatomic,retain) JBoBrushView *brushView;
@property(nonatomic,retain) JBoBrushScrollView *brushScrollView;

@end

@implementation JBoImageBrushTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_brushView release];
    [_brushScrollView release];
    
    [super dealloc];
}

#pragma mark- super method

- (void)initilization
{
    //画板
    JBoBrushView *brushView = [[JBoBrushView alloc] initWithFrame:CGRectMake(0, 0, self.imageEditor.editImageView.frame.size.width, self.imageEditor.editImageView.frame.size.height)];
    brushView.brushing = YES;
    brushView.delegate = self;
    [self.imageEditor.editImageView addSubview:brushView];
    self.brushView = brushView;
    [brushView release];
    
    
    //画笔
    JBoBrushScrollView *brushScrollView = [[JBoBrushScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.bounds.size.width, self.menuContainer.bounds.size.height)];
    brushScrollView.delegate = self;
    brushScrollView.backgroundColor = self.imageEditor.menuScrollView.backgroundColor;
    [self.menuContainer addSubview:brushScrollView];
    self.brushScrollView = brushScrollView;
    [brushScrollView release];
    
    [self.brushScrollView selectedColorAtIndex:0];
    [self.brushScrollView selectedLineWidth:2.0];
    self.imageEditor.scrollView.panGestureRecognizer.minimumNumberOfTouches = 2;
}

- (void)endEdit
{
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        [super endEdit];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
             UIImage *image = [self getComponentImageWithType:JBoImageEditTypeBrush];
             dispatch_async(dispatch_get_main_queue(), ^(void){
                [self.delegate imageEditTool:self editType:JBoImageEditTypeBrush didFinishEditWithImage:image];
            });
        });
    }
}

- (void)close
{
    self.imageEditor.scrollView.panGestureRecognizer.minimumNumberOfTouches = 1;
    [self.brushView removeFromSuperview];
    [super close];
}

#pragma mark-JBoBrushScrollView代理

- (void)brushScrollView:(JBoBrushScrollView *)brush didSelectedColorAtIndex:(NSInteger)index
{
    self.brushView.selectedColor = brush.selectedColor;
    self.brushView.blendMode = brush.blendMode;
}

- (void)brushScrollView:(JBoBrushScrollView *)brush lineWidthDidChanged:(CGFloat)lineWidth
{
    self.brushView.lineWidth = lineWidth;
}

- (void)brushScrollView:(JBoBrushScrollView *)brush DidUndone:(UIButton *)button
{
    [self.brushView undo];
    button.enabled = [self.brushView canUndo];
}

#pragma mark- JBoBrushViewDelegate

- (void)brushViewDidDraw:(JBoBrushView *)brushView
{
    _brushScrollView.undoButton.enabled = YES;
}

@end
