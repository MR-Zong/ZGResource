//
//  JBoImageFilterTool.m
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageFilterTool.h"
#import "JBoImageEditMenuItemView.h"
#import "JBoImageFilterColorMatrix.h"


#define _itemStartTag_ 1000

@interface JBoImageFilterTool ()

//源图片 和 缩略图
@property(nonatomic,retain) UIImage *bottomThumbnail;
@property(nonatomic,retain) UIImage *rootThumbnail;

//滤镜名称，数组元素是 NSString
@property(nonatomic,retain) NSArray *filterArray;

//滤镜选择菜单
@property(nonatomic,retain) UIScrollView *filterScrollView;

//选中的滤镜
@property(nonatomic,assign) NSInteger selectedIndex;

//scrollView 原始缩放比例
@property (nonatomic, assign) CGFloat maximumZoomScale;
@property (nonatomic, assign) CGFloat minimumZoomScale;

@end

@implementation JBoImageFilterTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_bottomThumbnail release];
    [_rootThumbnail release];
    [_filterArray release];
    [_filterScrollView release];
    
    [super dealloc];
}

#pragma mark- super method

- (void)initilization
{
//    self.imageEditor.scrollView.scrollEnabled = NO;
//    self.minimumZoomScale = self.imageEditor.scrollView.minimumZoomScale;
//    self.maximumZoomScale = self.imageEditor.scrollView.maximumZoomScale;
//    [self.imageEditor.scrollView setMaximumZoomScale:1.0];
//    [self.imageEditor.scrollView setMinimumZoomScale:1.0];
    [self.imageEditor.scrollView setZoomScale:self.imageEditor.scrollView.minimumZoomScale];
    
    CGFloat size = 30.0;
    UIActivityIndicatorView *actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    actView.frame = CGRectMake((self.menuContainer.width - size) / 2, (self.menuContainer.height - size) / 2, size, size);
    [self.menuContainer addSubview:actView];
    [actView startAnimating];
    [actView release];
    
    
    //异步加载滤镜
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void)
    {
        self.bottomThumbnail = [self.originalImage aspectFillThumbnailWithSize:CGSizeMake(_imageEditItemIconDefuaultSize_, _imageEditItemIconDefuaultSize_)];
        self.rootThumbnail = [self.originalImage resize:CGSizeMake(_width_ * 2, _height_ * 2)];
        self.imageEditor.editImageView.image = self.rootThumbnail;
        
        self.filterArray = [JBoImageFilterColorMatrix filterNames];
        NSMutableArray *images = [NSMutableArray arrayWithCapacity:self.filterArray.count];
        
        for(NSInteger i = 0;i < self.filterArray.count;i ++)
        {
            UIImage *image = [JBoImageFilterColorMatrix imageWithImage:self.bottomThumbnail withColorMatrix:[JBoImageFilterColorMatrix colorMartrixForIndex:i]];
            if(image)
            {
                [images addObject:image];
            }
        }
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            [actView stopAnimating];
            [actView removeFromSuperview];
            
            //创建滤镜选择菜单
            UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.bounds.size.width, self.menuContainer.bounds.size.height)];
            scrollView.backgroundColor = self.imageEditor.menuScrollView.backgroundColor;
            scrollView.showsHorizontalScrollIndicator = NO;
            scrollView.showsVerticalScrollIndicator = NO;
            [self.menuContainer addSubview:scrollView];
            self.filterScrollView = scrollView;
            [scrollView release];
            
            [self  setupMenuItemsWithImages:images];
        });
    });
}

- (void)close
{
//    self.imageEditor.scrollView.minimumZoomScale = self.minimumZoomScale;
//    self.imageEditor.scrollView.maximumZoomScale = self.maximumZoomScale;
//    self.imageEditor.scrollView.scrollEnabled = YES;
    [super close];
}

- (void)endEdit
{
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        [super endEdit];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
            UIImage *retImage = [JBoImageFilterColorMatrix imageWithImage:self.originalImage withColorMatrix:[JBoImageFilterColorMatrix colorMartrixForIndex:self.selectedIndex]];
            
            dispatch_async(dispatch_get_main_queue(), ^(void)
            {
                [self.delegate imageEditTool:self editType:JBoImageEditTypeFilter didFinishEditWithImage:retImage];
            });
        });
    }
}


#pragma mark- private method

//设置菜单
- (void)setupMenuItemsWithImages:(NSArray*) images
{
    CGFloat height = self.imageEditor.menuScrollView.bounds.size.height;
    CGFloat width = _imageEditItemIconDefuaultSize_ + 10.0;
    
    for(NSInteger i = 0;i < self.filterArray.count && i < images.count;i ++)
    {
        NSString *title = [self.filterArray objectAtIndex:i];
        UIImage *image = [images objectAtIndex:i];
        
        JBoImageEditMenuItemView *item = [[JBoImageEditMenuItemView alloc] initWithFrame:CGRectMake(width * i, 0, width, height) icon:image title:title];
        item.titleLabel.textColor = [UIColor whiteColor];
        item.tag = _itemStartTag_ + i;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(filterDidSelected:)];
        [item addGestureRecognizer:tap];
        [tap release];
        
        [self.filterScrollView addSubview:item];
        [item release];
    }
    
    self.filterScrollView.contentSize = CGSizeMake(width * self.filterArray.count, self.filterScrollView.bounds.size.height);
    self.selectedIndex = 0;
}

//选择滤镜
- (void)filterDidSelected:(UITapGestureRecognizer*) tap
{
    static BOOL inProgress = NO;
    if(inProgress)
        return;
    NSInteger index = tap.view.tag - _itemStartTag_;
    if(index == self.selectedIndex)
        return;
    
    inProgress = YES;
    self.selectedIndex = index;
    
    [self beginRender];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){

        UIImage *retImage = [JBoImageFilterColorMatrix imageWithImage:self.rootThumbnail withColorMatrix:[JBoImageFilterColorMatrix colorMartrixForIndex:self.selectedIndex]];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
             inProgress = NO;
             self.imageEditor.editImageView.image = retImage;
            [self endRender];
        });
    });
}

- (void)setSelectedIndex:(NSInteger)selectedIndex
{
    JBoImageEditMenuItemView *view = (JBoImageEditMenuItemView*)[self.filterScrollView viewWithTag:_selectedIndex + _itemStartTag_];
    view.selected = NO;
    _selectedIndex = selectedIndex;
    view = (JBoImageEditMenuItemView*)[self.filterScrollView viewWithTag:_selectedIndex + _itemStartTag_];;
    view.selected = YES;
}

//最大公约数
int GCD(int num1,int num2)
{
    if(num1 % num2 == 0)
        return num2;
    else
        return GCD(num2,num1 % num2);
}

//最小公倍数
int LCM(int a,int b)
{
    int temp_lcm;
    temp_lcm= a * b / GCD (a,b);//最小公倍数等于两数之积除以最大公约数
    return temp_lcm;
}

@end
