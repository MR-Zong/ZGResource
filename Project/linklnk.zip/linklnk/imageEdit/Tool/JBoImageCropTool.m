//
//  JBoImageCropTool.m
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageCropTool.h"
#import <QuartzCore/QuartzCore.h>

#define _animationDuration_ 0.25
#define _flipSize_ 70.0
#define _adjustZoomScale_ 0.90

static void* editImageViewFrameContext = &editImageViewFrameContext;

/**图片裁剪网格比例
 */
@interface JBoRatio : NSObject

/**图片是否是横的，即图片的宽大于高
 */
@property (nonatomic, assign) BOOL isLandscape;

/**比例值
 */
@property (nonatomic, readonly) CGFloat ratio;

/**构造方法 value1 : value2
 *@param value1 左边比数值
 *@param value2 右边比数值
 *@return 一个实例
 */
- (id)initWithValue1:(NSInteger)value1 value2:(NSInteger)value2;

/**比例文字描述
 */
- (NSString*)description;

/**便利构造方法
 */
+ (id)ratioWithValue1:(NSInteger) value1 value2:(NSInteger) value2;

@end

/**图片裁剪网格比例选择按钮
 */
@interface JBoRatioMenuItem : UIView

/**网格比例
 */
@property (nonatomic, retain) JBoRatio *ratio;

/**构造方法 
 *@param frame 位置大小
 *@param iconImage 要裁剪的图片
 *@return 一个实例
 */
- (id)initWithFrame:(CGRect)frame iconImage:(UIImage*)iconImage;

/**改变图片朝向,即把宽 ：高变成 高 ：宽
 */
- (void)changeOrientation;

@end

/**图片裁剪网格控制面板
 */
@interface JBoCroppingPanel : UIView

/**目前要裁减范围
 */
@property (nonatomic, assign) CGRect croppingRect;

/**目前裁剪网格的比例
 */
@property (nonatomic, retain) JBoRatio *croppingRatio;

/**构造方法
 *@param superview 网格的父视图
 *@param 网格的位置大小
 *@return 一个实例
 */
- (id)initWithSuperview:(UIView*)superview frame:(CGRect)frame;

/**设置网格的背景颜色
 */
- (void)setBgColor:(UIColor*)bgColor;

/**设置网格的颜色
 */
- (void)setGridColor:(UIColor*)gridColor;

/**网格的比例改变
 */
- (void)croppingRatioDidChange;

@end

/**控制按钮角度朝向
 */
typedef NS_ENUM(NSInteger, JBoCroppingCircleDirection)
{
    JBoCroppingCircleDirectionLeftTop = 0, //左上角
    JBoCroppingCircleDirectionRightTop = 1, //右上角
    JBoCroppingCircleDirectionLeftBottom = 2, //左下角
    JBoCroppingCircleDirectionRightBottom = 3, //右下角
};

/**图片裁剪框边角上的按钮
 */
@interface JBoCroppingCircle : UIView

/**背景颜色
 */
@property (nonatomic,retain) UIColor *bgColor;

/**方向
 */
@property (nonatomic,assign) JBoCroppingCircleDirection direction;

/**线条长度 default is '12.0',最长不能超过frame.size.width / 2.0
 */
@property (nonatomic,assign) CGFloat lineLength;

@end

/**网格图层
 */
@interface JBoGridLayar : CALayer

/**当前剪切范围
 */
@property (nonatomic, assign) CGRect croppingRect;

/**网格未覆盖的背景颜色
 */
@property (nonatomic, retain) UIColor *bgColor;

/**网格背景颜色
 */
@property (nonatomic, retain) UIColor *gridColor;

@end

#pragma mark- CLClippintTool

@interface JBoImageCropTool()

//剪切网格
@property (nonatomic, retain) JBoCroppingPanel *croppingPanel;

//选中网格比例按钮
@property (nonatomic, retain) JBoRatioMenuItem *selectedMenu;

//网格比例菜单
@property (nonatomic, retain) UIScrollView *cropScrollView;

//scrollView 原始缩放比例
@property (nonatomic, assign) CGFloat maximumZoomScale;
@property (nonatomic, assign) CGFloat minimumZoomScale;

@end


@implementation JBoImageCropTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_croppingPanel release];
    [_selectedMenu release];
    [_cropScrollView release];
    
    //[self removeObserver:self forKeyPath:@"imageEditor.editImageView.frame" context:editImageViewFrameContext];
    
    [super dealloc];
}

#pragma mark- super method

//初始化
- (void)initilization
{
    //原始的图片缩放比例
    self.minimumZoomScale = self.imageEditor.scrollView.minimumZoomScale;
    self.maximumZoomScale = self.imageEditor.scrollView.maximumZoomScale;
    
    CGFloat minZoomScale = self.imageEditor.scrollView.minimumZoomScale;
    
    self.imageEditor.scrollView.maximumZoomScale = _adjustZoomScale_ * minZoomScale;
    self.imageEditor.scrollView.minimumZoomScale = _adjustZoomScale_ * minZoomScale;
    
   // [self addObserver:self forKeyPath:@"imageEditor.editImageView.frame" options:NSKeyValueObservingOptionNew context:editImageViewFrameContext];
    [self.imageEditor.scrollView setZoomScale:self.imageEditor.scrollView.minimumZoomScale animated:NO];
    
    //裁剪网格比例选择菜单
    UIScrollView *cropScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.width - _flipSize_, self.menuContainer.height)];
    cropScrollView.backgroundColor = [UIColor clearColor];
    cropScrollView.showsHorizontalScrollIndicator = NO;
    cropScrollView.clipsToBounds = NO;
    [self.menuContainer addSubview:cropScrollView];
    self.cropScrollView = cropScrollView;
    [cropScrollView release];
    
    
    //翻转按钮
    UIView *flipView = [[UIView alloc] initWithFrame:CGRectMake(self.cropScrollView.right, 0, _flipSize_, self.cropScrollView.height)];
    flipView.backgroundColor = [self.menuContainer.backgroundColor colorWithAlphaComponent:0.9];
    [self.menuContainer addSubview:flipView];
    [flipView release];
    
    CGFloat size = 40.0;
    UIButton *flipButton = [UIButton buttonWithType:UIButtonTypeCustom];
    flipButton.frame = CGRectMake((_flipSize_ - size) / 2, (flipView.height - size) / 2, size, size);
    [flipButton addTarget:self action:@selector(pushedRotateBtn:) forControlEvents:UIControlEventTouchUpInside];
    [flipButton setImage:[UIImage imageNamed:@"imageEditor_crop_reverse"] forState:UIControlStateNormal];
    flipButton.adjustsImageWhenHighlighted = YES;
    [flipView addSubview:flipButton];
    
    [self createCropMenuItem];
    [self createGrid];
}

- (void)endEdit
{
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        [super endEdit];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
            CGFloat Rw = self.imageEditor.editImageView.width / self.originalImage.size.width;
            CGFloat Rh = self.imageEditor.editImageView.height / self.originalImage.size.height;
            CGFloat scale = MIN(Rw, Rh);
            
            CGRect rct = self.croppingPanel.croppingRect;
            
            rct.size.width  /= scale;
            rct.size.height /= scale;
            rct.origin.x    /= scale;
            rct.origin.y    /= scale;
            
            UIImage *result = [self.originalImage subImageWithRect:rct];
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [self.delegate imageEditTool:self editType:JBoImageEditTypeBrush didFinishEditWithImage:result];
            });
        });
    }
}

- (void)close
{
    self.imageEditor.scrollView.minimumZoomScale = self.minimumZoomScale;
    self.imageEditor.scrollView.maximumZoomScale = self.maximumZoomScale;
    [self.croppingPanel removeFromSuperview];
    [super close];
}

#pragma mark- private method

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if(context == editImageViewFrameContext)
    {
        [self createGrid];
    }
}

//创建裁剪网格
- (void)createGrid
{
    if(!self.croppingPanel)
    {
        //图片裁剪控制器
        JBoCroppingPanel *panel = [[JBoCroppingPanel alloc] initWithSuperview:self.imageEditor.scrollView frame:self.imageEditor.editImageView.frame];
        panel.backgroundColor = [UIColor clearColor];
        panel.bgColor = [self.imageEditor.view.backgroundColor colorWithAlphaComponent:0.5];
        panel.gridColor = [UIColor colorWithWhite:1.0 alpha:0.7];
        panel.clipsToBounds = NO;
        self.croppingPanel = panel;
        [panel release];
    }
}

//创建网格比例按钮
- (void)createCropMenuItem
{
    CGFloat W = _flipSize_;
    CGFloat x = 0;
    
    NSMutableArray *array = [NSMutableArray array];
    [array addObject:[JBoRatio ratioWithValue1:0 value2:0]];
    [array addObject:[JBoRatio ratioWithValue1:1 value2:1]];
    [array addObject:[JBoRatio ratioWithValue1:4 value2:3]];
    [array addObject:[JBoRatio ratioWithValue1:3 value2:2]];
    [array addObject:[JBoRatio ratioWithValue1:16 value2:9]];
    
    CGSize  imgSize = self.imageEditor.editImageView.image.size;
    CGFloat maxW = MIN(imgSize.width, imgSize.height);
    UIImage *iconImage = [self.imageEditor.editImageView.image resize:CGSizeMake(W * imgSize.width / maxW, W * imgSize.height / maxW)];
    
    for(JBoRatio *ratio in array)
    {
        ratio.isLandscape = (self.imageEditor.editImageView.image.size.width > self.imageEditor.editImageView.image.size.height);
        
        JBoRatioMenuItem *view = [[JBoRatioMenuItem alloc] initWithFrame:CGRectMake(x, 0, W, self.cropScrollView.height) iconImage:iconImage];
        view.ratio = ratio;
        
        UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tappedMenu:)];
        [view addGestureRecognizer:gesture];
        [gesture release];
        
        [self.cropScrollView addSubview:view];
        x += W;
        
        if(self.selectedMenu == nil)
        {
            self.selectedMenu = view;
        }
        [view release];
    }
    self.cropScrollView.contentSize = CGSizeMake(MAX(x, self.cropScrollView.frame.size.width + 1), 0);
}

//选择网格比例
- (void)tappedMenu:(UITapGestureRecognizer*) tap
{
    JBoRatioMenuItem *view = (JBoRatioMenuItem*)tap.view;
    
    view.alpha = 0.2;
    [UIView animateWithDuration:_animationDuration_
                     animations:^{
                         view.alpha = 1;
                     }
     ];
    
    self.selectedMenu = view;
    
    self.croppingPanel.croppingRatio = view.ratio.ratio == 0 ? nil : view.ratio;
}

//设置目前选择的网格比例
- (void)setSelectedMenu:(JBoRatioMenuItem *) selectedMenu
{
    if(selectedMenu != _selectedMenu)
    {
        _selectedMenu.backgroundColor = [UIColor clearColor];
        [_selectedMenu release];
        _selectedMenu = [selectedMenu retain];
        _selectedMenu.backgroundColor = [[UIColor cyanColor] colorWithAlphaComponent:0.2];
    }
}

//调换网格比例
- (void)pushedRotateBtn:(UIButton*) button
{
    for(JBoRatioMenuItem *item in self.cropScrollView.subviews)
    {
        if([item isKindOfClass:[JBoRatioMenuItem class]]){
            [item changeOrientation];
        }
    }
    
    if(self.croppingPanel.croppingRatio.ratio != 0 && self.croppingPanel.croppingRatio.ratio != 1)
    {
        [self.croppingPanel croppingRatioDidChange];
    }
}

@end


#pragma mark- UI components

@implementation JBoCroppingCircle

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        _lineLength = 12.0;
        _direction = JBoCroppingCircleDirectionLeftTop;
    }
    
    return self;
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGRect rct = self.bounds;
    
    //设置线条类型
    CGContextSetStrokeColorWithColor(context, _bgColor.CGColor);
    CGContextSetLineWidth(context, 3.0);
    CGContextSetLineJoin(context, kCGLineJoinRound);
    CGContextSetLineCap(context, kCGLineCapRound);
    
    //中心点和线条长度
    CGPoint center = CGPointMake(rct.size.width / 2.0, rct.size.height / 2.0);
    CGFloat lineLength = MIN(_lineLength, rct.size.width / 2.0);
    
    switch (_direction)
    {
        case JBoCroppingCircleDirectionLeftTop :
        {
            CGContextMoveToPoint(context, center.x, center.y + lineLength);
            CGContextAddLineToPoint(context, center.x, center.y);
            CGContextAddLineToPoint(context, center.x + lineLength, center.y);
        }
            break;
        case JBoCroppingCircleDirectionRightTop :
        {
            CGContextMoveToPoint(context, center.x, center.y + lineLength);
            CGContextAddLineToPoint(context, center.x, center.y);
            CGContextAddLineToPoint(context, center.x - lineLength, center.y);
        }
            break;
        case JBoCroppingCircleDirectionLeftBottom :
        {
            CGContextMoveToPoint(context, center.x, center.y - lineLength);
            CGContextAddLineToPoint(context, center.x, center.y);
            CGContextAddLineToPoint(context, center.x + lineLength, center.y);
        }
            break;
        case JBoCroppingCircleDirectionRightBottom :
        {
            CGContextMoveToPoint(context, center.x, center.y - lineLength);
            CGContextAddLineToPoint(context, center.x, center.y);
            CGContextAddLineToPoint(context, center.x - lineLength, center.y);
        }
            break;
    }
   
    CGContextStrokePath(context);
    
//    rct.origin.x = rct.size.width / 2 - rct.size.width / 6;
//    rct.origin.y = rct.size.height / 2 - rct.size.height / 6;
//    rct.size.width /= 3;
//    rct.size.height /= 3;
//    
//    CGContextSetFillColorWithColor(context, self.bgColor.CGColor);
//    CGContextFillEllipseInRect(context, rct);
}

- (void)dealloc
{
    [_bgColor release];
    [super dealloc];
}

@end


@implementation JBoGridLayar

/**是否需要刷新图层
 */
+ (BOOL)needsDisplayForKey:(NSString*)key
{
    if ([key isEqualToString:@"croppingRect"]) {
        return YES;
    }
    return [super needsDisplayForKey:key];
}

- (id)initWithLayer:(id)layer
{
    self = [super initWithLayer:layer];
    if(self && [layer isKindOfClass:[JBoGridLayar class]])
    {
        self.bgColor   = ((JBoGridLayar*)layer).bgColor;
        self.gridColor = ((JBoGridLayar*)layer).gridColor;
        self.croppingRect = ((JBoGridLayar*)layer).croppingRect;
    }
    return self;
}

- (void)dealloc
{
    [_bgColor release];
    [_gridColor release];
    [super dealloc];
}

- (void)drawInContext:(CGContextRef)context
{
    CGRect rct = self.bounds;
    
    CGContextSetFillColorWithColor(context, _bgColor.CGColor);
    CGContextFillRect(context, rct);
    
    CGContextClearRect(context, _croppingRect);
    
    CGContextSetStrokeColorWithColor(context, _gridColor.CGColor);
    CGContextSetLineWidth(context, 1);
    
    rct = _croppingRect;
    
    CGContextBeginPath(context);
    CGFloat dW = 0;
    for(int i = 0;i < 4;++i)
    {
        CGContextMoveToPoint(context, rct.origin.x + dW, rct.origin.y);
        CGContextAddLineToPoint(context, rct.origin.x + dW, rct.origin.y + rct.size.height);
        dW += _croppingRect.size.width / 3;
    }
    
    dW = 0;
    for(int i = 0;i < 4;++i)
    {
        CGContextMoveToPoint(context, rct.origin.x, rct.origin.y + dW);
        CGContextAddLineToPoint(context, rct.origin.x + rct.size.width, rct.origin.y + dW);
        dW += rct.size.height / 3;
    }
    CGContextStrokePath(context);
}

@end

@interface JBoCroppingPanel ()

@property(nonatomic,retain) JBoGridLayar *gridLayer;

//网格拖动控制按钮
@property(nonatomic,retain) JBoCroppingCircle *leftTopCircle;
@property(nonatomic,retain) JBoCroppingCircle *leftBottomCircle;
@property(nonatomic,retain) JBoCroppingCircle *rightTopCircle;;
@property(nonatomic,retain) JBoCroppingCircle *rightBottomCircle;

@end

@implementation JBoCroppingPanel

- (id)initWithSuperview:(UIView*)superview frame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        [superview addSubview:self];
        
        //图片裁剪网格
        JBoGridLayar *gridLayer = [[JBoGridLayar alloc] init];
        gridLayer.frame = self.bounds;
        gridLayer.bgColor   = [UIColor colorWithWhite:0 alpha:0.6];
        gridLayer.gridColor = [UIColor colorWithWhite:0 alpha:0.6];
        [self.layer addSublayer:gridLayer];
        self.gridLayer = gridLayer;
        [gridLayer release];
        
        //图片裁剪网格四格边角控制按钮
        self.leftTopCircle = [self croppingCircleWithTag:0];
        self.leftTopCircle.direction = JBoCroppingCircleDirectionLeftTop;
        
        self.leftBottomCircle = [self croppingCircleWithTag:1];
        self.leftBottomCircle.direction = JBoCroppingCircleDirectionLeftBottom;
        
        self.rightTopCircle = [self croppingCircleWithTag:2];
        self.rightTopCircle.direction = JBoCroppingCircleDirectionRightTop;
        
        self.rightBottomCircle = [self croppingCircleWithTag:3];
        self.rightBottomCircle.direction = JBoCroppingCircleDirectionRightBottom;
        
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGridView:)];
        [self addGestureRecognizer:panGesture];
        [panGesture release];
        
        self.croppingRect = self.bounds;
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_croppingRatio release];
    
    [_gridLayer release];
    [_leftTopCircle release];
    [_leftBottomCircle release];
    [_rightTopCircle release];
    [_rightBottomCircle release];
    
    [super dealloc];
}

#pragma mark- private method

//创建网格边角按钮
- (JBoCroppingCircle*)croppingCircleWithTag:(NSInteger)tag
{
    JBoCroppingCircle *view = [[JBoCroppingCircle alloc] initWithFrame:CGRectMake(0, 0, 75, 75)];
    view.backgroundColor = [UIColor clearColor];
    view.bgColor = [UIColor colorWithWhite:1.0 alpha:0.7];
    view.tag = tag;
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panCircleView:)];
    [view addGestureRecognizer:panGesture];
    [panGesture release];
    
    [self.superview addSubview:view];
    
    return [view autorelease];
}

- (void)removeFromSuperview
{
    [self.leftTopCircle removeFromSuperview];
    [self.leftBottomCircle removeFromSuperview];
    [self.rightTopCircle removeFromSuperview];
    [self.rightBottomCircle removeFromSuperview];
    
    [super removeFromSuperview];
}

#pragma mark- public method

- (void)setBgColor:(UIColor *)bgColor
{
    _gridLayer.bgColor = bgColor;
}

- (void)setGridColor:(UIColor *)gridColor
{
    _gridLayer.gridColor = gridColor;
    self.leftTopCircle.bgColor = self.leftBottomCircle.bgColor = self.rightTopCircle.bgColor = self.rightBottomCircle.bgColor = [gridColor colorWithAlphaComponent:1];
}

//设置裁剪范围
- (void)setCroppingRect:(CGRect)croppingRect
{
    _croppingRect = croppingRect;
    
    _leftTopCircle.center = [self.superview convertPoint:CGPointMake(_croppingRect.origin.x, _croppingRect.origin.y) fromView:self];
    _leftBottomCircle.center = [self.superview convertPoint:CGPointMake(_croppingRect.origin.x, _croppingRect.origin.y + _croppingRect.size.height) fromView:self];
    _rightTopCircle.center = [self.superview convertPoint:CGPointMake(_croppingRect.origin.x + _croppingRect.size.width, _croppingRect.origin.y) fromView:self];
    _rightBottomCircle.center = [self.superview convertPoint:CGPointMake(_croppingRect.origin.x + _croppingRect.size.width, _croppingRect.origin.y + _croppingRect.size.height) fromView:self];
    
    _gridLayer.croppingRect = _croppingRect;
    [self setNeedsDisplay];
}

//设置裁剪范围，可动画
- (void)setCroppingRect:(CGRect) croppingRect animated:(BOOL)animated
{
    if(animated)
    {
        [UIView animateWithDuration:_animationDuration_
                         animations:^{
                             _leftTopCircle.center = [self.superview convertPoint:CGPointMake(croppingRect.origin.x, croppingRect.origin.y) fromView:self];
                             _leftBottomCircle.center = [self.superview convertPoint:CGPointMake(croppingRect.origin.x, croppingRect.origin.y +croppingRect.size.height) fromView:self];
                             _rightTopCircle.center = [self.superview convertPoint:CGPointMake(croppingRect.origin.x + croppingRect.size.width, croppingRect.origin.y) fromView:self];
                             _rightBottomCircle.center = [self.superview convertPoint:CGPointMake(croppingRect.origin.x + croppingRect.size.width, croppingRect.origin.y + croppingRect.size.height) fromView:self];
                         }
         ];
        
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"croppingRect"];
        animation.duration = _animationDuration_;
        animation.fromValue = [NSValue valueWithCGRect:_croppingRect];
        animation.toValue = [NSValue valueWithCGRect:croppingRect];
        [_gridLayer addAnimation:animation forKey:nil];
        
        _gridLayer.croppingRect = croppingRect;
        _croppingRect = croppingRect;
        
        [self setNeedsDisplay];
    }
    else
    {
        self.croppingRect = croppingRect;
    }
}

//裁剪网格比例改变
- (void)croppingRatioDidChange
{
    CGRect rect = self.bounds;
    if(self.croppingRatio)
    {
        CGFloat H = rect.size.width * self.croppingRatio.ratio;
        if(H<=rect.size.height)
        {
            rect.size.height = H;
        }
        else
        {
            rect.size.width *= rect.size.height / H;
        }
        
        rect.origin.x = (self.bounds.size.width - rect.size.width) / 2;
        rect.origin.y = (self.bounds.size.height - rect.size.height) / 2;
    }
    [self setCroppingRect:rect animated:YES];
}

//设置裁剪网格比例
- (void)setCroppingRatio:(JBoRatio *)croppingRatio
{
    if(_croppingRatio != croppingRatio)
    {
        [_croppingRatio release];
        _croppingRatio = [croppingRatio retain];
        [self croppingRatioDidChange];
    }
}

- (void)setNeedsDisplay
{
    [super setNeedsDisplay];
    [_gridLayer setNeedsDisplay];
}

#pragma mark- handle gesture

//网格边角控制按钮移动
- (void)panCircleView:(UIPanGestureRecognizer*)sender
{
    CGPoint point = [sender locationInView:self];
    CGPoint dp = [sender translationInView:self];
    
    CGRect rct = self.croppingRect;
    
    const CGFloat W = self.frame.size.width;
    const CGFloat H = self.frame.size.height;
    CGFloat minX = 0;
    CGFloat minY = 0;
    CGFloat maxX = W;
    CGFloat maxY = H;
    
    CGFloat ratio = (sender.view.tag == 1 || sender.view.tag==2) ? -self.croppingRatio.ratio : self.croppingRatio.ratio;
    
    switch (sender.view.tag) {
        case 0 : // upper left
        {
            maxX = MAX((rct.origin.x + rct.size.width)  - 0.1 * W, 0.1 * W);
            maxY = MAX((rct.origin.y + rct.size.height) - 0.1 * H, 0.1 * H);
            
            if(ratio!=0){
                CGFloat y0 = rct.origin.y - ratio * rct.origin.x;
                CGFloat x0 = -y0 / ratio;
                minX = MAX(x0, 0);
                minY = MAX(y0, 0);
                
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
                
                if(-dp.x*ratio + dp.y > 0)
                {
                    point.x = (point.y - y0) / ratio;
                }
                else
                {
                    point.y = point.x * ratio + y0;
                }
            }
            else
            {
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
            }
            
            rct.size.width  = rct.size.width  - (point.x - rct.origin.x);
            rct.size.height = rct.size.height - (point.y - rct.origin.y);
            rct.origin.x = point.x;
            rct.origin.y = point.y;
            
            break;
        }
        case 1 : // lower left
        {
            maxX = MAX((rct.origin.x + rct.size.width)  - 0.1 * W, 0.1 * W);
            minY = MAX(rct.origin.y + 0.1 * H, 0.1 * H);
            
            if(ratio!=0)
            {
                CGFloat y0 = (rct.origin.y + rct.size.height) - ratio* rct.origin.x ;
                CGFloat xh = (H - y0) / ratio;
                minX = MAX(xh, 0);
                maxY = MIN(y0, H);
                
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
                
                if(-dp.x*ratio + dp.y < 0)
                {
                    point.x = (point.y - y0) / ratio;
                }
                else
                {
                    point.y = point.x * ratio + y0;
                }
            }
            else
            {
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
            }
            
            rct.size.width  = rct.size.width  - (point.x - rct.origin.x);
            rct.size.height = point.y - rct.origin.y;
            rct.origin.x = point.x;
            break;
        }
        case 2: // upper right
        {
            minX = MAX(rct.origin.x + 0.1 * W, 0.1 * W);
            maxY = MAX((rct.origin.y + rct.size.height) - 0.1 * H, 0.1 * H);
            
            if(ratio!=0)
            {
                CGFloat y0 = rct.origin.y - ratio * (rct.origin.x + rct.size.width);
                CGFloat yw = ratio * W + y0;
                CGFloat x0 = -y0 / ratio;
                maxX = MIN(x0, W);
                minY = MAX(yw, 0);
                
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
                
                if(-dp.x*ratio + dp.y > 0)
                {
                    point.x = (point.y - y0) / ratio;
                }
                else
                {
                    point.y = point.x * ratio + y0;
                }
            }
            else
            {
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
            }
            
            rct.size.width  = point.x - rct.origin.x;
            rct.size.height = rct.size.height - (point.y - rct.origin.y);
            rct.origin.y = point.y;
            
            break;
        }
        case 3 : // lower right
        {
            minX = MAX(rct.origin.x + 0.1 * W, 0.1 * W);
            minY = MAX(rct.origin.y + 0.1 * H, 0.1 * H);
            
            if(ratio!=0)
            {
                CGFloat y0 = (rct.origin.y + rct.size.height) - ratio * (rct.origin.x + rct.size.width);
                CGFloat yw = ratio * W + y0;
                CGFloat xh = (H - y0) / ratio;
                maxX = MIN(xh, W);
                maxY = MIN(yw, H);
                
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
                
                if(-dp.x*ratio + dp.y < 0)
                {
                    point.x = (point.y - y0) / ratio;
                }
                else
                {
                    point.y = point.x * ratio + y0;
                }
            }
            else
            {
                point.x = MAX(minX, MIN(point.x, maxX));
                point.y = MAX(minY, MIN(point.y, maxY));
            }
            
            rct.size.width  = point.x - rct.origin.x;
            rct.size.height = point.y - rct.origin.y;
            
            break;
        }
        default:
            break;
    }
    
    self.croppingRect = rct;
}

//一个整个网格
- (void)panGridView:(UIPanGestureRecognizer*) pan
{
    static BOOL dragging = NO;
    static CGRect initialRect;
    
    if(pan.state == UIGestureRecognizerStateBegan)
    {
        CGPoint point = [pan locationInView:self];
        dragging = CGRectContainsPoint(_croppingRect, point);
        initialRect = self.croppingRect;
    }
    else if(dragging)
    {
        CGPoint point = [pan translationInView:self];
        CGFloat left  = MIN(MAX(initialRect.origin.x + point.x, 0), self.frame.size.width - initialRect.size.width);
        CGFloat top   = MIN(MAX(initialRect.origin.y + point.y, 0), self.frame.size.height - initialRect.size.height);
        
        CGRect rct = self.croppingRect;
        rct.origin.x = left;
        rct.origin.y = top;
        self.croppingRect = rct;
    }
}

@end


@implementation JBoRatio
{
    NSInteger _longSide;
    NSInteger _shortSide;
}

/**构造方法 value1 : value2
 *@param value1 左边比数值
 *@param value2 右边比数值
 *@return 一个实例
 */
- (id)initWithValue1:(NSInteger)value1 value2:(NSInteger)value2
{
    self = [super init];
    if(self){
        _longSide  = MAX(labs(value1), labs(value2));
        _shortSide = MIN(labs(value1), labs(value2));
    }
    return self;
}

/**便利构造方法
 */
+ (id)ratioWithValue1:(NSInteger)value1 value2:(NSInteger)value2
{
    JBoRatio *ratio = [[JBoRatio alloc] initWithValue1:value1 value2:value2];
    return [ratio autorelease];
}

- (NSString*)description
{
    if(_longSide==0 || _shortSide==0){
        return @"自定义";
    }
    
    if(self.isLandscape){
        return [NSString stringWithFormat:@"%ld : %ld", (long)_longSide, (long)_shortSide];
    }
    return [NSString stringWithFormat:@"%ld : %ld", (long)_shortSide, (long)_longSide];
}

- (CGFloat)ratio
{
    if(_longSide==0 || _shortSide==0){
        return 0;
    }
    
    if(self.isLandscape){
        return _shortSide / (CGFloat)_longSide;
    }
    return _longSide / (CGFloat)_shortSide;
}

@end

//菜单按钮
@implementation JBoRatioMenuItem
{
    UIImageView *_iconView;
    UILabel *_titleLabel;
}

- (id)initWithFrame:(CGRect)frame iconImage:(UIImage *)iconImage
{
    self = [super initWithFrame:frame];
    if(self)
    {
        //按钮图标
        _iconView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 5, 50, 50)];
        _iconView.backgroundColor = [UIColor colorWithWhite:0 alpha:1];
        _iconView.image = iconImage;
        _iconView.clipsToBounds = YES;
        _iconView.contentMode = UIViewContentModeScaleAspectFill;
        _iconView.layer.cornerRadius = 3;
        [self addSubview:_iconView];
        
        //标题
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, frame.size.width-10, frame.size.width, 15)];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.font = [UIFont systemFontOfSize:10];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_titleLabel];
    }
    return self;
}

- (void)dealloc
{
    [_iconView release];
    [_titleLabel release];
    [_ratio release];
    
    [super dealloc];
}

- (void)setRatio:(JBoRatio *)ratio
{
    if(ratio != _ratio)
    {
        [_ratio release];
        _ratio = [ratio retain];
        [self refreshViews];
    }
}

- (void)refreshViews
{
    _titleLabel.text = [_ratio description];
    
    CGPoint center = _iconView.center;
    CGFloat W, H;
    if(_ratio.ratio != 0)
    {
        if(_ratio.isLandscape)
        {
            W = 50;
            H = 50 * _ratio.ratio;
        }
        else{
            W = 50 / _ratio.ratio;
            H = 50;
        }
    }
    else
    {
        CGFloat maxW  = MAX(_iconView.image.size.width, _iconView.image.size.height);
        W = 50 * _iconView.image.size.width / maxW;
        H = 50 * _iconView.image.size.height / maxW;
    }
    _iconView.frame = CGRectMake(center.x - W / 2, center.y - H / 2, W, H);
}

- (void)changeOrientation
{
    self.ratio.isLandscape = !self.ratio.isLandscape;
    
    [UIView animateWithDuration:_animationDuration_
                     animations:^{
                         [self refreshViews];
                     }
     ];
}

@end


