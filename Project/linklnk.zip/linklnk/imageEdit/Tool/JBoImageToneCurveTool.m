//
//  JBoImageToneCurveTool.m
//  靓咖
//
//  Created by kinghe005 on 14-5-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageToneCurveTool.h"

#pragma mark- 曲线图

@protocol JBoToneCurveGridDelegate;

@interface JBoToneCurveView : UIView

@property (nonatomic, assign) id<JBoToneCurveGridDelegate> delegate;
@property (nonatomic, retain) UIColor *gridColor;
@property (nonatomic, retain) UIColor *pointColor;
@property (nonatomic, retain) UIColor *lineColor;
@property (nonatomic, assign) BOOL continuous;

@property (nonatomic, readonly) CIVector *point0;
@property (nonatomic, readonly) CIVector *point1;
@property (nonatomic, readonly) CIVector *point2;
@property (nonatomic, readonly) CIVector *point3;
@property (nonatomic, readonly) CIVector *point4;

- (id)initWithSuperview:(UIView*)superview frame:(CGRect)frame;
- (void)resetPoints;

@end

@protocol JBoToneCurveGridDelegate <NSObject>

- (void)toneCurveDidChange:(JBoToneCurveView*) view;

@end

#pragma mark- 曲线

@interface JBoSplineInterpolator : NSObject

- (id)initWithPoints:(NSArray*)points;          // points: array of CIVector
- (CIVector*)interpolatedPoint:(CGFloat)t;      // {t | 0 ≤ t ≤ 1}

@end

@interface JBoSplineCalculator : NSObject

- (id)initWithData:(double*)points dataNum:(NSInteger)dataNum;
- (CGFloat)getValue:(CGFloat)t;

@end

#pragma mark- toneCurveTool

@interface JBoImageToneCurveTool ()<JBoToneCurveGridDelegate>

//缩略图
@property(nonatomic,retain) UIImage *thumbnail;
//曲线图
@property(nonatomic,retain) JBoToneCurveView *toneCurveView;
//滤镜
@property(nonatomic,retain) CIContext *context;

@property(nonatomic,assign) UIButton *upDownButton;

@end


@implementation JBoImageToneCurveTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_thumbnail release];
    [_toneCurveView release];
    [_context release];
    
    [super dealloc];
}

#pragma mark- super method

- (void)initilization
{
    [self.imageEditor.scrollView setZoomScale:self.imageEditor.scrollView.minimumZoomScale];
    self.thumbnail = [self.originalImage resize:self.imageEditor.editImageView.frame.size];
    self.imageEditor.editImageView.image = self.thumbnail;
    
    CGFloat menuContainerHeight = 280.0;
    self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, _height_, self.menuContainer.width, menuContainerHeight);
    self.menuContainer.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.5];
    
    UISwipeGestureRecognizer *upSwipGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(pushedHide:)];
    upSwipGesture.direction = UISwipeGestureRecognizerDirectionUp;
    [self.menuContainer addGestureRecognizer:upSwipGesture];
    [upSwipGesture release];
    
    UISwipeGestureRecognizer *downSwipGesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(pushedHide:)];
    downSwipGesture.direction = UISwipeGestureRecognizerDirectionDown;
    [self.menuContainer addGestureRecognizer:downSwipGesture];
    [downSwipGesture release];
    
    //曲线图
    JBoToneCurveView *tonecurveView = [[JBoToneCurveView alloc] initWithSuperview:self.menuContainer frame:CGRectMake(10, 20, 240, 240)];
    tonecurveView.delegate = self;
    tonecurveView.backgroundColor = [UIColor clearColor];
    tonecurveView.gridColor  = [UIColor colorWithWhite:0 alpha:0.2];
    tonecurveView.pointColor = _navigationBarBackgroundDefaultColor_;
    tonecurveView.lineColor  = _navigationBarBackgroundDefaultColor_;
    tonecurveView.continuous = NO;
    self.toneCurveView = tonecurveView;
    [tonecurveView release];
    
    //曲线图
    UIButton *icon = [UIButton buttonWithType:UIButtonTypeCustom];
    [icon setImage:[UIImage imageNamed:@"imageEditor_color"] forState:UIControlStateNormal];
    [icon setShowsTouchWhenHighlighted:YES];
    [icon addTarget:self action:@selector(touchHidden:) forControlEvents:UIControlEventTouchUpInside];
    icon.frame = CGRectMake(tonecurveView.right + 20, 15, 30, 30);
    [self.menuContainer addSubview:icon];
    
    //曲线图刷新
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(tonecurveView.right + 20, tonecurveView.bottom - 30, 30, 30);
    [btn addTarget:self action:@selector(pushedResetBtn:) forControlEvents:UIControlEventTouchUpInside];
    [btn setImage:[UIImage imageNamed:@"web_refresh"] forState:UIControlStateNormal];
    [btn setShowsTouchWhenHighlighted:YES];
    [self.menuContainer addSubview:btn];
}

- (void)beginEdit
{
    [UIView animateWithDuration:0.25 animations:^(void){
       
        self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, self.imageEditor.view.height - self.menuContainer.height, self.menuContainer.width, self.menuContainer.height);
    }];
}

- (void)endEdit
{
    [super endEdit];
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        [self pushedHide:nil];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            UIImage *image = [self filteredImage:self.originalImage];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.delegate imageEditTool:self editType:JBoImageEditTypeToneCurve didFinishEditWithImage:image];
            });
        });
    }
}

#pragma mark- JBoToneCurveGridDelegate

- (void)toneCurveDidChange:(JBoToneCurveView *)view
{
    static BOOL inProgress = NO;
    if(inProgress)
        return;
    inProgress = YES;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        UIImage *image = [self filteredImage:self.thumbnail];
        [self.imageEditor.editImageView performSelectorOnMainThread:@selector(setImage:) withObject:image waitUntilDone:NO];
        inProgress = NO;
    });
}

#pragma mark- private method

//过滤图片
- (UIImage*)filteredImage:(UIImage*)image
{
    CIImage *ciImage = [[CIImage alloc] initWithImage:image];
    CIFilter *filter = [CIFilter filterWithName:@"CIToneCurve" keysAndValues:kCIInputImageKey, ciImage, nil];
    
    [filter setDefaults];
    [filter setValue:_toneCurveView.point0 forKey:@"inputPoint0"];
    [filter setValue:_toneCurveView.point1 forKey:@"inputPoint1"];
    [filter setValue:_toneCurveView.point2 forKey:@"inputPoint2"];
    [filter setValue:_toneCurveView.point3 forKey:@"inputPoint3"];
    [filter setValue:_toneCurveView.point4 forKey:@"inputPoint4"];
    
    if(!self.context)
    {
        self.context = [CIContext contextWithOptions:nil];
    }
    CIImage *outputImage = [filter outputImage];
    CGImageRef cgImage = [self.context createCGImage:outputImage fromRect:[outputImage extent]];
    
    UIImage *result = [UIImage imageWithCGImage:cgImage scale:1.0 orientation:image.imageOrientation];
    
    CGImageRelease(cgImage);
    [ciImage release];
    
    return result;
}

- (void)pushedHide:(UISwipeGestureRecognizer*) swipe
{
    [UIView animateWithDuration:0.25 animations:^(void){
        if(swipe.direction == UISwipeGestureRecognizerDirectionDown || swipe == nil)
        {
            self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, self.imageEditor.memuOringinalY + 20.0, self.menuContainer.width, self.menuContainer.height);
            self.toneCurveView.userInteractionEnabled = NO;
        }
        else
        {
            self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, self.imageEditor.view.height - self.menuContainer.height, self.menuContainer.width, self.menuContainer.height);
            self.toneCurveView.userInteractionEnabled = YES;
        }
    }];
}

- (void)touchHidden:(UIButton*) button
{
    button.enabled = NO;
    CGFloat y = 0;
    if(self.menuContainer.frame.origin.y != self.imageEditor.view.height - self.menuContainer.height)
    {
        y = self.imageEditor.view.height - self.menuContainer.height;
        self.toneCurveView.userInteractionEnabled = YES;
    }
    else
    {
        y = self.imageEditor.memuOringinalY + 20.0;
        self.toneCurveView.userInteractionEnabled = NO;
    }
    
    [UIView animateWithDuration:0.25 animations:^(void){
        
        self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, y, self.menuContainer.width, self.menuContainer.height);
    }completion:^(BOOL finish){
        
        button.enabled = YES;
    }];
}

- (void)pushedResetBtn:(UIButton*) button
{
    [self.toneCurveView resetPoints];
    
    CABasicAnimation* rotation;
    rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotation.toValue  = [NSNumber numberWithFloat:-M_PI * 2.0];
    rotation.duration = 0.25;
    rotation.cumulative = YES;
    rotation.repeatCount = 1;
    rotation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
    [button.layer addAnimation:rotation forKey:@"rotationAnimation"];
}


@end

#pragma mark- UI components

//曲线控制点
@interface JBoControlPoint : UIView

@property (nonatomic, retain) CIVector *controlPoint;
@property (nonatomic, retain) UIColor *bgColor;
@property (nonatomic, assign) CGRect layoutFrame;

@end

@implementation JBoControlPoint

- (void)dealloc
{
    [_bgColor release];
    [_controlPoint release];
    
    [super dealloc];
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGRect rct = self.bounds;
    rct.origin.x = rct.size.width / 2 - rct.size.width / 6;
    rct.origin.y = rct.size.height / 2 - rct.size.height / 6;
    rct.size.width /= 3;
    rct.size.height /= 3;
    
    CGContextSetFillColorWithColor(context, self.bgColor.CGColor);
    CGContextFillEllipseInRect(context, rct);
}

- (void)setControlPoint:(CIVector *)controlPoint
{
    if(controlPoint != _controlPoint)
    {
        [_controlPoint release];
        _controlPoint = [controlPoint retain];
        self.center = CGPointMake(_controlPoint.X * self.layoutFrame.size.width + self.layoutFrame.origin.x, (1 - _controlPoint.Y) * self.layoutFrame.size.height + self.layoutFrame.origin.y);
    }
}

- (void)setBgColor:(UIColor *)bgColor
{
    if(![_bgColor isEqual:bgColor])
    {
        [_bgColor release];
        _bgColor = [bgColor retain];
        [self setNeedsDisplay];
    }
}

@end

#pragma mark- 曲线图

//曲线图
@interface JBoToneCurveView ()

@property(nonatomic,retain) NSMutableArray *controlPoints;

@end

@implementation JBoToneCurveView

- (id)initWithSuperview:(UIView *)superview frame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        [superview addSubview:self];
        
        NSMutableArray *tmp = [NSMutableArray array];
        for(NSInteger i = 0; i < 5; ++i)
        {
            [tmp addObject:[self controlPoint]];
        }
        self.controlPoints = tmp;
        
        [self resetPoints];
    }
    return self;
}

#pragma mark- 内存管理

- (void)dealloc
{
    [_gridColor release];
    [_pointColor release];
    [_lineColor release];
    
    [_controlPoints release];
    
    [super dealloc];
}

#pragma mark- private method

//创建曲线控制点
- (JBoControlPoint*)controlPoint
{
    JBoControlPoint *view = [[JBoControlPoint alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    view.backgroundColor = [UIColor clearColor];
    view.layoutFrame = self.frame;
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panControlPoint:)];
    pan.maximumNumberOfTouches = 1;
    [view addGestureRecognizer:pan];
    [pan release];
    
    [self.superview addSubview:view];
    
    return [view autorelease];
}

//重设曲线坐标
- (void)resetPoints
{
    for(NSInteger i = 0; i < _controlPoints.count; ++i)
    {
        CGFloat x = i/(CGFloat)(_controlPoints.count-1);
        JBoControlPoint *point = _controlPoints[i];
        point.controlPoint = [CIVector vectorWithCGPoint:CGPointMake(x, x)];
    }
    
    [self setNeedsDisplay];
    [self.delegate toneCurveDidChange:self];
}

- (void)setPointColor:(UIColor *)pointColor
{
    if(_pointColor != pointColor)
    {
        [_pointColor release];
        _pointColor = [pointColor retain];
        for(JBoControlPoint *view in _controlPoints)
        {
            view.bgColor = _pointColor;
        }
    }
}

- (void)setUserInteractionEnabled:(BOOL)userInteractionEnabled
{
    [super setUserInteractionEnabled:userInteractionEnabled];
    for(JBoControlPoint *view in _controlPoints)
    {
        view.userInteractionEnabled = userInteractionEnabled;
    }
}

- (CIVector*)point0
{
    return [_controlPoints[0] controlPoint];
}

- (CIVector*)point1
{
    return [_controlPoints[1] controlPoint];
}

- (CIVector*)point2
{
    return [_controlPoints[2] controlPoint];
}

- (CIVector*)point3
{
    return [_controlPoints[3] controlPoint];
}

- (CIVector*)point4
{
    return [_controlPoints[4] controlPoint];
}

- (void)setControlPoint:(CGPoint)point atIndex:(NSInteger)index
{
    if(index >= 0 && index < _controlPoints.count)
    {
        JBoControlPoint *prev = (index == 0) ? nil : _controlPoints[index - 1];
        JBoControlPoint *target = _controlPoints[index];
        JBoControlPoint *next = (index + 1 < _controlPoints.count) ? _controlPoints[index + 1] : nil;
        
        CGFloat left_limit  = (prev == nil) ? 0 : prev.controlPoint.X + 0.05;
        CGFloat right_limit = (next == nil) ? 1 : next.controlPoint.X - 0.05;
        
        point.x = MAX(left_limit, MIN(point.x, right_limit));
        point.y = MAX(0, MIN(1 - point.y, 1));
        
        target.controlPoint = [CIVector vectorWithCGPoint:point];
    }
}

- (CGPoint)convertControlPointToViewPoint:(CIVector*)controlPoint
{
    CGFloat X = MAX(0, MIN(controlPoint.X, 1));
    CGFloat Y = MAX(0, MIN(controlPoint.Y, 1));
    return CGPointMake(X * self.frame.size.width, (1 - Y) * self.frame.size.height);
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGRect rct = self.bounds;
    rct.origin.x += 1;
    rct.origin.y += 1;
    rct.size.width  -= 2;
    rct.size.height -= 2;
    
    // Draw grid
    
    CGContextSetStrokeColorWithColor(context, self.gridColor.CGColor);
    CGContextSetLineWidth(context, 1);
    
    CGContextBeginPath(context);
    CGFloat dW = 0;
    for(int i = 0;i < 5;++i)
    {
        CGContextMoveToPoint(context, rct.origin.x + dW, rct.origin.y);
        CGContextAddLineToPoint(context, rct.origin.x+dW, rct.origin.y + rct.size.height);
        dW += rct.size.width / 4;
    }
    
    dW = 0;
    for(int i=0;i<5;++i)
    {
        CGContextMoveToPoint(context, rct.origin.x, rct.origin.y + dW);
        CGContextAddLineToPoint(context, rct.origin.x + rct.size.width, rct.origin.y + dW);
        dW += rct.size.height / 4;
    }
    CGContextStrokePath(context);
    
    // Draw spline curve: It would be different from the actual curve.
    
    NSMutableArray *points = [NSMutableArray array];
    for(JBoControlPoint *view in _controlPoints)
    {
        [points addObject:view.controlPoint];
    }
    
    JBoSplineInterpolator *spline = [[JBoSplineInterpolator alloc] initWithPoints:points];
    
    UIBezierPath *curve = [UIBezierPath bezierPath];
    CGContextSetStrokeColorWithColor(context, self.lineColor.CGColor);
    [curve setLineWidth:1.0];
    
    const NSInteger L = 100;
    
    [curve moveToPoint:[self convertControlPointToViewPoint:[CIVector vectorWithCGPoint:CGPointMake(0, self.point0.Y)]]];
    
    for(NSInteger i = 0; i < L; ++i)
    {
        double t = i / (double)(L-1);
        CIVector *point = [spline interpolatedPoint:t];
        [curve addLineToPoint:[self convertControlPointToViewPoint:point]];
    }
    
    [curve addLineToPoint:[self convertControlPointToViewPoint:[CIVector vectorWithCGPoint:CGPointMake(1, self.point4.Y)]]];
    [curve stroke];
    
    
    [spline release];
}

- (void)panControlPoint:(UIPanGestureRecognizer*)sender
{
    static CGPoint initialPoint;
    if(sender.state == UIGestureRecognizerStateBegan){
        initialPoint = [sender locationInView:self];
    }
    
    CGPoint point = [sender translationInView:self];
    NSInteger index = [_controlPoints indexOfObject:sender.view];
    
    point.x = (initialPoint.x + point.x) / self.width;
    point.y = (initialPoint.y + point.y) / self.height;
    
    [self setControlPoint:point atIndex:index];
    
    [self setNeedsDisplay];
    if(self.continuous ||  sender.state == UIGestureRecognizerStateEnded)
    {
        [self.delegate toneCurveDidChange:self];
    }
}

@end

#pragma mark- 曲线

@implementation JBoSplineInterpolator
{
    NSInteger _pointNum;
    
    JBoSplineCalculator *_splineX;
    JBoSplineCalculator *_splineY;
}

- (id)initWithPoints:(NSArray *)points
{
    self = [super init];
    if(self)
    {
        _pointNum = points.count;
        
        double *dataX = malloc(sizeof(double) * _pointNum);
        double *dataY = malloc(sizeof(double) * _pointNum);
        
        for(NSInteger i = 0; i < _pointNum; ++i)
        {
            CIVector *point = points[i];
            dataX[i] = point.X;
            dataY[i] = point.Y;
        }
        
        _splineX = [[JBoSplineCalculator alloc] initWithData:dataX dataNum:_pointNum];
        _splineY = [[JBoSplineCalculator alloc] initWithData:dataY dataNum:_pointNum];
        
        free(dataX);
        free(dataY);
    }
    return self;
}

- (void)dealloc
{
    [_splineX release];
    [_splineY release];
    
    [super dealloc];
}

- (CIVector*)interpolatedPoint:(CGFloat)t
{
    t = MAX(0, MIN(t, 1));
    t = t * (_pointNum - 1);
    
    return [CIVector vectorWithX:[_splineX getValue:t] Y:[_splineY getValue:t]];
}

@end

#pragma mark- CLSplineCalculator

@implementation JBoSplineCalculator
{
    NSInteger _dataNum;
    double *a, *b, *c, *d;
}

- (id)initWithData:(double*)data dataNum:(NSInteger)dataNum
{
    self = [super init];
    if(self){
        
        _dataNum = dataNum;
        if(_dataNum > 0)
        {
            a = malloc(dataNum * sizeof(double));
            b = malloc(dataNum * sizeof(double));
            c = malloc(dataNum * sizeof(double));
            d = malloc(dataNum * sizeof(double));
            
            for(NSInteger i = 0; i < dataNum; ++i)
            {
                a[i] = data[i];
            }
            
            c[0] = c[dataNum - 1] = 0.0;
            for(NSInteger i = 1; i < dataNum-1; ++i)
            {
                c[i] = 3.0 * (a[i - 1] - 2.0 * a[i] + a[i + 1]);
            }
            
            double *w = malloc(dataNum * sizeof(double));
            w[0] = 0.0;
            for(NSInteger i=1; i<dataNum-1; ++i)
            {
                double tmp = 4.0 - w[i - 1];
                c[i] = (c[i] - c[i - 1]) / tmp;
                w[i] = 1.0 / tmp;
            }
            
            for(NSInteger i = dataNum - 2; i > 0; --i)
            {
                c[i] = c[i] - c[i + 1] * w[i];
            }
            
            b[dataNum - 1] = d[dataNum - 1] = 0.0;
            for(NSInteger i = 0; i < dataNum - 1; ++i)
            {
                d[i] = (c[i + 1] - c[i]) / 3.0;
                b[i] = a[i + 1] - a[i] - c[i] - d[i];
            }
            
            free(w);
        }
    }
    return self;
}

- (void)dealloc
{
    free(a);
    free(b);
    free(c);
    free(d);
    [super dealloc];
}

- (CGFloat)getValue:(CGFloat)t
{
    NSInteger j = (NSInteger)floor(t);
    if(j < 0)
    {
        j=0;
    }
    else if(j >= _dataNum-1)
    {
        j = _dataNum-2;
    }
    
    double dt = t - j;
    return a[j] + ( b[j] + (c[j] + d[j] * dt) * dt ) * dt;
}

@end
