//
//  JBoImageTextInputTool.m
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageTextInputTool.h"
#import "JBoCustomToolBar.h"
#import "JBoColorPicker.h"
#import "JBoInputTextCell.h"
#import "JBoImageTextTool.h"
#import "JBoRGBAInputView.h"

#define _cellDefaultHeight_ 60.0

#define _adjustZoomScale_ 0.95

#define _toolBarScale_ 3 / 8
#define _bottomHeight_ 40.0
#define _fontItemStartTag_ 1000

//文字输入框
#define _bubbleItemStartTag_ 100

//文字输入框添加按钮
#define _bubbleItemAddTag_ 200

//文字输入框最大数量
#define _bubbleItemMaxCount_ 5


typedef enum _JBoImageTextInputMenuItemStyle
{
    JBoImageTextInputMenuItemStyleText = 0, //文本
    JBoImageTextInputMenuItemStyleAdd = 2, //添加按钮
}JBoImageTextInputMenuItemStyle;

//选择框
@interface JBoImageTextInputMenuItem : UIView

/**选中的指示下划线高度
 */
@property(nonatomic,readonly) CGFloat indicatorSize;

/**选中的指示下划线颜色
 */
@property(nonatomic,readonly) UIView *selectedIndicator;
/**是否选中
 */
@property(nonatomic,assign) BOOL selected;

/**是否为添加
 */
@property(nonatomic,assign) BOOL add;

/**标题
 */
@property(nonatomic,readonly) UILabel *textLabel;

/**已菜单类型创建菜单按钮
 */
- (id)initWithFrame:(CGRect)frame style:(JBoImageTextInputMenuItemStyle) style;

@end

@implementation JBoImageTextInputMenuItem

- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame style:JBoImageTextInputMenuItemStyleText];
}

- (id)initWithFrame:(CGRect)frame style:(JBoImageTextInputMenuItemStyle)style
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        _indicatorSize = 2.0;
        
        switch (style)
        {
            case JBoImageTextInputMenuItemStyleText :
            {
                _textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5.0, frame.size.width, frame.size.height - 5.0)];
                _textLabel.backgroundColor = [UIColor clearColor];
                _textLabel.textColor = [UIColor whiteColor];
                _textLabel.font = [UIFont systemFontOfSize:14.0];
                [_textLabel setTextAlign:JBoTextAlignmentCenter];
                [self addSubview:_textLabel];
            }
                break;
            case JBoImageTextInputMenuItemStyleAdd :
            {
                self.add = YES;
            }
                break;
            default:
                break;
        }
    }
    
    return self;
}

- (void)setAdd:(BOOL)add
{
    if(_add != add)
    {
        _add = add;
        [self setNeedsDisplay];
    }
}

/**是否选中
 */
- (void)setSelected:(BOOL)selected
{
    _selected = selected;
    if(!_selectedIndicator)
    {
        CGFloat height = _indicatorSize;
        _selectedIndicator = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - height, self.frame.size.width, height)];
        _selectedIndicator.backgroundColor = _navigationBarBackgroundDefaultColor_;
        [self addSubview:_selectedIndicator];
    }
    
    _selectedIndicator.hidden = !_selected;
}

- (void)dealloc
{
    [_selectedIndicator release];
    [_textLabel release];
    
    [super dealloc];
}

- (void)drawRect:(CGRect)rect
{
    if(self.add)
    {
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        //设置线条颜色和宽度
        UIColor *color = [UIColor whiteColor];
        CGContextSetStrokeColorWithColor(context, color.CGColor);
        CGContextSetLineWidth(context, 2.0);
        CGContextSetLineCap(context, kCGLineCapRound);
        CGContextSetLineJoin(context, kCGLineJoinRound);
        
        CGFloat width = rect.size.height - 25.0;
        
        //绘制横线
        CGPoint point = CGPointMake((rect.size.width - width) / 2.0, rect.size.height / 2.0);
        CGContextMoveToPoint(context, point.x, point.y);
        CGContextAddLineToPoint(context, point.x + width, point.y);
        
        //绘制竖线
        point = CGPointMake(rect.size.width / 2.0, (rect.size.height - width) / 2.0);
        CGContextMoveToPoint(context, point.x, point.y);
        CGContextAddLineToPoint(context, point.x, point.y + width);
        
        //把线条都绘制出来 必须的
        CGContextStrokePath(context);
    }
}

@end

@interface JBoImageTextInputTool ()<JBoCustomToolBarDelegate,JBoInputTextCellDelegate,UITextFieldDelegate,JBoRGBAInputViewDelegate>

//文字样式
@property(nonatomic,retain) UIView *textStyleView;

//字体
@property(nonatomic,retain) UIScrollView *textFontScrollView;
@property(nonatomic,retain) NSArray *fontNameArray;
@property(nonatomic,assign) NSInteger selectedFontIndex;

//当前选择的字体
@property(nonatomic,retain) UIFont *selectedFont;

//字体大小
@property(nonatomic,retain) UISlider *fontSizeSlider;

//显示字体大小
@property(nonatomic,retain) UILabel *fontSizeLabel;

//当前选择的字体大小
@property(nonatomic,assign) float fontSize;

//文字输入框选项
@property(nonatomic,retain) UIScrollView *textBubbleScrollView;

//已创建的文字输入框 数组元素是 JBoInputTextCell对象
@property(nonatomic,retain) NSMutableArray *bubbleCells;

//选中的文字输入框
@property(nonatomic,assign) NSInteger selectedBubbleIndex;

//选择器
@property(nonatomic,retain) JBoCustomToolBar *toolBar;

//颜色选择器
@property(nonatomic,retain) JBoColorPicker *colorPicker;

//键盘
@property(nonatomic,assign) BOOL keyboardHidden;

//文字输入
@property(nonatomic,retain) UIView *textInputBroundgroudView;
@property(nonatomic,retain) UITextField *textField;
@property(nonatomic,retain) UIView *overlayView;

//背景视图
@property(nonatomic,retain) UIView *backgroundView;


//scrollView 原始缩放比例
@property (nonatomic, assign) CGFloat maximumZoomScale;
@property (nonatomic, assign) CGFloat minimumZoomScale;

//颜色rgb显示输入视图
@property(nonatomic,retain) JBoRGBAInputView *inputView;

@end

@implementation JBoImageTextInputTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_textStyleView release];
    
    [_textFontScrollView release];
    [_fontNameArray release];
    [_selectedFont release];
    
    [_fontSizeSlider release];
    
    [_textBubbleScrollView release];
    [_bubbleCells release];
    
    [_toolBar release];
    
    [_colorPicker release];
    
    [_textInputBroundgroudView release];
    [_textField release];
    [_overlayView release];
    
    [_backgroundView release];
    [_inputView release];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillChangeFrameNotification object:nil];
    
    [super dealloc];
}

#pragma mark- 键盘

- (void)keyboardWillAppearance:(NSNotification*) notification
{
    if([self.textField isFirstResponder])
    {
        self.keyboardHidden = NO;
        [self.imageEditor.view insertSubview:self.overlayView belowSubview:self.textInputBroundgroudView];
        [self setupTableViewFrameWithUserInfo:[notification userInfo]];
    }
}

- (void)keyboardWillDisAppearance:(NSNotification*) notification
{
    if([self.textField isFirstResponder])
    {
        self.keyboardHidden = YES;
        [self setupTableViewFrameWithUserInfo:[notification userInfo]];
    }
}

- (void)keyboardFrameWillChanged:(NSNotification*) notification
{
    if([self.textField isFirstResponder])
    {
        [self setupTableViewFrameWithUserInfo:[notification userInfo]];
    }
}

- (void)setupTableViewFrameWithUserInfo:(NSDictionary*) userInfo
{
    //获取键盘高度
    NSValue *keyboardValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGRect keyboardRect = [keyboardValue CGRectValue];
    
    //获取键盘动画时间
    NSNumber *animateDurationNumber = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    float animationDuration = [animateDurationNumber floatValue];
    CGFloat height = keyboardRect.size.height;
    
    if(self.keyboardHidden)
        height = 0;
    [UIView animateWithDuration:animationDuration animations:^(void)
     {
         self.textInputBroundgroudView.frame = CGRectMake(0, _height_  - _bottomHeight_ - height - _navgateBarHeight_, _width_, _bottomHeight_);
     }completion:^(BOOL finish)
     {
         self.textInputBroundgroudView.hidden = self.keyboardHidden;
         if(self.keyboardHidden)
         {
             [self.overlayView removeFromSuperview];
         }
     }];
}

#pragma mark- super method

- (void)initilization
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppearance:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillDisAppearance:) name:UIKeyboardWillHideNotification object:nil];
    //添加键盘frame改变通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardFrameWillChanged:) name:UIKeyboardWillChangeFrameNotification object:nil];
    
    //初始化字体
    self.fontSize = 17.0;
    self.selectedFont = [UIFont systemFontOfSize:17.0];
    
    //禁止缩放
    self.minimumZoomScale = self.imageEditor.scrollView.minimumZoomScale;
    self.maximumZoomScale = self.imageEditor.scrollView.maximumZoomScale;
    
    self.imageEditor.scrollView.minimumZoomScale = 1.0;
    self.imageEditor.scrollView.maximumZoomScale = 1.0;
    
    [self.imageEditor.scrollView setZoomScale:1.0 animated:NO];
    self.imageEditor.scrollView.delaysContentTouches = NO;
    self.imageEditor.scrollView.canCancelContentTouches = NO;
    
    CGFloat toolBarHeight = self.menuContainer.bounds.size.height * _toolBarScale_;
    JBoCustomToolBar *toolBar = [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, (self.menuContainer.bounds.size.height - toolBarHeight), self.menuContainer.bounds.size.width, toolBarHeight) items:[NSArray arrayWithObjects:[JBoCustomToolBarItem toolBarItemWithTitle:@"输入框" image:nil],  [JBoCustomToolBarItem toolBarItemWithTitle:@"英文字体" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"文字颜色" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"字体大小" image:nil], nil]];
    toolBar.titleSelectedColor = _navigationBarBackgroundDefaultColor_;
    toolBar.delegate = self;
    toolBar.titleFont = [UIFont boldSystemFontOfSize:13.0];
    [self.menuContainer addSubview:toolBar];
    self.toolBar = toolBar;
    [toolBar release];
    
    self.toolBar.selectedIndex = 0;
    
    
    //初始化文字输入框
    [self initlizationBubbleItems];
    
    //背景颜色
    CGFloat padding = _width_ * (1.0 - _adjustZoomScale_);
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(self.imageEditor.editImageView.left - padding, self.imageEditor.editImageView.top - padding, self.imageEditor.editImageView.width + padding * 2, self.imageEditor.editImageView.height + padding * 2)];
    view.backgroundColor = [UIColor clearColor];
    [self.imageEditor.scrollView addSubview:view];
    self.backgroundView = view;
    [view release];
    
    JBoRGBAInputView *inputView = [[JBoRGBAInputView alloc] initWithFrame:CGRectMake(padding, padding, _RGBAInputViewDefaultWidth_, 0)];
    inputView.delegate = self;
    inputView.hidden = YES;
    [self.imageEditor.scrollView addSubview:inputView];
    self.inputView = inputView;
    [inputView release];
}

//结束编辑
- (void)endEdit
{
    [self.textField resignFirstResponder];
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        //把视图重 backgroundView中 移到 编辑图片上
        self.inputView.hidden = YES;
        
        CGFloat padding = (1.0 - _adjustZoomScale_) * _width_;
        
        for(JBoInputTextCell *cell in self.bubbleCells)
        {
            cell.selected = NO;
            [cell removeFromSuperview];
            [self.imageEditor.editImageView addSubview:cell];
            
            cell.center = CGPointMake(cell.center.x - padding, cell.center.y - padding);
        }
        
        
        [super endEdit];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
            UIImage *image = [self getComponentImageWithType:JBoImageEditTypeTextInput];
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [self.delegate imageEditTool:self editType:JBoImageEditTypeTextInput didFinishEditWithImage:image];
            });
        });
    }
}

- (void)close
{
    [self.textField resignFirstResponder];
    self.imageEditor.scrollView.minimumZoomScale = self.minimumZoomScale;
    self.imageEditor.scrollView.maximumZoomScale = self.maximumZoomScale;
    self.imageEditor.scrollView.delaysContentTouches = YES;
    self.imageEditor.scrollView.canCancelContentTouches = YES;
    
    for(JBoInputTextCell *cell in self.bubbleCells)
    {
        [cell removeFromSuperview];
    }
    
    [self.backgroundView removeFromSuperview];
    [self.inputView removeFromSuperview];
    [super close];
}

#pragma mark- JBoCustomToolBar代理

- (void)toolBar:(JBoCustomToolBar *)toolBar didSelectedAtIndex:(NSInteger)index
{
    self.inputView.hidden = YES;
    switch (index)
    {
        case 0 :
        {
            self.textFontScrollView.hidden = YES;
            self.textStyleView.hidden = YES;
            self.textBubbleScrollView.hidden = NO;
            self.fontSizeSlider.hidden = YES;
            self.fontSizeLabel.hidden = YES;
        }
            break;
        case 1 :
        {
            if(!self.textFontScrollView)
            {
                UIScrollView *textFontScrollView = [[UIScrollView alloc] initWithFrame:self.textBubbleScrollView.frame];
                textFontScrollView.showsVerticalScrollIndicator = NO;
                textFontScrollView.showsVerticalScrollIndicator = NO;
                textFontScrollView.backgroundColor = self.textBubbleScrollView.backgroundColor;
                [self.menuContainer addSubview:textFontScrollView];
                self.textFontScrollView = textFontScrollView;
                [textFontScrollView release];
                
                [self createFontItems];
            }
            self.textFontScrollView.hidden = NO;
            self.textStyleView.hidden = YES;
            self.textBubbleScrollView.hidden = YES;
            self.fontSizeSlider.hidden = YES;
            self.fontSizeLabel.hidden = YES;
        }
            break;
        case 2 :
        {
            if(!self.textStyleView)
            {
                UIView *view = [[UIView alloc] initWithFrame:self.textBubbleScrollView.frame];
                view.backgroundColor = self.textBubbleScrollView.backgroundColor;
                [self.menuContainer addSubview:view];
                self.textStyleView = view;
                [view release];
                
                JBoColorPicker *colorPicker = [[JBoColorPicker alloc] initWithFrame:CGRectMake((view.frame.size.width - _colorPickerDefaultWidth_) / 2, (view.frame.size.height - _colorPickerDefaultHeight_) / 2, _colorPickerDefaultWidth_, _colorPickerDefaultHeight_)];
                colorPicker.colorAlpha = 1.0;
                [colorPicker addTarget:self action:@selector(colorValueDidChanged:) forControlEvents:UIControlEventValueChanged];
                [view addSubview:colorPicker];
                self.colorPicker = colorPicker;
                [colorPicker release];

            }
            
            self.inputView.hidden = NO;
            self.inputView.currentColor = self.colorPicker.selectedColor;
            
            self.textFontScrollView.hidden = YES;
            self.textStyleView.hidden = NO;
            self.textBubbleScrollView.hidden = YES;
            self.fontSizeSlider.hidden = YES;
            self.fontSizeLabel.hidden = YES;
        }
            break;
        case 3 :
        {
            if(!self.fontSizeSlider)
            {
                CGFloat width = 250.0;
                CGFloat height = _colorPickerDefaultHeight_;
                UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake((self.menuContainer.width - width) / 2.0, 13.0, width, height)];
                [slider addTarget:self action:@selector(fontSizeDidSelected:) forControlEvents:UIControlEventValueChanged];
                slider.minimumValue = 1.0;
                slider.maximumValue = 100.0;
                slider.minimumTrackTintColor = _navigationBarBackgroundDefaultColor_;
                slider.value = 20.0;
                [self.menuContainer addSubview:slider];
                self.fontSizeSlider = slider;
                [slider release];
                
                UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(slider.left, 0, width, 20.0)];
                label.backgroundColor = [UIColor clearColor];
                label.textColor = [UIColor whiteColor];
                label.font = [UIFont systemFontOfSize:15.0];
                label.text = [NSString stringWithFormat:@"%d",(int)slider.value];
                [self.menuContainer addSubview:label];
                self.fontSizeLabel = label;
                [label release];
            }
            
            self.textFontScrollView.hidden = YES;
            self.textStyleView.hidden = YES;
            self.textBubbleScrollView.hidden = YES;
            self.fontSizeSlider.hidden = NO;
            self.fontSizeLabel.hidden = NO;
        }
            break;
        default:
            break;
    }
}

#pragma mark- private method

#pragma mark- 字体颜色

//颜色选择
- (void)colorValueDidChanged:(JBoColorPicker*) picker
{
    self.inputView.currentColor = picker.selectedColor;
    if(self.selectedBubbleIndex < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:self.selectedBubbleIndex];
        cell.inputTextContentView.textLabel.textColor = picker.selectedColor;
    }
}

#pragma mark- 文字输入框

//初始化文字输入框选项
- (void)initlizationBubbleItems
{
    UIScrollView *textBubbleScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.bounds.size.width, self.menuContainer.bounds.size.height - self.toolBar.height)];
  
    textBubbleScrollView.backgroundColor = self.imageEditor.menuScrollView.backgroundColor;
    textBubbleScrollView.showsHorizontalScrollIndicator = NO;
    textBubbleScrollView.showsVerticalScrollIndicator = NO;
    [self.menuContainer addSubview:textBubbleScrollView];
    self.textBubbleScrollView = textBubbleScrollView;
    [textBubbleScrollView release];
    
    self.bubbleCells = [NSMutableArray array];
    CGFloat size = 48.0;
    
    //创建文字输入框添加按钮
    JBoImageTextInputMenuItem *item = [[JBoImageTextInputMenuItem alloc] initWithFrame:CGRectMake(0, 0, size, size) style:JBoImageTextInputMenuItemStyleAdd];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textBubbleDidAdd:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.tag = _bubbleItemAddTag_;
    [self.textBubbleScrollView addSubview:item];
    [item release];
    
    self.selectedBubbleIndex = NSNotFound;
    [self.textBubbleScrollView setContentSize:CGSizeMake(size * 1, self.textBubbleScrollView.bounds.size.height)];
}

//添加文字输入框
- (void)textBubbleDidAdd:(id) sender
{
    CGFloat interval = 5.0;
    
    JBoImageTextInputMenuItem *addItem = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemAddTag_];
    
    JBoImageTextInputMenuItem *item = [[JBoImageTextInputMenuItem alloc] initWithFrame:addItem.frame style:JBoImageTextInputMenuItemStyleText];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textBubbleDidselected:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.textLabel.text = @"点击输入";
    item.selected = YES;
    item.tag = _bubbleItemStartTag_ + self.bubbleCells.count;
    [self.textBubbleScrollView addSubview:item];
    [item release];
    
    addItem.left = item.right + interval;
    
    
    //添加文字输入框
    CGFloat cellSize = 120.0;
    
    JBoInputTextCell *cell = [[JBoInputTextCell alloc] initWithFrame:CGRectMake((self.backgroundView.width - cellSize) / 2.0, 30.0, cellSize, _cellDefaultHeight_) contentPadding:_width_ * (1.0 - _adjustZoomScale_)];
    cell.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    cell.preventsPositionOutsideSuperview = YES;
    cell.inputTextContentView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.0];
    cell.editable = YES;
    cell.inputTextContentView.textLabel.font = [UIFont systemFontOfSize:20.0];
    cell.inputTextContentView.textLabel.textColor = [UIColor blackColor];
    cell.inputTextContentView.hasText = NO;
    cell.index = self.bubbleCells.count;
    cell.userInteractionEnabled = YES;
    cell.delegate = self;
    [self.backgroundView addSubview:cell];
    cell.selected = YES;
    [cell release];
    
    [self.bubbleCells addObject:cell];
    
    NSInteger count = addItem.hidden ? self.bubbleCells.count : self.bubbleCells.count + 1;
    
    [self.textBubbleScrollView setContentSize:CGSizeMake(item.width * count, self.textBubbleScrollView.bounds.size.height)];
    
    [self setBubbleTextAtIndex:self.bubbleCells.count - 1];
    
    if(self.bubbleCells.count == _bubbleItemMaxCount_)
    {
        addItem.hidden = YES;
    }
    
    self.selectedBubbleIndex = self.bubbleCells.count - 1;
}

//移除文字输入框
- (void)removeTextBubbleAtIndex:(NSInteger) index
{
    CGFloat interval = 5.0;
    
    //从父视图中移除
    JBoImageTextInputMenuItem *item = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemStartTag_ + index];
    CGFloat x = item.left;
    
    //移动后面的item
    for(NSInteger i = index + 1;i < self.bubbleCells.count;i ++)
    {
        JBoImageTextInputMenuItem *backItem = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemStartTag_ + i];
        backItem.tag = _bubbleItemStartTag_ + i - 1;
        backItem.left = x;
        x = backItem.right + interval;
        
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:i];
        cell.index = i - 1;
    }
    
    
    
    JBoImageTextInputMenuItem *addItem = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemAddTag_];
    addItem.left = x;
    
    //如果添加按钮已隐藏 显示它
    addItem.hidden = NO;
    [self.textBubbleScrollView setContentSize:CGSizeMake(item.width * (self.bubbleCells.count + 1), self.textBubbleScrollView.bounds.size.height)];
    [item removeFromSuperview];
}

//选择文字输入框
- (void)setSelectedBubbleIndex:(NSInteger)selectedBubbleIndex
{
    //取消以前的选择
    if(_selectedBubbleIndex < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:_selectedBubbleIndex];
        cell.selected = NO;
    }
    
    JBoImageTextInputMenuItem *oldItem = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemStartTag_ + _selectedBubbleIndex];
    oldItem.selected = NO;
    
    //确定当前的选择
    _selectedBubbleIndex = selectedBubbleIndex;
    
    JBoImageTextInputMenuItem *curItem = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemStartTag_ + _selectedBubbleIndex];
    curItem.selected = YES;
    
    if(_selectedBubbleIndex < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:_selectedBubbleIndex];
        cell.selected = YES;
    }
}

//选择文字输入框
- (void)textBubbleDidselected:(UITapGestureRecognizer*) tap
{
    NSInteger index = tap.view.tag - _bubbleItemStartTag_;
    self.selectedBubbleIndex = index;
}

//前置文字输入框
- (void)setupBubblePositon
{
    for(JBoInputTextCell *cell in self.bubbleCells)
    {
        [self.backgroundView bringSubviewToFront:cell];
    }
}

//设置文本输入框选项的内容
- (void)setBubbleTextAtIndex:(NSInteger) index
{
    if(index < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:index];
        
        UILabel *label = cell.inputTextContentView.textLabel;
        
        NSInteger len = label.text.length >= 3 ? 3 : label.text.length;
        JBoImageTextInputMenuItem *item = (JBoImageTextInputMenuItem*)[self.textBubbleScrollView viewWithTag:_bubbleItemStartTag_ + index];
        item.textLabel.text = [label.text substringToIndex:len];
    }
}

#pragma mark- 字体

//字体
- (NSArray*)getFontNameArray
{
    return [NSArray arrayWithObjects:@"STHeitiSC-Light", @"Verdana-Bold",@"Zapfino", @"TimesNewRomanPS-BoldItalicMT", @"SnellRoundhand", @"SnellRoundhand-Black", @"Optima-ExtraBlack", @"Noteworthy-Bold", @"MarkerFelt-Thin", nil];
}

//创建字体选项
- (void)createFontItems
{
    self.fontNameArray = [self getFontNameArray];
    
    CGFloat width = 80.0;
    CGFloat height = self.textFontScrollView.bounds.size.height - 10.0;
    
    for(NSInteger i = 0;i < self.fontNameArray.count;i ++)
    {
        NSString *fontName = [self.fontNameArray objectAtIndex:i];
        
        JBoImageTextInputMenuItem *item = [[JBoImageTextInputMenuItem alloc] initWithFrame:CGRectMake(width * i, 0, width, height)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textFontDidSelected:)];
        [item addGestureRecognizer:tap];
        [tap release];
        item.tag = _fontItemStartTag_ + i;
        
        item.textLabel.text = @"linklnk";
        item.textLabel.font = [UIFont fontWithName:fontName size:17.0];
        item.textLabel.textColor = [UIColor whiteColor];
        
        [self.textFontScrollView addSubview:item];
        [item release];
    }
    
    [self.textFontScrollView setContentSize:CGSizeMake(width * self.fontNameArray.count, self.textFontScrollView.bounds.size.height)];
     self.selectedFontIndex = 0;
}

//选择字体
- (void)setSelectedFontIndex:(NSInteger)selectedFontIndex
{
    JBoImageTextInputMenuItem *oldItem = (JBoImageTextInputMenuItem*)[self.textFontScrollView viewWithTag:_selectedFontIndex + _fontItemStartTag_];
    oldItem.selected = NO;
    
    _selectedFontIndex = selectedFontIndex;
    JBoImageTextInputMenuItem *item = (JBoImageTextInputMenuItem*)[self.textFontScrollView viewWithTag:_selectedFontIndex + _fontItemStartTag_];
    item.selected = YES;
    
    NSString *fontName = [self.fontNameArray objectAtIndex:_selectedFontIndex];
    UIFont *font = [UIFont fontWithName:fontName size:self.fontSize];
    self.selectedFont = font;
}

- (void)textFontDidSelected:(UITapGestureRecognizer*) tap
{
    NSInteger index = tap.view.tag - _fontItemStartTag_;
    self.selectedFontIndex = index;
}

#pragma mark- 字体大小

//字体大小选择
- (void)fontSizeDidSelected:(UISlider*) slider
{
    self.fontSize = slider.value;
    self.fontSizeLabel.text = [NSString stringWithFormat:@"%d", (int)slider.value];
    
    if(self.selectedBubbleIndex < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:self.selectedBubbleIndex];
        NSString *fontName = cell.inputTextContentView.textLabel.font.fontName;
        UIFont *font = [UIFont fontWithName:fontName size:self.fontSize];
        cell.inputTextContentView.textLabel.font = font;
        self.selectedFont = font;
    }
}


#pragma mark- JBoRGBAInputView代理

- (void)RGBAInputView:(JBoRGBAInputView *)inputView colorDidChanged:(UIColor *)color
{
    switch (self.toolBar.selectedIndex)
    {
        case 2 :
        {
            [self.colorPicker setColor:color];
            [self colorValueDidChanged:self.colorPicker];
        }
            break;
        default:
            break;
    }
}
    

#pragma mark- Cell代理

- (void)cellDidBeganInputText:(JBoInputTextCell *)cell
{
    if(!self.textInputBroundgroudView)
    {
        UIView *overlayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cancelInputText:)];
        [overlayView addGestureRecognizer:tap];
        [tap release];
        overlayView.backgroundColor = [UIColor clearColor];
        self.overlayView = overlayView;
        [overlayView release];
        
        UIView *bgView = [[UIView alloc] initWithFrame:CGRectMake(0, _height_ - _bottomHeight_, _width_, _bottomHeight_)];
        bgView.backgroundColor = _mainBackgroundColor_;
        [self.imageEditor.view addSubview:bgView];
        self.textInputBroundgroudView = bgView;
        [bgView release];
        
        CGFloat interval = 5;
        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(interval, interval, _width_ - interval * 2, _bottomHeight_ - interval * 2)];
        textField.delegate = self;
        textField.returnKeyType = UIReturnKeyDone;
        textField.borderStyle = UITextBorderStyleRoundedRect;
        [textField addTarget:self action:@selector(textDidChange:) forControlEvents:UIControlEventEditingChanged];
        [bgView addSubview:textField];
        self.textField = textField;
        [textField release];
    }
    
    if(cell.inputTextContentView.hasText)
    {
        self.textField.text = cell.inputTextContentView.textLabel.text;
    }
    else
    {
        cell.inputTextContentView.textLabel.text = nil;
        self.textField.text = nil;
    }
    
    [self.textField becomeFirstResponder];
    
    self.selectedBubbleIndex = cell.index;
}


- (void)cancelInputText:(UITapGestureRecognizer*) tap
{
    [self.textField resignFirstResponder];
}

- (void)cellDidClose:(JBoImageEditBaseCell *)cell
{
    if([cell isKindOfClass:[JBoInputTextCell class]])
    {
        [self removeTextBubbleAtIndex:cell.index];
        [self.bubbleCells removeObject:cell];
        [cell removeFromSuperview];
        self.selectedBubbleIndex = NSNotFound;
    }
}

- (void)cellDidSelected:(JBoImageEditBaseCell *)cell
{
    if([cell isKindOfClass:[JBoInputTextCell class]])
    {
        self.selectedBubbleIndex = cell.index;
    }
}

#pragma mark- textField代理

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self.textField resignFirstResponder];
    return YES;
}

- (void)textDidChange:(UITextField*) textField
{
    if(self.selectedBubbleIndex < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:self.selectedBubbleIndex];
        cell.inputTextContentView.textLabel.text = textField.text;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if(self.selectedBubbleIndex < self.bubbleCells.count)
    {
        JBoInputTextCell *cell = [self.bubbleCells objectAtIndex:self.selectedBubbleIndex];
        cell.inputTextContentView.hasText = textField.text.length != 0;
        
        [self setBubbleTextAtIndex:self.selectedBubbleIndex];
    }
}

@end
