//
//  JBoColorPicker.m
//  靓咖
//
//  Created by kinghe005 on 14-5-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoColorPicker.h"
#import <CoreGraphics/CoreGraphics.h>
#import <QuartzCore/QuartzCore.h>
#import "JBoColorImageOperation.h"
#import <QuartzCore/QuartzCore.h>

#define _indicatorSize_ 24.0
#define _indicatorContentInset_ ((_colorPickerDefaultWidth_ - _indicatorSize_ - 256.0) / 2)
#define _barHeight_ 10.0
#define _whiteColorValue_ 1.1f
#define _blackColorValue_ 1.2f

#pragma mark- JBoColorIndicator

@implementation JBoColorIndicator

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.opaque = NO;
        self.userInteractionEnabled = NO;
        
        self.innerBorderColor = [UIColor whiteColor];
        self.outerBorderColor = [UIColor colorWithWhite:0 alpha:0.7];
        self.borderWidth = 1.0f;
    }
    return self;
}

- (void)dealloc
{
    [_fillColor release];
    [_innerBorderColor release];
    [_outerBorderColor release];
    
    [super dealloc];
}

- (void)setFillColor:(UIColor *)fillColor
{
    if(![_fillColor isEqual:fillColor])
    {
        [_fillColor release];
        _fillColor = [fillColor retain];
        [self setNeedsDisplay];
    }
}

- (void)setInnerBorderColor:(UIColor *)innerBorderColor
{
    if(![_innerBorderColor isEqual:innerBorderColor])
    {
        [_innerBorderColor release];
        _innerBorderColor = [innerBorderColor retain];
        [self setNeedsDisplay];
    }
}

- (void)setOuterBorderColor:(UIColor *)outerBorderColor
{
    if(![_outerBorderColor isEqual:outerBorderColor])
    {
        [_outerBorderColor release];
        _outerBorderColor = [outerBorderColor retain];
        [self setNeedsDisplay];
    }
}

- (void)setBorderWidth:(CGFloat)borderWidth
{
    if(_borderWidth != borderWidth)
    {
        _borderWidth = borderWidth;
        [self setNeedsDisplay];
    }
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //获取原点 、半径
    CGPoint center = CGPointMake(CGRectGetMidX(rect), CGRectGetMidY(rect));
    CGFloat radius = rect.size.width * 0.5;
    
    //绘制内部填充
    CGContextAddArc(context, center.x, center.y, radius - _borderWidth * 2, 0.0f, M_PI * 2.0f, YES);
    [_fillColor setFill];
    CGContextFillPath(context);
    
    //绘制内部边框
    CGContextAddArc(context, center.x, center.y, radius - _borderWidth * 2, 0.0f, M_PI * 2.0f, YES);
    CGContextSetStrokeColorWithColor(context, _innerBorderColor.CGColor);
    CGContextSetLineWidth(context, _borderWidth);
    CGContextStrokePath(context);
    
    //绘制外部边框
    CGContextAddArc(context, center.x, center.y, radius - _borderWidth, 0.0f, M_PI * 2.0f, YES);
    CGContextSetStrokeColorWithColor(context, _outerBorderColor.CGColor);
    CGContextSetLineWidth(context, _borderWidth);
    CGContextStrokePath(context);
}

@end

#pragma mark- JBoColorBarView

@implementation JBoColorBarView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        self.layer.borderColor = [UIColor grayColor].CGColor;
        self.layer.borderWidth = 1.0;
    }
    return self;
}

static CGImageRef createContentImage()
{
    float hsv[] = { 0.0f, 1.0f, 1.0f };
	return createHSVBarContentImage(JBoComponentIndexHue, hsv);
}

- (void)drawRect:(CGRect)rect
{
    CGImageRef image = createContentImage();
    if(image != NULL)
    {
        CGFloat width = CGImageGetWidth(image);
        CGFloat x = (rect.size.width - width) / 2;
        
        //白色
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextAddRect(context, CGRectMake(0, 0, x, rect.size.height));
        [[UIColor blackColor] setFill];
        CGContextFillPath(context);
        
        //黑色
        CGContextAddRect(context, CGRectMake(x, 0, x, rect.size.height));
        [[UIColor whiteColor] setFill];
        CGContextFillPath(context);
        
        //多种颜色
        CGContextDrawImage(context, CGRectMake(x * 2, rect.origin.y, width, rect.size.height), image);
        CGImageRelease(image);
    }
}

@end

#pragma mark- JBoColorPicker

@interface JBoColorPicker ()

@property(nonatomic,assign) CGFloat currentX;

@end

@implementation JBoColorPicker

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _colorBarView = [[JBoColorBarView alloc] initWithFrame:CGRectMake(_indicatorSize_ / 2.0, (frame.size.height - _barHeight_) / 2, frame.size.width - _indicatorSize_, _barHeight_)];
        [self addSubview:_colorBarView];
        
        _indicator = [[JBoColorIndicator alloc] initWithFrame:CGRectMake(0, (frame.size.height - _indicatorSize_) / 2.0, _indicatorSize_, _indicatorSize_)];
        [self addSubview:_indicator];
        
        self.colorAlpha = 1.0f;
        self.white = 0.0;
        self.selectedColor = [UIColor colorWithHue:0 saturation:0 brightness:self.white alpha:self.colorAlpha];
        
        self.value = 0.0;
    }
    return self;
}

- (void)dealloc
{
    [_indicator release];
    [_colorBarView release];
    [_selectedColor release];
    
    [super dealloc];
}

- (void)setValue:(float)value
{
    if(_value != value)
    {
        _value = value;
        [self sendActionsForControlEvents:UIControlEventValueChanged];
        [self setNeedsLayout];
    }
}

- (void)setSelectedColor:(UIColor *)selectedColor
{
    if(_selectedColor != selectedColor)
    {
        _selectedColor = [selectedColor retain];
        _indicator.fillColor = _selectedColor;
    }
}

- (void)setColor:(UIColor *)color
{
    self.selectedColor = color;
    HSBType hsb = [_selectedColor HSB];
    
    if(hsb.brightness == 0 && hsb.saturation == 0)
    {
        self.currentX = _indicatorContentInset_;
    }
    else if(hsb.brightness == 1.0 && hsb.saturation == 0)
    {
        self.currentX = _indicatorContentInset_ * 3 / 2;
    }
    else
    {
        self.currentX = hsb.hue * 255.0 + _indicatorContentInset_ * 2;
    }
    
    self.selectedColor = [UIColor colorWithHue:hsb.hue saturation:hsb.saturation brightness:hsb.brightness alpha:self.colorAlpha];
    
    float percent = self.currentX / _colorBarView.width;
    _value = pin(0.0f, percent, 1.0f);
    CGFloat indicatorLoc =  _value * _colorBarView.bounds.size.width + _indicatorSize_ / 2.0;
    _indicator.center = CGPointMake(indicatorLoc, _indicator.center.y);
}

- (void)layoutSubviews
{
    if(self.currentX <= _indicatorContentInset_)
    {
        self.selectedColor = [UIColor colorWithHue:((self.currentX - _indicatorContentInset_ * 2) / 255.0) saturation:0 brightness:0 alpha:self.colorAlpha];;
        self.white = 0.0;
    }
    else if(self.currentX > _indicatorContentInset_ && self.currentX < _indicatorContentInset_ * 2)
    {
        self.selectedColor = [UIColor colorWithHue:((self.currentX - _indicatorContentInset_ * 2) / 255.0) saturation:0 brightness:1.0f alpha:self.colorAlpha];;
        self.white = 1.0;
    }
    else
    {
        self.selectedColor = [UIColor colorWithHue:((self.currentX - _indicatorContentInset_ * 2) / 255.0) saturation:1.0f brightness:1.0f alpha:self.colorAlpha];
    }
    
    CGFloat indicatorLoc =  _value * _colorBarView.bounds.size.width + _indicatorSize_ / 2.0;
    _indicator.center = CGPointMake(indicatorLoc, _indicator.center.y);
}


#pragma mark- tracking

- (void)trackIndicatorWithTouch:(UITouch*) touch
{
    CGFloat x = [touch locationInView:_colorBarView].x;
    self.currentX = x;
    float percent = x / _colorBarView.width;
    self.value = pin( 0.0f, percent, 1.0f );
}

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event
{
    [self trackIndicatorWithTouch:touch];
    return YES;
}

- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event
{
    [self trackIndicatorWithTouch:touch];
    return YES;
}

@end
