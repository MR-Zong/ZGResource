//
//  JBoImageBrushTool.h
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditToolBase.h"

@interface JBoImageBrushTool : JBoImageEditToolBase

@end
