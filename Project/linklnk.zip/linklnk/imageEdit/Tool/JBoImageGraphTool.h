//
//  JBoImageGraphTool.h
//  linklnk
//
//  Created by kinghe005 on 15/4/17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoImageEditToolBase.h"

/**图片编辑，添加图形
 */
@interface JBoImageGraphTool : JBoImageEditToolBase

@end
