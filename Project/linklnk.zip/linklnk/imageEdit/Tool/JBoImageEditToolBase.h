//
//  JBoImageEditToolBase.h
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoBasic.h"
#import "JBoImageEditorViewController.h"
#import "UIImage+Utilities.h"
#import "UIView+Utilities.h"
#import <QuartzCore/QuartzCore.h>


/**图片编辑类型
 */
typedef NS_ENUM(NSInteger, JBoImageEditType)
{
    JBoImageEditTypeFilter = 0, //滤镜
    JBoImageEditTypeBrush = 1, //画笔
    JBoImageEditTypeCrop = 2, //裁剪
    JBoImageEditTypeWatermark = 3, //水印
    JBoImageEditTypeTextInput = 4, //文字输入
    JBoImageEditTypeToneCurve = 5, //色彩调整
    JBoImageEditTypeGraph = 6, ///图形
};

@class JBoImageEditToolBase;

/**图片编辑基础工具代理
 */
@protocol JBoImageEditToolDelegate <NSObject>

/**图片编辑完成
 *@param tool 编辑工具类
 *@param type 编辑类型
 *@param image 编辑完成的图片
 */
- (void)imageEditTool:(JBoImageEditToolBase*) tool editType:(JBoImageEditType) type didFinishEditWithImage:(UIImage*) image;

@end

/**图片编辑基础工具
 */
@interface JBoImageEditToolBase : NSObject

//编辑器 工具图标 标题
+ (NSArray*)imageEditToolIcons;
+ (NSArray*)imageEditToolTitles;

//编辑视图
@property(nonatomic,assign) JBoImageEditorViewController *imageEditor;
//编辑的源图片
@property(nonatomic,retain) UIImage *originalImage;
//菜单容器
@property(nonatomic,readonly) UIView *menuContainer;
//分割线
@property(nonatomic,retain) UIView *lineView;

@property(nonatomic,assign) id<JBoImageEditToolDelegate> delegate;

- (id)initWithImageEditor:(JBoImageEditorViewController*) editor;

//初始化工具
- (void)initilization;

//开始编辑
- (void)beginEdit;

//编辑完成
- (void)endEdit;

//编辑撤销
- (void)close;

//开始渲染
- (void)beginRender;

//渲染完成
- (void)endRender;

//获取图片
- (UIImage*)getComponentImageWithType:(JBoImageEditType) type;

@end
