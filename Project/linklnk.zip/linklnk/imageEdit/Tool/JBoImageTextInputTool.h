//
//  JBoImageTextInputTool.h
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditToolBase.h"

/**图片编辑 添加文字和色块
 */
@interface JBoImageTextInputTool : JBoImageEditToolBase

@end
