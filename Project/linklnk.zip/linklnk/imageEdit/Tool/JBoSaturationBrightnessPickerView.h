//
//  JBoColorPickerView.h
//  靓咖
//
//  Created by kinghe005 on 14-8-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoSaturationBrightnessPickerView;

@protocol JBoSaturationBrightnessPickerViewDelegate <NSObject>

/**选择的颜色改变
 */
- (void)saturationBrightnessPickerView:(JBoSaturationBrightnessPickerView*) pickerView didSelectColor:(UIColor*) color;

@end

/**大范围颜色饱和度和亮度选择器
 */
@interface JBoSaturationBrightnessPickerView : UIView

/**色彩 default is '0.0'
 */
@property(nonatomic,assign) CGFloat hue;

/**饱和度 default is '1.0'
 */
@property(nonatomic,assign) CGFloat saturation;

/**亮度 default is '1.0'
 */
@property(nonatomic,assign) CGFloat brightness;

/**当前选中的颜色
 */
@property(nonatomic,assign) UIColor *color;

@property(nonatomic,assign) id<JBoSaturationBrightnessPickerViewDelegate> delegate;

@end
