//
//  JBoImageWatemarkTool.m
//  靓咖
//
//  Created by kinghe005 on 14-5-28.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageWatemarkTool.h"
#import "JBoImageEditOperation.h"
#import "JBoDrawImageCell.h"
#import "JBoImagePickerController.h"
#import "JBoMutilImagePickerViewController.h"
#import "JBoNavigationViewController.h"
#import "JBoImageCropViewController.h"
#import "JBoImageEditWatermarkScrollView.h"
#import "JBoImageEditWartermarkInfo.h"

#define _watermarkItemStartTag_ 1000

@interface JBoImageWatemarkTool ()<JBoDrawImageCellDelegate,JBoMutiImagePickerDelegate, JBoImagePickerControllerDelegate,JBoImageEditWatermarkScrollViewDelegte>

/**拼图选择菜单
 */
@property(nonatomic,retain) JBoImageEditWatermarkScrollView *watermarkScrollView;

/**可选的拼图信息 数组元素是 JBoImageEditWartermarkInfo
 */
@property(nonatomic,retain) NSMutableArray *watermarks;

//选中的拼图
@property(nonatomic,retain) NSMutableArray *selectedCellArray;

/**当前选中编辑的拼图
 */
@property(nonatomic,retain) JBoDrawImageCell *currentCell;

//相机
@property(nonatomic,retain) JBoImagePickerController *imagePicker;

@end

@implementation JBoImageWatemarkTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_watermarkScrollView release];
    [_watermarks release];
    [_selectedCellArray release];
    [_currentCell release];
    
    [_imagePicker release];
    
    [super dealloc];
}

#pragma mark- super method

- (void)initilization
{
    self.imageEditor.scrollView.panGestureRecognizer.minimumNumberOfTouches = 2;
    self.selectedCellArray = [NSMutableArray array];
    
    [self createWatermarkItems];
}

- (void)endEdit
{
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        for(JBoDrawImageCell *cell in self.selectedCellArray)
        {
            cell.selected = NO;
        }
        
        [super endEdit];
        [self.imageEditor.scrollView setZoomScale:self.imageEditor.scrollView.minimumZoomScale];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
            UIImage *image = [self getComponentImageWithType:JBoImageEditTypeWatermark];
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [self.delegate imageEditTool:self editType:JBoImageEditTypeBrush didFinishEditWithImage:image];
            });
        });
    }
}

- (void)close
{
    self.imageEditor.scrollView.panGestureRecognizer.minimumNumberOfTouches = 1;
    for(JBoDrawImageCell *cell in self.selectedCellArray)
    {
        [cell removeFromSuperview];
    }
    [super close];
}

#pragma mark- private method

//创建拼图菜单
- (void)createWatermarkItems
{
    CGFloat size = 30.0;
    
    //拼图图片加载过程中的加载指示器
    UIActivityIndicatorView *actView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    actView.frame = CGRectMake((self.menuContainer.width - size) / 2, (self.menuContainer.height - size) / 2, size, size);
    [self.menuContainer addSubview:actView];
    [actView startAnimating];
    [actView release];
    
    //异步加载图片
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        
        NSArray *cellArray = [NSArray arrayWithObjects:
                              @"appIcon5@2x",
                              @"appIcon6@2x",
                              @"appIcon7@2x",nil];
        
        
        NSMutableArray *thumbnailArray = [[NSMutableArray alloc] init];
        
        for(NSString *imageName in cellArray)
        {
            NSString *filePath = [[NSBundle mainBundle] pathForResource:imageName ofType:_imageType_];
            
            UIImage *image = [[UIImage alloc] initWithContentsOfFile:filePath];
            if(image)
            {
                JBoImageEditWartermarkInfo *info = [[JBoImageEditWartermarkInfo alloc] init];
                info.image = image;
                
                UIImage *thumbnailImage = nil;
                if(image.size.width != image.size.height)
                {
                    thumbnailImage = [image aspectFitThumbnailWithSize:CGSizeMake(_JBoImageEditWatermarkCellSize_, _JBoImageEditWatermarkCellSize_)];
                }
                else
                {
                    thumbnailImage = [image resize:CGSizeMake(_JBoImageEditWatermarkCellSize_, _JBoImageEditWatermarkCellSize_)];
                }
                
                info.thumbnail = thumbnailImage;
                [thumbnailArray addObject:info];
                [info release];
            }
            
            [image release];
            
        }
        
        self.watermarks = thumbnailArray;
        [thumbnailArray release];

        [JBoImageEditOperation addCameraCell:self.watermarks];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            [actView stopAnimating];
            [actView removeFromSuperview];
            
            //创建拼图选择菜单
            JBoImageEditWatermarkScrollView *watermarkScrollView = [[JBoImageEditWatermarkScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.width, _JBoImageEditWatermarkCellSize_ + _JBoImageEditWatermarkCellMargin_ * 2)];
            watermarkScrollView.srcArray = self.watermarks;
            watermarkScrollView.delegate = self;
            [self.menuContainer addSubview:watermarkScrollView];
            self.watermarkScrollView = watermarkScrollView;
            [watermarkScrollView release];
            [watermarkScrollView loadingDidFinished];
        });
        
    });
}

/**创建拼图
 *@param image 拼图图片
 */
- (void)createWatermarkWithImage:(UIImage*) image
{
    CGFloat cellSize = 100.0;
    CGSize size = CGSizeMake(cellSize, cellSize);
    CGFloat minWidth = _cellDefaultMinWidth_;
    CGFloat minHeight = _cellDefaultMinHeight_;
    
    if(image.size.width != image.size.height)
    {
        size = [image shrinkWithContraintSize:CGSizeMake(_width_ - (_cellGlobalInset_ + _cellInteractiveBorderSize_) * 2, _height_ - (_cellGlobalInset_ + _cellInteractiveBorderSize_) * 2)];
        
        CGFloat width = size.width;
        CGFloat height = size.height;
        
        width = width / 4 + (_cellGlobalInset_ + _cellInteractiveBorderSize_) * 2;
        height = height / 4 + (_cellGlobalInset_ + _cellInteractiveBorderSize_) * 2;
        
        minWidth = width;
        minHeight = height;
        
        size = CGSizeMake(width, height);
    }
    
    JBoDrawImageCell *cell = [[JBoDrawImageCell alloc] initWithFrame:CGRectMake((self.imageEditor.scrollView.contentOffset.x + _width_ / 2 - size.width) / self.imageEditor.scrollView.zoomScale, (self.imageEditor.scrollView.contentOffset.y + (_height_ - _navgateBarHeight_ - _menuHeight_) / 2 - size.height) / self.imageEditor.scrollView.zoomScale, size.width, size.height)];
    cell.preventsPositionOutsideSuperview = YES;
    cell.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    cell.contentImage = image;
    cell.minWidth = minWidth;
    cell.minHeight = minHeight;
    cell.corners = NO;
    cell.maxScale = self.imageEditor.editImageView.width / size.width / self.imageEditor.scrollView.zoomScale;
    cell.userInteractionEnabled = YES;
    cell.delegate = self;
    [self.imageEditor.editImageView addSubview:cell];
    [self.selectedCellArray addObject:cell];
    cell.selected = YES;
    cell.editable = YES;
    cell.burshing = NO;
    self.currentCell = cell;
    
    [cell release];
}


#pragma mark- JBoImageEditWatermarkScrollView delegate

- (void)imageEditWatermarkScrollView:(JBoImageEditWatermarkScrollView *)sceneScrollView didSelectedImage:(UIImage *)image
{
    if(!image)
    {
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"选择拼图素材" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
        [actionSheet showInView:self.imageEditor.view];
        [actionSheet release];
        return;
    }
    
    [self createWatermarkWithImage:image];
}


#pragma mark- actionSheet代理

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0 :
        {
            if([JBoImagePickerController cameraIsAvaliable])
            {
                JBoImagePickerController *imagePicker = [[JBoImagePickerController alloc] initWithSourceType:JBoImagePickerControllerSourceTypePicker];
                imagePicker.delegate = self;
                self.imagePicker = imagePicker;
                [imagePicker showWithViewController:self.imageEditor animated:YES completion:nil];
                [imagePicker release];
            }
        }
            break;
        case 1 :
        {
            JBoMutilImagePickerViewController *mutilImagePicker = [[JBoMutilImagePickerViewController alloc] init];
            mutilImagePicker.delegate = self;
            mutilImagePicker.mutilImagePickType = JBoMutilImagePickTypeCrop;
            mutilImagePicker.cropFrame = CGRectMake(0, (_height_ - _width_) / 2, _width_, _width_);
            [mutilImagePicker showInViewController:self.imageEditor animated:YES completion:nil];
            [mutilImagePicker release];
        }
            break;
        default:
            break;
    }
}

#pragma mark- imagePicker代理

- (void)imagePickerDidCanceled:(JBoImagePickerController *)imagePicker
{
    [imagePicker dismissWithAnimated:YES completion:^(void){
        self.imagePicker = nil;
    }];
}

- (void)imagePicker:(JBoImagePickerController *)imagePicker didTokenPicture:(UIImage *)image
{
    [imagePicker dismissWithAnimated:NO completion:^(void){
        JBoImageCropViewController *imageCropVC = [[JBoImageCropViewController alloc] initWithImage:imagePicker.originalImage];
        imageCropVC.delegate = self;
        [self.imageEditor.navigationController pushViewController:imageCropVC animated:YES];
        [imageCropVC release];
        self.imagePicker = nil;
    }];
}

#pragma mark- mutilImagePicker 代理

- (void)imagePicker:(UIViewController *)viewControler didCroppedImage:(UIImage *)image
{
    [self createWatermarkWithImage:image];
    if([self.imageEditor.navigationController.viewControllers containsObject:viewControler])
    {
        [viewControler.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        [viewControler dismissViewControllerAnimated:YES completion:nil];
    }
}

#pragma mark- JBoDrawImageCell代理

- (void)cellDidClose:(JBoDrawImageCell *)cell
{
    [self.selectedCellArray removeObject:cell];
    [cell removeFromSuperview];
    self.currentCell = nil;
}

- (void)cellDidSelected:(JBoDrawImageCell *)cell
{
    if(self.currentCell == cell)
    {
        self.currentCell = cell.selected ? cell : nil;
        return;
    }
    
    self.currentCell.selected = NO;
    self.currentCell = cell;
}

- (void)cellDidDoubleTapped:(JBoDrawImageCell *)cell
{
    [self.imageEditor.editImageView bringSubviewToFront:cell];
}


@end
