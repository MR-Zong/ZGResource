//
//  JBoImageGraphTool.m
//  linklnk
//
//  Created by kinghe005 on 15/4/17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoImageGraphTool.h"
#import "JBoCustomToolBar.h"
#import "JBoColorPicker.h"
#import "JBoImageEditRectangleCell.h"
#import "JBoImageEditArrowCell.h"
#import "JBoImageTextTool.h"
#import "JBoRGBAInputView.h"
#import "JBoImageEditBackgroundCell.h"

#define _cellDefaultHeight_ 80.0

#define _adjustZoomScale_ 0.95

#define _toolBarScale_ 3 / 8
#define _bottomHeight_ 40.0
#define _fontItemStartTag_ 1000


//色块
#define _colorPieceStartTag_ 300
#define _colorPieceAddTag_ 400

//色块最大数量
#define _colorPieceMaxCount_ 5

//箭头
#define _arrowStartTag_ 300
#define _arrowAddTag_ 400

//箭头最大数量
#define _arrowMaxCount_ 5

//矩形框
#define _rectangleItemStartTag_ 100

//矩形框框添加按钮
#define _rectangleItemAddTag_ 200

//矩形框最大数量
#define _rectangleItemMaxCount_ 5

typedef NS_ENUM(NSInteger, JBoImageGraphToolMenuItemStyle)
{
    JBoImageGraphToolMenuItemStyleRectangle = 0, //文本
    JBoImageGraphToolMenuItemStyleArrow = 1, //箭头
    JBoImageGraphToolMenuItemStyleAdd = 2, //添加按钮
    JBoImageGraphToolMenuItemStyleColorPiece = 3, //色块
};

//选择框
@interface JBoImageGraphMenuItem : UIView

/**选中的指示下划线高度
 */
@property(nonatomic,readonly) CGFloat indicatorSize;

/**选中的指示下划线颜色
 */
@property(nonatomic,readonly) UIView *selectedIndicator;
/**是否选中
 */
@property(nonatomic,assign) BOOL selected;

/**是否为添加
 */
@property(nonatomic,assign) BOOL add;

/**箭头
 */
@property(nonatomic,readonly) JBoImageEditArrow *arrowView;

/**矩形框
 */
@property(nonatomic,readonly) UIView *rectangleView;

/**色块
 */
@property(nonatomic,readonly) UIView *colorPieceView;

/**已菜单类型创建菜单按钮
 */
- (id)initWithFrame:(CGRect)frame style:(JBoImageGraphToolMenuItemStyle) style;

@end

@implementation JBoImageGraphMenuItem

- (id)initWithFrame:(CGRect)frame
{
    return [self initWithFrame:frame style:JBoImageGraphToolMenuItemStyleRectangle];
}

- (id)initWithFrame:(CGRect)frame style:(JBoImageGraphToolMenuItemStyle)style
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        _indicatorSize = 2.0;
        
        switch (style)
        {
            case JBoImageGraphToolMenuItemStyleRectangle :
            {
                _rectangleView = [[UIView alloc] initWithFrame:CGRectMake(0, 5.0, frame.size.width, frame.size.height - 10.0)];
                _rectangleView.backgroundColor = [UIColor clearColor];
                _rectangleView.userInteractionEnabled = NO;
                _rectangleView.layer.borderWidth = 1.0;
                [self addSubview:_rectangleView];
            }
                break;
            case JBoImageGraphToolMenuItemStyleAdd :
            {
                self.add = YES;
            }
                break;
            case JBoImageGraphToolMenuItemStyleArrow :
            {
                CGFloat size = 35.0;
                _arrowView = [[JBoImageEditArrow alloc] initWithFrame:CGRectMake((frame.size.width - size) / 2.0, (frame.size.height - size) / 2.0, size, size)];
                [self addSubview:_arrowView];
            }
                break;
            case JBoImageGraphToolMenuItemStyleColorPiece :
            {
                CGFloat size = 35.0;
                _colorPieceView = [[UIView alloc] initWithFrame:CGRectMake((frame.size.width - size) / 2.0, (frame.size.height - size) / 2.0, size, size)];
                _colorPieceView.layer.cornerRadius = 3.0;
                _colorPieceView.layer.borderColor = [UIColor whiteColor].CGColor;
                _colorPieceView.layer.borderWidth = 2.0;
                [self addSubview:_colorPieceView];
            }
                break;
            default:
                break;
        }
    }
    
    return self;
}

- (void)setAdd:(BOOL)add
{
    if(_add != add)
    {
        _add = add;
        [self setNeedsDisplay];
    }
}

/**是否选中
 */
- (void)setSelected:(BOOL)selected
{
    _selected = selected;
    if(!_selectedIndicator)
    {
        CGFloat height = _indicatorSize;
        _selectedIndicator = [[UIView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - height, self.frame.size.width, height)];
        _selectedIndicator.backgroundColor = _navigationBarBackgroundDefaultColor_;
        [self addSubview:_selectedIndicator];
    }
    
    _selectedIndicator.hidden = !_selected;
}

- (void)dealloc
{
    [_selectedIndicator release];
    [_rectangleView release];
    [_arrowView release];
    [_colorPieceView release];
    
    [super dealloc];
}

- (void)drawRect:(CGRect)rect
{
    if(self.add)
    {
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        //设置线条颜色和宽度
        UIColor *color = [UIColor whiteColor];
        CGContextSetStrokeColorWithColor(context, color.CGColor);
        CGContextSetLineWidth(context, 2.0);
        CGContextSetLineCap(context, kCGLineCapRound);
        CGContextSetLineJoin(context, kCGLineJoinRound);
        
        CGFloat width = rect.size.height - 25.0;
        
        //绘制横线
        CGPoint point = CGPointMake((rect.size.width - width) / 2.0, rect.size.height / 2.0);
        CGContextMoveToPoint(context, point.x, point.y);
        CGContextAddLineToPoint(context, point.x + width, point.y);
        
        //绘制竖线
        point = CGPointMake(rect.size.width / 2.0, (rect.size.height - width) / 2.0);
        CGContextMoveToPoint(context, point.x, point.y);
        CGContextAddLineToPoint(context, point.x, point.y + width);
        
        //把线条都绘制出来 必须的
        CGContextStrokePath(context);
    }
}

@end

@interface JBoImageGraphTool ()<JBoCustomToolBarDelegate,JBoImageEditBaseCellDelegate,UITextFieldDelegate,JBoRGBAInputViewDelegate>

//矩形框选项，可添加矩形框
@property(nonatomic,retain) UIScrollView *rectangleScrollView;

//已创建的矩形框 数组元素是 JBoImageEditRectangleCell对象
@property(nonatomic,retain) NSMutableArray *rectangleCells;

//选中的矩形框
@property(nonatomic,assign) NSInteger selectedRectangleIndex;

//底部菜单
@property(nonatomic,retain) JBoCustomToolBar *toolBar;

//颜色选择器
@property(nonatomic,retain) JBoColorPicker *colorPicker;

//颜色选择容器
@property(nonatomic,retain) UIView *colorPickerContainer;

//箭头添加
@property(nonatomic,retain) UIScrollView *arrowScrollView;

//已创建的箭头 数组元素是JBoImageEditArrowCell对象
@property(nonatomic,retain) NSMutableArray *arrows;

//选中的箭头
@property(nonatomic,assign) NSInteger selectedArrowIndex;

//背景视图 箭头，矩形框的父视图
@property(nonatomic,retain) UIView *backgroundView;

//scrollView 原始缩放比例
@property (nonatomic, assign) CGFloat maximumZoomScale;
@property (nonatomic, assign) CGFloat minimumZoomScale;

//色块添加
@property(nonatomic,retain) UIScrollView *colorPieceScrollView;

//已创建的色块 数组元素是JBoImageEditBackgroundCell对象
@property(nonatomic,retain) NSMutableArray *colorPieces;

//选中的色块
@property(nonatomic,assign) NSInteger selectedColorPieceIndex;

//色块背景颜色
@property(nonatomic,retain) UIView *backgroundColorView;
@property(nonatomic,retain) JBoColorPicker *backgroundColorPicker;

//背景颜色透明度
@property(nonatomic,retain) UISlider *backgroundColorAlphaSlider;

//颜色rgb显示输入视图
@property(nonatomic,retain) JBoRGBAInputView *inputView;

@end

@implementation JBoImageGraphTool

#pragma mark- 内存管理

- (void)dealloc
{
    [_rectangleScrollView release];
    [_rectangleCells release];
    
    [_toolBar release];
    [_colorPicker release];
    [_colorPickerContainer release];
    
    [_arrowScrollView release];
    [_arrows release];
    
    [_backgroundView release];
    
    [_colorPieces release];
    [_colorPieceScrollView release];
    [_backgroundColorAlphaSlider release];
    [_backgroundColorPicker release];
    [_backgroundColorView release];
    
    [_inputView release];
    
    [super dealloc];
}

#pragma mark- super method

- (void)initilization
{
    _selectedArrowIndex = NSNotFound;
    _selectedRectangleIndex = NSNotFound;
    
    //禁止缩放
    self.minimumZoomScale = self.imageEditor.scrollView.minimumZoomScale;
    self.maximumZoomScale = self.imageEditor.scrollView.maximumZoomScale;
    
    self.imageEditor.scrollView.minimumZoomScale = 1.0;
    self.imageEditor.scrollView.maximumZoomScale = 1.0;
    
    [self.imageEditor.scrollView setZoomScale:1.0 animated:NO];
    self.imageEditor.scrollView.delaysContentTouches = NO;
    self.imageEditor.scrollView.canCancelContentTouches = NO;
    
    CGFloat toolBarHeight = self.menuContainer.bounds.size.height * _toolBarScale_;
    JBoCustomToolBar *toolBar = [[JBoCustomToolBar alloc] initWithFrame:CGRectMake(0, (self.menuContainer.bounds.size.height - toolBarHeight), self.menuContainer.bounds.size.width, toolBarHeight) items:[NSArray arrayWithObjects:[JBoCustomToolBarItem toolBarItemWithTitle:@"矩形框" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"箭头" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"图形颜色" image:nil] ,[JBoCustomToolBarItem toolBarItemWithTitle:@"色块" image:nil], [JBoCustomToolBarItem toolBarItemWithTitle:@"色块颜色" image:nil], nil]];
    toolBar.titleSelectedColor = _navigationBarBackgroundDefaultColor_;
    toolBar.delegate = self;
    toolBar.titleFont = [UIFont boldSystemFontOfSize:13.0];
    [self.menuContainer addSubview:toolBar];
    self.toolBar = toolBar;
    [toolBar release];
    
    self.toolBar.selectedIndex = 0;
    
    
    //初始化矩形框
    [self initlizationRectangleItems];

    //背景颜色
    CGFloat padding = _width_ * (1.0 - _adjustZoomScale_);
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(self.imageEditor.editImageView.left - padding, self.imageEditor.editImageView.top - padding, self.imageEditor.editImageView.width + padding * 2, self.imageEditor.editImageView.height + padding * 2)];
    view.backgroundColor = [UIColor clearColor];
    [self.imageEditor.scrollView addSubview:view];
    self.backgroundView = view;
    [view release];
    
    
    JBoRGBAInputView *inputView = [[JBoRGBAInputView alloc] initWithFrame:CGRectMake(padding, padding, _RGBAInputViewDefaultWidth_, 0)];
    inputView.delegate = self;
    inputView.hidden = YES;
    [self.imageEditor.scrollView addSubview:inputView];
    self.inputView = inputView;
    [inputView release];
}

//结束编辑
- (void)endEdit
{
    if([self.delegate respondsToSelector:@selector(imageEditTool:editType:didFinishEditWithImage:)])
    {
        //把视图重 backgroundView中 移到 编辑图片上
        self.inputView.hidden = YES;
        
        CGFloat padding = (1.0 - _adjustZoomScale_) * _width_;
        
        for(JBoImageEditRectangleCell *cell in self.rectangleCells)
        {
            cell.selected = NO;
            [cell removeFromSuperview];
            [self.imageEditor.editImageView addSubview:cell];
            
            cell.center = CGPointMake(cell.center.x - padding, cell.center.y - padding);
        }
        
        for(JBoImageEditArrowCell *cell in self.arrows)
        {
            cell.selected = NO;
            [cell removeFromSuperview];
            [self.imageEditor.editImageView addSubview:cell];
            
            cell.center = CGPointMake(cell.center.x - padding, cell.center.y - padding);
        }
        
        for(JBoImageEditBackgroundCell *cell in self.colorPieces)
        {
            cell.selected = NO;
            [cell removeFromSuperview];
            [self.imageEditor.editImageView addSubview:cell];
            
            cell.center = CGPointMake(cell.center.x - padding, cell.center.y - padding);
        }
        
        
        [super endEdit];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            
            UIImage *image = [self getComponentImageWithType:JBoImageEditTypeGraph];
            dispatch_async(dispatch_get_main_queue(), ^(void){
                [self.delegate imageEditTool:self editType:JBoImageEditTypeGraph didFinishEditWithImage:image];
            });
        });
    }
}

- (void)close
{
    self.imageEditor.scrollView.delaysContentTouches = YES;
    self.imageEditor.scrollView.canCancelContentTouches = YES;
    self.imageEditor.scrollView.minimumZoomScale = self.minimumZoomScale;
    self.imageEditor.scrollView.maximumZoomScale = self.maximumZoomScale;
    
    for(JBoImageEditRectangleCell *cell in self.rectangleCells)
    {
        [cell removeFromSuperview];
    }
    
    for(JBoImageEditArrowCell *cell in self.arrows)
    {
        [cell removeFromSuperview];
    }
    
    for(JBoImageEditBackgroundCell *cell in self.colorPieces)
    {
        [cell removeFromSuperview];
    }
    
    [self.backgroundView removeFromSuperview];
    [self.inputView removeFromSuperview];
    [super close];
}

#pragma mark- JBoCustomToolBar代理

- (void)toolBar:(JBoCustomToolBar *)toolBar didSelectedAtIndex:(NSInteger)index
{
    self.inputView.hidden = YES;
    switch (index)
    {
        case 0 :
        {
        }
            break;
        case 1 :
        {
            if(!self.arrowScrollView)
            {
                [self initlizationArrowItems];
            }
        }
            break;
        case 2 :
        {
            if(!self.colorPickerContainer)
            {
                UIView *view = [[UIView alloc] initWithFrame:self.rectangleScrollView.frame];
                view.backgroundColor = self.rectangleScrollView.backgroundColor;
                [self.menuContainer addSubview:view];
                self.colorPickerContainer = view;
                [view release];
                
                JBoColorPicker *colorPicker = [[JBoColorPicker alloc] initWithFrame:CGRectMake((view.frame.size.width - _colorPickerDefaultWidth_) / 2, (view.frame.size.height - _colorPickerDefaultHeight_) / 2, _colorPickerDefaultWidth_, _colorPickerDefaultHeight_)];
                colorPicker.colorAlpha = 1.0;
                [colorPicker addTarget:self action:@selector(colorValueDidChanged:) forControlEvents:UIControlEventValueChanged];
                [view addSubview:colorPicker];
                self.colorPicker = colorPicker;
                [colorPicker release];
                
                [colorPicker setColor:[UIColor redColor]];
                
            }
            
            self.inputView.currentColor = self.colorPicker.selectedColor;
        }
            break;
        case 3 :
        {
            if(!self.colorPieceScrollView)
            {
                [self initlizationColorPieceItems];
            }
        }
            break;
        case 4 :
        {
            if(!self.backgroundColorView)
            {
                UIView *view = [[UIView alloc] initWithFrame:self.rectangleScrollView.frame];
                view.backgroundColor = self.rectangleScrollView.backgroundColor;
                [self.menuContainer addSubview:view];
                self.backgroundColorView = view;
                [view release];
                
                JBoColorPicker *colorPicker = [[JBoColorPicker alloc] initWithFrame:CGRectMake((view.frame.size.width - _colorPickerDefaultWidth_) / 2, 0, _colorPickerDefaultWidth_, _colorPickerDefaultHeight_)];
                [colorPicker addTarget:self action:@selector(backgroundColorValueDidChanged:) forControlEvents:UIControlEventValueChanged];
                [view addSubview:colorPicker];
                self.backgroundColorPicker = colorPicker;
                [colorPicker release];
                
                CGFloat width = 250.0;
                CGFloat height = view.height - colorPicker.height;
                UISlider *slider = [[UISlider alloc] initWithFrame:CGRectMake((self.menuContainer.width - width) / 2.0, colorPicker.bottom, width, height)];
                [slider addTarget:self action:@selector(backgroundColorAlphaValueDidChanged:) forControlEvents:UIControlEventValueChanged];
                slider.minimumValue = 0.0;
                slider.maximumValue = 1.0;
                slider.minimumTrackTintColor = _navigationBarBackgroundDefaultColor_;
                slider.value = 0.3;
                [view addSubview:slider];
                self.backgroundColorAlphaSlider = slider;
                [slider release];
                
                [self backgroundColorValueDidChanged:self.backgroundColorPicker];
                [self backgroundColorAlphaValueDidChanged:self.backgroundColorAlphaSlider];
            }
            
            self.inputView.currentColor = self.backgroundColorPicker.selectedColor;
        }
            break;
        default:
            break;
    }
    
    self.inputView.hidden = index != 2 && index != 3;
    self.colorPickerContainer.hidden = index != 2;
    
    self.rectangleScrollView.hidden = index != 0;
    self.arrowScrollView.hidden = index != 1;
    
    self.backgroundColorView.hidden = index != 4;
    self.colorPieceScrollView.hidden = index != 3;
}

#pragma mark- private method

#pragma mark- 颜色选择

//颜色选择
- (void)colorValueDidChanged:(JBoColorPicker*) picker
{
    self.inputView.currentColor = picker.selectedColor;
    if(self.selectedRectangleIndex < self.rectangleCells.count)
    {
        JBoImageEditRectangleCell *cell = [self.rectangleCells objectAtIndex:self.selectedRectangleIndex];
        cell.rectangleColor = picker.selectedColor;
        
        JBoImageGraphMenuItem *item = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemStartTag_ + _selectedRectangleIndex];
        item.rectangleView.layer.borderColor = picker.selectedColor.CGColor;
    }
    else if (self.selectedArrowIndex < self.arrows.count)
    {
        JBoImageEditArrowCell *cell = [self.arrows objectAtIndex:self.selectedArrowIndex];
        cell.arrow.arrowColor = picker.selectedColor;
        
        JBoImageGraphMenuItem *item = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_arrowStartTag_ + _selectedRectangleIndex];
        item.arrowView.arrowColor = picker.selectedColor;
    }
}

#pragma mark- 矩形框框

//初始化矩形框选项
- (void)initlizationRectangleItems
{
    UIScrollView *rectangleScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.bounds.size.width, self.menuContainer.bounds.size.height - self.toolBar.height)];
    
    rectangleScrollView.backgroundColor = self.imageEditor.menuScrollView.backgroundColor;
    rectangleScrollView.showsHorizontalScrollIndicator = NO;
    rectangleScrollView.showsVerticalScrollIndicator = NO;
    [self.menuContainer addSubview:rectangleScrollView];
    self.rectangleScrollView = rectangleScrollView;
    [rectangleScrollView release];
    
    self.rectangleCells = [NSMutableArray array];
    CGFloat size = 48.0;
    
    //创建矩形框添加按钮
    JBoImageGraphMenuItem *item = [[JBoImageGraphMenuItem alloc] initWithFrame:CGRectMake(0, 0, size, size) style:JBoImageGraphToolMenuItemStyleAdd];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rectangleDidAdd:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.tag = _rectangleItemAddTag_;
    [self.rectangleScrollView addSubview:item];
    [item release];
    
    self.selectedRectangleIndex = NSNotFound;
    [self.rectangleScrollView setContentSize:CGSizeMake(size * 1, self.rectangleScrollView.bounds.size.height)];
}

//添加矩形框
- (void)rectangleDidAdd:(id) sender
{
    CGFloat interval = 5.0;
    
    JBoImageGraphMenuItem *addItem = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemAddTag_];
    
    JBoImageGraphMenuItem *item = [[JBoImageGraphMenuItem alloc] initWithFrame:addItem.frame style:JBoImageGraphToolMenuItemStyleRectangle];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rectangleDidselected:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.selected = YES;
    item.tag = _rectangleItemStartTag_ + self.rectangleCells.count;
    [self.rectangleScrollView addSubview:item];
    [item release];
    
    addItem.left = item.right + interval;
    
    
    //添加矩形框
    CGFloat cellSize = 120.0;
    
    JBoImageEditRectangleCell *cell = [[JBoImageEditRectangleCell alloc] initWithFrame:CGRectMake((self.backgroundView.width - cellSize) / 2.0, 30.0, cellSize, _cellDefaultHeight_) contentPadding:_width_ * (1.0 - _adjustZoomScale_)];
    cell.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    cell.preventsPositionOutsideSuperview = YES;
    cell.index = self.rectangleCells.count;
    cell.delegate = self;
    [self.backgroundView addSubview:cell];
    cell.selected = YES;
    [cell release];
    
    
    [self.rectangleCells addObject:cell];
    
    NSInteger count = addItem.hidden ? self.rectangleCells.count : self.rectangleCells.count + 1;
    
    [self.rectangleScrollView setContentSize:CGSizeMake(item.width * count, self.rectangleScrollView.bounds.size.height)];
    
    if(self.rectangleCells.count == _rectangleItemMaxCount_)
    {
        addItem.hidden = YES;
    }
    
    item.rectangleView.layer.borderColor = cell.rectangleColor.CGColor;
    self.selectedRectangleIndex = self.rectangleCells.count - 1;
    self.selectedArrowIndex = NSNotFound;
    self.selectedColorPieceIndex = NSNotFound;
}

//移除矩形框
- (void)removeRectangleAtIndex:(NSInteger) index
{
    CGFloat interval = 5.0;
    
    //从父视图中移除
    JBoImageGraphMenuItem *item = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemStartTag_ + index];
    CGFloat x = item.left;
    
    //移动后面的item
    for(NSInteger i = index + 1;i < self.rectangleCells.count;i ++)
    {
        JBoImageGraphMenuItem *backItem = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemStartTag_ + i];
        backItem.tag = _rectangleItemStartTag_ + i - 1;
        backItem.left = x;
        x = backItem.right + interval;
        
        JBoImageEditRectangleCell *cell = [self.rectangleCells objectAtIndex:i];
        cell.index = i - 1;
    }
    
    
    
    JBoImageGraphMenuItem *addItem = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemAddTag_];
    addItem.left = x;
    
    //如果添加按钮已隐藏 显示它
    addItem.hidden = NO;
    [self.rectangleScrollView setContentSize:CGSizeMake(item.width * (self.rectangleCells.count + 1), self.rectangleScrollView.bounds.size.height)];
    [item removeFromSuperview];
}

//选择矩形框
- (void)setSelectedRectangleIndex:(NSInteger)selectedRectangleIndex
{
    //取消以前的选择
    if(_selectedRectangleIndex < self.rectangleCells.count)
    {
        JBoImageEditRectangleCell *cell = [self.rectangleCells objectAtIndex:_selectedRectangleIndex];
        cell.selected = NO;
    }
    
    JBoImageGraphMenuItem *oldItem = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemStartTag_ + _selectedRectangleIndex];
    oldItem.selected = NO;
    
    //确定当前的选择
    _selectedRectangleIndex = selectedRectangleIndex;
    
    JBoImageGraphMenuItem *curItem = (JBoImageGraphMenuItem*)[self.rectangleScrollView viewWithTag:_rectangleItemStartTag_ + _selectedRectangleIndex];
    curItem.selected = YES;
    
    if(_selectedRectangleIndex < self.rectangleCells.count)
    {
        JBoImageEditRectangleCell *cell = [self.rectangleCells objectAtIndex:_selectedRectangleIndex];
        cell.selected = YES;
    }
}

//选择矩形框
- (void)rectangleDidselected:(UITapGestureRecognizer*) tap
{
    NSInteger index = tap.view.tag - _rectangleItemStartTag_;
    self.selectedRectangleIndex = index;
}

//前置矩形框
- (void)setupRectanglePositon
{
    for(JBoImageEditRectangleCell *cell in self.rectangleCells)
    {
        [self.backgroundView bringSubviewToFront:cell];
    }
}

#pragma mark- 箭头

//初始化箭头选项
- (void)initlizationArrowItems
{
    UIScrollView *arrowScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.bounds.size.width, self.menuContainer.bounds.size.height - self.toolBar.height)];
    arrowScrollView.backgroundColor = self.imageEditor.menuScrollView.backgroundColor;
    arrowScrollView.showsHorizontalScrollIndicator = NO;
    arrowScrollView.showsVerticalScrollIndicator = NO;
    [self.menuContainer addSubview:arrowScrollView];
    self.arrowScrollView = arrowScrollView;
    [arrowScrollView release];
    
    self.arrows = [NSMutableArray array];
    CGFloat size = 48.0;
    
    //创建文字输入框添加按钮
    JBoImageGraphMenuItem *item = [[JBoImageGraphMenuItem alloc] initWithFrame:CGRectMake(0, 0, size, size) style:JBoImageGraphToolMenuItemStyleAdd];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(arrowDidAdd:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.tag = _arrowAddTag_;
    [self.arrowScrollView addSubview:item];
    [item release];
    
    self.selectedArrowIndex = NSNotFound;
    [self.arrowScrollView setContentSize:CGSizeMake(size * 1, self.arrowScrollView.bounds.size.height)];
}

//添加箭头
- (void)arrowDidAdd:(id) sender
{
    CGFloat interval = 5.0;
    
    JBoImageGraphMenuItem *addItem = (JBoImageGraphMenuItem*)[self.arrowScrollView viewWithTag:_arrowAddTag_];
    
    JBoImageGraphMenuItem *item = [[JBoImageGraphMenuItem alloc] initWithFrame:addItem.frame style:JBoImageGraphToolMenuItemStyleArrow];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(arrowDidSelected:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.selected = YES;
    item.tag = _arrowStartTag_ + self.arrows.count;
    [self.arrowScrollView addSubview:item];
    [item release];
    
    addItem.left = item.right + interval;
    
    
    //添加箭头
    JBoImageEditArrowCell *cell = [[JBoImageEditArrowCell alloc] initWithFrame:CGRectMake(30.0, 30.0, 100, 60.0) contentPadding:_width_ * (1.0 - _adjustZoomScale_)];
    cell.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    cell.index = self.arrows.count;
    cell.preventsPositionOutsideSuperview = NO;
    cell.delegate = self;
    cell.userInteractionEnabled = YES;
    
    [self.backgroundView addSubview:cell];
    cell.selected = YES;
    [cell release];
    
    [self.arrows addObject:cell];
    
    NSInteger count = addItem.hidden ? self.arrows.count : self.arrows.count + 1;
    
    [self.arrowScrollView setContentSize:CGSizeMake(item.width * count, self.arrowScrollView.bounds.size.height)];
    
    if(self.arrows.count == _arrowMaxCount_)
    {
        addItem.hidden = YES;
    }
    
    self.selectedArrowIndex = self.arrows.count - 1;
    self.selectedRectangleIndex = NSNotFound;
    self.selectedColorPieceIndex = NSNotFound;
    
    [self setupRectanglePositon];
}

//移除箭头
- (void)removeArrowAtIndex:(NSInteger) index
{
    CGFloat interval = 5.0;
    
    //从父视图中移除
    JBoImageGraphMenuItem *item = (JBoImageGraphMenuItem*)[self.arrowScrollView viewWithTag:_arrowStartTag_ + index];
    CGFloat x = item.left;
    
    //移动后面的item
    for(NSInteger i = index + 1;i < self.arrows.count;i ++)
    {
        JBoImageGraphMenuItem *backItem = (JBoImageGraphMenuItem*)[self.arrowScrollView viewWithTag:_arrowStartTag_ + i];
        backItem.left = x;
        backItem.tag = _arrowStartTag_ + i - 1;
        x = backItem.right + interval;
        
        JBoImageEditArrowCell *cell = [self.arrows objectAtIndex:i];
        cell.index = i - 1;
    }
    
    JBoImageGraphMenuItem *addItem = (JBoImageGraphMenuItem*)[self.arrowScrollView viewWithTag:_arrowAddTag_];
    addItem.left = x;
    
    //如果添加按钮已隐藏 显示它
    addItem.hidden = NO;
    [self.arrowScrollView setContentSize:CGSizeMake(item.width * (self.arrows.count + 1), self.arrowScrollView.bounds.size.height)];
    [item removeFromSuperview];
}

//选择箭头
- (void)setSelectedArrowIndex:(NSInteger)selectedArrowIndex
{
    //取消以前的选择
    if(_selectedArrowIndex < self.arrows.count)
    {
        JBoImageEditArrowCell *cell = [self.arrows objectAtIndex:_selectedArrowIndex];
        cell.selected = NO;
    }
    
    JBoImageGraphMenuItem *oldItem = (JBoImageGraphMenuItem*)[self.arrowScrollView viewWithTag:_arrowStartTag_ + _selectedArrowIndex];
    oldItem.selected = NO;
    
    //确定当前的选择
    _selectedArrowIndex = selectedArrowIndex;
    
    JBoImageGraphMenuItem *curItem = (JBoImageGraphMenuItem*)[self.arrowScrollView viewWithTag:_arrowStartTag_ + _selectedArrowIndex];
    curItem.selected = YES;
    
    if(_selectedArrowIndex < self.arrows.count)
    {
        JBoImageEditArrowCell *cell = [self.arrows objectAtIndex:_selectedArrowIndex];
        cell.selected = YES;
    }
}

//选择色块
- (void)arrowDidSelected:(UITapGestureRecognizer*) tap
{
    NSInteger index = tap.view.tag - _arrowStartTag_;
    self.selectedArrowIndex = index;
}


#pragma mark- 色块

//初始化色块选项
- (void)initlizationColorPieceItems
{
    UIScrollView *colorPieceScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.menuContainer.bounds.size.width, self.menuContainer.bounds.size.height - self.toolBar.height)];
    colorPieceScrollView.backgroundColor = self.imageEditor.menuScrollView.backgroundColor;
    colorPieceScrollView.showsHorizontalScrollIndicator = NO;
    colorPieceScrollView.showsVerticalScrollIndicator = NO;
    [self.menuContainer addSubview:colorPieceScrollView];
    self.colorPieceScrollView = colorPieceScrollView;
    [colorPieceScrollView release];
    
    self.colorPieces = [NSMutableArray array];
    CGFloat size = 48.0;
    
    //创建文字输入框添加按钮
    JBoImageGraphMenuItem *item = [[JBoImageGraphMenuItem alloc] initWithFrame:CGRectMake(0, 0, size, size) style:JBoImageGraphToolMenuItemStyleAdd];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(colorPieceDidAdd:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.tag = _colorPieceAddTag_;
    [self.colorPieceScrollView addSubview:item];
    [item release];
    
    self.selectedColorPieceIndex = NSNotFound;
    [self.colorPieceScrollView setContentSize:CGSizeMake(size * 1, self.colorPieceScrollView.bounds.size.height)];
}

//添加色块
- (void)colorPieceDidAdd:(id) sender
{
    CGFloat interval = 5.0;
    
    JBoImageGraphMenuItem *addItem = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceAddTag_];
    
    JBoImageGraphMenuItem *item = [[JBoImageGraphMenuItem alloc] initWithFrame:addItem.frame style:JBoImageGraphToolMenuItemStyleColorPiece];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(colorPieceDidselected:)];
    [item addGestureRecognizer:tap];
    [tap release];
    item.selected = YES;
    item.tag = _colorPieceStartTag_ + self.colorPieces.count;
    [self.colorPieceScrollView addSubview:item];
    [item release];
    
    addItem.left = item.right + interval;
    
    
    //添加色块
    
    JBoImageEditBackgroundCell *cell = [[JBoImageEditBackgroundCell alloc] initWithFrame:CGRectMake(30.0, 30.0, 150.0, _cellDefaultHeight_) contentPadding:_width_ * (1.0 - _adjustZoomScale_)];
    cell.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    cell.index = self.colorPieces.count;
    cell.preventsPositionOutsideSuperview = YES;
    cell.editable = YES;
    cell.delegate = self;
    cell.contentView.backgroundColor = [UIColor colorWithWhite:0 alpha:0.3];
    cell.userInteractionEnabled = YES;
    
    [self.backgroundView addSubview:cell];
    cell.selected = YES;
    [cell release];
    
    [self.colorPieces addObject:cell];
    
    NSInteger count = addItem.hidden ? self.colorPieces.count : self.colorPieces.count + 1;
    
    [self.colorPieceScrollView setContentSize:CGSizeMake(item.width * count, self.colorPieceScrollView.bounds.size.height)];
    
    [self setColorPieceColorAtIndex:self.colorPieces.count - 1];
    
    if(self.colorPieces.count == _colorPieceMaxCount_)
    {
        addItem.hidden = YES;
    }
    
    self.selectedColorPieceIndex = self.colorPieces.count - 1;
    self.selectedArrowIndex = NSNotFound;
    self.selectedRectangleIndex = NSNotFound;
}

//移除色块
- (void)removeColorPieceAtIndex:(NSInteger) index
{
    CGFloat interval = 5.0;
    
    //从父视图中移除
    JBoImageGraphMenuItem *item = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceStartTag_ + index];
    CGFloat x = item.left;
    
    //移动后面的item
    for(NSInteger i = index + 1;i < self.colorPieces.count;i ++)
    {
        JBoImageGraphMenuItem *backItem = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceStartTag_ + i];
        backItem.left = x;
        backItem.tag = _colorPieceStartTag_ + i - 1;
        x = backItem.right + interval;
        
        JBoImageEditBackgroundCell *cell = [self.colorPieces objectAtIndex:i];
        cell.index = i - 1;
    }
    
    JBoImageGraphMenuItem *addItem = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceAddTag_];
    addItem.left = x;
    
    //如果添加按钮已隐藏 显示它
    addItem.hidden = NO;
    [self.colorPieceScrollView setContentSize:CGSizeMake(item.width * (self.colorPieces.count + 1), self.colorPieceScrollView.bounds.size.height)];
    [item removeFromSuperview];
}

//选择色块
- (void)setSelectedColorPieceIndex:(NSInteger)selectedColorPieceIndex
{
    //取消以前的选择
    if(_selectedColorPieceIndex < self.colorPieces.count)
    {
        JBoImageEditBackgroundCell *cell = [self.colorPieces objectAtIndex:_selectedColorPieceIndex];
        cell.selected = NO;
    }
    
    JBoImageGraphMenuItem *oldItem = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceStartTag_ + _selectedColorPieceIndex];
    oldItem.selected = NO;
    
    //确定当前的选择
    _selectedColorPieceIndex = selectedColorPieceIndex;
    
    JBoImageGraphMenuItem *curItem = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceStartTag_ + _selectedColorPieceIndex];
    curItem.selected = YES;
    
    if(_selectedColorPieceIndex < self.colorPieces.count)
    {
        JBoImageEditBackgroundCell *cell = [self.colorPieces objectAtIndex:_selectedColorPieceIndex];
        cell.selected = YES;
    }
}

//选择色块
- (void)colorPieceDidselected:(UITapGestureRecognizer*) tap
{
    NSInteger index = tap.view.tag - _colorPieceStartTag_;
    self.selectedColorPieceIndex = index;
}

//设置色块颜色
- (void)setColorPieceColorAtIndex:(NSInteger) index
{
    if(index < self.colorPieces.count && self.backgroundColorPicker)
    {
        JBoImageEditBackgroundCell *cell = [self.colorPieces objectAtIndex:index];
        
        cell.contentView.backgroundColor = self.backgroundColorPicker.selectedColor;
        JBoImageGraphMenuItem *item = (JBoImageGraphMenuItem*)[self.colorPieceScrollView viewWithTag:_colorPieceStartTag_ + index];
        item.colorPieceView.backgroundColor = cell.contentView.backgroundColor;
    }
}

#pragma mark- 色块颜色选择

//背景颜色选择
- (void)backgroundColorValueDidChanged:(JBoColorPicker*) colorPicker
{
    [self setColorPieceColorAtIndex:self.selectedColorPieceIndex];
    self.inputView.currentColor = colorPicker.selectedColor;
}

//背景颜色透明度选择
- (void)backgroundColorAlphaValueDidChanged:(UISlider*) slider
{
    NSDictionary *dic = [self.backgroundColorPicker.selectedColor getColorRGB];
    
    UIColor *color = nil;
    self.backgroundColorPicker.colorAlpha = slider.value;
    if(dic)
    {
        
        color = [UIColor colorWithRed:[[dic objectForKey:_colorRedKey_] floatValue] green:[[dic objectForKey:_colorGreenKey_] floatValue] blue:[[dic objectForKey:_colorBlueKey_] floatValue] alpha:slider.value];
    }
    else
    {
        color = [UIColor colorWithHue:0 saturation:0 brightness:self.backgroundColorPicker.white alpha:slider.value];
    }
    
    self.backgroundColorPicker.selectedColor = color;
    
    [self setColorPieceColorAtIndex:self.selectedColorPieceIndex];
}


#pragma mark- JBoRGBAInputView代理

- (void)RGBAInputView:(JBoRGBAInputView *)inputView colorDidChanged:(UIColor *)color
{
    if(self.toolBar.selectedIndex != 4)
    {
        [self.colorPicker setColor:color];
        [self colorValueDidChanged:self.colorPicker];
    }
    else
    {

        [self.backgroundColorPicker setColor:color];
        [self backgroundColorValueDidChanged:self.backgroundColorPicker];
    }
}


#pragma mark- JBoImageEditBaseCell delegate

- (void)cellDidClose:(JBoImageEditBaseCell *)cell
{
    if([cell isKindOfClass:[JBoImageEditRectangleCell class]])
    {
        [self removeRectangleAtIndex:cell.index];
        [self.rectangleCells removeObject:cell];
        [cell removeFromSuperview];
        self.selectedRectangleIndex = NSNotFound;
    }
    else if ([cell isKindOfClass:[JBoImageEditArrowCell class]])
    {
        [self removeArrowAtIndex:cell.index];
        [self.arrows removeObject:cell];
        [cell removeFromSuperview];
        self.selectedArrowIndex = NSNotFound;
    }
    else if ([cell isKindOfClass:[JBoImageEditBackgroundCell class]])
    {
        [self removeColorPieceAtIndex:cell.index];
        [self.colorPieces removeObject:cell];
        [cell removeFromSuperview];
        self.selectedColorPieceIndex = NSNotFound;
    }
}

- (void)cellDidSelected:(JBoImageEditBaseCell *)cell
{
    if([cell isKindOfClass:[JBoImageEditRectangleCell class]])
    {
        if(self.selectedRectangleIndex != cell.index)
        {
            self.selectedRectangleIndex = cell.index;
        }
        else
        {
            self.selectedRectangleIndex = NSNotFound;
        }
        self.selectedArrowIndex = NSNotFound;
        self.selectedColorPieceIndex = NSNotFound;
    }
    else if ([cell isKindOfClass:[JBoImageEditArrowCell class]])
    {
        if(self.selectedArrowIndex != cell.index)
        {
            self.selectedArrowIndex = cell.index;
        }
        else
        {
            self.selectedArrowIndex = NSNotFound;
        }
        self.selectedRectangleIndex = NSNotFound;
        self.selectedColorPieceIndex = NSNotFound;
    }
    else if ([cell isKindOfClass:[JBoImageEditBackgroundCell class]])
    {
        if(self.selectedColorPieceIndex != cell.index)
        {
            self.selectedColorPieceIndex = cell.index;
        }
        else
        {
            self.selectedColorPieceIndex = NSNotFound;
        }
        self.selectedRectangleIndex = NSNotFound;
        self.selectedArrowIndex = NSNotFound;
    }
}


@end
