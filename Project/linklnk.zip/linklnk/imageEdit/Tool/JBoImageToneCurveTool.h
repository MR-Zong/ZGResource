//
//  JBoImageToneCurveTool.h
//  靓咖
//
//  Created by kinghe005 on 14-5-30.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditToolBase.h"

/**色彩调整
 */
@interface JBoImageToneCurveTool : JBoImageEditToolBase

@end
