//
//  JBoImageEditToolBase.m
//  靓咖
//
//  Created by kinghe005 on 14-5-27.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditToolBase.h"
#import "JBoAppDelegate.h"

@interface JBoImageEditToolBase ()
{
    JBoAppDelegate *_appDelegate;
}
@end

@implementation JBoImageEditToolBase

//编辑器 工具图标
+ (NSArray*)imageEditToolIcons
{
    return [NSArray arrayWithObjects:
            @"imageEditor_color", @"imageEditor_filter", @"imageEditor_rotate", @"imageEditor_crop", @"imageEditor_brush", @"imageEditor_watermark", @"imageEditor_text", @"imageEditor_graph", nil];
}

+ (NSArray*)imageEditToolTitles
{
    return [NSArray arrayWithObjects:
            @"色彩", @"滤镜", @"旋转", @"剪裁", @"画笔", @"拼图", @"文字", @"图形", nil];
}

- (id)initWithImageEditor:(JBoImageEditorViewController *)editor
{
    self = [super init];
    if(self)
    {
        _appDelegate = (JBoAppDelegate*)[UIApplication sharedApplication].delegate;
        
        self.imageEditor = editor;
        self.originalImage = editor.editImageView.image;
        
        _menuContainer = [[UIView alloc] initWithFrame:CGRectMake(0, _height_, self.imageEditor.scrollView.width, _menuHeight_)];
        _menuContainer.backgroundColor = [UIColor clearColor];;
        [self.imageEditor.view addSubview:_menuContainer];
        
//        CGFloat lineHeight = 0.5;
//        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, - lineHeight, self.menuContainer.bounds.size.width, lineHeight)];
//        lineView.backgroundColor = [UIColor lightGrayColor];
//        [_menuContainer addSubview:lineView];
//        [lineView release];
//        self.lineView = lineView;
        
        [self initilization];
    }
    return self;
}

- (void)dealloc
{
    _imageEditor = nil;
    [_originalImage release];
    [_menuContainer release];
    [_lineView release];
    
    [super dealloc];
}

//初始化工具
- (void)initilization
{
    
}

//开始编辑
- (void)beginEdit
{
    [UIView animateWithDuration:0.25 animations:^(void){
        self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, self.imageEditor.memuOringinalY, self.menuContainer.frame.size.width, self.menuContainer.frame.size.height);
    }];
}

//编辑完成
- (void)endEdit
{
    self.menuContainer.userInteractionEnabled = NO;
}

//编辑撤销
- (void)close
{
    [self endRender];
    [UIView animateWithDuration:0.25 animations:^(void){
        self.menuContainer.frame = CGRectMake(self.menuContainer.frame.origin.x, _height_, self.menuContainer.frame.size.width, self.menuContainer.frame.size.height);
    } completion:^(BOOL finish){
        [self.menuContainer removeFromSuperview];
    }];
    [self.imageEditor.scrollView setZoomScale:self.imageEditor.scrollView.minimumZoomScale animated:YES];
}

//开始渲染
- (void)beginRender
{
    _appDelegate.dataLoadingView.hidden = NO;
}

- (void)endRender
{
    _appDelegate.dataLoadingView.hidden = YES;
}

//获取图片
- (UIImage*)getComponentImageWithType:(JBoImageEditType)type
{
    UIView *view = self.imageEditor.editImageView;
    
    CALayer *layer = view.layer;
    CGSize size = CGSizeMake(floorf(layer.frame.size.width), floorf(layer.frame.size.height));
    
    UIGraphicsBeginImageContextWithOptions(size, view.opaque, 0.0f);
    
    [layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage *retImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    //NSLog(@"retImage %f,%f", retImage.size.width, retImage.size.height);
    
    return retImage;
}

- (void)layoutSublayersOfLayer:(CALayer *)layer withScale:(CGFloat) scale
{
    for(CALayer *sublayer in layer.sublayers)
    {
        CGRect rect = sublayer.frame;
        
        rect.origin.x *= scale;
        rect.origin.y *= scale;
        rect.size.width *= scale;
        rect.size.height *= scale;
        
        sublayer.frame = rect;
    }
}

@end
