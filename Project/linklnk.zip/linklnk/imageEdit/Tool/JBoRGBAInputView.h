//
//  JBoRGBAInputView.h
//  靓咖
//
//  Created by kinghe005 on 14-9-6.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _RGBAInputViewDefaultWidth_ 50.0

@class JBoRGBAInputView;

@protocol JBoRGBAInputViewDelegate <NSObject>

/**颜色值改变
 */
- (void)RGBAInputView:(JBoRGBAInputView*) inputView colorDidChanged:(UIColor*) color;

@end

/**R、G、B、A 颜色输入和显示框
 */
@interface JBoRGBAInputView : UIView<UITextFieldDelegate>

/**当前颜色
 */
@property(nonatomic,assign) UIColor *currentColor;

/**是否有透明度 default is 'NO'
 */
@property(nonatomic,assign) BOOL hasAlpha;

@property(nonatomic,assign) id<JBoRGBAInputViewDelegate> delegate;

@end
