//
//  JBoHuePickerView.h
//  靓咖
//
//  Created by kinghe005 on 14-8-22.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JBoHuePickerView;

@protocol JBoHuePickerViewDelegate <NSObject>

/**选择色彩
 */
- (void)huePickerView:(JBoHuePickerView*) pickerView didSelectHue:(CGFloat) hue;

@end

/**颜色色彩选择器
 */
@interface JBoHuePickerView : UIView

@property(nonatomic,assign) id<JBoHuePickerViewDelegate> delegate;

/**色彩 default is '0.5'
 */
@property(nonatomic,assign) CGFloat hue;

/**当前选择的颜色
 */
@property(nonatomic,assign) UIColor *color;

@end
