//
//  JBoColorPicker.h
//  靓咖
//
//  Created by kinghe005 on 14-5-29.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _colorPickerDefaultWidth_ 310.0
#define _colorPickerDefaultHeight_ 30.0

//颜色选中指示器
@interface JBoColorIndicator : UIView

//内部填充颜色
@property(nonatomic,retain) UIColor *fillColor;
//内部边框颜色
@property(nonatomic,retain) UIColor *innerBorderColor;
//外部边框颜色
@property(nonatomic,retain) UIColor *outerBorderColor;
//边框宽度
@property(nonatomic,assign) CGFloat borderWidth;

@end

//颜色条
@interface JBoColorBarView : UIView

@end

//颜色选择器
@interface JBoColorPicker : UIControl
{
    JBoColorIndicator *_indicator;
    JBoColorBarView *_colorBarView;
}

/**当前的值
 */
@property(nonatomic,assign) float value;
/**当前颜色 default is  [UIColor colorWithWhite:0.0 alpha:self.colorAlpha];
 */
@property(nonatomic,retain) UIColor *selectedColor;
/**颜色透明度 default is '0.0f'
 */
@property(nonatomic,assign) CGFloat colorAlpha;

/**颜色白色比例 当选择的颜色不是彩色时用到 default is '0.0'
 */
@property(nonatomic,assign) CGFloat white;

/**设置颜色
 */
- (void)setColor:(UIColor*) color;


@end
