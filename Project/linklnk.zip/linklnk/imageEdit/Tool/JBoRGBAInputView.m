//
//  JBoRGBAInputView.m
//  靓咖
//
//  Created by kinghe005 on 14-9-6.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoRGBAInputView.h"
#import "JBoBasic.h"

#define _controlHeight_ 18.0
#define _controlInterval_ 5.0

@interface JBoRGBAInputView ()

/**red
 */
@property(nonatomic,retain) UITextField *redTextField;

/**green
 */
@property(nonatomic,retain) UITextField *greenTextField;

/**blue
 */
@property(nonatomic,retain) UITextField *blueTextField;

/**alpha
 */
@property(nonatomic,retain) UITextField *alphaTextField;

/**键盘的inputView
 */
@property(nonatomic,retain) UIView *inputAccessoryView;

@end

@implementation JBoRGBAInputView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, 35.0)];
        view.backgroundColor = [UIColor colorWithWhite:0.9 alpha:1.0];
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 150.0, view.height)];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor blackColor];
        label.font = [UIFont systemFontOfSize:14.0];
        label.text = @"请输入0~255间的数";
        [view addSubview:label];
        [label release];
        
        CGFloat buttonWidth = 60.0;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [button setTitle:@"完成" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(inputFinish:) forControlEvents:UIControlEventTouchUpInside];
        [button setFrame:CGRectMake(_width_ - buttonWidth, 0, buttonWidth, 35.0)];
        [view addSubview:button];
        
        self.inputAccessoryView = view;
        [view release];
        
        self.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
        
        self.redTextField = [self textFieldWithTitle:@"R:"];
        
        self.greenTextField = [self textFieldWithTitle:@"G:"];
        self.greenTextField.top = self.redTextField.bottom + _controlInterval_;
        
        self.blueTextField = [self textFieldWithTitle:@"B:"];
        self.blueTextField.top = self.greenTextField.bottom + _controlInterval_;
        
        self.height = self.blueTextField.bottom;
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_redTextField release];
    [_blueTextField release];
    [_greenTextField release];
    
    [_alphaTextField release];
    
    self.delegate = nil;
    [_inputAccessoryView release];
    
    [super dealloc];
}

#pragma mark- property

- (void)setCurrentColor:(UIColor *)currentColor
{
    if(currentColor == nil)
        return;
    NSDictionary *dic = [currentColor getColorRGB];

    if(dic == nil)
        return;
    
    int red = ceil([[dic objectForKey:_colorRedKey_] floatValue] * 255);
    self.redTextField.text = [NSString stringWithFormat:@"%d", red];
    
    int green = ceil([[dic objectForKey:_colorGreenKey_] floatValue] * 255);
    self.greenTextField.text = [NSString stringWithFormat:@"%d", green];
    
    int blue = ceil([[dic objectForKey:_colorBlueKey_] floatValue] * 255);
    self.blueTextField.text = [NSString stringWithFormat:@"%d", blue];
    
    int alpha = ceil([[dic objectForKey:_colorAlphaKey_] floatValue] * 255);
    self.alphaTextField.text = [NSString stringWithFormat:@"%d", alpha];
}

- (UIColor*)currentColor
{
    CGFloat red = [self.redTextField.text intValue] / 255.0;
    CGFloat green = [self.greenTextField.text intValue] / 255.0;
    CGFloat blue = [self.blueTextField.text intValue] / 255.0;
    CGFloat alpha = 1.0;
    if(self.alphaTextField)
    {
        alpha = [self.alphaTextField.text intValue] / 255.0;
    }
    
    return [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
}

#pragma mark- private method

/**创建textField
 *@param title 输入框左边标题
 */
- (UITextField*)textFieldWithTitle:(NSString*) title;
{
    UIFont *font = [UIFont systemFontOfSize:13.0];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 20.0, _controlHeight_)];
    label.backgroundColor = [UIColor clearColor];
    label.text = title;
    label.textColor = [UIColor whiteColor];
   // label.textAlign = JBoTextAlignmentRight;
    label.font = font;
    
    UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, self.width, _controlHeight_)];
    textField.delegate = self;
    textField.textColor = label.textColor;
    textField.backgroundColor = [UIColor clearColor];
    textField.borderStyle = UITextBorderStyleNone;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    textField.keyboardType = UIKeyboardTypeNumberPad;
    textField.returnKeyType = UIReturnKeyDone;
    textField.leftView = label;
   // textField.placeholder = @"请输入0~255间的数";
    textField.font = font;
    textField.leftViewMode = UITextFieldViewModeAlways;
    textField.inputAccessoryView = self.inputAccessoryView;
    [self addSubview:textField];
    [label release];
    
    return [textField autorelease];
}

- (void)inputFinish:(id) sender
{
    [[UIApplication sharedApplication].keyWindow endEditing:YES];
    if([self.delegate respondsToSelector:@selector(RGBAInputView:colorDidChanged:)])
    {
        [self.delegate RGBAInputView:self colorDidChanged:self.currentColor];
    }
}

#pragma mark- textField代理

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    int value = [textField.text intValue];
    if(value == 0)
    {
        textField.text = nil;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if([NSString isEmpty:textField.text])
    {
        textField.text = @"0";
        return;
    }
    
    NSInteger num = [textField.text integerValue];
    if(num > 255)
    {
        textField.text = @"255";
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if([self.delegate respondsToSelector:@selector(RGBAInputView:colorDidChanged:)])
    {
        [self.delegate RGBAInputView:self colorDidChanged:self.currentColor];
    }
    
    return YES;
}

@end
