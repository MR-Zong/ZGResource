//
//  JBoDrawDreamSceneScrollView.h
//  连客
//
//  Created by kinghe005 on 13-12-28.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>

#define _JBoImageEditWatermarkCellSize_ 60.0
#define _JBoImageEditWatermarkCellMargin_ 5.0

/**水印cell
 */
@interface JBoImageEditWatermarkCell : UITableViewCell

/**水印图片
 */
@property(nonatomic,readonly) UIImageView *singleImageView;

/**构造方法
 *@param reuseIdentifier 复用标识
 *@param width 宽度
 *@return 一个实例
 */
- (id)initWithReuseIdentifier:(NSString *)reuseIdentifier width:(CGFloat) width;

@end


@class JBoImageEditWatermarkScrollView;

/**水印选择菜单 代理
 */
@protocol JBoImageEditWatermarkScrollViewDelegte <NSObject>

/**选择某个水印
 *@param image 选择的水印图片，如果nil,则可以从相册中选择或拍照
 */
- (void)imageEditWatermarkScrollView:(JBoImageEditWatermarkScrollView*) sceneScrollView didSelectedImage:(UIImage*) image;

@end

/**水印选择菜单
 */
@interface JBoImageEditWatermarkScrollView : UIView<UITableViewDelegate,UITableViewDataSource>
{
    //水印列表
    UITableView *_tableView;
    
    //加载指示器
    UIActivityIndicatorView *_actView;
}

/**水印数据源 数组元素是 JBoImageEditWartermarkInfo
 */
@property(nonatomic,retain) NSMutableArray *srcArray;

@property(nonatomic,assign) id<JBoImageEditWatermarkScrollViewDelegte> delegate;

/**是否正在加载
 */
@property(nonatomic,assign) BOOL loading;

/**加载完成
 */
- (void)loadingDidFinished;

@end
