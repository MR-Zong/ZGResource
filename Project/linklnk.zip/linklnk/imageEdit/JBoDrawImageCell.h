//
//  JBoDrawImageCell.h
//  连客
//
//  Created by kinghe005 on 13-12-28.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoDrawDreamBorderView.h"
#import "JBoBrushView.h"
#import "JBoCustomInsetLabel.h"
#import "JBoImageEditBaseCell.h"

/**画图内容的显示视图
 */
@interface JBoDrawImageCellBrushView : UIView

/**画图生成的图片
 */
@property(nonatomic,retain) UIImage *image;

/**当前画笔工具
 */
@property(nonatomic,retain) id<JBoBrushTool> brushTool;

/**画笔的路径集合 数组内容 是实现JBoBrushTool协议的对象
 */
@property(nonatomic,retain) NSMutableArray *pathArray;

/**撤销
 */
- (void)undo;

/**是否能够撤销
 */
- (BOOL)canUndo;

/**更新画的内容
 *@param redraw 是否需要重画所有路径
 */
- (void)updataImage:(BOOL) redraw;

@end

@class JBoDrawImageCellContentView;

/**图片编辑内容代理
 */
@protocol JBoDrawImageCellContentViewDelegate <NSObject>

@optional
/**开始输入文字
 */
- (void)contentViewDidBeginInputText:(JBoDrawImageCellContentView*) contentView;

@end

/**图片编辑内容
 */
@interface JBoDrawImageCellContentView : UIImageView

/**文本显示标签
 */
@property(nonatomic,readonly) JBoCustomInsetLabel *label;

/**是否可输入文本
 */
@property(nonatomic,assign) BOOL editable;

/**是否存在文本
 */
@property(nonatomic,assign) BOOL hasText;
@property(nonatomic,assign) id<JBoDrawImageCellContentViewDelegate> delegate;

@end

#pragma mark- cell

@class JBoDrawImageCell;

/**可编辑cell的代理
 */
@protocol JBoDrawImageCellDelegate <NSObject>

@optional

/**开始编辑 触摸开始
 */
- (void)cellDidBeginEditing:(JBoDrawImageCell *) cell;

/**结束编辑 触摸结束
 */
- (void)cellDidEndEditing:(JBoDrawImageCell *) cell;

/**触摸移动
 */
- (void)cellDidMoved:(JBoDrawImageCell*) cell;

/**取消编辑 触摸取消
 */
- (void)cellDidCancelEditing:(JBoDrawImageCell *) cell;

/**cell关闭，从父视图上移除
 */
- (void)cellDidClose:(JBoDrawImageCell *) cell;

/**选中cell
 */
- (void)cellDidSelected:(JBoDrawImageCell *) cell;

/**锁住cell 此时cell无法移动 编辑 缩放
 */
- (void)celldidLocked:(JBoDrawImageCell *) cell;

/**cell被双击
 */
- (void)cellDidDoubleTapped:(JBoDrawImageCell*) cell;

/**cell开始输入文本
 */
- (void)cellDidBeganInputText:(JBoDrawImageCell *) cell;

/**cell 结束画图
 */
- (void)cellDidEndDraw:(JBoDrawImageCell*) cell;

@end

/**图片编辑cell，如用在图片编辑中的水印编辑
 */
@interface JBoDrawImageCell : UIView<UIGestureRecognizerDelegate, JBoDrawImageCellContentViewDelegate>
{
    //边框
    JBoDrawDreamBorderView *_borderView;
}

/**cell内容
 */
@property(nonatomic, readonly) JBoDrawImageCellContentView *contentImageView;

/**cell的内容图片
 */
@property(nonatomic, retain) UIImage *contentImage;

/**cell的内容图片 为圆形
 */
@property (retain, nonatomic) UIImage *circleImage;

/**画图的画板
 */
@property(nonatomic, retain) JBoDrawImageCellBrushView *brushView;

/**是否正在画图 default is 'NO'
 */
@property(nonatomic, assign) BOOL burshing;

/**画图生成的图片
 */
@property(nonatomic, retain) UIImage *drawImage;

/**画笔的颜色
 */
@property(nonatomic, retain) UIColor *selectedColor;

/**画笔线的宽度
 */
@property(nonatomic, assign) CGFloat lineWidth;

/**画图模式
 */
@property(nonatomic, assign) CGBlendMode blendMode;

/**cell是否被锁住 default is 'NO'
 */
@property(nonatomic, assign) BOOL lock;

/**是否阻止cell被拖出父视图 default is 'YES'
 */
@property (nonatomic, assign) BOOL preventsPositionOutsideSuperview;

/**是否阻止缩放cell default is 'NO'
 */
@property (nonatomic, assign) BOOL preventsResizing;

/**是否阻止删除cell default is 'NO'
 */
@property (nonatomic, assign) BOOL preventsDeleting;

/**cell的最小宽度
 */
@property (nonatomic, assign) CGFloat minWidth;

/**cell的最小高度
 */
@property (nonatomic, assign) CGFloat minHeight;

/**cell的最大缩放比例
 */
@property (nonatomic,assign) CGFloat maxScale;

/**是否允许编辑 default is 'YES'
 */
@property (nonatomic, assign) BOOL editable;

/**是否输入文本 default is 'NO'
 */
@property (nonatomic, assign) BOOL inputText;

/**是否圆角 default is 'NO'
 */
@property (nonatomic, assign) BOOL corners;

/**隐藏删除按钮
 */
- (void)hideDelHandle;

/**显示删除按钮
 */
- (void)showDelHandle;
//- (void)hideEditingHandles;
//- (void)showEditingHandles;

/**是否被选中 default is 'NO'
 */
@property(nonatomic,assign) BOOL selected;

@property(nonatomic,assign) id<JBoDrawImageCellDelegate> delegate;

/**cell的标识
 */
@property(nonatomic,copy) NSString *identifier;

/**初始化一个cell
 *param frame cell的位置大小
 *param padding cell的内容的边距
 */
- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat) padding;

@end
