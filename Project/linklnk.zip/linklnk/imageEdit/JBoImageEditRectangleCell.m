//
//  JBoImageEditRectangleCell.m
//  linklnk
//
//  Created by kinghe005 on 15/4/17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoImageEditRectangleCell.h"

@implementation JBoImageEditRectangleCell

- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat)padding
{
    self = [super initWithFrame:frame contentPadding:padding];
    if (self)
    {
        [self setupDefaultAttributes];
        
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_rectangleColor release];
    
    [super dealloc];
}

#pragma mark- property

- (void)setRectangleColor:(UIColor *)rectangleColor
{
    if(![_rectangleColor isEqualToColor:rectangleColor])
    {
        [_rectangleColor release];
        _rectangleColor = [rectangleColor retain];
        self.borderView.borderColor = _rectangleColor;
    }
}

#pragma mark- super method

- (void)setupDefaultAttributes
{
    [super setupDefaultAttributes];
    self.rectangleColor = [UIColor redColor];
    [self.rotateControl removeFromSuperview];
    self.rotateControl = nil;
}

- (void)hideEditingHandles
{
    [super hideEditingHandles];
    self.borderView.hidden = NO;
}

- (void)selectedTap:(id)sender
{
    self.selected = !self.selected;
    if([self.delegate respondsToSelector:@selector(cellDidSelected:)])
    {
        [self.delegate cellDidSelected:self];
    }
}

@end
