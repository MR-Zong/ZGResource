//
//  JBoBrushScrollView.m
//  连你
//
//  Created by kinghe005 on 14-1-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoBrushScrollView.h"
#import <QuartzCore/QuartzCore.h>

#define _controlInterval_ 10.0
#define _controlHeight_ 20.0
#define _colorScrollViewHeight_ 70.0

#define _startTag_ 1000

@implementation JBoBrushCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.borderColor = [UIColor grayColor];
        self.borderWidth = 2.0;
        self.backgroundColor = [UIColor clearColor];
        _borderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        _borderView.layer.borderWidth = self.borderWidth;
        _borderView.layer.borderColor = self.borderColor.CGColor;
        [self addSubview:_borderView];
        
        _innerView = [[UIView alloc] initWithFrame:CGRectMake(self.borderWidth, self.borderWidth, frame.size.width - self.borderWidth * 2, frame.size.height - self.borderWidth * 2)];
        [self addSubview:_innerView];
    }
    return self;
}

- (void)setSelected:(BOOL)selected
{
    _selected = selected;
    _borderView.layer.borderColor = _selected ? self.selectedBorderColor.CGColor : self.borderColor.CGColor;
}

- (void)setBorderColor:(UIColor *)borderColor
{
    if(_borderColor != borderColor)
    {
        [_borderColor release];
        _borderColor = [borderColor retain];
        _borderView.layer.borderColor = _borderColor.CGColor;
    }
}

- (void)setBorderWidth:(CGFloat)borderWidth
{
    if(_borderWidth != borderWidth)
    {
        _borderWidth = borderWidth;
        _borderView.layer.borderWidth = _borderWidth;
    }
}

- (void)dealloc
{
    [_borderView release];
    [_innerView release];
    [_borderColor release];
    [_selectedBorderColor release];
    
    [super dealloc];
}

@end

@interface JBoBrushScrollView ()

@property(nonatomic,retain) JBoBrushCell *selectedCell;

@end

@implementation JBoBrushScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        CGFloat lineLabelWidth = 40.0;
        _lineWidhtLabel = [[UILabel alloc] initWithFrame:CGRectMake(_controlInterval_, 0, lineLabelWidth, _controlHeight_)];
        _lineWidhtLabel.backgroundColor = [UIColor clearColor];
        _lineWidhtLabel.textColor = [UIColor whiteColor];
        [_lineWidhtLabel setTextAlign:JBoTextAlignmentCenter];
        [self addSubview:_lineWidhtLabel];
        
        _lineWidhtSlider = [[UISlider alloc] initWithFrame:CGRectMake(lineLabelWidth + _controlInterval_, 5, frame.size.width - _controlInterval_ * 3 - lineLabelWidth, _controlHeight_)];
        [_lineWidhtSlider addTarget:self action:@selector(lineWidthSelectedAction:) forControlEvents:UIControlEventTouchUpInside];
        _lineWidhtSlider.minimumValue = 0.1;
        _lineWidhtSlider.maximumValue = 20.0;
        [self addSubview:_lineWidhtSlider];
        _lineWidhtSlider.value = 5.0;
        [self lineWidthSelectedAction:_lineWidhtSlider];
        
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _controlHeight_, frame.size.width, _colorScrollViewHeight_)];
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.backgroundColor = [UIColor clearColor];
        [self addSubview:_scrollView];
        
        _colorArray = [[NSMutableArray alloc] initWithObjects:[UIColor redColor], [UIColor orangeColor], [UIColor yellowColor], [UIColor greenColor] , [UIColor cyanColor], [UIColor blueColor], [UIColor purpleColor], [UIColor blackColor], [UIColor grayColor], [UIColor whiteColor], nil];
        
        CGFloat cellSize = frame.size.height - _controlHeight_ - _controlInterval_ * 2;
        
        _undoButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_undoButton addTarget:self action:@selector(undoAction:) forControlEvents:UIControlEventTouchUpInside];
        [_undoButton setShowsTouchWhenHighlighted:YES];
        [_undoButton setImage:[UIImage imageNamed:@"imageEditor_undo"] forState:UIControlStateNormal];
        [_undoButton setImage:[UIImage imageNamed:@"imageEditor_undo_disable"] forState:UIControlStateDisabled];
        [_undoButton setFrame:CGRectMake(_controlInterval_, _controlInterval_, cellSize, cellSize)];
        [_scrollView addSubview:_undoButton];
        _undoButton.enabled = NO;
        
        UITapGestureRecognizer *eraserTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(eraserSelectedAction:)];
        UIImage *eraserImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"eraser@2x" ofType:@"png"]];
        _eraserImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_controlInterval_ * 2 + cellSize, _controlInterval_, cellSize, cellSize)];
        _eraserImageView.image = eraserImage;
        _eraserImageView.userInteractionEnabled = YES;
        [_eraserImageView addGestureRecognizer:eraserTap];
        _eraserImageView.layer.borderColor = [UIColor whiteColor].CGColor;
        _eraserImageView.layer.borderWidth = 0.0;
        [_scrollView addSubview:_eraserImageView];
        [eraserImage release];
        [eraserTap release];
        
        for(NSInteger i = 0;i < _colorArray.count; i ++)
        {
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(colorSelectedAction:)];
            JBoBrushCell *cell = [[JBoBrushCell alloc] initWithFrame:CGRectMake((_controlInterval_ + cellSize) * (i + 2) + _controlInterval_, _controlInterval_, cellSize, cellSize)];
            cell.innerView.backgroundColor = [_colorArray objectAtIndex:i];
            cell.index = i;
            cell.tag = _startTag_ + i;
            cell.selectedBorderColor = [UIColor whiteColor];
            cell.userInteractionEnabled = YES;
            [cell addGestureRecognizer:tap];
            [_scrollView addSubview:cell];
            [tap release];
            [cell release];
        }
        
        [_scrollView setContentSize:CGSizeMake((_controlInterval_ + cellSize) * (_colorArray.count + 2) + _controlInterval_, _scrollView.frame.size.height)];
    }
    return self;
}

- (void)dealloc
{
    [_lineWidhtLabel release];
    [_lineWidhtSlider release];
    
    [_colorArray release];
    [_selectedColor release];
    
    [_scrollView release];
    [_eraserImageView release];
    [_selectedCell release];
    
    [super dealloc];
}

- (void)setBlendMode:(CGBlendMode)blendMode
{
    _blendMode = blendMode;
    if(_blendMode == kCGBlendModeClear)
    {
        _eraserImageView.layer.borderWidth = 2.0;
    }
    else
    {
        _eraserImageView.layer.borderWidth = 0.0;
    }
    
}

- (void)undoAction:(UIButton*) button
{
    if([self.delegate respondsToSelector:@selector(brushScrollView:DidUndone:)])
    {
        [self.delegate brushScrollView:self DidUndone:_undoButton];
    }
}

- (void)selectedColorAtIndex:(NSInteger)index
{
    if(index >= self.colorArray.count)
        index = self.colorArray.count - 1;
    if(index < 0)
        index = 0;
    
    JBoBrushCell *cell = (JBoBrushCell*)[_scrollView viewWithTag:_startTag_ + index];
    self.selectedColor = [_colorArray objectAtIndex:cell.index];
    self.selectedCell = cell;
    self.selectedCell.selected = YES;
    self.blendMode = kCGBlendModeNormal;
    
    if([self.delegate respondsToSelector:@selector(brushScrollView:didSelectedColorAtIndex:)])
    {
        [self.delegate brushScrollView:self didSelectedColorAtIndex:cell.index];
    }
}

- (void)selectedLineWidth:(CGFloat)width
{
    _lineWidhtSlider.value = width;
    [self lineWidthSelectedAction:_lineWidhtSlider];
}

- (void)eraserSelectedAction:(UITapGestureRecognizer*) tap
{
    self.blendMode = kCGBlendModeClear;
    self.selectedColor = [UIColor clearColor];
    self.selectedCell.selected = NO;
    if([self.delegate respondsToSelector:@selector(brushScrollView:didSelectedColorAtIndex:)])
    {
        [self.delegate brushScrollView:self didSelectedColorAtIndex:0];
    }
}

- (void)colorSelectedAction:(UITapGestureRecognizer*) tap
{
    //NSLog(@"- ");
    self.blendMode = kCGBlendModeNormal;
    self.selectedCell.selected = NO;
    JBoBrushCell *cell = (JBoBrushCell*) tap.view;
    self.selectedColor = [_colorArray objectAtIndex:cell.index];
    self.selectedCell = cell;
    self.selectedCell.selected = YES;
    
    if([self.delegate respondsToSelector:@selector(brushScrollView:didSelectedColorAtIndex:)])
    {
        [self.delegate brushScrollView:self didSelectedColorAtIndex:cell.index];
    }
}

- (void)lineWidthSelectedAction:(UISlider*) slider
{
    self.lineWidth = slider.value;
    _lineWidhtLabel.text = [NSString stringWithFormat:@"%0.1f", slider.value];
    if([self.delegate respondsToSelector:@selector(brushScrollView:lineWidthDidChanged:)])
    {
        [self.delegate brushScrollView:self lineWidthDidChanged:self.lineWidth];
    }
}

@end
