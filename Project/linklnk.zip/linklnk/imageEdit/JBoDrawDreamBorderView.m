//
//  JBoDrawDreamBorderView.m
//  连你
//
//  Created by kinghe005 on 14-1-14.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoDrawDreamBorderView.h"



@implementation JBoDrawDreamBorderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.borderColor = [UIColor whiteColor];//[UIColor colorWithRed:126.0 / 255.0 green:206.0 / 255.0 blue:244.0 / 255.0 alpha:1.0];
        self.borderWidth = _cellInteractiveBorderSize_;
    }
    return self;
}

- (void)dealloc
{
    [_borderColor release];
    [super dealloc];
}

- (void)setBorderColor:(UIColor *)borderColor
{
    if(![_borderColor isEqualToColor:borderColor])
    {
        [_borderColor release];
        _borderColor = [borderColor retain];
        [self setNeedsDisplay];
    }
}

- (void)setBorderWidth:(CGFloat)borderWidth
{
    if(_borderWidth != borderWidth)
    {
        _borderWidth = borderWidth;
        [self setNeedsDisplay];
    }
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    
    CGContextSetLineWidth(context, self.borderWidth);
    CGContextSetStrokeColorWithColor(context, self.borderColor.CGColor);
    CGContextAddRect(context, CGRectInset(self.bounds, _cellInteractiveBorderSize_ / 2, _cellInteractiveBorderSize_ / 2));
    CGContextStrokePath(context);
    
    CGContextRestoreGState(context);
}


@end
