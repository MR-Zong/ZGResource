//
//  JBoImageEditBaseCell.h
//  靓咖
//
//  Created by kinghe005 on 14-8-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoDrawDreamBorderView.h"

#define _drawButtonSize_ 20
#define _drawImageCellSize_ 50.0
#define _drawImageCellMaxScale_ 2.0
#define _drawimageCellMinScale_ 0.5


#define _cellDefaultMinWidth_ 70.0
#define _cellDefaultMinHeight_ 70.0
#define _cellControlSize_ 25.0
#define _cellControlIconSize_ 20.0

#define _cellGlobalInset_ (_cellControlSize_ / 2.0)

#pragma mark- control

//编辑控制器位置
typedef enum _JBoImageEditControlPosition
{
    JBoImageEditControlPositionLeftTop = 0, //左上角
    JBoImageEditControlPositionRightTop = 1, //右上角
    JBoImageEditControlPositionCenter = 2, //中心
    JBoImageEditControlPositionLeftBottom = 3, //左下角
    JBoImageEditControlPositionRightBottom = 4, //右下角
}JBoImageEditControlPosition;

/**控制图片
 */
@interface JBoDrawImageCellControl : UIView

/**图标
 */
@property(nonatomic,readonly) UIImageView *iconImageView;

@end

#pragma mark- cell

@class JBoImageEditBaseCell;

@protocol JBoImageEditBaseCellDelegate <NSObject>

@optional
/**开始编辑 触摸开始
 */
- (void)cellDidBeginEditing:(JBoImageEditBaseCell *) cell;
/**结束编辑 触摸结束
 */
- (void)cellDidEndEditing:(JBoImageEditBaseCell *) cell;
/**触摸移动
 */
- (void)cellDidMoved:(JBoImageEditBaseCell*) cell;
/**取消编辑 触摸取消
 */
- (void)cellDidCancelEditing:(JBoImageEditBaseCell *) cell;
/**cell被双击
 */
- (void)cellDidDoubleTapped:(JBoImageEditBaseCell*) cell;
/**选中cell
 */
- (void)cellDidSelected:(JBoImageEditBaseCell *) cell;
/**cell关闭，从父视图上移除
 */
- (void)cellDidClose:(JBoImageEditBaseCell *) cell;

@end

/**靓图秀秀图文编辑的基类 封装了视图的缩放 拖拽方法
 */
@interface JBoImageEditBaseCell : UIView<UIGestureRecognizerDelegate>

/**下标
 */
@property(nonatomic,assign) NSInteger index;

/**捏合手势
 */
@property(nonatomic,readonly) UIPinchGestureRecognizer *pinchGesture;

/**是否阻止cell被拖出父视图 default is 'YES'
 */
@property (nonatomic, assign) BOOL preventsPositionOutsideSuperview;
/**是否阻止缩放cell default is 'NO'
 */
@property (nonatomic, assign) BOOL preventsResizing;

/**缩放视图是 阻止layout default is 'YES'
 */
@property (nonatomic, assign) BOOL preventsLayoutWhileResizing;

/**是否支持单手缩放，default is 'NO'
 */
@property (nonatomic, assign) BOOL enableSingleHandResize;

/**cell的最小宽度
 */
@property (nonatomic, assign) CGFloat minWidth;

/**cell的最小高度
 */
@property (nonatomic, assign) CGFloat minHeight;

//缩放最大值
@property (nonatomic,assign) CGFloat maxWidth;
@property (nonatomic,assign) CGFloat maxHeight;

/**是否可编辑 default is 'YES'
 */
@property (nonatomic, assign) BOOL editable;

/**是否被选中 default is 'NO'
 */
@property (nonatomic, assign) BOOL selected;

/**边框
 */
@property (nonatomic, readonly) JBoDrawDreamBorderView *borderView;

/**内容边距
 */
@property (nonatomic, assign) CGFloat contentPadding;

/**内容视图 default is 'nil'
 */
@property (nonatomic, retain) UIView *contentView;

/**旋转控制器
 */
@property(nonatomic,retain) JBoDrawImageCellControl *rotateControl;

/**向右向上缩放控制器
 */
@property(nonatomic,retain) JBoDrawImageCellControl *toRightAndTopControl;

/**向左向下缩放控制器
 */
@property(nonatomic,retain) JBoDrawImageCellControl *toLeftAndBottomControl;

/**关闭控制器
 */
@property(nonatomic,retain) JBoDrawImageCellControl *closeControl;


@property (nonatomic, assign) id<JBoImageEditBaseCellDelegate> delegate;

/**初始化参数 子类重写该方法时必须调用 [super setupDefaultAttributes];
 */
- (void)setupDefaultAttributes;

/**视图缩放 子类重写该方法时必须调用 [super layoutSubviewsAfterResize];
 */
- (void)layoutSubviewsAfterResize;

/**调整 子视图在图层中的位置，把控制器放在前面
 */
- (void)setupSubviewsPosition;

/**单击视图 默认不做任何事 子类必须实现该方法
 */
- (void)selectedTap:(id) sender;

/**隐藏编辑层 子类重写该方法时必须调用 [super hideEditingHandles];
 */
- (void)hideEditingHandles;
/**显示编辑层 子类重写该方法时必须调用 [super showEditingHandles];
 */
- (void)showEditingHandles;

/**初始化一个cell
 *param frame cell的位置大小
 *param padding cell的内容的边距
 */
- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat) padding;

/**设定编辑控制器位置
 */
- (void)setControl:(JBoDrawImageCellControl*) control position:(JBoImageEditControlPosition) position;

@end
