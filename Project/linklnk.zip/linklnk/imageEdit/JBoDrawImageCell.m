//
//  JBoDrawImageCell.m
//  连客
//
//  Created by kinghe005 on 13-12-28.
//  Copyright (c) 2013年 KingHe. All rights reserved.
//

#import "JBoDrawImageCell.h"
#import "JBoBasic.h"
#import "JBoBrushDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import "UIImage+Utilities.h"

@implementation JBoDrawImageCellBrushView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        self.pathArray = [[[NSMutableArray alloc] init] autorelease];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    [self.image drawInRect:self.bounds];
    [self.brushTool draw];
}

- (void)dealloc
{
    [_image release];
    [_brushTool release];
    
    [_pathArray release];
    
    [super dealloc];
}

- (void)updataImage:(BOOL) redraw
{
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0.0);
    // CGContextRef context = UIGraphicsGetCurrentContext();
    
    if(redraw)
    {
        self.image = nil;
        for(id<JBoBrushTool> tool in self.pathArray)
        {
            [tool draw];
        }
    }
    else
    {
        [self.image drawInRect:self.bounds];
        [self.brushTool draw];
    }
    
	self.image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
}

- (void)undo
{
    if([self canUndo])
    {
        [self.pathArray removeLastObject];
        [self updataImage:YES];
        [self setNeedsDisplay];
    }
}

- (BOOL)canUndo
{
    return self.pathArray.count > 0;
}

@end

@implementation JBoDrawImageCellContentView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        
    }
    return self;
}

- (void)setHasText:(BOOL)hasText
{
    _hasText = hasText;
    if(!_hasText)
    {
        self.label.text = @"点击输入";
    }
}

- (void)setEditable:(BOOL)editable
{
    if(_editable != editable)
    {
        _editable = editable;
        if(_editable)
        {
            if(!_label)
            {
                CGFloat rightPadding = 20;
                CGFloat leftPadding = 10;
                CGFloat topPadding = 20;
                
               // UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(beginEndited:)];
                _label = [[JBoCustomInsetLabel alloc] initWithFrame:CGRectMake(rightPadding, topPadding, self.frame.size.width - rightPadding - leftPadding, self.frame.size.height - topPadding * 2)];
                _label.backgroundColor = [UIColor clearColor];
                _label.insets = UIEdgeInsetsMake(5, 5, 5, 5);
                //_label.adjustsFontSizeToFitWidth = YES;
                _label.text = @"点击输入";
                _label.userInteractionEnabled = YES;
                _label.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin;
                //[_label addGestureRecognizer:tap];
                //[tap release];
                _label.numberOfLines = 0;
                [self addSubview:_label];
            }
        }
    }
}

//- (void)beginEndited:(UITapGestureRecognizer*) tap
//{
//    NSLog(@"开始编辑");
//    if([self.delegate respondsToSelector:@selector(contentViewDidBeginInputText:)])
//    {
//        [self.delegate contentViewDidBeginInputText:self];
//    }
//}

- (void)dealloc
{
    [_label release];
    [super dealloc];
}

@end

@interface JBoDrawImageCell ()

//旋转缩放  删除 按钮 锁定 镜像 圆角
@property (retain, nonatomic) JBoDrawImageCellControl *resizingControl;
@property (retain, nonatomic) JBoDrawImageCellControl *deleteControl;
@property (retain, nonatomic) JBoDrawImageCellControl *lockControl;
@property (retain, nonatomic) JBoDrawImageCellControl *mirrorControl;
@property (retain, nonatomic) JBoDrawImageCellControl *cornerControl;

@property (nonatomic, assign) BOOL preventsLayoutWhileResizing;

//旋转正弦
@property (nonatomic, assign) float deltaAngle;
@property (nonatomic, assign) CGPoint prevPoint;

@property (nonatomic, assign) CGPoint touchStart;

//内容边距
@property (nonatomic, assign) CGFloat contentPadding;

//绘图
@property (nonatomic,assign) CGPoint previousPoint1;
@property (nonatomic,assign) CGPoint previousPoint2;
@property (nonatomic,assign) CGPoint currentPoint;
@property (nonatomic,assign) BOOL touchMoved;

//缩放最大值
@property (nonatomic,assign) CGFloat maxWidth;
@property (nonatomic,assign) CGFloat maxHeight;

@end

@implementation JBoDrawImageCell

#pragma mark-初始化

- (id)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame]))
    {
        self.contentPadding = _cellGlobalInset_ + _cellInteractiveBorderSize_;
        [self setupDefaultAttributes];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if ((self = [super initWithCoder:aDecoder]))
    {
        self.contentPadding = _cellGlobalInset_ + _cellInteractiveBorderSize_;
        [self setupDefaultAttributes];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat)padding
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.contentPadding = _cellGlobalInset_ + padding;
        [self setupDefaultAttributes];
    }
    return self;
}

- (void)dealloc
{
    [_resizingControl release];
    [_deleteControl release];
    [_lockControl release];
    [_mirrorControl release];
    [_cornerControl release];
    
    [_borderView release];
    [_brushView release];
    [_drawImage release];
    [_selectedColor release];
    
    [_contentImageView release];
    [_contentImage release];
    
    [_identifier release];
    [_circleImage release];
    
    [super dealloc];
}

- (void)setupDefaultAttributes
{
    _borderView = [[JBoDrawDreamBorderView alloc] initWithFrame:CGRectInset(self.bounds, _cellGlobalInset_, _cellGlobalInset_)];
    [_borderView setHidden:YES];
    [self addSubview:_borderView];
    
//    if (_cellDefaultMinWidth_ > self.bounds.size.width * 0.5) {
//        self.minWidth = _cellDefaultMinWidth_;
//        self.minHeight = self.bounds.size.height * (_cellDefaultMinWidth_/self.bounds.size.width);
//    } else {
//        self.minWidth = self.bounds.size.width * 0.5;
//        self.minHeight = self.bounds.size.height * 0.5;
//    }
    self.minWidth = _cellDefaultMinWidth_;
    self.minHeight = _cellDefaultMinHeight_;
    
    self.preventsPositionOutsideSuperview = YES;
    self.preventsLayoutWhileResizing = YES;
    self.preventsResizing = NO;
    self.preventsDeleting = NO;
    
    //删除
    self.deleteControl = [[[JBoDrawImageCellControl alloc]initWithFrame:CGRectMake(0, 0,
                                                                       _cellControlSize_, _cellControlSize_)] autorelease];
    self.deleteControl.backgroundColor = [UIColor clearColor];
    self.deleteControl.autoresizingMask = UIViewAutoresizingNone;
    self.deleteControl.iconImageView.image = [UIImage imageNamed:@"draw_delete_btn.png"];
    self.deleteControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    self.deleteControl.userInteractionEnabled = YES;
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc]
                                          initWithTarget:self
                                          action:@selector(singleTap:)];
    [self.deleteControl addGestureRecognizer:singleTap];
    [self addSubview:self.deleteControl];
    [singleTap release];
    
    //锁定
    self.lockControl = [[[JBoDrawImageCellControl alloc]initWithFrame:CGRectMake(0, self.frame.size.height - _cellControlSize_,
                                                                       _cellControlSize_, _cellControlSize_)] autorelease];
    self.lockControl.backgroundColor = [UIColor clearColor];
    self.lockControl.autoresizingMask = UIViewAutoresizingNone;
    self.lockControl.iconImageView.image = [UIImage imageNamed:@"draw_unlock_btn.png"];
    self.lockControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    self.lockControl.userInteractionEnabled = YES;
    UITapGestureRecognizer *lockTap = [[UITapGestureRecognizer alloc]
                                          initWithTarget:self
                                          action:@selector(lockTap:)];
    [self.lockControl addGestureRecognizer:lockTap];
    [self addSubview:self.lockControl];
    [lockTap release];
    self.lock = NO;
    self.burshing = NO;
    
    //缩放
    self.resizingControl = [[[JBoDrawImageCellControl alloc]initWithFrame:CGRectMake(self.frame.size.width - _cellControlSize_,
                                                                         self.frame.size.height - _cellControlSize_,
                                                                         _cellControlSize_, _cellControlSize_)] autorelease];
    self.resizingControl.backgroundColor = [UIColor clearColor];
    self.resizingControl.autoresizingMask = UIViewAutoresizingNone;
    self.resizingControl.userInteractionEnabled = YES;
    self.resizingControl.iconImageView.image = [UIImage imageNamed:@"draw_zoom_btn.png"];
    self.resizingControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    UIPanGestureRecognizer *panResizeGesture = [[UIPanGestureRecognizer alloc]
                                                initWithTarget:self
                                                action:@selector(resizeTranslate:)];
    [self.resizingControl addGestureRecognizer:panResizeGesture];
    [panResizeGesture release];
    [self addSubview:self.resizingControl];
    
    
    self.deltaAngle = atan2(self.frame.origin.y + self.frame.size.height - self.center.y,
                            self.frame.origin.x + self.frame.size.width - self.center.x);
    
    //镜像
    self.mirrorControl = [[[JBoDrawImageCellControl alloc] initWithFrame:CGRectMake(self.frame.size.width - _cellControlSize_, 0, _cellControlSize_, _cellControlSize_)] autorelease];
    self.mirrorControl.backgroundColor = [UIColor clearColor];
    self.mirrorControl.autoresizingMask = UIViewAutoresizingNone;
    self.mirrorControl.userInteractionEnabled = YES;
    self.mirrorControl.iconImageView.image = [UIImage imageNamed:@"draw_mirror_btn.png"];
    self.mirrorControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
    
    UITapGestureRecognizer *mirrorTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(mirrorTapAction:)];
    [self.mirrorControl addGestureRecognizer:mirrorTap];
    [mirrorTap release];
    [self addSubview:self.mirrorControl];
    
    
    UITapGestureRecognizer *selectedTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectedTap:)];
    selectedTap.delegate = self;
    _contentImageView = [[JBoDrawImageCellContentView alloc] initWithFrame:CGRectInset(self.bounds, self.contentPadding, self.contentPadding)];
   // _contentImageView.delegate = self;
    _contentImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _contentImageView.userInteractionEnabled = YES;
   // _contentImageView.contentMode = UIViewContentModeScaleAspectFill;
    [self addGestureRecognizer:selectedTap];
    [selectedTap release];
    [self addSubview:_contentImageView];
    
    self.brushView = [[[JBoDrawImageCellBrushView alloc] initWithFrame:_contentImageView.frame] autorelease];
    self.brushView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.brushView.userInteractionEnabled = YES;
    [self addSubview:self.brushView];
    
    [self bringSubviewToFront:_borderView];
    [self bringSubviewToFront:_brushView];
    [self bringSubviewToFront:self.resizingControl];
    [self bringSubviewToFront:self.deleteControl];
    [self bringSubviewToFront:self.lockControl];
    [self bringSubviewToFront:self.mirrorControl];
    self.autoresizesSubviews = YES;
    
    self.editable = YES;
    self.maxScale = 2.0;
}

- (void)setMaxScale:(CGFloat)maxScale
{
    self.maxWidth = self.bounds.size.width * maxScale;
    self.maxHeight = self.bounds.size.height * maxScale;
}

#pragma mark-JBoDrawImageCellContentView代理
//- (void)contentViewDidBeginInputText:(JBoDrawImageCellContentView *)contentView
//{
//    if([self.delegate respondsToSelector:@selector(cellDidBeganInputText:)])
//    {
//        [self.delegate cellDidBeganInputText:self];
//    }
//}

- (void)setContentImage:(UIImage *)contentImage
{
    if(_contentImage != contentImage)
    {
        [_contentImage release];
        _contentImage = [contentImage retain];
        self.contentImageView.image = _contentImage;
    }
}

- (void)selectedTap:(UITapGestureRecognizer*) tap
{
    if(!self.editable)
        return;
    
    if(self.selected && self.inputText && !self.lock)
    {
        if([self.delegate respondsToSelector:@selector(cellDidBeganInputText:)])
        {
            [self.delegate cellDidBeganInputText:self];
        }
    }
    self.selected = !self.selected;
}

//删除
- (void)singleTap:(UIPanGestureRecognizer *)recognizer
{
    if(!self.editable)
        return;
    if(NO == self.preventsDeleting)
    {
        //UIView * close = (UIView *)[recognizer view];
//        [close.superview removeFromSuperview];
       // NSLog(@"%@",close);
        if([self.delegate respondsToSelector:@selector(cellDidClose:)])
        {
            [self.delegate cellDidClose:self];
        }
    }
}

//锁定
- (void)lockTap:(UITapGestureRecognizer*) tap
{
    if(!self.editable)
        return;
    NSLog(@"锁定");
    self.lock = !self.lock;
    //NSLog(@"%@",_brushView);
    if([self.delegate respondsToSelector:@selector(celldidLocked:)])
    {
        [self.delegate celldidLocked:self];
    }
}

- (void)mirrorTapAction:(UITapGestureRecognizer*)tap
{
    if(!self.editable)
        return;
    NSLog(@"镜像");
    
    UIImage *retImage = (self.corners && self.circleImage) ? self.circleImage : self.contentImage;
    
    if(self.contentImageView.image.imageOrientation == UIImageOrientationUp)
    {
        UIImage *image = [[UIImage alloc] initWithCGImage:retImage.CGImage scale:1.0 orientation:UIImageOrientationUpMirrored];
        self.contentImageView.image = image;
        [image release];
        
        if(self.drawImage)
        {
            UIImage *drawImage = [[UIImage alloc] initWithCGImage:self.drawImage.CGImage scale:1.0 orientation:UIImageOrientationUpMirrored];
            self.brushView.image = drawImage;
            [drawImage release];
            [self.brushView setNeedsDisplay];
        }
    }
    else
    {
        UIImage *image = [[UIImage alloc] initWithCGImage:retImage.CGImage scale:1.0 orientation:UIImageOrientationUp];
        self.contentImageView.image = image;
        [image release];
        
        if(self.drawImage)
        {
            UIImage *drawImage = [[UIImage alloc] initWithCGImage:self.drawImage.CGImage scale:1.0 orientation:UIImageOrientationUp];
            self.brushView.image = drawImage;
            [drawImage release];
            [self.brushView setNeedsDisplay];
        }
    }
}

- (void)setLock:(BOOL)lock
{
    _lock = lock;
    if(_lock)
    {
        self.lockControl.iconImageView.image = [UIImage imageNamed:@"draw_lock_btn.png"];
        self.resizingControl.hidden = YES;
        self.deleteControl.hidden = YES;
        self.mirrorControl.hidden = YES;
    }
    else
    {
        self.lockControl.iconImageView.image = [UIImage imageNamed:@"draw_unlock_btn.png"];
        self.resizingControl.hidden = NO;
        self.deleteControl.hidden = NO;
        self.mirrorControl.hidden = NO;
    }
}

- (void)setCorners:(BOOL)corners
{
    _corners = corners;
    if(!self.cornerControl)
    {
        //锁定
        self.cornerControl = [[[JBoDrawImageCellControl alloc]initWithFrame:self.lockControl.frame] autorelease];
        self.cornerControl.backgroundColor = [UIColor clearColor];
        self.cornerControl.autoresizingMask = UIViewAutoresizingNone;
        self.cornerControl.iconImageView.image = [UIImage imageNamed:@"draw_arc_ractang_btn"];
        self.cornerControl.iconImageView.frame = CGRectMake((_cellControlSize_ - _cellControlIconSize_) / 2, (_cellControlSize_ - _cellControlIconSize_) / 2, _cellControlIconSize_, _cellControlIconSize_);
        self.cornerControl.userInteractionEnabled = YES;
        UITapGestureRecognizer *cornerTap = [[UITapGestureRecognizer alloc]
                                           initWithTarget:self
                                           action:@selector(cornerTap:)];
        [self.cornerControl addGestureRecognizer:cornerTap];
        [self addSubview:self.cornerControl];
        [cornerTap release];
        [self.lockControl removeFromSuperview];
        self.lockControl = self.cornerControl;
    }
    
    if(_corners)
    {
        if(!self.circleImage)
        {
            self.circleImage = [self.contentImage circleImageWithBorderColor:[UIColor whiteColor] borderWidth:10.0 innerPadding:0];
        }
        self.contentImageView.image = self.circleImage;
    }
    else
    {
        self.contentImageView.image = self.contentImage;
    }
}

- (void)cornerTap:(UITapGestureRecognizer*)tap
{
    self.corners = !self.corners;
}

#pragma mark-gesture代理
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if([touch.view isEqual:self.resizingControl] || [touch.view isEqual:self.deleteControl] || [touch.view isEqual:self.lockControl] || [touch.view isEqual:self.mirrorControl])
    {
        return NO;
    }
    return YES;
}

#pragma mark-pan滑动

- (void)resizeTranslate:(UIPanGestureRecognizer *)recognizer
{
    if(!self.editable)
        return;
    self.selected = YES;
    if ([recognizer state] == UIGestureRecognizerStateBegan)
    {
        self.prevPoint = [recognizer locationInView:self];
        [self setNeedsDisplay];
    }
    else if ([recognizer state] == UIGestureRecognizerStateChanged)
    {
        //NSLog(@"bounds = %f,%f", self.bounds.size.width, self.bounds.size.height);
        if (self.bounds.size.width < self.minWidth || self.bounds.size.height < self.minHeight)
        {
           // NSLog(@"最小%f,%f -- %f,%f",self.bounds.size.width , self.bounds.size.height, self.minWidth, self.minHeight);
            self.bounds = CGRectMake(self.bounds.origin.x,
                                     self.bounds.origin.y,
                                     self.minWidth,
                                     self.minHeight);
            self.resizingControl.frame = CGRectMake(self.bounds.size.width - _cellControlSize_,
                                              self.bounds.size.height - _cellControlSize_,
                                              _cellControlSize_,
                                              _cellControlSize_);
            self.deleteControl.frame = CGRectMake(0, 0,
                                             _cellControlSize_, _cellControlSize_);
            self.lockControl.frame = CGRectMake(0, self.bounds.size.height - _cellControlSize_, _cellControlSize_, _cellControlSize_);
            self.mirrorControl.frame = CGRectMake(self.bounds.size.width - _cellControlSize_, 0, _cellControlSize_, _cellControlSize_);
            self.prevPoint = [recognizer locationInView:self];
            
        }
        else
        {
            CGPoint point = [recognizer locationInView:self];
            float wChange = 0.0, hChange = 0.0;
            
            wChange = (point.x - self.prevPoint.x);
            hChange = (point.y - self.prevPoint.y);
            
            if (ABS(wChange) > 20.0f || ABS(hChange) > 20.0f)
            {
                self.prevPoint = [recognizer locationInView:self];
                return;
            }
            
            if (YES == self.preventsLayoutWhileResizing)
            {
                if (wChange < 0.0f && hChange < 0.0f)
                {
                    float change = MIN(wChange, hChange);
                    wChange = change;
                    hChange = change;
                }
                if (wChange < 0.0f)
                {
                    hChange = wChange;
                } else if (hChange < 0.0f)
                {
                    wChange = hChange;
                } else
                {
                    float change = MAX(wChange, hChange);
                    wChange = change;
                    hChange = change;
                }
            }
            
           // NSLog(@"%f,%f",wChange,hChange);
            if(self.bounds.size.width != self.bounds.size.height)
            {
                CGFloat scale = self.bounds.size.width / self.bounds.size.height;
                hChange = wChange / scale;
                
               // NSLog(@"--%f,%f",wChange,hChange);
            }
            
            CGRect bounds = CGRectMake(self.bounds.origin.x, self.bounds.origin.y,
                                       self.bounds.size.width + (wChange),
                                       self.bounds.size.height + (hChange));
            bounds.size.width = bounds.size.width > self.maxWidth ? self.maxWidth : bounds.size.width;
            bounds.size.height = bounds.size.height > self.maxHeight ? self.maxHeight : bounds.size.height;
            
            self.bounds = bounds;
            self.resizingControl.frame = CGRectMake(self.bounds.size.width - _cellControlSize_,
                                              self.bounds.size.height -_cellControlSize_,
                                              _cellControlSize_, _cellControlSize_);
            self.deleteControl.frame = CGRectMake(0, 0,
                                             _cellControlSize_, _cellControlSize_);
            self.lockControl.frame = CGRectMake(0, self.bounds.size.height - _cellControlSize_, _cellControlSize_, _cellControlSize_);
            self.mirrorControl.frame = CGRectMake(self.bounds.size.width - _cellControlSize_, 0, _cellControlSize_, _cellControlSize_);
            self.prevPoint = [recognizer locationInView:self];
        }
        
        //旋转
        float ang = atan2([recognizer locationInView:self.superview].y - self.center.y,
                          [recognizer locationInView:self.superview].x - self.center.x);
        float angleDiff = self.deltaAngle - ang;
        if (NO == self.preventsResizing)
        {
            self.transform = CGAffineTransformMakeRotation(- angleDiff);
        }
        
        _borderView.frame = CGRectInset(self.bounds, _cellGlobalInset_, _cellGlobalInset_);
        [_borderView setNeedsDisplay];
       // _brushView.frame = CGRectMake(10, 10, self.frame.size.width, self.frame.size.height);
        
        [self setNeedsDisplay];
    }
    else if ([recognizer state] == UIGestureRecognizerStateEnded)
    {
        self.prevPoint = [recognizer locationInView:self];
        [self setNeedsDisplay];
    }
    
    //NSLog(@"%@--%@",self.resizingControl, self.resizingControl.iconImageView);
}


- (void)setFrame:(CGRect)newFrame
{
    [super setFrame:newFrame];
    _contentImageView.frame = CGRectInset(self.bounds, self.contentPadding, self.contentPadding);
    
    _borderView.frame = CGRectInset(self.bounds, _cellGlobalInset_, _cellGlobalInset_);
    _brushView.frame = _contentImageView.frame;
    
    self.resizingControl.frame = CGRectMake(self.bounds.size.width - _cellControlSize_,
                                      self.bounds.size.height - _cellControlSize_,
                                      _cellControlSize_,
                                      _cellControlSize_);
    self.deleteControl.frame = CGRectMake(0, 0,
                                     _cellControlSize_, _cellControlSize_);
    self.lockControl.frame = CGRectMake(0, self.bounds.size.height - _cellControlSize_, _cellControlSize_, _cellControlSize_);
    self.mirrorControl.frame = CGRectMake(self.bounds.size.width - _cellControlSize_, 0, _cellControlSize_, _cellControlSize_);
    
    [_borderView setNeedsDisplay];
}

#pragma mark-重写触摸方法

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
   // NSLog(@"touchBegan");
    UITouch *touch = [touches anyObject];
    
    if(self.lock && self.burshing)
    {
        self.brushView.brushTool = [[[JBoBrushPenTool alloc] init] autorelease];
        self.brushView.brushTool.lineWidth = self.lineWidth;
        self.brushView.brushTool.lineColor = self.selectedColor;
        self.brushView.brushTool.blendMode = self.blendMode;
        [self.brushView.pathArray addObject:self.brushView.brushTool];
        
        self.previousPoint1 = [touch previousLocationInView:self.brushView];
        self.currentPoint = [touch locationInView:self.brushView];
        
        [self.brushView.brushTool setInitialPoint:self.currentPoint];
    }
    else if(!self.lock && self.editable)
    {
        self.touchStart = [touch locationInView:self.superview];
        if([_delegate respondsToSelector:@selector(cellDidBeginEditing:)])
        {
            [_delegate cellDidBeginEditing:self];
        }
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(!self.editable)
        return;
    UITouch *touch = [touches anyObject];
    //NSLog(@"%d",touch.tapCount);
    if(self.lock && self.burshing)
    {
        [self.brushView updataImage:NO];
        self.drawImage = self.brushView.image;
        self.brushView.brushTool = nil;
        
        if([self.delegate respondsToSelector:@selector(cellDidEndDraw:)])
        {
            [self.delegate cellDidEndDraw:self];
        }
    }
    
    if(touch.tapCount == 2)
    {
        //NSLog(@"双击");
        if([self.delegate respondsToSelector:@selector(cellDidDoubleTapped:)])
        {
            [self.delegate cellDidDoubleTapped:self];
        }
        return;
    }
    // Notify the delegate we've ended our editing session.
    if([_delegate respondsToSelector:@selector(cellDidEndEditing:)])
    {
        [_delegate cellDidEndEditing:self];
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(!self.editable)
        return;
    UITouch *touch = [touches anyObject];
   // NSLog(@"cancel%d",touch.tapCount);
   // NSLog(@"%d",touch.tapCount);
    
    if(self.lock && self.burshing)
    {
        [self.brushView updataImage:NO];
        self.drawImage = self.brushView.image;
        self.brushView.brushTool = nil;
    }
    
    if(touch.tapCount == 2)
    {
        //NSLog(@"双击");
        if([self.delegate respondsToSelector:@selector(cellDidDoubleTapped:)])
        {
            [self.delegate cellDidDoubleTapped:self];
        }
        return;
    }
    // Notify the delegate we've ended our editing session.
    if([_delegate respondsToSelector:@selector(cellDidCancelEditing:)])
    {
        [_delegate cellDidCancelEditing:self];
    }
}

- (void)translateUsingTouchLocation:(CGPoint)touchPoint
{
    
    CGPoint newCenter = CGPointMake(self.center.x + touchPoint.x - self. touchStart.x,
                                    self.center.y + touchPoint.y - self.touchStart.y);
    if (self.preventsPositionOutsideSuperview) {
        // Ensure the translation won't cause the view to move offscreen.
        
        //控制器宽度
        CGFloat controlWidth = _resizingControl.width / 2.0 + _borderView.borderWidth;
        
        CGFloat midPointX = CGRectGetMidX(self.bounds) - controlWidth;
        if (newCenter.x > self.superview.bounds.size.width - midPointX)
        {
            newCenter.x = self.superview.bounds.size.width - midPointX;
        }
        
        if (newCenter.x < midPointX)
        {
            newCenter.x = midPointX;
        }
        
        CGFloat midPointY = CGRectGetMidY(self.bounds) - controlWidth;
        
        if (newCenter.y > self.superview.bounds.size.height - midPointY)
        {
            newCenter.y = self.superview.bounds.size.height - midPointY;
        }
        
        if (newCenter.y < midPointY)
        {
            newCenter.y = midPointY;
        }
    }
    self.center = newCenter;
    if([self.delegate respondsToSelector:@selector(cellDidMoved:)])
    {
        [self.delegate cellDidMoved:self];
    }
   
}

- (void)draw:(CGPoint) point
{
    UIGraphicsBeginImageContext(self.brushView.frame.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    //NSLog(@"----11%@", self.brushView);
	[self.drawImage drawInRect:CGRectMake(0, 0, self.brushView.frame.size.width, self.brushView.frame.size.height)];
	CGContextSetLineCap(context, kCGLineCapRound);
    // NSLog(@"%f",width);
    
	CGContextSetLineWidth(context, self.lineWidth);
    CGContextSetBlendMode(UIGraphicsGetCurrentContext(), self.blendMode);
	CGContextSetStrokeColorWithColor(context,self.selectedColor.CGColor);
	CGContextBeginPath(context);
	CGContextMoveToPoint(context, self.touchStart.x, self.touchStart.y);
	CGContextAddLineToPoint(context, point.x, point.y);
	CGContextStrokePath(context);
	self.drawImage = UIGraphicsGetImageFromCurrentImageContext();
    self.brushView.image = self.drawImage;
	UIGraphicsEndImageContext();
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
//    if(self.lock)
//        return;
    
    if(self.lock && self.burshing)
    {
        UITouch *touch = [touches anyObject];
        self.previousPoint2 = self.previousPoint1;
        self.previousPoint1 = [touch previousLocationInView:self.brushView];
        self.currentPoint = [touch locationInView:self.brushView];
        
        if ([self.brushView.brushTool isKindOfClass:[JBoBrushPenTool class]]) {
            CGRect bounds = [(JBoBrushPenTool*)self.brushView.brushTool addPathPreviousPreviousPoint:self.previousPoint2 withPreviousPoint:self.previousPoint1 withCurrentPoint:self.currentPoint];
            
            CGRect drawBox = bounds;
            drawBox.origin.x -= self.lineWidth * 2.0;
            drawBox.origin.y -= self.lineWidth * 2.0;
            drawBox.size.width += self.lineWidth * 4.0;
            drawBox.size.height += self.lineWidth * 4.0;
            
            [self.brushView setNeedsDisplayInRect:drawBox];
        }
        else
        {
            NSLog(@" cell touchMove");
            [self.brushView.brushTool moveFromPoint:self.previousPoint1 toPoint:self.currentPoint];
            [self.brushView setNeedsDisplay];
        }
    }
    else if(!self.lock && self.editable)
    {
        CGPoint touch = [[touches anyObject] locationInView:self.superview];
        [self translateUsingTouchLocation:touch];
        self.touchStart = touch;
    }
}

#pragma mark-公有方法

- (void)hideDelHandle
{
   self.deleteControl.hidden = YES;
}

- (void)showDelHandle
{
    self.deleteControl.hidden = NO;
}

- (void)hideEditingHandles
{
    self.resizingControl.hidden = YES;
    self.deleteControl.hidden = YES;
    self.lockControl.hidden = YES;
    self.mirrorControl.hidden = YES;
    [_borderView setHidden:YES];
}

- (void)showEditingHandles
{
    self.resizingControl.hidden = self.lock;
    self.deleteControl.hidden = self.lock;
    self.lockControl.hidden = NO;
    self.mirrorControl.hidden = self.lock;
    [_borderView setHidden:NO];
}

- (void)setSelected:(BOOL)selected
{
    if(_selected != selected)
    {
        _selected = selected;
        if(_selected)
        {
            [self showEditingHandles];

        }
        else
        {
            [self hideEditingHandles];
        }
    }
    if([self.delegate respondsToSelector:@selector(cellDidSelected:)])
    {
        [self.delegate cellDidSelected:self];
    }
}

@end
