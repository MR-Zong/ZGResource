//
//  JBoImageEditBackgroundCell.h
//  靓咖
//
//  Created by kinghe005 on 14-8-23.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoImageEditBaseCell.h"

/**图片编辑 色块
 */
@interface JBoImageEditBackgroundCell : JBoImageEditBaseCell

@end
