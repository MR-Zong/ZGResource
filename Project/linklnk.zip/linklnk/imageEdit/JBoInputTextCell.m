//
//  JBoInputTextCell.m
//  靓咖
//
//  Created by kinghe005 on 14-8-21.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoInputTextCell.h"

#pragma mark- contentView

@implementation JBoInputTextContentView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.backgroundColor = [UIColor clearColor];
        
        _imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        _imageView.backgroundColor = [UIColor clearColor];
        [self addSubview:_imageView];
        
        _textLabel = [[JBoCustomInsetLabel alloc] initWithFrame:self.bounds];
        _textLabel.verticalAlignment = JBoTextVerticalAlignmentTop;
        _textLabel.enableVerticalAlignment = YES;
        _textLabel.insets = UIEdgeInsetsZero;
        _textLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin;
        _textLabel.numberOfLines = 0;
        _textLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_textLabel];
    }
    
    return self;
}

- (void)dealloc
{
    [_imageView release];
    [_textLabel release];
    
    [super dealloc];
}

- (void)setHasText:(BOOL)hasText
{
    _hasText = hasText;
    if(!_hasText)
    {
        self.textLabel.text = @"点击输入";
    }
}

- (void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    _imageView.frame = self.bounds;
}

@end

#pragma mark- cell

@interface JBoInputTextCell ()

@end

@implementation JBoInputTextCell

@synthesize delegate;

- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat)padding
{
    self = [super initWithFrame:frame contentPadding:padding];
    if (self) {
        [self setupDefaultAttributes];
    }
    return self;
}

#pragma mark- dealloc

- (void)dealloc
{
    [_inputTextContentView release];
    [super dealloc];
}

#pragma mark- super method

- (void)setupDefaultAttributes
{
    [super setupDefaultAttributes];
    
    JBoInputTextContentView *contentView = [[JBoInputTextContentView alloc] initWithFrame:CGRectInset(self.bounds, self.contentPadding, self.contentPadding)];
    contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    contentView.userInteractionEnabled = YES;
    [self addSubview:contentView];
    self.inputTextContentView = contentView;
    self.contentView = contentView;
    [contentView release];
    
    [self setupSubviewsPosition];
}

- (void)selectedTap:(id)sender
{
    if(!self.editable)
        return;
    
    if(self.selected)
    {
        if([self.delegate respondsToSelector:@selector(cellDidBeganInputText:)])
        {
            [self.delegate cellDidBeganInputText:self];
        }
    }
 
    if(!self.selected)
    {
        self.selected = !self.selected;
    }
    
    if([self.delegate respondsToSelector:@selector(cellDidSelected:)])
    {
        [self.delegate cellDidSelected:self];
    }
}

@end
