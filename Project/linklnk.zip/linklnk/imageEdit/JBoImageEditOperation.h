//
//  JBoImageEditOperation.h
//  连你
//
//  Created by kinghe005 on 14-3-5.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

/**图片编辑操作
 */
@interface JBoImageEditOperation : NSObject

/**添加水印相机按钮
 *@param srcArray 水印数组 数组元素是 JBoImageEditWartermarkInfo
 */
+ (void)addCameraCell:(NSMutableArray*) srcArray;

@end
