//
//  JBoImageEditArrowCell.m
//  linklnk
//
//  Created by kinghe005 on 15/4/17.
//  Copyright (c) 2015年 KingHe. All rights reserved.
//

#import "JBoImageEditArrowCell.h"

@implementation JBoImageEditArrow

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if(self)
    {
        self.opaque = NO;
        self.userInteractionEnabled = NO;
        self.clipsToBounds = YES;
        self.backgroundColor = [UIColor clearColor];
        self.arrowColor = [UIColor redColor];
    }
    
    return self;
}

- (void)dealloc
{
    [_arrowColor release];
    [super dealloc];
}

- (void)setArrowColor:(UIColor *)arrowColor
{
    if(![_arrowColor isEqualToColor:arrowColor])
    {
        [_arrowColor release];
        _arrowColor = [arrowColor retain];
        [self setNeedsDisplay];
    }
}

- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, _arrowColor.CGColor);
    
    CGMutablePathRef path = CGPathCreateMutable();
    
    //添加箭头箭柄
    CGFloat height = rect.size.height / 2.0;
    CGFloat width = rect.size.width / 3.0 * 2;
    
    CGPathAddRect(path, NULL, CGRectMake(0, (rect.size.height - height) / 2.0, width, height));
    CGContextAddPath(context, path);
    CGPathRelease(path);
//
    //添加箭头
    CGPoint point = CGPointMake(width, 0);
    CGContextMoveToPoint(context, point.x, point.y);
    
    CGContextAddLineToPoint(context, width, rect.size.height);
    CGContextAddLineToPoint(context, rect.size.width, rect.size.height / 2.0);
    CGContextAddLineToPoint(context, point.x, point.y);
    
    CGContextFillPath(context);
    
}

@end

@interface JBoImageEditArrowCell ()

//旋转正弦
@property (nonatomic, assign) float angle;

@end

@implementation JBoImageEditArrowCell

- (id)initWithFrame:(CGRect)frame contentPadding:(CGFloat)padding
{
    self = [super initWithFrame:frame contentPadding:padding];
    if(self)
    {
        [self setupDefaultAttributes];
    }
    
    return self;
}

- (void)dealloc
{
    [_arrow release];
    [super dealloc];
}

#pragma mark- super method

- (void)setupDefaultAttributes
{
    [super setupDefaultAttributes];
    
    [self.toLeftAndBottomControl removeFromSuperview];
    self.toLeftAndBottomControl = nil;
    [self.toRightAndTopControl removeFromSuperview];
    self.toRightAndTopControl = nil;
    
    self.enableSingleHandResize = YES;
    //内容
    JBoImageEditArrow *arrow = [[JBoImageEditArrow alloc] initWithFrame:CGRectInset(self.bounds, self.contentPadding, self.contentPadding)];
    arrow.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    arrow.userInteractionEnabled = YES;
    [self addSubview:arrow];
    self.contentView = arrow;
    self.arrow = arrow;
    [arrow release];
    
    [self setupSubviewsPosition];
}


- (void)selectedTap:(id)sender
{
    self.selected = !self.selected;
    if([self.delegate respondsToSelector:@selector(cellDidSelected:)])
    {
        [self.delegate cellDidSelected:self];
    }
}

@end
