//
//  JBoLeaveMsgOperation.h
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>

#define _getLeaveMsgIdentifier_ @"getLeaveMsgIdentifier"
#define _addLeaveMsgIdentifier_ @"addLeaveMsgIdentifier"
#define _removeLeaveMsgIdentifier_ @"removeLeaveMsgIdentifier"

/**私信网络操作
 */
@interface JBoLeaveMsgOperation : NSObject

/**获取私信
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*) getLeaveMsgWithPageNum:(int) pageNum rows:(int) rows;

/**从返回的数据获取私信信息
 *@param data 返回的数据
 *@return 数组元素是 JBoLeaveMsgInfo对象
 */
+ (NSMutableArray*) getLeaveMsgFromData:(NSData*) data;

/**发私信
 *@param content 私信内容
 *@param reveiver 接收者的userId
 *@return get请求url
 */
+ (NSString*) addLeaveMsgWithContent:(NSString*) content reveiver:(NSString*) reveiver;

/**删除私信
 *@param leaveMsgId 私信Id
 *@return get请求url
 */
+ (NSString*) removeLeaveMsgWithId:(NSString*) leaveMsgId;

+ (void)setBadgeHidden:(BOOL) hidden;
+ (BOOL)getBadgeState;

@end
