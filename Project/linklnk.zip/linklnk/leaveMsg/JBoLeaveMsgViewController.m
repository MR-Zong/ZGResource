//
//  JBoLeaveMsgViewController.m
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLeaveMsgViewController.h"
#import "JBoAppDelegate.h"
#import "JBoHttpRequest.h"
#import "JBoImageTextTool.h"
#import "JBoBottomLoadingView.h"
#import "JBoLeaveMsgCell.h"
#import "JBoLeaveMsgInfo.h"
#import "JBoLeaveMsgOperation.h"
#import "JBoUserOperation.h"
#import "JBoAsyncDownloadUserInfoOperation.h"
#import "JBoDatetimeTool.h"
#import "JBoWebViewController.h"
#import "JBoPublickUserInfoViewController.h"
#import "JBoContactDetailInfotViewController.h"

@interface JBoLeaveMsgViewController ()<JBoHttpRequestDelegate,JBoLeaveMsgCellDelegate>
{
    JBoHttpRequest *_httpRequest;
    
    JBoBottomLoadingView *_bottomLoadingView;
    
    //用户信息
    NSMutableDictionary *_userDetailInfoDic;
    
    //下载进程
    NSMutableDictionary *_downloadProgressDic;
}

/**私信内容 数组元素是 JBoLeaveMsgInfo对象
 */
@property(nonatomic,retain) NSMutableArray *infoArray;

//正在网络请求
@property(nonatomic,assign) BOOL isRequest;

//是否还有私信内容
@property(nonatomic,assign) BOOL hasInfo;

//页码
@property(nonatomic,assign) int pageIndex;

//旧的页码
@property(nonatomic,assign) int oldPageIndex;

//选中的cell
@property(nonatomic,copy) NSIndexPath *selectedIndexPath;

//菜单覆盖视图
@property(nonatomic,retain) UIView *overlayView;

//没有信息
@property(nonatomic,retain) UILabel *hasNoMsgLabel;

@end

@implementation JBoLeaveMsgViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        self.infoArray = [[[NSMutableArray alloc] init] autorelease];
        _httpRequest = [[JBoHttpRequest alloc] initWithDelegate:self];
        
        self.hasInfo = YES;
        self.pageIndex = 1;
        
        _userDetailInfoDic = [[NSMutableDictionary alloc] init];
        _downloadProgressDic = [[NSMutableDictionary alloc] init];
        
        self.title = @"私信";
    }
    return self;
}

- (void)setIsRequest:(BOOL)isRequest
{
    _isRequest = isRequest;
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:_isRequest];
    if(!_isRequest)
    {
        self.appDelegate.dataLoadingView.hidden = YES;
        _tableView.tableHeaderView = nil;
    }
}

#pragma mark-内存管理
- (void)dealloc
{
    [_tableView release];
    
    [_bottomLoadingView release];
    [_httpRequest release];
    
    [_downloadProgressDic release];
    [_userDetailInfoDic release];
    
    [_infoArray release];
    [_selectedIndexPath release];
    [_overlayView release];
    
    [_hasNoMsgLabel release];
    
    [super dealloc];
}

#pragma mark- 视图消失出现


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if(self.isRequest)
    {
        [self.appDelegate closeAlertView];
    }
}

#pragma mark-httpRequest
- (void)httpRequest:(JBoHttpRequest *)request didFailed:(NSError *)error identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_getLeaveMsgIdentifier_])
    {
        self.isRequest = NO;
  
        self.pageIndex = self.oldPageIndex;
        [JBoUserOperation alertmsgWithBadNetwork:@"获取私信失败"];
        return;
    }
    
    if([identifier isEqualToString:_removeLeaveMsgIdentifier_])
    {
        self.isRequest = NO;
        [JBoUserOperation alertmsgWithBadNetwork:@"删除失败"];
    }
}

- (void)httpRequest:(JBoHttpRequest *)request didFinishedLoading:(NSData *)data identifier:(NSString *)identifier
{
    if([identifier isEqualToString:_getLeaveMsgIdentifier_])
    {
        self.isRequest = NO;
        self.pageIndex ++;
        NSMutableArray *array = [JBoLeaveMsgOperation getLeaveMsgFromData:data];
        self.hasInfo = array.count == _leaveMsgPageSize_;
        
        [self.infoArray addObjectsFromArray:array];
        
        if(!_tableView)
        {
            [self loadInitView];
        }
        
        [_tableView reloadData];
        
        if(array.count > 0)
        {
            [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:array.count - 1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
        }
        else
        {
            [self leaveMsgIsNull];
        }
    
        return;
    }
    
    if([identifier isEqualToString:_removeLeaveMsgIdentifier_])
    {
        self.isRequest = NO;
        [JBoUserOperation isSuccess:data];
        
        if(self.selectedIndexPath.row < _infoArray.count)
        {
            [_infoArray removeObjectAtIndex:self.selectedIndexPath.row];
            [_tableView beginUpdates];
            [_tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:self.selectedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            [_tableView endUpdates];
        }
        
        [self leaveMsgIsNull];
        return;
    }
}

#pragma mark-加载视图

- (void)back
{
    [_downloadProgressDic removeAllObjects];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.backItem = YES;
    
    [self loadLeaveMsg:[NSNumber numberWithBool:NO]];
}

- (void)loadInitView
{
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_ - _statuBarHeight_ - _navgateBarHeight_) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    
    [self leaveMsgIsNull];
}

//是否有私信
- (void)leaveMsgIsNull
{
    if(self.infoArray.count == 0)
    {
        if(!self.hasNoMsgLabel)
        {
            UILabel *label = [[UILabel alloc] initWithFrame:_tableView.bounds];
            label.backgroundColor = [UIColor clearColor];
            label.font = [UIFont boldSystemFontOfSize:20.0];
            label.textColor = [UIColor grayColor];
            label.textAlign = JBoTextAlignmentCenter;
            label.text = @"暂无私信";
            self.hasNoMsgLabel = label;
            [label release];
        }
        _tableView.tableFooterView = self.hasNoMsgLabel;
    }
    else
    {
        _tableView.tableFooterView = nil;
    }
}

- (void)loadLeaveMsg:(NSNumber*) hidden
{
    if(self.isRequest)
    {
        return;
    }
    
    _httpRequest.identifier = _getLeaveMsgIdentifier_;
    self.appDelegate.dataLoadingView.hidden = [hidden boolValue];
    self.isRequest = YES;
    [_httpRequest downloadWithURL:[JBoLeaveMsgOperation getLeaveMsgWithPageNum:self.pageIndex rows:_leaveMsgPageSize_]];
}

#pragma mark-tableview代理
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.infoArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    JBoLeaveMsgInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    if(info.contentSize.height == 0)
    {
        CGSize size = [JBoImageTextTool getStringSize:info.content withFont:_contentFont_ andContraintSize:CGSizeMake(_contentMaxWidth_, NSNotFound)];
        size.height += 10.0;
        info.contentSize = size;
    }
    
    return info.contentSize.height + _headViewSize_ + 10;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    JBoLeaveMsgCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell == nil)
    {
        cell = [[[JBoLeaveMsgCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
        cell.delegate = self;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    JBoLeaveMsgInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    JBoUserDetailInfo *detailInfo = [_userDetailInfoDic objectForKey:info.userId];
    
   // NSLog(@"%@",detailInfo);
    if(detailInfo)
    {
        // NSLog(@"%@",cell.multiImageView);
        cell.nameLabel.text = detailInfo.rosterInfo.name;
        cell.nameLabel.sex = detailInfo.rosterInfo.sex;
        cell.headImageView.role = detailInfo.rosterInfo.role;
        cell.headImageView.sex = detailInfo.rosterInfo.sex;
        
        UIImage *headImage = detailInfo.rosterInfo.image;
        if(headImage)
        {
            cell.headImageView.imageView.image = headImage;
        }
    }
    else
    {
        cell.headImageView.sex = _sexBoy_;
        cell.nameLabel.text = nil;
        
        if(!tableView.dragging && !tableView.decelerating)
        {
            [self downloadUserInfoForInfo:info];
        }
    }
    
    cell.dateLabel.text = [JBoDatetimeTool datetimeTool:info.date];
   // NSLog(@"%@",info.content);
    cell.contentSize = info.contentSize;
    cell.contentLabel.content = info.content;
   
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView shouldShowMenuForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (BOOL)tableView:(UITableView *)tableView canPerformAction:(SEL)action forRowAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender
{
    if(action == @selector(deleteMsg:))
    {
        return YES;
    }
    return NO;
}

- (void)tableView:(UITableView *)tableView performAction:(SEL)action forRowAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender
{
    if(action == @selector(deleteMsg:))
    {
        NSLog(@"delete");
    }
    
}

#pragma mark-cell代理
- (void)leaveMsgCell:(JBoLeaveMsgCell *)cell didSelectedURL:(NSURL *)url
{
    JBoWebViewController *web = [[JBoWebViewController alloc] init];
    web.URL = url;
    web.black = NO;
    [web showInViewController:self animated:YES completion:nil];
    [web release];
}

- (void)leaveMsgCellDidSelectedHeadImage:(JBoLeaveMsgCell *)cell
{
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    JBoLeaveMsgInfo *info = [self.infoArray objectAtIndex:indexPath.row];
    
    JBoRosterInfo *rosterInfo = [self.appDelegate.rosterAndUsernameDic objectForKey:info.userId];
    if(rosterInfo)
    {
        JBoContactDetailInfotViewController *detail = [[JBoContactDetailInfotViewController alloc] init];
        detail.rosterInfo = rosterInfo;
        [self.navigationController pushViewController:detail animated:YES];
        [detail release];
    }
    else
    {
        JBoPublickUserInfoViewController *userInfo = [[JBoPublickUserInfoViewController alloc] init];
        userInfo.userId = info.userId;
        [self.navigationController pushViewController:userInfo animated:YES];
        [userInfo release];
    }
}

- (void)leaveMsgCellDidLongPress:(JBoLeaveMsgCell *)cell
{
    if(self.isRequest)
        return;
    NSIndexPath *indexPath = [_tableView indexPathForCell:cell];
    self.selectedIndexPath = indexPath;
    
    [cell becomeFirstResponder];
    UIMenuItem *delete = [[UIMenuItem alloc] initWithTitle:@"删除" action:@selector(deleteMsg:)];

    CGRect rect = CGRectMake(cell.frame.origin.x, cell.frame.origin.y + 40, cell.frame.size.width, cell.frame.size.height - 40);
    UIMenuController *menu = [UIMenuController sharedMenuController];
    [menu setMenuItems:[NSArray arrayWithObjects:delete, nil]];
    [menu setTargetRect:rect inView:cell.superview];
    [menu setMenuVisible:YES animated:YES];

    [delete release];
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if(action == @selector(deleteMsg:))
    {
        return YES;
    }
    return NO;
}

- (void)deleteMsg:(id)sender
{
    if(self.selectedIndexPath.row < _infoArray.count)
    {
        self.isRequest = YES;
        JBoLeaveMsgInfo *info = [_infoArray objectAtIndex:self.selectedIndexPath.row];
        _httpRequest.identifier = _removeLeaveMsgIdentifier_;
        [_httpRequest downloadWithURL:[JBoLeaveMsgOperation removeLeaveMsgWithId:info.Id]];
    }
}

- (void)showOverlayView
{
    if(!self.overlayView)
    {
        self.overlayView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, _width_, _height_)] autorelease];
        self.overlayView.backgroundColor = [UIColor clearColor];
        
        UITapGestureRecognizer *dismissMenuTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissMenu:)];
        [self.overlayView addGestureRecognizer:dismissMenuTap];
        [dismissMenuTap release];
    }
    
    [self.view addSubview:self.overlayView];
}

- (void)dismissMenu:(UITapGestureRecognizer*) tap
{
    JBoLeaveMsgCell *cell = (JBoLeaveMsgCell*)[_tableView cellForRowAtIndexPath:self.selectedIndexPath];
    [cell resignFirstResponder];
    [self.overlayView removeFromSuperview];
}



#pragma mark-加载用户信息
- (void)downloadUserInfoForInfo:(JBoLeaveMsgInfo*) info
{
    if([NSString isEmpty:info.userId])
        return;
    
    JBoAsyncDownloadUserInfoOperation *asyncDownload = [_downloadProgressDic objectForKey:info.userId];
    if(!asyncDownload)
    {
        asyncDownload = [[JBoAsyncDownloadUserInfoOperation alloc] init];
        __block JBoAsyncDownloadUserInfoOperation *blockAsyncDownload = asyncDownload;
        
        asyncDownload.completionHandler = ^(void)
        {
            if(blockAsyncDownload.userDetailInfo)
            {
                if(blockAsyncDownload.userDetailInfo.rosterInfo.image)
                {
                    blockAsyncDownload.userDetailInfo.rosterInfo.image = [JBoImageTextTool getThumbnailFromImage:blockAsyncDownload.userDetailInfo.rosterInfo.image withSize:CGSizeMake(_headViewSize_, _headViewSize_)];
                }
                [_userDetailInfoDic setObject:blockAsyncDownload.userDetailInfo forKey:info.userId];
                [_tableView reloadData];
            }
            [_downloadProgressDic removeObjectForKey:info.userId];
        };
        [_downloadProgressDic setObject:asyncDownload forKey:info.userId];
        [asyncDownload downloadWithUserId:info.userId];
        [asyncDownload release];
    }
}

//加载可见的cell的好友头像
- (void)loadImageForOnScreenRows
{
    if(_infoArray.count > 0)
    {
        NSArray *indexPathArray = [_tableView indexPathsForVisibleRows];
        for(NSIndexPath *indexPath in indexPathArray)
        {
            JBoLeaveMsgInfo *info = [self.infoArray objectAtIndex:indexPath.row];
            JBoUserDetailInfo *detailInfo = [_userDetailInfoDic objectForKey:info.userId];
            
            if(!detailInfo)
            {
                [self downloadUserInfoForInfo:info];
            }
        }
    }
}

#pragma mark-scrollView代理  在用户停止拖动和拖动停止减速时加载图片
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(!decelerate)
    {
        [self loadImageForOnScreenRows];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self loadImageForOnScreenRows];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(self.hasInfo && !self.isRequest)
    {
        if(scrollView.contentOffset.y < - 10)
        {
            if(!_bottomLoadingView)
            {
                //创建加载更多视图
                _bottomLoadingView = [[JBoBottomLoadingView alloc] initWithFrame:CGRectMake(0, 0, _width_, 40)];
            }

            _tableView.tableHeaderView = _bottomLoadingView;
            [self performSelector:@selector(loadLeaveMsg:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.5];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    [_downloadProgressDic removeAllObjects];
}


@end
