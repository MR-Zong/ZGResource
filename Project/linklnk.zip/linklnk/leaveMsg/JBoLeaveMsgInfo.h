//
//  JBoLeaveMsgInfo.h
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JBoUserDetailInfo.h"

/**私信信息
 */
@interface JBoLeaveMsgInfo : NSObject

/**私信Id
 */
@property(nonatomic,copy) NSString *Id;

/**私信内容
 */
@property(nonatomic,copy) NSString *content;

/**发私信的日期时间
 */
@property(nonatomic,copy) NSString *date;

/**发私信的用户
 */
@property(nonatomic,copy) NSString *userId;

/**私信内容大小
 */
@property(nonatomic,assign) CGSize contentSize;

@end
