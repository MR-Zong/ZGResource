//
//  JBoLeaveMsgInfo.m
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLeaveMsgInfo.h"

@implementation JBoLeaveMsgInfo

- (id)init
{
    self = [super init];
    if(self)
    {
        self.contentSize = CGSizeZero;
    }
    return self;
}

- (void)dealloc
{
    [_Id release];
    [_content release];
    [_date release];
    
    [_userId release];
    [super dealloc];
}

@end
