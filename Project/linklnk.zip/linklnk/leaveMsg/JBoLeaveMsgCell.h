//
//  JBoLeaveMsgCell.h
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JBoChatMsgLabel.h"
#import "JBoUserNameLabel.h"
#import "JBoUserHeadImageView.h"

#define _contentLabelHeight_ 21.0
#define _contentMaxWidth_ 200.0
#define _headViewSize_ 40
#define _contentFont_ [UIFont systemFontOfSize:15.0]

@class JBoLeaveMsgCell;

/**私信信息的cell的代理
 */
@protocol JBoLeaveMsgCellDelegate <NSObject>

@optional

/**点击头像
 */
- (void)leaveMsgCellDidSelectedHeadImage:(JBoLeaveMsgCell*) cell;

/**点击链接
 *@param url 链接
 */
- (void)leaveMsgCell:(JBoLeaveMsgCell*) cell didSelectedURL:(NSURL*) url;

/**长按私信内容
 */
- (void)leaveMsgCellDidLongPress:(JBoLeaveMsgCell*) cell;

@end

/**私信信息的cell
 */
@interface JBoLeaveMsgCell : UITableViewCell<JBoChatMsgLabelDelegate>
{
    UIImageView *_msgBgImageView;
}

/**头像
 */
@property(nonatomic,readonly) JBoUserHeadImageView *headImageView;

/**昵称
 */
@property(nonatomic,readonly) JBoUserNameLabel *nameLabel;

/**私信内容
 */
@property(nonatomic,readonly) JBoChatMsgLabel *contentLabel;

/**发私信的日期
 */
@property(nonatomic,readonly) UILabel *dateLabel;

/**私信内容大小
 */
@property(nonatomic,assign) CGSize contentSize;
@property(nonatomic,assign) id<JBoLeaveMsgCellDelegate> delegate;

@end
