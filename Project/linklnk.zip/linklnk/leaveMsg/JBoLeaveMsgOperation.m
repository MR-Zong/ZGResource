//
//  JBoLeaveMsgOperation.m
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLeaveMsgOperation.h"
#import "JBoBasic.h"
#import "JBoUserOperation.h"
#import "JSONKit.h"
#import "NSString+customString.h"
#import "JBoLeaveMsgInfo.h"
#import "NSDictionary+customDic.h"

@implementation JBoLeaveMsgOperation

/**获取私信
 *@param pageNum 页码
 *@param rows 每页数量
 *@return get请求url
 */
+ (NSString*) getLeaveMsgWithPageNum:(int) pageNum rows:(int) rows
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%d&%@=%d", _getLeaveMsg_, _rosterUserId_, [JBoUserOperation getUserId], _pageNum_, pageNum, _rows_, rows];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**从返回的数据获取私信信息
 *@param data 返回的数据
 *@return 数组元素是 JBoLeaveMsgInfo对象
 */
+ (NSMutableArray*) getLeaveMsgFromData:(NSData *)data
{
    NSDictionary *dic = [data objectFromJSONData];
    
    NSLog(@"%@",dic);
    
    NSDictionary *resultDic = [dic dictionaryForKey:_result_];
    NSNumber *code = [resultDic valueWithKey:_code_];
    
    if([code integerValue] == _codeSuccess_)
    {
        NSArray *dataArray = [dic arrayForKey:_data_];
        NSMutableArray *infoArray = [[NSMutableArray alloc] init];
        
        for(NSInteger i = dataArray.count - 1;i >= 0;i --)
        {
            NSDictionary *dict = [dataArray objectAtIndex:i];
            JBoLeaveMsgInfo *info = [[JBoLeaveMsgInfo alloc] init];
            info.Id = [dict objectWithKey:_leaveMsgId_];
            info.content = [dict objectWithKey:_leaveMsgContent_];
            info.userId = [dict objectWithKey:_leaveMsgSender_];
            info.date = [dict objectWithKey:_leaveMsgDate_];
            
            [infoArray addObject:info];
            [info release];
        }
        
        return [infoArray autorelease];
    }
    else
    {
        return nil;
    }
}

/**发私信
 *@param content 私信内容
 *@param reveiver 接收者的userId
 *@return get请求url
 */
+ (NSString*) addLeaveMsgWithContent:(NSString*) content reveiver:(NSString*) reveiver
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@&%@=%@&%@=%@", _addLeaveMsg_, _leaveMsgSender_, [JBoUserOperation getUserId], _leaveMsgContent_, [NSString encodeStr:content], _leaveMsgReceiver_, reveiver];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

/**删除私信
 *@param leaveMsgId 私信Id
 *@return get请求url
 */
+ (NSString*) removeLeaveMsgWithId:(NSString*) leaveMsgId
{
    NSString *url = [NSString stringWithFormat:@"%@%@=%@", _deleteLeaveMsg_, _leaveMsgId_, leaveMsgId];
    url = [JBoUserOperation md5Url:url withUserId:YES];
    
    NSLog(@"%@",url);
    
    return url;
}

//设置标记
+ (void)setBadgeHidden:(BOOL) hidden
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *histroyDic = [defaults objectForKey:_leaveMsgReadState_];
    
    NSMutableDictionary *mutableHistoryDic = nil;
    
    if([histroyDic isKindOfClass:[NSDictionary class]])
    {
        mutableHistoryDic = [NSMutableDictionary dictionaryWithDictionary:histroyDic];
    }
    else
    {
        mutableHistoryDic = [NSMutableDictionary dictionaryWithCapacity:1];
    }
    
    [mutableHistoryDic setObject:[NSNumber numberWithBool:hidden] forKey:[JBoUserOperation getUserId]];
    [defaults setObject:mutableHistoryDic forKey:_leaveMsgReadState_];
    [defaults synchronize];
}

+ (BOOL)getBadgeState
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *histroyDic = [defaults objectForKey:_leaveMsgReadState_];
    
    if([histroyDic isKindOfClass:[NSDictionary class]])
    {
        NSNumber *number = [histroyDic objectForKey:[JBoUserOperation getUserId]];
        if([number isKindOfClass:[NSNumber class]])
        {
            return [number boolValue];
        }
        
        return YES;
    }
    return YES;
}

@end
