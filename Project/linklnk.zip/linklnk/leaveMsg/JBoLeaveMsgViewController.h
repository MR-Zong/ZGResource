//
//  JBoLeaveMsgViewController.h
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoViewController.h"

/**私信列表
 */
@interface JBoLeaveMsgViewController : JBoViewController<UITableViewDataSource,UITableViewDelegate>
{
    UITableView *_tableView;
}

@end
