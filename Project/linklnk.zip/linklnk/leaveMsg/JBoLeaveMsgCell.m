//
//  JBoLeaveMsgCell.m
//  连你
//
//  Created by kinghe005 on 14-3-25.
//  Copyright (c) 2014年 KingHe. All rights reserved.
//

#import "JBoLeaveMsgCell.h"
#import "JBoBasic.h"


#define _padding_ 10
#define _nameLabelWidth_ 110

@implementation JBoLeaveMsgCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        _headImageView = [[JBoUserHeadImageView alloc] initWithFrame:CGRectMake(_padding_, 5, _headViewSize_, _headViewSize_)];
        _headImageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headImageSelectedAction:)];
        [_headImageView addGestureRecognizer:tap];
        [tap release];
        [self.contentView addSubview:_headImageView];
        
        CGFloat controlHeight = 30.0;
        _nameLabel = [[JBoUserNameLabel alloc] initWithFrame:CGRectMake(_headImageView.frame.origin.x + _headImageView.frame.size.width + _padding_, _headImageView.frame.origin.y, _nameLabelWidth_, controlHeight)];
        _nameLabel.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:_nameLabel];
        
        CGFloat dateWidth = _width_ - _nameLabel.frame.origin.x - _nameLabel.frame.size.width - _padding_;
        _dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(_width_ - dateWidth - _padding_, _nameLabel.frame.origin.y, dateWidth, _nameLabel.frame.size.height)];
        _dateLabel.backgroundColor = [UIColor clearColor];
        _dateLabel.font = [UIFont systemFontOfSize:_dateFontSize_];
        _dateLabel.textColor = _dateTextColor_;

        [_dateLabel setTextAlign:JBoTextAlignmentRight];
        [self.contentView addSubview:_dateLabel];
        
        
        _contentLabel = [[JBoChatMsgLabel alloc] initWithFrame:CGRectZero];
        _contentLabel.contentFont = _contentFont_;
        _contentLabel.backgroundColor = [UIColor clearColor];
        _contentLabel.delegate = self;
        
        UIImage *receiverBubbleImage = [[UIImage alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"receive_bg@2x" ofType:_imageType_]];
        UIImage *resizeImage = [receiverBubbleImage resizableImageWithCapInsets:UIEdgeInsetsMake(15, 20, 10, 20)];
        _msgBgImageView = [[UIImageView alloc] initWithFrame:CGRectMake(_nameLabel.frame.origin.x, _nameLabel.frame.origin.y + _nameLabel.frame.size.height, 0, 0)];
        _msgBgImageView.image = resizeImage;
        _msgBgImageView.userInteractionEnabled = YES;
        //            [_messageBgImageView addGestureRecognizer:longPress];
        //            [longPress release];
        [self.contentView addSubview:_msgBgImageView];
        [_msgBgImageView addSubview:_contentLabel];
        [receiverBubbleImage release];
        
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressAction:)];
        [self.contentView addGestureRecognizer:longPress];
        [longPress release];
    }
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    [_headImageView release];
    [_msgBgImageView release];
    [_nameLabel release];
    [_dateLabel release];
    
    [_contentLabel release];
    
    [super dealloc];
}

- (void)longPressAction:(UILongPressGestureRecognizer*) longPress
{
    if(longPress.state == UIGestureRecognizerStateBegan)
    {
        [self becomeFirstResponder];
        if([self.delegate respondsToSelector:@selector(leaveMsgCellDidLongPress:)])
        {
            [self.delegate leaveMsgCellDidLongPress:self];
        }
    }
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}



- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat padding = 10.0;
    _msgBgImageView.frame = CGRectMake(_msgBgImageView.frame.origin.x, _msgBgImageView.frame.origin.y, self.contentSize.width + padding * 3 / 2, self.contentSize.height + padding);
    _contentLabel.frame = CGRectMake(padding, padding / 2, self.contentSize.width, self.contentSize.height);
   // NSLog(@"%@",_contentLabel);
}

- (void)headImageSelectedAction:(UITapGestureRecognizer*) tap
{
    if([self.delegate respondsToSelector:@selector(leaveMsgCellDidSelectedHeadImage:)])
    {
        [self.delegate leaveMsgCellDidSelectedHeadImage:self];
    }
}

#pragma mark-chatMsgLabel代理
- (void)chatMsgLabel:(JBoChatMsgLabel *)label didSelectedURL:(NSURL *)url
{
    if([self.delegate respondsToSelector:@selector(leaveMsgCell:didSelectedURL:)])
    {
        [self.delegate leaveMsgCell:self didSelectedURL:url];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
